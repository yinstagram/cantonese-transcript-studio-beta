# Website release checklist

核對日期：2026-08-29。呢份 checklist 係 production gate，唔係話目前 App 已可分發；未剔齊所有 blocking 項目前，唔准 upload、叫朋友測試或稱為 release。已安裝local private beta `0.8.12 (36)`同「網站公開可下載」係兩個分開嘅驗收狀態。

## 目前判斷

**FACT（100%）**：網站分發技術上可行，但現有`~/Applications/Cantonese Transcript Studio.app`係machine-local、ad-hoc signed build。2026-08-29已對installed `0.8.12 (36)`重跑`scripts/audit_distribution.sh --portable-only`，得到12 PASS／4 FAIL／0 WARN，`RESULT: NOT DISTRIBUTABLE`。

**FACT（100%）**：build36 regression係backend 938 passed、0 failed、另1 environment-gated skip（JUnit：`../dist/adversarial-audit/tests/backend-build36-after-recovery-fix.xml`），Swift Testing 165/165 passed、0 failed（`../dist/adversarial-audit/tests/swift-build36/`）。Installed bundle真跑Accuracy pipeline、15/15 format extraction、YouTube人工字幕、雙語／純譯文burn-in、speaker style burn-in、local API同restart recovery。完整finding disposition見`../dist/adversarial-audit/adversarial-audit-build36-final.json`；呢啲唔會將portable／license／signing／clean-Mac gates變成通過。

**DECISION（100%）**：公開網站版維持 **HOLD**。移除`mutagen`只解決一個dependency-license trap；self-contained runtime、nested helper／dylib notices同SBOM、FFmpeg renderer route、Wenet weights caveat、Sortformer converted／upstream license chain、Developer ID、notarization同clean-quarantine Mac仍然全部係blocking gates。

**FACT（100%）**：Apple對網站等 Mac App Store以外嘅正常分發路線係 Developer ID Application signature + Hardened Runtime + notarization。Apple Developer Program目前列明年費 USD 99或當地貨幣；enrollment、法律身份、2FA、certificate private key同付費都要 Yin本人決定，project唔會自行代辦。[Apple enrollment](https://developer.apple.com/help/account/membership/program-enrollment/)、[Developer ID](https://developer.apple.com/developer-id/)、[notarization](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution)

## Gate A — Product identity／外部決定

- [ ] Yin批准 Apple Developer Program付費／身份選擇。
- [ ] Apple Account 2FA完成；Developer ID private key只留Keychain／安全CI，唔入repo或chat。
- [ ] 將 `com.local.cantonesetranscriptstudio`換成Yin長期擁有嘅stable reverse-DNS bundle ID。
- [ ] 決定公開display name、support email、HTTPS domain同release owner。
- [ ] 定義版本政策：每個release提高 `CFBundleVersion`，artifact永不覆蓋同版本。

## Gate B — Self-contained App

- [ ] Python worker係 relocatable／frozen runtime，唔symlink去 `/opt/homebrew`或Application Support venv。
- [ ] MLX、sherpa／ONNX、NumPy及所有 native extension只含目標架構，rpath同dylib全部resolve喺bundle或Apple system library。
- [ ] Pinned `yt-dlp` core、`yt-dlp-ejs` 同 Deno 係 self-contained，唔依賴 Homebrew／Application Support external copy、PATH、runtime self-update 或 remote executable code。
- [ ] Bundled `ffmpeg` + `ffprobe`可做extraction；subtitle renderer有libass/font能力並通過真frame測試。
- [ ] `Info.plist`最低macOS 14，且不低於任何bundled Mach-O `minos`；主App同`CTSSpeakerDiarizer` helper都核對14.0，最少喺一部真正macOS 14 clean Mac跑完整雙模型、Sortformer同咪高峰權限。
- [ ] `CTSSpeakerDiarizer`同FluidAudio/Core ML runtime完全嵌入、inside-out簽署；helper只接受pinned local `.mlmodelc`，唔依賴SwiftPM checkout、project path或網絡loader。
- [ ] Models、Jobs、Logs、exports只寫入user Application Support／用戶揀選位置，唔改signed bundle。
- [ ] `scripts/audit_distribution.sh --portable-only <App>`係0 FAIL。

## Gate C — License／privacy

- [ ] FFmpeg/subtitle renderer由固定source revision reproducibly build；保存hash、configure line、patch同`otool -L` inventory。
- [ ] 用final `ffmpeg -buildconf`／`ffmpeg -L`決定LGPL或GPL義務；唔直接複製Homebrew GPL-enabled binary。
- [ ] DMG內有App、Python、FFmpeg、libass、font stack及全部 transitive dependency notices／適用source offer。
- [ ] `yt-dlp==2026.7.4` 只用 core wheel，`yt-dlp-ejs==0.8.0` 獨立 pin；project lock、built runtime 同 SBOM 均證明冇 `mutagen`。每次重建後用真實獲授權 fixture 重跑 video／audio／caption import，唔可以只因 dependency 列表變短就當通過。
- [ ] 附 `yt-dlp` Unlicense、`yt-dlp-ejs` Unlicense／MIT／ISC、Deno MIT、sherpa Apache-2.0、ONNX Runtime MIT 同 matching third-party notices；正式 bundle 嘅實際 inventory 同 SBOM 對得上。
- [ ] Verifier archive嘅license caveat再次審核；models唔bundle入DMG。
- [ ] Sortformer license chain完成release review：FluidAudio 0.15.5係Apache-2.0；converted repo metadata係CC BY 4.0；NVIDIA upstream係NVIDIA Open Model License。Notices、attribution、model download UI同redistribution策略要由actual artifact inventory一致證明，唔可以只列SDK license。
- [ ] 下載頁預先列 exact model names、pinned revisions／hashes同重新量度 network sizes。2026-08-26 本機 installed logical baseline：1.7B + verifier + ForcedAligner + Sortformer + CAM++ 6,815,947,541 bytes（約6.348 GiB）；0.6B primary 組合 3,993,451,630 bytes（約3.719 GiB）；1.7B Accuracy + Whisper Large v3 9,910,981,846 bytes（約9.230 GiB）。
- [ ] Privacy 明確分開三種情況：App／model 下載要網絡；用戶主動 YouTube import 要網絡並向平台／CDN 送出一般 request metadata；本機檔案 ASR、字幕、burn-in、exports 只喺本機。全 App 冇 analytics／telemetry。
- [ ] YouTube UI 保留 rights confirmation，並清楚說明公開可看唔代表有下載權；software license 唔當成 media license。

FFmpeg upstream compliance入口：[FFmpeg legal](https://ffmpeg.org/legal.html)、[FFmpeg license](https://ffmpeg.org/doxygen/trunk/md_LICENSE.html)。

**FACT（100%）**：本機 dependency-closure regression 已用 82.121 秒獲授權單 URL fixture 驗證 `yt-dlp` core + EJS + Deno、冇 `mutagen`、video／audio／zh-Hant caption／6 exports／manifest／restart read-back，16.168 秒完成；current targeted suite另有 `60 passed`。Playlist、multi-URL batch、人工字幕、無字幕 fallback同 network cancel／resume目前只係 deterministic tests，唔係全 live矩陣。Gate C 仍然保持未剔，因為呢個 smoke 亦唔係最終 signed／notarized public bundle嘅 SBOM同 clean-Mac驗收。

## Gate D — Signing／notarization／DMG

- [ ] 所有nested executable、framework、dylib、helper由inside-out用同一Developer ID team簽署；唔用`codesign --deep`代替正確signing hierarchy。
- [ ] 主App有Hardened Runtime、secure timestamp同最少必要entitlements。
- [ ] `codesign --verify --deep --strict --verbose=4 <App>`通過。
- [ ] 用`notarytool`提交、status係`Accepted`；App ticket已staple並validate。
- [ ] `spctl -a -t exec -vv <App>`顯示`source=Notarized Developer ID`。
- [ ] `scripts/audit_distribution.sh <App>`係0 FAIL。
- [ ] 用`scripts/package_release.sh`建立signed、notarized、stapled DMG同SHA-256；script缺identity/profile或external runtime必須拒絕。

Apple明確接受UDIF DMG、flat PKG同ZIP做notarization container；ZIP ticket唔可以直接staple，所以本App以DMG做朋友／公眾首選。[Apple notarization workflow](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow)、[packaging](https://developer.apple.com/documentation/xcode/packaging-mac-software-for-distribution)

## Gate E — Clean quarantine Mac

- [ ] DMG經實際HTTPS browser下載，保留`com.apple.quarantine`；唔用AirDrop／本地copy冒充下載測試。
- [ ] 乾淨、冇Homebrew／project venv／models嘅Apple Silicon Mac可以拖入Applications並正常開啟。
- [ ] 用 Finder 對 current signed candidate 真實拖入 M4A、MP4 同多選 batch；逐項加入／移除、right-click 移除、multi-select 移除、clear-all confirmation 同「開始處理」全部有 UI read-back。File picker、Swift drag regression或舊build拖放證據唔可以代替呢一項。
- [ ] 15種支援副檔名逐一做真 `ffprobe` + 16kHz mono WAV extraction；至少 M4A、MP4 再完整跑到雙ASR、reconciliation、OpenCC同exports。Format probe通過唔等於15種格式全部跑完整模型。
- [ ] Gatekeeper首次提示顯示正確identified developer；毋須Terminal、毋須全域降低安全設定。
- [ ] 首次 model 確認、download progress、resume、SHA-256、missing/error UI 全部實測；預設 required list 包括 primary、verifier、ForcedAligner 同 speaker models，Accuracy Mode 另加 Whisper Large v3；Large v2只屬legacy compatibility。
- [ ] 真影片完整跑：extract → Qwen → verifier → reconciliation → Sortformer（auto／1–4）或legacy（>4）→香港繁體 → ForcedAligner →字幕 edit／speaker rename／reassign／style → live preview → burn-in →六種export（TXT、timestamp TXT、SRT、VTT、JSON、CSV）。
- [ ] 真咪高峰開始／權限拒絕後恢復／partial／final／stop／cancel／overrun／App中途退出全部喺clean Mac實測；普通即時字幕喺CAM++缺失時仍只出字幕，Lazy Camman缺CAM++必須拒絕開始。另以已註冊closed roster驗A→B→A、Unknown、stop同cancel。
- [ ] 普通「即時字幕」只驗字幕／AI提示，確認完全冇講者辨認；Lazy Camman另用房間咪高峰驗已註冊A→B→A、短句、相似聲線、WhatsApp playback、重疊講話、誤報率、畫面flash同project重開。
- [ ] 個人詞庫畫面清楚披露accepted subtitle edits會本機學習；opt-out、手動alias、兩次確認policy、import／export、逐項delete、clear-all confirmation、restart同corrupt import fail-closed全部實測。
- [ ] ForcedAligner 實測 cancel、no-progress timeout、child crash、App restart chunk resume 同完成後 chosen-text exact preservation；冇 orphan child／helper。
- [ ] YouTube 單 URL、多 URL、playlist partial failure、cancel、retry、restart resume，video／audio／人工字幕／自動字幕／無字幕 ASR fallback 全部用獲授權 fixtures 實測；raw／normalized caption、artifact hashes 同 6 exports 讀回。
- [ ] Burn-in output用`ffprobe`驗audio/video stream、duration、rotation/VFR，並抽頭／中／尾frame做視覺QC。
- [ ] App重開可恢復queue、字幕project同render狀態；cancel唔留貌似完成嘅partial output。
- [ ] 用 multi-GB 媒體驗證 import-time quick fingerprint 只讀開頭／結尾各 4 MiB、duration 非同步回填、background full SHA-256 seal；batch 一項失敗唔會阻止其餘項目加入，重複 start／retry 唔會產生兩個 queue slot。
- [ ] Release page列version、minimum OS、Apple Silicon、DMG bytes、SHA-256、model sizes、privacy、licenses、release notes同support contact。

## 最近一次 portable read-back（current expected-failure evidence）

2026-08-29對 installed build36 執行：

```zsh
scripts/audit_distribution.sh \
  --portable-only \
  "$HOME/Applications/Cantonese Transcript Studio.app"
```

Installed `0.8.12 (36)` read-back exit code`1`；總結係`12 PASS, 4 FAIL, 0 WARN`／`RESULT: NOT DISTRIBUTABLE`。完整log：`../dist/adversarial-audit/tests/installed-build36-portable-audit.log`。呢次係portable scope，所以明確跳過Developer ID／notarization檢查；production gate仍要用一個真正self-contained、擬公開嘅candidate跑default full scope。

實際讀返嘅 4 個 blocking failures：

| Audit 項目 | 現況 | 結果 |
|---|---|---:|
| Bundle ID | `com.local.cantonesetranscriptstudio` | FAIL |
| Python/helper | 冇embedded runtime；worker用Application Support venv | FAIL |
| FFmpeg/ffprobe | 冇embedded tools；依賴Homebrew | FAIL |
| Backend paths | bundled worker仍含external runtime fallback | FAIL |

Signature／notarization由今次 portable scope明確跳過；另行 `codesign --verify --deep --strict` 通過只證明現有 ad-hoc bundle完整，唔等於 production gate。

呢個fail結果係安全證據：目前build script只會產生local App，唔會靜靜產生可誤會為portable/notarized嘅release。修正後必須重新跑audit；唔可以手動改呢張表當成通過。

## 唔可以做嘅 shortcut

- 唔可以因為App得幾MB就直接ZIP/upload；細係因為runtime喺bundle外。
- 唔可以叫朋友全域關閉Gatekeeper、執行`spctl --master-disable`或清除quarantine。
- 唔可以將Apple notarization當成功能QA；佢唔驗ASR準確、字幕畫面或model相容性。
- 唔可以將Homebrew FFmpeg executable單獨copy入App；佢仲有外部dylib同redistribution義務。
- 唔可以因為FluidAudio SDK係Apache-2.0就忽略converted Sortformer repo嘅CC BY 4.0 metadata同NVIDIA upstream model license；三層要分開審。
- 唔可以將ad-hoc beta稱為正式網站release。
