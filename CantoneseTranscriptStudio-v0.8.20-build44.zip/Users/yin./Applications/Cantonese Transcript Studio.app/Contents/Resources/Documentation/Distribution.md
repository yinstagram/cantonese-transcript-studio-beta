# Website distribution audit

核對日期：portable audit、本機 build／signing read-back均更新至2026-08-29。呢份文件只評估將 App 放上網站俾朋友下載；未有進行 Developer ID signing、notarization或 upload。呢份亦唔係法律意見。

## 結論先講

**FACT（100%）**：可以將 `Cantonese Transcript Studio` 做成網站下載 App，但**目前 local beta 唔可以原封不動當成可攜式 release**。2026-08-29 read-back嘅installed bundle係arm64 `0.8.12 (36)`、minimum macOS 14、18,964 KiB filesystem allocation、strict ad-hoc signature有效但冇Team ID；candidate同installed嘅105-file canonical inventory SHA-256同為`2712db20bada8575fc8c6ec5cfc14014dfa7e49557eb2012bce9c8d3a4b50dae`。呢個係inventory digest，唔係未來DMG／ZIP downloadable artifact hash。App仍依賴Application Support／Homebrew嘅Python、FFmpeg、Deno及`whisper-server`；呢啲runtime尚未bundle、未經clean-Mac smoke。Current portable audit係12 PASS／4 FAIL／`NOT DISTRIBUTABLE`；本機真模型smoke同資料保留證據唔會推論朋友下載版已可用。

**INFERENCE（98%）**：最合理產品路線係：模型繼續首次啟動後按用戶確認下載；App 本身改為內置 Python worker runtime、經 license 審核嘅 FFmpeg build，同埋簽署／驗證過嘅 whisper.cpp server runtime；之後先做 Developer ID signing、Hardened Runtime、Apple notarization、stapling，同一個可拖入 Applications 嘅 DMG。唔應該將 4–7GB models 包入網站下載檔。

**DECISION（99%）**：Docker唔係朋友下載版。佢喺 Mac提供Linux VM／container reproducibility，唔會將現有 SwiftUI App變成portable product，普通 container亦冇目前 MLX／Metal ASR路徑。Aiko對照同17條第一方來源見 [Aiko／Docker研究](aiko-native-distribution-research.md)。

**FACT（100%）**：2026-08-29對已安裝 `0.8.12 (36)` 執行 `scripts/audit_distribution.sh --portable-only`，結果係12 PASS／4 FAIL／0 WARN、`RESULT: NOT DISTRIBUTABLE`。四個failure係development-only bundle ID、冇embedded Python、冇bundled FFmpeg／ffprobe，同bundled backend仍含external runtime paths；完整log係`../dist/adversarial-audit/tests/installed-build36-portable-audit.log`。在Developer ID、notarization同clean-Mac驗收前，公開分發維持 **HOLD**。真Accuracy pipeline、Gemma字幕smoke或Lazy Camman backend test亦唔會自動解決packaging blockers。

## 目前版本點解唔 portable

以下係本機 code、bundle 同 executable read-back，唔係估計。

| 阻礙 | 實際證據 | 判斷 |
|---|---|---|
| Python 唔喺 App 入面 | App 只包 `Contents/Resources/Backend` source；worker 固定搵 `~/Library/Application Support/Cantonese Transcript Studio/Runtime/.venv/bin/python` | FACT 100% |
| venv 再依賴 Homebrew Python | 現有 `Runtime/.venv/bin/python` 係 symlink，指去 `/opt/homebrew/opt/python@3.12/bin/python3.12` | FACT 100% |
| FFmpeg 唔喺 App 入面 | Swift worker PATH 加 `/opt/homebrew/bin`；Python fallback 固定 `/opt/homebrew/bin/ffmpeg`、`ffprobe` | FACT 100% |
| Whisper live runtime 唔喺 App 入面 | Small `zh` + Large-v3 `yue` live ASR 目前由 `/opt/homebrew/bin/whisper-server` 兩個 local child 提供；呢個 binary同其 dylibs冇嵌入／簽署喺 App | FACT 100% |
| 首次安裝器唔喺 App 入面 | `bootstrap.sh` 需要 repo、Terminal、Homebrew、`uv`；App 自己喺 Python runtime missing 時無法先啟動 model manager | FACT 100% |
| 未有可公開驗證嘅 release signature | `codesign` 顯示 `Signature=adhoc`、`TeamIdentifier=not set`；現有 build 有 `runtime` flag，但冇 Developer ID／notarization identity，`spctl -a -t exec` 仍回報 rejected | FACT 100% |
| 架構只係 arm64 | App executable 同現有 native Python extensions 都係 Apple Silicon／arm64 | FACT 100% |
| 對外最低系統版本未成立 | Build32 `Info.plist`宣告macOS 14.0，但external runtime入面嘅MLX／ONNX wheels曾讀到較高`minos`；未用final self-contained runtime喺clean macOS 14實機跑完整pipeline | FACT 100% |
| 無公眾 release identity | 2026-08-08 read-back：Bundle ID仍係`com.local.cantonesetranscriptstudio`，本機 build `Signature=adhoc`、`TeamIdentifier=not set`，`security find-identity -v -p codesigning` 找不到有效 identity；冇 Developer ID／notarization identity | FACT 100% |

Python 官方亦明確話 `venv` 一般係 inherently non-portable，入面 script 會有 interpreter 絕對路徑，搬去另一個位置應重新建立，而唔係直接 copy。[Python venv 文件](https://docs.python.org/3.12/library/venv.html)

**FACT（100%）**：所以將現有約18.20 MiB filesystem allocation嘅`.app` zip起再upload，朋友就算成功繞過Gatekeeper，仍然會見到「本機處理器未安裝完成」。只有一部預先裝好同一路徑Homebrew Python、所有pinned wheels、FFmpeg同models嘅Mac先可能直接運作；呢個唔係可接受嘅朋友下載體驗。

## 真正可派發 bundle 應該包含乜

```text
Cantonese Transcript Studio.app
└── Contents/
    ├── MacOS/                  # Swift app + signed worker launcher/helper
    ├── Frameworks/             # Python/native dylibs，逐個 Developer ID sign
    └── Resources/
        ├── Backend/            # pure Python code/data
        ├── Runtime/            # relocatable Python stdlib/site packages
        ├── Tools/              # bundled ffmpeg + ffprobe + whisper-server
        └── Licenses/           # Python、FFmpeg、全部 bundled dependency notices
```

**FACT（99%）**：Apple 要 nested executables、frameworks、dylibs 同 helper 有有效 signature；手動 workflow 要由最入面開始逐層 sign，最後先 sign 主 App。Apple 明確唔建議用 `codesign --deep` 代替正確 signing hierarchy。[Apple distribution signing](https://developer.apple.com/documentation/xcode/creating-distribution-signed-code-for-the-mac)、[TN2206](https://developer.apple.com/library/archive/technotes/tn2206/)

**INFERENCE（95%）**：唔應該將現有 Application Support venv 原樣搬入 bundle。應該製作一個針對 release deployment target 嘅 relocatable／frozen arm64 Python worker，將 pure Python、CPython、MLX、sherpa／ONNX、NumPy、whisper.cpp server／Metal dylibs 同其他 native extensions放入正確 bundle 位置，再逐個做 signature、rpath 同 clean-machine launch 驗證。

**INFERENCE（90%）**：Hardened Runtime 初版應先用最少 entitlements；所有 native libraries 用同一 Developer ID team 正確 signing。除非實測證明必要，唔應預設加入 `disable-library-validation` 等廣泛例外。

**FACT（100%）**：models、jobs 同 user exports 仍然留喺 Application Support，唔應寫入已簽名 `.app`。Model downloader 已經有確認、progress、resume、manifest／SHA-256 驗證，runtime self-contained 後可以沿用。

## 最低 macOS 同硬件

- **FACT（100%）**：MLX 官方 0.32.0 文件要求 Apple Silicon、native Python 3.10+、macOS 14.0+。[MLX install requirements](https://ml-explore.github.io/mlx/build/html/install.html)
- **FACT（100%）**：目前 release artifacts 只係 arm64；Intel Mac 唔支援。
- **FACT（100%）**：目前實際 installed MLX native code曾讀到`minos 26.2`，verifier ONNX Runtime dylib曾讀到`minos 15.5`；因此build36 `LSMinimumSystemVersion=14.0`只係App宣告，唔足以證明整個external runtime喺clean macOS 14相容。
- **UNKNOWN**：最終最低版本要等 release runtime 喺目標 SDK 重建／揀正確 wheel，再喺乾淨實機做 Qwen + verifier full pipeline 先可以落實。
- **建議（INFERENCE 95%）**：朋友 beta 先寫「Apple Silicon、macOS 15.5 或以上」，並實測至少一部乾淨 M1/M2 Mac。若要正式支援 macOS 14，先解決 sherpa／ONNX `minos 15.5` 同鎖定 MLX 14 wheel，再建立 macOS 14 test matrix。絕對唔好而家對外寫 macOS 13+。

## Download size／首次模型下載

| 項目 | 本機 read-back／估算 | 判斷 |
|---|---:|---|
| 現有 build36 `.app` | 2026-08-29 `du -sk`讀回18,964 KiB（約18.52 MiB filesystem allocation）；只含Swift executable、helper同backend source，唔含portable runtime | FACT 100% |
| 現有 Python site-package runtime | 336,660,628 bytes／321.06 MiB；但未包含外部 base Python | FACT 100% |
| 現有 Homebrew Python logical files | 77,133,520 bytes／73.56 MiB | FACT 100% |
| 現有 venv + Python gzip stream | 約 132 MiB；未計 App、FFmpeg、DMG、signatures | FACT 99% |
| 最終 self-contained DMG | 約 150–220 MiB download、約 450–600 MiB installed | INFERENCE 80% |
| 預設 1.7B + verifier 首次網絡下載 | 約 4.489 GiB；完成後約 4.511 GiB disk | FACT 99% |
| 0.6B + verifier 首次網絡下載 | 約 1.861 GiB；完成後約 1.883 GiB disk | FACT 99% |
| 兩個 Qwen + verifier 全部裝齊 | 約 6.263 GiB disk | FACT 100% |
| 即時字幕 Whisper Small + Large-v3 | 3,582,635,450 bytes／約3.336 GiB（兩個 pinned weight files） | FACT 100% |

**INFERENCE（98%）**：網站只 host 約 150–220MB App DMG；models 繼續由官方 Hugging Face／sherpa release 首次下載，可以大幅減低網站 bandwidth、notarization size 同 weights redistribution 風險。下載頁要按功能分開講清楚 batch 轉錄需要嘅模型，並另列 live caption 必需嘅 Small + Large-v3 約3.336GiB；唔可以將舊 Wenet live 路徑當作替代。

## FFmpeg redistribution／license

**FACT（100%）**：目前 App 冇分發 FFmpeg，而係執行 Yin 本機 Homebrew binary；該 binary 自報 FFmpeg 8.1.1、`--enable-gpl --enable-version3`，license 係 GPL version 3 or later。佢亦動態依賴 Homebrew Cellar 內多個 libraries，所以唔可以只 copy `ffmpeg`、`ffprobe` 兩個檔就叫 portable。

**FACT（100%）**：FFmpeg 官方話 default 主要係 LGPL 2.1+；加入 `--enable-gpl` components 後，整個 FFmpeg binary 會轉為 GPL。官方 redistribution checklist要求提供對應 source、build changes／configure資料、license notice等；LGPL route亦建議唔開 `--enable-gpl`、`--enable-nonfree`，並處理 relinking／source obligations。[FFmpeg legal](https://ffmpeg.org/legal.html)、[FFmpeg license](https://ffmpeg.org/doxygen/trunk/md_LICENSE.html)

**建議（INFERENCE 98%）**：公眾 build 唔好重分發目前 Homebrew GPLv3 binary。另建一個只包含實際需要 demux、decode、resample、WAV output（以及將來經審核嘅 subtitle burn-in encode）嘅 reproducible FFmpeg build，唔開 `--enable-gpl`／`--enable-nonfree`；保存 exact source tarball、hash、configure line、patch、license texts，並喺 App About、DMG同下載頁提供 notices/source link。加入 burn-in encoder／libass 後要重新做一次 dependency-by-dependency license review。

**UNKNOWN**：最終 FFmpeg build 係咪完全符合所有 open-source license、codec patent同所在司法區要求，仍要用 final binary/configure output 做正式 legal review；免費派俾朋友唔會免除 redistribution obligations。

## Developer ID、notarization、Gatekeeper

**FACT（100%）**：Apple 對網站等 Mac App Store 以外下載，正常路線係 Developer ID Application signature + notarization。Gatekeeper會檢查 identified developer、notarization同下載後有冇被改；首次啟動仍會要求用戶確認。[Developer ID certificates](https://developer.apple.com/help/account/certificates/create-developer-id-certificates/)、[Gatekeeper](https://support.apple.com/en-us/guide/security/sec5599b66df/web)

**FACT（100%）**：notarization 要用 Developer ID（ad-hoc 唔得）、所有 executable 有有效 signature、Hardened Runtime同 secure timestamp。現行 command-line service 用 `notarytool`；成功後可以 staple ticket，令 Gatekeeper離線亦可驗。[Apple notarization](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution)

**FACT（100%）**：Apple notary service接受 UDIF DMG、flat PKG同 ZIP；ZIP 可以 submit，但 ticket 唔可以直接 staple 去 ZIP。[Custom notarization workflow](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow)

**建議（INFERENCE 98%）**：本 App 唔需要安裝 system daemon／system extension；用 signed + notarized DMG 最簡單。DMG 放 App 同 `/Applications` shortcut，App 自己喺 user Application Support 建 models/jobs/runtime data；唔需要 `.pkg` 或 admin installer。

Production release gate：

1. 建 self-contained app；逐個驗 native dependency architecture、deployment target、rpath同 license。
2. 用 Developer ID Application identity，由 nested code inside-out signing；主 app 用 secure timestamp + Hardened Runtime。
3. `codesign --verify --deep --strict`，再跑真實 batch pipeline smoke，同埋 Small／Large-v3 live pair 的 physical-mic smoke。
4. 建 signed DMG；用 `notarytool` submit並保存 submission ID／log。
5. Accepted 後 staple、`stapler validate`、`spctl` 驗證。
6. 將 DMG 經真正 browser 下載，保留 quarantine，喺乾淨、非開發 Mac拖入 Applications再跑完整 pipeline。
7. 網站列 version、system requirements、SHA-256、download size、首次 model size、privacy、licenses同 release notes。

## DMG、ZIP 定 PKG

| 格式 | 用途 | 建議 |
|---|---|---|
| DMG | 朋友／公眾第一次網站下載；可放 `/Applications` shortcut，可 notarize及 staple | **首選**；INFERENCE 98% |
| ZIP | 最簡單 beta artifact；Apple 接受作 notarization container，但 ZIP 本身不能 staple | 可做內部 beta／將來 Sparkle payload；FACT 100% |
| PKG | 需要安裝多個 system locations、daemon或特殊權限時 | 呢個 App 暫時唔需要；INFERENCE 98% |

Apple 有獨立 packaging guidance：[Packaging Mac software for distribution](https://developer.apple.com/documentation/xcode/packaging-mac-software-for-distribution)。

## 兩階段可落地方案

### A. 免費朋友 beta

**可以做，但唔係將現有 App 直接 upload。**

1. 先完成 self-contained arm64 bundle、bundled FFmpeg notices、部署版本修正同 clean-Mac smoke。
2. 暫時 ad-hoc sign，再用 `ditto` 產生 ZIP或 DMG，同時發 SHA-256。
3. 朋友需要清楚知道開發者未經 Apple Developer ID驗證；只可用 Finder control-click「開啟」或 macOS提供嘅單次 Privacy & Security override，唔可以要求佢哋全域關閉 Gatekeeper。
4. 只邀請少量、認識 Yin、同意測試風險而且有相容 Apple Silicon／macOS 嘅朋友。
5. 每個 build仍然要完整 license notices、版本號同 clean-machine regression。

**FACT（100%）**：Apple確認用戶可以對未符合預設 Gatekeeper policy嘅軟件作明確 override，除非部機受 MDM限制；但呢個體驗唔適合普通公眾。[Gatekeeper](https://support.apple.com/en-us/guide/security/sec5599b66df/web)

### B. 正式網站發布

完成 production release gate，提供 notarized/stapled DMG、HTTPS下載頁同版本化 release。呢條路唔需要 Mac App Store審批；Apple notarization係 automated malware/code-signing check，唔係 App Review。[Apple notarization](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution)

## Sparkle／自動更新（只評估，今次唔加入）

**FACT（99%）**：Sparkle 2支援 macOS App更新、DMG／ZIP等 payload、HTTPS appcast、EdDSA update signatures、Apple code-sign validation同 delta updates。[Sparkle documentation](https://sparkle-project.org/documentation/)

**建議（INFERENCE 97%）**：第一個朋友／公眾 release先用網站手動下載新 DMG，等 signing、bundle layout、version policy穩定後先加入 Sparkle。加入時要：

- 將 Sparkle framework/helpers當 nested code正確 Developer ID sign + notarize；
- 用 HTTPS appcast、EdDSA archive signature，private key只放 Keychain／安全 CI，唔放 web server；
- 每次提高 `CFBundleVersion`；
- models繼續由 model manager獨立管理，唔塞入 App update；
- 更新 privacy wording：屆時網絡用途唔再只得模型下載，update check亦會連線；預設應透明並俾用戶控制。

## 需要 Yin 提供／付費／批准嘅外部條件

| 條件 | 點解要 Yin 決定 | 狀態 |
|---|---|---|
| Apple Developer Program membership | Developer ID／notarization正式分發需要；Apple現列年費 USD 99或當地貨幣，價格因地區而異 | 需要付費／Yin批准；FACT 100% |
| Enrollment身份 | Individual會用個人法律身份；Organization要合法實體、D-U-N-S等資料 | 需要 Yin選擇；FACT 100% |
| Apple Account 2FA、Developer ID private key | 必須由 Yin本人安全建立／保存在 Keychain；唔可以將 password、app-specific password或private key交入 repo/chat | 需要 Yin操作或現場批准；FACT 100% |
| Stable bundle identifier | `com.local...`唔適合作長期更新 identity；要先決定一個擁有／會長期保留嘅 reverse-DNS ID | 需要 Yin批准；INFERENCE 98% |
| Website／HTTPS hosting | 放 DMG、checksums、privacy、release notes同 FFmpeg source／notices | 需要 Yin指定 domain／hosting；INFERENCE 98% |
| Public display name／support contact | Developer ID dialog、網站、About、release notes要一致 | 需要 Yin批准；INFERENCE 95% |
| 完整 Xcode | 呢部機而家只有 Command Line Tools；已有 `notarytool`／`stapler`，但 production archive/signing QA建議裝目前支援嘅完整 Xcode | 需要下載空間／Yin批准；FACT 95% + recommendation |
| Clean test Macs／朋友名單 | 現有驗收只喺呢部 macOS 26 Apple Silicon；Gatekeeper同最低版本一定要用真正 quarantine clean download測 | 需要外部測試者；FACT 100% |
| License release decision | Models唔 bundle可減低風險；FFmpeg／Python／全部 transitive binaries仍要 notices。若日後分發 verifier weights，要先處理現有 archive-level license caveat | 需要 Yin接受 release policy；FACT 99% |

Apple官方 enrollment頁列年費同身份要求：[Program enrollment](https://developer.apple.com/help/account/membership/program-enrollment/)。

## Adversarial check：最容易誤判嘅四件事

1. **「App得約5.3MiB，所以upload就得」係錯。** 細只因為約400MB runtime／Python同 FFmpeg留咗喺 bundle外。
2. **「免費送朋友就唔使理 signing/license」係錯。** 免費 beta可以請朋友單次 override Gatekeeper，但 open-source redistribution obligations仍然存在。
3. **「Info.plist寫macOS 13就支援13」係錯。** native wheel內嘅 Mach-O minimum OS先係真限制；目前最嚴係 MLX 26.2。
4. **「notarized即係所有功能可靠」係錯。** Apple notarization只掃 malware同 code-signing問題；ASR準確度、MLX／sherpa／whisper.cpp compatibility、model downloads、Small／Large-v3 physical-mic latency同長片效能仍要自己做 clean-machine smoke。

## 已驗證 primary sources

以下每條 URL 已於 2026-08-04 用 `curl -sIL` 驗證；200代表當時可達，唔代表 Apple／上游永久不改政策。

| Source | 支援範圍 | HTTP |
|---|---|---:|
| [Developer ID certificates](https://developer.apple.com/help/account/certificates/create-developer-id-certificates/) | 網站外分發 certificate | 200 |
| [Notarizing macOS software](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution) | Developer ID、Hardened Runtime、timestamp、ticket | 200 |
| [Customizing notarization workflow](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow) | `notarytool`、ZIP／DMG／PKG、stapling限制 | 200 |
| [Creating distribution-signed code](https://developer.apple.com/documentation/xcode/creating-distribution-signed-code-for-the-mac) | nested signing、timestamp、runtime option | 200 |
| [Packaging Mac software](https://developer.apple.com/documentation/xcode/packaging-mac-software-for-distribution) | DMG packaging | 200 |
| [Gatekeeper and runtime protection](https://support.apple.com/en-us/guide/security/sec5599b66df/web) | quarantine／first launch／user override | 200 |
| [Apple Developer Program enrollment](https://developer.apple.com/help/account/membership/program-enrollment/) | 年費、身份、2FA／enrollment | 200 |
| [Apple TN2206](https://developer.apple.com/library/archive/technotes/tn2206/) | code bundle layout、inside-out signing | 200 |
| [Python 3.12 venv](https://docs.python.org/3.12/library/venv.html) | venv non-portability | 200 |
| [Python license](https://docs.python.org/3/license.html) | CPython redistribution notices | 200 |
| [FFmpeg legal](https://ffmpeg.org/legal.html) | LGPL compliance checklist | 200 |
| [FFmpeg license](https://ffmpeg.org/doxygen/trunk/md_LICENSE.html) | `--enable-gpl`／external library impact | 200 |
| [Sparkle documentation](https://sparkle-project.org/documentation/) | secure update evaluation | 200 |
| [MLX install requirements](https://ml-explore.github.io/mlx/build/html/install.html) | Apple Silicon、macOS 14+ | 200 |
