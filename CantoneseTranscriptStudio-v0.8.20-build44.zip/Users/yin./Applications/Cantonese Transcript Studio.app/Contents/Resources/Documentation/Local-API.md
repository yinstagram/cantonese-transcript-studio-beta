# Local API／Apple Shortcuts

Local API 係 opt-in，只會喺 App 開住並且設定頁開啟後，綁定 `127.0.0.1`。正常轉錄仍然完全 offline；唔會監聽 LAN、唔會公開 port。

## 開啟

1. 開啟 App →「設定」→「Local API／Apple Shortcuts」→ 打開「容許本機自動化」。
2. 關閉並重新開啟 App。
3. App 會喺以下位置寫入 mode `0600` 嘅 token 設定檔：

   `~/Library/Application Support/Cantonese Transcript Studio/local-api.json`

API 預設位址係 `http://127.0.0.1:8765/v1`。Token 只可以由本機設定檔讀取，唔好分享或上載。

## Endpoints

所有 request 都要加 `X-CTS-Token`，亦接受 `Authorization: Bearer <token>`。

- `GET /health`
- `GET /jobs`
- `POST /jobs`：JSON `{ "source_path": "/absolute/path/file.m4a", "vocabulary": ["人名"] }`；預設會自動開始。
- `GET /jobs/<id>`
- `POST /jobs/<id>/cancel`
- `POST /jobs/<id>/retry`
- `GET /jobs/<id>/export/timestamp_txt`
- `GET /jobs/<id>/export/txt|srt|vtt|json|csv`

Export endpoint 只會讀取該 job workspace 內已完成嘅檔案，唔接受任意 path。

## Apple Shortcuts

建立一個 Shortcut：

1. `Choose File`（Allow Multiple 關閉）。
2. `Run Shell Script`，Shell 揀 `/bin/zsh`，Pass Input 揀 `as arguments`。
3. Script 填入 project 內嘅 `scripts/cantonese_transcript_shortcut.sh` 路徑（或者將呢個檔案 copy 到你固定嘅 scripts folder）。
4. 接 `Quick Look`／`Save File`，就會收到完成後嘅 timestamp TXT。

呢個 helper 會自動 create job、poll 真實 progress、完成後下載 segment-level timestamp TXT；2 小時錄音等候時間上限係 24 小時。App 關閉、API 關閉或者 token 不符時會清楚報錯，唔會假裝完成。

## Installed App smoke test

Release QA 可以直接驗證已安裝、已開啟嘅 App，而唔需要另起 backend。先喺設定啟用 Local API 並重新開 App，再跑安全／連線檢查：

```zsh
python3 scripts/run_local_api_installed_smoke.py \
  --skip-heavy \
  --report ~/Claude/scratch/cts-local-api-security-smoke.json
```

完整 smoke 會由指定錄音建立一份全新 2–30 秒 M4A、經 API 真實排隊及轉錄，然後下載帶時間碼 TXT。預設明確要求 Qwen3-ASR-1.7B；`--use-app-primary` 先會改用 App 當前設定。

```zsh
python3 scripts/run_local_api_installed_smoke.py \
  --source "/absolute/path/to/audio.m4a" \
  --start-seconds 0 \
  --clip-seconds 8 \
  --work-dir ~/Claude/scratch/cts-local-api-real-smoke \
  --report ~/Claude/scratch/cts-local-api-real-smoke.json
```

如只想重新核對一份已完成嘅真實工作同 timestamp TXT，可改用 `--existing-job-id <job-id>`。Smoke test 有 bounded timeout、會驗證原始檔及新 M4A 前後 SHA-256 不變，亦會確認 status file 係目前使用者擁有嘅 `0600` 普通檔案、endpoint 只係 `127.0.0.1`、錯 token 回 `401`。JSON report 唔會寫入 token 或 transcript 文字；實際 timestamp TXT 會獨立保留喺 `--work-dir`。
