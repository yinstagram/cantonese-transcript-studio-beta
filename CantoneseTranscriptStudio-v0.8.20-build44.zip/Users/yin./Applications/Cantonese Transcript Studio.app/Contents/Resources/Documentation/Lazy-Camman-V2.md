# Lazy Camman V2：本機拍攝 project、講者切換提示與 Companion 路線圖

文件狀態：**Mac-first `0.8.5 (15)`：普通即時字幕係純字幕模式，Lazy Camman 先係獨立講者功能。Lazy Camman 支援 2–15 位講者依次完成約 10 秒有效語音註冊；每位完成後會停留喺 project 畫面，只有使用者撳「註冊下一位講者」先繼續，全部成功先可以開始。已註冊 CAM++ profiles 形成 closed roster；live matching 唔會自創 speaker，兩個相容 1.0 秒 sliding windows 先確認轉人，唔受 Whisper final 完成時間阻塞。三組 real-human disjoint enrol/eval 全部完成 `A,A,B,B,A` 5/5、2 次正確轉人、0 誤報；production Worker 真跑順序註冊、Whisper Large-v3 final、CAM++ A→B→A、snapshot restart、cancel 同私隱清理。實際房間咪高峰／WhatsApp 播放、相似聲線、重疊說話、iPhone／Apple Watch 同公開發行仍係獨立 field／release gate。**

更新：2026-08-26
適用產品：Cantonese Transcript Studio（macOS 14+）

> 目的係令拍攝現場嘅即時字幕可以保守咁提示「已確認講者轉換」，又可以喺同一個拍攝 project 跨時段記住 A／B 等講者；唔將佢包裝成保安級身份認證，亦唔將任何錄音或聲紋上傳。

## 1. 範圍與狀態：邊啲已經有，邊啲係 V2 要完成

| 層級 | 狀態 | 用戶會得到咩 |
|---|---|---|
| 現有 `0.7.0` baseline | **HISTORICAL — implementation baseline，唔代表 current TCC 真機驗收** | 設計上提供本機咪高峰字幕；本次 app session 內匿名 `A → B → A` 講者延續；模型缺失時降級成冇 speaker label 嘅正常字幕。Stop 後原型清除。 |
| Lazy Camman V2（Mac-first） | **LOCAL ACCEPTED — source、真模型、加密 store、installed Worker smoke 同 App UI read-back** | 獨立側欄入口；2–15 人逐位註冊；每位完成後手動確認下一位；未完成不能開始；project-scoped label／顏色／加密聲紋；closed-roster A→B→A 提示；重開 project 延續。未宣稱保安級 identity、所有 overlap 都可識別、跨 Developer ID update continuity、或公開版可下載。 |
| Lazy Camman V2.1（iPhone companion） | **FUTURE — 不屬今次 Mac V2 release** | 只把最少 speaker-switch event 經同一 Wi‑Fi 本機通道交畀前景 iPhone companion。 |
| Lazy Camman V2.2（Apple Watch） | **FUTURE — 不屬今次 Mac V2 release** | 由 iPhone companion 再轉送畀配對 Apple Watch；唔承諾背景下即時送達。 |

**FACT（100%）**：`0.8.5 (15)` 將普通即時字幕改成 captions-only contract，UI、Swift request 同 backend allocation 三層都唔會啟動講者分析；named project 仍只接受完整、連續 slots `0..<expectedSpeakerCount`，註冊期間可安全恢復 partial prefix，正式 live start 則 fail closed。ad-hoc build 如見到既有 `.ctsprofile` 會在替換 App 前停止，避免新簽名靜默失去舊 Keychain ACL。Project 只係比較本機聲音參考，唔係真人身份認證。

**INFERENCE（98%）**：先把 Mac V2 做成可量度、可撤銷嘅本機功能，再做 companion，比一開始跨三個 Apple platform 更容易驗證私隱、延遲同誤報。

### 1.1 Current live ASR runtime

```text
AVAudioEngine → 16kHz mono PCM16 → local VAD
  ├─ whisper.cpp Small (`zh`)       → provisional partial only
  └─ whisper.cpp Large-v3 (`yue`)   → final caption only
```

兩個 `whisper-server` child 都只綁 `127.0.0.1`、各自使用 random request path、同一 session 內保持 model loaded，並且唔加 `-ng`，所以 Apple Silicon 可用 Metal。WenetSpeech-Yue 繼續係檔案轉錄嘅 verifier，**唔再係 live ASR**。音訊只會變成每次 bounded request 的暫存 WAV，request 完成後即刪；唔會傳去外部 API。呢個係 source／loopback engine contract，唔係宣稱 Small／Large-v3 pair 已經有真實咪高峰延遲或準確度 benchmark。

## 2. V2 的用戶流程（Mac）

### 2.1 開始前

主側欄分開兩個入口：

| 選擇 | 預設／資料保留 | UI 行為 |
|---|---|---|
| **即時字幕** | 不載入／不儲存聲紋 | 只做即時字幕；唔分析講者、唔顯示 Speaker、唔發轉人提示。 |
| **Lazy Camman** | 用戶建立或選擇 project；只儲存此 project 的加密 profile | 先揀 2–15 人、名稱同顏色，再由 Speaker 1 逐位註冊；每個 slot 顯示有效說話秒數／質素，完成後停低等使用者撳下一位，全部成功先解鎖「開始 Lazy Camman」。 |

「預計講者人數」係**軟上限**：超出預計人數、低信心、聲音太短，或者 backend 已收到 overlap flag 時，結果必須係 `Unknown`／不提示，唔可以為咗填滿 A/B 而硬塞入已知講者。

**重要限制（FACT／UNKNOWN）**：目前 backend 只會在上游結果明確提供 `speaker_overlap`／`overlap_detected` 時拒絕提示；未有已 benchmark 的 dedicated overlap detector。因此唔可以講「所有同時講嘢都一定不會 flash」——未被 flag 的重疊仍係 **UNKNOWN**，要由真正兩人／多人錄音 benchmark 加一個獨立 overlap gate 先可以收窄。

**INFERENCE（99%）**：project-scoped profile 加明確 opt-in，比全 app 共享 voiceprint 更符合拍攝用途，亦可減少另一個 client／另一條片誤認成同一人的風險。

### 2.2 進行中：切換提示

一個「切換」只可以由 backend 的 enrolled-speaker confidence gate 產生；UI 唔可以由 partial text 自行猜。`0.8.3` 以獨立 sliding speaker detector 收 PCM，連續兩個相容 window 先發 `confirmed_enrolled_window`，所以提示可以早過 ASR final；final caption 仍由 Whisper Large-v3 產生。

| 條件 | V2 要求 |
|---|---|
| 初次確認講者 | 記錄顏色／label，但**不**提示切換。 |
| 已確認 A，之後已確認 B | 第一個合格 sliding window 只出 amber review；第二個相容 window 先送 `speaker_switched`。Preview 邊框以 B 嘅顏色低強度 pulse 兩下。 |
| 同一人、Unknown、**已明確標記的**重疊、低信心、短 utterance、cancel | **不**提示。未被上游標記的重疊不屬已證明安全範圍。 |
| 重複訊號 | backend 加全局 debounce；快速 A→B→A 亦不可連環 flash。 |
| Reduce Motion | 改為靜態色條／label，唔做動態 pulse。 |
| 聲音提示 | 可選、預設關閉；唔可以取代畫面提示。 |

這個提示係「**已確認的 speaker-group transition**」，唔係「某個真實身份一定開口」。相近聲線、嘈音、離咪、多人重疊、少於最低有效時長嘅說話，都可以令系統保持 Unknown 或漏報；呢個係保守設計，不係 bug workaround。

## 3. Profile 資料、加密與生命週期

### 3.1 架構決定

| 層 | V2 requirement |
|---|---|
| Swift macOS app | 唯一負責 Keychain key、CryptoKit 加密／解密、project 檔案、名稱／色彩／預計人數 UI。 |
| Python live backend | 只在正在跑嘅 live session RAM 內收到**已解密、嚴格 schema 驗證過**的 bounded speaker snapshot 做 matching；唔持有 master key，唔讀 Keychain，唔寫 profile 檔。 |
| 保存位置 | `~/Library/Application Support/Cantonese Transcript Studio/Live Speaker Projects/<project-uuid>.ctsprofile`；directory owner-only，檔案 owner-only。 |
| Key | release 設計係每部 Mac／每次安裝一條 256-bit key，放入 macOS Keychain；現時 ad-hoc beta 以每個已簽名 build namespace 隔離，並阻止有 project 時重建覆蓋。兩者都不放 `.env`、command line、backend log、JSONL RPC 或 repo。 |
| 加密 | CryptoKit AES-GCM；AAD 綁定 bundle identifier、schema version 與 project UUID，避免一個 project 的 ciphertext 被換入另一個 project。 |

**FACT（100%）**：Apple 提供 Keychain Services 儲存敏感資料，亦提供 CryptoKit AES-GCM；兩者可以令 key 同 ciphertext 分開處理。見 [Keychain Services](https://developer.apple.com/documentation/security/keychain-services) 與 [AES.GCM](https://developer.apple.com/documentation/cryptokit/aes/gcm?changes=_5)。

**INFERENCE（99%）**：由 Swift 管 key、Python 只處理短暫 snapshot，會比將 key 放 Python／環境變數／worker argument 更少可意外披露的邊界。

### 3.2 可保存與不可保存的資料

加密 blob 可以包括：

- project UUID、schema、建立／更新時間；
- 用戶自訂 project 名稱、speaker label、顏色、預計人數；
- model identity（key + model digest）、sample rate、snapshot policy；
- 目前每個 speaker slot 一個 bounded、只可由明確重新註冊取代嘅 float prototype、observation count 和 dimension；正常 live matching 不會改寫 anchor。

**禁止保存／傳送：** raw enrollment audio、live mic PCM、完整 transcript、speaker name 對照以外的聯絡資料、API key、網絡識別碼。

**FACT（100%）**：V2 無 global voiceprint database，亦無跨 project 搜尋／matching API。保存只係同一個被用戶選取的 project 內、加密後的 speaker continuity snapshot；普通即時字幕根本不會載入、產生或保存 speaker snapshot。

**INFERENCE（高置信度）**：研究建議日後可比較 bounded multi-prototype 與現有單一 immutable prototype，但唔可以將研究建議寫成已交付功能。任何自動更新門檻都要先經粵語、code-switch、不同咪距／噪音實測；`0.8.3` 明確不做 live adaptation，避免一次誤配污染之後所有 session。

Python input/output contract 應為：

```text
Swift decrypts saved project
    → live.start({ mode: "project", project_id, expected_speaker_count,
                   tracker_snapshot })
    → Python keeps snapshot only in RAM while that session runs; after a
      clean stop it may exist only until that same normal stop RPC returns
    → live.stop() returns profile_update only once for a normal project stop
    → Swift validates + encrypts replacement snapshot
```

`live.cancel`、worker error、crash recovery poll、普通 captions-only session，都**不得**回傳或保存 `profile_update`。model digest、sample rate、dimension、slot count、finite float values、payload size 和 project UUID 都要嚴格驗證；任何不相容資料必須 fail closed，不可靜靜混用舊／新模型 profile。

**FACT（100%）**：clean-stop payload 係 one-shot。就算 decode thread 恰好喺 owner 進入 `live.stop` 前已經到 `STOPPED`，第一次正常 stop 仍可交回 profile update；之後的 duplicate stop、status、poll 或 cancel 都唔可以再攞到佢，並會清除 Python 內殘留 reference。

### 3.3 刪除、損壞與復原

| 情況 | 用戶可見行為／requirement |
|---|---|
| 刪除單一 project | 刪除該 project ciphertext；其餘 project 不受影響。UI 要清楚講「之後不能用此 project 記住講者」。 |
| 清除全部 saved speaker projects | 刪除所有 project blobs；可在確認後輪換 install key，令殘留舊 blob 不能再讀。 |
| Keychain key 不見／AES-GCM 驗證失敗／AAD mismatch | 顯示可理解錯誤、保留證據、提供「刪除此損壞 project」選項；**絕不可**默默覆寫、降級解密或誤當成空 project。 |
| model identity 不同 | 不載入到 live tracker；要求重新建立／重新 enrol 同一個 project profile。 |
| macOS backup／同步 | release privacy 說明必須寫明加密 profile 檔可能受使用者自己的 backup 政策影響；唔承諾 secure erase 或 backup 內可讀／不可讀的結果。 |

**THREAT MODEL（requirement）**：這層主要防止有人單獨複製 Application Support 檔案就讀到 speaker vector。佢唔防已登入同一 macOS account 並可使用該 Keychain 的惡意程式、已被入侵的 OS、session 進行中 RAM／咪高峰捕獲，亦唔等於生物辨識／保安身份驗證。

## 4. iPhone／Apple Watch：正確但延後的架構

### 4.1 不採用的錯誤路徑

**FACT（100%）**：`WCSession` 係 iOS 與其 Watch app 用嘅 WatchConnectivity session API，唔係 macOS-to-Watch transport。[WCSession](https://developer.apple.com/documentation/watchconnectivity/wcsession)（`curl -sIL`：200，2026-08-08）

**FACT（100%）**：Apple 的 watchOS networking 技術說明限制一般 watchOS app 直接使用低層 network APIs；因此唔應假設 Mac 可以直接以 `NWConnection`／Bonjour 同 Watch 做可靠連線。[TN3135](https://developer.apple.com/documentation/technotes/tn3135-low-level-networking-on-watchos)（`curl -sIL`：200，2026-08-08）

**INFERENCE（99%）**：V2.2 唔會設計成 Mac → Watch 直連。

### 4.2 建議路徑（V2.1／V2.2 future scope）

```text
Mac Lazy Camman
  └─ local TLS + Bonjour, same local network, event-only
       └─ foreground iPhone “Shoot Monitor” companion
            └─ WatchConnectivity WCSession
                 └─ paired Apple Watch
```

| Link | 要求／限制 |
|---|---|
| Mac → iPhone | 僅本機 network；採用 TLS、明確 pairing／trust、短命 opaque token。iPhone 需顯示 Local Network privacy reason 並正確宣告 Bonjour service。 |
| iPhone → Watch | 只送最小 event；即時 message 僅在 session reachable 時嘗試，否則只可作 best-effort background transfer／iPhone local notification fallback。 |
| Event payload | `event_id`、版本、短命 project token、speaker slot、色彩、timestamp、confidence band、expiry；不含 raw audio、transcript、voiceprint、speaker full name。 |
| 背景行為 | **唔保證**即時、必達或順序；Watch app／phone app 不在可互動狀態時只可 best effort，UI 必須以「可能錯過」而非「必定通知」表述。 |

**FACT（100%）**：`WCSession.isReachable` 用來判斷可否即時溝通；因此 reachability 本身已經表明即時 delivery 有條件。[isReachable](https://developer.apple.com/documentation/watchconnectivity/wcsession/isreachable)（`curl -sIL`：200，2026-08-08）

**FACT（100%）**：Apple 文件要求 iOS app 對 Local Network privacy／Bonjour discovery 作相應配置。[TN3179](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)（`curl -sIL`：200，2026-08-08）、[Bonjour](https://developer.apple.com/documentation/foundation/bonjour/)（`curl -sIL`：200，2026-08-08）。

**INFERENCE（98%）**：因為拍攝現場最有價值嘅係短暫「切換」而唔係遠端查看逐字稿，event-only local companion 係最細、最易審核嘅資料面。

### 4.3 Companion non-goals

- V2 Mac release **不**建立 iPhone／watchOS target，唔會宣稱已支援電話／手錶通知。
- 不用 APNs、cloud queue、analytics 或第三方 push service 去繞過本機限制。
- 不把加密 project blob、Keychain key 或 enrollment audio 同步到 iPhone／Watch。
- 不作人在不在場、身份真實性、出勤或保安判定。

## 5. Mac V2 驗收清單

### 5.0 已有本機證據（2026-08-26）

| Gate | 結果 | 證據 |
|---|---|---|
| Backend regression | **通過** | `811 passed, 1 real-model-gated skipped, 0 failed`；`../dist/evidence/backend-live-captions-asr-only-0.8.5-20260826.log`。包括普通 captions-only 不載入 speaker factory、15-slot partial enrolment prefix restore、complete-roster live gate、quality、immutability、sliding confirmation 同 terminal cleanup。 |
| Swift source／UI／store | **通過** | Swift Testing `139 passed, 0 failed`；普通字幕忽略任何 speaker event，獨立 Lazy Camman sidebar、2–15 人 setup、15 組固定顏色／圖示、手動下一位、start gate、review／pulse／VoiceOver、encrypted store 全部在真正 target 執行。`../dist/evidence/swift-live-captions-asr-only-0.8.5-20260826.log`。 |
| Real-human matcher | **通過／bounded** | 真人廣東話、official Chinese register/test、independent two-human RTTM 三組都以 disjoint enrol/eval 跑 `A,A,B,B,A`，每組 5/5、2 true switches、0 false switches、0 eligible Unknown，anchors 不變。`../dist/evidence/lazy-camman-real-human-acceptance-0.8.3-20260826.json`。 |
| Production Worker e2e | **通過／非 physical mic** | 真實兩位講者逐位註冊 → Whisper Large-v3 + CAM++ → exact A→B→A → clean stop → snapshot restart → cancel；21.103 秒，0 false switch，offline，無 retained audio／transcript／embedding。`../dist/evidence/live-project-real-smoke-source-0.8.3-20260826.json` 及 installed report。 |
| Installed App health／畫面 | **通過／只限本機** | `0.8.5 (15)` 已驗證 source／bundle parity、strict signature；普通 live captions 真 Whisper final 同時有 0 speaker event／0 speaker model；Lazy Camman 真 Whisper Large-v3 + CAM++ exact A→B→A、現有 4 人加密 project 可重開。Evidence：`../dist/evidence/installation-live-captions-asr-only-0.8.5-20260826.log`、`../dist/evidence/installed-live-captions-only-0.8.5-20260826.json`、`../dist/evidence/installed-lazy-camman-real-e2e-0.8.5-20260826.json`。呢個仍唔代表 Developer ID／notarization 已完成。 |

**仍屬獨立 field／release gate：** ①實際房間咪高峰、WhatsApp speaker playback、相似聲線、遠近咪與重疊講話矩陣；②Developer ID update／Keychain continuity；③任何 iPhone／Watch transport；④notarized public distribution。呢啲唔影響本機已註冊 speaker e2e 完成，但唔可以用 supplied-audio smoke 冒充現場 population accuracy。

### 5.1 microphone prompt：歷史 blocker 與現況

**FACT（local diagnostic，2026-08-08）**：主 App 具 microphone usage description 和 audio-input entitlement；當時以 main app 及全新 diagnostic bundle 在前景呼叫 microphone authorization 時，均未見系統 prompt 或 completion，授權狀態仍然係 `.notDetermined`。TCC log 顯示 prompt 進入 requesting 後被 delayed。這係當時 macOS 登入 session 狀態，不可由 worker／ASR smoke 推論成「咪高峰已可用」。

**HISTORICAL（2026-08-09，pre-Whisper live switch）**：使用者其後喺 macOS prompt 允許 microphone；同一已安裝 Wenet App 實際進入 capture、顯示 final caption 並正常 stop，故當時不需要 restart。呢個只證明 TCC／capture device-flow，唔證明新 Whisper pair；若日後另一部機再次卡住，才採用以下安全操作建議。

**INFERENCE（安全操作建議）**：先保存其他工作，再 restart 或 sign out/in，之後只在前景重新開已安裝 App 再試一次 microphone permission。可在重試前做 bundle-scoped `tccutil reset Microphone com.local.cantonesetranscriptstudio`，但佢只會重置已有決定，**唔會**保證或強迫彈 prompt。

**DO NOT**：不要直接改 TCC database、kill `tccd`、全域關閉 Gatekeeper／SIP，亦不要靠不斷換 bundle identifier 假裝修好。若重登後仍然延後，狀態維持 blocked，應改用另一個 macOS user／乾淨測試環境或 Apple 支援途徑，而唔係把未授權的 microphone feature 寫成驗收通過。

### 5.2 功能 acceptance

- [x] Private Session 同 cancel 於 worker contract 及真模型 smoke 均不回／不寫 `profile_update`；session prototype 保持 RAM-only。
- [x] 加密 project store 可重載合法 snapshot；正常 stop 後由同一真 worker 用 snapshot 重開。Swift 狀態重開／恢復由 Store harness 驗證。
- [x] **HISTORICAL Wenet build**：實際咪高峰 Private Session 已顯示 final caption；named project 已完成建立、owner-only encrypted blob、normal stop、App restart、選回 project 及第二次 start／cancel。呢個只驗證舊 device flow，唔代表新 Whisper pair 或真人說話者 accuracy。
- [x] clean-stop snapshot 只可 hand-off 一次；terminal decode／RPC race、duplicate stop、poll、status、cancel 與 error 都有 regression protection，Python terminal reference 會清除。
- [x] A → B → A、Unknown-first、short／partial、同一人與 directional debounce 的 deterministic alert conditions 有 backend tests；只有**上游已標記** overlap 會被拒絕，未有 dedicated overlap detector；**真實兩人場景數據仍待補**。
- [x] 預計人數作 new-speaker soft cap；不可信第三人不會被強塞入 A／B。
- [x] Reduce Motion 有靜態色條 code path；聲音預設 off，使用者可選。Whisper pair physical-mic speaker-switch alert timing 仍待兩位真人場景驗收。
- [x] 只有 normal project stop 會保存 snapshot；Private、cancel、error／failed-stop 有 regression protection。
- [x] Delete、key loss、ciphertext tamper、AAD mismatch、model mismatch、over-size／corrupt sibling 均 fail closed；壞 project 不會遮住其他可讀 project。
- [x] project library loading／讀取失敗不會被誤作空白 library；首次 project 可先設定每位講者 label／顏色；confirmed switch 先會發出 VoiceOver announcement。

### 5.3 自動測試 matrix

| 範圍 | 最少測試 |
|---|---|
| Swift crypto codec | AES-GCM round trip、tamper、錯 AAD、錯 project UUID、key missing、random nonce、payload cap。 |
| Swift project store | directory/file mode、atomic write、list/read/delete、delete-all、損壞 blob、舊 schema、不可解密 blob。 |
| Python snapshot boundary | schema、base64、float finite、dimension、slot／prototype上限、size cap、sample rate、model digest mismatch；Private／project start-stop-cancel RPC contract。 |
| Speaker logic | A→B→A、Unknown-first、expected-count soft cap、confidence／margin gate、**flagged-overlap**／short utterance、debounce、no partial-driven alert。另加 dedicated overlap gate 前，不可把此 matrix 解讀成「所有 overlap 已涵蓋」。 |
| UI/accessibility | two-pulse colour mapping、Reduce Motion、confirmed-switch VoiceOver announcement、無顏色也可理解、optional sound default off、project load-failure recovery、首次 project label／顏色 mapping。 |
| On-device smoke | 真實本機 mic 兩人、相似聲線、距離咪／噪音／重疊情境；報告 false switch、missed switch、Unknown，並記錄 explicit overlap gate 的 false-negative／false-positive，**不得**將單一 demo 稱作 identity accuracy。 |

### 5.4 Release gate：簽名與 Keychain continuity

在任何網站／朋友下載版本前，必須在乾淨 Mac 完成：

1. 用同一個 production bundle identifier／Developer ID Team 由舊版升級新版本；
2. 建立一個 project profile，upgrade 後可解密；
3. ad-hoc build、不同 Team、re-signed copy 的失敗行為清楚而安全；
4. 任何 key access error 不會令 app 靜默重置全部 profile；
5. release notes／privacy notice 寫清楚本機保存、刪除與失去 Keychain key 後不可復原。

**FACT（100%）**：macOS Keychain 行為、access group／code-signing 與升級測試屬 Apple 平台安全範圍，應按官方 Mac keychain 指引驗證，而非由 ad-hoc 開發版推論 production 結果。[TN3137](https://developer.apple.com/documentation/technotes/tn3137-on-mac-keychains)（`curl -sIL`：200，2026-08-08）

**INFERENCE（99%）**：呢個 upgrade smoke 係 public distribution 前必要 gate；未通過前，應寫「未驗證持久 profile continuity」，而唔係宣稱一經儲存便永久可用。

## 6. 研究來源與 URL 核對

完整 design review、primary-source links、已驗證／推論／未知的分界，見本次研究存檔：[2026-08-08 Lazy Camman V2 ChatGPT Deep Research](research/2026-08-08-lazy-camman-v2-chatgpt-deep-research.md)。本文件只採用同現有程式／測試證據一致的結論；研究建議不會自動變成已 shipped 功能。

以下全部係 Apple 官方一手來源；每條連結已於 **2026-08-08** 用 `curl -sIL` 核對 HTTP `200`：

| Source | 用途 | curl status |
|---|---|---:|
| [WCSession](https://developer.apple.com/documentation/watchconnectivity/wcsession) | iOS／watchOS WatchConnectivity session boundary | 200 |
| [WCSession.isSupported](https://developer.apple.com/documentation/watchconnectivity/wcsession/issupported%28%29) | platform support check | 200 |
| [WCSession.isReachable](https://developer.apple.com/documentation/watchconnectivity/wcsession/isreachable) | immediate-message reachability gate | 200 |
| [TN3135 — Low-level networking on watchOS](https://developer.apple.com/documentation/technotes/tn3135-low-level-networking-on-watchos) | 不以 direct Mac→Watch NWConnection／Bonjour 作設計基礎 | 200 |
| [Networking and communication overview](https://developer.apple.com/documentation/technologyoverviews/networking-and-communication) | Apple network API selection context | 200 |
| [TN3151 — Choosing the right networking API](https://developer.apple.com/documentation/technotes/tn3151-choosing-the-right-networking-api) | Mac／iPhone local transport choice context | 200 |
| [NWParameters.tls](https://developer.apple.com/documentation/network/nwparameters/tls) | local transport TLS requirement basis | 200 |
| [TN3179 — Local Network privacy](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy) | iPhone Local Network disclosure/configuration | 200 |
| [Bonjour](https://developer.apple.com/documentation/foundation/bonjour/) | Bonjour service declaration context | 200 |
| [Keychain Services](https://developer.apple.com/documentation/security/keychain-services) | install key storage | 200 |
| [CryptoKit AES.GCM](https://developer.apple.com/documentation/cryptokit/aes/gcm?changes=_5) | authenticated encryption | 200 |
| [Storing CryptoKit keys in Keychain](https://developer.apple.com/documentation/cryptokit/storing-cryptokit-keys-in-the-keychain?changes=_3) | key handling reference | 200 |
| [TN3137 — On macOS Keychains](https://developer.apple.com/documentation/technotes/tn3137-on-mac-keychains) | release signing／keychain continuity verification | 200 |

## 7. 決策結論

**建議鎖定次序：** Mac V2 的 project-scoped encrypted profiles、保守 switch alert、刪除／損壞處理已有 current beta evidence；實際咪高峰與 app-restart project flow 只得 **historical Wenet** beta evidence。下一個實質 gate 先係新 Whisper Small／Large-v3 pair 的 physical-mic smoke，之後先做兩位真人 field benchmark；通過後先啟動 V2.1 iPhone companion，最後才做 V2.2 Watch relay。

**不要做：** global voiceprint database、背景／雲端「保證即時」通知、用 partial transcript 猜 speaker、或在 Python 保管 Keychain master key。

**完成定義：** 呢個 Mac V2 beta 已完成可 build、可測、加密 project persistence 同保守 switch-alert implementation；但新 Whisper pair 尚未有獨立 physical-mic／app-restart acceptance。任何合成兩把聲嘅 controlled smoke，只可以覆核 no-playback event path，**唔可以**代替真人／真咪高峰的 speaker-recognition benchmark。要到達「已量度、可公開宣稱準確」的現場產品層級，仍要完成新 pair physical-mic smoke、真實兩人／多人 benchmark（包括 dedicated overlap gate）、完整 Xcode test runner 與 5.4 release gate。任何「講者辨認準確率」或「可俾朋友下載」聲明都要等呢啲 gate。iPhone／Apple Watch 必須另有獨立 acceptance，不能借 Mac beta 的成功當已完成。
