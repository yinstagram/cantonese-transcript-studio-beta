"""Microphone-independent state machine for local live captions."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from enum import StrEnum
from typing import Callable

from .engine import LocalRecognitionEngine
from .speaker import LiveSpeakerAssignment, LiveSpeakerTracker
from .types import LiveCaptionEvent, LiveCaptionEventType
from .vad import EnergyVAD, EnergyVADConfig, pcm16_rms


_CURRENT_UTTERANCE = object()


class LiveCaptionState(StrEnum):
    CREATED = "created"
    RUNNING = "running"
    STOPPED = "stopped"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class LiveCaptionConfig:
    sample_rate: int = 16_000
    maximum_frame_ms: int = 200
    partial_interval_ms: int = 500
    minimum_partial_audio_ms: int = 350
    maximum_utterance_seconds: float = 15.0
    pre_roll_ms: int = 200
    speaker_switch_debounce_seconds: float = 1.0
    # A lower-confidence label change must recur on this many completed turns
    # before it can flash the presenter cue.  This is a product-safety policy,
    # not a claim about a universal acoustic threshold.
    speaker_switch_confirmation_turns: int = 2
    # A completed enrolled roster can identify a hand-off before Whisper has
    # finalized its sentence.  One-second windows, advanced every 0.5 seconds,
    # remain bounded and require two consecutive compatible observations.
    enrolled_speaker_window_ms: int = 1_000
    enrolled_speaker_hop_ms: int = 500
    enrolled_speaker_minimum_voiced_ratio: float = 0.40
    enrolled_speaker_confirmation_windows: int = 2
    vad: EnergyVADConfig = EnergyVADConfig()

    def __post_init__(self) -> None:
        if self.sample_rate != 16_000 or self.vad.sample_rate != self.sample_rate:
            raise ValueError("live caption 只接受 16kHz mono PCM16")
        if not 20 <= self.maximum_frame_ms <= 1_000:
            raise ValueError("maximum_frame_ms 必須係 20 至 1000")
        if not 100 <= self.partial_interval_ms <= 5_000:
            raise ValueError("partial_interval_ms 必須係 100 至 5000")
        if not 100 <= self.minimum_partial_audio_ms <= 5_000:
            raise ValueError("minimum_partial_audio_ms 必須係 100 至 5000")
        if not 2.0 <= self.maximum_utterance_seconds <= 20.0:
            raise ValueError("maximum_utterance_seconds 必須係 2 至 20")
        if not 0 <= self.pre_roll_ms <= 1_000:
            raise ValueError("pre_roll_ms 必須係 0 至 1000")
        if not 0.0 <= self.speaker_switch_debounce_seconds <= 5.0:
            raise ValueError("speaker_switch_debounce_seconds 必須係 0 至 5")
        if not 2 <= self.speaker_switch_confirmation_turns <= 5:
            raise ValueError("speaker_switch_confirmation_turns 必須係 2 至 5")
        if not 650 <= self.enrolled_speaker_window_ms <= 3_000:
            raise ValueError("enrolled speaker window 必須係 650 至 3000ms")
        if not 200 <= self.enrolled_speaker_hop_ms <= self.enrolled_speaker_window_ms:
            raise ValueError("enrolled speaker hop 無效")
        if not 0.4 <= self.enrolled_speaker_minimum_voiced_ratio <= 1.0:
            raise ValueError("enrolled speaker voiced ratio 無效")
        if not 2 <= self.enrolled_speaker_confirmation_windows <= 4:
            raise ValueError("enrolled speaker confirmation windows 必須係 2 至 4")


class LiveCaptionProcessor:
    """Consume contiguous PCM frames and produce timestamped caption events.

    ``push_pcm16`` is synchronous and deliberately independent of AVFoundation,
    PortAudio, and microphone permissions.  ``LiveCaptionWorker`` supplies the
    bounded background queue used by the app integration layer.
    """

    def __init__(
        self,
        engine: LocalRecognitionEngine,
        *,
        final_engine: LocalRecognitionEngine | None = None,
        config: LiveCaptionConfig | None = None,
        normalizer: Callable[[str], str] | None = None,
        speaker_tracker: LiveSpeakerTracker | None = None,
        clock: Callable[[], float] = time.perf_counter,
    ) -> None:
        if not getattr(engine, "is_local", False):
            raise ValueError("live caption 禁止使用非本地 ASR engine")
        self.config = config or LiveCaptionConfig()
        resolved_final_engine = final_engine or engine
        if not getattr(resolved_final_engine, "is_local", False):
            raise ValueError("live caption final 禁止使用非本地 ASR engine")
        for candidate in (engine, resolved_final_engine):
            if int(getattr(candidate, "sample_rate", 0)) != self.config.sample_rate:
                raise ValueError("ASR engine sample rate 同 live caption 唔一致")
        self.engine = engine
        self.final_engine = resolved_final_engine
        if (
            speaker_tracker is not None
            and speaker_tracker.sample_rate != self.config.sample_rate
        ):
            raise ValueError("speaker tracker sample rate 同 live caption 唔一致")
        self.speaker_tracker = speaker_tracker
        # The core stays import-light and does not pull OpenCC/RapidFuzz into a
        # microphone callback process. The app injects its already-loaded Hong
        # Kong normalizer; identity remains useful for isolated PCM QA.
        self._normalizer = normalizer or (lambda text: text)
        self._clock = clock
        self._vad = EnergyVAD(self.config.vad)
        self._state = LiveCaptionState.CREATED
        self._sequence = 0
        self._utterance_id = 0
        self._expected_sample = 0
        self._speech_start_sample: int | None = None
        self._buffer_start_sample: int | None = None
        self._utterance = bytearray()
        self._pre_roll = bytearray()
        self._last_partial_text = ""
        self._last_partial_sample = 0
        # Speaker changes are a backend decision made only from a completed,
        # final utterance. The UI must never infer one from rolling partials.
        self._last_confirmed_speaker_id: str | None = None
        # The baseline only moves after strict evidence or repeated compatible
        # finals.  A one-off plausible turn therefore cannot cause an alert.
        self._pending_switch: tuple[str, str, int] | None = None
        # Debounce the *visible* cue globally, including fast A→B→A
        # oscillation, while retaining the latest reliable internal baseline.
        self._last_switch_at: float | None = None
        self._enrolled_speaker_monitor_enabled = bool(
            speaker_tracker is not None
            and getattr(speaker_tracker, "enrolled_roster_complete", False)
        )
        self._speaker_monitor_buffer = bytearray()
        self._speaker_monitor_buffer_start_sample = 0
        self._speaker_monitor_next_end_sample = round(
            self.config.sample_rate * self.config.enrolled_speaker_window_ms / 1_000
        )
        self._speaker_monitor_pending: tuple[str, int] | None = None
        self._speaker_monitor_last_observation: LiveSpeakerAssignment | None = None
        self.partial_inferences = 0
        self.final_inferences = 0
        self.maximum_inference_latency_ms = 0.0

    @property
    def state(self) -> LiveCaptionState:
        return self._state

    @property
    def processed_samples(self) -> int:
        return self._expected_sample

    @property
    def processed_seconds(self) -> float:
        return self._expected_sample / self.config.sample_rate

    @property
    def maximum_frame_bytes(self) -> int:
        return round(
            self.config.sample_rate * self.config.maximum_frame_ms / 1000
        ) * 2

    def _event(
        self,
        event_type: LiveCaptionEventType,
        *,
        start_sample: int,
        end_sample: int,
        text: str = "",
        is_final: bool = False,
        latency_ms: float | None = None,
        reason: str = "",
        metadata: dict[str, object] | None = None,
        utterance_id: int | None | object = _CURRENT_UTTERANCE,
        engine_name: str | None = None,
    ) -> LiveCaptionEvent:
        self._sequence += 1
        return LiveCaptionEvent(
            type=event_type,
            sequence=self._sequence,
            start=max(0, start_sample) / self.config.sample_rate,
            end=max(start_sample, end_sample) / self.config.sample_rate,
            utterance_id=(
                self._utterance_id
                if utterance_id is _CURRENT_UTTERANCE
                else utterance_id  # type: ignore[arg-type]
            ),
            text=text,
            is_final=is_final,
            engine=engine_name or str(getattr(self.engine, "name", "local")),
            inference_latency_ms=latency_ms,
            reason=reason,
            metadata=dict(metadata or {}),
        )

    def start(self) -> list[LiveCaptionEvent]:
        if self._state is not LiveCaptionState.CREATED:
            raise RuntimeError("live caption session 只可以 start 一次")
        self._state = LiveCaptionState.RUNNING
        return [
            self._event(
                LiveCaptionEventType.SESSION_STARTED,
                start_sample=0,
                end_sample=0,
                utterance_id=None,
                metadata={
                    "sample_rate": self.config.sample_rate,
                    "format": "pcm_s16le_mono",
                    "offline": True,
                    "anonymous_speaker_tracking": self.speaker_tracker is not None,
                    "speaker_identity_mode": (
                        "disabled"
                        if self.speaker_tracker is None
                        else (
                            "enrolled_sliding_window"
                            if self._enrolled_speaker_monitor_enabled
                            else "anonymous_final_turn"
                        )
                    ),
                },
            )
        ]

    @property
    def enrolled_speaker_monitor_enabled(self) -> bool:
        return self._enrolled_speaker_monitor_enabled

    def _append_pre_roll(self, data: bytes) -> None:
        maximum = round(self.config.sample_rate * self.config.pre_roll_ms / 1000) * 2
        if maximum <= 0:
            self._pre_roll.clear()
            return
        self._pre_roll.extend(data)
        if len(self._pre_roll) > maximum:
            del self._pre_roll[: len(self._pre_roll) - maximum]

    def _begin_utterance(self, speech_start_sample: int, frame_end_sample: int) -> LiveCaptionEvent:
        self._utterance_id += 1
        self._speech_start_sample = speech_start_sample
        self._utterance = bytearray(self._pre_roll)
        buffered_samples = len(self._utterance) // 2
        self._buffer_start_sample = max(0, frame_end_sample - buffered_samples)
        self._last_partial_sample = speech_start_sample
        self._last_partial_text = ""
        if self.speaker_tracker is not None:
            self.speaker_tracker.begin_utterance()
        return self._event(
            LiveCaptionEventType.SPEECH_STARTED,
            start_sample=speech_start_sample,
            end_sample=speech_start_sample,
        )

    def _reset_enrolled_speaker_monitor(self, *, start_sample: int) -> None:
        self._speaker_monitor_buffer.clear()
        self._speaker_monitor_buffer_start_sample = start_sample
        window_samples = round(
            self.config.sample_rate * self.config.enrolled_speaker_window_ms / 1_000
        )
        self._speaker_monitor_next_end_sample = start_sample + window_samples
        self._speaker_monitor_pending = None
        self._speaker_monitor_last_observation = None

    def _speaker_window_voiced_ratio(self, pcm: bytes) -> float:
        frame_samples = round(self.config.sample_rate * 20 / 1_000)
        voiced = 0
        total = 0
        for start in range(0, len(pcm) // 2, frame_samples):
            frame = pcm[start * 2 : (start + frame_samples) * 2]
            if not frame:
                continue
            total += 1
            if pcm16_rms(frame) >= self.config.vad.release_threshold:
                voiced += 1
        return voiced / total if total else 0.0

    def _enrolled_speaker_window_events(
        self,
        assignment: LiveSpeakerAssignment,
        *,
        window_start_sample: int,
        window_end_sample: int,
        voiced_ratio: float,
    ) -> list[LiveCaptionEvent]:
        """Confirm a closed-roster hand-off without waiting for ASR text."""

        self._speaker_monitor_last_observation = assignment
        speaker_id = assignment.speaker_id
        if speaker_id is None:
            self._speaker_monitor_pending = None
            return []
        baseline = self._last_confirmed_speaker_id
        if baseline is None:
            pending = self._speaker_monitor_pending
            confirmations = pending[1] + 1 if pending and pending[0] == speaker_id else 1
            self._speaker_monitor_pending = (speaker_id, confirmations)
            if confirmations >= self.config.enrolled_speaker_confirmation_windows:
                self._last_confirmed_speaker_id = speaker_id
                self._speaker_monitor_pending = None
            return []
        if speaker_id == baseline:
            self._speaker_monitor_pending = None
            return []

        pending = self._speaker_monitor_pending
        confirmations = pending[1] + 1 if pending and pending[0] == speaker_id else 1
        self._speaker_monitor_pending = (speaker_id, confirmations)
        common_metadata: dict[str, object] = {
            **assignment.to_metadata(),
            "from_speaker_id": baseline,
            "to_speaker_id": speaker_id,
            "speaker_window_start_seconds": round(
                window_start_sample / self.config.sample_rate,
                6,
            ),
            "speaker_window_end_seconds": round(
                window_end_sample / self.config.sample_rate,
                6,
            ),
            "speaker_window_voiced_ratio": round(voiced_ratio, 6),
            "speaker_switch_confirmations": confirmations,
            "speaker_switch_required_confirmations": (
                self.config.enrolled_speaker_confirmation_windows
            ),
            "speaker_switch_detector": "enrolled_sliding_window_v1",
        }
        if confirmations < self.config.enrolled_speaker_confirmation_windows:
            return [
                self._event(
                    LiveCaptionEventType.SPEAKER_SWITCH_CANDIDATE,
                    start_sample=window_end_sample,
                    end_sample=window_end_sample,
                    reason="pending_confirmation",
                    metadata=common_metadata,
                    engine_name=str(getattr(self.speaker_tracker.engine, "name", "local")),
                )
            ]

        self._last_confirmed_speaker_id = speaker_id
        self._speaker_monitor_pending = None
        last_switch_at = self._last_switch_at
        at_seconds = window_end_sample / self.config.sample_rate
        if (
            last_switch_at is not None
            and at_seconds - last_switch_at < self.config.speaker_switch_debounce_seconds
        ):
            return []
        self._last_switch_at = at_seconds
        return [
            self._event(
                LiveCaptionEventType.SPEAKER_SWITCHED,
                start_sample=window_end_sample,
                end_sample=window_end_sample,
                reason="confirmed_enrolled_window",
                metadata={
                    **common_metadata,
                    "speaker_switch_confirmation": "enrolled_sliding_windows",
                },
                engine_name=str(getattr(self.speaker_tracker.engine, "name", "local")),
            )
        ]

    def _process_enrolled_speaker_windows(
        self,
        frame: bytes,
        *,
        frame_start: int,
        frame_end: int,
    ) -> list[LiveCaptionEvent]:
        tracker = self.speaker_tracker
        if not self._enrolled_speaker_monitor_enabled or tracker is None:
            return []
        expected_buffer_end = (
            self._speaker_monitor_buffer_start_sample
            + len(self._speaker_monitor_buffer) // 2
        )
        if not self._speaker_monitor_buffer:
            self._speaker_monitor_buffer_start_sample = frame_start
            expected_buffer_end = frame_start
        if expected_buffer_end != frame_start:
            self._reset_enrolled_speaker_monitor(start_sample=frame_start)
        self._speaker_monitor_buffer.extend(frame)
        window_samples = round(
            self.config.sample_rate * self.config.enrolled_speaker_window_ms / 1_000
        )
        hop_samples = round(
            self.config.sample_rate * self.config.enrolled_speaker_hop_ms / 1_000
        )
        events: list[LiveCaptionEvent] = []
        while self._speaker_monitor_next_end_sample <= frame_end:
            window_end = self._speaker_monitor_next_end_sample
            window_start = window_end - window_samples
            start_offset = window_start - self._speaker_monitor_buffer_start_sample
            end_offset = window_end - self._speaker_monitor_buffer_start_sample
            if start_offset >= 0 and end_offset * 2 <= len(self._speaker_monitor_buffer):
                window = bytes(
                    self._speaker_monitor_buffer[start_offset * 2 : end_offset * 2]
                )
                voiced_ratio = self._speaker_window_voiced_ratio(window)
                if voiced_ratio >= self.config.enrolled_speaker_minimum_voiced_ratio:
                    try:
                        assignment = tracker.assign_pcm16(
                            window,
                            observed_at_seconds=window_end / self.config.sample_rate,
                        )
                    except Exception:
                        assignment = LiveSpeakerAssignment(
                            speaker_index=None,
                            confidence=None,
                            reason="speaker_tracker_error",
                        )
                    events.extend(
                        self._enrolled_speaker_window_events(
                            assignment,
                            window_start_sample=window_start,
                            window_end_sample=window_end,
                            voiced_ratio=voiced_ratio,
                        )
                    )
            self._speaker_monitor_next_end_sample += hop_samples

        # Retain only the samples needed by the next overlapping window.
        earliest_needed = self._speaker_monitor_next_end_sample - window_samples
        removable = max(0, earliest_needed - self._speaker_monitor_buffer_start_sample)
        if removable:
            del self._speaker_monitor_buffer[: removable * 2]
            self._speaker_monitor_buffer_start_sample += removable
        return events

    def _speaker_metadata(
        self,
        *,
        final: bool,
        end_sample: int,
        result_metadata: dict[str, object],
    ) -> dict[str, object]:
        tracker = self.speaker_tracker
        if tracker is None:
            return {}
        if self._enrolled_speaker_monitor_enabled:
            assignment = self._speaker_monitor_last_observation or LiveSpeakerAssignment(
                speaker_index=None,
                confidence=None,
                reason="awaiting_enrolled_speaker_window",
            )
            metadata = assignment.to_metadata()
            metadata["speaker_tracking"] = "enrolled_sliding_window"
            if final:
                metadata["speaker_evidence_seconds"] = round(
                    self.config.enrolled_speaker_window_ms / 1_000,
                    6,
                )
            return metadata
        evidence_pcm = bytes(self._utterance)
        if final:
            buffer_start = (
                self._speech_start_sample
                if self._buffer_start_sample is None
                else self._buffer_start_sample
            )
            speech_start = self._speech_start_sample or buffer_start
            start_offset = max(0, speech_start - buffer_start)
            end_offset = max(start_offset, end_sample - buffer_start)
            total_samples = len(evidence_pcm) // 2
            start_offset = min(total_samples, start_offset)
            end_offset = min(total_samples, end_offset)
            evidence_pcm = evidence_pcm[start_offset * 2 : end_offset * 2]
        try:
            assignment = (
                tracker.assign_pcm16(
                    evidence_pcm,
                    overlap_detected=bool(
                        result_metadata.get("speaker_overlap")
                        or result_metadata.get("overlap_detected")
                    ),
                    # Use the stream's monotonic audio timeline rather than
                    # wall clock: a corroborating turn must be adjacent in
                    # captured speech, even if model inference took longer.
                    observed_at_seconds=end_sample / self.config.sample_rate,
                )
                if final
                else tracker.partial_assignment()
            )
        except Exception as exc:
            # Speaker continuity is optional metadata.  A failed embedding must
            # never suppress otherwise valid local caption text.
            assignment = LiveSpeakerAssignment(
                speaker_index=None,
                confidence=None,
                reason="speaker_tracker_error",
            )
            return {
                **assignment.to_metadata(),
                "speaker_error": str(exc)[:200],
                **(
                    {
                        "speaker_evidence_seconds": round(
                            len(evidence_pcm) / 2 / self.config.sample_rate,
                            6,
                        )
                    }
                    if final
                    else {}
                ),
            }
        metadata = assignment.to_metadata()
        if final:
            metadata["speaker_evidence_seconds"] = round(
                len(evidence_pcm) / 2 / self.config.sample_rate,
                6,
            )
        return metadata

    def _speaker_switch_event(
        self,
        final: LiveCaptionEvent,
    ) -> LiveCaptionEvent | None:
        """Emit one conservative post-final speaker-turn notification.

        A bounded short or dead-zone voice may first emit a neutral suspected
        cue. It is never a switch by itself: only the immediate corroborating
        full turn may promote it to a speaker and produce the visible cue.
        All other Unknown, overlap, ambiguity, errors, and forced-duration
        continuations clear pending evidence instead of advancing a switch.
        """

        metadata = final.metadata
        speaker_id = metadata.get("speaker_id")
        confidence = metadata.get("speaker_confidence")
        speaker_reason = metadata.get("speaker_reason")
        previous_speaker_id = self._last_confirmed_speaker_id
        candidate_from = metadata.get("speaker_candidate_from_speaker_id")
        candidate_state = metadata.get("speaker_candidate_state")
        suspected_kind = {
            "new_speaker_candidate_pending": ("pending", "short_dissimilar_window"),
            "uncertain_new_speaker_pending": ("suspected", "dead_zone_window"),
        }.get(speaker_reason)
        if suspected_kind is not None:
            expected_state, candidate_kind = suspected_kind
            # The tracker only sets these for one bounded, in-RAM candidate
            # that is unlike the active confirmed voice. It remains Unknown,
            # so the UI may show a neutral review cue but must not assign a
            # label/colour or claim that a handoff has already happened.
            self._pending_switch = None
            if (
                final.reason == "maximum_duration"
                or previous_speaker_id is None
                or candidate_state != expected_state
                or candidate_from != previous_speaker_id
            ):
                return None
            return self._event(
                LiveCaptionEventType.SPEAKER_SWITCH_SUSPECTED,
                start_sample=round(final.end * self.config.sample_rate),
                end_sample=round(final.end * self.config.sample_rate),
                reason="awaiting_corroboration",
                metadata={
                    "from_speaker_id": previous_speaker_id,
                    "speaker_unknown": True,
                    "suspected_reason": str(speaker_reason),
                    "suspected_kind": candidate_kind,
                    "suspected_at_seconds": round(final.end, 6),
                    "speaker_evidence_seconds": metadata.get(
                        "speaker_candidate_evidence_seconds"
                    ),
                    "source_final_sequence": final.sequence,
                },
                utterance_id=final.utterance_id,
                engine_name=final.engine,
            )
        if (
            not isinstance(speaker_id, str)
            or not speaker_id
            or not isinstance(confidence, (int, float))
            or isinstance(confidence, bool)
            or not math.isfinite(float(confidence))
            or speaker_reason
            not in {
                "first_reliable_utterance",
                "new_dissimilar_speaker",
                "matched_stable_prototype",
                "matched_enrolled_profile_short_turn",
                "confirmed_short_candidate_new_speaker",
                "confirmed_uncertain_candidate_new_speaker",
            }
            or final.reason == "maximum_duration"
        ):
            self._pending_switch = None
            return None

        if previous_speaker_id is None:
            self._last_confirmed_speaker_id = speaker_id
            self._pending_switch = None
            return None
        if previous_speaker_id == speaker_id:
            self._pending_switch = None
            return None

        if speaker_reason in {
            "confirmed_short_candidate_new_speaker",
            "confirmed_uncertain_candidate_new_speaker",
        }:
            return self._commit_speaker_switch(
                final,
                previous_speaker_id=previous_speaker_id,
                speaker_id=speaker_id,
                confidence=float(confidence),
                speaker_reason=str(speaker_reason),
                confirmation=(
                    "short_candidate_follow_up"
                    if speaker_reason == "confirmed_short_candidate_new_speaker"
                    else "uncertain_candidate_follow_up"
                ),
            )

        strict_confidence = self._is_strict_switch_evidence(
            speaker_reason=str(speaker_reason),
            confidence=float(confidence),
            metadata=metadata,
        )
        if strict_confidence:
            return self._commit_speaker_switch(
                final,
                previous_speaker_id=previous_speaker_id,
                speaker_id=speaker_id,
                confidence=float(confidence),
                speaker_reason=str(speaker_reason),
                confirmation="strict_tracker_evidence",
            )

        pending = self._pending_switch
        if (
            pending is not None
            and pending[0] == previous_speaker_id
            and pending[1] == speaker_id
        ):
            confirmations = pending[2] + 1
        else:
            confirmations = 1
        self._pending_switch = (
            previous_speaker_id,
            speaker_id,
            confirmations,
        )
        if confirmations < self.config.speaker_switch_confirmation_turns:
            return None
        return self._commit_speaker_switch(
            final,
            previous_speaker_id=previous_speaker_id,
            speaker_id=speaker_id,
            confidence=float(confidence),
            speaker_reason=str(speaker_reason),
            confirmation="repeated_compatible_finals",
        )

    def _is_strict_switch_evidence(
        self,
        *,
        speaker_reason: str,
        confidence: float,
        metadata: dict[str, object],
    ) -> bool:
        """Reuse the tracker's stricter persistence policy for one-turn cues.

        The live tracker already has a deliberately higher threshold for
        deciding whether an utterance may safely alter a persisted project
        profile.  Reusing that existing policy avoids inventing a second,
        unbenchmarked acoustic cutoff solely for a visual alert.
        """

        tracker = self.speaker_tracker
        if tracker is None:
            return False
        config = tracker.config
        if confidence < config.profile_adaptation_similarity:
            return False
        if speaker_reason == "new_dissimilar_speaker":
            return True
        if speaker_reason not in {
            "matched_stable_prototype",
            "matched_enrolled_profile_short_turn",
        }:
            return False
        margin = metadata.get("speaker_similarity_margin")
        if margin is None:
            # With one known prototype the tracker intentionally exposes no
            # fabricated competing-prototype margin.  It cannot produce a
            # different matched speaker in that state, so this is safe here.
            return True
        return (
            isinstance(margin, (int, float))
            and not isinstance(margin, bool)
            and math.isfinite(float(margin))
            and float(margin) >= config.profile_adaptation_margin
        )

    def _commit_speaker_switch(
        self,
        final: LiveCaptionEvent,
        *,
        previous_speaker_id: str,
        speaker_id: str,
        confidence: float,
        speaker_reason: str,
        confirmation: str,
    ) -> LiveCaptionEvent | None:
        """Move the confirmed baseline and emit a rate-limited cue if due."""

        self._last_confirmed_speaker_id = speaker_id
        self._pending_switch = None
        last_switch_at = self._last_switch_at
        if (
            last_switch_at is not None
            and final.end - last_switch_at < self.config.speaker_switch_debounce_seconds
        ):
            return None
        self._last_switch_at = final.end
        return self._event(
            LiveCaptionEventType.SPEAKER_SWITCHED,
            start_sample=round(final.end * self.config.sample_rate),
            end_sample=round(final.end * self.config.sample_rate),
            reason="confirmed_final_turn",
            metadata={
                "from_speaker_id": previous_speaker_id,
                "to_speaker_id": speaker_id,
                "speaker_confidence": round(float(confidence), 6),
                "speaker_reason": speaker_reason,
                "speaker_switch_confirmation": confirmation,
                "source_final_sequence": final.sequence,
            },
            utterance_id=final.utterance_id,
            engine_name=final.engine,
        )

    def _recognize(self, *, final: bool, end_sample: int, reason: str) -> LiveCaptionEvent | None:
        if not self._utterance or self._speech_start_sample is None:
            return None
        started = self._clock()
        selected_engine = self.final_engine if final else self.engine
        result = selected_engine.recognize_pcm16(bytes(self._utterance))
        latency_ms = max(0.0, (self._clock() - started) * 1000)
        self.maximum_inference_latency_ms = max(
            self.maximum_inference_latency_ms, latency_ms
        )
        text = self._normalizer(result.text).strip()
        if final:
            self.final_inferences += 1
            event_type = LiveCaptionEventType.FINAL
        else:
            self.partial_inferences += 1
            event_type = LiveCaptionEventType.PARTIAL
            if not text or text == self._last_partial_text:
                return None
            self._last_partial_text = text
        if not text:
            return None
        speaker_metadata = self._speaker_metadata(
            final=final,
            end_sample=end_sample,
            result_metadata=result.metadata,
        )
        buffer_start = (
            self._speech_start_sample
            if self._buffer_start_sample is None
            else self._buffer_start_sample
        )
        absolute_token_times = tuple(
            round(buffer_start / self.config.sample_rate + value, 6)
            for value in result.timestamps
        )
        return self._event(
            event_type,
            start_sample=self._speech_start_sample,
            end_sample=end_sample,
            text=text,
            is_final=final,
            latency_ms=round(latency_ms, 3),
            reason=reason,
            engine_name=str(getattr(selected_engine, "name", "local")),
            metadata={
                **result.metadata,
                "recognition_role": "final" if final else "provisional",
                "confidence": result.confidence,
                "tokens": result.tokens,
                "token_timestamps": absolute_token_times,
                "buffer_seconds": round(len(self._utterance) / 2 / self.config.sample_rate, 6),
                **speaker_metadata,
            },
        )

    def _finish_utterance(self, *, end_sample: int, reason: str) -> list[LiveCaptionEvent]:
        if self._speech_start_sample is None:
            return []
        speech_start = self._speech_start_sample
        utterance_id = self._utterance_id
        events: list[LiveCaptionEvent] = []
        final = self._recognize(final=True, end_sample=end_sample, reason=reason)
        if final is not None:
            events.append(final)
            if not self._enrolled_speaker_monitor_enabled:
                switch = self._speaker_switch_event(final)
                if switch is not None:
                    events.append(switch)
        events.append(
            self._event(
                LiveCaptionEventType.SPEECH_ENDED,
                start_sample=speech_start,
                end_sample=end_sample,
                reason=reason,
                utterance_id=utterance_id,
            )
        )
        self._speech_start_sample = None
        self._buffer_start_sample = None
        self._utterance.clear()
        self._last_partial_text = ""
        if self.speaker_tracker is not None:
            self.speaker_tracker.end_utterance()
        return events

    def push_pcm16(
        self,
        data: bytes | bytearray | memoryview,
        *,
        start_sample: int | None = None,
    ) -> list[LiveCaptionEvent]:
        if self._state is not LiveCaptionState.RUNNING:
            raise RuntimeError("live caption session 未開始或已停止")
        frame = bytes(data)
        if not frame or len(frame) % 2:
            raise ValueError("frame 必須係非空 little-endian PCM16 bytes")
        if len(frame) > self.maximum_frame_bytes:
            raise ValueError(
                f"frame 超過 {self.config.maximum_frame_ms}ms 資源上限"
            )
        supplied_start = self._expected_sample if start_sample is None else int(start_sample)
        if supplied_start < self._expected_sample:
            raise ValueError("PCM frame timestamp 倒序或重疊")

        events: list[LiveCaptionEvent] = []
        if supplied_start > self._expected_sample:
            gap_start = self._expected_sample
            events.extend(
                self._finish_utterance(end_sample=gap_start, reason="input_gap")
            )
            self._vad.reset()
            self._pre_roll.clear()
            if self._enrolled_speaker_monitor_enabled:
                self._reset_enrolled_speaker_monitor(start_sample=supplied_start)
            events.append(
                self._event(
                    LiveCaptionEventType.OVERRUN,
                    start_sample=gap_start,
                    end_sample=supplied_start,
                    reason="input_gap",
                    metadata={"dropped_samples": supplied_start - gap_start},
                    utterance_id=None,
                )
            )
            self._expected_sample = supplied_start

        frame_start = supplied_start
        frame_samples = len(frame) // 2
        frame_end = frame_start + frame_samples
        was_active = self._speech_start_sample is not None
        self._append_pre_roll(frame)
        decision = self._vad.process(frame, start_sample=frame_start)
        speaker_window_events = self._process_enrolled_speaker_windows(
            frame,
            frame_start=frame_start,
            frame_end=frame_end,
        )
        events.extend(speaker_window_events)

        if was_active:
            self._utterance.extend(frame)
        elif decision.speech_started_at_sample is not None:
            events.append(
                self._begin_utterance(decision.speech_started_at_sample, frame_end)
            )

        self._expected_sample = frame_end
        if decision.speech_ended_at_sample is not None:
            events.extend(
                self._finish_utterance(
                    end_sample=decision.speech_ended_at_sample,
                    reason="vad_endpoint",
                )
            )
            return events

        if self._speech_start_sample is None:
            return events

        # Publish a candidate/confirmed enrolled-speaker hand-off immediately.
        # A rolling Whisper partial on this exact frame can take materially
        # longer than the tiny speaker embedding; deferring that optional
        # partial until the next frame prevents it from holding the visual cue.
        if any(
            event.type
            in {
                LiveCaptionEventType.SPEAKER_SWITCH_CANDIDATE,
                LiveCaptionEventType.SPEAKER_SWITCHED,
            }
            for event in speaker_window_events
        ):
            return events

        maximum_samples = round(
            self.config.maximum_utterance_seconds * self.config.sample_rate
        )
        if frame_end - self._speech_start_sample >= maximum_samples:
            events.extend(
                self._finish_utterance(end_sample=frame_end, reason="maximum_duration")
            )
            # The energy VAD remains in speech, so continue with a fresh bounded
            # segment. The next audio frame starts exactly at this boundary.
            self._utterance_id += 1
            self._speech_start_sample = frame_end
            self._buffer_start_sample = frame_end
            self._last_partial_sample = frame_end
            if self.speaker_tracker is not None:
                self.speaker_tracker.begin_utterance(continue_previous=True)
            events.append(
                self._event(
                    LiveCaptionEventType.SPEECH_STARTED,
                    start_sample=frame_end,
                    end_sample=frame_end,
                    reason="maximum_duration_continuation",
                )
            )
            return events

        partial_interval_samples = round(
            self.config.sample_rate * self.config.partial_interval_ms / 1000
        )
        minimum_partial_samples = round(
            self.config.sample_rate * self.config.minimum_partial_audio_ms / 1000
        )
        if (
            frame_end - self._last_partial_sample >= partial_interval_samples
            and frame_end - self._speech_start_sample >= minimum_partial_samples
        ):
            self._last_partial_sample = frame_end
            partial = self._recognize(
                final=False,
                end_sample=frame_end,
                reason="rolling_partial",
            )
            if partial is not None:
                events.append(partial)
        return events

    def skip_to(self, sample: int, *, reason: str = "input_overrun") -> list[LiveCaptionEvent]:
        """Advance across audio that the bounded producer queue could not retain."""

        if self._state is not LiveCaptionState.RUNNING:
            raise RuntimeError("live caption session 未開始或已停止")
        target = int(sample)
        if target < self._expected_sample:
            raise ValueError("skip target 唔可以早過已處理 audio")
        if target == self._expected_sample:
            return []
        start = self._expected_sample
        events = self._finish_utterance(end_sample=start, reason=reason)
        self._vad.reset()
        self._pre_roll.clear()
        if self._enrolled_speaker_monitor_enabled:
            self._reset_enrolled_speaker_monitor(start_sample=target)
        self._expected_sample = target
        events.append(
            self._event(
                LiveCaptionEventType.OVERRUN,
                start_sample=start,
                end_sample=target,
                reason=reason,
                metadata={"dropped_samples": target - start},
                utterance_id=None,
            )
        )
        return events

    def flush_current_utterance(self) -> list[LiveCaptionEvent]:
        """Finalize the current turn without stopping the live session.

        This is deliberately narrower than :meth:`finish`: an interviewer can
        author a manual answer-end boundary, but microphone capture continues
        for the next manual action.  The caller must invoke it on the caption
        worker's FIFO thread *after* every pre-boundary PCM frame; otherwise a
        direct call could cut an utterance before its already-captured tail.

        Resetting VAD is required here.  ``_finish_utterance`` clears CTS's
        transcript state, but a still-voiced VAD would otherwise suppress the
        next turn's ``speech_started`` event after this manual split.
        """

        if self._state is not LiveCaptionState.RUNNING:
            raise RuntimeError("live caption session 未開始或已停止")
        events = self._finish_utterance(
            end_sample=self._expected_sample,
            reason="manual_answer_end",
        )
        self._vad.reset()
        self._pre_roll.clear()
        if self._enrolled_speaker_monitor_enabled:
            self._reset_enrolled_speaker_monitor(start_sample=self._expected_sample)
        return events

    def fail(self, message: str) -> list[LiveCaptionEvent]:
        if self._state is not LiveCaptionState.RUNNING:
            return []
        self._speech_start_sample = None
        self._utterance.clear()
        self._pre_roll.clear()
        self._state = LiveCaptionState.STOPPED
        return [
            self._event(
                LiveCaptionEventType.ERROR,
                start_sample=self._expected_sample,
                end_sample=self._expected_sample,
                reason="local_engine_error",
                metadata={"message": str(message)[:500]},
                utterance_id=None,
            )
        ]

    def close_engines(self) -> None:
        resources = [self.engine]
        if self.final_engine is not self.engine:
            resources.append(self.final_engine)
        if self.speaker_tracker is not None:
            resources.append(self.speaker_tracker)
        errors: list[Exception] = []
        for resource in resources:
            try:
                resource.close()
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise errors[0]

    def finish(self) -> list[LiveCaptionEvent]:
        if self._state is LiveCaptionState.STOPPED:
            return []
        if self._state is not LiveCaptionState.RUNNING:
            raise RuntimeError("live caption session 未開始")
        events = self._finish_utterance(
            end_sample=self._expected_sample,
            reason="input_finished",
        )
        self._state = LiveCaptionState.STOPPED
        events.append(
            self._event(
                LiveCaptionEventType.STOPPED,
                start_sample=self._expected_sample,
                end_sample=self._expected_sample,
                reason="input_finished",
                utterance_id=None,
            )
        )
        return events

    def cancel(self) -> list[LiveCaptionEvent]:
        if self._state in {LiveCaptionState.CANCELLED, LiveCaptionState.STOPPED}:
            return []
        if self._state is not LiveCaptionState.RUNNING:
            raise RuntimeError("live caption session 未開始")
        self._speech_start_sample = None
        self._utterance.clear()
        self._pre_roll.clear()
        self._vad.reset()
        if self.speaker_tracker is not None:
            self.speaker_tracker.cancel()
        self._state = LiveCaptionState.CANCELLED
        return [
            self._event(
                LiveCaptionEventType.CANCELLED,
                start_sample=self._expected_sample,
                end_sample=self._expected_sample,
                reason="user_cancelled",
                utterance_id=None,
            )
        ]
