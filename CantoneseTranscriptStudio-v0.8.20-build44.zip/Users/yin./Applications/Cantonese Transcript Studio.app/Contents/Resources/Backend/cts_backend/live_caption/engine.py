"""Strictly local recognition engines for low-latency caption updates."""

from __future__ import annotations

import gc
import http.client
import json
import math
import os
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import wave
from array import array
from pathlib import Path
from typing import Any, Callable, Protocol, runtime_checkable

from .types import RecognitionResult


@runtime_checkable
class LocalRecognitionEngine(Protocol):
    name: str
    is_local: bool
    sample_rate: int

    def recognize_pcm16(self, data: bytes) -> RecognitionResult: ...

    def close(self) -> None: ...


class LocalEngineError(RuntimeError):
    pass


_LOOPBACK_HOST = "127.0.0.1"
_WHISPER_SERVER_MAX_RESPONSE_BYTES = 2 * 1024 * 1024
_WHISPER_SERVER_REQUEST_PATH_PATTERN = re.compile(r"^/cts-live-[A-Za-z0-9_-]{12,}$")


def resolve_whisper_server(explicit: str | Path | None = None) -> Path:
    """Resolve a locally installed whisper.cpp HTTP server executable.

    The live engine deliberately does not download a runtime or call a package
    manager.  Keeping executable discovery here also makes the production
    boundary explicit: the only child process it can launch is a local binary.
    """

    candidates = (
        Path(explicit).expanduser() if explicit else None,
        Path(os.environ["CTS_WHISPER_SERVER"]).expanduser()
        if os.environ.get("CTS_WHISPER_SERVER")
        else None,
        Path(shutil.which("whisper-server")) if shutil.which("whisper-server") else None,
        Path("/opt/homebrew/bin/whisper-server"),
        Path("/usr/local/bin/whisper-server"),
    )
    for candidate in candidates:
        if candidate is not None and candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate.resolve()
    raise LocalEngineError("搵唔到 whisper-server；請先安裝本機 whisper.cpp runtime")


def reserve_loopback_port() -> int:
    """Ask the OS for an ephemeral TCP port on IPv4 loopback only.

    There is necessarily a short close-to-bind race before the child process
    takes ownership.  Readiness is therefore checked against this exact port;
    a failed bind is reported as a failed local server start, never retried
    against an arbitrary host.
    """

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind((_LOOPBACK_HOST, 0))
        port = int(probe.getsockname()[1])
    if not 1 <= port <= 65_535:  # pragma: no cover - OS contract guard
        raise LocalEngineError("系統未能提供有效嘅本機 Whisper port")
    return port


def _remove_owned_tree(directory: Path) -> None:
    """Remove only an engine-created temporary directory without shelling out.

    ``directory`` is created by ``mkdtemp`` with mode 0700.  This explicit
    traversal refuses to follow a symlink, so cleanup cannot expand beyond the
    per-session directory even if an unexpected file appears inside it.
    """

    try:
        if directory.is_symlink():
            directory.unlink(missing_ok=True)
            return
        if not directory.is_dir():
            return
        for child in directory.iterdir():
            if child.is_symlink() or child.is_file():
                child.unlink(missing_ok=True)
            elif child.is_dir():
                _remove_owned_tree(child)
        directory.rmdir()
    except OSError:
        # Cleanup must not turn a successfully stopped caption session into a
        # UI crash.  The 0700 directory is still inaccessible to other users.
        pass


def terminate_whisper_server_process_group(
    process: Any,
    *,
    grace_seconds: float = 2.0,
    clock: Callable[[], float] = time.monotonic,
    sleeper: Callable[[float], None] = time.sleep,
) -> None:
    """Terminate the server and every child in its own process group.

    The server is launched with ``start_new_session=True``.  A normal SIGTERM
    gives whisper.cpp a chance to finish its listener shutdown; SIGKILL is the
    bounded fallback so an abandoned Metal worker cannot outlive a session.
    """

    pid = getattr(process, "pid", None)
    if not isinstance(pid, int) or pid <= 0:
        # This branch is useful for narrow fake-process tests.  Production
        # Popen objects always have a positive PID and use killpg below.
        terminate = getattr(process, "terminate", None)
        if callable(terminate):
            try:
                terminate()
            except OSError:
                pass
        return

    try:
        os.killpg(pid, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        pass

    deadline = clock() + max(0.0, float(grace_seconds))
    while clock() < deadline:
        try:
            if process.poll() is not None:
                break
        except OSError:
            break
        sleeper(0.02)

    try:
        still_running = process.poll() is None
    except OSError:
        still_running = False
    if still_running:
        try:
            os.killpg(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    try:
        process.wait(timeout=max(0.05, min(1.0, float(grace_seconds))))
    except (OSError, subprocess.TimeoutExpired):
        pass


class SherpaWenetMicroBatchEngine:
    """Reuse one local offline WeNet recognizer for bounded rolling passes.

    The installed Yue U2++ file is an offline export (``model.int8.onnx``), not
    sherpa's ``model-streaming.int8.onnx`` format.  Reusing the loaded 128 MB
    recognizer and decoding a short rolling buffer still produces practical
    partials without retaining Qwen or Whisper Large in memory.
    """

    name = "sherpa-wenetspeech-yue-u2pp-int8-microbatch"
    is_local = True
    sample_rate = 16_000

    def __init__(
        self,
        model_dir: str | Path,
        *,
        num_threads: int = 2,
        maximum_audio_seconds: float = 20.0,
        warm_up: bool = True,
        recognizer_factory: Callable[..., Any] | None = None,
    ) -> None:
        if not 1 <= int(num_threads) <= 4:
            raise ValueError("live Wenet num_threads 必須係 1 至 4")
        if not 1.0 <= float(maximum_audio_seconds) <= 30.0:
            raise ValueError("maximum_audio_seconds 必須係 1 至 30")
        self.model_dir = Path(model_dir).expanduser().resolve()
        self.model_file = self.model_dir / "model.int8.onnx"
        self.tokens_file = self.model_dir / "tokens.txt"
        if not self.model_file.is_file() or not self.tokens_file.is_file():
            raise FileNotFoundError(f"本地 live Wenet 模型不完整：{self.model_dir}")
        self.num_threads = int(num_threads)
        self.maximum_audio_seconds = float(maximum_audio_seconds)
        self._lock = threading.Lock()
        self._closed = False

        if recognizer_factory is None:
            try:
                import sherpa_onnx
            except ImportError as exc:  # pragma: no cover - pinned production dependency
                raise LocalEngineError("runtime 未安裝 sherpa-onnx==1.13.4") from exc
            factory = sherpa_onnx.OfflineRecognizer.from_wenet_ctc
        else:
            factory = recognizer_factory
        self._recognizer = factory(
            model=str(self.model_file),
            tokens=str(self.tokens_file),
            num_threads=self.num_threads,
            sample_rate=self.sample_rate,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
        )
        self.warm_up_latency_ms = 0.0
        if warm_up:
            started = time.perf_counter()
            # ONNX Runtime may map/compile model pages lazily on its first
            # decode. Pay that cost while the app shows "準備即時字幕", before
            # accepting microphone frames.
            self.recognize_pcm16(b"\0\0" * round(self.sample_rate * 0.25))
            self.warm_up_latency_ms = (time.perf_counter() - started) * 1000

    @property
    def resident_model_bytes(self) -> int:
        return self.model_file.stat().st_size

    def recognize_pcm16(self, data: bytes) -> RecognitionResult:
        if not data or len(data) % 2:
            raise ValueError("ASR input 必須係非空 PCM16 bytes")
        samples_count = len(data) // 2
        duration = samples_count / self.sample_rate
        if duration > self.maximum_audio_seconds + 1e-6:
            raise ValueError(
                f"live ASR buffer {duration:.2f}s 超過 {self.maximum_audio_seconds:.2f}s 上限"
            )
        pcm = array("h")
        pcm.frombytes(data)
        if sys.byteorder != "little":  # pragma: no cover - supported Macs are little-endian
            pcm.byteswap()
        # sherpa's pybind API consumes any contiguous float32 buffer. Using the
        # stdlib array keeps live startup independent of NumPy's large module
        # graph, which is important when the project venv sits on an HDD.
        samples = array("f", (value / 32768.0 for value in pcm))
        with self._lock:
            if self._closed:
                raise LocalEngineError("live ASR engine 已關閉")
            stream = self._recognizer.create_stream()
            stream.accept_waveform(self.sample_rate, samples)
            self._recognizer.decode_stream(stream)
            result = stream.result
            raw_probabilities = tuple(
                float(value) for value in (getattr(result, "ys_log_probs", []) or [])
            )
            confidence: float | None = None
            if raw_probabilities:
                mean_log_probability = sum(raw_probabilities) / len(raw_probabilities)
                confidence = max(0.0, min(1.0, math.exp(mean_log_probability)))
            return RecognitionResult(
                text=str(getattr(result, "text", "") or "").strip(),
                tokens=tuple(str(value) for value in (getattr(result, "tokens", []) or [])),
                timestamps=tuple(
                    float(value) for value in (getattr(result, "timestamps", []) or [])
                ),
                confidence=confidence,
                metadata={
                    "model_path": str(self.model_file),
                    "provider": "cpu",
                    "num_threads": self.num_threads,
                    "audio_seconds": round(duration, 6),
                    "engine_warm_up_ms": round(self.warm_up_latency_ms, 3),
                },
            )

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            recognizer = self._recognizer
            self._recognizer = None  # type: ignore[assignment]
        del recognizer
        gc.collect()


def build_whisper_server_command(
    *,
    server_path: Path,
    model_file: Path,
    port: int,
    request_path: str,
    temporary_dir: Path,
    threads: int,
    language: str = "yue",
) -> list[str]:
    """Build the fixed, loopback-only whisper.cpp server command.

    This is intentionally a very small command surface.  In particular,
    callers cannot replace the host, inference path, or GPU policy.  Live
    recognition is intentionally limited to the two explicitly supported
    local roles: ``zh`` provisional and ``yue`` Cantonese final.
    ``whisper-server`` starts with Metal enabled by default on Apple Silicon;
    omitting ``-ng`` is an explicit correctness requirement here.
    """

    if not _WHISPER_SERVER_REQUEST_PATH_PATTERN.fullmatch(request_path):
        raise ValueError("Whisper request path 無效")
    if not 1 <= int(port) <= 65_535:
        raise ValueError("Whisper loopback port 無效")
    if not 1 <= int(threads) <= 12:
        raise ValueError("Whisper live threads 必須係 1 至 12")
    if language not in {"zh", "yue"}:
        raise ValueError("Whisper live language 必須係 zh 或 yue")
    command = [
        str(server_path),
        "-m",
        str(model_file),
        "-l",
        language,
        "-t",
        str(int(threads)),
        "--host",
        _LOOPBACK_HOST,
        "--port",
        str(int(port)),
        "--request-path",
        request_path,
        "--inference-path",
        "/inference",
        # No static files are shipped by this per-session directory.  The
        # random request path protects the local endpoint from generic
        # localhost callers while the loopback bind prevents LAN exposure.
        "--public",
        str(temporary_dir / "public"),
        "--tmp-dir",
        str(temporary_dir),
    ]
    if "-ng" in command or "--no-gpu" in command:  # defensive invariant
        raise AssertionError("live Whisper 唔可以停用 GPU")
    return command


class WhisperCppLiveEngine:
    """Persistent, loopback-only whisper.cpp server for live Cantonese ASR.

    Audio never leaves the process except across one HTTP connection to the
    child server at ``127.0.0.1``.  The child owns one loaded model for the
    session, avoiding a costly model reload for every rolling partial.  Every
    PCM request becomes a short 16kHz/mono/PCM16 WAV inside a fresh 0700 temp
    directory and is unlinked immediately after the request returns.

    The engine intentionally keeps no audio bytes, response body, or
    transcript on ``self`` after ``recognize_pcm16`` returns.  The returned
    ``RecognitionResult`` remains the caller's normal caption event data.
    """

    name = "whisper.cpp-live-yue"
    is_local = True
    sample_rate = 16_000

    def __init__(
        self,
        model_file: str | Path,
        *,
        server_path: str | Path | None = None,
        language: str = "yue",
        threads: int = 4,
        maximum_audio_seconds: float = 20.0,
        startup_timeout_seconds: float = 75.0,
        inference_timeout_seconds: float = 45.0,
        temporary_root: str | Path | None = None,
        process_factory: Callable[..., Any] = subprocess.Popen,
        http_connection_factory: Callable[..., Any] = http.client.HTTPConnection,
        port_allocator: Callable[[], int] = reserve_loopback_port,
        clock: Callable[[], float] = time.monotonic,
        sleeper: Callable[[float], None] = time.sleep,
        token_factory: Callable[[], str] = lambda: secrets.token_urlsafe(18),
        process_terminator: Callable[..., None] = terminate_whisper_server_process_group,
    ) -> None:
        if not 1 <= int(threads) <= 12:
            raise ValueError("Whisper live threads 必須係 1 至 12")
        if language not in {"zh", "yue"}:
            raise ValueError("Whisper live language 必須係 zh 或 yue")
        if not 1.0 <= float(maximum_audio_seconds) <= 30.0:
            raise ValueError("maximum_audio_seconds 必須係 1 至 30")
        if not 1.0 <= float(startup_timeout_seconds) <= 180.0:
            raise ValueError("startup_timeout_seconds 必須係 1 至 180")
        if not 1.0 <= float(inference_timeout_seconds) <= 120.0:
            raise ValueError("inference_timeout_seconds 必須係 1 至 120")

        self.model_file = Path(model_file).expanduser().resolve()
        if not self.model_file.is_file():
            raise FileNotFoundError(f"本機 live Whisper 模型不存在：{self.model_file}")
        self.server_path = resolve_whisper_server(server_path)
        self.language = language
        self.name = f"whisper.cpp-live-{self.language}"
        self.threads = int(threads)
        self.maximum_audio_seconds = float(maximum_audio_seconds)
        self.startup_timeout_seconds = float(startup_timeout_seconds)
        self.inference_timeout_seconds = float(inference_timeout_seconds)
        self._process_factory = process_factory
        self._http_connection_factory = http_connection_factory
        self._port_allocator = port_allocator
        self._clock = clock
        self._sleeper = sleeper
        self._token_factory = token_factory
        self._process_terminator = process_terminator
        self._lock = threading.RLock()
        # Serialise requests to one whisper-server (the server itself owns a
        # single model mutex) without using the lifecycle lock.  ``close``
        # must remain able to terminate that server while an HTTP request is
        # blocked, otherwise LiveCaptionWorker.stop can deadlock behind an
        # inference timeout.
        self._inference_lock = threading.Lock()
        self._active_requests = 0
        self._active_connections: dict[int, Any] = {}
        self._cleanup_pending = False
        self._closed = False
        self._process: Any | None = None

        root = Path(temporary_root or tempfile.gettempdir()).expanduser().resolve()
        if not root.is_dir():
            raise FileNotFoundError(f"Whisper 暫存位置不存在：{root}")
        self._temporary_root = root
        self._session_dir = Path(
            tempfile.mkdtemp(prefix="cts-live-whisper-", dir=str(root))
        ).resolve()
        os.chmod(self._session_dir, 0o700)
        self._public_dir = self._session_dir / "public"
        self._public_dir.mkdir(mode=0o700)
        os.chmod(self._public_dir, 0o700)

        raw_token = str(self._token_factory())
        self._request_path = f"/cts-live-{raw_token}"
        if not _WHISPER_SERVER_REQUEST_PATH_PATTERN.fullmatch(self._request_path):
            _remove_owned_tree(self._session_dir)
            raise ValueError("Whisper request token 無效")

        try:
            port = self._port_allocator()
            if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65_535:
                raise LocalEngineError("系統未能提供有效嘅本機 Whisper port")
            self._port = int(port)
            self._command = build_whisper_server_command(
                server_path=self.server_path,
                model_file=self.model_file,
                port=self._port,
                request_path=self._request_path,
                temporary_dir=self._session_dir,
                threads=self.threads,
                language=self.language,
            )
            self._start_and_wait()
        except Exception:
            self.close()
            raise

    @property
    def resident_model_bytes(self) -> int:
        return self.model_file.stat().st_size

    @property
    def server_port(self) -> int:
        return self._port

    @property
    def request_path(self) -> str:
        return self._request_path

    @property
    def command(self) -> tuple[str, ...]:
        """A redacted-safe command view for diagnostics and isolated tests."""

        return tuple(self._command)

    def _start_and_wait(self) -> None:
        process = self._process_factory(
            self._command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            start_new_session=True,
            shell=False,
        )
        self._process = process
        deadline = self._clock() + self.startup_timeout_seconds
        health_path = f"{self._request_path}/health"
        last_error = ""
        while self._clock() < deadline:
            return_code = process.poll()
            if return_code is not None:
                raise LocalEngineError(
                    f"本機 Whisper server 無法啟動（exit {return_code}）"
                )
            try:
                status, body = self._local_http_request(
                    "GET",
                    health_path,
                    timeout_seconds=min(1.0, max(0.1, deadline - self._clock())),
                )
                if status == 200:
                    decoded = json.loads(body.decode("utf-8"))
                    if isinstance(decoded, dict) and decoded.get("status") == "ok":
                        return
                last_error = f"health status {status}"
            except (OSError, ValueError, json.JSONDecodeError, http.client.HTTPException) as exc:
                last_error = str(exc)[:160]
            self._sleeper(min(0.08, max(0.01, deadline - self._clock())))
        detail = f"：{last_error}" if last_error else ""
        raise LocalEngineError(f"本機 Whisper model 載入逾時{detail}")

    def _local_http_request(
        self,
        method: str,
        path: str,
        *,
        body: bytes | None = None,
        headers: dict[str, str] | None = None,
        timeout_seconds: float,
    ) -> tuple[int, bytes]:
        """Issue one fixed-loopback request without redirect support.

        ``http.client`` does not follow redirects.  Since the hostname and
        path prefix are constructed internally, this method cannot contact an
        external API, even if an untrusted response attempts to suggest one.
        """

        if not path.startswith(f"{self._request_path}/"):
            raise LocalEngineError("Whisper request path 唔屬於目前 session")
        connection = self._http_connection_factory(
            _LOOPBACK_HOST,
            self._port,
            timeout=max(0.1, float(timeout_seconds)),
        )
        connection_key = id(connection)
        with self._lock:
            if self._closed:
                close = getattr(connection, "close", None)
                if callable(close):
                    close()
                raise LocalEngineError("live Whisper engine 已關閉")
            self._active_connections[connection_key] = connection
        try:
            connection.request(method, path, body=body, headers=headers or {})
            response = connection.getresponse()
            status = int(response.status)
            payload = response.read(_WHISPER_SERVER_MAX_RESPONSE_BYTES + 1)
            if len(payload) > _WHISPER_SERVER_MAX_RESPONSE_BYTES:
                raise LocalEngineError("本機 Whisper 回應超過安全上限")
            return status, bytes(payload)
        finally:
            with self._lock:
                self._active_connections.pop(connection_key, None)
            close = getattr(connection, "close", None)
            if callable(close):
                close()

    @staticmethod
    def _wav_bytes(data: bytes) -> bytes:
        # This helper exists solely so test doubles can inspect a valid WAV
        # payload.  The actual temporary file is still created before every
        # call, then unlinked in ``recognize_pcm16``'s finally block.
        import io

        output = io.BytesIO()
        with wave.open(output, "wb") as writer:
            writer.setnchannels(1)
            writer.setsampwidth(2)
            writer.setframerate(WhisperCppLiveEngine.sample_rate)
            writer.writeframes(data)
        return output.getvalue()

    def _write_pcm_wav(self, data: bytes) -> Path:
        filename = f"audio-{secrets.token_hex(16)}.wav"
        path = self._session_dir / filename
        # The parent is a 0700 directory we created; the random name avoids
        # collisions within an otherwise single-threaded inference lock.
        try:
            with wave.open(str(path), "wb") as writer:
                writer.setnchannels(1)
                writer.setsampwidth(2)
                writer.setframerate(self.sample_rate)
                writer.writeframes(data)
            os.chmod(path, 0o600)
            return path
        except BaseException:
            # A write can fail after creating the file (for example, a full
            # disk).  This is still an engine-owned transient path, so remove
            # it before the failure reaches the caller.
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            raise

    def _multipart_body(self, wav_bytes: bytes) -> tuple[bytes, str]:
        boundary = f"----CTSWhisper{secrets.token_hex(16)}"
        chunks: list[bytes] = []

        def field(name: str, value: str) -> None:
            chunks.extend(
                (
                    f"--{boundary}\r\n".encode("ascii"),
                    f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(
                        "ascii"
                    ),
                    value.encode("utf-8"),
                    b"\r\n",
                )
            )

        chunks.extend(
            (
                f"--{boundary}\r\n".encode("ascii"),
                b'Content-Disposition: form-data; name="file"; filename="audio.wav"\r\n',
                b"Content-Type: audio/wav\r\n\r\n",
                wav_bytes,
                b"\r\n",
            )
        )
        # Keep the HTTP request in the same explicitly selected local role as
        # the server command.  Repeating it protects against any server-side
        # per-request default reset.
        field("language", self.language)
        field("response_format", "verbose_json")
        field("token_timestamps", "true")
        field("temperature", "0.0")
        field("no_language_probabilities", "true")
        chunks.append(f"--{boundary}--\r\n".encode("ascii"))
        return b"".join(chunks), boundary

    @staticmethod
    def _finite_number(value: object) -> float | None:
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return None
        result = float(value)
        return result if math.isfinite(result) else None

    def _parse_response(
        self,
        body: bytes,
        *,
        audio_seconds: float,
    ) -> RecognitionResult:
        try:
            decoded = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise LocalEngineError("本機 Whisper 回應並非有效 JSON") from exc
        if not isinstance(decoded, dict):
            raise LocalEngineError("本機 Whisper 回應格式無效")
        error = decoded.get("error")
        if isinstance(error, str) and error.strip():
            raise LocalEngineError(f"本機 Whisper 未能轉錄：{error.strip()[:200]}")

        raw_segments = decoded.get("segments")
        if raw_segments is None:
            raw_segments = []
        if not isinstance(raw_segments, list):
            raise LocalEngineError("本機 Whisper 回應缺少有效 segments")

        segments: list[dict[str, object]] = []
        tokens: list[str] = []
        timestamps: list[float] = []
        log_probabilities: list[float] = []
        for raw_segment in raw_segments:
            if not isinstance(raw_segment, dict):
                continue
            segment_text = raw_segment.get("text")
            if not isinstance(segment_text, str):
                segment_text = ""
            start = self._finite_number(raw_segment.get("start"))
            end = self._finite_number(raw_segment.get("end"))
            if start is not None and end is not None:
                start = max(0.0, min(audio_seconds, start))
                end = max(start, min(audio_seconds, end))
            if segment_text or start is not None or end is not None:
                segments.append(
                    {
                        "start": start,
                        "end": end,
                        "text": segment_text.strip(),
                    }
                )
            average_log_probability = self._finite_number(raw_segment.get("avg_logprob"))
            if average_log_probability is not None:
                log_probabilities.append(average_log_probability)
            raw_words = raw_segment.get("words")
            if isinstance(raw_words, list):
                for raw_word in raw_words:
                    if not isinstance(raw_word, dict):
                        continue
                    word = raw_word.get("word")
                    word_start = self._finite_number(raw_word.get("start"))
                    if not isinstance(word, str) or word_start is None:
                        continue
                    tokens.append(word)
                    timestamps.append(max(0.0, min(audio_seconds, word_start)))

        response_text = decoded.get("text")
        if isinstance(response_text, str):
            text = response_text.strip()
        else:
            text = ""
        if not text:
            text = "".join(
                str(segment["text"]) for segment in segments if segment["text"]
            ).strip()
        if not tokens:
            # Retain segment-level alignment when an older whisper.cpp build
            # omits word data.  Never invent token timestamps beyond what the
            # server gave us.
            for segment in segments:
                segment_text = str(segment["text"])
                segment_start = segment["start"]
                if segment_text and isinstance(segment_start, float):
                    tokens.append(segment_text)
                    timestamps.append(segment_start)

        confidence: float | None = None
        if log_probabilities:
            mean_log_probability = sum(log_probabilities) / len(log_probabilities)
            confidence = max(0.0, min(1.0, math.exp(mean_log_probability)))
        return RecognitionResult(
            text=text,
            tokens=tuple(tokens),
            timestamps=tuple(timestamps),
            confidence=confidence,
            metadata={
                "model_path": str(self.model_file),
                "language": self.language,
                "audio_seconds": round(audio_seconds, 6),
                "server": "whisper.cpp",
                "gpu_disabled": False,
                "segment_count": len(segments),
                # This is structured response data, not a server-side cache;
                # it lives only in the RecognitionResult returned to the live
                # caption processor for the current inference.
                "segments": tuple(segments),
            },
        )

    def recognize_pcm16(self, data: bytes) -> RecognitionResult:
        if not data or len(data) % 2:
            raise ValueError("ASR input 必須係非空 PCM16 bytes")
        duration = len(data) / 2 / self.sample_rate
        if duration > self.maximum_audio_seconds + 1e-6:
            raise ValueError(
                f"live ASR buffer {duration:.2f}s 超過 {self.maximum_audio_seconds:.2f}s 上限"
            )

        # Calls are serialized for one server, but the lifecycle lock is held
        # only long enough to protect ownership state.  This lets ``close``
        # asynchronously close the loopback socket and kill the process group
        # while the current HTTP inference is waiting.
        with self._inference_lock:
            audio_path: Path | None = None
            with self._lock:
                if self._closed:
                    raise LocalEngineError("live Whisper engine 已關閉")
                if self._process is None or self._process.poll() is not None:
                    raise LocalEngineError("本機 Whisper server 已停止")
                # Increment before writing.  Once close observes this count,
                # it defers session-dir removal until this call has unlinked
                # its own WAV and left the request safely.
                self._active_requests += 1
            try:
                # Never hold the lifecycle lock around filesystem or network
                # I/O.  ``close`` may now terminate the process group even if
                # a pathological disk stalls this short WAV write; the active
                # request lease keeps the 0700 session directory alive until
                # this call's finally block has finished its own cleanup.
                audio_path = self._write_pcm_wav(data)
                with self._lock:
                    if self._closed:
                        raise LocalEngineError("live Whisper engine 已關閉")
                wav_bytes = audio_path.read_bytes()
                body, boundary = self._multipart_body(wav_bytes)
                status, response = self._local_http_request(
                    "POST",
                    f"{self._request_path}/inference",
                    body=body,
                    headers={
                        "Content-Type": f"multipart/form-data; boundary={boundary}",
                        "Content-Length": str(len(body)),
                    },
                    timeout_seconds=self.inference_timeout_seconds,
                )
                if status != 200:
                    raise LocalEngineError(f"本機 Whisper server 回應 HTTP {status}")
                result = self._parse_response(response, audio_seconds=duration)
                with self._lock:
                    if self._closed:
                        # A caller that chose cancel/close must never receive a
                        # late final caption merely because the local server
                        # completed at the same moment.
                        raise LocalEngineError("live Whisper engine 已關閉")
                return result
            except (OSError, http.client.HTTPException) as exc:
                raise LocalEngineError("本機 Whisper server 連線失敗") from exc
            finally:
                if audio_path is not None:
                    # Only this engine-created per-call file is removed.  No
                    # user input path is ever accepted by this cleanup branch.
                    try:
                        audio_path.unlink(missing_ok=True)
                    except OSError:
                        pass
                with self._lock:
                    cleanup_dir = self._finish_active_request_locked()
                if cleanup_dir is not None:
                    _remove_owned_tree(cleanup_dir)

    def _finish_active_request_locked(self) -> Path | None:
        """Release one active-call lease and defer deletion until it is safe.

        The caller holds ``self._lock``.  A closed engine keeps its 0700 temp
        directory until the final active request has removed its audio file;
        this prevents close-vs-write and close-vs-unlink races.
        """

        if self._active_requests <= 0:  # pragma: no cover - lifecycle invariant
            raise AssertionError("Whisper active request 計數失效")
        self._active_requests -= 1
        if self._active_requests == 0 and self._cleanup_pending:
            self._cleanup_pending = False
            return self._session_dir
        return None

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            process = self._process
            self._process = None
            # Do not remove a temp directory while a request may be writing,
            # reading, or unlinking its per-call WAV.  The final request takes
            # this cleanup lease in its ``finally`` block.
            self._cleanup_pending = True
            session_dir = (
                self._session_dir if self._active_requests == 0 else None
            )
            if session_dir is not None:
                self._cleanup_pending = False
            connections = tuple(self._active_connections.values())
            self._active_connections.clear()
        try:
            # Closing the loopback connection first unblocks a client waiting
            # in HTTPResponse.read; process-group termination remains the
            # bounded fallback for a native server that has not observed it.
            for connection in connections:
                close = getattr(connection, "close", None)
                if callable(close):
                    try:
                        close()
                    except OSError:
                        pass
            if process is not None:
                self._process_terminator(
                    process,
                    grace_seconds=2.0,
                    clock=self._clock,
                    sleeper=self._sleeper,
                )
        finally:
            if session_dir is not None:
                _remove_owned_tree(session_dir)

    def __del__(self) -> None:  # pragma: no cover - best-effort interpreter cleanup
        try:
            self.close()
        except Exception:
            pass
