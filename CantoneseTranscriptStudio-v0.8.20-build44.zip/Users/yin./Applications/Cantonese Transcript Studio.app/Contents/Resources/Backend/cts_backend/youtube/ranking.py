"""Deterministic Cantonese／Traditional-Chinese subtitle selection."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from .schemas import SubtitleSource, SubtitleTrack


_FORMAT_PRIORITY = {"vtt": 0, "srt": 1}


def _normalize_language(value: str) -> str:
    return value.strip().replace("_", "-").lower()


def _language_priority(value: str) -> tuple[int, str] | None:
    language = _normalize_language(value)
    if language == "yue":
        return (0, language)
    if language.startswith("yue-"):
        return (1, language)
    if language == "zh-hk" or language.startswith("zh-hk-"):
        return (2, language)
    if language == "zh-hant" or language.startswith("zh-hant-"):
        return (3, language)
    if language == "zh-tw" or language.startswith("zh-tw-"):
        return (4, language)
    if language == "zh":
        return (5, language)
    if language.startswith("zh-"):
        return (6, language)
    return None


def _extensions(items: Any) -> tuple[str, ...]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes)):
        return ()
    values: set[str] = set()
    for item in items:
        if isinstance(item, Mapping):
            extension = str(item.get("ext", "")).lower().lstrip(".")
        else:
            extension = str(item).lower().lstrip(".")
        if extension in _FORMAT_PRIORITY:
            values.add(extension)
    return tuple(sorted(values, key=lambda value: (_FORMAT_PRIORITY[value], value)))


def _tracks(
    mapping: Mapping[str, Any] | None,
    source: SubtitleSource,
) -> list[tuple[tuple[int, str], SubtitleTrack]]:
    ranked: list[tuple[tuple[int, str], SubtitleTrack]] = []
    if not isinstance(mapping, Mapping):
        return ranked
    for raw_language, formats in mapping.items():
        language = str(raw_language)
        priority = _language_priority(language)
        extensions = _extensions(formats)
        if priority is None or not extensions:
            continue
        try:
            track = SubtitleTrack(language, source, extensions[0])
        except ValueError:
            continue
        ranked.append((priority, track))
    return ranked


def rank_subtitle_tracks(
    subtitles: Mapping[str, Any] | None,
    automatic_captions: Mapping[str, Any] | None,
) -> tuple[SubtitleTrack, ...]:
    """Return every usable track: all manual priorities, then all automatic."""

    manual = sorted(_tracks(subtitles, SubtitleSource.MANUAL), key=lambda item: item[0])
    automatic = sorted(
        _tracks(automatic_captions, SubtitleSource.AUTOMATIC), key=lambda item: item[0]
    )
    return tuple(track for _, track in (*manual, *automatic))


def select_best_subtitle_track(
    subtitles: Mapping[str, Any] | None,
    automatic_captions: Mapping[str, Any] | None,
) -> SubtitleTrack | None:
    tracks = rank_subtitle_tracks(subtitles, automatic_captions)
    return tracks[0] if tracks else None
