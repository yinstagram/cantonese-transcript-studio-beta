from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping

from .constants import SCHEMA_VERSION


@dataclass(frozen=True)
class AudioStreamMetadata:
    index: int
    codec_name: str | None = None
    sample_rate: int | None = None
    channels: int | None = None


@dataclass(frozen=True)
class MediaMetadata:
    path: str
    duration_ms: int
    size_bytes: int
    format_name: str | None
    audio_streams: tuple[AudioStreamMetadata, ...]
    video_stream_count: int = 0

    @property
    def has_audio(self) -> bool:
        return bool(self.audio_streams)


@dataclass(frozen=True)
class ChunkSpec:
    index: int
    path: str
    start_ms: int
    end_ms: int
    core_start_ms: int
    core_end_ms: int

    @property
    def duration_ms(self) -> int:
        return self.end_ms - self.start_ms


@dataclass(frozen=True)
class ChunkPlan:
    source_path: str
    sample_rate: int
    total_duration_ms: int
    overlap_ms: int
    chunks: tuple[ChunkSpec, ...]
    version: int = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ChunkPlan":
        return cls(
            source_path=str(data["source_path"]),
            sample_rate=int(data["sample_rate"]),
            total_duration_ms=int(data["total_duration_ms"]),
            overlap_ms=int(data["overlap_ms"]),
            chunks=tuple(ChunkSpec(**item) for item in data.get("chunks", ())),
            version=int(data.get("version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class TranscriptSegment:
    start_ms: int
    end_ms: int
    text: str
    confidence: float | None = None
    source: str = "primary"
    chunk_index: int | None = None

    def __post_init__(self) -> None:
        if self.start_ms < 0 or self.end_ms < self.start_ms:
            raise ValueError("segment timestamps must satisfy 0 <= start_ms <= end_ms")
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ValueError("segment confidence must be between 0 and 1")


@dataclass(frozen=True)
class Correction:
    primary_start: int
    primary_end: int
    before: str
    after: str
    reason: str


@dataclass(frozen=True)
class AlignmentAudit:
    similarity: float
    edit_distance: int
    disagreement_count: int
    missing_in_verifier: bool
    conflict: bool
    low_confidence: bool
    reasons: tuple[str, ...] = ()
    corrections: tuple[Correction, ...] = ()
    disagreement_ratio: float = 0.0
    missing: bool = False
    conflict_candidate: bool = False


@dataclass(frozen=True)
class ReconciledSegment:
    start_ms: int
    end_ms: int
    primary_text: str
    verifier_text: str
    text: str
    confidence: float | None
    audit: AlignmentAudit
    whisper_text: str = ""
    ensemble_audit: Mapping[str, Any] = field(default_factory=dict)
    speaker_index: int | None = None
    speaker_id: str | None = None
    speaker_label: str | None = None
    speaker_labels: tuple[str, ...] = ()
    speaker_overlap: bool = False

    def to_dict(self) -> dict[str, Any]:
        audit = asdict(self.audit)
        reason = ";".join(self.audit.reasons)
        candidate_audit = {
            "disagreement_ratio": self.audit.disagreement_ratio,
            "missing": self.audit.missing,
            "conflict": self.audit.conflict,
            "conflict_candidate": self.audit.conflict_candidate,
        }
        value = {
            "start_ms": self.start_ms,
            "end_ms": self.end_ms,
            "start": round(self.start_ms / 1000.0, 3),
            "end": round(self.end_ms / 1000.0, 3),
            "confidence": self.confidence,
            "disagreement_flag": bool(
                self.audit.disagreement_count or self.audit.missing or self.audit.conflict_candidate
            ),
            "primary_text": self.primary_text,
            "verifier_text": self.verifier_text,
            "chosen_text": self.text,
            "reconciliation_reason": reason,
            "text": self.text,
            "disagreement_ratio": self.audit.disagreement_ratio,
            "missing": self.audit.missing,
            "conflict_candidate": self.audit.conflict_candidate,
            "candidate_audit": candidate_audit,
            "audit": audit,
        }
        if self.whisper_text or self.ensemble_audit:
            value["whisper_text"] = self.whisper_text
            value["ensemble_audit"] = dict(self.ensemble_audit)
        if self.speaker_label is not None or self.speaker_labels:
            value.update(
                {
                    "speaker_index": self.speaker_index,
                    "speaker_id": self.speaker_id,
                    "speaker_label": self.speaker_label,
                    "speaker_labels": list(self.speaker_labels),
                    "speaker_overlap": self.speaker_overlap,
                }
            )
        return value


@dataclass(frozen=True)
class TimedSubtitleSegment:
    """Fine subtitle cue derived from the final, already-normalized transcript.

    Reconciliation segments remain the audit source of truth.  These shorter
    cues are a presentation/export layer, so they deliberately carry source
    segment references instead of duplicating primary/verifier text.
    """

    id: str
    start_ms: int
    end_ms: int
    text: str
    source_start: int
    source_end: int
    source_segment_index: int | None = None
    source_segment_indices: tuple[int, ...] = ()
    confidence: float | None = None
    low_confidence: bool = False
    method: str = "qwen3_forced_aligner"
    speaker_index: int | None = None
    speaker_id: str | None = None
    speaker_label: str | None = None
    speaker_labels: tuple[str, ...] = ()
    speaker_overlap: bool = False
    timing_review_required: bool | None = None

    def __post_init__(self) -> None:
        if not self.id or len(self.id) > 128:
            raise ValueError("subtitle segment id 無效")
        if self.start_ms < 0 or self.end_ms <= self.start_ms:
            raise ValueError("subtitle timestamps 必須滿足 0 <= start_ms < end_ms")
        if self.source_start < 0 or self.source_end < self.source_start:
            raise ValueError("subtitle source range 無效")
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ValueError("subtitle confidence 必須係 0 至 1")
        if self.timing_review_required is not None and not isinstance(self.timing_review_required, bool):
            raise ValueError("subtitle timing_review_required 必須係布林值或 None")

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        if self.timing_review_required is None:
            value.pop("timing_review_required")
        value.update(
            {
                "start": round(self.start_ms / 1000.0, 3),
                "end": round(self.end_ms / 1000.0, 3),
            }
        )
        return value


@dataclass(frozen=True)
class TranscriptDocument:
    media_path: str
    text: str
    segments: tuple[ReconciledSegment, ...]
    language: str = "Cantonese"
    model_primary: str | None = None
    model_verifier: str | None = None
    model_whisper: str | None = None
    vocabulary: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)
    subtitle_segments: tuple[TimedSubtitleSegment, ...] = ()
    word_timestamps: tuple[Mapping[str, Any], ...] = ()
    character_timestamps: tuple[Mapping[str, Any], ...] = ()
    duration: float | None = None
    processing_started_at: str | None = None
    processing_completed_at: str | None = None
    version: int = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        source = str(self.media_path)
        value = {
            "source_filename": Path(source).name,
            "source_path": source,
            "media_path": source,
            "duration": self.duration,
            "language": self.language,
            "primary_model": self.model_primary,
            "verifier_model": self.model_verifier,
            "model_primary": self.model_primary,
            "model_verifier": self.model_verifier,
            "processing_started_at": self.processing_started_at,
            "processing_completed_at": self.processing_completed_at,
            "final_transcript": self.text,
            "text": self.text,
            "segments": [segment.to_dict() for segment in self.segments],
            "vocabulary": list(self.vocabulary),
            "metadata": dict(self.metadata),
            "version": self.version,
        }
        if self.subtitle_segments:
            value["subtitle_segments"] = [segment.to_dict() for segment in self.subtitle_segments]
        if self.word_timestamps:
            value["word_timestamps"] = [dict(item) for item in self.word_timestamps]
        if self.character_timestamps:
            value["character_timestamps"] = [dict(item) for item in self.character_timestamps]
        if self.model_whisper is not None:
            value["whisper_model"] = self.model_whisper
            value["model_whisper"] = self.model_whisper
        return value


def path_strings(paths: list[str | Path] | tuple[str | Path, ...]) -> tuple[str, ...]:
    return tuple(str(Path(path)) for path in paths)
