"""Real local ASR adapters."""

from .qwen import QwenASR, release_mlx_memory
from .sensevoice import SenseVoiceYueCandidate, format_timestamp, timestamp_txt
from .sherpa import SherpaYueVerifier
from .whisper_cpp import (
    WHISPER_CPP_POLICY_VERSION,
    WhisperCPPASR,
    WhisperCPPError,
    build_whisper_command,
    parse_whisper_json,
    resolve_whisper_cli,
)
from .types import ASRCancelled, AudioChunk, TranscriptSegment, VerifierToken

__all__ = [
    "ASRCancelled",
    "AudioChunk",
    "QwenASR",
    "SenseVoiceYueCandidate",
    "SherpaYueVerifier",
    "WHISPER_CPP_POLICY_VERSION",
    "TranscriptSegment",
    "VerifierToken",
    "WhisperCPPASR",
    "WhisperCPPError",
    "build_whisper_command",
    "format_timestamp",
    "release_mlx_memory",
    "parse_whisper_json",
    "resolve_whisper_cli",
    "timestamp_txt",
]
