"""Retired cue-anchor experiments kept outside the production alignment path.

These deterministic transforms remain available only for reproducing historical
evaluation receipts.  Real-recording review rejected automatic cue retiming, so
production code must not import this module or apply either result to a project.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Sequence

from ..alignment.forced_timestamps import MIN_CUE_MS, SubtitleCue, WordTimestamp


CUE_OWNED_WORD_ANCHOR_POLICY_VERSION = "cue-owned-word-anchor-v1-experimental"
CUE_OWNED_WORD_ANCHOR_MIN_DURATION_MS = 200
CUE_START_ONLY_ANCHOR_POLICY_VERSION = (
    "cue-start-only-owned-word-anchor-v2-final-presealed-trial"
)


@dataclass(frozen=True)
class CueOwnedWordAnchorAudit:
    """Transcript-free audit for a retired cue-only timing experiment."""

    policy_version: str
    cue_count: int
    anchored_cue_count: int
    unchanged_cue_count: int
    no_owned_word_fallback_count: int
    invalid_owned_word_fallback_count: int
    changed_start_count: int
    changed_end_count: int
    global_rejected: bool
    rejection_reasons: tuple[str, ...]


@dataclass(frozen=True)
class CueOwnedWordAnchorResult:
    """Historical presentation cues; never a production project mutation."""

    cues: tuple[SubtitleCue, ...]
    audit: CueOwnedWordAnchorAudit


def _validated_inputs(
    cues: Sequence[SubtitleCue],
    words: Sequence[WordTimestamp],
    media_duration_ms: int | None,
) -> tuple[tuple[SubtitleCue, ...], tuple[WordTimestamp, ...]]:
    if media_duration_ms is not None and (
        isinstance(media_duration_ms, bool)
        or not isinstance(media_duration_ms, int)
        or media_duration_ms < 0
    ):
        raise ValueError("media_duration_ms 必須係非負整數")

    originals = tuple(cues)
    ordered_words = tuple(
        sorted(words, key=lambda item: (item.source_start, item.source_end))
    )
    previous_source_end: int | None = None
    for cue in originals:
        if cue.source_end <= cue.source_start or cue.end_ms <= cue.start_ms or not cue.text:
            raise ValueError("subtitle cue range 無效")
        if previous_source_end is not None and cue.source_start != previous_source_end:
            raise ValueError("subtitle cue source ranges 必須連續")
        if len(cue.text) != cue.source_end - cue.source_start:
            raise ValueError("subtitle cue text 同 source range 唔一致")
        previous_source_end = cue.source_end

    previous_word_source_end = -1
    for word in ordered_words:
        if (
            not word.text
            or word.source_end <= word.source_start
            or word.end_ms <= word.start_ms
            or word.source_start < previous_word_source_end
        ):
            raise ValueError("word timestamp range 無效")
        previous_word_source_end = word.source_end
    return originals, ordered_words


def _owned_words(
    cue: SubtitleCue, words: Sequence[WordTimestamp]
) -> tuple[tuple[WordTimestamp, ...], tuple[WordTimestamp, ...]]:
    intersecting = tuple(
        word
        for word in words
        if word.source_start < cue.source_end and word.source_end > cue.source_start
    )
    partial = tuple(
        word
        for word in intersecting
        if not (cue.source_start <= word.source_start and word.source_end <= cue.source_end)
    )
    owned = tuple(
        word
        for word in intersecting
        if cue.source_start <= word.source_start and word.source_end <= cue.source_end
    )
    return partial, owned


def anchor_cues_to_owned_words(
    cues: Sequence[SubtitleCue],
    words: Sequence[WordTimestamp],
    *,
    media_duration_ms: int | None = None,
) -> CueOwnedWordAnchorResult:
    """Reproduce the retired v1 cue-start-and-end anchor experiment."""

    originals, ordered_words = _validated_inputs(cues, words, media_duration_ms)
    anchored: list[SubtitleCue] = []
    anchored_count = 0
    no_word_fallback_count = 0
    invalid_word_fallback_count = 0
    changed_start_count = 0
    changed_end_count = 0
    rejection_reasons: set[str] = set()

    for cue in originals:
        partial, owned = _owned_words(cue, ordered_words)
        candidate = cue
        if partial:
            invalid_word_fallback_count += 1
            rejection_reasons.add("partial_word_overlap")
        elif not owned:
            no_word_fallback_count += 1
        else:
            valid_content = all(
                cue.text[
                    word.source_start - cue.source_start : word.source_end - cue.source_start
                ]
                == word.text
                for word in owned
            )
            start_ms = owned[0].start_ms
            end_ms = owned[-1].end_ms
            in_bounds = (
                start_ms >= 0
                and end_ms > start_ms
                and (media_duration_ms is None or end_ms <= media_duration_ms)
            )
            if not valid_content:
                invalid_word_fallback_count += 1
                rejection_reasons.add("owned_word_text_mismatch")
            elif not in_bounds:
                invalid_word_fallback_count += 1
                rejection_reasons.add("owned_word_interval_invalid")
            elif end_ms - start_ms < CUE_OWNED_WORD_ANCHOR_MIN_DURATION_MS:
                invalid_word_fallback_count += 1
                rejection_reasons.add("owned_word_interval_absolute_flash")
            else:
                candidate = replace(cue, start_ms=start_ms, end_ms=end_ms)
                anchored_count += 1
                changed_start_count += int(start_ms != cue.start_ms)
                changed_end_count += int(end_ms != cue.end_ms)
        anchored.append(candidate)

    global_reasons = {
        "anchored_cue_overlap"
        for previous, current in zip(anchored, anchored[1:])
        if previous.end_ms > current.start_ms
    }
    if media_duration_ms is not None and any(
        cue.start_ms < 0 or cue.end_ms > media_duration_ms for cue in anchored
    ):
        global_reasons.add("anchored_cue_out_of_media_bounds")
    if global_reasons:
        rejection_reasons.update(global_reasons)
        return CueOwnedWordAnchorResult(
            cues=originals,
            audit=CueOwnedWordAnchorAudit(
                CUE_OWNED_WORD_ANCHOR_POLICY_VERSION,
                len(originals),
                0,
                len(originals),
                no_word_fallback_count,
                invalid_word_fallback_count,
                0,
                0,
                True,
                tuple(sorted(rejection_reasons)),
            ),
        )

    anchored_tuple = tuple(anchored)
    if "".join(item.text for item in anchored_tuple) != "".join(item.text for item in originals):
        raise AssertionError("cue anchor changed transcript content")
    return CueOwnedWordAnchorResult(
        cues=anchored_tuple,
        audit=CueOwnedWordAnchorAudit(
            CUE_OWNED_WORD_ANCHOR_POLICY_VERSION,
            len(originals),
            anchored_count,
            sum(candidate == original for candidate, original in zip(anchored_tuple, originals)),
            no_word_fallback_count,
            invalid_word_fallback_count,
            changed_start_count,
            changed_end_count,
            False,
            tuple(sorted(rejection_reasons)),
        ),
    )


def anchor_cue_starts_to_owned_words(
    cues: Sequence[SubtitleCue],
    words: Sequence[WordTimestamp],
    *,
    media_duration_ms: int | None = None,
) -> CueOwnedWordAnchorResult:
    """Reproduce the retired v2 later-start-only anchor experiment."""

    originals, ordered_words = _validated_inputs(cues, words, media_duration_ms)
    anchored: list[SubtitleCue] = []
    anchored_count = 0
    no_word_fallback_count = 0
    invalid_word_fallback_count = 0
    changed_start_count = 0
    rejection_reasons: set[str] = set()

    for cue in originals:
        partial, owned = _owned_words(cue, ordered_words)
        candidate = cue
        if partial:
            invalid_word_fallback_count += 1
            rejection_reasons.add("partial_word_overlap")
        elif not owned:
            no_word_fallback_count += 1
        elif cue.end_ms - cue.start_ms < MIN_CUE_MS:
            invalid_word_fallback_count += 1
            rejection_reasons.add("original_cue_below_min_duration")
        else:
            exact_local_coverage = all(
                cue.text[
                    word.source_start - cue.source_start : word.source_end - cue.source_start
                ]
                == word.text
                for word in owned
            )
            proposed_start_ms = owned[0].start_ms
            in_bounds = (
                proposed_start_ms >= 0
                and proposed_start_ms < cue.end_ms
                and (media_duration_ms is None or cue.end_ms <= media_duration_ms)
            )
            if not exact_local_coverage:
                invalid_word_fallback_count += 1
                rejection_reasons.add("owned_word_text_mismatch")
            elif not in_bounds:
                invalid_word_fallback_count += 1
                rejection_reasons.add("owned_word_start_invalid")
            elif proposed_start_ms <= cue.start_ms:
                invalid_word_fallback_count += 1
                rejection_reasons.add("start_not_later")
            elif cue.end_ms - proposed_start_ms < MIN_CUE_MS:
                invalid_word_fallback_count += 1
                rejection_reasons.add("anchored_cue_below_min_duration")
            else:
                candidate = replace(cue, start_ms=proposed_start_ms)
                anchored_count += 1
                changed_start_count += 1
        anchored.append(candidate)

    global_reasons = {
        "anchored_cue_overlap"
        for previous, current in zip(anchored, anchored[1:])
        if previous.end_ms > current.start_ms
    }
    if media_duration_ms is not None and any(
        cue.start_ms < 0 or cue.end_ms > media_duration_ms for cue in anchored
    ):
        global_reasons.add("anchored_cue_out_of_media_bounds")
    if global_reasons:
        rejection_reasons.update(global_reasons)
        return CueOwnedWordAnchorResult(
            cues=originals,
            audit=CueOwnedWordAnchorAudit(
                CUE_START_ONLY_ANCHOR_POLICY_VERSION,
                len(originals),
                0,
                len(originals),
                no_word_fallback_count,
                invalid_word_fallback_count,
                0,
                0,
                True,
                tuple(sorted(rejection_reasons)),
            ),
        )

    anchored_tuple = tuple(anchored)
    if "".join(item.text for item in anchored_tuple) != "".join(item.text for item in originals):
        raise AssertionError("cue start anchor changed transcript content")
    if any(candidate.end_ms != original.end_ms for candidate, original in zip(anchored_tuple, originals)):
        raise AssertionError("cue start anchor changed cue end")
    return CueOwnedWordAnchorResult(
        cues=anchored_tuple,
        audit=CueOwnedWordAnchorAudit(
            CUE_START_ONLY_ANCHOR_POLICY_VERSION,
            len(originals),
            anchored_count,
            sum(candidate == original for candidate, original in zip(anchored_tuple, originals)),
            no_word_fallback_count,
            invalid_word_fallback_count,
            changed_start_count,
            0,
            False,
            tuple(sorted(rejection_reasons)),
        ),
    )


__all__ = [
    "CUE_OWNED_WORD_ANCHOR_MIN_DURATION_MS",
    "CUE_OWNED_WORD_ANCHOR_POLICY_VERSION",
    "CUE_START_ONLY_ANCHOR_POLICY_VERSION",
    "CueOwnedWordAnchorAudit",
    "CueOwnedWordAnchorResult",
    "anchor_cue_starts_to_owned_words",
    "anchor_cues_to_owned_words",
]
