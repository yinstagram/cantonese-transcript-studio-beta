"""Deterministic source manifest for validation and candidate construction.

The manifest deliberately covers every project-owned file consumed by the
full test run or ``scripts/build_app.sh``.  It excludes generated caches and
build outputs, rejects symlinks, and records the absent/present state of
optional lock files so additions and removals are both detectable.
"""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path
from typing import Any, Iterable


BUILD_INPUT_MANIFEST_SCHEMA = "cts.build-input-manifest/v1"

BUILD_INPUT_TREES = (
    "app/Sources",
    "app/Tests",
    "backend/cts_backend",
    "backend/tests",
    "resources",
    "scripts",
    "app/.build/checkouts/FluidAudio",
)

BUILD_INPUT_REQUIRED_FILES = (
    "app/Package.swift",
    "pyproject.toml",
    "uv.lock",
    "LICENSE",
    "README.md",
    "docs/model-licenses.md",
    "docs/troubleshooting.md",
    "docs/distribution.md",
    "docs/release-checklist.md",
    "docs/local-api.md",
    "docs/lazy-camman-v2.md",
    "docs/architecture.md",
    "docs/timestamp-gold-protocol.md",
)

BUILD_INPUT_OPTIONAL_FILES = (
    "app/Package.resolved",
    "requirements.lock",
)

_IGNORED_DIRECTORY_NAMES = frozenset({"__pycache__", ".git", ".build"})
_IGNORED_FILE_NAMES = frozenset({".DS_Store"})


def _canonical_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return hashlib.sha256(encoded).hexdigest()


def _sha256_regular_file(path: Path) -> tuple[int, str]:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags)
    digest = hashlib.sha256()
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError(f"build input 唔係 regular file：{path}")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            digest.update(block)
        after = os.fstat(descriptor)
        identity_before = (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        )
        identity_after = (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        )
        if identity_after != identity_before:
            raise RuntimeError(f"build input hash 期間被修改：{path}")
        return after.st_size, digest.hexdigest()
    finally:
        os.close(descriptor)


def _file_record(project_root: Path, relative: str) -> dict[str, Any]:
    path = project_root / relative
    if path.is_symlink():
        raise ValueError(f"build input 唔可以係 symlink：{relative}")
    if not path.is_file():
        raise FileNotFoundError(f"required build input 唔存在：{relative}")
    size, digest = _sha256_regular_file(path)
    return {
        "path": relative,
        "state": "file",
        "bytes": size,
        "sha256": digest,
    }


def _tree_relative_files(project_root: Path, relative_root: str) -> Iterable[str]:
    tree = project_root / relative_root
    if tree.is_symlink() or not tree.is_dir():
        raise ValueError(f"build input tree 無效：{relative_root}")
    for directory, raw_directories, raw_files in os.walk(tree, followlinks=False):
        directory_path = Path(directory)
        kept_directories: list[str] = []
        for name in sorted(raw_directories):
            child = directory_path / name
            if child.is_symlink():
                raise ValueError(
                    "build input tree 唔可以包含 symlink directory："
                    f"{child.relative_to(project_root).as_posix()}"
                )
            if name not in _IGNORED_DIRECTORY_NAMES:
                kept_directories.append(name)
        raw_directories[:] = kept_directories
        for name in sorted(raw_files):
            if name in _IGNORED_FILE_NAMES or name.endswith((".pyc", ".pyo")):
                continue
            child = directory_path / name
            relative = child.relative_to(project_root).as_posix()
            if child.is_symlink():
                raise ValueError(f"build input 唔可以係 symlink：{relative}")
            if not child.is_file():
                raise ValueError(f"build input 唔係 regular file：{relative}")
            yield relative


def build_input_manifest(project_root: str | Path) -> dict[str, Any]:
    root = Path(project_root).resolve()
    records: dict[str, dict[str, Any]] = {}
    for relative in BUILD_INPUT_REQUIRED_FILES:
        records[relative] = _file_record(root, relative)
    for relative in BUILD_INPUT_OPTIONAL_FILES:
        path = root / relative
        if path.is_symlink():
            raise ValueError(f"optional build input 唔可以係 symlink：{relative}")
        records[relative] = (
            _file_record(root, relative)
            if path.exists()
            else {"path": relative, "state": "absent"}
        )
    for relative_root in BUILD_INPUT_TREES:
        for relative in _tree_relative_files(root, relative_root):
            if relative in records:
                raise ValueError(f"build input manifest 重複路徑：{relative}")
            records[relative] = _file_record(root, relative)
    files = [records[path] for path in sorted(records)]
    return {
        "schema": BUILD_INPUT_MANIFEST_SCHEMA,
        "sha256": _canonical_hash(files),
        "files": files,
    }


def require_build_input_manifest(
    expected: Any, project_root: str | Path
) -> dict[str, Any]:
    if (
        not isinstance(expected, dict)
        or expected.get("schema") != BUILD_INPUT_MANIFEST_SCHEMA
        or not isinstance(expected.get("sha256"), str)
        or not isinstance(expected.get("files"), list)
    ):
        raise ValueError("validated build-input manifest 無效")
    current = build_input_manifest(project_root)
    if current != expected:
        raise RuntimeError("build inputs changed after validation; refusing candidate build")
    return current
