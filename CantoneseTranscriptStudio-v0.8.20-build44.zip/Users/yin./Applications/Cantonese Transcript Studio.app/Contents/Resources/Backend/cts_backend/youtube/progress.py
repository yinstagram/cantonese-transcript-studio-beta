"""Parser for the one tab-delimited progress protocol emitted by our argv."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path

from .commands import ARTIFACT_PREFIX, PROGRESS_PREFIX


_MISSING = frozenset({"", "NA", "N/A", "None", "null", "unknown"})
_ALLOWED_STATUS = frozenset({"downloading", "finished", "postprocessing", "error"})


def _optional_integer(value: str) -> int | None:
    stripped = value.strip()
    if stripped in _MISSING:
        return None
    try:
        number = int(float(stripped))
    except (TypeError, ValueError, OverflowError):
        return None
    return number if number >= 0 else None


@dataclass(frozen=True)
class DownloadProgress:
    status: str
    downloaded_bytes: int | None
    total_bytes: int | None
    fragment_index: int | None
    fragment_count: int | None

    @property
    def ratio(self) -> float | None:
        if self.status == "finished":
            return 1.0
        if self.downloaded_bytes is not None and self.total_bytes:
            return min(1.0, max(0.0, self.downloaded_bytes / self.total_bytes))
        if self.fragment_index is not None and self.fragment_count:
            return min(1.0, max(0.0, self.fragment_index / self.fragment_count))
        return None


def parse_progress_line(line: str) -> DownloadProgress | None:
    """Parse only our machine sentinel; normal yt-dlp output is ignored."""

    if not isinstance(line, str) or len(line) > 1_024 or "\x00" in line:
        return None
    parts = line.rstrip("\r\n").split("\t")
    if len(parts) != 6 or parts[0] != PROGRESS_PREFIX:
        return None
    status = parts[1].strip().lower()
    if status not in _ALLOWED_STATUS:
        return None
    return DownloadProgress(
        status=status,
        downloaded_bytes=_optional_integer(parts[2]),
        total_bytes=_optional_integer(parts[3]),
        fragment_index=_optional_integer(parts[4]),
        fragment_count=_optional_integer(parts[5]),
    )


def parse_artifact_line(
    line: str,
    *,
    workspace: str | Path,
    expected_video_id: str,
) -> Path | None:
    """Accept only a completed local path inside the video's workspace."""

    if not isinstance(line, str) or len(line) > 16_384 or "\x00" in line:
        return None
    parts = line.rstrip("\r\n").split("\t", 2)
    if len(parts) != 3 or parts[0] != ARTIFACT_PREFIX or parts[1] != expected_video_id:
        return None
    try:
        decoded = json.loads(parts[2])
    except json.JSONDecodeError:
        return None
    if not isinstance(decoded, str) or not decoded:
        return None
    root = Path(workspace).expanduser().resolve(strict=False)
    candidate_input = Path(decoded).expanduser()
    if not candidate_input.is_absolute() or candidate_input.is_symlink():
        return None
    candidate = candidate_input.resolve(strict=False)
    try:
        candidate.relative_to(root)
    except ValueError:
        return None
    return candidate if candidate.is_file() else None
