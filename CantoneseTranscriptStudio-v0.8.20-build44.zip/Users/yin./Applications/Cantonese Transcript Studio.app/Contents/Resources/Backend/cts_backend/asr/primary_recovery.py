"""Source-bound, single-verifier fallbacks for explicitly failed primary decodes."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from .decode_health import primary_decode_health
from .types import TranscriptSegment
from ..models import SHERPA_MODEL_NAME
from ..schemas import ReconciledSegment

PRIMARY_RECOVERY_POLICY = "same-core-secondary-recovery-v1"
SAMPLE_RATE = 16000


class PrimaryRecoveryError(ValueError):
    pass


def _frame(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise PrimaryRecoveryError("non-finite/non-numeric core")
    frame = round(value * SAMPLE_RATE)
    if frame < 0 or not math.isclose(value * SAMPLE_RATE, frame, rel_tol=0, abs_tol=0.00001):
        raise PrimaryRecoveryError("core is not an exact source frame")
    return frame


def _tokens(values: Any) -> list[dict[str, Any]]:
    if not isinstance(values, (list, tuple)):
        raise PrimaryRecoveryError("verifier tokens must be a sequence")
    result = []
    for index, value in enumerate(values):
        token = value.get("token") if isinstance(value, Mapping) else getattr(value, "token", None)
        timestamp = value.get("timestamp") if isinstance(value, Mapping) else getattr(value, "timestamp", None)
        if (not isinstance(token, str) or not token or isinstance(timestamp, bool)
                or not isinstance(timestamp, (int, float)) or not math.isfinite(timestamp)):
            raise PrimaryRecoveryError("invalid verifier token/text/absolute timestamp")
        result.append({"index": index, "token": token, "timestamp": float(timestamp)})
    return result


def build_primary_recovery_decisions(
    primary: Sequence[TranscriptSegment], verifier: Sequence[TranscriptSegment], *, verifier_model: str
) -> list[dict[str, Any]]:
    health = [primary_decode_health(s.metadata, truncated=s.truncated) for s in primary]
    if not any(h["failed"] for h in health):
        return []
    if verifier_model != SHERPA_MODEL_NAME:
        raise PrimaryRecoveryError("unsupported independent verifier identity")
    ids = [s.id for s in primary]
    if any(not isinstance(i, str) or not i for i in ids) or len(set(ids)) != len(ids):
        raise PrimaryRecoveryError("duplicate/missing primary identity")
    previous_end = -1
    for segment in primary:
        start, end = _frame(segment.start), _frame(segment.end)
        if start < previous_end or end <= start:
            raise PrimaryRecoveryError("primary cores overlap or are out of order")
        previous_end = end
    decisions = []
    for index, (original, original_health) in enumerate(zip(primary, health)):
        if not original_health["failed"]:
            continue
        matches = [s for s in verifier if s.id == original.id]
        if len(matches) != 1:
            raise PrimaryRecoveryError(f"{original.id}: missing/ambiguous same-ID verifier")
        secondary = matches[0]
        model_path = secondary.metadata.get("model_path")
        if (original.source != "primary" or secondary.source != "verifier"
                or not isinstance(model_path, str) or Path(model_path).name != verifier_model
                or model_path == original.metadata.get("model_path")):
            raise PrimaryRecoveryError(f"{original.id}: independent verifier provenance missing")
        start, end = _frame(original.start), _frame(original.end)
        if (_frame(secondary.start), _frame(secondary.end)) != (start, end):
            raise PrimaryRecoveryError(f"{original.id}: verifier core differs from original frames")
        secondary_health = primary_decode_health(secondary.metadata, truncated=secondary.truncated)
        if secondary_health["failed"]:
            raise PrimaryRecoveryError(f"{original.id}: verifier decode also failed")
        direct = _tokens(secondary.tokens)
        resumed = _tokens(secondary.metadata.get("resumed_tokens", []))
        if direct and resumed and direct != resumed:
            raise PrimaryRecoveryError(f"{original.id}: contradictory verifier token sources")
        owned = direct or resumed
        if (not owned or not isinstance(secondary.text, str) or not secondary.text.strip()
                or "".join(t["token"] for t in owned) != secondary.text):
            raise PrimaryRecoveryError(f"{original.id}: nonempty exact token reconstruction required")
        previous = original.start
        for token in owned:
            # Match Sherpa's ownership: only the final source core includes its end.
            within_end = (token["timestamp"] <= original.end if index == len(primary) - 1
                          else token["timestamp"] < original.end)
            if token["timestamp"] < original.start or not within_end or token["timestamp"] < previous:
                raise PrimaryRecoveryError(f"{original.id}: token time outside core or out of order")
            previous = token["timestamp"]
        decisions.append({
            "policy_version": PRIMARY_RECOVERY_POLICY, "parent_id": original.id, "parent_index": index,
            "core_start_frame": start, "core_end_frame": end, "sample_rate": SAMPLE_RATE,
            "original_primary_text": original.text, "original_decode_health": original_health,
            "original_primary_selectable": False,
            "mode": "same_core_verifier_fallback", "selected_source": "verifier",
            "selected_model": verifier_model, "selected_model_path": model_path,
            "selected_text": secondary.text, "secondary_decode_health": secondary_health,
            "token_ownership": owned, "token_clock": "absolute_full_audio_seconds",
            "review_required": True, "consensus": False, "independent_sources_used": 1,
            "accuracy_verified": False, "acoustic_extent_verified": False,
        })
    return decisions


def recovery_segment(decision: Mapping[str, Any]) -> ReconciledSegment:
    from ..alignment.reconcile import reconcile_text

    # Retain measured text disagreement, but never use its rewritten choice or
    # count the secondary twice as consensus. This branch selects one source.
    _, audit = reconcile_text(decision["original_primary_text"], decision["selected_text"])
    audit = replace(audit, low_confidence=True, conflict_candidate=True,
                    reasons=(*audit.reasons, "primary_decode_failed", "same_core_secondary_fallback",
                             "recovery_requires_review"), corrections=())
    return ReconciledSegment(
        start_ms=round(decision["core_start_frame"] / SAMPLE_RATE * 1000),
        end_ms=round(decision["core_end_frame"] / SAMPLE_RATE * 1000),
        primary_text=decision["original_primary_text"], verifier_text=decision["selected_text"],
        text=decision["selected_text"], confidence=None, audit=audit,
        ensemble_audit={"policy_version": PRIMARY_RECOVERY_POLICY,
                        "method": "same_core_verifier_fallback", "choice": "verifier_recovery",
                        "requires_local_arbiter": False, "consensus": False,
                        "independent_sources_used": 1, "accuracy_verified": False,
                        "candidates": [{"id": "verifier_recovery", "text": decision["selected_text"],
                                        "supported_by": ["verifier"], "kind": "single_source_fallback"}],
                        "raw_hypotheses": {"qwen": {"text": decision["original_primary_text"],
                                                     "selectable": False, "reason": "known_decode_failure"}},
                        "primary_recovery": deepcopy(dict(decision))},
    )
