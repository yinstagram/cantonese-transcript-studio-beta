"""Gold-free planning for one final leading-edge Qwen timing trial."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from ..alignment.forced_timestamps import WordTimestamp
from .acoustic_witness import DualTokenAnchor, WitnessSegment
from .bracketed_realign import (
    MAX_TOTAL_WINDOW_MS,
    MAX_WINDOW_MS,
    MAX_WITNESS_DISAGREEMENT_MS,
    WINDOW_LEFT_MARGIN_MS,
    WINDOW_RIGHT_MARGIN_MS,
)


LEADING_EDGE_REALIGN_POLICY_VERSION = (
    "dual-witness-leading-edge-one-sided-qwen-realign-v1-final-trial"
)


@dataclass(frozen=True)
class LeadingEdgeSuspect:
    source_start: int
    source_end: int
    baseline_start_ms: int
    first_witness_start_ms: int
    second_witness_start_ms: int


@dataclass(frozen=True)
class LeadingEdgeIslandPlan:
    segment_index: int
    projected_source_start: int
    projected_source_end: int
    suspect_source_start: int
    suspect_source_end: int
    right_guard_source_start: int
    right_guard_source_end: int
    right_guard_first_start_ms: int
    right_guard_second_start_ms: int
    right_guard_baseline_start_ms: int
    right_guard_baseline_end_ms: int
    retained_previous_source_start: int | None
    retained_previous_source_end: int | None
    retained_previous_end_ms: int | None
    window_start_ms: int
    window_end_ms: int
    suspects: tuple[LeadingEdgeSuspect, ...]
    baseline_minimum_witness_disagreement_ms: int

    @property
    def window_duration_ms(self) -> int:
        return self.window_end_ms - self.window_start_ms


@dataclass(frozen=True)
class LeadingEdgePlanTelemetry:
    raw_dual_anchor_count: int
    raw_suspect_anchor_count: int
    segment_leading_suspect_count: int
    contiguous_leading_suspect_run_count: int
    stable_immediate_right_guard_count: int
    eligible_one_sided_island_count: int
    distinct_eligible_segment_count: int
    selected_suspect_start_count: int
    total_planned_audio_ms: int
    rejection_counts: Mapping[str, int]


@dataclass(frozen=True)
class LeadingEdgePlanResult:
    islands: tuple[LeadingEdgeIslandPlan, ...]
    telemetry: LeadingEdgePlanTelemetry


def _literal_occurrence_count(haystack: str, needle: str) -> int:
    if not needle:
        return 0
    count = 0
    offset = 0
    while True:
        found = haystack.find(needle, offset)
        if found < 0:
            return count
        count += 1
        offset = found + 1


def _is_suspect(word: WordTimestamp, anchor: DualTokenAnchor) -> bool:
    return (
        abs(word.start_ms - anchor.first_start_ms)
        > MAX_WITNESS_DISAGREEMENT_MS
        and abs(word.start_ms - anchor.second_start_ms)
        > MAX_WITNESS_DISAGREEMENT_MS
    )


def _is_stable(word: WordTimestamp, anchor: DualTokenAnchor) -> bool:
    return (
        abs(word.start_ms - anchor.first_start_ms)
        <= MAX_WITNESS_DISAGREEMENT_MS
        and abs(word.start_ms - anchor.second_start_ms)
        <= MAX_WITNESS_DISAGREEMENT_MS
    )


def plan_leading_edge_realign_islands(
    source_text: str,
    segments: Sequence[WitnessSegment],
    baseline_words: Sequence[WordTimestamp],
    dual_anchors: Sequence[DualTokenAnchor],
    *,
    maximum_total_window_ms: int = MAX_TOTAL_WINDOW_MS,
) -> LeadingEdgePlanResult:
    """Plan one one-sided leading-edge island per reconciled segment.

    Witness starts may bound the audio search window but are never candidate
    output timestamps.  The planner never reads reference/gold boundaries.
    """

    if not source_text:
        raise ValueError("source_text must not be empty")
    if not 0 < maximum_total_window_ms <= MAX_TOTAL_WINDOW_MS:
        raise ValueError("maximum_total_window_ms is invalid")

    baseline_by_key: dict[tuple[int, int, str], WordTimestamp] = {}
    for word in baseline_words:
        key = (word.source_start, word.source_end, word.text)
        if key in baseline_by_key:
            raise ValueError("baseline word source spans must be unique")
        if source_text[word.source_start : word.source_end] != word.text:
            raise ValueError("baseline word differs from immutable transcript")
        baseline_by_key[key] = word
    baseline_index_by_key = {
        (word.source_start, word.source_end, word.text): index
        for index, word in enumerate(baseline_words)
    }
    anchor_by_key: dict[tuple[int, int, str], DualTokenAnchor] = {}
    for anchor in dual_anchors:
        key = (anchor.source_start, anchor.source_end, anchor.text)
        if key in anchor_by_key:
            raise ValueError("dual anchor source spans must be unique")
        if source_text[anchor.source_start : anchor.source_end] != anchor.text:
            raise ValueError("dual anchor differs from immutable transcript")
        anchor_by_key[key] = anchor

    raw_suspects = sum(
        _is_suspect(baseline_by_key[key], anchor)
        for key, anchor in anchor_by_key.items()
        if key in baseline_by_key
    )
    rejection_keys = (
        "first_word_has_no_dual_anchor",
        "first_word_is_not_suspect",
        "missing_immediate_stable_right_guard",
        "ambiguous_projected_text",
        "window_exceeds_8_seconds",
        "unsafe_baseline_stitch",
        "total_audio_cap",
    )
    rejections = {key: 0 for key in rejection_keys}
    candidates: list[LeadingEdgeIslandPlan] = []
    segment_leading_suspects = 0
    leading_runs = 0
    stable_guards = 0

    for segment in segments:
        words = [
            word
            for word in baseline_words
            if segment.source_start <= word.source_start
            and word.source_end <= segment.source_end
        ]
        if not words:
            rejections["first_word_has_no_dual_anchor"] += 1
            continue
        first = words[0]
        first_key = (first.source_start, first.source_end, first.text)
        first_anchor = anchor_by_key.get(first_key)
        if first_anchor is None or first_anchor.segment_index != segment.index:
            rejections["first_word_has_no_dual_anchor"] += 1
            continue
        if not _is_suspect(first, first_anchor):
            rejections["first_word_is_not_suspect"] += 1
            continue
        segment_leading_suspects += 1

        suspect_pairs: list[tuple[WordTimestamp, DualTokenAnchor]] = []
        guard_pair: tuple[WordTimestamp, DualTokenAnchor] | None = None
        for word in words:
            key = (word.source_start, word.source_end, word.text)
            anchor = anchor_by_key.get(key)
            if anchor is not None and anchor.segment_index == segment.index and _is_suspect(word, anchor):
                suspect_pairs.append((word, anchor))
                continue
            if anchor is not None and anchor.segment_index == segment.index and _is_stable(word, anchor):
                guard_pair = (word, anchor)
            break
        leading_runs += 1
        if guard_pair is None:
            rejections["missing_immediate_stable_right_guard"] += 1
            continue
        stable_guards += 1
        guard_word, guard_anchor = guard_pair
        projected_start = suspect_pairs[0][0].source_start
        projected_end = guard_word.source_end
        projected_text = source_text[projected_start:projected_end]
        segment_text = source_text[segment.source_start : segment.source_end]
        if _literal_occurrence_count(segment_text, projected_text) != 1:
            rejections["ambiguous_projected_text"] += 1
            continue
        first_suspect_anchor = suspect_pairs[0][1]
        window_start = max(
            segment.start_ms,
            min(
                first_suspect_anchor.first_start_ms,
                first_suspect_anchor.second_start_ms,
            )
            - WINDOW_LEFT_MARGIN_MS,
        )
        window_end = min(
            segment.end_ms,
            max(
                guard_anchor.first_start_ms,
                guard_anchor.second_start_ms,
            )
            + WINDOW_RIGHT_MARGIN_MS,
        )
        if not 0 < window_end - window_start <= MAX_WINDOW_MS:
            rejections["window_exceeds_8_seconds"] += 1
            continue
        global_first_index = baseline_index_by_key[first_key]
        retained_previous = (
            baseline_words[global_first_index - 1] if global_first_index else None
        )
        if (
            retained_previous is not None
            and retained_previous.end_ms > first.start_ms
        ) or suspect_pairs[-1][0].end_ms > guard_word.start_ms:
            rejections["unsafe_baseline_stitch"] += 1
            continue
        suspects = tuple(
            LeadingEdgeSuspect(
                source_start=word.source_start,
                source_end=word.source_end,
                baseline_start_ms=word.start_ms,
                first_witness_start_ms=anchor.first_start_ms,
                second_witness_start_ms=anchor.second_start_ms,
            )
            for word, anchor in suspect_pairs
        )
        candidates.append(
            LeadingEdgeIslandPlan(
                segment_index=segment.index,
                projected_source_start=projected_start,
                projected_source_end=projected_end,
                suspect_source_start=suspect_pairs[0][0].source_start,
                suspect_source_end=suspect_pairs[-1][0].source_end,
                right_guard_source_start=guard_word.source_start,
                right_guard_source_end=guard_word.source_end,
                right_guard_first_start_ms=guard_anchor.first_start_ms,
                right_guard_second_start_ms=guard_anchor.second_start_ms,
                right_guard_baseline_start_ms=guard_word.start_ms,
                right_guard_baseline_end_ms=guard_word.end_ms,
                retained_previous_source_start=(
                    retained_previous.source_start if retained_previous else None
                ),
                retained_previous_source_end=(
                    retained_previous.source_end if retained_previous else None
                ),
                retained_previous_end_ms=(
                    retained_previous.end_ms if retained_previous else None
                ),
                window_start_ms=window_start,
                window_end_ms=window_end,
                suspects=suspects,
                baseline_minimum_witness_disagreement_ms=max(
                    min(
                        abs(item.baseline_start_ms - item.first_witness_start_ms),
                        abs(item.baseline_start_ms - item.second_witness_start_ms),
                    )
                    for item in suspects
                ),
            )
        )

    candidates.sort(
        key=lambda item: (
            -item.baseline_minimum_witness_disagreement_ms,
            item.projected_source_start,
        )
    )
    selected: list[LeadingEdgeIslandPlan] = []
    total_duration = 0
    for candidate in candidates:
        if total_duration + candidate.window_duration_ms > maximum_total_window_ms:
            rejections["total_audio_cap"] += 1
            continue
        selected.append(candidate)
        total_duration += candidate.window_duration_ms
    islands = tuple(
        sorted(selected, key=lambda item: (item.segment_index, item.projected_source_start))
    )
    telemetry = LeadingEdgePlanTelemetry(
        raw_dual_anchor_count=len(dual_anchors),
        raw_suspect_anchor_count=raw_suspects,
        segment_leading_suspect_count=segment_leading_suspects,
        contiguous_leading_suspect_run_count=leading_runs,
        stable_immediate_right_guard_count=stable_guards,
        eligible_one_sided_island_count=len(islands),
        distinct_eligible_segment_count=len({item.segment_index for item in islands}),
        selected_suspect_start_count=sum(len(item.suspects) for item in islands),
        total_planned_audio_ms=total_duration,
        rejection_counts=rejections,
    )
    return LeadingEdgePlanResult(islands=islands, telemetry=telemetry)


__all__ = [
    "LEADING_EDGE_REALIGN_POLICY_VERSION",
    "LeadingEdgeIslandPlan",
    "LeadingEdgePlanResult",
    "LeadingEdgePlanTelemetry",
    "LeadingEdgeSuspect",
    "plan_leading_edge_realign_islands",
]
