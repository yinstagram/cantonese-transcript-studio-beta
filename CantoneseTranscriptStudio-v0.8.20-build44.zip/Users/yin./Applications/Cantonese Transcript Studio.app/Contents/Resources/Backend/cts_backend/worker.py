"""Persistent stdin/stdout JSONL worker. Stdout is protocol-only."""

from __future__ import annotations

import argparse
import base64
import binascii
import fcntl
import hashlib
import hmac
import importlib.util
import json
import logging
import os
import queue
import signal
import shutil
import sys
import threading
import time
import traceback
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence, TextIO


# ``python -m cts_backend.worker --health-check`` is also the signed-app
# installation probe.  Importing the complete transcription pipeline first can
# fault hundreds of Python/model-support files from an external volume even
# though the probe never uses them.  Keep this method manifest next to the
# worker entry point and use it for a bounded, dependency-light preflight.
# ``Worker._register_methods`` asserts that the live dispatcher stays in sync.
WORKER_METHOD_NAMES = (
    "corrections.clear",
    "corrections.delete",
    "corrections.export",
    "corrections.import",
    "corrections.list",
    "corrections.remember",
    "corrections.remember_edit",
    "history.clear_completed",
    "insights.cancel",
    "insights.explain",
    "insights.generate",
    "insights.get",
    "jobs.cancel",
    "jobs.create",
    "jobs.get",
    "jobs.list",
    "jobs.retry",
    "jobs.start",
    "live.assistant.cancel",
    "live.cancel",
    "live.interview.command",
    "live.poll",
    "live.push",
    "live.speaker_enroll.cancel",
    "live.speaker_enroll.push",
    "live.speaker_enroll.start",
    "live.speaker_enroll.stop",
    "live.start",
    "live.status",
    "live.stop",
    "models.delete",
    "models.download",
    "models.status",
    "models.verify",
    "settings.get",
    "settings.update",
    "subtitle.preview.cancel",
    "subtitle.preview.prepare",
    "subtitle.preview.status",
    "subtitle.project.auto_segment",
    "subtitle.project.export",
    "subtitle.project.get",
    "subtitle.project.update",
    "subtitle.render.cancel",
    "subtitle.render.start",
    "subtitle.render.status",
    "subtitle.timing_attention.cancel",
    "subtitle.timing_attention.scan",
    "subtitle.timing_attention.status",
    "system.health",
    "translations.cancel",
    "translations.export",
    "translations.generate",
    "translations.list",
    "translations.update",
    "youtube.capabilities",
    "youtube.import.cancel",
    "youtube.import.list",
    "youtube.import.retry",
    "youtube.import.start",
    "youtube.import.status",
)


def _fast_health_check() -> int:
    """Print the CLI installation health contract without heavy ASR imports.

    This path intentionally reports only cheap, process-independent facts.  A
    running worker's ``system.health`` RPC remains the authoritative live
    health check and uses the instantiated services.
    """

    root = (
        Path.home()
        / "Library"
        / "Application Support"
        / "Cantonese Transcript Studio"
    )
    paths = {
        "root": root,
        "models": root / "Models",
        "jobs": root / "Jobs",
        "runtime": root / "Runtime",
        "logs": root / "Logs",
    }
    for directory in paths.values():
        directory.mkdir(parents=True, exist_ok=True)

    settings_path = root / "settings.json"
    local_api_enabled = False
    local_api_port = 8765
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        if isinstance(settings, dict):
            local_api_enabled = settings.get("local_api_enabled") is True
            candidate_port = settings.get("local_api_port")
            if (
                isinstance(candidate_port, int)
                and not isinstance(candidate_port, bool)
                and 1024 <= candidate_port <= 65535
            ):
                local_api_port = candidate_port
    except (OSError, json.JSONDecodeError):
        # Missing settings are valid on first launch.  Invalid settings will be
        # surfaced by the live worker instead of making this preflight hang.
        pass

    youtube_root = paths["runtime"] / "youtube"
    deno = youtube_root / "deno"
    ffmpeg = youtube_root / "ffmpeg"
    if not ffmpeg.is_file():
        ffmpeg = Path("/opt/homebrew/bin/ffmpeg")
    try:
        yt_dlp_available = importlib.util.find_spec("yt_dlp") is not None
    except (ImportError, ValueError):
        yt_dlp_available = False
    youtube_available = (
        yt_dlp_available
        and deno.is_file()
        and os.access(deno, os.X_OK)
        and ffmpeg.is_file()
        and os.access(ffmpeg, os.X_OK)
    )

    whisper_candidates = [
        Path(os.environ["CTS_WHISPER_CLI"]).expanduser()
        if os.environ.get("CTS_WHISPER_CLI")
        else None,
        Path(found) if (found := shutil.which("whisper-cli")) else None,
        Path("/opt/homebrew/bin/whisper-cli"),
        Path("/usr/local/bin/whisper-cli"),
    ]
    whisper_cli = next(
        (
            candidate.resolve()
            for candidate in whisper_candidates
            if candidate is not None
            and candidate.is_file()
            and os.access(candidate, os.X_OK)
        ),
        None,
    )
    whisper_server_candidates = [
        Path(os.environ["CTS_WHISPER_SERVER"]).expanduser()
        if os.environ.get("CTS_WHISPER_SERVER")
        else None,
        Path(found) if (found := shutil.which("whisper-server")) else None,
        Path("/opt/homebrew/bin/whisper-server"),
        Path("/usr/local/bin/whisper-server"),
    ]
    whisper_server = next(
        (
            candidate.resolve()
            for candidate in whisper_server_candidates
            if candidate is not None
            and candidate.is_file()
            and os.access(candidate, os.X_OK)
        ),
        None,
    )

    youtube = {
        "available": youtube_available,
        "user_initiated_network_only": True,
        "normal_transcription_network": False,
        "platforms": [
            "youtube",
            "instagram",
            "threads",
            "x",
            "tiktok",
            "facebook",
            "reddit",
            "bilibili",
        ],
        # Keep the standalone ``system.health`` probe aligned with the live
        # YouTubeImportService capability. Threads media is resolved by our
        # bounded public-page adapter, not by an upstream yt-dlp extractor.
        "threads_support": "public_page_adapter",
        "modes": ["video", "audio", "subtitles", "all"],
        "playlist_policies": ["expand", "reject"],
        "caption_preferences": [
            "manual_then_auto",
            "manual_only",
            "auto_only",
            "auto_then_manual",
        ],
        "runtime": {
            "yt_dlp": yt_dlp_available,
            "deno": deno.is_file(),
            "ffmpeg": ffmpeg.is_file(),
            "python_path": sys.executable,
            "deno_path": str(deno.resolve(strict=False)),
            "ffmpeg_path": str(ffmpeg.resolve(strict=False)),
        },
    }
    live_small_model = paths["models"] / "Whisper-Small" / "ggml-small.bin"
    live_final_model = paths["models"] / "Whisper-Large-v3" / "ggml-large-v3.bin"
    live_speaker_model = (
        paths["models"]
        / "3dspeaker_speech_campplus_sv_zh-cn_16k-common"
        / "3dspeaker_speech_campplus_sv_zh-cn_16k-common.onnx"
    )
    live_asr_available = (
        whisper_server is not None
        and live_small_model.is_file()
        and live_final_model.is_file()
    )
    live_speaker_available = live_speaker_model.is_file()
    payload = {
        "ok": True,
        "protocol": 1,
        "paths": {name: str(path) for name, path in paths.items()},
        "methods": WORKER_METHOD_NAMES,
        "normal_transcription_network": False,
        "user_initiated_youtube_network": True,
        "youtube": youtube,
        "live_caption": {
            "available": live_asr_available,
            "offline": True,
            "sample_rate": 16_000,
            "format": "pcm_s16le_mono",
            "maximum_frame_ms": 200,
            "partial_model": "whisper.cpp/small",
            "final_model": "whisper.cpp/large-v3",
            "speaker_tracking_available": live_speaker_available,
            "speaker_tracking_model": (
                "3dspeaker_speech_campplus_sv_zh-cn_16k-common"
                if live_speaker_available
                else None
            ),
        },
        "runtimes": {
            "whisper_cpp": {
                "available": whisper_cli is not None and whisper_server is not None,
                "path": str(whisper_cli) if whisper_cli is not None else None,
                "server_path": str(whisper_server) if whisper_server is not None else None,
            }
        },
        "local_api": {
            "enabled": local_api_enabled,
            "host": "127.0.0.1",
            "port": local_api_port,
            "base_url": f"http://127.0.0.1:{local_api_port}/v1",
            "status_path": str(root / "local-api.json"),
            "token_header": "X-CTS-Token",
        },
    }
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()
    return 0


# Run the installation probe before importing the model pipeline.  Restrict
# this shortcut to the exact public CLI form so regular imports and argparse's
# validation retain their normal behaviour.
if __name__ == "__main__" and sys.argv[1:] == ["--health-check"]:
    raise SystemExit(_fast_health_check())

from .api.dispatcher import Dispatcher, MethodNotFound
from .api.jobs import DUPLICATE_MEDIA_UI_MESSAGE, present_job
from .api.local_server import LocalAPIServer, new_token
from .api.protocol import ProtocolError, error_message, event_message, parse_request, result_message
from .alignment import LMStudioLifecycle
from .asr import WhisperCPPError, resolve_whisper_cli
from .asr.types import ASRCancelled
from .live_caption.engine import LocalEngineError, resolve_whisper_server
from .correction_memory import (
    AUTOMATIC_APPLICATION_POLICY,
    CORRECTION_MEMORY_SCHEMA_VERSION,
    CorrectionMemoryStore,
    apply_approved_corrections,
)
from .insights import (
    BilingualTranslation,
    INSIGHTS_POLICY_VERSION,
    ConceptExplainRequest,
    ConceptExplainResult,
    DerivedArtifactStore,
    TranscriptInsightInput,
    TranscriptInsightsClient,
    TranslatedCue,
    TranslationClient,
    build_deterministic_insights,
)
from .evaluation.timing_attention import (
    TIMING_ATTENTION_SCHEMA,
    TimingAttentionScanner,
    load_timing_attention_result,
    prepare_timing_attention_result,
    publish_timing_attention_result,
    timing_attention_cue_word_capacities,
)
from .models import (
    ModelManager,
    QWEN_FALLBACK_ID,
    QWEN_PRIMARY_ID,
    SENSEVOICE_YUE_MODEL_NAME,
    SHERPA_MODEL_NAME,
    SPEAKER_EMBEDDING_FILENAME,
    SPEAKER_EMBEDDING_ID,
    WHISPER_LARGE_V3_FILENAME,
    WHISPER_LARGE_V3_ID,
    WHISPER_SMALL_FILENAME,
    WHISPER_SMALL_ID,
)
from .pipeline import PipelineCancelled, PipelineInterrupted, TranscriptionPipeline
from .settings import AppPaths, SettingsStore, _atomic_json
from .subtitles import PreviewProxy, SubtitleProjectStore, SubtitleRenderer, generate_ass
from .subtitles.preview import PreviewCancelled
from .subtitles.project_exports import EXPORT_FORMATS, export_project_revision
from .subtitles.bilingual_exports import (
    BILINGUAL_EXPORT_FORMATS,
    BILINGUAL_EXPORT_LAYOUTS,
    export_bilingual_revision,
    resolve_translated_project,
    translation_result_sha256,
)
from .subtitles.render import RenderCancelled, resolve_subtitle_ffmpeg, resolve_subtitle_ffprobe
from .youtube.commands import YtDlpRuntimePaths
from .youtube.service import CommandExecutor, YouTubeImportService

logger = logging.getLogger(__name__)

HOMEBREW_FFMPEG = Path("/opt/homebrew/bin/ffmpeg")
HOMEBREW_FFPROBE = Path("/opt/homebrew/bin/ffprobe")


@dataclass(frozen=True)
class _LiveProjectSession:
    """Validated project metadata retained only while one live session runs.

    The opaque ``tracker_snapshot`` was decrypted by Swift before it crossed
    stdin.  This worker never owns a Keychain key, an encrypted profile file,
    or any disk persistence for voice embeddings.
    """

    project_id: str
    expected_speaker_count: int | None
    tracker_snapshot: dict[str, Any] | None
    embedding_model_sha256: str | None = None


@dataclass(frozen=True)
class _LiveStartOptions:
    """Validated text-only or enrolled-project live run settings."""

    project: _LiveProjectSession | None
    expected_speaker_count: int | None
    # This is a validated, session-only LiveAssistantConfig object.  Keep the
    # annotation import-light because ``--health-check`` intentionally exits
    # before the full live-caption stack is imported.
    assistant_config: Any
    # Retention is deliberately independent from the optional LLM/Interview
    # configuration: ordinary captions can request a local timing receipt too.
    timing_archive_enabled: bool


@dataclass
class _LiveSpeakerEnrollmentSession:
    """RAM-only explicit voice enrollment owned by the Python worker."""

    session_id: str
    project: _LiveProjectSession
    target_slot: int
    tracker: Any
    embedding_model_sha256: str
    buffer: bytearray
    recommended_seconds: float = 10.0
    minimum_speech_seconds: float = 6.0
    maximum_seconds: float = 15.0


def acquire_worker_lock(paths: AppPaths) -> TextIO:
    """Hold a process-wide lock so two workers cannot mutate one job store."""
    handle = (paths.root / "worker.lock").open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        handle.close()
        raise
    return handle


def _jsonable(value: Any) -> Any:
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return value.to_dict()
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if hasattr(value, "value"):
        return value.value
    return value


def _safe_lifecycle_event(value: Any, *, phase: str) -> dict[str, str]:
    """Keep model lifecycle provenance without leaking command output or text."""

    event: dict[str, str] = {"phase": phase, "status": "unknown"}
    if not isinstance(value, Mapping):
        return event
    for key in ("status", "model", "api_model", "reason"):
        candidate = value.get(key)
        if isinstance(candidate, str) and candidate:
            event[key] = candidate[:512]
    return event


def _validated_partial_translation_seed(
    value: object,
    project_cues: Sequence[Mapping[str, Any]],
    *,
    target_language: str,
    api_model: str,
) -> tuple[TranslatedCue, ...] | None:
    """Return a sealed partial result only when it exactly matches the project."""

    if not isinstance(value, Mapping):
        return None
    if (
        value.get("schema") != 1
        or value.get("status") != "partial"
        or value.get("source_language") != "yue-Hant-HK"
        or value.get("target_language") != target_language
        or value.get("model") != api_model
        or value.get("policy_version") != INSIGHTS_POLICY_VERSION
    ):
        return None
    raw_cues = value.get("cues")
    raw_failed = value.get("failed_ids")
    if not isinstance(raw_cues, list) or not isinstance(raw_failed, list):
        return None

    expected_by_id = {
        str(cue.get("id")): cue
        for cue in project_cues
        if isinstance(cue.get("id"), str)
    }
    expected_ids = [str(cue.get("id")) for cue in project_cues]
    if len(expected_by_id) != len(project_cues):
        return None
    if any(not isinstance(item, str) for item in raw_failed):
        return None
    failed_ids = tuple(raw_failed)
    if len(set(failed_ids)) != len(failed_ids) or any(item not in expected_by_id for item in failed_ids):
        return None

    translated: list[TranslatedCue] = []
    translated_ids: list[str] = []
    for raw in raw_cues:
        if not isinstance(raw, Mapping) or set(raw) != {
            "id",
            "start",
            "end",
            "source_text",
            "translated_text",
        }:
            return None
        cue_id = raw.get("id")
        expected = expected_by_id.get(str(cue_id))
        translated_text = raw.get("translated_text")
        if (
            not isinstance(cue_id, str)
            or expected is None
            or not isinstance(translated_text, str)
            or not translated_text.strip()
            or raw.get("source_text") != expected.get("text")
        ):
            return None
        try:
            start = float(raw.get("start"))
            end = float(raw.get("end"))
            expected_start = float(expected.get("start"))
            expected_end = float(expected.get("end"))
        except (TypeError, ValueError):
            return None
        if abs(start - expected_start) > 0.0005 or abs(end - expected_end) > 0.0005:
            return None
        translated_ids.append(cue_id)
        translated.append(
            TranslatedCue(
                id=cue_id,
                start=expected_start,
                end=expected_end,
                source_text=str(expected.get("text")),
                translated_text=translated_text,
            )
        )

    if len(set(translated_ids)) != len(translated_ids):
        return None
    completed_set = set(translated_ids)
    failed_set = set(failed_ids)
    if completed_set & failed_set or completed_set | failed_set != set(expected_ids):
        return None
    expected_completed_order = [item for item in expected_ids if item in completed_set]
    if translated_ids != expected_completed_order:
        return None
    return tuple(translated)


class _FileJobStore:
    """Minimal fallback store; a full jobs module can be injected transparently."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _path(self, job_id: str) -> Path:
        return self.root / job_id / "job.json"

    def create(self, **params: Any) -> dict[str, Any]:
        job_id = str(params.pop("id", "") or uuid.uuid4())
        if "/" in job_id or job_id in (".", ".."):
            raise ValueError("job id 無效")
        job = {"id": job_id, "status": "queued", "progress": 0.0, **params}
        _atomic_json(self._path(job_id), job)
        return job

    def get(self, job_id: str) -> dict[str, Any]:
        path = self._path(job_id)
        if not path.is_file():
            raise KeyError(f"搵唔到工作：{job_id}")
        return json.loads(path.read_text(encoding="utf-8"))

    def list(self) -> list[dict[str, Any]]:
        output = []
        for path in sorted(self.root.glob("*/job.json")):
            try:
                output.append(json.loads(path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError):
                logger.exception("Invalid job file: %s", path)
        return output

    def update(self, job_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            job = self.get(job_id)
            job.update(fields)
            _atomic_json(self._path(job_id), job)
            return job

    def cancel(
        self,
        job_id: str,
        *,
        expected_attempt_generation: int | None = None,
    ) -> dict[str, Any]:
        del expected_attempt_generation
        return self.update(job_id, cancel_requested=True)

    def retry(self, job_id: str) -> dict[str, Any]:
        return self.update(job_id, status="queued", progress=0.0, cancel_requested=False, error=None)

    def clear_completed(self) -> dict[str, Any]:
        moved = []
        from .models import move_to_trash

        for job in self.list():
            if job.get("status") == "completed":
                destination = move_to_trash(self._path(job["id"]).parent)
                if destination:
                    moved.append(str(destination))
        return {"moved_to_trash": moved}

    def recover_startup(self) -> list[str]:
        recovered = []
        for job in self.list():
            if job.get("status") in {"running", "queued"}:
                self.update(job["id"], status="queued", recovered=True)
                recovered.append(job["id"])
        return recovered


def _call(store: Any, names: tuple[str, ...], *args: Any, **kwargs: Any) -> Any:
    for name in names:
        method = getattr(store, name, None)
        if callable(method):
            return method(*args, **kwargs)
    raise AttributeError(f"job store 缺少 method：{'/'.join(names)}")


class _AttemptBoundJobStore:
    """Pass a runner's durable ownership token through pipeline store writes."""

    def __init__(self, store: Any, attempt_generation: int) -> None:
        self._store = store
        self._attempt_generation = attempt_generation

    def __getattr__(self, name: str) -> Any:
        return getattr(self._store, name)

    def get(self, job_id: str) -> Any:
        record = _call(self._store, ("get", "get_job"), job_id)
        generation = getattr(record, "attempt_generation", None)
        if generation is not None and int(generation) != self._attempt_generation:
            from .jobs import JobAttemptOwnershipLost

            raise JobAttemptOwnershipLost(
                f"stale attempt for {job_id}: expected {self._attempt_generation}, "
                f"got {generation}"
            )
        return record

    def transition(self, job_id: str, state: Any, **kwargs: Any) -> Any:
        return self._store.transition(
            job_id,
            state,
            expected_attempt_generation=self._attempt_generation,
            **kwargs,
        )

    def update_progress(self, job_id: str, progress: float, **kwargs: Any) -> Any:
        return self._store.update_progress(
            job_id,
            progress,
            expected_attempt_generation=self._attempt_generation,
            **kwargs,
        )

    def checkpoint(self, job_id: str, name: str, **kwargs: Any) -> Any:
        return self._store.checkpoint(
            job_id,
            name,
            expected_attempt_generation=self._attempt_generation,
            **kwargs,
        )


class Worker:
    def __init__(
        self,
        *,
        paths: AppPaths | None = None,
        settings_store: SettingsStore | None = None,
        model_manager: ModelManager | None = None,
        job_store: Any | None = None,
        pipeline_factory: Any = TranscriptionPipeline,
        stdout: TextIO | None = None,
        stderr: TextIO | None = None,
        recover: bool = True,
        start_runner: bool = True,
        start_youtube_runner: bool | None = None,
        enable_local_api: bool = True,
        youtube_executor: CommandExecutor | None = None,
        youtube_runtime: YtDlpRuntimePaths | None = None,
        live_engine_factory: Callable[[Path], Any] | None = None,
        live_speaker_factory: Callable[[Path], Any] | None = None,
        live_assistant_factory: Callable[[Any], Any] | None = None,
        live_interview_factory: Callable[[Any, bool], Any] | None = None,
        live_assistant_runtime_factory: Callable[[Any], Any] | None = None,
        derived_lifecycle_factory: Callable[..., Any] | None = None,
        insights_client_factory: Callable[..., Any] | None = None,
        translation_client_factory: Callable[..., Any] | None = None,
        timing_attention_scanner: Any | None = None,
    ) -> None:
        self.paths = (paths or AppPaths.default()).ensure()
        self.settings_store = settings_store or SettingsStore(self.paths)
        self._correction_memory = CorrectionMemoryStore(self.paths)
        self.models = model_manager or ModelManager(self.paths)
        if job_store is not None:
            self.jobs = job_store
        else:
            try:
                from .jobs import JobStore

                self.jobs = JobStore(self.paths.jobs)
            except ImportError:
                self.jobs = _FileJobStore(self.paths.jobs)
        self.pipeline_factory = pipeline_factory
        self.stdout = stdout or sys.stdout
        self.stderr = stderr or sys.stderr
        self._write_lock = threading.Lock()
        self._output_disconnected = False
        self._heavy_work_lock = threading.Lock()
        self._live_lock = threading.RLock()
        self._live_engine_factory = live_engine_factory
        self._live_speaker_factory = live_speaker_factory
        self._live_assistant_factory = live_assistant_factory
        self._live_interview_factory = live_interview_factory
        self._live_assistant_runtime_factory = live_assistant_runtime_factory
        self._derived_lifecycle_factory = derived_lifecycle_factory or LMStudioLifecycle
        self._insights_client_factory = insights_client_factory or TranscriptInsightsClient
        self._translation_client_factory = translation_client_factory or TranslationClient
        self._live_worker: Any | None = None
        self._live_assistant: Any | None = None
        self._live_assistant_runtime: Any | None = None
        self._live_session_id: str | None = None
        self._live_project_session: _LiveProjectSession | None = None
        self._live_heavy_lock_owned = False
        self._live_speaker_tracking_available = False
        self._live_speaker_tracking_error: str | None = None
        self._live_asr_mode = "dual_whisper"
        self._live_correction_entries: tuple[Any, ...] = ()
        self._live_hk_normalizer: Any | None = None
        self._live_speaker_enrollment: _LiveSpeakerEnrollmentSession | None = None
        self._live_speaker_enrollment_heavy_lock_owned = False
        self._job_queue: queue.Queue[str | None] = queue.Queue()
        self._job_queue_lock = threading.RLock()
        self._job_queue_members: set[str] = set()
        self._job_queue_attempts: dict[str, int] = {}
        self._job_running: set[str] = set()
        self._job_running_attempts: dict[str, int] = {}
        self._job_requeue_after_run: set[str] = set()
        self._cancel: dict[str, threading.Event] = {}
        self._cancel_attempts: dict[str, int] = {}
        self._subtitle_projects = SubtitleProjectStore(self.paths.jobs)
        self._subtitle_renderer = SubtitleRenderer()
        self._subtitle_render_queue: queue.Queue[tuple[str, str] | None] = queue.Queue()
        self._subtitle_render_cancel: dict[str, threading.Event] = {}
        self._subtitle_previews = PreviewProxy()
        self._subtitle_preview_queue: queue.Queue[tuple[str, str] | None] = queue.Queue()
        self._subtitle_preview_cancel: dict[str, threading.Event] = {}
        self._subtitle_project_revisions: dict[str, int] = {}
        self._timing_attention_scanner = timing_attention_scanner or TimingAttentionScanner()
        self._timing_attention_queue: queue.Queue[tuple[str, int, str] | None] = queue.Queue()
        self._timing_attention_cancel: dict[str, threading.Event] = {}
        self._timing_attention_statuses: dict[str, dict[str, Any]] = {}
        self._timing_attention_lock = threading.RLock()
        self._derived_store = DerivedArtifactStore(self.paths.jobs)
        self._derived_queue: queue.Queue[tuple[str, str, str | None, str] | None] = queue.Queue()
        self._derived_cancel: dict[str, threading.Event] = {}
        self._local_api: LocalAPIServer | None = None
        self._shutdown_event = threading.Event()
        self._shutdown_lock = threading.Lock()
        self._shutdown_sentinels_sent = False
        self._runner = None
        self._subtitle_render_runner = None
        self._subtitle_preview_runner = None
        self._derived_runner = None
        self._timing_attention_runner = None
        self._youtube = YouTubeImportService(
            root=self.paths.root / "YouTube Imports",
            runtime_root=self.paths.runtime,
            executor=youtube_executor,
            runtime=youtube_runtime,
            event_callback=lambda event, payload: self.emit(event, **payload),
            enqueue_asr=self._enqueue_youtube_asr,
            recover=recover,
            runner_enabled=(start_runner if start_youtube_runner is None else start_youtube_runner),
        )
        if start_runner:
            self._runner = threading.Thread(target=self._run_jobs, name="cts-job-runner", daemon=True)
            self._runner.start()
            self._subtitle_render_runner = threading.Thread(
                target=self._run_subtitle_renders,
                name="cts-subtitle-render-runner",
                daemon=True,
            )
            self._subtitle_render_runner.start()
            self._subtitle_preview_runner = threading.Thread(
                target=self._run_subtitle_previews,
                name="cts-subtitle-preview-runner",
                daemon=True,
            )
            self._subtitle_preview_runner.start()
            self._derived_runner = threading.Thread(
                target=self._run_derived_tasks,
                name="cts-derived-runner",
                daemon=True,
            )
            self._derived_runner.start()
            self._timing_attention_runner = threading.Thread(
                target=self._run_timing_attention_scans,
                name="cts-timing-attention-runner",
                daemon=True,
            )
            self._timing_attention_runner.start()
        self.dispatcher = Dispatcher()
        self._register_methods()
        if recover:
            try:
                recovered = _call(self.jobs, ("recover_startup", "recover_interrupted", "recover"))
                queued_ids: list[str] = []
                queued_seen: set[str] = set()

                def remember_queued(raw_job_id: object) -> None:
                    job_id = str(raw_job_id)
                    if job_id and job_id not in queued_seen:
                        queued_seen.add(job_id)
                        queued_ids.append(job_id)

                for item in recovered or []:
                    job_id = getattr(item, "job_id", item)
                    remember_queued(job_id)
                try:
                    records = _call(self.jobs, ("list", "list_jobs"))
                except AttributeError:
                    records = ()
                for record in records:
                    record_value = _jsonable(record)
                    state = record_value.get("state", record_value.get("status"))
                    if state == "queued":
                        remember_queued(record_value.get("job_id") or record_value.get("id"))
                for job_id in queued_ids:
                    self._enqueue_job_once(job_id)
            except AttributeError:
                pass
            queued_renders, interrupted_renders = self._subtitle_renderer.recover(self.paths.jobs)
            for job_id in queued_renders:
                try:
                    job = _call(self.jobs, ("get", "get_job"), job_id)
                    workspace = self._subtitle_projects.workspace_for_job(job_id, job)
                    render = self._subtitle_renderer.status(workspace, job_id)
                    token = render.get("output_filename")
                    if isinstance(token, str) and token:
                        self._subtitle_render_cancel[job_id] = threading.Event()
                        self._subtitle_render_queue.put((job_id, token))
                except Exception:
                    logger.exception("Could not recover queued subtitle render: %s", job_id)
            for job_id in interrupted_renders:
                try:
                    job = _call(self.jobs, ("get", "get_job"), job_id)
                    workspace = self._subtitle_projects.workspace_for_job(job_id, job)
                    render = self._subtitle_renderer.status(workspace, job_id)
                    project = self._subtitle_projects.get_or_create(job_id, job)
                    self._subtitle_project_revisions[job_id] = project.revision
                    self.emit(
                        "subtitle.render.updated",
                        job_id=job_id,
                        render=self._render_view_for_job(job_id, render),
                    )
                except Exception:
                    logger.exception("Could not report interrupted subtitle render: %s", job_id)
            queued_previews, interrupted_previews = self._subtitle_previews.recover(self.paths.jobs)
            for job_id, token in queued_previews:
                try:
                    _call(self.jobs, ("get", "get_job"), job_id)
                    self._subtitle_preview_cancel[job_id] = threading.Event()
                    self._subtitle_preview_queue.put((job_id, token))
                except Exception:
                    logger.exception("Could not recover queued subtitle preview: %s", job_id)
            for job_id in interrupted_previews:
                try:
                    job = _call(self.jobs, ("get", "get_job"), job_id)
                    workspace = self._subtitle_projects.workspace_for_job(job_id, job)
                    preview = self._subtitle_previews.status(workspace, job_id)
                    self.emit("subtitle.preview.updated", job_id=job_id, preview=preview)
                except Exception:
                    logger.exception("Could not report interrupted subtitle preview: %s", job_id)
            for task in self._derived_store.recover():
                kind, job_id, target_language, token = task
                self._derived_cancel[token] = threading.Event()
                self._derived_queue.put(task)
        if enable_local_api:
            self._start_local_api_if_enabled()

    def _write(self, value: dict[str, Any]) -> None:
        payload = json.dumps(_jsonable(value), ensure_ascii=False, separators=(",", ":"))
        with self._write_lock:
            if self._output_disconnected:
                return
            try:
                self.stdout.write(payload + "\n")
                self.stdout.flush()
            except (BrokenPipeError, OSError, ValueError):
                # The macOS app closes the worker's stdout reader during
                # Cmd+Q/termination.  Events are best-effort IPC; a broken
                # consumer must never escape into the transcription pipeline
                # and turn a recoverable active job into FAILED/CANCELED.
                self._output_disconnected = True
                logger.info("Worker output disconnected; suppressing later IPC events")

    def emit(self, event: str, **payload: Any) -> None:
        self._write(event_message(event, **payload))

    @staticmethod
    def _render_revision_view(
        render: dict[str, Any], current_revision: int | None
    ) -> dict[str, Any]:
        value = dict(render)
        snapshot = value.get("project_revision")
        if isinstance(snapshot, bool) or not isinstance(snapshot, int):
            value["current_project_revision"] = current_revision
            value["is_current_revision"] = None
            value["outdated"] = False
            return value
        value["current_project_revision"] = current_revision
        is_current = isinstance(current_revision, int) and snapshot == current_revision
        value["is_current_revision"] = is_current
        value["outdated"] = not is_current
        return value

    def _render_view_for_job(self, job_id: str, render: dict[str, Any]) -> dict[str, Any]:
        return self._render_revision_view(
            render,
            self._subtitle_project_revisions.get(job_id),
        )

    def shutdown(self, *, wait_timeout: float = 8.0) -> None:
        """Cancel owned subtitle encoders and stop runners on EOF/SIGTERM."""
        with self._live_lock:
            self._close_live_assistant()
            if self._live_speaker_enrollment is not None:
                self._close_live_speaker_enrollment()
            if self._live_worker is not None:
                try:
                    self._live_worker.cancel(timeout=min(max(wait_timeout, 0.1), 5.0))
                except Exception:
                    logger.exception("Could not cancel live caption session during shutdown")
                finally:
                    self._clear_terminal_live_sensitive_state(self._live_worker)
        if self._local_api is not None:
            self._local_api.stop()
            self._local_api = None
        self._youtube.shutdown(wait_timeout=wait_timeout)
        with self._shutdown_lock:
            self._shutdown_event.set()
            for event in list(self._cancel.values()):
                event.set()
            for event in list(self._subtitle_render_cancel.values()):
                event.set()
            for event in list(self._subtitle_preview_cancel.values()):
                event.set()
            for event in list(self._derived_cancel.values()):
                event.set()
            for event in list(self._timing_attention_cancel.values()):
                event.set()
            if not self._shutdown_sentinels_sent:
                self._shutdown_sentinels_sent = True
                if self._runner is not None:
                    self._job_queue.put(None)
                if self._subtitle_render_runner is not None:
                    self._subtitle_render_queue.put(None)
                if self._subtitle_preview_runner is not None:
                    self._subtitle_preview_queue.put(None)
                if self._derived_runner is not None:
                    self._derived_queue.put(None)
                if self._timing_attention_runner is not None:
                    self._timing_attention_queue.put(None)
        deadline = time.monotonic() + max(0.0, wait_timeout)
        current = threading.current_thread()
        for runner in (
            self._subtitle_render_runner,
            self._subtitle_preview_runner,
            self._derived_runner,
            self._timing_attention_runner,
            self._runner,
        ):
            if runner is None or runner is current or not runner.is_alive():
                continue
            runner.join(timeout=max(0.0, deadline - time.monotonic()))

    def _register_methods(self) -> None:
        self.dispatcher.add("corrections.clear", self._corrections_clear)
        self.dispatcher.add("corrections.delete", self._corrections_delete)
        self.dispatcher.add("corrections.export", self._corrections_export)
        self.dispatcher.add("corrections.import", self._corrections_import)
        self.dispatcher.add("corrections.list", self._corrections_list)
        self.dispatcher.add("corrections.remember", self._corrections_remember)
        self.dispatcher.add("corrections.remember_edit", self._corrections_remember_edit)
        self.dispatcher.add("insights.cancel", self._insights_cancel)
        self.dispatcher.add("insights.explain", self._insights_explain)
        self.dispatcher.add("insights.generate", self._insights_generate)
        self.dispatcher.add("insights.get", self._insights_get)
        self.dispatcher.add("system.health", self._health)
        self.dispatcher.add("translations.cancel", self._translations_cancel)
        self.dispatcher.add("translations.export", self._translations_export)
        self.dispatcher.add("translations.generate", self._translations_generate)
        self.dispatcher.add("translations.list", self._translations_list)
        self.dispatcher.add("translations.update", self._translations_update)
        self.dispatcher.add("models.status", lambda p: self.models.status(p.get("model")))
        self.dispatcher.add("models.verify", self._model_verify)
        self.dispatcher.add("models.delete", self._model_delete)
        self.dispatcher.add("models.download", self._model_download)
        self.dispatcher.add("jobs.list", self._jobs_list)
        self.dispatcher.add("jobs.get", self._job_get)
        self.dispatcher.add("jobs.create", self._job_create)
        self.dispatcher.add("jobs.start", self._job_start)
        self.dispatcher.add("jobs.cancel", self._job_cancel)
        self.dispatcher.add("jobs.retry", self._job_retry)
        self.dispatcher.add("live.assistant.cancel", self._live_assistant_cancel)
        self.dispatcher.add("live.cancel", self._live_cancel)
        self.dispatcher.add("live.interview.command", self._live_interview_command)
        self.dispatcher.add("live.poll", self._live_poll)
        self.dispatcher.add("live.push", self._live_push)
        self.dispatcher.add("live.start", self._live_start)
        self.dispatcher.add("live.status", self._live_status)
        self.dispatcher.add("live.stop", self._live_stop)
        self.dispatcher.add("live.speaker_enroll.cancel", self._live_speaker_enroll_cancel)
        self.dispatcher.add("live.speaker_enroll.push", self._live_speaker_enroll_push)
        self.dispatcher.add("live.speaker_enroll.start", self._live_speaker_enroll_start)
        self.dispatcher.add("live.speaker_enroll.stop", self._live_speaker_enroll_stop)
        self.dispatcher.add("subtitle.project.auto_segment", self._subtitle_project_auto_segment)
        self.dispatcher.add("subtitle.project.export", self._subtitle_project_export)
        self.dispatcher.add("subtitle.project.get", self._subtitle_project_get)
        self.dispatcher.add("subtitle.project.update", self._subtitle_project_update)
        self.dispatcher.add("subtitle.render.start", self._subtitle_render_start)
        self.dispatcher.add("subtitle.render.cancel", self._subtitle_render_cancel_request)
        self.dispatcher.add("subtitle.render.status", self._subtitle_render_status)
        self.dispatcher.add("subtitle.preview.prepare", self._subtitle_preview_prepare)
        self.dispatcher.add("subtitle.preview.cancel", self._subtitle_preview_cancel_request)
        self.dispatcher.add("subtitle.preview.status", self._subtitle_preview_status)
        self.dispatcher.add(
            "subtitle.timing_attention.cancel", self._subtitle_timing_attention_cancel
        )
        self.dispatcher.add(
            "subtitle.timing_attention.scan", self._subtitle_timing_attention_scan
        )
        self.dispatcher.add(
            "subtitle.timing_attention.status", self._subtitle_timing_attention_status
        )
        self.dispatcher.add("settings.get", lambda p: self.settings_store.get().to_dict())
        self.dispatcher.add("settings.update", lambda p: self.settings_store.update(p).to_dict())
        self.dispatcher.add("history.clear_completed", self._history_clear_completed)
        self.dispatcher.add("youtube.capabilities", lambda p: self._youtube.capabilities())
        self.dispatcher.add("youtube.import.start", self._youtube_import_start)
        self.dispatcher.add("youtube.import.list", lambda p: self._youtube.list_imports())
        self.dispatcher.add("youtube.import.status", self._youtube_import_status)
        self.dispatcher.add("youtube.import.cancel", self._youtube_import_cancel)
        self.dispatcher.add("youtube.import.retry", self._youtube_import_retry)
        if self.dispatcher.methods != WORKER_METHOD_NAMES:
            raise RuntimeError("worker method manifest 同 live dispatcher 唔一致")

    @staticmethod
    def _required(params: dict[str, Any], name: str) -> str:
        value = params.get(name)
        if not isinstance(value, str) or not value:
            raise ValueError(f"缺少 {name}")
        return value

    def _canonical_job_workspace(self, job_id: str, raw_workspace: Any) -> Path:
        """Return only the canonical, non-symlinked Jobs/<job-id> directory."""

        if not job_id or Path(job_id).name != job_id or job_id in {".", ".."}:
            raise ValueError("工作 ID 無效")
        root = self.paths.jobs.expanduser().resolve(strict=True)
        expected = root / job_id
        supplied = Path(str(raw_workspace)).expanduser()
        supplied = Path(os.path.abspath(supplied))
        if supplied != expected:
            raise ValueError("工作 workspace 同 Jobs 記錄不一致")
        if expected.is_symlink():
            raise ValueError("工作 workspace 唔可以係 symlink")
        if expected.exists():
            if not expected.is_dir() or expected.resolve(strict=True) != expected:
                raise ValueError("工作 workspace 路徑無效")
        return expected

    @staticmethod
    def _canonical_workspace_subdirectory(workspace: Path, name: str) -> Path:
        """Create/return one direct workspace directory without following links.

        Media tools write sizeable outputs.  Rejecting linked workspace
        components keeps a damaged or hand-edited job record from redirecting
        those writes outside its own ``Jobs/<job-id>`` directory.
        """

        if not name or Path(name).name != name or name in {".", ".."}:
            raise ValueError("工作子目錄名稱無效")
        root = Path(os.path.abspath(workspace.expanduser()))
        if root.is_symlink() or not root.is_dir():
            raise ValueError("工作 workspace 路徑無效")
        try:
            resolved_root = root.resolve(strict=True)
        except OSError as error:
            raise ValueError("工作 workspace 路徑無效") from error
        if resolved_root != root:
            raise ValueError("工作 workspace 唔可以經 symlink 存取")

        child = root / name
        if child.is_symlink():
            raise ValueError(f"工作 {name} 目錄唔可以係 symlink")
        if child.exists() and not child.is_dir():
            raise ValueError(f"工作 {name} 路徑唔係目錄")
        child.mkdir(exist_ok=True)
        if child.is_symlink() or child.resolve(strict=True) != resolved_root / name:
            raise ValueError(f"工作 {name} 目錄路徑無效")
        return child

    def _health(self, params: dict[str, Any]) -> dict[str, Any]:
        settings = self.settings_store.get()
        try:
            whisper_cli = str(resolve_whisper_cli())
        except WhisperCPPError:
            whisper_cli = None
        try:
            whisper_server = str(resolve_whisper_server())
        except LocalEngineError:
            whisper_server = None
        live_small = self.models.path_for(WHISPER_SMALL_ID) / WHISPER_SMALL_FILENAME
        live_final = self.models.path_for(WHISPER_LARGE_V3_ID) / WHISPER_LARGE_V3_FILENAME
        return {
            "ok": True,
            "protocol": 1,
            "paths": {
                "root": str(self.paths.root),
                "models": str(self.paths.models),
                "jobs": str(self.paths.jobs),
                "runtime": str(self.paths.runtime),
                "logs": str(self.paths.logs),
            },
            "methods": self.dispatcher.methods,
            "normal_transcription_network": False,
            "user_initiated_youtube_network": True,
            "youtube": self._youtube.capabilities(),
            "live_caption": {
                "available": (
                    whisper_server is not None
                    and live_small.is_file()
                    and live_final.is_file()
                ),
                "offline": True,
                "sample_rate": 16_000,
                "format": "pcm_s16le_mono",
                "maximum_frame_ms": 200,
                "partial_model": WHISPER_SMALL_ID,
                "final_model": WHISPER_LARGE_V3_ID,
                "speaker_tracking_available": (
                    self.models.path_for(SPEAKER_EMBEDDING_ID)
                    / SPEAKER_EMBEDDING_FILENAME
                ).is_file(),
                "speaker_tracking_model": SPEAKER_EMBEDDING_ID,
                "state": self._live_status_value()["state"],
            },
            "runtimes": {
                "whisper_cpp": {
                    "available": whisper_cli is not None and whisper_server is not None,
                    "path": whisper_cli,
                    "server_path": whisper_server,
                }
            },
            "local_api": self._local_api.info() if self._local_api is not None else {
                "enabled": False,
                "host": "127.0.0.1",
                "port": settings.local_api_port,
                "base_url": f"http://127.0.0.1:{settings.local_api_port}/v1",
                "status_path": str(self.paths.root / "local-api.json"),
                "token_header": "X-CTS-Token",
            },
        }

    def _start_local_api_if_enabled(self) -> None:
        settings = self.settings_store.get()
        if not settings.local_api_enabled:
            return
        token = settings.local_api_token or new_token()
        if token != settings.local_api_token:
            self.settings_store.update({"local_api_token": token})
        try:
            self._local_api = LocalAPIServer(
                self,
                host="127.0.0.1",
                port=settings.local_api_port,
                token=token,
                status_path=self.paths.root / "local-api.json",
            )
            self._local_api.start()
        except Exception:
            self._local_api = None
            logger.exception("Local API requested but could not start")

    def _model_download(self, params: dict[str, Any]) -> dict[str, Any]:
        key = self._required(params, "model")
        return self._with_exclusive_model_access(
            lambda: self.models.download(
                key,
                redownload=bool(params.get("redownload", False)),
                progress=lambda value: self.emit(
                    "model.download.progress", model=key, progress=value
                ),
            )
        )

    def _model_verify(self, params: dict[str, Any]) -> dict[str, Any]:
        key = self._required(params, "model")
        return self._with_exclusive_model_access(lambda: self.models.verify(key))

    def _model_delete(self, params: dict[str, Any]) -> dict[str, Any]:
        key = self._required(params, "model")
        return self._with_exclusive_model_access(lambda: self.models.delete(key))

    def _with_exclusive_model_access(self, operation: Callable[[], Any]) -> Any:
        if not self._heavy_work_lock.acquire(blocking=False):
            raise ValueError("轉錄／模型工作進行中；完成或取消後先可以更改模型")
        try:
            return operation()
        finally:
            self._heavy_work_lock.release()

    def _release_live_heavy_lock(self) -> None:
        if self._live_heavy_lock_owned:
            self._live_heavy_lock_owned = False
            self._heavy_work_lock.release()

    def _release_live_heavy_lock_if_terminal(self) -> bool:
        worker = self._live_worker
        if worker is None or str(worker.state.value) in {
            "stopped",
            "cancelled",
            "failed",
        }:
            self._release_live_heavy_lock()
            return True
        return False

    @staticmethod
    def _idle_live_interview_status() -> dict[str, Any]:
        return {
            "enabled": False,
            "question_id": None,
            "question_index": None,
            "question_count": 0,
            "subject_number": 1,
            "visit_id": None,
            "revision": 0,
            "answer_capture_active": False,
            "can_previous": False,
            "can_next": False,
            "manual_navigation_only": True,
            "analysis_available": False,
        }

    @staticmethod
    def _idle_live_assistant_status() -> dict[str, Any]:
        """Status contract when no optional AI Cue session exists.

        A runtime is created only after an explicit Live AI Cue opt-in.  The
        native app can therefore show a precise managed/prepared state without
        ever asking users to preload a model in Terminal.
        """

        return {
            "enabled": False,
            "offline": True,
            "model": None,
            "policy_version": "local-live-assistant-v2",
            "pending": False,
            "circuit_open": False,
            "circuit_retry_after_seconds": 0.0,
            "captions_in_memory": 0,
            "runtime_management": "app_managed",
            "prepared": False,
            "runtime_state": "disabled",
            "unavailable_reason": None,
            "memory_gate": None,
            "release_status": None,
            "asr_priority": True,
            "interview": Worker._idle_live_interview_status(),
        }

    def _live_assistant_runtime_status_value(self) -> dict[str, Any] | None:
        runtime = self._live_assistant_runtime
        if runtime is None:
            return None
        status = getattr(runtime, "status", None)
        if not callable(status):
            return None
        try:
            value = status()
        except Exception:
            # A runtime manager must never make microphone captioning fail.
            # Keep it text-free because a development adapter could surface
            # a request body in its exception.
            return {
                "enabled": True,
                "offline": True,
                "model": None,
                "policy_version": "local-live-assistant-v2",
                "pending": False,
                "circuit_open": False,
                "circuit_retry_after_seconds": 0.0,
                "captions_in_memory": 0,
                "runtime_management": "app_managed",
                "prepared": False,
                "runtime_state": "runtime_unavailable",
                "unavailable_reason": "runtime_status_failed",
                "memory_gate": None,
                "release_status": None,
                "asr_priority": True,
                "interview": self._idle_live_interview_status(),
            }
        if not isinstance(value, Mapping):
            return None
        result = dict(value)
        result.setdefault("interview", self._idle_live_interview_status())
        return result

    def _live_assistant_status_value(self) -> dict[str, Any]:
        assistant = self._live_assistant
        runtime_status = self._live_assistant_runtime_status_value()
        if assistant is None:
            return runtime_status or self._idle_live_assistant_status()
        try:
            status = assistant.status()
        except Exception:
            # Never turn an optional assistant status failure into a failed
            # microphone session. Keep this error text-free so it cannot leak
            # captions into the worker log.
            status = {
                "enabled": True,
                "offline": True,
                "model": None,
                "policy_version": "local-live-assistant-v2",
                "pending": False,
                "circuit_open": True,
                "circuit_retry_after_seconds": 0.0,
                "captions_in_memory": 0,
                "interview": self._idle_live_interview_status(),
            }
        value = dict(status) if isinstance(status, Mapping) else {}
        if runtime_status is not None:
            # The runtime manager owns model lifecycle and tells Swift whether
            # E2B remains safely resident.  The coordinator owns only the
            # bounded in-memory cue queue, so merge its live values without
            # allowing it to overwrite the lifecycle contract.
            cue_runtime_state = value.get("runtime_state")
            runtime_status.update(
                {
                    "pending": bool(value.get("pending", False)),
                    "circuit_open": bool(value.get("circuit_open", False)),
                    "circuit_retry_after_seconds": float(
                        value.get("circuit_retry_after_seconds", 0.0)
                    ),
                    "captions_in_memory": int(value.get("captions_in_memory", 0)),
                    "cue_runtime_state": cue_runtime_state,
                    "asr_priority": True,
                    "interview": value.get(
                        "interview", self._idle_live_interview_status()
                    ),
                }
            )
            if cue_runtime_state in {"available", "unavailable"}:
                runtime_status["runtime_state"] = cue_runtime_state
            # Session-only operator markers are coordinator-owned.  Preserve
            # their read-back only when an enabled Interview Coach supplied
            # them, so the pre-existing non-interview status schema stays
            # byte-for-byte unchanged.
            if "operational_markers" in value:
                runtime_status["operational_markers"] = list(
                    value["operational_markers"]
                )
            return runtime_status
        value.update(
            {
                "runtime_management": "test_injected",
                "prepared": True,
                "asr_priority": True,
            }
        )
        value.setdefault("interview", self._idle_live_interview_status())
        return value

    def _close_live_assistant(self) -> None:
        """Discard cue state and release only CTS's dedicated E2B lease."""

        assistant = self._live_assistant
        self._live_assistant = None
        if assistant is not None:
            close = getattr(assistant, "close", None)
            if callable(close):
                try:
                    close()
                except Exception:
                    # The cue is optional and has no persisted state.  Avoid
                    # logging exception payloads because they can include a fake
                    # client's input text in development builds.
                    logger.warning("Could not close local live assistant")
        runtime = self._live_assistant_runtime
        self._live_assistant_runtime = None
        if runtime is not None:
            release = getattr(runtime, "release", None)
            if callable(release):
                try:
                    # Runtime policy limits this to the CTS E2B identifier;
                    # it never requests a process-global LM Studio stop.
                    release()
                except Exception:
                    logger.warning("Could not release local live AI runtime")

    def _cancel_live_assistant_request(self) -> bool:
        """Invalidate an in-flight cue while retaining the active session."""

        assistant = self._live_assistant
        if assistant is None:
            return False
        cancel = getattr(assistant, "cancel", None)
        if not callable(cancel):
            return False
        try:
            cancel()
            return True
        except Exception:
            logger.warning("Could not cancel local live assistant")
            return False

    def _live_assistant_observe_final_values(
        self,
        values: list[dict[str, Any]],
    ) -> None:
        """Send only finished, already-normalized caption values to AI Cue."""

        assistant = self._live_assistant
        if assistant is None:
            return
        try:
            from .live_caption.assistant import FinalizedCaption
        except Exception:
            logger.warning("Local live assistant caption adapter unavailable")
            return
        for value in values:
            if value.get("type") != "final":
                continue
            try:
                sequence = value.get("sequence")
                start = value.get("start")
                end = value.get("end")
                text = value.get("text")
                if (
                    isinstance(sequence, bool)
                    or not isinstance(sequence, int)
                    or isinstance(start, bool)
                    or not isinstance(start, (int, float))
                    or isinstance(end, bool)
                    or not isinstance(end, (int, float))
                    or not isinstance(text, str)
                ):
                    raise ValueError("invalid normalized final")
                assistant.observe_final(
                    FinalizedCaption(
                        sequence=sequence,
                        start=float(start),
                        end=float(end),
                        text=text,
                    )
                )
            except Exception:
                # Keep live ASR independent from every optional AI cue fault.
                logger.warning("Local live assistant ignored one final caption")

    def _live_assistant_event_values(
        self,
        *,
        include_pending: bool = True,
    ) -> list[dict[str, Any]]:
        assistant = self._live_assistant
        if assistant is None:
            return []
        try:
            values = assistant.poll_events(16)
        except Exception:
            logger.warning("Could not read local live assistant events")
            return []
        if not isinstance(values, list):
            return []
        output = [item for item in values if isinstance(item, dict)]
        if not include_pending:
            output = [item for item in output if item.get("type") != "assistant_pending"]
        return output

    def _clear_terminal_live_sensitive_state(
        self,
        worker: Any,
        *,
        discard_profile_snapshot: bool = True,
    ) -> bool:
        """Drop terminal project references under the live RPC lock.

        ``live.stop`` is the only caller allowed to hand the one-shot snapshot
        to Swift, so it consumes that value first and passes
        ``discard_profile_snapshot=False`` here.  All other terminal paths
        discard it fail-closed; status/poll/cancel/error must never become a
        delayed persistence channel.
        """

        if str(worker.state.value) not in {"stopped", "cancelled", "failed"}:
            return False
        if discard_profile_snapshot:
            take_snapshot = getattr(worker, "take_profile_snapshot", None)
            if callable(take_snapshot):
                take_snapshot()
        # A terminal poll/status/cancel must not become a delayed raw-audio
        # persistence route. `live.stop` consumes its prepared receipt first;
        # every other terminal cleanup drops the private staging bytes here.
        discard_timing_archive = getattr(worker, "discard_timing_archive", None)
        if callable(discard_timing_archive):
            discard_timing_archive()
        self._live_project_session = None
        self._live_asr_mode = "dual_whisper"
        self._close_live_assistant()
        self._release_live_heavy_lock_if_terminal()
        return True

    @staticmethod
    def _live_stats_value(stats: Any) -> dict[str, Any]:
        return {
            "captured_sample_index": int(stats.captured_sample_index),
            "sample_rate_hz": int(stats.sample_rate_hz),
            "captured_seconds": float(stats.captured_seconds),
            "processed_seconds": float(stats.processed_seconds),
            "dropped_seconds": float(stats.dropped_seconds),
            "accepted_frames": int(stats.accepted_frames),
            "dropped_frames": int(stats.dropped_frames),
            "emitted_events": int(stats.emitted_events),
            "partial_inferences": int(stats.partial_inferences),
            "final_inferences": int(stats.final_inferences),
            "maximum_inference_latency_ms": float(stats.maximum_inference_latency_ms),
            "pending_audio_seconds": float(stats.pending_audio_seconds),
        }

    @staticmethod
    def _idle_live_timing_archive_status() -> dict[str, Any]:
        return {
            "enabled": False,
            "state": "disabled",
            "local_only": True,
            "review_only": True,
            "automatic_timestamp_mutation": False,
            "candidate_state": "not_run",
            "integrity_scope": None,
            "archive_id": None,
            "source_audio_sha256": None,
            "manifest_sha256": None,
            "detached_receipt_sha256": None,
            "accepted_samples": 0,
            "dropped_samples": 0,
            "sample_rate_hz": 16_000,
            "durability_warning": None,
            "error_code": None,
        }

    def _live_event_values(self, events: Any) -> list[dict[str, Any]]:
        """Normalize every caption locally; apply approved aliases to finals only."""

        output: list[dict[str, Any]] = []
        for event in events:
            value = event.to_dict()
            raw_text = value.get("text")
            if isinstance(raw_text, str) and raw_text:
                normalizer = self._live_hk_normalizer
                hk_text = (
                    normalizer.normalize(raw_text)
                    if normalizer is not None
                    else raw_text
                )
                metadata = value.get("metadata")
                metadata = dict(metadata) if isinstance(metadata, dict) else {}
                metadata["raw_asr_text"] = raw_text
                metadata["hk_normalized_text"] = hk_text
                value["text"] = hk_text
                if value.get("type") == "final":
                    corrected, decisions = apply_approved_corrections(
                        hk_text,
                        self._live_correction_entries,
                    )
                    value["text"] = corrected
                    metadata["correction_memory"] = {
                        "schema": CORRECTION_MEMORY_SCHEMA_VERSION,
                        "policy": "manual_or_two_confirmations",
                        "session_snapshot_entries": len(
                            self._live_correction_entries
                        ),
                        "raw_asr_text": raw_text,
                        "hk_normalized_text": hk_text,
                        "applied_count": len(decisions),
                        "decisions": list(decisions),
                    }
                value["metadata"] = metadata
            output.append(value)
        return output

    @staticmethod
    def _canonical_live_project_id(value: object) -> str:
        if not isinstance(value, str):
            raise ValueError("project_id 必須係 UUID 字串")
        try:
            return str(uuid.UUID(value))
        except (ValueError, AttributeError) as exc:
            raise ValueError("project_id UUID 格式無效") from exc

    @staticmethod
    def _parse_live_project_start(params: dict[str, Any]) -> _LiveStartOptions:
        """Validate the narrow Swift→Python live project boundary.

        `{}` and `captions_only` are ASR-only sessions: they never accept a
        speaker count or voice snapshot. Only project mode enables the speaker
        engine and accepts a decrypted snapshot object. Persistence and
        encryption remain in Swift and are deliberately absent from Python.
        """

        allowed = {
            "assistant",
            "mode",
            "project_id",
            "expected_speaker_count",
            "tracker_snapshot",
            "timing_archive",
        }
        unknown = set(params) - allowed
        if unknown:
            raise ValueError(f"live.start 有未知參數：{', '.join(sorted(unknown))}")
        raw_assistant = params.get("assistant")
        if raw_assistant is not None and not isinstance(raw_assistant, dict):
            raise ValueError("assistant 必須係 object")
        from .live_caption.assistant import LiveAssistantConfig

        assistant_config = LiveAssistantConfig.from_dict(raw_assistant)
        raw_timing_archive = params.get("timing_archive")
        if raw_timing_archive is None:
            timing_archive_enabled = False
        else:
            if (
                not isinstance(raw_timing_archive, dict)
                or set(raw_timing_archive) != {"enabled"}
                or not isinstance(raw_timing_archive["enabled"], bool)
            ):
                raise ValueError("timing_archive 只接受 enabled boolean")
            timing_archive_enabled = raw_timing_archive["enabled"]
        if not params:
            return _LiveStartOptions(
                project=None,
                expected_speaker_count=None,
                assistant_config=assistant_config,
                timing_archive_enabled=timing_archive_enabled,
            )
        mode = params.get("mode", "captions_only")
        from .live_caption.speaker import LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS

        expected = params.get("expected_speaker_count")
        if expected is not None and (
            isinstance(expected, bool)
            or not isinstance(expected, int)
            or not 1 <= expected <= LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS
        ):
            raise ValueError(
                "expected_speaker_count 必須係 1 至 "
                f"{LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS} 或留空"
            )
        if mode in {"captions_only", "private"}:
            if set(params) - {"mode", "assistant", "timing_archive"}:
                raise ValueError("普通即時字幕不接受講者或 project 參數；請使用 Lazy Camman")
            return _LiveStartOptions(
                project=None,
                expected_speaker_count=None,
                assistant_config=assistant_config,
                timing_archive_enabled=timing_archive_enabled,
            )
        if mode != "project":
            raise ValueError("live.start mode 必須係 captions_only 或 project")
        if "project_id" not in params:
            raise ValueError("project live.start 缺少 project_id")
        if expected is None:
            raise ValueError("project live.start 必須指定 expected_speaker_count")
        project_id = Worker._canonical_live_project_id(params["project_id"])
        raw_snapshot = params.get("tracker_snapshot")
        if not isinstance(raw_snapshot, dict):
            raise ValueError("project live.start 必須提供完整 tracker_snapshot")
        profiles = raw_snapshot.get("profiles")
        if not isinstance(profiles, list):
            raise ValueError("tracker_snapshot profiles 必須係 list")
        if len(profiles) != expected:
            raise ValueError("tracker_snapshot profiles 必須等於 expected_speaker_count")
        for expected_slot, profile in enumerate(profiles):
            if not isinstance(profile, Mapping) or profile.get("slot") != expected_slot:
                raise ValueError("tracker_snapshot profile slot 必須由 0 連續排序")
        return _LiveStartOptions(
            project=_LiveProjectSession(
                project_id=project_id,
                expected_speaker_count=expected,
                tracker_snapshot=dict(raw_snapshot),
            ),
            expected_speaker_count=expected,
            assistant_config=assistant_config,
            timing_archive_enabled=timing_archive_enabled,
        )

    @staticmethod
    def _speaker_model_sha256(
        speaker_tracker: Any,
        model_path: Path,
    ) -> str | None:
        """Return the exact local embedding model fingerprint without logging it."""

        engine = getattr(speaker_tracker, "engine", None)
        declared = getattr(engine, "model_sha256", None)
        if isinstance(declared, str) and len(declared) == 64:
            normalized = declared.lower()
            if all(character in "0123456789abcdef" for character in normalized):
                return normalized
        if not model_path.is_file():
            return None
        digest = hashlib.sha256()
        with model_path.open("rb") as handle:
            for block in iter(lambda: handle.read(1_048_576), b""):
                digest.update(block)
        return digest.hexdigest()

    def _live_status_value(self) -> dict[str, Any]:
        worker = self._live_worker
        if worker is None or self._live_session_id is None:
            return {
                "session_id": None,
                "state": "idle",
                "offline": True,
                "sample_rate": 16_000,
                "format": "pcm_s16le_mono",
                "speaker_tracking_available": (
                    self.models.path_for(SPEAKER_EMBEDDING_ID)
                    / SPEAKER_EMBEDDING_FILENAME
                ).is_file(),
                "speaker_tracking_model": SPEAKER_EMBEDDING_ID,
                "speaker_tracking_error": None,
                "assistant": self._live_assistant_status_value(),
                "timing_archive": self._idle_live_timing_archive_status(),
            }
        state = str(worker.state.value)
        lightweight = self._live_asr_mode == "lightweight_answer"
        final_model_id = WHISPER_SMALL_ID if lightweight else WHISPER_LARGE_V3_ID
        value = {
            "session_id": self._live_session_id,
            "state": state,
            "offline": True,
            "sample_rate": 16_000,
            "format": "pcm_s16le_mono",
            "model": final_model_id,
            "partial_model": WHISPER_SMALL_ID,
            "final_model": final_model_id,
            "asr_mode": self._live_asr_mode,
            "speaker_tracking_available": self._live_speaker_tracking_available,
            "speaker_tracking_model": (
                SPEAKER_EMBEDDING_ID
                if self._live_speaker_tracking_available
                else None
            ),
            "speaker_tracking_error": self._live_speaker_tracking_error,
            "stats": self._live_stats_value(worker.stats()),
            "assistant": self._live_assistant_status_value(),
            "timing_archive": (
                worker.timing_archive_status()
                if callable(getattr(worker, "timing_archive_status", None))
                else self._idle_live_timing_archive_status()
            ),
        }
        project = self._live_project_session
        if project is not None:
            value.update(
                {
                    "mode": "project",
                    "project_id": project.project_id,
                    "expected_speaker_count": project.expected_speaker_count,
                    "enrolled_speaker_count": project.expected_speaker_count,
                    "speaker_identity_mode": "enrolled_closed_roster",
                }
            )
        else:
            value.update(
                {
                    "mode": "captions_only",
                    "speaker_identity_mode": "disabled",
                }
            )
        return value

    def _require_live_session(self, params: dict[str, Any]) -> Any:
        session_id = self._required(params, "session_id")
        if self._live_worker is None or self._live_session_id != session_id:
            raise ValueError("即時字幕 session 已失效，請重新開始")
        return self._live_worker

    def _live_speaker_enrollment_status_value(
        self, enrollment: _LiveSpeakerEnrollmentSession
    ) -> dict[str, Any]:
        seconds = len(enrollment.buffer) / 2 / 16_000
        quality = enrollment.tracker.enrollment_quality(enrollment.buffer)
        return {
            "session_id": enrollment.session_id,
            "state": "recording",
            "project_id": enrollment.project.project_id,
            "target_slot": enrollment.target_slot,
            "speaker_id": f"speaker-{enrollment.target_slot + 1}",
            "recorded_seconds": round(seconds, 3),
            "recommended_seconds": enrollment.recommended_seconds,
            "minimum_seconds": enrollment.minimum_speech_seconds,
            "maximum_seconds": enrollment.maximum_seconds,
            "can_stop": bool(quality["enrollment_ready"]),
            "complete": seconds >= enrollment.maximum_seconds,
            "speaker_tracking_model": SPEAKER_EMBEDDING_ID,
            "offline": True,
            "quality": quality,
        }

    def _close_live_speaker_enrollment(self) -> None:
        enrollment = self._live_speaker_enrollment
        self._live_speaker_enrollment = None
        if enrollment is not None and enrollment.tracker is not None:
            # The only recording copy is session RAM. Wipe it before releasing
            # the tracker so neither a completed nor cancelled enrolment can
            # be recovered through this worker object.
            enrollment.buffer[:] = b"\0" * len(enrollment.buffer)
            enrollment.buffer.clear()
            try:
                enrollment.tracker.close()
            except Exception:
                logger.exception("Could not release speaker enrollment tracker")
        if self._live_speaker_enrollment_heavy_lock_owned:
            self._live_speaker_enrollment_heavy_lock_owned = False
            self._heavy_work_lock.release()

    def _parse_live_speaker_enrollment_start(
        self, params: dict[str, Any]
    ) -> tuple[_LiveProjectSession, int]:
        from .live_caption.speaker import LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS

        allowed = {
            "project_id",
            "expected_speaker_count",
            "target_slot",
            "tracker_snapshot",
        }
        unknown = set(params) - allowed
        if unknown:
            raise ValueError(
                f"live.speaker_enroll.start 有未知參數：{', '.join(sorted(unknown))}"
            )
        project_id = Worker._canonical_live_project_id(self._required(params, "project_id"))
        expected = params.get("expected_speaker_count")
        if (
            isinstance(expected, bool)
            or not isinstance(expected, int)
            or not 1 <= expected <= LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS
        ):
            raise ValueError(
                "expected_speaker_count 必須係 1 至 "
                f"{LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS}"
            )
        raw_snapshot = params.get("tracker_snapshot")
        if raw_snapshot is not None and not isinstance(raw_snapshot, dict):
            raise ValueError("tracker_snapshot 必須係 object")
        slot = params.get("target_slot")
        if isinstance(slot, bool) or not isinstance(slot, int) or not 0 <= slot < expected:
            raise ValueError("target_slot 必須係 0 至 expected_speaker_count - 1")
        return (
            _LiveProjectSession(
                project_id=project_id,
                expected_speaker_count=expected,
                tracker_snapshot=None if raw_snapshot is None else dict(raw_snapshot),
            ),
            slot,
        )

    def _live_speaker_enroll_start(self, params: dict[str, Any]) -> dict[str, Any]:
        project, target_slot = self._parse_live_speaker_enrollment_start(params)
        with self._live_lock:
            if self._live_worker is not None and str(
                self._live_worker.state.value
            ) in {"running", "stopping"}:
                raise ValueError("請先停止即時字幕，再註冊講者")
            if self._live_speaker_enrollment is not None:
                raise ValueError("已有講者註冊進行中")
            if not self._heavy_work_lock.acquire(blocking=False):
                raise ValueError("另一項轉錄／模型工作進行中；稍後再註冊講者")
            self._live_speaker_enrollment_heavy_lock_owned = True
            tracker = None
            try:
                from .live_caption import (
                    LiveSpeakerTracker,
                    SherpaSpeakerEmbeddingEngine,
                )

                speaker_path = (
                    self.models.path_for(SPEAKER_EMBEDDING_ID)
                    / SPEAKER_EMBEDDING_FILENAME
                )
                if self._live_speaker_factory is None:
                    engine = SherpaSpeakerEmbeddingEngine(
                        speaker_path,
                        num_threads=2,
                    )
                    tracker = LiveSpeakerTracker(engine)
                else:
                    tracker = self._live_speaker_factory(speaker_path)
                tracker.set_expected_speaker_count(
                    project.expected_speaker_count
                )
                model_sha256 = self._speaker_model_sha256(tracker, speaker_path)
                if model_sha256 is None:
                    raise ValueError("無法驗證本機 speaker model SHA-256")
                if project.tracker_snapshot is not None:
                    profiles = project.tracker_snapshot.get("profiles")
                    if not isinstance(profiles, list):
                        raise ValueError("tracker_snapshot profiles 必須係 list")
                    if len(profiles) > project.expected_speaker_count:
                        raise ValueError(
                            "tracker_snapshot profiles 不可多過 expected_speaker_count"
                        )
                    tracker.restore_project_snapshot(
                        project.tracker_snapshot,
                        project_id=project.project_id,
                        embedding_model_key=SPEAKER_EMBEDDING_ID,
                        embedding_model_sha256=model_sha256,
                        # Sequential enrollment persists after each person.
                        # A contiguous Speaker 1..N prefix is therefore valid
                        # here, but normal live.start still uses the strict
                        # default and rejects every incomplete roster.
                        require_complete=False,
                    )
                enrollment = _LiveSpeakerEnrollmentSession(
                    session_id=str(uuid.uuid4()),
                    project=_LiveProjectSession(
                        project_id=project.project_id,
                        expected_speaker_count=project.expected_speaker_count,
                        tracker_snapshot=project.tracker_snapshot,
                        embedding_model_sha256=model_sha256,
                    ),
                    target_slot=target_slot,
                    tracker=tracker,
                    embedding_model_sha256=model_sha256,
                    buffer=bytearray(),
                )
                tracker = None
                self._live_speaker_enrollment = enrollment
                return {
                    "status": self._live_speaker_enrollment_status_value(enrollment)
                }
            finally:
                if tracker is not None:
                    try:
                        tracker.close()
                    except Exception:
                        logger.exception("Could not release failed speaker enrollment tracker")
                if self._live_speaker_enrollment is None:
                    self._close_live_speaker_enrollment()

    def _require_live_speaker_enrollment(
        self, params: dict[str, Any]
    ) -> _LiveSpeakerEnrollmentSession:
        session_id = self._required(params, "session_id")
        enrollment = self._live_speaker_enrollment
        if enrollment is None or enrollment.session_id != session_id:
            raise ValueError("講者註冊 session 已失效，請重新開始")
        return enrollment

    def _live_speaker_enroll_push(self, params: dict[str, Any]) -> dict[str, Any]:
        unknown = set(params) - {"session_id", "pcm16_base64"}
        if unknown:
            raise ValueError(
                f"live.speaker_enroll.push 有未知參數：{', '.join(sorted(unknown))}"
            )
        with self._live_lock:
            enrollment = self._require_live_speaker_enrollment(params)
            encoded = self._required(params, "pcm16_base64")
            if len(encoded) > 12_000:
                raise ValueError("PCM frame 超過 200ms 資源上限")
            try:
                frame = base64.b64decode(encoded, validate=True)
            except (binascii.Error, ValueError) as exc:
                raise ValueError("pcm16_base64 格式無效") from exc
            maximum_bytes = int(enrollment.maximum_seconds * 16_000 * 2) + 2
            if len(enrollment.buffer) + len(frame) > maximum_bytes:
                self._close_live_speaker_enrollment()
                raise ValueError("講者註冊超過 15 秒上限，請重新開始")
            enrollment.buffer.extend(frame)
            return {
                "accepted": True,
                "status": self._live_speaker_enrollment_status_value(enrollment),
            }

    def _live_speaker_enroll_stop(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"session_id"}:
            raise ValueError("live.speaker_enroll.stop 只接受 session_id")
        with self._live_lock:
            enrollment = self._require_live_speaker_enrollment(params)
            result = enrollment.tracker.enroll_pcm16(
                bytes(enrollment.buffer),
                target_slot=enrollment.target_slot,
            )
            snapshot = enrollment.tracker.export_project_snapshot(
                project_id=enrollment.project.project_id,
                embedding_model_key=SPEAKER_EMBEDDING_ID,
                embedding_model_sha256=enrollment.embedding_model_sha256,
            )
            status = {
                **result,
                "state": "completed",
                "session_id": enrollment.session_id,
                "project_id": enrollment.project.project_id,
                "speaker_tracking_model": SPEAKER_EMBEDDING_ID,
                "offline": True,
            }
            self._close_live_speaker_enrollment()
            return {
                "status": status,
                "profile_update": {
                    "project_id": enrollment.project.project_id,
                    "snapshot": snapshot,
                },
            }

    def _live_speaker_enroll_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"session_id"}:
            raise ValueError("live.speaker_enroll.cancel 只接受 session_id")
        with self._live_lock:
            enrollment = self._require_live_speaker_enrollment(params)
            status = {
                "state": "cancelled",
                "session_id": enrollment.session_id,
                "project_id": enrollment.project.project_id,
                "target_slot": enrollment.target_slot,
                "speaker_tracking_model": SPEAKER_EMBEDDING_ID,
                "offline": True,
            }
            self._close_live_speaker_enrollment()
            return {"status": status}

    def _live_start(self, params: dict[str, Any]) -> dict[str, Any]:
        start_options = self._parse_live_project_start(params)
        project_request = start_options.project
        logger.info(
            "Live session start mode=%s assistant_runtime_enabled=%s interview_enabled=%s auto_concept=%s answer_mode=%s",
            "project" if project_request is not None else "captions_only",
            bool(getattr(start_options.assistant_config, "runtime_enabled", False)),
            bool(
                getattr(
                    getattr(start_options.assistant_config, "interview", None),
                    "enabled",
                    False,
                )
            ),
            bool(
                getattr(
                    start_options.assistant_config,
                    "automatic_concept_detection_enabled",
                    False,
                )
            ),
            str(getattr(start_options.assistant_config, "answer_mode", "unknown")),
        )
        with self._live_lock:
            if self._live_worker is not None:
                state = str(self._live_worker.state.value)
                if state in {"running", "stopping"}:
                    raise ValueError("已有即時字幕 session 正在運行")
                self._clear_terminal_live_sensitive_state(self._live_worker)
                self._live_worker = None
                self._close_live_assistant()
                self._live_session_id = None
                self._live_project_session = None
                self._live_correction_entries = ()
                self._live_hk_normalizer = None
                self._live_speaker_tracking_available = False
                self._live_speaker_tracking_error = None
                self._live_asr_mode = "dual_whisper"
            if not self._heavy_work_lock.acquire(blocking=False):
                raise ValueError("另一項轉錄／模型工作進行中；完成或取消後先開始即時字幕")
            self._live_heavy_lock_owned = True
            engine: Any | None = None
            final_engine: Any | None = None
            speaker_engine: Any | None = None
            speaker_tracker: Any | None = None
            live_assistant: Any | None = None
            live_assistant_runtime: Any | None = None
            timing_archive: Any | None = None
            live_assistant_prepared = False
            project_session = project_request
            try:
                from .live_caption import (
                    EnergyVADConfig,
                    LiveCaptionConfig,
                    LiveCaptionProcessor,
                    LocalInterviewCoordinator,
                    LocalLiveAssistantCoordinator,
                    LiveAssistantRuntimeManager,
                    LiveTimingArchive,
                    LiveSpeakerTracker,
                    LiveCaptionWorker,
                    SherpaSpeakerEmbeddingEngine,
                    WhisperCppLiveEngine,
                    read_total_memory_bytes,
                    should_use_lightweight_live_asr,
                )
                from .normalization import HongKongNormalizer

                if self._live_engine_factory is None:
                    partial_model = (
                        self.models.require_local(WHISPER_SMALL_ID)
                        / WHISPER_SMALL_FILENAME
                    )
                    lightweight_asr = should_use_lightweight_live_asr(
                        bool(
                            getattr(
                                start_options.assistant_config,
                                "runtime_enabled",
                                False,
                            )
                        ),
                        read_total_memory_bytes(),
                    )
                    self._live_asr_mode = (
                        "lightweight_answer" if lightweight_asr else "dual_whisper"
                    )
                    engine = WhisperCppLiveEngine(
                        partial_model,
                        language="zh",
                        maximum_audio_seconds=10.0,
                    )
                    if lightweight_asr:
                        # Validated 16 GB configuration: one resident Small
                        # server leaves enough free memory for the optional
                        # E2B answer lease, which dual Whisper cannot do.
                        final_engine = engine
                    else:
                        final_model = (
                            self.models.require_local(WHISPER_LARGE_V3_ID)
                            / WHISPER_LARGE_V3_FILENAME
                        )
                        # The fast multilingual Small pass is only provisional.
                        # Each VAD-finalized utterance is resolved by Large v3
                        # with its dedicated Cantonese language token, so the
                        # final transcript never adopts the Small model's common
                        # Cantonese character substitutions as its source of
                        # truth.  Both whisper-server children hold their model
                        # once per live session and keep Metal enabled.
                        try:
                            final_engine = WhisperCppLiveEngine(
                                final_model,
                                language="yue",
                                maximum_audio_seconds=10.0,
                            )
                        except Exception:
                            engine.close()
                            engine = None
                            raise
                else:
                    # Test/custom injection intentionally keeps its historical
                    # single-engine contract.  Production is the only path
                    # that starts both resident Whisper roles.
                    engine = self._live_engine_factory(self.models.path_for(WHISPER_SMALL_ID))
                    final_engine = engine
                    self._live_asr_mode = "injected_engine"
                speaker_path = (
                    self.models.path_for(SPEAKER_EMBEDDING_ID)
                    / SPEAKER_EMBEDDING_FILENAME
                )
                # Plain live captions deliberately skip the speaker model.
                # Only an explicitly selected, fully enrolled Lazy Camman
                # project is allowed to allocate or receive voice features.
                if project_session is not None:
                    try:
                        if self._live_speaker_factory is None:
                            speaker_directory = self.models.require_local(SPEAKER_EMBEDDING_ID)
                            speaker_engine = SherpaSpeakerEmbeddingEngine(
                                speaker_directory / SPEAKER_EMBEDDING_FILENAME,
                                num_threads=2,
                            )
                            speaker_tracker = LiveSpeakerTracker(speaker_engine)
                        else:
                            speaker_tracker = self._live_speaker_factory(speaker_path)
                    except Exception as exc:
                        if speaker_engine is not None and speaker_tracker is None:
                            try:
                                speaker_engine.close()
                            except Exception:
                                logger.exception(
                                    "Could not release unavailable live speaker engine"
                                )
                            speaker_engine = None
                        raise ValueError(
                            "拍攝 project 無法啟動本機講者辨識；請先驗證 speaker model"
                        ) from exc
                if speaker_tracker is not None:
                    setter = getattr(speaker_tracker, "set_expected_speaker_count", None)
                    if start_options.expected_speaker_count is not None and not callable(setter):
                        raise ValueError("本機 speaker tracker 不支援 expected speaker count")
                    if callable(setter):
                        setter(start_options.expected_speaker_count)
                if project_session is not None:
                    if speaker_tracker is None:
                        raise ValueError("拍攝 project 需要本機講者辨識 model")
                    model_sha256 = self._speaker_model_sha256(
                        speaker_tracker,
                        speaker_path,
                    )
                    if model_sha256 is None:
                        raise ValueError("無法驗證本機 speaker model SHA-256")
                    start_snapshot = project_session.tracker_snapshot
                    project_session = _LiveProjectSession(
                        project_id=project_session.project_id,
                        expected_speaker_count=project_session.expected_speaker_count,
                        # The Swift-decrypted start snapshot is only needed for
                        # this restore call.  Do not retain it in the Worker
                        # project session, callback closure, or terminal state.
                        tracker_snapshot=None,
                        embedding_model_sha256=model_sha256,
                    )
                    if start_snapshot is None:  # parser enforces this; fail closed defensively
                        raise ValueError("project live.start 必須提供完整 tracker_snapshot")
                    expected_speaker_count = project_session.expected_speaker_count
                    if expected_speaker_count is None:
                        raise ValueError(
                            "project tracker_snapshot 必須指定 expected_speaker_count"
                        )
                    profiles = start_snapshot.get("profiles")
                    if not isinstance(profiles, list):
                        raise ValueError("tracker_snapshot profiles 必須係 list")
                    if len(profiles) != expected_speaker_count:
                        raise ValueError(
                            "tracker_snapshot profiles 必須等於 expected_speaker_count"
                        )
                    restore = getattr(speaker_tracker, "restore_project_snapshot", None)
                    if not callable(restore):
                        raise ValueError("本機 speaker tracker 不支援 project snapshot")
                    restore(
                        start_snapshot,
                        project_id=project_session.project_id,
                        embedding_model_key=SPEAKER_EMBEDDING_ID,
                        embedding_model_sha256=model_sha256,
                    )
                    if not bool(getattr(speaker_tracker, "enrolled_roster_complete", False)):
                        raise ValueError("project speaker roster 未完整載入")
                self._live_speaker_tracking_available = speaker_tracker is not None

                # ASR and (for Lazy Camman) the enrolled-speaker engine always
                # get memory priority.  Only after those local engines are
                # resident may the optional, session-scoped AI Cue acquire its
                # small E2B lease.  Both memory readings therefore describe
                # the real concurrent working set.  A rejected/missing local
                # runtime merely makes the cue unavailable; captions continue.
                if bool(
                    getattr(start_options.assistant_config, "runtime_enabled", False)
                ):
                    if self._live_assistant_runtime_factory is None:
                        live_assistant_runtime = LiveAssistantRuntimeManager(
                            start_options.assistant_config
                        )
                    else:
                        live_assistant_runtime = self._live_assistant_runtime_factory(
                            start_options.assistant_config
                        )
                    prepare = getattr(live_assistant_runtime, "prepare", None)
                    if callable(prepare):
                        try:
                            prepared_value = prepare()
                            live_assistant_prepared = bool(
                                isinstance(prepared_value, Mapping)
                                and prepared_value.get("prepared") is True
                            )
                        except Exception:
                            # The optional runtime boundary must not expose a
                            # model error or interrupt the microphone path.
                            live_assistant_prepared = False
                correction_entries = tuple(self._correction_memory.entries())
                normalizer = HongKongNormalizer(
                    entry.canonical for entry in correction_entries
                )
                processor = LiveCaptionProcessor(
                    engine,
                    final_engine=final_engine,
                    config=LiveCaptionConfig(
                        maximum_frame_ms=200,
                        # Small stays ahead of microphone capture for rolling
                        # draft text; final Large v3 work is bounded to 8s so
                        # a long monologue cannot stall the live queue.
                        partial_interval_ms=1_000,
                        minimum_partial_audio_ms=700,
                        maximum_utterance_seconds=8.0,
                        pre_roll_ms=200,
                        vad=EnergyVADConfig(
                            min_speech_ms=100,
                            min_silence_ms=300,
                        ),
                    ),
                    # Keep raw model text until the RPC drain so every final can
                    # carry a replayable raw/HK/correction audit. Partials are
                    # HK-normalized there but never receive alias replacement.
                    normalizer=lambda text: text,
                    speaker_tracker=speaker_tracker,
                )
                session_id = str(uuid.uuid4())
                if start_options.timing_archive_enabled:
                    # Explicit setup-time opt-in: raw microphone PCM stays in
                    # a private local staging area until a normal Stop finalizes
                    # its hash/checkable lineage. It never changes captions.
                    timing_archive = LiveTimingArchive.create(
                        runtime_root=self.paths.runtime,
                        jobs_root=self.paths.jobs,
                        session_id=session_id,
                        sample_rate_hz=processor.config.sample_rate,
                    )
                snapshot_supplier: Callable[[], dict[str, Any]] | None = None
                if project_session is not None and speaker_tracker is not None:
                    if project_session.embedding_model_sha256 is None:  # defensive
                        raise ValueError("project speaker model SHA-256 缺失")

                    def snapshot_supplier() -> dict[str, Any]:
                        export = getattr(speaker_tracker, "export_project_snapshot", None)
                        if not callable(export):
                            raise RuntimeError("本機 speaker tracker 不支援 project snapshot")
                        return export(
                            project_id=project_session.project_id,
                            embedding_model_key=SPEAKER_EMBEDDING_ID,
                            embedding_model_sha256=project_session.embedding_model_sha256,
                        )

                live_worker = LiveCaptionWorker(
                    processor,
                    # Large v3 final decoding can take several seconds on an
                    # M1, especially immediately after another real-model
                    # live smoke.  Ten seconds costs only ~320 KiB of PCM but
                    # prevents a valid microphone-paced stream from dropping
                    # the next sentence while a correct final is produced.
                    # The queue remains at LiveCaptionWorker's hard maximum.
                    maximum_pending_audio_seconds=10.0,
                    maximum_pending_events=128,
                    on_clean_stop=snapshot_supplier,
                    timing_archive=timing_archive,
                )
                # The cue client starts only after the app-managed runtime
                # has passed both memory gates.  It receives finalized text
                # only and remains fully asynchronous to live ASR.
                interview_enabled = bool(
                    getattr(
                        getattr(start_options.assistant_config, "interview", None),
                        "enabled",
                        False,
                    )
                )
                if interview_enabled:
                    # Manual question navigation remains usable even if the
                    # optional E2B runtime/memory gate is unavailable.  Only
                    # analysis is disabled in that state; captions continue.
                    if self._live_interview_factory is None:
                        live_assistant = LocalInterviewCoordinator(
                            start_options.assistant_config,
                            analysis_available=live_assistant_prepared,
                        )
                    else:
                        live_assistant = self._live_interview_factory(
                            start_options.assistant_config,
                            live_assistant_prepared,
                        )
                elif live_assistant_prepared:
                    if self._live_assistant_factory is None:
                        live_assistant = LocalLiveAssistantCoordinator(
                            start_options.assistant_config
                        )
                    else:
                        live_assistant = self._live_assistant_factory(
                            start_options.assistant_config
                        )
                live_worker.start()
                self._live_worker = live_worker
                self._live_assistant = live_assistant
                self._live_assistant_runtime = live_assistant_runtime
                self._live_session_id = session_id
                self._live_project_session = project_session
                self._live_correction_entries = correction_entries
                self._live_hk_normalizer = normalizer
                return self._live_status_value()
            except Exception:
                if timing_archive is not None:
                    try:
                        timing_archive.abort()
                    except Exception:
                        logger.warning("Could not discard failed live timing archive")
                if live_assistant is not None:
                    close = getattr(live_assistant, "close", None)
                    if callable(close):
                        try:
                            close()
                        except Exception:
                            logger.warning("Could not release failed live assistant")
                if live_assistant_runtime is not None:
                    release = getattr(live_assistant_runtime, "release", None)
                    if callable(release):
                        try:
                            release()
                        except Exception:
                            logger.warning("Could not release failed local live AI runtime")
                if speaker_tracker is not None:
                    try:
                        speaker_tracker.close()
                    except Exception:
                        logger.exception("Could not release failed live speaker tracker")
                if final_engine is not None and final_engine is not engine:
                    try:
                        final_engine.close()
                    except Exception:
                        logger.exception("Could not release failed live final Whisper engine")
                if engine is not None:
                    try:
                        engine.close()
                    except Exception:
                        logger.exception("Could not release failed live caption engine")
                self._live_worker = None
                self._live_assistant = None
                self._live_assistant_runtime = None
                self._live_session_id = None
                self._live_project_session = None
                self._live_asr_mode = "dual_whisper"
                self._live_correction_entries = ()
                self._live_hk_normalizer = None
                self._live_speaker_tracking_available = False
                self._live_speaker_tracking_error = None
                self._release_live_heavy_lock()
                raise

    def _live_push(self, params: dict[str, Any]) -> dict[str, Any]:
        unknown = set(params) - {"session_id", "pcm16_base64"}
        if unknown:
            raise ValueError(f"live.push 有未知參數：{', '.join(sorted(unknown))}")
        with self._live_lock:
            worker = self._require_live_session(params)
            encoded = self._required(params, "pcm16_base64")
            if len(encoded) > 12_000:
                raise ValueError("PCM frame 超過 200ms 資源上限")
            try:
                frame = base64.b64decode(encoded, validate=True)
            except (binascii.Error, ValueError) as exc:
                raise ValueError("pcm16_base64 格式無效") from exc
            accepted = worker.push_pcm16(frame)
            return {
                "accepted": accepted,
                "session_id": self._live_session_id,
                "state": str(worker.state.value),
                "pending_audio_seconds": float(worker.stats().pending_audio_seconds),
            }

    def _live_poll(self, params: dict[str, Any]) -> dict[str, Any]:
        unknown = set(params) - {"session_id", "maximum"}
        if unknown:
            raise ValueError(f"live.poll 有未知參數：{', '.join(sorted(unknown))}")
        raw_maximum = params.get("maximum", 64)
        if (
            isinstance(raw_maximum, bool)
            or not isinstance(raw_maximum, int)
            or not 1 <= raw_maximum <= 128
        ):
            raise ValueError("maximum 必須係 1 至 128")
        with self._live_lock:
            worker = self._require_live_session(params)
            terminal = str(worker.state.value) in {"stopped", "cancelled", "failed"}
            try:
                events = self._live_event_values(
                    worker.poll_events(None if terminal else raw_maximum)
                )
                terminal = terminal or str(worker.state.value) in {
                    "stopped",
                    "cancelled",
                    "failed",
                }
                if not terminal:
                    # This is the sole live-assistant ingress. ``events`` has
                    # already passed HK normalization + correction memory, and
                    # the helper ignores every non-final caption.
                    self._live_assistant_observe_final_values(events)
                assistant_events = self._live_assistant_event_values(
                    include_pending=not terminal
                )
                if terminal:
                    self._cancel_live_assistant_request()
                return {
                    "events": events,
                    "assistant_events": assistant_events,
                    "status": self._live_status_value(),
                }
            finally:
                self._clear_terminal_live_sensitive_state(worker)

    def _live_stop(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"session_id"}:
            raise ValueError("live.stop 只接受 session_id")
        with self._live_lock:
            worker = self._require_live_session(params)
            try:
                worker.stop(timeout=15.0)
            except Exception:
                discard_timing_archive = getattr(worker, "discard_timing_archive", None)
                if callable(discard_timing_archive):
                    discard_timing_archive()
                raise
            # Capture both one-shot values before the terminal cleanup below.
            # Neither survives this RPC call.
            project = self._live_project_session
            take_snapshot = getattr(worker, "take_profile_snapshot", None)
            snapshot = take_snapshot() if callable(take_snapshot) else None
            timing_archive_status = (
                worker.timing_archive_status()
                if callable(getattr(worker, "timing_archive_status", None))
                else self._idle_live_timing_archive_status()
            )
            take_timing_archive = getattr(worker, "take_timing_archive_prepared", None)
            prepared_timing_archive = (
                take_timing_archive() if callable(take_timing_archive) else None
            )
            if prepared_timing_archive is not None:
                try:
                    timing_archive_status = prepared_timing_archive.publish().status_value()
                except Exception as exc:
                    # A receipt which failed its own read-back never becomes a
                    # usable timing input. Caption stop still succeeds, but
                    # the operator gets a visible failed archive state.
                    abort_cleanup_succeeded = prepared_timing_archive.abort()
                    from .live_caption.timing_archive import (
                        LiveTimingArchivePublicationError,
                    )

                    error_code = "publish_or_verify_failed"
                    if (
                        isinstance(exc, LiveTimingArchivePublicationError)
                        and not exc.raw_audio_cleanup_succeeded
                    ) or not abort_cleanup_succeeded:
                        error_code = "publish_cleanup_failed_possible_local_retention"
                    timing_archive_status = {
                        **timing_archive_status,
                        "state": "failed",
                        "integrity_scope": None,
                        "source_audio_sha256": None,
                        "manifest_sha256": None,
                        "detached_receipt_sha256": None,
                        "durability_warning": None,
                        "error_code": error_code,
                    }
            try:
                events = self._live_event_values(worker.poll_events())
                # Do not launch a fresh cue while a session is ending. A cue
                # that completed before Stop is still surfaced, but pending
                # work is filtered and then invalidated by terminal cleanup.
                assistant_events = self._live_assistant_event_values(
                    include_pending=False
                )
                self._cancel_live_assistant_request()
                value = {
                    "events": events,
                    "assistant_events": assistant_events,
                    "status": self._live_status_value(),
                }
                status_value = value.get("status")
                if isinstance(status_value, dict):
                    status_value["timing_archive"] = timing_archive_status
                if (
                    project is not None
                    and str(worker.state.value) == "stopped"
                    and isinstance(snapshot, dict)
                ):
                    # This is the only RPC response that hands the native app a
                    # project voiceprint payload. Poll/cancel/error never do.
                    value["profile_update"] = {
                        "project_id": project.project_id,
                        "snapshot": dict(snapshot),
                    }
                return value
            finally:
                self._clear_terminal_live_sensitive_state(
                    worker,
                    discard_profile_snapshot=False,
                )

    def _live_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"session_id"}:
            raise ValueError("live.cancel 只接受 session_id")
        with self._live_lock:
            worker = self._require_live_session(params)
            worker.cancel(timeout=5.0)
            try:
                events = self._live_event_values(worker.poll_events())
                assistant_events = self._live_assistant_event_values(
                    include_pending=False
                )
                self._cancel_live_assistant_request()
                return {
                    "events": events,
                    "assistant_events": assistant_events,
                    "status": self._live_status_value(),
                }
            finally:
                self._clear_terminal_live_sensitive_state(worker)

    def _live_assistant_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        """Cancel only an in-flight AI cue, never the live caption session."""

        if set(params) != {"session_id"}:
            raise ValueError("live.assistant.cancel 只接受 session_id")
        with self._live_lock:
            self._require_live_session(params)
            assistant = self._live_assistant
            if assistant is None:
                return {"cancelled": False, "assistant": self._live_assistant_status_value()}
            return {
                "cancelled": self._cancel_live_assistant_request(),
                "assistant": self._live_assistant_status_value(),
            }

    def _live_interview_command(self, params: dict[str, Any]) -> dict[str, Any]:
        """Apply one user-authored interview command with an optional close fence."""

        if set(params) != {"session_id", "action", "expected_revision"}:
            raise ValueError(
                "live.interview.command 只接受 session_id、action 同 expected_revision"
            )
        with self._live_lock:
            live_worker = self._require_live_session(params)
            assistant = self._live_assistant
            command = getattr(assistant, "command", None)
            if assistant is None or not callable(command):
                raise ValueError("今次即時字幕 session 未啟用 Interview Coach")
            events: list[dict[str, Any]] = []
            action = params["action"]
            if action == "finish_answer":
                # Fail closed before touching the worker-owned FIFO.  The
                # coordinator repeats this guard inside ``command`` below as
                # the TOCTOU defence, but a stale click must not first flush
                # a normal caption event and make it Coach evidence.
                status = getattr(assistant, "status", None)
                if not callable(status):
                    raise ValueError("Interview Coach status 無效")
                before_status = status()
                before_finish = (
                    before_status.get("interview")
                    if isinstance(before_status, Mapping)
                    else None
                )
                expected_revision = params["expected_revision"]
                if isinstance(expected_revision, bool) or not isinstance(
                    expected_revision, int
                ):
                    raise ValueError("expected_revision 必須係整數")
                if not isinstance(before_finish, Mapping):
                    raise ValueError("Interview Coach status 無效")
                if before_finish.get("revision") != expected_revision:
                    raise ValueError("interview revision 已失效；請重新讀取 status")
                if before_finish.get("answer_capture_active") is not True:
                    # Never drain normal caption events for a stale/duplicate
                    # Finish Answer click.  The rejection must be a no-op so
                    # existing captions remain available to ``live.poll``.
                    raise ValueError("而家未開始收答案")
                flush = getattr(live_worker, "flush_current_utterance", None)
                if not callable(flush):
                    raise ValueError("即時字幕 worker 未支援完成呢題")
                # The Swift transport has already drained earlier PCM before
                # this RPC is written.  This second, worker-owned fence waits
                # for that FIFO audio to be decoded and finalized.  Crucially,
                # finals enter the coordinator while answer capture is still
                # active; only then can the manual finish command close it.
                flush(timeout=15.0)
                events = self._live_event_values(live_worker.poll_events())
                self._live_assistant_observe_final_values(events)
            stats = live_worker.stats()
            interview = command(
                action,
                expected_revision=params["expected_revision"],
                capture_boundary_sample_index=int(stats.captured_sample_index),
                capture_boundary_sample_rate_hz=int(stats.sample_rate_hz),
            )
            if not isinstance(interview, Mapping):
                raise ValueError("Interview Coach status 無效")
            # Immediate read-back uses the exact same merged runtime/coordinator
            # status contract as live.status and live.poll.
            assistant_status = self._live_assistant_status_value()
            return {
                "interview": dict(interview),
                "assistant": assistant_status,
                # A finish drains the same normal caption event buffer as
                # ``live.poll``.  Return those events in this response so the
                # native UI can render/persist them instead of silently losing
                # the final it just fenced for Coach evidence.
                "events": events,
                "assistant_events": self._live_assistant_event_values(),
                "status": self._live_status_value(),
            }

    def _live_status(self, params: dict[str, Any]) -> dict[str, Any]:
        unknown = set(params) - {"session_id"}
        if unknown:
            raise ValueError(f"live.status 有未知參數：{', '.join(sorted(unknown))}")
        with self._live_lock:
            supplied = params.get("session_id")
            if supplied is not None and supplied != self._live_session_id:
                raise ValueError("即時字幕 session 已失效，請重新開始")
            worker = self._live_worker
            try:
                return self._live_status_value()
            finally:
                if worker is not None:
                    self._clear_terminal_live_sensitive_state(worker)

    def _present(self, job: Any) -> dict[str, Any]:
        return present_job(job)

    def _job_get(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._present(_call(self.jobs, ("get", "get_job"), self._required(params, "id")))

    def _jobs_list(self, params: dict[str, Any]) -> dict[str, Any]:
        records = _call(self.jobs, ("list", "list_jobs"))
        return {"jobs": [self._present(record) for record in records]}

    @staticmethod
    def _correction_entry_value(entry: Any) -> dict[str, Any]:
        return entry.to_json()

    def _corrections_clear(self, params: dict[str, Any]) -> dict[str, Any]:
        if params:
            raise ValueError("corrections.clear 不接受參數")
        self._correction_memory.clear()
        result = self._corrections_list({})
        result["cleared"] = True
        return result

    def _corrections_list(self, params: dict[str, Any]) -> dict[str, Any]:
        if params:
            raise ValueError("corrections.list 不接受參數")
        return {
            "entries": [
                self._correction_entry_value(entry)
                for entry in self._correction_memory.entries()
            ],
            "path": str(self._correction_memory.path),
            "local_only": True,
            "free_form_rewrite": False,
            "automatic_application": True,
            "automatic_application_policy": AUTOMATIC_APPLICATION_POLICY,
        }

    def _corrections_export(self, params: dict[str, Any]) -> dict[str, Any]:
        path = self._required(params, "path")
        overwrite_confirmed = params.get("overwrite_confirmed", False)
        if set(params) != {"path", "overwrite_confirmed"}:
            raise ValueError("corrections.export 只接受 path 同 overwrite_confirmed")
        if not isinstance(overwrite_confirmed, bool):
            raise ValueError("overwrite_confirmed 必須係布林值")
        destination = self._correction_memory.export_to_path(
            path,
            overwrite_confirmed=overwrite_confirmed,
        )
        return {
            "exported": True,
            "path": str(destination),
            "entry_count": len(self._correction_memory.entries()),
            "local_only": True,
        }

    def _corrections_import(self, params: dict[str, Any]) -> dict[str, Any]:
        path = self._required(params, "path")
        if set(params) != {"path"}:
            raise ValueError("corrections.import 只接受 path")
        self._correction_memory.import_from_path(path)
        result = self._corrections_list({})
        result["imported"] = True
        return result

    def _corrections_remember(self, params: dict[str, Any]) -> dict[str, Any]:
        canonical = self._required(params, "canonical")
        aliases = params.get("aliases", [])
        if not isinstance(aliases, list) or not all(
            isinstance(item, str) for item in aliases
        ):
            raise ValueError("aliases 必須係文字 array")
        unknown = set(params) - {"canonical", "aliases"}
        if unknown:
            raise ValueError(f"未知 corrections.remember 參數：{', '.join(sorted(unknown))}")
        entry = self._correction_memory.remember(
            canonical=canonical,
            aliases=aliases,
            source="manual_alias",
        )
        return {"learned": True, "entry": self._correction_entry_value(entry)}

    def _corrections_remember_edit(self, params: dict[str, Any]) -> dict[str, Any]:
        before = self._required(params, "before")
        after = self._required(params, "after")
        unknown = set(params) - {"before", "after"}
        if unknown:
            raise ValueError(
                f"未知 corrections.remember_edit 參數：{', '.join(sorted(unknown))}"
            )
        if not self.settings_store.get().correction_memory_learning_enabled:
            return {"learned": False, "entry": None, "disabled": True}
        entry = self._correction_memory.remember_accepted_edit(before, after)
        return {
            "learned": entry is not None,
            "entry": (
                self._correction_entry_value(entry) if entry is not None else None
            ),
        }

    def _corrections_delete(self, params: dict[str, Any]) -> dict[str, Any]:
        canonical = self._required(params, "canonical")
        if set(params) != {"canonical"}:
            raise ValueError("corrections.delete 只接受 canonical")
        return {"deleted": self._correction_memory.delete(canonical)}

    @staticmethod
    def _derived_segment_value(item: Mapping[str, Any], index: int) -> dict[str, Any]:
        raw_start = item.get("start")
        raw_end = item.get("end")
        if not isinstance(raw_start, (int, float)) or isinstance(raw_start, bool):
            raw_start_ms = item.get("start_ms")
            raw_start = (
                float(raw_start_ms) / 1_000.0
                if isinstance(raw_start_ms, (int, float)) and not isinstance(raw_start_ms, bool)
                else 0.0
            )
        if not isinstance(raw_end, (int, float)) or isinstance(raw_end, bool):
            raw_end_ms = item.get("end_ms")
            raw_end = (
                float(raw_end_ms) / 1_000.0
                if isinstance(raw_end_ms, (int, float)) and not isinstance(raw_end_ms, bool)
                else raw_start
            )
        return {
            "id": f"s{index}",
            "start": raw_start,
            "end": raw_end,
            "text": item.get("chosen_text") or item.get("text") or item.get("final_text") or "",
        }

    def _transcript_insight_source(
        self,
        job_id: str,
        job: Any | None = None,
    ) -> tuple[TranscriptInsightInput, str, Path, Any]:
        resolved_job = job or _call(self.jobs, ("get", "get_job"), job_id)
        document, final_sha, workspace = self._subtitle_projects.load_final_document(
            job_id,
            resolved_job,
        )
        raw_segments = document.get("segments")
        if not isinstance(raw_segments, list) or not raw_segments:
            raw_segments = document.get("subtitle_segments")
        segments = tuple(
            self._derived_segment_value(item, index)
            for index, item in enumerate(raw_segments or [])
            if isinstance(item, Mapping)
        )
        transcript = document.get("text", document.get("final_transcript"))
        if not isinstance(transcript, str) or not transcript.strip():
            transcript = "".join(str(item.get("text") or "") for item in segments)
        job_value = _jsonable(resolved_job)
        metadata = job_value.get("metadata")
        vocabulary = metadata.get("vocabulary", ()) if isinstance(metadata, Mapping) else ()
        if not isinstance(vocabulary, (list, tuple)):
            vocabulary = ()
        source_path = document.get("source_path") or job_value.get("source_path") or ""
        filename = Path(source_path).name if isinstance(source_path, str) and source_path else ""
        source = TranscriptInsightInput(
            transcript=transcript,
            segments=segments,
            source_filename=filename,
            language="yue-Hant-HK",
            vocabulary=tuple(item for item in vocabulary if isinstance(item, str)),
        )
        return source, final_sha, workspace, resolved_job

    def _derived_lifecycle(
        self,
        *,
        purpose: str,
    ) -> tuple[Any, str | None, list[dict[str, str]], Any]:
        settings = self.settings_store.get()
        lifecycle_events: list[dict[str, str]] = []
        try:
            lifecycle = self._derived_lifecycle_factory(
                settings.local_arbiter_model,
                api_identifier=f"cts-{purpose}",
                context_length=8_192,
                parallel=1,
                ttl_seconds=600,
            )
            configure_endpoint = getattr(lifecycle, "configure_endpoint", None)
            if callable(configure_endpoint):
                configure_endpoint(settings.local_arbiter_endpoint)
            raw_prepare = lifecycle.prepare_arbiter()
        except Exception as exc:
            lifecycle = None
            raw_prepare = {
                "status": "prepare_exception",
                "model": settings.local_arbiter_model,
                "reason": type(exc).__name__,
            }
        prepare_event = _safe_lifecycle_event(raw_prepare, phase="prepare")
        lifecycle_events.append(prepare_event)
        api_model = raw_prepare.get("api_model") if isinstance(raw_prepare, Mapping) else None
        if (
            prepare_event.get("status") not in {"loaded", "already_loaded"}
            or not isinstance(api_model, str)
            or not api_model.strip()
        ):
            api_model = None
        return lifecycle, api_model, lifecycle_events, settings

    @staticmethod
    def _release_derived_lifecycle(
        lifecycle: Any,
        lifecycle_events: list[dict[str, str]],
    ) -> bool:
        if lifecycle is None:
            return True

        prepare_status = next(
            (
                event.get("status", "unknown")
                for event in lifecycle_events
                if event.get("phase") == "prepare"
            ),
            "unknown",
        )
        release_required = prepare_status in {"loaded", "already_loaded"}
        successful_statuses = {"unloaded", "already_unloaded"}

        for attempt in range(2):
            try:
                raw_release = lifecycle.release()
            except Exception as exc:
                raw_release = {
                    "status": "release_exception",
                    "reason": type(exc).__name__,
                }
            event = _safe_lifecycle_event(
                raw_release,
                phase="release" if attempt == 0 else "release_retry",
            )
            lifecycle_events.append(event)
            if event.get("status") in successful_statuses:
                return True
            if not release_required:
                return True
        return False

    def _emit_derived(self, kind: str, job_id: str, manifest: Mapping[str, Any]) -> None:
        event = "insights.updated" if kind == "insights" else "translations.updated"
        # `artifact` is an established string field used by YouTube download
        # progress.  Keep that wire contract stable and use a dedicated JSON
        # field for transcript-derived manifests.
        self.emit(event, job_id=job_id, derived_artifact=dict(manifest))

    def _insights_get(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"id"}:
            raise ValueError("insights.get 只接受 id")
        job_id = self._required(params, "id")
        _, final_sha, workspace, _ = self._transcript_insight_source(job_id)
        return {
            "insights": self._derived_store.read(
                workspace,
                job_id,
                kind="insights",
                source_final_sha256=final_sha,
            )
        }

    def _insights_generate(self, params: dict[str, Any]) -> dict[str, Any]:
        unexpected = set(params) - {"id", "force"}
        if unexpected:
            raise ValueError(f"insights.generate 有未知參數：{', '.join(sorted(unexpected))}")
        job_id = self._required(params, "id")
        force = params.get("force", False)
        if not isinstance(force, bool):
            raise ValueError("insights force 必須係 boolean")
        _, final_sha, workspace, _ = self._transcript_insight_source(job_id)
        current = self._derived_store.read(
            workspace,
            job_id,
            kind="insights",
            source_final_sha256=final_sha,
        )
        if current.get("state") in {"queued", "generating"}:
            return {"insights": current}
        if current.get("state") == "completed" and not force:
            return {"insights": current}
        current_payload_sha = current.get("payload_sha256")
        expected_payload_sha = (
            current_payload_sha
            if isinstance(current_payload_sha, str) and len(current_payload_sha) == 64
            else None
        )
        expected_state = (
            str(current.get("state"))
            if expected_payload_sha is None and current.get("state") in {"missing", "corrupt"}
            else None
        )
        manifest = self._derived_store.prepare(
            workspace,
            job_id,
            kind="insights",
            source_final_sha256=final_sha,
            expected_payload_sha256=expected_payload_sha,
            expected_state=expected_state,
        )
        token = str(manifest["token"])
        self._derived_cancel[token] = threading.Event()
        self._derived_queue.put(("insights", job_id, None, token))
        self._emit_derived("insights", job_id, manifest)
        return {"insights": manifest}

    def _insights_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"id"}:
            raise ValueError("insights.cancel 只接受 id")
        job_id = self._required(params, "id")
        _, final_sha, workspace, _ = self._transcript_insight_source(job_id)
        current = self._derived_store.read(
            workspace,
            job_id,
            kind="insights",
            source_final_sha256=final_sha,
        )
        token = current.get("token")
        if isinstance(token, str) and current.get("state") in {"queued", "generating"}:
            self._derived_cancel.setdefault(token, threading.Event()).set()
            current = self._derived_store.update(
                workspace,
                job_id,
                kind="insights",
                token=token,
                cancel_requested=True,
            )
            self._emit_derived("insights", job_id, current)
        return {"insights": current}

    def _insights_explain(self, params: dict[str, Any]) -> dict[str, Any]:
        unexpected = set(params) - {"id", "concept", "question"}
        if unexpected:
            raise ValueError(f"insights.explain 有未知參數：{', '.join(sorted(unexpected))}")
        job_id = self._required(params, "id")
        concept = self._required(params, "concept")
        question = params.get("question", "")
        if not isinstance(question, str):
            raise ValueError("insights question 必須係文字")
        source, _, _, _ = self._transcript_insight_source(job_id)
        if not self._heavy_work_lock.acquire(blocking=False):
            return {
                "concept": ConceptExplainResult(
                    status="unavailable",
                    concept=concept,
                    reason="heavy_work_busy",
                ).to_dict()
            }
        lifecycle = None
        lifecycle_events: list[dict[str, str]] = []
        try:
            lifecycle, api_model, lifecycle_events, settings = self._derived_lifecycle(
                purpose="concept-insights"
            )
            if api_model is None:
                result = ConceptExplainResult(
                    status="unavailable",
                    concept=concept,
                    model=settings.local_arbiter_model,
                    reason=f"lifecycle_{lifecycle_events[0].get('status', 'unknown')}",
                )
            else:
                client = self._insights_client_factory(
                    endpoint=settings.local_arbiter_endpoint,
                    model=api_model,
                    timeout_seconds=90.0,
                )
                result = client.explain(ConceptExplainRequest(concept, source, question))
        finally:
            self._release_derived_lifecycle(lifecycle, lifecycle_events)
            self._heavy_work_lock.release()
        return {"concept": result.to_dict(), "lifecycle": lifecycle_events}

    def _translations_list(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"id"}:
            raise ValueError("translations.list 只接受 id")
        job_id = self._required(params, "id")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        return {
            "translations": self._derived_store.list_translations(
                workspace,
                job_id,
                source_final_sha256=project.source_final_sha256,
                project_revision=project.revision,
            )
        }

    def _translations_generate(self, params: dict[str, Any]) -> dict[str, Any]:
        unexpected = set(params) - {"id", "target_language", "force"}
        if unexpected:
            raise ValueError(f"translations.generate 有未知參數：{', '.join(sorted(unexpected))}")
        job_id = self._required(params, "id")
        target = self._required(params, "target_language")
        force = params.get("force", False)
        if not isinstance(force, bool):
            raise ValueError("translation force 必須係 boolean")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        current = self._derived_store.read(
            workspace,
            job_id,
            kind="translation",
            target_language=target,
            source_final_sha256=project.source_final_sha256,
            project_revision=project.revision,
        )
        if current.get("state") in {"queued", "generating"}:
            return {"translation": current}
        if current.get("state") in {"completed", "partial"} and not force:
            return {"translation": current}
        resume_result: Mapping[str, Any] | None = None
        resume_model: str | None = None
        if force:
            candidate = current.get("result")
            if not isinstance(candidate, Mapping):
                candidate = current.get("resume_result")
            settings = self.settings_store.get()
            lifecycle = current.get("lifecycle")
            lifecycle_models = {
                item.get("model")
                for item in lifecycle or []
                if isinstance(item, Mapping)
                and item.get("phase") == "prepare"
                and item.get("status") in {"loaded", "already_loaded"}
            }
            stored_resume_model = current.get("resume_model")
            candidate_api_model = (
                candidate.get("model")
                if isinstance(candidate, Mapping) and isinstance(candidate.get("model"), str)
                else None
            )
            candidate_cues = tuple(
                {
                    "id": cue.id,
                    "start": cue.start_ms / 1_000.0,
                    "end": cue.end_ms / 1_000.0,
                    "text": cue.text.strip(),
                }
                for cue in project.segments
                if cue.text.strip()
            )
            validated_candidate = (
                _validated_partial_translation_seed(
                    candidate,
                    candidate_cues,
                    target_language=target,
                    api_model=candidate_api_model,
                )
                if candidate_api_model is not None
                else None
            )
            if (
                isinstance(candidate, Mapping)
                and candidate.get("status") == "partial"
                and validated_candidate is not None
                and (
                    settings.local_arbiter_model in lifecycle_models
                    or stored_resume_model == settings.local_arbiter_model
                )
            ):
                resume_result = candidate
                resume_model = settings.local_arbiter_model
        current_payload_sha = current.get("payload_sha256")
        expected_payload_sha = (
            current_payload_sha
            if isinstance(current_payload_sha, str) and len(current_payload_sha) == 64
            else None
        )
        expected_state = (
            str(current.get("state"))
            if expected_payload_sha is None and current.get("state") in {"missing", "corrupt"}
            else None
        )
        manifest = self._derived_store.prepare(
            workspace,
            job_id,
            kind="translation",
            target_language=target,
            source_final_sha256=project.source_final_sha256,
            project_revision=project.revision,
            resume_result=resume_result,
            resume_model=resume_model,
            expected_payload_sha256=expected_payload_sha,
            expected_state=expected_state,
        )
        token = str(manifest["token"])
        self._derived_cancel[token] = threading.Event()
        self._derived_queue.put(("translation", job_id, target, token))
        self._emit_derived("translation", job_id, manifest)
        return {"translation": manifest}

    def _translations_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"id", "target_language"}:
            raise ValueError("translations.cancel 只接受 id 同 target_language")
        job_id = self._required(params, "id")
        target = self._required(params, "target_language")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        current = self._derived_store.read(
            workspace,
            job_id,
            kind="translation",
            target_language=target,
            source_final_sha256=project.source_final_sha256,
            project_revision=project.revision,
        )
        token = current.get("token")
        if isinstance(token, str) and current.get("state") in {"queued", "generating"}:
            self._derived_cancel.setdefault(token, threading.Event()).set()
            current = self._derived_store.update(
                workspace,
                job_id,
                kind="translation",
                target_language=target,
                token=token,
                cancel_requested=True,
            )
            self._emit_derived("translation", job_id, current)
        return {"translation": current}

    def _translations_update(self, params: dict[str, Any]) -> dict[str, Any]:
        expected = {
            "id",
            "target_language",
            "cue_id",
            "translated_text",
            "expected_payload_sha256",
        }
        if set(params) != expected:
            unexpected = set(params) - expected
            missing = expected - set(params)
            details = []
            if unexpected:
                details.append(f"未知參數：{', '.join(sorted(unexpected))}")
            if missing:
                details.append(f"欠缺參數：{', '.join(sorted(missing))}")
            raise ValueError(f"translations.update 參數無效（{'；'.join(details)}）")
        job_id = self._required(params, "id")
        target = self._required(params, "target_language")
        cue_id = self._required(params, "cue_id")
        translated_text = self._required(params, "translated_text")
        expected_payload_sha256 = self._required(params, "expected_payload_sha256")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        if sum(1 for cue in project.segments if cue.id == cue_id) != 1:
            raise ValueError("搵唔到目前逐字稿嘅唯一字幕段落")
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        updated = self._derived_store.update_completed_translation_cue(
            workspace,
            job_id,
            target_language=target,
            source_final_sha256=project.source_final_sha256,
            project_revision=project.revision,
            cue_id=cue_id,
            translated_text=translated_text,
            expected_payload_sha256=expected_payload_sha256,
        )
        self._emit_derived("translation", job_id, updated)
        return {"translation": updated}

    def _translations_export(self, params: dict[str, Any]) -> dict[str, Any]:
        unexpected = set(params) - {"id", "target_language", "layout", "format"}
        if unexpected:
            raise ValueError(f"translations.export 有未知參數：{', '.join(sorted(unexpected))}")
        job_id = self._required(params, "id")
        target = self._required(params, "target_language")
        layout = self._required(params, "layout")
        selected_format = self._required(params, "format")
        if layout not in BILINGUAL_EXPORT_LAYOUTS:
            raise ValueError("translation layout 必須係 bilingual 或 translated")
        if selected_format not in BILINGUAL_EXPORT_FORMATS:
            raise ValueError("translation format 必須係 txt、srt、vtt 或 ass")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        manifest = self._derived_store.read(
            workspace,
            job_id,
            kind="translation",
            target_language=target,
            source_final_sha256=project.source_final_sha256,
            project_revision=project.revision,
        )
        if manifest.get("state") != "completed" or not isinstance(manifest.get("result"), dict):
            raise ValueError("翻譯未完整完成，暫時唔可以匯出")
        paths = export_bilingual_revision(
            workspace,
            project,
            manifest["result"],
            target_language=target,
            layout=layout,
        )
        return {
            "translation_export": {
                "project_revision": project.revision,
                "target_language": target,
                "layout": layout,
                "format": selected_format,
                "path": paths[selected_format],
                "paths": paths,
            }
        }

    def _job_create(self, params: dict[str, Any]) -> dict[str, Any]:
        source_path = self._required(params, "source_path")
        raw_vocabulary = params.get("vocabulary", [])
        if not isinstance(raw_vocabulary, list) or not all(isinstance(item, str) for item in raw_vocabulary):
            raise ValueError("vocabulary 必須係文字 array")
        vocabulary = list(dict.fromkeys(item.strip() for item in raw_vocabulary if item.strip()))
        correction_memory_entries = [
            self._correction_entry_value(entry)
            for entry in self._correction_memory.entries()
        ]
        correction_memory_terms = list(
            self._correction_memory.prompt_terms(limit=100)
        )
        raw_metadata = params.get("metadata", {})
        if not isinstance(raw_metadata, dict):
            raise ValueError("metadata 必須係 object")
        settings = self.settings_store.get()
        default_primary = settings.fallback_model if settings.use_fallback else settings.primary_model
        primary_model = params.get("primary_model") or default_primary
        verifier_model = params.get("verifier_model") or settings.verifier_model
        accuracy_mode = params.get("accuracy_mode", settings.accuracy_mode)
        local_arbiter_enabled = params.get(
            "local_arbiter_enabled", settings.local_arbiter_enabled
        )
        speaker_diarization_enabled = params.get(
            "speaker_diarization_enabled", settings.speaker_diarization_enabled
        )
        forced_alignment_enabled = params.get(
            "forced_alignment_enabled", settings.forced_alignment_enabled
        )
        speaker_num_speakers = params.get("speaker_num_speakers", settings.speaker_num_speakers)
        if not isinstance(accuracy_mode, bool):
            raise ValueError("accuracy_mode 必須係布林值")
        if not isinstance(local_arbiter_enabled, bool):
            raise ValueError("local_arbiter_enabled 必須係布林值")
        if not isinstance(speaker_diarization_enabled, bool):
            raise ValueError("speaker_diarization_enabled 必須係布林值")
        if not isinstance(forced_alignment_enabled, bool):
            raise ValueError("forced_alignment_enabled 必須係布林值")
        if speaker_num_speakers is not None and (
            isinstance(speaker_num_speakers, bool)
            or not isinstance(speaker_num_speakers, int)
            or not 1 <= speaker_num_speakers <= 20
        ):
            raise ValueError("speaker_num_speakers 必須係 1 至 20 或留空自動辨認")
        if not accuracy_mode:
            local_arbiter_enabled = False
        if not isinstance(primary_model, str) or not primary_model.strip():
            raise ValueError("primary_model 必須係文字")
        if not isinstance(verifier_model, str) or not verifier_model.strip():
            raise ValueError("verifier_model 必須係文字")
        primary_model = primary_model.strip()
        verifier_model = verifier_model.strip()
        if primary_model not in {QWEN_PRIMARY_ID, QWEN_FALLBACK_ID}:
            raise ValueError("primary_model 只支援 Qwen3-ASR 1.7B 或 0.6B")
        if verifier_model != SHERPA_MODEL_NAME:
            raise ValueError("verifier_model 必須使用固定 WenetSpeech-Yue 模型")
        metadata = dict(raw_metadata)
        auto_start = params.get("auto_start", True)
        if not isinstance(auto_start, bool):
            raise ValueError("auto_start 必須係布林值")
        if not auto_start:
            metadata["manual_hold"] = True
        metadata.update(
            {
                "vocabulary": vocabulary,
                "correction_memory_terms": correction_memory_terms,
                "correction_memory_entries": correction_memory_entries,
                "correction_memory_schema": CORRECTION_MEMORY_SCHEMA_VERSION,
                "primary_model": primary_model,
                "verifier_model": verifier_model,
                "accuracy_mode": accuracy_mode,
                "whisper_model": settings.whisper_model,
                "local_arbiter_enabled": local_arbiter_enabled,
                "local_arbiter_model": settings.local_arbiter_model,
                "local_arbiter_endpoint": settings.local_arbiter_endpoint,
                "speaker_diarization_enabled": speaker_diarization_enabled,
                "speaker_num_speakers": speaker_num_speakers,
                "forced_alignment_enabled": forced_alignment_enabled,
            }
        )
        if isinstance(params.get("media_type"), str):
            metadata["media_type"] = params["media_type"]

        create_job = getattr(self.jobs, "create_job", None)
        if callable(create_job):
            job = create_job(source_path, metadata=metadata, queue=False)
        else:
            job = _call(
                self.jobs,
                ("create",),
                source_path=source_path,
                metadata=metadata,
                vocabulary=vocabulary,
                primary_model=metadata["primary_model"],
                verifier_model=metadata["verifier_model"],
            )
        return self._present(job)

    def _job_start(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        suppress_event = bool(params.get("_suppress_event", False))
        with self._job_queue_lock:
            update = getattr(self.jobs, "update", None) or getattr(
                self.jobs, "update_job", None
            )
            if callable(update):
                job = update(job_id, status="queued", cancel_requested=False)
            else:
                from .jobs import JobState

                record = self.jobs.get(job_id)
                if record.state == JobState.CREATED:
                    job = self.jobs.transition(job_id, JobState.QUEUED)
                elif record.state in {JobState.FAILED, JobState.CANCELED}:
                    retry = getattr(self.jobs, "retry", None)
                    job = retry(job_id) if callable(retry) else self.jobs.transition(
                        job_id, JobState.QUEUED
                    )
                elif record.state == JobState.QUEUED:
                    job = record
                else:
                    raise ValueError(f"工作狀態唔可以 start：{record.state.value}")
            self._enqueue_job_once(job_id, self._record_attempt(job))
        job = _call(self.jobs, ("get", "get_job"), job_id)
        presented = self._present(job)
        if not suppress_event:
            self.emit("job.updated", job=presented)
        return presented

    def _history_clear_completed(self, params: dict[str, Any]) -> dict[str, Any]:
        clear = getattr(self.jobs, "clear_completed", None)
        if callable(clear):
            return clear()
        from .jobs import JobState
        from .models import move_to_trash

        moved = []
        for record in _call(self.jobs, ("list_jobs", "list")):
            if getattr(record, "state", None) == JobState.COMPLETED:
                workspace = self._canonical_job_workspace(
                    str(record.job_id), record.workspace
                )
                destination = move_to_trash(workspace)
                if destination:
                    moved.append(str(destination))
        return {"moved_to_trash": moved}

    def _job_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        with self._job_queue_lock:
            record = _call(self.jobs, ("get", "get_job"), job_id)
            attempt_generation = self._record_attempt(record)
            event = self._event_for_attempt(job_id, attempt_generation)
            cancel = getattr(self.jobs, "cancel", None) or getattr(
                self.jobs, "cancel_job", None
            )
            if callable(cancel):
                job = cancel(
                    job_id,
                    expected_attempt_generation=attempt_generation,
                )
            else:
                from .jobs import JobState

                if record.state == JobState.CANCELED:
                    job = record
                else:
                    job = self.jobs.transition(
                        job_id,
                        JobState.CANCELED,
                        expected_attempt_generation=attempt_generation,
                    )
            # Persist the user's terminal command before the model process can
            # observe its stop token.  If persistence fails, inference keeps
            # running instead of becoming an ambiguous shutdown cancellation.
            event.set()
            # An explicit Cancel issued after Retry wins.  Clear the in-memory
            # mirror while JobStore.cancel atomically clears durable intent.
            self._job_requeue_after_run.discard(job_id)
        presented = self._present(job)
        self.emit("job.updated", job=presented)
        return presented

    def _job_retry(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        with self._job_queue_lock:
            if job_id in self._job_running:
                # Keep the currently running attempt's cancel Event intact.
                # Its finally path will perform the persisted retry transition
                # and create exactly one fresh Event/queue slot after unwind.
                attempt_generation = self._job_running_attempts.get(job_id)
                if attempt_generation is None:
                    attempt_generation = self._record_attempt(
                        _call(self.jobs, ("get", "get_job"), job_id)
                    )
                request_retry = getattr(self.jobs, "request_retry", None)
                if callable(request_retry):
                    job = request_retry(
                        job_id,
                        expected_attempt_generation=attempt_generation,
                    )
                else:
                    job = _call(self.jobs, ("get", "get_job"), job_id)
                # As with explicit Cancel, durable retry intent owns the race:
                # only signal the old process after request_retry succeeds.
                self._event_for_attempt(job_id, attempt_generation).set()
                self._job_requeue_after_run.add(job_id)
                presented = self._present(job)
                self.emit("job.updated", job=presented)
                return presented
            retry = getattr(self.jobs, "retry", None) or getattr(
                self.jobs, "retry_job", None
            )
            if callable(retry):
                job = retry(job_id)
            else:
                from .jobs import JobState

                job = self.jobs.transition(job_id, JobState.QUEUED)
            self._enqueue_job_once(job_id, self._record_attempt(job))
        presented = self._present(job)
        self.emit("job.updated", job=presented)
        return presented

    def _youtube_import_start(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._youtube.start(params)

    def _youtube_import_status(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._youtube.status(self._required(params, "id"))

    def _youtube_import_cancel(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._youtube.cancel(self._required(params, "id"))

    def _youtube_import_retry(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._youtube.retry(self._required(params, "id"))

    def _enqueue_youtube_asr(
        self,
        source_path: str,
        metadata: Mapping[str, Any],
    ) -> Mapping[str, Any]:
        try:
            created = self._job_create(
                {
                    "source_path": source_path,
                    "metadata": dict(metadata),
                    "media_type": Path(source_path).suffix.lower().lstrip("."),
                }
            )
        except Exception as exc:
            existing_job_id = getattr(exc, "existing_job_id", None)
            if not isinstance(existing_job_id, str) or not existing_job_id:
                raise
            existing = _call(self.jobs, ("get", "get_job"), existing_job_id)
            state = _jsonable(existing).get("state", _jsonable(existing).get("status"))
            if state in {"created", "failed", "canceled"}:
                return self._job_start({"id": existing_job_id})
            return self._present(existing)
        return self._job_start({"id": created["id"]})

    def _subtitle_job_and_workspace(self, job_id: str) -> tuple[Any, Path]:
        job = _call(self.jobs, ("get", "get_job"), job_id)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        return job, workspace

    def _subtitle_project_get(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        self._subtitle_project_revisions[job_id] = project.revision
        return {"project": project.to_dict()}

    def _subtitle_project_update(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        submitted = params.get("project")
        if not isinstance(submitted, dict):
            raise ValueError("project 必須係 object")
        expected_revision = params.get("expected_revision")
        if isinstance(expected_revision, bool) or not isinstance(expected_revision, int):
            raise ValueError("expected_revision 必須係整數")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        project = self._subtitle_projects.update(
            job_id,
            job,
            submitted,
            expected_revision=expected_revision,
        )
        value = project.to_dict()
        self._subtitle_project_revisions[job_id] = project.revision
        self.emit("subtitle.project.updated", job_id=job_id, project=value)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        raw_render = self._subtitle_renderer.status(workspace, job_id)
        render = self._render_view_for_job(
            job_id,
            raw_render,
        )
        if isinstance(raw_render.get("project_revision"), int):
            self.emit("subtitle.render.updated", job_id=job_id, render=render)
        return {"project": value}

    @staticmethod
    def _timing_attention_idle(
        *, job_id: str, project_revision: int, source_final_sha256: str
    ) -> dict[str, Any]:
        return {
            "schema": TIMING_ATTENTION_SCHEMA,
            "job_id": job_id,
            "project_revision": project_revision,
            "source_final_sha256": source_final_sha256,
            "status": "idle",
            "progress": 0.0,
            "pending_count": 0,
            "cues": [],
            "error": None,
            "automatic_timestamp_mutation": False,
            "replacement_timestamps_present": False,
        }

    def _timing_attention_current(
        self,
        *,
        job_id: str,
        workspace: Path,
        project_revision: int,
        source_final_sha256: str,
        cue_word_capacities: Mapping[str, int],
        media_duration_ms: int,
    ) -> dict[str, Any]:
        persisted = load_timing_attention_result(
            workspace,
            job_id=job_id,
            project_revision=project_revision,
            source_final_sha256=source_final_sha256,
            cue_word_capacities=cue_word_capacities,
            media_duration_ms=media_duration_ms,
        )
        if persisted is not None:
            return {**persisted, "progress": 1.0, "error": None}
        with self._timing_attention_lock:
            current = self._timing_attention_statuses.get(job_id)
            if (
                isinstance(current, dict)
                and current.get("project_revision") == project_revision
                and current.get("source_final_sha256") == source_final_sha256
            ):
                return dict(current)
        return self._timing_attention_idle(
            job_id=job_id,
            project_revision=project_revision,
            source_final_sha256=source_final_sha256,
        )

    def _subtitle_timing_attention_status(
        self, params: dict[str, Any]
    ) -> dict[str, Any]:
        unexpected = set(params) - {"id"}
        if unexpected:
            raise ValueError(
                f"timing_attention.status 有未知參數：{', '.join(sorted(unexpected))}"
            )
        job_id = self._required(params, "id")
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        document, source_final_sha256, loaded_workspace = (
            self._subtitle_projects.load_final_document(job_id, job)
        )
        if loaded_workspace != workspace or source_final_sha256 != project.source_final_sha256:
            raise ValueError("Timing Attention final transcript identity 無效")
        _, _, words, cues = self._timing_attention_scan_inputs(document, project)
        self._subtitle_project_revisions[job_id] = project.revision
        return {
            "timing_attention": self._timing_attention_current(
                job_id=job_id,
                workspace=workspace,
                project_revision=project.revision,
                source_final_sha256=project.source_final_sha256,
                cue_word_capacities=timing_attention_cue_word_capacities(words, cues),
                media_duration_ms=project.duration_ms,
            )
        }

    def _subtitle_timing_attention_scan(
        self, params: dict[str, Any]
    ) -> dict[str, Any]:
        unexpected = set(params) - {"id", "expected_revision"}
        if unexpected:
            raise ValueError(
                f"timing_attention.scan 有未知參數：{', '.join(sorted(unexpected))}"
            )
        job_id = self._required(params, "id")
        expected_revision = params.get("expected_revision")
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 1 <= expected_revision <= 2_147_483_647
        ):
            raise ValueError("expected_revision 必須係正整數")
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        if project.revision != expected_revision:
            raise ValueError(
                f"stale_revision：目前 revision 係 {project.revision}，唔係 {expected_revision}"
            )
        self._subtitle_project_revisions[job_id] = project.revision
        document, source_final_sha256, loaded_workspace = (
            self._subtitle_projects.load_final_document(job_id, job)
        )
        if loaded_workspace != workspace or source_final_sha256 != project.source_final_sha256:
            raise ValueError("Timing Attention final transcript identity 無效")
        _, _, words, cues = self._timing_attention_scan_inputs(document, project)
        current = self._timing_attention_current(
            job_id=job_id,
            workspace=workspace,
            project_revision=project.revision,
            source_final_sha256=project.source_final_sha256,
            cue_word_capacities=timing_attention_cue_word_capacities(words, cues),
            media_duration_ms=project.duration_ms,
        )
        if current.get("status") in {"completed", "queued", "running"}:
            return {"timing_attention": current}
        audio_path = workspace / "audio" / "mono-16k.wav"
        if audio_path.is_symlink() or not audio_path.is_file():
            raise FileNotFoundError("工作缺少安全嘅 16 kHz 本地音訊")
        try:
            wenet_model = self.models.require_local(SHERPA_MODEL_NAME)
        except Exception as exc:
            raise FileNotFoundError(
                "Timing Attention 缺少或未驗證 WenetSpeech Yue 模型"
            ) from exc
        try:
            sensevoice_model = self.models.require_local(SENSEVOICE_YUE_MODEL_NAME)
        except Exception as exc:
            raise FileNotFoundError(
                "Timing Attention 缺少或未驗證 SenseVoice Yue 模型；請到設定下載或檢查完整性"
            ) from exc
        token = uuid.uuid4().hex
        cancel_event = threading.Event()
        queued = {
            **self._timing_attention_idle(
                job_id=job_id,
                project_revision=project.revision,
                source_final_sha256=project.source_final_sha256,
            ),
            "status": "queued",
            "token": token,
            "queued_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        }
        with self._timing_attention_lock:
            self._timing_attention_cancel[job_id] = cancel_event
            self._timing_attention_statuses[job_id] = queued
        self._timing_attention_queue.put((job_id, project.revision, token))
        self.emit(
            "subtitle.timing_attention.updated",
            job_id=job_id,
            timing_attention=queued,
        )
        return {"timing_attention": queued}

    def _subtitle_timing_attention_cancel(
        self, params: dict[str, Any]
    ) -> dict[str, Any]:
        unexpected = set(params) - {"id"}
        if unexpected:
            raise ValueError(
                f"timing_attention.cancel 有未知參數：{', '.join(sorted(unexpected))}"
            )
        job_id = self._required(params, "id")
        with self._timing_attention_lock:
            event = self._timing_attention_cancel.get(job_id)
            current = self._timing_attention_statuses.get(job_id)
            if event is not None:
                event.set()
            if isinstance(current, dict) and current.get("status") in {"queued", "running"}:
                current = {
                    **current,
                    "status": "cancelled",
                    "progress": 0.0,
                    "completed_at": datetime.now(timezone.utc)
                    .isoformat()
                    .replace("+00:00", "Z"),
                    "error": None,
                    "cues": [],
                    "pending_count": 0,
                }
                self._timing_attention_statuses[job_id] = current
        if not isinstance(current, dict):
            return self._subtitle_timing_attention_status({"id": job_id})
        self.emit(
            "subtitle.timing_attention.updated",
            job_id=job_id,
            timing_attention=current,
        )
        return {"timing_attention": dict(current)}

    def _subtitle_project_auto_segment(self, params: dict[str, Any]) -> dict[str, Any]:
        unexpected = set(params) - {"id", "expected_revision", "max_characters", "mode"}
        if unexpected:
            raise ValueError(f"auto_segment 有未知參數：{', '.join(sorted(unexpected))}")
        job_id = self._required(params, "id")
        expected_revision = params.get("expected_revision")
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 1 <= expected_revision <= 2_147_483_647
        ):
            raise ValueError("expected_revision 必須係正整數")
        max_characters = params.get("max_characters")
        if (
            isinstance(max_characters, bool)
            or not isinstance(max_characters, int)
            or not 6 <= max_characters <= 60
        ):
            raise ValueError("max_characters 必須係 6 至 60 嘅整數")
        mode = params.get("mode")
        if mode not in {"precise", "semantic"}:
            raise ValueError("mode 必須係 precise 或 semantic")
        job = _call(self.jobs, ("get", "get_job"), job_id)
        semantic_boundary_ids: tuple[int, ...] = ()
        semantic_selector_audit: dict[str, Any] | None = None
        if mode == "semantic":
            context = self._subtitle_projects.auto_segment_context(
                job_id,
                job,
                expected_revision=expected_revision,
            )
            lifecycle_events: list[dict[str, str]] = []
            snapshot_audit = {
                "snapshot_revision": context.revision,
                "snapshot_source_final_sha256": context.source_final_sha256,
            }
            if not self._heavy_work_lock.acquire(blocking=False):
                semantic_selector_audit = {
                    "attempted": False,
                    "candidate_count": len(context.candidate_boundary_ids),
                    "selected_count": 0,
                    "calls": [],
                    "status": "fallback",
                    "reason": "heavy_work_busy",
                    "heavy_work_lock": "busy",
                    "lifecycle": lifecycle_events,
                    **snapshot_audit,
                }
            else:
                lifecycle: LMStudioLifecycle | None = None
                selector: Any | None = None
                fallback_reason = "selector_not_configured"
                try:
                    try:
                        from .subtitles.semantic_boundaries import (
                            LocalSemanticBoundarySelector,
                        )

                        settings = self.settings_store.get()
                        lifecycle = LMStudioLifecycle(settings.local_arbiter_model)
                        configure_endpoint = getattr(
                            lifecycle, "configure_endpoint", None
                        )
                        if callable(configure_endpoint):
                            configure_endpoint(settings.local_arbiter_endpoint)
                        try:
                            raw_prepare = lifecycle.prepare_arbiter()
                        except Exception as exc:
                            raw_prepare = {
                                "status": "prepare_exception",
                                "model": settings.local_arbiter_model,
                                "reason": type(exc).__name__,
                            }
                        prepare_event = _safe_lifecycle_event(
                            raw_prepare,
                            phase="prepare",
                        )
                        lifecycle_events.append(prepare_event)
                        api_model = (
                            raw_prepare.get("api_model")
                            if isinstance(raw_prepare, Mapping)
                            else None
                        )
                        if (
                            prepare_event.get("status") in {"loaded", "already_loaded"}
                            and isinstance(api_model, str)
                            and api_model.strip()
                        ):
                            selector = LocalSemanticBoundarySelector(
                                endpoint=settings.local_arbiter_endpoint,
                                model=api_model,
                                timeout_seconds=60.0,
                            )
                        else:
                            fallback_reason = (
                                f"lifecycle_{prepare_event.get('status', 'unknown')}"
                            )
                    except Exception as exc:
                        fallback_reason = f"semantic_setup_exception:{type(exc).__name__}"

                    semantic_boundary_ids, semantic_selector_audit = (
                        self._subtitle_projects.select_semantic_boundaries(
                            context.text,
                            context.candidate_boundary_ids,
                            selector,
                        )
                    )
                    if selector is None:
                        semantic_selector_audit["reason"] = fallback_reason
                except Exception as exc:
                    # Semantic assistance is optional.  Any unexpected local
                    # setup/provider failure remains a deterministic precise
                    # segmentation with a privacy-safe audit reason.
                    semantic_boundary_ids = ()
                    semantic_selector_audit = {
                        "attempted": selector is not None,
                        "candidate_count": len(context.candidate_boundary_ids),
                        "selected_count": 0,
                        "calls": [],
                        "status": "fallback",
                        "reason": f"semantic_exception:{type(exc).__name__}",
                    }
                finally:
                    if lifecycle is not None:
                        try:
                            raw_release = lifecycle.release()
                        except Exception as exc:
                            raw_release = {
                                "status": "release_exception",
                                "reason": type(exc).__name__,
                            }
                        lifecycle_events.append(
                            _safe_lifecycle_event(raw_release, phase="release")
                        )
                    self._heavy_work_lock.release()
                assert semantic_selector_audit is not None
                semantic_selector_audit.update(
                    {
                        "heavy_work_lock": "acquired",
                        "lifecycle": lifecycle_events,
                        **snapshot_audit,
                    }
                )
        project = self._subtitle_projects.auto_segment(
            job_id,
            job,
            expected_revision=expected_revision,
            max_characters=max_characters,
            mode=mode,
            semantic_boundary_ids=semantic_boundary_ids,
            semantic_selector_audit=semantic_selector_audit,
        )
        value = project.to_dict()
        self._subtitle_project_revisions[job_id] = project.revision
        self.emit("subtitle.project.updated", job_id=job_id, project=value)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        raw_render = self._subtitle_renderer.status(workspace, job_id)
        if isinstance(raw_render.get("project_revision"), int):
            self.emit(
                "subtitle.render.updated",
                job_id=job_id,
                render=self._render_view_for_job(job_id, raw_render),
            )
        return {"project": value, "segmentation": value["segmentation_audit"]}

    def _subtitle_project_export(self, params: dict[str, Any]) -> dict[str, Any]:
        unexpected = set(params) - {"id", "expected_revision", "format"}
        if unexpected:
            raise ValueError(f"project.export 有未知參數：{', '.join(sorted(unexpected))}")
        job_id = self._required(params, "id")
        expected_revision = params.get("expected_revision")
        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 1 <= expected_revision <= 2_147_483_647
        ):
            raise ValueError("expected_revision 必須係正整數")
        selected_format = params.get("format")
        if not isinstance(selected_format, str) or selected_format not in EXPORT_FORMATS:
            raise ValueError(
                "format 必須係 txt、timestamp_txt、srt、vtt、json 或 csv"
            )
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        if project.revision != expected_revision:
            raise ValueError(
                f"stale_revision：目前 revision 係 {project.revision}，唔係 {expected_revision}"
            )
        self._subtitle_project_revisions[job_id] = project.revision
        paths = export_project_revision(workspace, project)
        return {
            "revision": project.revision,
            "paths": paths,
            "format": selected_format,
            "path": paths[selected_format],
        }

    def _subtitle_render_status(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"id"}:
            raise ValueError("subtitle.render.status 只接受 id")
        job_id = self._required(params, "id")
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        self._subtitle_project_revisions[job_id] = project.revision
        render = self._render_view_for_job(
            job_id,
            self._subtitle_renderer.status(workspace, job_id),
        )
        return {"render": render}

    def _translation_render_snapshot(
        self,
        *,
        workspace: Path,
        job_id: str,
        project: Any,
        target_language: str,
        translation_layout: str,
        expected_payload_sha256: str,
    ) -> tuple[Any, dict[str, Any], str]:
        """Resolve and seal the exact translated project selected in Swift."""

        if translation_layout not in BILINGUAL_EXPORT_LAYOUTS:
            raise ValueError("translation_layout 必須係 bilingual 或 translated")
        if (
            not isinstance(expected_payload_sha256, str)
            or len(expected_payload_sha256) != 64
            or any(character not in "0123456789abcdef" for character in expected_payload_sha256)
        ):
            raise ValueError("translation_payload_sha256 必須係有效 SHA-256")
        manifest = self._derived_store.read(
            workspace,
            job_id,
            kind="translation",
            target_language=target_language,
            source_final_sha256=project.source_final_sha256,
            project_revision=project.revision,
        )
        actual_payload_sha256 = manifest.get("payload_sha256")
        if (
            manifest.get("state") != "completed"
            or manifest.get("stale") is True
            or not isinstance(manifest.get("result"), dict)
            or not isinstance(actual_payload_sha256, str)
            or not hmac.compare_digest(expected_payload_sha256, actual_payload_sha256)
        ):
            raise ValueError("翻譯 artifact 已過期、損壞或同畫面版本唔一致")
        result = manifest["result"]
        resolved = resolve_translated_project(
            project,
            result,
            target_language=target_language,
            layout=translation_layout,
        )
        return resolved, manifest, translation_result_sha256(result)

    def _subtitle_render_start(self, params: dict[str, Any]) -> dict[str, Any]:
        if self._shutdown_event.is_set():
            raise ValueError("Worker 正在關閉，唔可以開始字幕輸出")
        allowed = {
            "id",
            "expected_revision",
            "profile",
            "target_language",
            "translation_layout",
            "translation_payload_sha256",
        }
        unexpected = set(params) - allowed
        if unexpected:
            raise ValueError(
                f"subtitle.render.start 有未知參數：{', '.join(sorted(unexpected))}"
            )
        job_id = self._required(params, "id")
        expected_revision = params.get("expected_revision")
        if isinstance(expected_revision, bool) or not isinstance(expected_revision, int):
            raise ValueError("expected_revision 必須係整數")
        profile = params.get("profile", "h264_mp4")
        if profile != "h264_mp4":
            raise ValueError("profile 目前只支援 h264_mp4")
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        if project.revision != expected_revision:
            raise ValueError(
                f"stale_revision：目前 revision 係 {project.revision}，唔係 {expected_revision}"
            )
        self._subtitle_project_revisions[job_id] = project.revision
        translation_keys = {
            "target_language",
            "translation_layout",
            "translation_payload_sha256",
        }
        present_translation_keys = translation_keys.intersection(params)
        render_project = project
        render_content = "source"
        target_language: str | None = None
        translation_layout: str | None = None
        translation_artifact_sha256: str | None = None
        translation_result_identity: str | None = None
        if present_translation_keys:
            if present_translation_keys != translation_keys:
                raise ValueError("翻譯影片輸出必須同時提供 language、layout 同 artifact SHA")
            target_language = self._required(params, "target_language")
            translation_layout = self._required(params, "translation_layout")
            translation_artifact_sha256 = self._required(
                params, "translation_payload_sha256"
            )
            (
                render_project,
                _translation_manifest,
                translation_result_identity,
            ) = self._translation_render_snapshot(
                workspace=workspace,
                job_id=job_id,
                project=project,
                target_language=target_language,
                translation_layout=translation_layout,
                expected_payload_sha256=translation_artifact_sha256,
            )
            render_content = translation_layout
        ffmpeg = resolve_subtitle_ffmpeg()
        ffprobe = resolve_subtitle_ffprobe(ffmpeg)
        if render_content == "source":
            # Preserve the original renderer call contract for source-only
            # callers and tests; ``prepare`` writes explicit null translation
            # identity fields by default.
            render = self._subtitle_renderer.prepare(
                workspace=workspace,
                project=render_project,
                ffmpeg_path=ffmpeg,
                ffprobe_path=ffprobe,
            )
        else:
            render = self._subtitle_renderer.prepare(
                workspace=workspace,
                project=render_project,
                ffmpeg_path=ffmpeg,
                ffprobe_path=ffprobe,
                render_content=render_content,
                target_language=target_language,
                translation_layout=translation_layout,
                translation_artifact_sha256=translation_artifact_sha256,
                translation_result_sha256=translation_result_identity,
            )
        self._subtitle_render_cancel[job_id] = threading.Event()
        self._subtitle_render_queue.put((job_id, str(render["output_filename"])))
        view = self._render_view_for_job(job_id, render)
        self.emit("subtitle.render.updated", job_id=job_id, render=view)
        return {"render": view}

    def _subtitle_render_cancel_request(self, params: dict[str, Any]) -> dict[str, Any]:
        if set(params) != {"id"}:
            raise ValueError("subtitle.render.cancel 只接受 id")
        job_id = self._required(params, "id")
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        self._subtitle_project_revisions[job_id] = project.revision
        render = self._subtitle_renderer.status(workspace, job_id)
        state = render.get("state")
        if state == "queued":
            self._subtitle_render_cancel.setdefault(job_id, threading.Event()).set()
            render.update(
                {
                    "state": "cancelled",
                    "cancel_requested": False,
                    "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                    "error": None,
                }
            )
            render = self._subtitle_renderer.save_status(workspace, render)
        elif state == "rendering":
            self._subtitle_render_cancel.setdefault(job_id, threading.Event()).set()
            render["cancel_requested"] = True
            render = self._subtitle_renderer.save_status(workspace, render)
        view = self._render_view_for_job(job_id, render)
        self.emit("subtitle.render.updated", job_id=job_id, render=view)
        return {"render": view}

    def _subtitle_preview_status(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        _, workspace = self._subtitle_job_and_workspace(job_id)
        return {"preview": self._subtitle_previews.status(workspace, job_id)}

    def _subtitle_preview_prepare(self, params: dict[str, Any]) -> dict[str, Any]:
        if self._shutdown_event.is_set():
            raise ValueError("Worker 正在關閉，唔可以建立 preview")
        job_id = self._required(params, "id")
        job, workspace = self._subtitle_job_and_workspace(job_id)
        project = self._subtitle_projects.get_or_create(job_id, job)
        self._subtitle_project_revisions[job_id] = project.revision
        ffmpeg = resolve_subtitle_ffmpeg()
        ffprobe = resolve_subtitle_ffprobe(ffmpeg)
        preview = self._subtitle_previews.prepare(
            workspace=workspace,
            project=project,
            ffmpeg_path=ffmpeg,
            ffprobe_path=ffprobe,
        )
        self._subtitle_preview_cancel[job_id] = threading.Event()
        self._subtitle_preview_queue.put((job_id, str(preview["token"])))
        self.emit("subtitle.preview.updated", job_id=job_id, preview=preview)
        return {"preview": preview}

    def _subtitle_preview_cancel_request(self, params: dict[str, Any]) -> dict[str, Any]:
        job_id = self._required(params, "id")
        _, workspace = self._subtitle_job_and_workspace(job_id)
        preview = self._subtitle_previews.status(workspace, job_id)
        state = preview.get("state")
        if state == "queued":
            self._subtitle_preview_cancel.setdefault(job_id, threading.Event()).set()
            preview.update(
                {
                    "state": "cancelled",
                    "cancel_requested": False,
                    "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                    "error": None,
                }
            )
            preview = self._subtitle_previews.save_status(workspace, preview)
        elif state == "rendering":
            self._subtitle_preview_cancel.setdefault(job_id, threading.Event()).set()
            preview["cancel_requested"] = True
            preview = self._subtitle_previews.save_status(workspace, preview)
        self.emit("subtitle.preview.updated", job_id=job_id, preview=preview)
        return {"preview": preview}

    def _load_chunks(self, job: dict[str, Any], workspace: Path) -> list[dict[str, Any]]:
        job_value = _jsonable(job)
        chunks = job_value.get("chunks") or job_value.get("metadata", {}).get("chunks")
        if chunks is not None:
            return list(chunks)
        checkpoint = workspace / "chunks.json"
        if checkpoint.is_file():
            value = json.loads(checkpoint.read_text(encoding="utf-8"))
            return list(value.get("chunks", value if isinstance(value, list) else []))
        raise ValueError("工作未有 chunks；等待 audio preparation integration")

    @staticmethod
    def _chunk_files_exist(
        chunks: list[Any], *, allowed_root: Path | None = None
    ) -> bool:
        if not chunks:
            return False
        root = allowed_root.resolve(strict=True) if allowed_root is not None else None
        for chunk in chunks:
            path = chunk.get("path") if isinstance(chunk, dict) else getattr(chunk, "path", None)
            candidate = Path(str(path)) if path else None
            if (
                candidate is None
                or candidate.is_symlink()
                or not candidate.is_file()
            ):
                return False
            if root is not None:
                try:
                    candidate.resolve(strict=True).relative_to(root)
                except (OSError, ValueError):
                    return False
        return True

    @staticmethod
    def _binary_path(name: str) -> str | None:
        discovered = shutil.which(name)
        if discovered:
            return str(Path(discovered).resolve())
        fallback = HOMEBREW_FFMPEG if name == "ffmpeg" else HOMEBREW_FFPROBE
        return str(fallback) if fallback.is_file() and os.access(fallback, os.X_OK) else None

    @staticmethod
    def _record_attempt(record: Any) -> int:
        value = _jsonable(record)
        raw = value.get("attempt_generation", 0) if isinstance(value, dict) else 0
        try:
            return max(0, int(raw))
        except (TypeError, ValueError):
            return 0

    def _event_for_attempt(
        self, job_id: str, attempt_generation: int
    ) -> threading.Event:
        event = self._cancel.get(job_id)
        if event is None or self._cancel_attempts.get(job_id) != attempt_generation:
            event = threading.Event()
            self._cancel[job_id] = event
            self._cancel_attempts[job_id] = attempt_generation
        return event

    def _enqueue_job_once(
        self, job_id: str, attempt_generation: int | None = None
    ) -> bool:
        """Idempotently own one queue slot per job.

        A repeated Start/retry request for a pending queue item is a no-op.
        Running-attempt retry is handled separately by ``_job_retry`` so its
        cancellation token cannot be replaced before the attempt unwinds.
        """

        with self._job_queue_lock:
            if attempt_generation is None:
                try:
                    attempt_generation = self._record_attempt(
                        _call(self.jobs, ("get", "get_job"), job_id)
                    )
                except KeyError:
                    # Preserve the lightweight injected-store contract used by
                    # installation/recovery protocol tests.
                    attempt_generation = 0
            if job_id in self._job_queue_members:
                # A pending canceled attempt can be retried without adding a
                # second physical queue slot.  The runner will atomically claim
                # the latest persisted generation when this slot is popped.
                if job_id not in self._job_running:
                    previous = self._job_queue_attempts.get(job_id)
                    self._job_queue_attempts[job_id] = attempt_generation
                    if previous != attempt_generation:
                        self._event_for_attempt(job_id, attempt_generation)
                return False
            self._job_queue_members.add(job_id)
            self._job_queue_attempts[job_id] = attempt_generation
            self._event_for_attempt(job_id, attempt_generation)
            self._job_queue.put(job_id)
            return True

    def _finish_job_queue_item(
        self, job_id: str, attempt_generation: int | None = None
    ) -> None:
        with self._job_queue_lock:
            owned_attempt = self._job_running_attempts.get(job_id)
            if attempt_generation is None:
                attempt_generation = (
                    owned_attempt
                    if owned_attempt is not None
                    else self._job_queue_attempts.get(job_id, 0)
                )
            if owned_attempt is not None and owned_attempt != attempt_generation:
                # A stale runner is never allowed to consume a newer queue slot.
                return
            self._job_running.discard(job_id)
            self._job_running_attempts.pop(job_id, None)
            try:
                record = _call(self.jobs, ("get", "get_job"), job_id)
                persisted_retry = bool(
                    _jsonable(record).get("retry_requested", False)
                )
            except Exception:
                logger.exception("Could not inspect retry ownership for %s", job_id)
                persisted_retry = False
            should_retry = persisted_retry or job_id in self._job_requeue_after_run
            if self._shutdown_event.is_set():
                # Leave the durable retry flag untouched for startup recovery.
                self._job_queue_members.discard(job_id)
                self._job_queue_attempts.pop(job_id, None)
                self._job_requeue_after_run.discard(job_id)
                return
            if should_retry:
                try:
                    fulfill = getattr(self.jobs, "fulfill_retry", None)
                    if callable(fulfill):
                        job = fulfill(
                            job_id,
                            expected_attempt_generation=attempt_generation,
                        )
                    else:
                        retry = getattr(self.jobs, "retry", None) or getattr(
                            self.jobs, "retry_job", None
                        )
                        if not callable(retry):
                            raise AttributeError("job store 缺少 durable retry method")
                        job = retry(job_id)
                    job_value = _jsonable(job)
                    if job_value.get("state", job_value.get("status")) != "queued":
                        self._job_queue_members.discard(job_id)
                        self._job_queue_attempts.pop(job_id, None)
                        self._job_requeue_after_run.discard(job_id)
                        self.emit("job.updated", job=self._present(job))
                        return
                    next_attempt = self._record_attempt(job)
                    self._job_queue_attempts[job_id] = next_attempt
                    self._event_for_attempt(job_id, next_attempt)
                    self._job_queue.put(job_id)
                    self._job_requeue_after_run.discard(job_id)
                    self.emit("job.updated", job=self._present(job))
                    return
                except Exception:
                    logger.exception("Could not queue requested retry for %s", job_id)
            self._job_requeue_after_run.discard(job_id)
            self._job_queue_members.discard(job_id)
            self._job_queue_attempts.pop(job_id, None)

    @staticmethod
    def _valid_checkpoint(job_value: dict[str, Any], name: str) -> dict[str, Any] | None:
        checkpoints = job_value.get("checkpoints")
        checkpoint = checkpoints.get(name) if isinstance(checkpoints, dict) else None
        if not isinstance(checkpoint, dict):
            return None
        artifacts = checkpoint.get("artifacts", ())
        data = checkpoint.get("data", {})
        if (
            not isinstance(artifacts, (list, tuple))
            or not isinstance(data, Mapping)
        ):
            return None
        from .jobs import JobCheckpoint

        candidate = JobCheckpoint(
            name=str(checkpoint.get("name", name)),
            completed_at=str(checkpoint.get("completed_at", "")),
            artifacts=tuple(str(path) for path in artifacts),
            data=dict(data),
        )
        if not candidate.is_valid():
            return None
        return checkpoint

    @staticmethod
    def _ffmpeg_fraction(event: dict[str, str], duration_ms: int) -> float | None:
        if event.get("progress") == "end":
            return 1.0
        if duration_ms <= 0:
            return None
        for key in ("out_time_us", "out_time_ms"):
            raw = event.get(key)
            if raw is None:
                continue
            try:
                return max(0.0, min(1.0, int(raw) / (duration_ms * 1000)))
            except ValueError:
                continue
        return None

    def _prepare_chunks(
        self,
        job: Any,
        workspace: Path,
        cancel_event: threading.Event,
        *,
        attempt_generation: int | None = None,
    ) -> list[Any]:
        """Use the audio module when a persisted chunk plan is not present."""
        job_value = _jsonable(job)
        source_path = job_value.get("source_path")
        expected_fingerprint = job_value.get("fingerprint")
        if not isinstance(source_path, str) or not source_path:
            raise ValueError("工作缺少 source_path")
        from .jobs import fingerprint_file, quick_fingerprint_file, source_identity_file

        metadata = job_value.get("metadata")
        metadata = metadata if isinstance(metadata, dict) else {}
        expected_identity = metadata.get("source_identity")
        if (
            isinstance(expected_identity, dict)
            and source_identity_file(source_path) != expected_identity
        ):
            raise ValueError(
                "原始媒體檔案喺匯入後已變更；為免續用舊結果，請重新匯入檔案"
            )
        expected_quick = metadata.get("source_quick_fingerprint")
        if isinstance(expected_quick, str):
            actual_quick = quick_fingerprint_file(source_path)
            if actual_quick != expected_quick:
                raise ValueError(
                    "原始媒體檔案喺匯入後已變更；為免續用舊結果，請重新匯入檔案"
                )
        job_id = job_value.get("job_id", job_value.get("id"))
        actual_fingerprint = fingerprint_file(
            source_path,
            cancelled=cancel_event.is_set,
            progress=lambda fraction: self._on_job_progress(
                str(job_id),
                {
                    "stage": "fingerprinting",
                    "progress": fraction,
                    "overall_progress": 0.02 * fraction,
                },
                attempt_generation=attempt_generation,
            ),
        )
        expected_full = metadata.get("source_content_fingerprint")
        if not isinstance(expected_full, str) and isinstance(expected_fingerprint, str):
            expected_full = (
                expected_fingerprint if expected_fingerprint.startswith("sha256:") else None
            )
        if isinstance(expected_full, str) and actual_fingerprint != expected_full:
            raise ValueError(
                "原始媒體檔案喺匯入後已變更；為免續用舊結果，請重新匯入檔案"
            )
        if expected_full is None and isinstance(expected_quick, str):
            seal = getattr(self.jobs, "seal_source_fingerprint", None)
            if callable(seal):
                seal(
                    job_id,
                    quick_fingerprint=expected_quick,
                    content_fingerprint=actual_fingerprint,
                    expected_attempt_generation=attempt_generation,
                )

        def source_bound_checkpoint(name: str) -> dict[str, Any] | None:
            checkpoint = self._valid_checkpoint(job_value, name)
            if checkpoint is None:
                return None
            data = checkpoint.get("data")
            if (
                not isinstance(data, dict)
                or data.get("source_content_fingerprint") != actual_fingerprint
            ):
                logger.warning(
                    "Ignoring legacy or source-unbound %s checkpoint for %s",
                    name,
                    job_id,
                )
                return None
            return checkpoint

        audio_dir = self._canonical_workspace_subdirectory(workspace, "audio")
        chunks_dir = self._canonical_workspace_subdirectory(workspace, "chunks")
        for existing in (*audio_dir.iterdir(), *chunks_dir.iterdir()):
            if existing.is_symlink():
                raise ValueError("工作音訊／分段檔案唔可以係 symlink")

        persisted_chunked = source_bound_checkpoint("chunked")
        if persisted_chunked is not None:
            try:
                loaded_chunks = self._load_chunks(job_value, workspace)
                if self._chunk_files_exist(loaded_chunks, allowed_root=chunks_dir):
                    return loaded_chunks
                logger.warning(
                    "Persisted job chunks are incomplete; rebuilding from extracted WAV"
                )
            except ValueError:
                pass
        from .audio import build_chunk_plan, extract_audio, probe_media
        from .constants import CHUNK_PLAN_FILENAME
        from .schemas import ChunkPlan

        chunk_plan_path = chunks_dir / CHUNK_PLAN_FILENAME
        ffprobe = self._binary_path("ffprobe")
        ffmpeg = self._binary_path("ffmpeg")
        if not ffprobe or not ffmpeg:
            raise RuntimeError("搵唔到 FFmpeg/ffprobe")
        job_id = str(job_value.get("job_id") or job_value.get("id"))
        probed = source_bound_checkpoint("probed")
        extracted = source_bound_checkpoint("extracted")
        chunked = persisted_chunked

        if chunked and chunk_plan_path.is_file():
            try:
                plan = ChunkPlan.from_dict(
                    json.loads(chunk_plan_path.read_text(encoding="utf-8"))
                )
            except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
                invalid = chunk_plan_path.with_name(
                    f"{chunk_plan_path.name}.invalid-{time.time_ns()}-{os.getpid()}"
                )
                try:
                    os.replace(chunk_plan_path, invalid)
                except OSError:
                    logger.exception("Could not quarantine invalid chunk plan for %s", job_id)
                logger.warning(
                    "Invalid chunk plan for %s; rebuilding from extracted WAV: %s",
                    job_id,
                    type(error).__name__,
                )
                chunked = None
            else:
                if self._chunk_files_exist(list(plan.chunks), allowed_root=chunks_dir):
                    self._on_job_progress(
                        job_id,
                        {
                            "stage": "chunking",
                            "progress": 1.0,
                            "overall_progress": 0.10,
                            "resumed": True,
                        },
                        attempt_generation=attempt_generation,
                    )
                    return list(plan.chunks)
                logger.warning("Chunk plan references missing files; rebuilding disk chunks")

        if probed:
            data = probed.get("data", {})
            media_value = data.get("media", {}) if isinstance(data, dict) else {}
            try:
                duration_ms = int(media_value.get("duration_ms", 0)) if isinstance(media_value, dict) else 0
            except (TypeError, ValueError):
                duration_ms = 0
            self._on_job_progress(
                job_id,
                {"stage": "probing", "progress": 1.0, "overall_progress": 0.01, "resumed": True},
                attempt_generation=attempt_generation,
            )
        else:
            self._transition_if_supported(
                job_id, "probing", attempt_generation=attempt_generation
            )
            self._on_job_progress(
                job_id,
                {"stage": "probing", "progress": 0.0, "overall_progress": 0.0},
                attempt_generation=attempt_generation,
            )
            metadata = probe_media(source_path, ffprobe_path=ffprobe)
            duration_ms = metadata.duration_ms
            self._checkpoint_if_supported(
                job_id,
                "probed",
                [source_path],
                {
                    "media": _jsonable(metadata),
                    "source_content_fingerprint": actual_fingerprint,
                },
                attempt_generation=attempt_generation,
            )
            self._on_job_progress(
                job_id,
                {"stage": "probing", "progress": 1.0, "overall_progress": 0.01},
                attempt_generation=attempt_generation,
            )

        wav_path = audio_dir / "mono-16k.wav"
        if not (extracted and wav_path.is_file()):
            self._transition_if_supported(
                job_id, "extracting", attempt_generation=attempt_generation
            )

            def extraction_progress(event: dict[str, str]) -> None:
                fraction = self._ffmpeg_fraction(event, duration_ms)
                overall = 0.01 if fraction is None else 0.01 + 0.07 * fraction
                self._on_job_progress(
                    job_id,
                    {
                        "stage": "extracting",
                        "progress": fraction,
                        "overall_progress": overall,
                        "ffmpeg": event,
                    },
                    attempt_generation=attempt_generation,
                )

            extract_audio(
                source_path,
                wav_path,
                ffmpeg_path=ffmpeg,
                cancel_requested=cancel_event.is_set,
                progress_callback=extraction_progress,
            )
            post_extract_fingerprint = fingerprint_file(
                source_path,
                cancelled=cancel_event.is_set,
                progress=lambda fraction: self._on_job_progress(
                    job_id,
                    {
                        "stage": "fingerprinting",
                        "phase": "post_extraction_source_verification",
                        "progress": fraction,
                        "overall_progress": 0.08 + 0.01 * fraction,
                    },
                    attempt_generation=attempt_generation,
                ),
            )
            post_extract_identity = source_identity_file(source_path)
            if (
                post_extract_fingerprint != actual_fingerprint
                or (
                    isinstance(expected_identity, dict)
                    and post_extract_identity != expected_identity
                )
            ):
                from .models import move_to_trash

                if wav_path.exists():
                    move_to_trash(wav_path)
                raise ValueError(
                    "原始媒體檔案喺音訊提取期間已變更；已棄用提取結果，請重新匯入檔案"
                )
            self._checkpoint_if_supported(
                job_id,
                "extracted",
                [wav_path],
                {"source_content_fingerprint": actual_fingerprint},
                attempt_generation=attempt_generation,
            )
        else:
            self._on_job_progress(
                job_id,
                {"stage": "extracting", "progress": 1.0, "overall_progress": 0.08, "resumed": True},
                attempt_generation=attempt_generation,
            )

        self._transition_if_supported(
            job_id, "chunking", attempt_generation=attempt_generation
        )
        self._on_job_progress(
            job_id,
            {"stage": "chunking", "progress": 0.0, "overall_progress": 0.09},
            attempt_generation=attempt_generation,
        )
        plan = build_chunk_plan(
            wav_path,
            chunks_dir,
            cancel_requested=cancel_event.is_set,
        )
        self._checkpoint_if_supported(
            job_id,
            "chunked",
            [chunk_plan_path, *(chunk.path for chunk in plan.chunks)],
            {
                "chunk_count": len(plan.chunks),
                "source_content_fingerprint": actual_fingerprint,
            },
            attempt_generation=attempt_generation,
        )
        self._on_job_progress(
            job_id,
            {"stage": "chunking", "progress": 1.0, "overall_progress": 0.10},
            attempt_generation=attempt_generation,
        )
        return list(plan.chunks)

    def _transition_if_supported(
        self,
        job_id: str,
        state: str,
        *,
        attempt_generation: int | None = None,
    ) -> None:
        transition = getattr(self.jobs, "transition", None)
        if not callable(transition):
            return
        from .jobs import JobState

        record = self.jobs.get(job_id)
        target = JobState(state)
        if record.state == target:
            return
        ordered = (
            JobState.PROBING,
            JobState.EXTRACTING,
            JobState.CHUNKING,
            JobState.PRIMARY_ASR,
            JobState.VERIFYING,
            JobState.RECONCILING,
            JobState.NORMALIZING,
            JobState.EXPORTING,
        )
        if record.state == JobState.QUEUED and record.resume_from in ordered:
            # Resumed checkpoints still emit truthful completion progress for
            # earlier stages.  Do not turn those read-only events into illegal
            # backwards state transitions.
            if target in ordered and ordered.index(target) < ordered.index(record.resume_from):
                return
        elif record.state in ordered and target in ordered:
            if ordered.index(target) < ordered.index(record.state):
                return
        kwargs = (
            {"expected_attempt_generation": attempt_generation}
            if attempt_generation is not None
            else {}
        )
        transition(job_id, target, **kwargs)

    def _checkpoint_if_supported(
        self,
        job_id: str,
        name: str,
        artifacts: list[str | Path],
        data: dict[str, Any] | None = None,
        *,
        attempt_generation: int | None = None,
    ) -> None:
        checkpoint = getattr(self.jobs, "checkpoint", None)
        if callable(checkpoint):
            kwargs = (
                {"expected_attempt_generation": attempt_generation}
                if attempt_generation is not None
                else {}
            )
            checkpoint(job_id, name, artifacts=artifacts, data=data or {}, **kwargs)

    def _run_jobs(self) -> None:
        while True:
            job_id = self._job_queue.get()
            if job_id is None:
                return
            with self._job_queue_lock:
                attempt_generation = self._job_queue_attempts.get(job_id)
                if attempt_generation is None:
                    attempt_generation = self._record_attempt(
                        _call(self.jobs, ("get", "get_job"), job_id)
                    )
                    self._job_queue_attempts[job_id] = attempt_generation
                cancel_event = self._event_for_attempt(job_id, attempt_generation)
                self._job_running.add(job_id)
                self._job_running_attempts[job_id] = attempt_generation
            if self._shutdown_event.is_set():
                self._finish_job_queue_item(job_id, attempt_generation)
                self._job_queue.task_done()
                continue
            try:
                with self._heavy_work_lock:
                    if self._shutdown_event.is_set():
                        continue
                    job = _call(self.jobs, ("get", "get_job"), job_id)
                    job_value = _jsonable(job)
                    if (
                        "attempt_generation" in job_value
                        and self._record_attempt(job) != attempt_generation
                    ):
                        from .jobs import JobAttemptOwnershipLost

                        raise JobAttemptOwnershipLost(
                            f"queue attempt {attempt_generation} no longer owns {job_id}"
                        )
                    state_value = job_value.get("state", job_value.get("status"))
                    if state_value != "queued" or cancel_event.is_set():
                        continue
                    attempt_store: Any = (
                        _AttemptBoundJobStore(self.jobs, attempt_generation)
                        if "attempt_generation" in job_value
                        else self.jobs
                    )
                    self._transition_if_supported(
                        job_id,
                        "probing",
                        attempt_generation=(
                            attempt_generation
                            if "attempt_generation" in job_value
                            else None
                        ),
                    )
                    job = _call(attempt_store, ("get", "get_job"), job_id)
                    job_value = _jsonable(job)
                    workspace = self._canonical_job_workspace(
                        job_id,
                        job_value.get("workspace") or (self.paths.jobs / job_id),
                    )
                    chunks = self._prepare_chunks(
                        job,
                        workspace,
                        cancel_event,
                        attempt_generation=(
                            attempt_generation
                            if "attempt_generation" in job_value
                            else None
                        ),
                    )
                    pipeline = self.pipeline_factory(
                        model_manager=self.models,
                        settings=self.settings_store.get(),
                        job_store=attempt_store,
                    )
                    pipeline.run(
                        job_id=job_id,
                        workspace=workspace,
                        chunks=chunks,
                        media_path=job_value.get("source_path"),
                        vocabulary=tuple(
                            dict.fromkeys(
                                (
                                    *job_value.get("metadata", {}).get("vocabulary", ()),
                                    *job_value.get("metadata", {}).get(
                                        "correction_memory_terms", ()
                                    ),
                                )
                            )
                        ),
                        correction_memory_entries=job_value.get("metadata", {}).get(
                            "correction_memory_entries", ()
                        ),
                        correction_memory_schema=job_value.get("metadata", {}).get(
                            "correction_memory_schema"
                        ),
                        primary_model=job_value.get("metadata", {}).get("primary_model"),
                        verifier_model=job_value.get("metadata", {}).get("verifier_model"),
                        accuracy_mode=job_value.get("metadata", {}).get("accuracy_mode", False),
                        whisper_model=job_value.get("metadata", {}).get(
                            "whisper_model", WHISPER_LARGE_V3_ID
                        ),
                        local_arbiter_enabled=job_value.get("metadata", {}).get(
                            "local_arbiter_enabled", False
                        ),
                        local_arbiter_model=job_value.get("metadata", {}).get(
                            "local_arbiter_model", "google/gemma-4-12b-qat"
                        ),
                        local_arbiter_endpoint=job_value.get("metadata", {}).get(
                            "local_arbiter_endpoint",
                            "http://127.0.0.1:1234/v1/chat/completions",
                        ),
                        diarization_audio_path=workspace / "audio" / "mono-16k.wav",
                        speaker_diarization_enabled=job_value.get("metadata", {}).get(
                            "speaker_diarization_enabled",
                            self.settings_store.get().speaker_diarization_enabled,
                        ),
                        speaker_num_speakers=job_value.get("metadata", {}).get(
                            "speaker_num_speakers",
                            self.settings_store.get().speaker_num_speakers,
                        ),
                        forced_alignment_enabled=job_value.get("metadata", {}).get(
                            "forced_alignment_enabled",
                            self.settings_store.get().forced_alignment_enabled,
                        ),
                        cancelled=cancel_event.is_set,
                        interrupted=self._shutdown_event.is_set,
                        progress=lambda value: self._on_job_progress(
                            job_id,
                            value,
                            attempt_generation=(
                                attempt_generation
                                if "attempt_generation" in job_value
                                else None
                            ),
                        ),
                    )
                    self._transition_if_supported(
                        job_id,
                        "completed",
                        attempt_generation=(
                            attempt_generation
                            if "attempt_generation" in job_value
                            else None
                        ),
                    )
            except PipelineInterrupted:
                logger.info("Job interrupted for restart recovery: %s", job_id)
            except PipelineCancelled:
                logger.info("Job cancelled: %s", job_id)
            except Exception as exc:
                from .jobs import DuplicateJobError, JobAttemptOwnershipLost

                if isinstance(exc, JobAttemptOwnershipLost):
                    logger.info("Obsolete job attempt stopped without mutation: %s", job_id)
                    continue
                if self._shutdown_event.is_set() and cancel_event.is_set():
                    # Cancellation may surface before Pipeline.run (for
                    # example during fingerprinting or FFmpeg extraction).
                    # Shutdown must stop the process but leave the active job
                    # recoverable; only jobs.cancel may persist CANCELED.
                    logger.info(
                        "Job preparation interrupted for restart recovery: %s",
                        job_id,
                    )
                    continue
                logger.exception("Job failed: %s", job_id)
                duplicate_media = isinstance(exc, DuplicateJobError)
                public_error = (
                    DUPLICATE_MEDIA_UI_MESSAGE if duplicate_media else str(exc)
                )
                try:
                    update = getattr(self.jobs, "update", None) or getattr(self.jobs, "update_job", None)
                    if callable(update):
                        update(job_id, status="failed", error=public_error)
                    else:
                        from .jobs import JobState

                        record = self.jobs.get(job_id)
                        if record.attempt_generation != attempt_generation:
                            raise JobAttemptOwnershipLost(
                                f"obsolete failure handler for {job_id}"
                            )
                        if cancel_event.is_set() and record.state not in {JobState.CANCELED, JobState.COMPLETED}:
                            self.jobs.transition(
                                job_id,
                                JobState.CANCELED,
                                expected_attempt_generation=attempt_generation,
                            )
                        elif record.state not in {JobState.FAILED, JobState.CANCELED, JobState.COMPLETED}:
                            self.jobs.transition(
                                job_id, JobState.FAILED,
                                error={
                                    "code": (
                                        "duplicate_job"
                                        if duplicate_media
                                        else "pipeline_failed"
                                    ),
                                    "message": public_error,
                                },
                                expected_attempt_generation=attempt_generation,
                            )
                except Exception:
                    logger.exception("Could not persist job failure")
            finally:
                try:
                    job = _call(self.jobs, ("get", "get_job"), job_id)
                    self.emit("job.updated", job=self._present(job))
                except Exception:
                    logger.exception("Could not emit final job state")
                self._finish_job_queue_item(job_id, attempt_generation)
                self._job_queue.task_done()

    def _run_derived_tasks(self) -> None:
        while True:
            task = self._derived_queue.get()
            if task is None:
                return
            kind, job_id, target_language, token = task
            try:
                self._process_derived_task(
                    kind=kind,
                    job_id=job_id,
                    target_language=target_language,
                    token=token,
                )
            except Exception:
                logger.exception("Derived local-model task failed: %s/%s", kind, job_id)
            finally:
                self._derived_cancel.pop(token, None)
                self._derived_queue.task_done()

    def _process_derived_task(
        self,
        *,
        kind: str,
        job_id: str,
        target_language: str | None,
        token: str,
    ) -> None:
        job = _call(self.jobs, ("get", "get_job"), job_id)
        workspace = self._subtitle_projects.workspace_for_job(job_id, job)
        current = self._derived_store.read(
            workspace,
            job_id,
            kind=kind,
            target_language=target_language,
        )
        if current.get("token") != token or current.get("state") != "queued":
            return
        cancel_event = self._derived_cancel.setdefault(token, threading.Event())
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        if cancel_event.is_set() or self._shutdown_event.is_set():
            completed = self._derived_store.update(
                workspace,
                job_id,
                kind=kind,
                target_language=target_language,
                token=token,
                state="cancelled",
                progress=0.0,
                cancel_requested=False,
                completed_at=now,
                error=None,
            )
            self._emit_derived(kind, job_id, completed)
            return
        current = self._derived_store.update(
            workspace,
            job_id,
            kind=kind,
            target_language=target_language,
            token=token,
            state="generating",
            progress=0.05,
            cancel_requested=False,
            started_at=now,
            completed_at=None,
            error=None,
        )
        self._emit_derived(kind, job_id, current)

        lifecycle = None
        lifecycle_events: list[dict[str, str]] = []
        try:
            with self._heavy_work_lock:
                if cancel_event.is_set() or self._shutdown_event.is_set():
                    raise InterruptedError("cancelled")
                lifecycle, api_model, lifecycle_events, settings = self._derived_lifecycle(
                    purpose="transcript-insights"
                )
                current = self._derived_store.update(
                    workspace,
                    job_id,
                    kind=kind,
                    target_language=target_language,
                    token=token,
                    progress=0.2,
                    lifecycle=lifecycle_events,
                )
                self._emit_derived(kind, job_id, current)

                if kind == "insights":
                    source, final_sha, _, _ = self._transcript_insight_source(job_id, job)
                    if final_sha != current.get("source_final_sha256"):
                        raise ValueError("來源逐字稿已更改，請重新分析")
                    if api_model is None:
                        result: Any = build_deterministic_insights(
                            source,
                            reason=f"lifecycle_{lifecycle_events[0].get('status', 'unknown')}",
                        )
                    else:
                        client = self._insights_client_factory(
                            endpoint=settings.local_arbiter_endpoint,
                            model=api_model,
                            timeout_seconds=120.0,
                        )
                        result = client.generate(source, cancel_event=cancel_event)
                elif kind == "translation" and target_language is not None:
                    project = self._subtitle_projects.get_or_create(job_id, job)
                    if (
                        project.source_final_sha256 != current.get("source_final_sha256")
                        or project.revision != current.get("project_revision")
                    ):
                        raise ValueError("字幕 project 已更新，請重新翻譯")
                    cues = tuple(
                        {
                            "id": cue.id,
                            "start": cue.start_ms / 1_000.0,
                            "end": cue.end_ms / 1_000.0,
                            "text": cue.text.strip(),
                        }
                        for cue in project.segments
                        if cue.text.strip()
                    )
                    if api_model is None:
                        result = BilingualTranslation(
                            status="unavailable",
                            source_language="yue-Hant-HK",
                            target_language=target_language,
                            model=settings.local_arbiter_model,
                            cues=(),
                            failed_ids=tuple(cue["id"] for cue in cues),
                            reason=f"lifecycle_{lifecycle_events[0].get('status', 'unknown')}",
                        )
                    else:
                        resume_cues = None
                        if current.get("resume_model") == settings.local_arbiter_model:
                            resume_cues = _validated_partial_translation_seed(
                                current.get("resume_result"),
                                cues,
                                target_language=target_language,
                                api_model=api_model,
                            )
                        completed_by_id = {
                            cue.id: cue for cue in (resume_cues or ())
                        }
                        pending_cues = tuple(
                            cue for cue in cues if cue["id"] not in completed_by_id
                        )
                        pending_by_id = {cue["id"]: cue for cue in pending_cues}

                        def persist_translation_checkpoint(
                            checkpoint_cues: tuple[TranslatedCue, ...],
                        ) -> None:
                            nonlocal current
                            for cue in checkpoint_cues:
                                expected = pending_by_id.get(cue.id)
                                existing = completed_by_id.get(cue.id)
                                if expected is None:
                                    mismatch = "unexpected_id"
                                elif cue.source_text != expected["text"]:
                                    mismatch = "source_text"
                                elif abs(cue.start - expected["start"]) > 0.0005:
                                    mismatch = "start"
                                elif abs(cue.end - expected["end"]) > 0.0005:
                                    mismatch = "end"
                                elif existing is not None and existing != cue:
                                    mismatch = "duplicate_conflict"
                                else:
                                    mismatch = ""
                                if mismatch:
                                    raise ValueError(
                                        f"translation checkpoint cue identity 無效: {cue.id}:{mismatch}"
                                    )
                                completed_by_id[cue.id] = cue
                            checkpoint_failed_ids = tuple(
                                cue["id"] for cue in cues if cue["id"] not in completed_by_id
                            )
                            checkpoint = BilingualTranslation(
                                status="partial",
                                source_language="yue-Hant-HK",
                                target_language=target_language,
                                model=api_model,
                                cues=tuple(
                                    completed_by_id[cue["id"]]
                                    for cue in cues
                                    if cue["id"] in completed_by_id
                                ),
                                failed_ids=checkpoint_failed_ids,
                                reason="checkpoint",
                            )
                            completed_count = len(completed_by_id)
                            progress = min(
                                0.95,
                                0.2 + (0.7 * completed_count / max(1, len(cues))),
                            )
                            current = self._derived_store.update(
                                workspace,
                                job_id,
                                kind=kind,
                                target_language=target_language,
                                token=token,
                                progress=progress,
                                resume_result=checkpoint.to_dict(),
                                resume_model=settings.local_arbiter_model,
                            )
                            self._emit_derived(kind, job_id, current)

                        client = self._translation_client_factory(
                            endpoint=settings.local_arbiter_endpoint,
                            model=api_model,
                            timeout_seconds=120.0,
                        )
                        if pending_cues:
                            retry_result = client.translate_cues(
                                pending_cues,
                                target_language=target_language,
                                source_language="yue-Hant-HK",
                                cancel_event=cancel_event,
                                checkpoint_callback=persist_translation_checkpoint,
                            )
                            if (
                                retry_result.source_language != "yue-Hant-HK"
                                or retry_result.target_language != target_language
                                or retry_result.model != api_model
                            ):
                                raise ValueError("translation retry model identity 無效")
                            for cue in retry_result.cues:
                                expected = pending_by_id.get(cue.id)
                                existing = completed_by_id.get(cue.id)
                                if (
                                    expected is None
                                    or cue.source_text != expected["text"]
                                    or abs(cue.start - expected["start"]) > 0.0005
                                    or abs(cue.end - expected["end"]) > 0.0005
                                    or (existing is not None and existing != cue)
                                ):
                                    raise ValueError("translation retry cue identity 無效")
                                completed_by_id[cue.id] = cue
                            remaining_ids = tuple(
                                cue["id"] for cue in cues if cue["id"] not in completed_by_id
                            )
                            status = "completed" if not remaining_ids else (
                                "partial" if completed_by_id else "unavailable"
                            )
                            result = BilingualTranslation(
                                status=status,
                                source_language="yue-Hant-HK",
                                target_language=target_language,
                                model=api_model,
                                cues=tuple(
                                    completed_by_id[cue["id"]]
                                    for cue in cues
                                    if cue["id"] in completed_by_id
                                ),
                                failed_ids=remaining_ids,
                                reason=retry_result.reason,
                            )
                        else:
                            result = BilingualTranslation(
                                status="completed",
                                source_language="yue-Hant-HK",
                                target_language=target_language,
                                model=api_model,
                                cues=tuple(completed_by_id[cue["id"]] for cue in cues),
                            )
                else:
                    raise ValueError("derived task kind 無效")

                if cancel_event.is_set() or self._shutdown_event.is_set():
                    raise InterruptedError("cancelled")

                # Re-read immutable/revision bindings immediately before publish.
                if kind == "insights":
                    _, final_sha_after, _, _ = self._transcript_insight_source(job_id)
                    if final_sha_after != current.get("source_final_sha256"):
                        raise ValueError("來源逐字稿已更改，分析結果冇寫入")
                else:
                    latest_job = _call(self.jobs, ("get", "get_job"), job_id)
                    latest_project = self._subtitle_projects.get_or_create(job_id, latest_job)
                    if (
                        latest_project.source_final_sha256 != current.get("source_final_sha256")
                        or latest_project.revision != current.get("project_revision")
                    ):
                        raise ValueError("字幕 project 已更新，翻譯結果冇寫入")
            release_confirmed = self._release_derived_lifecycle(
                lifecycle,
                lifecycle_events,
            )
            lifecycle = None

            result_value = result.to_dict()
            result_status = result_value.get("status")
            if not release_confirmed:
                state = "failed"
                error = (
                    "本機 AI 模型未能安全釋放；結果已保留但未標記完成。"
                    "請重試，或重新開啟 App 後再處理。"
                )
                progress = 0.0
            elif kind == "translation" and result_status == "unavailable":
                state = "failed"
                error = "本機翻譯模型未能啟動，請稍後重試或喺設定揀較細模型。"
                progress = 0.0
            elif kind == "translation" and result_status == "partial":
                state = "partial"
                error = "部分字幕未能翻譯，可以重試未完成部分。"
                progress = 1.0
            else:
                state = "completed"
                error = None
                progress = 1.0
            completed = self._derived_store.update(
                workspace,
                job_id,
                kind=kind,
                target_language=target_language,
                token=token,
                state=state,
                progress=progress,
                cancel_requested=False,
                completed_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                result=result_value,
                resume_result=None,
                resume_model=None,
                error=error,
                lifecycle=lifecycle_events,
            )
            self._emit_derived(kind, job_id, completed)
        except InterruptedError:
            self._release_derived_lifecycle(lifecycle, lifecycle_events)
            preserved_result = (
                current.get("resume_result")
                if kind == "translation" and isinstance(current.get("resume_result"), Mapping)
                else None
            )
            completed = self._derived_store.update(
                workspace,
                job_id,
                kind=kind,
                target_language=target_language,
                token=token,
                state="partial" if preserved_result is not None else "cancelled",
                progress=1.0 if preserved_result is not None else 0.0,
                cancel_requested=False,
                completed_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                result=preserved_result,
                resume_result=None,
                resume_model=None,
                error=(
                    "翻譯重試已取消；之前完成部分已保留。"
                    if preserved_result is not None
                    else None
                ),
                lifecycle=lifecycle_events,
            )
            self._emit_derived(kind, job_id, completed)
        except Exception as exc:
            logger.exception("Derived local-model task failed: %s/%s", kind, job_id)
            self._release_derived_lifecycle(lifecycle, lifecycle_events)
            try:
                preserved_result = (
                    current.get("resume_result")
                    if kind == "translation" and isinstance(current.get("resume_result"), Mapping)
                    else None
                )
                failed = self._derived_store.update(
                    workspace,
                    job_id,
                    kind=kind,
                    target_language=target_language,
                    token=token,
                    state="partial" if preserved_result is not None else "failed",
                    progress=1.0 if preserved_result is not None else 0.0,
                    cancel_requested=False,
                    completed_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                    result=preserved_result,
                    resume_result=None,
                    resume_model=None,
                    error=(
                        "翻譯重試失敗；之前完成部分已保留。"
                        if preserved_result is not None
                        else str(exc)[-2_000:]
                    ),
                    lifecycle=lifecycle_events,
                )
                self._emit_derived(kind, job_id, failed)
            except Exception:
                logger.exception("Could not persist derived task failure: %s/%s", kind, job_id)

    @staticmethod
    def _timing_attention_scan_inputs(
        document: Mapping[str, Any], project: Any
    ) -> tuple[str, list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        source_text = document.get("text", document.get("final_transcript"))
        if not isinstance(source_text, str) or not source_text:
            raise ValueError("Timing Attention 缺少 immutable transcript")
        raw_words = document.get("word_timestamps")
        if not isinstance(raw_words, list) or not raw_words:
            raise ValueError("Timing Attention 缺少 Build 39 word timestamps")
        words = [dict(item) for item in raw_words if isinstance(item, Mapping)]
        if len(words) != len(raw_words):
            raise ValueError("Timing Attention word timestamps 無效")
        raw_segments = document.get("subtitle_segments")
        if not isinstance(raw_segments, list) or not raw_segments:
            raw_segments = document.get("segments")
        if not isinstance(raw_segments, list) or not raw_segments:
            raise ValueError("Timing Attention 缺少 immutable source segments")
        segments: list[dict[str, Any]] = []
        for index, item in enumerate(raw_segments):
            if not isinstance(item, Mapping):
                raise ValueError("Timing Attention source segment 無效")
            segments.append(
                {
                    "index": index,
                    "source_start": item.get("source_start"),
                    "source_end": item.get("source_end"),
                    "start_ms": item.get("start_ms"),
                    "end_ms": item.get("end_ms"),
                }
            )
        project_value = project.to_dict()
        raw_cues = project_value.get("segments")
        if not isinstance(raw_cues, list) or not raw_cues:
            raise ValueError("Timing Attention project 未有字幕 cues")
        cues = [dict(item) for item in raw_cues if isinstance(item, Mapping)]
        if len(cues) != len(raw_cues):
            raise ValueError("Timing Attention project cues 無效")
        return source_text, segments, words, cues

    def _timing_attention_update_status(
        self, job_id: str, token: str, **fields: Any
    ) -> dict[str, Any] | None:
        with self._timing_attention_lock:
            current = self._timing_attention_statuses.get(job_id)
            if not isinstance(current, dict) or current.get("token") != token:
                return None
            updated = {**current, **fields}
            self._timing_attention_statuses[job_id] = updated
        self.emit(
            "subtitle.timing_attention.updated",
            job_id=job_id,
            timing_attention=updated,
        )
        return updated

    def _timing_attention_commit_result(
        self,
        *,
        job_id: str,
        token: str,
        workspace: Path,
        result: Mapping[str, Any],
        cancel_event: threading.Event,
        temporary: Path,
    ) -> dict[str, Any] | None:
        """Linearize cancellation against the only diagnostic artifact write.

        Cancellation and completion both use ``_timing_attention_lock`` as their
        commit point.  If cancellation wins the lock, no artifact is written.  If
        completion wins, the result and in-memory status become completed before a
        later cancel request can observe a cancellable scan.
        """

        with self._timing_attention_lock:
            active = self._timing_attention_statuses.get(job_id)
            if (
                cancel_event.is_set()
                or self._shutdown_event.is_set()
                or not isinstance(active, dict)
                or active.get("token") != token
                or active.get("status") != "running"
            ):
                return None
            publication = publish_timing_attention_result(workspace, temporary)
            runtime = dict(result.get("runtime", {}))
            if publication.durability_warning is not None:
                runtime["durability_warning"] = publication.durability_warning
            completed = {
                **result,
                "runtime": runtime,
                "token": token,
                "progress": 1.0,
                "error": None,
            }
            self._timing_attention_statuses[job_id] = completed
            return completed

    def _run_timing_attention_scans(self) -> None:
        while True:
            queued_item = self._timing_attention_queue.get()
            if queued_item is None:
                return
            job_id, expected_revision, token = queued_item
            cancel_event = self._timing_attention_cancel.setdefault(
                job_id, threading.Event()
            )
            try:
                with self._timing_attention_lock:
                    queued = self._timing_attention_statuses.get(job_id)
                    if (
                        not isinstance(queued, dict)
                        or queued.get("token") != token
                        or queued.get("status") != "queued"
                    ):
                        continue
                if self._shutdown_event.is_set():
                    cancel_event.set()
                if cancel_event.is_set():
                    raise ASRCancelled("Timing Attention Scan 已取消")
                with self._heavy_work_lock:
                    if cancel_event.is_set() or self._shutdown_event.is_set():
                        raise ASRCancelled("Timing Attention Scan 已取消")
                    running = self._timing_attention_update_status(
                        job_id,
                        token,
                        status="running",
                        started_at=datetime.now(timezone.utc)
                        .isoformat()
                        .replace("+00:00", "Z"),
                        progress=0.01,
                        error=None,
                    )
                    if running is None:
                        continue
                    job, workspace = self._subtitle_job_and_workspace(job_id)
                    document, source_final_sha256, loaded_workspace = (
                        self._subtitle_projects.load_final_document(job_id, job)
                    )
                    if loaded_workspace != workspace:
                        raise ValueError("Timing Attention workspace identity 無效")
                    project = self._subtitle_projects.get_or_create(job_id, job)
                    if project.revision != expected_revision:
                        raise ValueError(
                            f"stale_revision：目前 revision 係 {project.revision}，"
                            f"唔係 {expected_revision}"
                        )
                    if project.source_final_sha256 != source_final_sha256:
                        raise ValueError("Timing Attention final transcript identity 已改變")
                    source_text, segments, words, cues = self._timing_attention_scan_inputs(
                        document, project
                    )

                    def on_progress(event: dict[str, Any]) -> None:
                        if cancel_event.is_set():
                            return
                        try:
                            fraction = min(0.99, max(0.01, float(event.get("progress", 0.0))))
                        except (TypeError, ValueError):
                            fraction = 0.01
                        self._timing_attention_update_status(
                            job_id,
                            token,
                            progress=fraction,
                            phase=str(event.get("phase") or "scanning")[:64],
                        )

                    result = self._timing_attention_scanner.scan(
                        job_id=job_id,
                        project_revision=expected_revision,
                        source_final_sha256=source_final_sha256,
                        workspace=workspace,
                        audio_path=workspace / "audio" / "mono-16k.wav",
                        source_text=source_text,
                        segments=segments,
                        baseline_words=words,
                        cues=cues,
                        wenet_model=self.models.path_for(SHERPA_MODEL_NAME),
                        sensevoice_model=self.models.path_for(SENSEVOICE_YUE_MODEL_NAME),
                        progress=on_progress,
                        cancelled=cancel_event.is_set,
                    )
                    if cancel_event.is_set() or self._shutdown_event.is_set():
                        raise ASRCancelled("Timing Attention Scan 已取消")
                    latest = self._subtitle_projects.get_or_create(job_id, job)
                    if latest.revision != expected_revision:
                        raise ValueError(
                            f"stale_revision：scan 期間 project 已更新至 {latest.revision}"
                        )
                    if latest.source_final_sha256 != source_final_sha256:
                        raise ValueError("Timing Attention final transcript identity 已改變")
                    cue_word_capacities = timing_attention_cue_word_capacities(
                        words, cues
                    )
                    temporary = prepare_timing_attention_result(
                        workspace,
                        result,
                        cue_word_capacities=cue_word_capacities,
                        media_duration_ms=project.duration_ms,
                    )
                    try:
                        completed = self._timing_attention_commit_result(
                            job_id=job_id,
                            token=token,
                            workspace=workspace,
                            result=result,
                            cancel_event=cancel_event,
                            temporary=temporary,
                        )
                    finally:
                        temporary.unlink(missing_ok=True)
                    if completed is None:
                        raise ASRCancelled("Timing Attention Scan 已取消")
                self.emit(
                    "subtitle.timing_attention.updated",
                    job_id=job_id,
                    timing_attention=completed,
                )
            except ASRCancelled:
                self._timing_attention_update_status(
                    job_id,
                    token,
                    status="cancelled",
                    progress=0.0,
                    pending_count=0,
                    cues=[],
                    error=None,
                    completed_at=datetime.now(timezone.utc)
                    .isoformat()
                    .replace("+00:00", "Z"),
                )
            except Exception as exc:
                logger.exception("Timing Attention scan failed: %s", job_id)
                self._timing_attention_update_status(
                    job_id,
                    token,
                    status="failed",
                    progress=0.0,
                    pending_count=0,
                    cues=[],
                    error=str(exc)[-2_000:],
                    completed_at=datetime.now(timezone.utc)
                    .isoformat()
                    .replace("+00:00", "Z"),
                )
            finally:
                self._timing_attention_queue.task_done()

    def _run_subtitle_renders(self) -> None:
        while True:
            queued_item = self._subtitle_render_queue.get()
            if queued_item is None:
                return
            job_id, render_token = queued_item
            if self._shutdown_event.is_set():
                self._subtitle_render_queue.task_done()
                continue
            cancel_event = self._subtitle_render_cancel.setdefault(job_id, threading.Event())
            if self._shutdown_event.is_set():
                cancel_event.set()
            try:
                job, workspace = self._subtitle_job_and_workspace(job_id)
                with self._heavy_work_lock:
                    render = self._subtitle_renderer.status(workspace, job_id)
                    if (
                        render.get("state") != "queued"
                        or render.get("output_filename") != render_token
                        or cancel_event.is_set()
                    ):
                        continue
                    project = self._subtitle_projects.get_or_create(job_id, job)
                    self._subtitle_project_revisions[job_id] = project.revision
                    if render.get("project_revision") != project.revision:
                        raise ValueError("字幕影片 project revision 已過期，請重新開始輸出")
                    if render.get("source_final_sha256") != project.source_final_sha256:
                        raise ValueError("字幕影片來源逐字稿已更改，請重新開始輸出")
                    if render.get("source_path") != project.source_path:
                        raise ValueError("字幕影片來源路徑同 project 唔一致")
                    if render.get("source_fingerprint") != project.source_fingerprint:
                        raise ValueError("字幕影片來源 fingerprint 同 project 唔一致")
                    render_content = render.get("render_content", "source")
                    render_project = project
                    if render_content == "source":
                        if any(
                            render.get(key) is not None
                            for key in (
                                "target_language",
                                "translation_layout",
                                "translation_artifact_sha256",
                                "translation_result_sha256",
                            )
                        ):
                            raise ValueError("原文字幕 render manifest 含有無效翻譯 identity")
                    elif render_content in BILINGUAL_EXPORT_LAYOUTS:
                        target_language = render.get("target_language")
                        translation_layout = render.get("translation_layout")
                        artifact_identity = render.get("translation_artifact_sha256")
                        if (
                            not isinstance(target_language, str)
                            or translation_layout != render_content
                            or not isinstance(artifact_identity, str)
                        ):
                            raise ValueError("雙語字幕 render manifest identity 無效")
                        (
                            render_project,
                            current_translation,
                            result_identity,
                        ) = self._translation_render_snapshot(
                            workspace=workspace,
                            job_id=job_id,
                            project=project,
                            target_language=target_language,
                            translation_layout=translation_layout,
                            expected_payload_sha256=artifact_identity,
                        )
                        if not hmac.compare_digest(
                            str(render.get("translation_result_sha256") or ""),
                            result_identity,
                        ):
                            raise ValueError("翻譯結果 identity 已變更，請重新開始輸出")
                        if not hmac.compare_digest(
                            str(current_translation.get("payload_sha256") or ""),
                            artifact_identity,
                        ):
                            raise ValueError("翻譯 artifact identity 已變更，請重新開始輸出")
                    else:
                        raise ValueError("字幕影片內容類型無效")
                    # Real renderer manifests always include an ASS filename.
                    # Older test doubles/legacy source-only queue records may
                    # omit it, while translated renders are never accepted
                    # without the full sealed identity.
                    if render.get("ass_filename") is not None:
                        expected_ass_identity = (
                            "sha256:"
                            + hashlib.sha256(
                                generate_ass(
                                    render_project,
                                    width=int(render["width"]),
                                    height=int(render["height"]),
                                ).encode("utf-8")
                            ).hexdigest()
                        )
                        if not hmac.compare_digest(
                            str(render.get("ass_sha256") or ""), expected_ass_identity
                        ):
                            raise ValueError("字幕內容或 ASS identity 已變更，請重新開始輸出")
                    render["ffmpeg_path"] = resolve_subtitle_ffmpeg()
                    render["ffprobe_path"] = resolve_subtitle_ffprobe(str(render["ffmpeg_path"]))
                    render.update(
                        {
                            "state": "rendering",
                            "started_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "completed_at": None,
                            "error": None,
                            "cancel_requested": False,
                        }
                    )
                    render = self._subtitle_renderer.save_status(workspace, render)
                    self.emit(
                        "subtitle.render.updated",
                        job_id=job_id,
                        render=self._render_view_for_job(job_id, render),
                    )
                    last_saved_progress = float(render.get("progress", 0.0))
                    last_saved_at = 0.0

                    def on_progress(fraction: float, event: Any) -> None:
                        nonlocal render, last_saved_progress, last_saved_at
                        render = {**render, "progress": fraction}
                        now = time.monotonic()
                        if fraction - last_saved_progress >= 0.01 or now - last_saved_at >= 1.0:
                            render = self._subtitle_renderer.save_status(workspace, render)
                            last_saved_progress = fraction
                            last_saved_at = now
                        self.emit(
                            "subtitle.render.progress",
                            job_id=job_id,
                            progress=fraction,
                            render=self._render_view_for_job(job_id, render),
                        )

                    completed = self._subtitle_renderer.execute(
                        workspace=workspace,
                        manifest=render,
                        cancel_event=cancel_event,
                        progress_callback=on_progress,
                    )
                self.emit(
                    "subtitle.render.updated",
                    job_id=job_id,
                    render=self._render_view_for_job(job_id, completed),
                )
            except RenderCancelled:
                try:
                    _, workspace = self._subtitle_job_and_workspace(job_id)
                    render = self._subtitle_renderer.status(workspace, job_id)
                    render.update(
                        {
                            "state": "cancelled",
                            "cancel_requested": False,
                            "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "error": None,
                        }
                    )
                    render = self._subtitle_renderer.save_status(workspace, render)
                    self.emit(
                        "subtitle.render.updated",
                        job_id=job_id,
                        render=self._render_view_for_job(job_id, render),
                    )
                except Exception:
                    logger.exception("Could not persist cancelled subtitle render: %s", job_id)
            except Exception as exc:
                logger.exception("Subtitle render failed: %s", job_id)
                try:
                    _, workspace = self._subtitle_job_and_workspace(job_id)
                    render = self._subtitle_renderer.status(workspace, job_id)
                    render.update(
                        {
                            "state": "failed",
                            "cancel_requested": False,
                            "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "error": str(exc)[-4000:],
                        }
                    )
                    render = self._subtitle_renderer.save_status(workspace, render)
                    self.emit(
                        "subtitle.render.updated",
                        job_id=job_id,
                        render=self._render_view_for_job(job_id, render),
                    )
                except Exception:
                    logger.exception("Could not persist subtitle render failure: %s", job_id)
            finally:
                self._subtitle_render_queue.task_done()

    def _run_subtitle_previews(self) -> None:
        while True:
            queued_item = self._subtitle_preview_queue.get()
            if queued_item is None:
                return
            job_id, preview_token = queued_item
            if self._shutdown_event.is_set():
                self._subtitle_preview_queue.task_done()
                continue
            cancel_event = self._subtitle_preview_cancel.setdefault(job_id, threading.Event())
            if self._shutdown_event.is_set():
                cancel_event.set()
            try:
                job, workspace = self._subtitle_job_and_workspace(job_id)
                with self._heavy_work_lock:
                    preview = self._subtitle_previews.status(workspace, job_id)
                    if (
                        preview.get("state") != "queued"
                        or preview.get("token") != preview_token
                        or cancel_event.is_set()
                    ):
                        continue
                    project = self._subtitle_projects.get_or_create(job_id, job)
                    if preview.get("source_final_sha256") != project.source_final_sha256:
                        raise ValueError("Preview 來源逐字稿已更改，請重新建立")
                    if preview.get("source_path") != project.source_path:
                        raise ValueError("Preview 來源路徑同 project 唔一致")
                    if preview.get("source_fingerprint") != project.source_fingerprint:
                        raise ValueError("Preview 來源 fingerprint 同 project 唔一致")
                    preview["ffmpeg_path"] = resolve_subtitle_ffmpeg()
                    preview["ffprobe_path"] = resolve_subtitle_ffprobe(str(preview["ffmpeg_path"]))
                    preview.update(
                        {
                            "state": "rendering",
                            "started_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "completed_at": None,
                            "error": None,
                            "cancel_requested": False,
                        }
                    )
                    preview = self._subtitle_previews.save_status(workspace, preview)
                    self.emit("subtitle.preview.updated", job_id=job_id, preview=preview)
                    last_saved_progress = float(preview.get("progress", 0.0))
                    last_saved_at = 0.0

                    def on_progress(fraction: float, event: Any) -> None:
                        nonlocal preview, last_saved_progress, last_saved_at
                        preview = {**preview, "progress": fraction}
                        now = time.monotonic()
                        if fraction - last_saved_progress >= 0.01 or now - last_saved_at >= 1.0:
                            preview = self._subtitle_previews.save_status(workspace, preview)
                            last_saved_progress = fraction
                            last_saved_at = now
                        self.emit(
                            "subtitle.preview.progress",
                            job_id=job_id,
                            progress=fraction,
                            preview=preview,
                        )

                    completed = self._subtitle_previews.execute(
                        workspace=workspace,
                        manifest=preview,
                        cancel_event=cancel_event,
                        progress_callback=on_progress,
                    )
                self.emit("subtitle.preview.updated", job_id=job_id, preview=completed)
            except PreviewCancelled:
                try:
                    _, workspace = self._subtitle_job_and_workspace(job_id)
                    preview = self._subtitle_previews.status(workspace, job_id)
                    preview.update(
                        {
                            "state": "cancelled",
                            "cancel_requested": False,
                            "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "error": None,
                        }
                    )
                    preview = self._subtitle_previews.save_status(workspace, preview)
                    self.emit("subtitle.preview.updated", job_id=job_id, preview=preview)
                except Exception:
                    logger.exception("Could not persist cancelled subtitle preview: %s", job_id)
            except Exception as exc:
                logger.exception("Subtitle preview failed: %s", job_id)
                try:
                    _, workspace = self._subtitle_job_and_workspace(job_id)
                    preview = self._subtitle_previews.status(workspace, job_id)
                    preview.update(
                        {
                            "state": "failed",
                            "cancel_requested": False,
                            "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                            "error": str(exc)[-4000:],
                        }
                    )
                    preview = self._subtitle_previews.save_status(workspace, preview)
                    self.emit("subtitle.preview.updated", job_id=job_id, preview=preview)
                except Exception:
                    logger.exception("Could not persist subtitle preview failure: %s", job_id)
            finally:
                self._subtitle_preview_queue.task_done()

    def _on_job_progress(
        self,
        job_id: str,
        value: dict[str, Any],
        *,
        attempt_generation: int | None = None,
    ) -> None:
        overall = value.get("overall_progress")
        if overall is not None:
            try:
                stage_to_state = {
                    "primary": "primary_asr", "verifier": "verifying",
                    "alignment": "reconciling", "final": "normalizing",
                    "timestamps": "normalizing", "exports": "exporting",
                }
                stage = value.get("stage")
                if stage in stage_to_state:
                    self._transition_if_supported(
                        job_id,
                        stage_to_state[stage],
                        attempt_generation=attempt_generation,
                    )
                update_progress = getattr(self.jobs, "update_progress", None)
                if callable(update_progress):
                    record = _call(self.jobs, ("get", "get_job"), job_id)
                    if (
                        attempt_generation is not None
                        and self._record_attempt(record) != attempt_generation
                    ):
                        from .jobs import JobAttemptOwnershipLost

                        raise JobAttemptOwnershipLost(
                            f"obsolete progress callback for {job_id}"
                        )
                    persisted = max(float(getattr(record, "progress", 0.0)), float(overall))
                    kwargs = (
                        {"expected_attempt_generation": attempt_generation}
                        if attempt_generation is not None
                        else {}
                    )
                    update_progress(job_id, persisted, **kwargs)
                else:
                    _call(self.jobs, ("update", "update_job"), job_id, progress=overall, stage=stage)
            except Exception as exc:
                from .jobs import JobAttemptOwnershipLost

                if isinstance(exc, JobAttemptOwnershipLost):
                    logger.info("Ignored obsolete progress for %s", job_id)
                    return
                logger.exception("Could not persist progress")
        try:
            job = self._present(_call(self.jobs, ("get", "get_job"), job_id))
        except Exception:
            logger.exception("Could not present job progress")
            job = None
        self.emit("job.progress", job_id=job_id, job=job, progress=value)

    def handle_line(self, line: str) -> None:
        request_id: str | None = None
        try:
            request = parse_request(line)
            request_id = request["id"]
            result = self.dispatcher.dispatch(request["method"], request["params"])
            self._write(result_message(request_id, result))
        except ProtocolError as exc:
            self._write(error_message(exc.request_id, exc.code, str(exc)))
        except MethodNotFound as exc:
            self._write(error_message(request_id, "method_not_found", str(exc)))
        except (ValueError, KeyError, FileNotFoundError) as exc:
            self._write(error_message(request_id, "invalid_input", str(exc)))
        except Exception as exc:
            from .jobs import DuplicateJobError

            if isinstance(exc, DuplicateJobError):
                logger.info(
                    "Duplicate media request rejected; existing job=%s",
                    exc.existing_job_id,
                )
                self._write(
                    error_message(
                        request_id,
                        "duplicate_job",
                        DUPLICATE_MEDIA_UI_MESSAGE,
                    )
                )
                return
            logger.exception("Worker request failed")
            self.stderr.write(traceback.format_exc())
            self.stderr.flush()
            self._write(error_message(request_id, "internal_error", f"處理失敗：{exc}"))

    def serve(self, stdin: TextIO | None = None) -> None:
        source = stdin or sys.stdin
        try:
            for line in source:
                line = line.strip()
                if line:
                    self.handle_line(line)
        finally:
            self.shutdown()


def configure_logging(paths: AppPaths) -> None:
    paths.ensure()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
        handlers=[logging.FileHandler(paths.logs / "worker.log", encoding="utf-8"), logging.StreamHandler(sys.stderr)],
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m cts_backend.worker")
    parser.add_argument("--health-check", action="store_true", help="print health JSON and exit")
    parser.add_argument(
        "--no-recover",
        action="store_true",
        help="start without changing or enqueueing pre-existing jobs (smoke-test use)",
    )
    arguments = parser.parse_args(argv)
    paths = AppPaths.default().ensure()
    configure_logging(paths)
    logger.info("CTS backend source=%s", Path(__file__).resolve())
    if arguments.health_check:
        worker = Worker(paths=paths, recover=False, start_runner=False, enable_local_api=False)
        sys.stdout.write(json.dumps(worker._health({}), ensure_ascii=False, separators=(",", ":")) + "\n")
        sys.stdout.flush()
        return 0
    try:
        worker_lock = acquire_worker_lock(paths)
    except OSError:
        logger.error("另一個 Cantonese Transcript Studio worker 已經運行緊")
        return 3
    try:
        # This is a privacy cleanup, not job recovery: it always runs after
        # the exclusive worker lock, including --no-recover starts. It scans
        # Jobs only for direct UUID archives that still carry our pending
        # marker; marker-free published archives are never guessed stale.
        from .live_caption.timing_archive import (
            recover_pending_live_timing_archive_publications,
            recover_stale_live_timing_archive_staging,
        )

        timing_staging_recovery = recover_stale_live_timing_archive_staging(
            paths.runtime
        )
        timing_publication_recovery = recover_pending_live_timing_archive_publications(
            paths.jobs
        )
        if (
            timing_staging_recovery.failed_count
            or timing_publication_recovery.failed_count
        ):
            raise RuntimeError("未能安全清除舊 timing archive 暫存")
        if timing_staging_recovery.removed_count:
            logger.warning(
                "Removed %d abandoned local timing archive staging directories",
                timing_staging_recovery.removed_count,
            )
        if timing_staging_recovery.skipped_count:
            logger.warning(
                "Skipped %d unrecognized timing archive staging entries",
                timing_staging_recovery.skipped_count,
            )
        if timing_publication_recovery.removed_count:
            logger.warning(
                "Removed %d pending local timing archive publications",
                timing_publication_recovery.removed_count,
            )
        if timing_publication_recovery.skipped_count:
            logger.warning(
                "Preserved %d unverified timing archive receipt entries",
                timing_publication_recovery.skipped_count,
            )
    except Exception:
        logger.exception("Could not safely recover local timing archive staging")
        fcntl.flock(worker_lock.fileno(), fcntl.LOCK_UN)
        worker_lock.close()
        return 4
    worker = Worker(paths=paths, recover=not arguments.no_recover)

    def stop_worker(signum: int, frame: Any) -> None:
        del frame
        worker.shutdown()
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, stop_worker)
    signal.signal(signal.SIGINT, stop_worker)
    try:
        worker.serve()
        return 0
    finally:
        fcntl.flock(worker_lock.fileno(), fcntl.LOCK_UN)
        worker_lock.close()


if __name__ == "__main__":
    raise SystemExit(main())
