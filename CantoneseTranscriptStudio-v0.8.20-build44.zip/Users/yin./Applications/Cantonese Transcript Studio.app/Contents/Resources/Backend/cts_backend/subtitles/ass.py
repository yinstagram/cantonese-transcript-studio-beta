"""Deterministic Advanced SubStation Alpha generation."""

from __future__ import annotations

from .schemas import SubtitleProject, SubtitleStyle


WORD_JOINER = "\u2060"


def ass_timestamp(milliseconds: int) -> str:
    """Round to ASS centiseconds and format without locale dependencies."""
    centiseconds = max(0, (milliseconds + 5) // 10)
    hours, remainder = divmod(centiseconds, 360_000)
    minutes, remainder = divmod(remainder, 6_000)
    seconds, fraction = divmod(remainder, 100)
    return f"{hours}:{minutes:02d}:{seconds:02d}.{fraction:02d}"


def rgba_to_ass(value: str) -> str:
    """Convert #RRGGBBAA to ASS &HAABBGGRR (ASS alpha is inverted)."""
    red = value[1:3]
    green = value[3:5]
    blue = value[5:7]
    alpha = 255 - int(value[7:9], 16)
    return f"&H{alpha:02X}{blue}{green}{red}"


def escape_ass_text(value: str) -> str:
    """Preserve visible text while neutralising ASS override/control injection."""
    normalized = value.replace("\r\n", "\n").replace("\r", "\n")
    # A word joiner after a literal slash prevents user text such as ``\N``
    # becoming an ASS control sequence while remaining visually unchanged.
    normalized = normalized.replace("\\", "\\" + WORD_JOINER)
    normalized = normalized.replace("{", r"\{").replace("}", r"\}")
    return normalized.replace("\n", r"\N")


def _number(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else f"{value:.2f}".rstrip("0").rstrip(".")


def _render_scale(height: int) -> float:
    """Scale UI style pixels from the 1080p design canvas to the source video.

    Subtitle style values are edited against a 1080p preview.  Writing those
    values unchanged into a 360p/720p ASS canvas makes otherwise valid captions
    cover most of the picture (and bilingual captions can be clipped entirely).
    Keep the physical proportions deterministic while retaining useful lower
    bounds for tiny proxy media.
    """

    return min(2.0, max(0.25, height / 1080.0))


def _style_line(name: str, style: SubtitleStyle, *, height: int) -> str:
    scale = _render_scale(height)
    font_size = max(16.0, style.font_size_px * scale)
    margin_bottom = max(12.0, style.margin_bottom_px * scale)
    primary = rgba_to_ass(style.text_color_rgba)
    shadow_colour = rgba_to_ass(style.shadow_color_rgba)
    if style.background_enabled:
        border_style = 3
        outline = max(1.0, style.background_padding_px * scale)
        outline_colour = rgba_to_ass(style.background_color_rgba)
    else:
        border_style = 1
        outline = max(1.0, 2.0 * scale)
        outline_colour = "&H00000000"
    shadow = max(1.0, style.shadow_depth_px * scale) if style.shadow_enabled else 0.0
    if not style.shadow_enabled:
        shadow_colour = "&HFF000000"
    italic = -1 if style.italic else 0
    return (
        f"Style: {name},{style.font_family},{_number(font_size)},{primary},{primary},"
        f"{outline_colour},{shadow_colour},0,{italic},0,0,100,100,0,0,{border_style},"
        f"{_number(outline)},{_number(shadow)},2,40,40,{round(margin_bottom)},1"
    )


def generate_ass(project: SubtitleProject, *, width: int, height: int) -> str:
    if width <= 0 or height <= 0 or width > 16_384 or height > 16_384:
        raise ValueError("影片尺寸無效")
    speaker_names = {
        speaker.id: f"Speaker{index:03d}"
        for index, speaker in enumerate(project.speakers, start=1)
    }
    speaker_profiles = {speaker.id: speaker for speaker in project.speakers}
    lines = [
        "[Script Info]",
        "; Generated locally by Cantonese Transcript Studio",
        "ScriptType: v4.00+",
        f"PlayResX: {width}",
        f"PlayResY: {height}",
        "ScaledBorderAndShadow: yes",
        "WrapStyle: 0",
        "",
        "[V4+ Styles]",
        (
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
            "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, "
            "ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
            "MarginL, MarginR, MarginV, Encoding"
        ),
        _style_line("Default", project.style, height=height),
        *(
            _style_line(
                speaker_names[speaker.id],
                speaker.style.resolve(project.style),
                height=height,
            )
            for speaker in project.speakers
        ),
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    for cue in project.segments:
        if not cue.text.strip():
            continue
        start_cs = max(0, (cue.start_ms + 5) // 10)
        end_cs = max(start_cs + 1, (cue.end_ms + 5) // 10)
        start = ass_timestamp(start_cs * 10)
        end = ass_timestamp(end_cs * 10)
        profile = speaker_profiles.get(cue.speaker_id or "")
        style_name = speaker_names.get(cue.speaker_id or "", "Default")
        # ASS actor/name is metadata rather than visible caption text.  Replacing
        # commas keeps the event field structurally safe while preserving the
        # user's editable anonymous label in a human-readable form.
        actor = profile.display_name.replace(",", "，") if profile is not None else ""
        visible_text = (
            f"{profile.display_name}：{cue.text}"
            if profile is not None and profile.show_name
            else cue.text
        )
        lines.append(
            f"Dialogue: 0,{start},{end},{style_name},{actor},0,0,0,,"
            f"{escape_ass_text(visible_text)}"
        )
    return "\n".join(lines) + "\n"


__all__ = ["ass_timestamp", "escape_ass_text", "generate_ass", "rgba_to_ass"]
