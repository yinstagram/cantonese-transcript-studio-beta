from __future__ import annotations

import json
import math
import os
import selectors
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..constants import (
    SUPPORTED_MEDIA_EXTENSIONS,
    TARGET_CHANNELS,
    TARGET_CODEC,
    TARGET_SAMPLE_RATE,
    normalized_extension,
)
from ..models import move_to_trash
from ..schemas import AudioStreamMetadata, MediaMetadata


class UnsupportedMediaError(ValueError):
    pass


class MediaProbeError(RuntimeError):
    pass


class NoAudioStreamError(MediaProbeError):
    pass


class AudioExtractionError(RuntimeError):
    pass


FFPROBE_TIMEOUT_SECONDS = 30.0
FFMPEG_EXTRACTION_TIMEOUT_SECONDS = 6 * 60 * 60.0
PROCESS_TERMINATION_GRACE_SECONDS = 2.0
PROCESS_POLL_SECONDS = 0.10
PROCESS_PIPE_DRAIN_SECONDS = 1.0
MAX_STDOUT_BYTES = 8 * 1024 * 1024
MAX_STDERR_TAIL_BYTES = 128 * 1024
MAX_PROGRESS_LINE_BYTES = 1024 * 1024


class OwnedProcessCancelled(RuntimeError):
    pass


class OwnedProcessDeadlineExceeded(RuntimeError):
    pass


class OwnedProcessOutputLimitExceeded(RuntimeError):
    pass


def _positive_finite(value: float, *, label: str) -> float:
    if isinstance(value, bool) or not math.isfinite(float(value)) or float(value) <= 0:
        raise ValueError(f"{label} must be a positive finite number")
    return float(value)


def _group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _signal_group(process_group_id: int, signum: int) -> None:
    try:
        os.killpg(process_group_id, signum)
    except (ProcessLookupError, PermissionError):
        pass


def terminate_owned_process_group(
    process: subprocess.Popen[Any], *, grace_seconds: float
) -> None:
    """Bounded TERM -> KILL for the wrapper and all native descendants."""

    group_id = process.pid
    if group_id <= 1 or group_id in {os.getpid(), os.getpgrp()}:
        raise ValueError("refusing to signal an unsafe process group")
    started = time.monotonic()
    grace = min(5.0, max(0.0, float(grace_seconds)))
    _signal_group(group_id, signal.SIGTERM)
    term_deadline = started + grace
    while time.monotonic() < term_deadline:
        if process.poll() is not None and not _group_exists(group_id):
            break
        time.sleep(0.01)
    if _group_exists(group_id):
        _signal_group(group_id, signal.SIGKILL)
    try:
        process.wait(timeout=1.0)
    except subprocess.TimeoutExpired:
        _signal_group(group_id, signal.SIGKILL)


def owned_process_command(command: Sequence[str]) -> list[str]:
    return [
        sys.executable,
        str(Path(__file__).with_name("process_child.py")),
        "--parent-pid",
        str(os.getpid()),
        "--",
        *command,
    ]


def _append_tail(buffer: bytearray, data: bytes, *, maximum: int) -> None:
    buffer.extend(data)
    excess = len(buffer) - maximum
    if excess > 0:
        del buffer[:excess]


def run_owned_process(
    command: Sequence[str],
    *,
    timeout_seconds: float,
    termination_grace_seconds: float,
    cancel_requested: Callable[[], bool] | None = None,
    stdout_consumer: Callable[[bytes], None] | None = None,
    stderr_consumer: Callable[[bytes], None] | None = None,
    stdout_limit_bytes: int = MAX_STDOUT_BYTES,
    working_directory: str | Path | None = None,
    environment: Mapping[str, str] | None = None,
) -> tuple[int, bytes, bytes]:
    """Run one owned local process while continuously draining both pipes.

    The private wrapper is the process-group leader and watches this Python
    parent.  That gives callers the same bounded cleanup guarantee both during
    ordinary cancellation and when the backend itself is killed abruptly.
    """

    timeout = _positive_finite(timeout_seconds, label="timeout_seconds")
    grace = _positive_finite(
        termination_grace_seconds, label="termination_grace_seconds"
    )
    if (
        isinstance(stdout_limit_bytes, bool)
        or not isinstance(stdout_limit_bytes, int)
        or stdout_limit_bytes <= 0
    ):
        raise ValueError("stdout_limit_bytes must be a positive integer")
    try:
        process = subprocess.Popen(
            owned_process_command(command),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            close_fds=True,
            start_new_session=True,
            shell=False,
            cwd=working_directory,
            env=environment,
        )
    except OSError:
        raise

    selector = selectors.DefaultSelector()
    stdout = bytearray()
    stdout_seen = 0
    stderr_tail = bytearray()
    exit_drain_deadline: float | None = None
    unexpected_descendants = False
    deadline = time.monotonic() + timeout
    streams: tuple[tuple[Any, str], ...] = (
        (process.stdout, "stdout"),
        (process.stderr, "stderr"),
    )
    try:
        for stream, channel in streams:
            assert stream is not None
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, channel)

        while selector.get_map() or process.poll() is None:
            now = time.monotonic()
            if cancel_requested is not None and cancel_requested():
                raise OwnedProcessCancelled
            if now >= deadline:
                raise OwnedProcessDeadlineExceeded

            return_code = process.poll()
            if return_code is not None and exit_drain_deadline is None:
                exit_drain_deadline = now + PROCESS_PIPE_DRAIN_SECONDS
            if exit_drain_deadline is not None and now >= exit_drain_deadline:
                # A descendant retained a pipe after the wrapper exited.  It
                # is part of our isolated group and must not outlive the job.
                unexpected_descendants = True
                terminate_owned_process_group(process, grace_seconds=grace)
                break

            wait_seconds = min(PROCESS_POLL_SECONDS, max(0.0, deadline - now))
            for key, _ in selector.select(wait_seconds):
                stream = key.fileobj
                while True:
                    try:
                        data = os.read(stream.fileno(), 64 * 1024)
                    except BlockingIOError:
                        break
                    if not data:
                        try:
                            selector.unregister(stream)
                        except KeyError:
                            pass
                        stream.close()
                        break
                    if key.data == "stdout":
                        stdout_seen += len(data)
                        if stdout_seen > stdout_limit_bytes:
                            raise OwnedProcessOutputLimitExceeded
                        if stdout_consumer is not None:
                            stdout_consumer(data)
                        else:
                            stdout.extend(data)
                    else:
                        _append_tail(
                            stderr_tail, data, maximum=MAX_STDERR_TAIL_BYTES
                        )
                        if stderr_consumer is not None:
                            stderr_consumer(data)
                    if len(data) < 64 * 1024:
                        break

        return_code = process.poll()
        if return_code is None:
            try:
                return_code = process.wait(timeout=0.1)
            except subprocess.TimeoutExpired:
                terminate_owned_process_group(process, grace_seconds=grace)
                return_code = process.returncode
        if _group_exists(process.pid):
            # The wrapper has returned but one of its descendants has not.
            unexpected_descendants = True
            terminate_owned_process_group(process, grace_seconds=grace)
        if unexpected_descendants and return_code == 0:
            return_code = 70
        return (
            int(return_code if return_code is not None else 70),
            bytes(stdout),
            bytes(stderr_tail),
        )
    except BaseException:
        terminate_owned_process_group(process, grace_seconds=grace)
        raise
    finally:
        selector.close()
        for stream, _ in streams:
            if stream is not None and not stream.closed:
                stream.close()


def validate_media_path(path: str | Path) -> Path:
    media_path = Path(path).expanduser()
    if not media_path.exists():
        raise FileNotFoundError(media_path)
    if not media_path.is_file():
        raise UnsupportedMediaError(f"Not a regular media file: {media_path}")
    extension = normalized_extension(media_path)
    if extension not in SUPPORTED_MEDIA_EXTENSIONS:
        allowed = ", ".join(sorted(SUPPORTED_MEDIA_EXTENSIONS))
        raise UnsupportedMediaError(
            f"Unsupported media extension '{media_path.suffix}'. Supported: {allowed}"
        )
    return media_path.resolve()


def parse_ffprobe_payload(path: str | Path, payload: Mapping[str, Any]) -> MediaMetadata:
    streams = payload.get("streams")
    if not isinstance(streams, list):
        raise MediaProbeError("ffprobe response is missing the streams array")

    audio_streams: list[AudioStreamMetadata] = []
    video_stream_count = 0
    for stream in streams:
        if not isinstance(stream, Mapping):
            continue
        codec_type = stream.get("codec_type")
        if codec_type == "audio":
            try:
                sample_rate = int(stream["sample_rate"]) if stream.get("sample_rate") else None
                channels = int(stream["channels"]) if stream.get("channels") else None
                index = int(stream.get("index", len(audio_streams)))
            except (TypeError, ValueError) as exc:
                raise MediaProbeError("ffprobe returned invalid audio stream metadata") from exc
            audio_streams.append(
                AudioStreamMetadata(
                    index=index,
                    codec_name=str(stream["codec_name"]) if stream.get("codec_name") else None,
                    sample_rate=sample_rate,
                    channels=channels,
                )
            )
        elif codec_type == "video":
            video_stream_count += 1

    if not audio_streams:
        raise NoAudioStreamError(f"No audio stream found in media: {path}")

    fmt = payload.get("format")
    if not isinstance(fmt, Mapping):
        raise MediaProbeError("ffprobe response is missing format metadata")
    try:
        duration_seconds = float(fmt.get("duration", 0.0))
        size_bytes = int(fmt.get("size", Path(path).stat().st_size))
    except (TypeError, ValueError, OSError) as exc:
        raise MediaProbeError("ffprobe returned invalid duration or size metadata") from exc
    if not math.isfinite(duration_seconds) or duration_seconds < 0:
        raise MediaProbeError("ffprobe returned an invalid media duration")
    if size_bytes < 0:
        raise MediaProbeError("ffprobe returned an invalid media size")

    return MediaMetadata(
        path=str(Path(path).resolve()),
        duration_ms=round(duration_seconds * 1000),
        size_bytes=size_bytes,
        format_name=str(fmt["format_name"]) if fmt.get("format_name") else None,
        audio_streams=tuple(audio_streams),
        video_stream_count=video_stream_count,
    )


def probe_media(
    path: str | Path,
    *,
    ffprobe_path: str | Path = "ffprobe",
    timeout_seconds: float = FFPROBE_TIMEOUT_SECONDS,
    termination_grace_seconds: float = PROCESS_TERMINATION_GRACE_SECONDS,
) -> MediaMetadata:
    media_path = validate_media_path(path)
    command = [
        str(ffprobe_path),
        "-v",
        "error",
        "-show_entries",
        (
            "format=duration,format_name,size:"
            "stream=index,codec_type,codec_name,sample_rate,channels,width,height"
        ),
        "-of",
        "json",
        str(media_path),
    ]
    try:
        return_code, stdout, stderr = run_owned_process(
            command,
            timeout_seconds=timeout_seconds,
            termination_grace_seconds=termination_grace_seconds,
        )
    except OwnedProcessDeadlineExceeded as exc:
        raise MediaProbeError(
            f"ffprobe timed out after {float(timeout_seconds):g} seconds for {media_path}"
        ) from exc
    except OwnedProcessOutputLimitExceeded as exc:
        raise MediaProbeError("ffprobe returned an oversized response") from exc
    except OSError as exc:
        raise MediaProbeError(f"Unable to run ffprobe: {exc}") from exc
    if return_code != 0:
        diagnostic = (
            stderr.decode("utf-8", errors="replace").strip()
            or "unknown ffprobe error"
        )
        raise MediaProbeError(f"ffprobe failed for {media_path}: {diagnostic}")
    try:
        payload = json.loads(stdout.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise MediaProbeError("ffprobe returned invalid JSON") from exc
    if not isinstance(payload, Mapping):
        raise MediaProbeError("ffprobe JSON root must be an object")
    return parse_ffprobe_payload(media_path, payload)


def build_ffmpeg_extract_command(
    input_path: str | Path,
    output_path: str | Path,
    *,
    ffmpeg_path: str | Path = "ffmpeg",
) -> list[str]:
    source = Path(input_path).expanduser().resolve()
    raw_destination = Path(output_path).expanduser()
    destination = Path(os.path.abspath(os.fspath(raw_destination)))
    if destination.is_symlink():
        raise ValueError("Extraction output must not be a symbolic link")
    if source == destination:
        raise ValueError("Extraction output must not overwrite the original media")
    if destination.exists() and os.path.samefile(source, destination):
        raise ValueError("Extraction output must not alias the original media")
    return [
        str(ffmpeg_path),
        "-hide_banner",
        "-nostdin",
        "-y",
        "-i",
        str(source),
        "-map",
        "0:a:0",
        "-vn",
        "-ac",
        str(TARGET_CHANNELS),
        "-ar",
        str(TARGET_SAMPLE_RATE),
        "-c:a",
        TARGET_CODEC,
        "-f",
        "wav",
        "-progress",
        "pipe:1",
        "-nostats",
        str(destination),
    ]


def extract_audio(
    input_path: str | Path,
    output_path: str | Path,
    *,
    ffmpeg_path: str | Path = "ffmpeg",
    progress_callback: Callable[[Mapping[str, str]], None] | None = None,
    cancel_requested: Callable[[], bool] | None = None,
    timeout_seconds: float = FFMPEG_EXTRACTION_TIMEOUT_SECONDS,
    termination_grace_seconds: float = PROCESS_TERMINATION_GRACE_SECONDS,
) -> Path:
    source = validate_media_path(input_path)
    raw_destination = Path(output_path).expanduser()
    absolute_destination = Path(os.path.abspath(os.fspath(raw_destination)))
    absolute_destination.parent.mkdir(parents=True, exist_ok=True)
    destination_parent = absolute_destination.parent.resolve(strict=True)
    destination = destination_parent / absolute_destination.name
    if destination.is_symlink():
        raise AudioExtractionError("Audio extraction output cannot be a symbolic link")
    if source == destination:
        raise AudioExtractionError("Audio extraction output cannot overwrite the source")
    descriptor, partial_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        suffix=".partial.wav",
        dir=destination_parent,
    )
    os.close(descriptor)
    partial = Path(partial_name)
    os.chmod(partial, 0o600)
    command = build_ffmpeg_extract_command(source, partial, ffmpeg_path=ffmpeg_path)
    progress: dict[str, str] = {}
    pending_stdout = bytearray()

    def accept_stdout(data: bytes) -> None:
        pending_stdout.extend(data)
        if len(pending_stdout) > MAX_PROGRESS_LINE_BYTES and b"\n" not in pending_stdout:
            raise OwnedProcessOutputLimitExceeded
        while True:
            newline = pending_stdout.find(b"\n")
            if newline < 0:
                break
            raw_line = bytes(pending_stdout[:newline])
            del pending_stdout[: newline + 1]
            line = raw_line.rstrip(b"\r").decode("utf-8", errors="replace")
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            progress[key] = value
            if key == "progress":
                if progress_callback is not None:
                    progress_callback(dict(progress))
                progress.clear()

    try:
        return_code, _, stderr_bytes = run_owned_process(
            command,
            timeout_seconds=timeout_seconds,
            termination_grace_seconds=termination_grace_seconds,
            cancel_requested=cancel_requested,
            stdout_consumer=accept_stdout,
        )
    except OwnedProcessCancelled as exc:
        move_to_trash(partial)
        raise AudioExtractionError("Audio extraction canceled") from exc
    except OwnedProcessDeadlineExceeded as exc:
        move_to_trash(partial)
        raise AudioExtractionError(
            f"Audio extraction timed out after {float(timeout_seconds):g} seconds"
        ) from exc
    except OwnedProcessOutputLimitExceeded as exc:
        move_to_trash(partial)
        raise AudioExtractionError("ffmpeg returned an oversized progress line") from exc
    except OSError as exc:
        move_to_trash(partial)
        raise AudioExtractionError(f"Unable to run ffmpeg: {exc}") from exc
    except BaseException:
        move_to_trash(partial)
        raise

    if pending_stdout:
        accept_stdout(b"\n")

    if return_code != 0:
        diagnostic = (
            stderr_bytes.decode("utf-8", errors="replace").strip()
            or f"ffmpeg exited with {return_code}"
        )
        move_to_trash(partial)
        raise AudioExtractionError(f"Audio extraction failed: {diagnostic}")
    if partial.is_symlink() or not partial.is_file() or partial.stat().st_size == 0:
        move_to_trash(partial)
        raise AudioExtractionError("ffmpeg completed without a usable WAV output")
    if destination.is_symlink():
        move_to_trash(partial)
        raise AudioExtractionError("Audio extraction output became a symbolic link")
    try:
        os.replace(partial, destination)
    except BaseException:
        move_to_trash(partial)
        raise
    return destination
