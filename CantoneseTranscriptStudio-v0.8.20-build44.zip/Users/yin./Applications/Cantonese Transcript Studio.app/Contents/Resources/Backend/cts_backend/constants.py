from __future__ import annotations

from pathlib import Path


VIDEO_EXTENSIONS = frozenset({".mp4", ".mov", ".mkv", ".m4v", ".avi", ".webm"})
AUDIO_EXTENSIONS = frozenset(
    {".wav", ".mp3", ".m4a", ".aac", ".flac", ".aiff", ".aif", ".ogg", ".opus"}
)
SUPPORTED_MEDIA_EXTENSIONS = VIDEO_EXTENSIONS | AUDIO_EXTENSIONS

TARGET_SAMPLE_RATE = 16_000
TARGET_CHANNELS = 1
TARGET_SAMPLE_WIDTH_BYTES = 2
TARGET_CODEC = "pcm_s16le"

# mlx-qwen3-asr performs its own recursive split for inputs longer than 30s.
# Keep our core duration low enough that boundary search (+3s) and two 0.75s
# overlaps still remain below that limit.  This avoids duplicate encoder/prefill
# work and makes every completed outer chunk a useful recovery checkpoint.
DEFAULT_CHUNK_SECONDS = 24.0
DEFAULT_CHUNK_OVERLAP_SECONDS = 0.75
DEFAULT_CHUNK_BOUNDARY_SEARCH_SECONDS = 3.0
DEFAULT_ENERGY_WINDOW_MS = 100
MIN_CHUNK_SECONDS = 2.0
QWEN_INTERNAL_CHUNK_LIMIT_SECONDS = 30.0

JOB_METADATA_FILENAME = "job.json"
CHUNK_PLAN_FILENAME = "chunk-plan.json"
SCHEMA_VERSION = 1


def normalized_extension(path: str | Path) -> str:
    return Path(path).suffix.casefold()
