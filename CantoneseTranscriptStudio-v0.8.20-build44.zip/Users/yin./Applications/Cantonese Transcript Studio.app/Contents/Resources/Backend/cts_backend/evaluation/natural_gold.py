"""Fail-closed contract for a natural Cantonese timestamp gold set.

The validator intentionally treats durations, hashes, source spans, split
membership and annotation provenance as evidence.  A synthetic smoke fixture
can test the validator, but cannot be labelled as production gold.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..audio.media import probe_media


GOLD_SCHEMA = "CTS_NATURAL_CANTONESE_TIMING_GOLD_V1"
GOLD_COLLECTION_CONTRACT_VERSION = "cts-natural-gold-collection-contract/v2"
ANNOTATION_POLICY_VERSION = "cts-natural-cantonese-timing-annotation/v1"
BASELINE_SEGMENT_SCHEMA = "CTS_FROZEN_BASELINE_SEGMENTATION_V1"
BASELINE_SEGMENT_POLICY_VERSION = "cts-frozen-baseline-segmentation/v1"
DETERMINISTIC_RESOLVER = "lower_median_start_end_ms"
RENDERER_POLICY_VERSION = "cts-natural-gold-human-ui/v2"
REQUIRED_CONDITIONS = frozenset(
    {
        "slow_speech",
        "fast_speech",
        "particles_fillers",
        "repeated_words",
        "continuous_speech",
        "cantonese_english_code_switching",
        "clean_audio",
        "room_audio",
        "background_noise",
        "varied_microphones",
        "varied_distances",
    }
)
REQUIRED_SPLIT_RATIOS = {"train": 0.50, "validation": 0.20, "test": 0.30}
ROLE_KEYS = {
    "transcript_corrector",
    "primary_timing_annotator",
    "secondary_timing_annotator",
    "adjudicator",
}
LINEAGE_KEYS = {
    "draft_sha256",
    "transcript_freeze_sha256",
    "transcript_freeze_file_sha256",
    "ready_sha256",
    "primary_packet_sha256",
    "primary_export_file_sha256",
    "secondary_packet_sha256",
    "secondary_export_file_sha256",
    "adjudication_packet_sha256",
    "adjudication_export_file_sha256",
    "tool_source_manifest_sha256",
    "tool_source_manifest_file_sha256",
    "transcript_review_ui_sha256",
    "primary_annotation_ui_sha256",
    "secondary_annotation_ui_sha256",
    "adjudication_ui_sha256",
    "renderer_policy_version",
    "finalization_execution_id",
}
MANIFEST_KEYS = {
    "schema",
    "status",
    "natural_human_speech",
    "synthetic_or_tts",
    "annotation_policy_version",
    "role_identities",
    "collection_lineage",
    "clips",
    "annotations",
    "split_contract",
}
CLIP_KEYS = {
    "id",
    "split",
    "audio_path",
    "audio_sha256",
    "transcript_path",
    "transcript_sha256",
    "baseline_segments_path",
    "baseline_segments_sha256",
    "duration_seconds",
    "speaker_ids",
    "source_authority",
    "source_reference",
    "conditions",
}
ANNOTATIONS_KEYS = {
    "transcripts_frozen_before_timing",
    "annotators_blind_to_model_timestamps",
    "annotator_pseudonyms",
    "adjudicator_pseudonyms",
    "deterministic_resolver",
    "punctuation_interval_policy",
    "raw_boundary_format",
    "pre_adjudication_median_ms",
    "pre_adjudication_p95_ms",
    "words",
    "cues",
}
RAW_ANNOTATION_KEYS = {"annotator", "start_ms", "end_ms"}
ADJUDICATION_KEYS = {
    "adjudicator",
    "decided_at",
    "policy_version",
    "start_ms",
    "end_ms",
}
WORD_KEYS = {
    "id",
    "clip_id",
    "baseline_word_id",
    "segment_id",
    "text",
    "source_start",
    "source_end",
    "start_ms",
    "end_ms",
    "role",
    "ambiguous",
    "resolution",
    "raw_annotations",
}
CUE_KEYS = {
    "id",
    "clip_id",
    "text",
    "source_start",
    "source_end",
    "appearance_ms",
    "disappearance_ms",
    "ambiguous",
    "resolution",
    "raw_annotations",
}
SPLIT_CONTRACT_KEYS = {
    "collection_contract_version",
    "unit",
    "speaker_disjoint",
    "test_locked_before_development",
    "sealed_at",
    "test_seal_sha256",
}


@dataclass(frozen=True)
class GoldValidation:
    accepted: bool
    errors: tuple[str, ...]
    stats: Mapping[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": GOLD_SCHEMA,
            "accepted": self.accepted,
            "errors": list(self.errors),
            "stats": dict(self.stats),
        }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _safe_file(root: Path, raw_path: object) -> Path:
    if not isinstance(raw_path, str) or not raw_path:
        raise ValueError("path missing")
    root = root.resolve(strict=True)
    path = (root / raw_path).resolve(strict=True)
    path.relative_to(root)
    if path.is_symlink() or not path.is_file():
        raise ValueError("path is not a regular file")
    return path


def _default_duration_probe(path: Path) -> float:
    return probe_media(path).duration_ms / 1_000


def _canonical(value: object) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")


def compute_baseline_projection_sha256(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        _canonical(
            {
                "schema": value.get("schema"),
                "segmentation_policy_version": value.get(
                    "segmentation_policy_version"
                ),
                "source_build": value.get("source_build"),
                "transcript_sha256": value.get("transcript_sha256"),
                "segments": value.get("segments"),
                "words": value.get("words"),
            }
        )
    ).hexdigest()


def compute_test_seal(manifest: Mapping[str, Any]) -> str:
    clips = [item for item in manifest.get("clips", []) if isinstance(item, Mapping)]
    clip_splits = {
        str(item.get("id")): item.get("split")
        for item in clips
        if isinstance(item.get("id"), str)
    }
    test_clip_ids = {
        str(item.get("id")) for item in clips if item.get("split") == "test"
    }
    annotations = manifest.get("annotations")
    annotations = annotations if isinstance(annotations, Mapping) else {}
    test_words = [
        item
        for item in annotations.get("words", [])
        if isinstance(item, Mapping) and item.get("clip_id") in test_clip_ids
    ]
    test_cues = [
        item
        for item in annotations.get("cues", [])
        if isinstance(item, Mapping) and item.get("clip_id") in test_clip_ids
    ]
    split_contract = manifest.get("split_contract")
    split_contract = split_contract if isinstance(split_contract, Mapping) else {}
    payload = {
        "schema": GOLD_SCHEMA,
        "annotation_policy_version": manifest.get("annotation_policy_version"),
        "role_identities": manifest.get("role_identities"),
        "collection_lineage": manifest.get("collection_lineage"),
        "clip_splits": clip_splits,
        "test_clips": [item for item in clips if item.get("split") == "test"],
        "annotation_policy": {
            key: annotations.get(key)
            for key in (
                "transcripts_frozen_before_timing",
                "annotators_blind_to_model_timestamps",
                "annotator_pseudonyms",
                "adjudicator_pseudonyms",
                "deterministic_resolver",
                "punctuation_interval_policy",
                "raw_boundary_format",
            )
        },
        "split_policy": {
            key: split_contract.get(key)
            for key in (
                "collection_contract_version",
                "unit",
                "speaker_disjoint",
                "test_locked_before_development",
                "sealed_at",
            )
        },
        "words": test_words,
        "cues": test_cues,
    }
    return hashlib.sha256(_canonical(payload)).hexdigest()


def _integer(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _baseline_word_roles(
    value: object,
    *,
    label: str,
    transcript: str,
    transcript_sha256: str,
    errors: list[str],
) -> dict[str, dict[str, Any]]:
    required_keys = {
        "schema",
        "segmentation_policy_version",
        "source_build",
        "transcript_sha256",
        "segment_projection_sha256",
        "segments",
        "words",
    }
    if not isinstance(value, Mapping) or set(value) != required_keys:
        errors.append(f"{label} baseline segmentation schema is invalid")
        return {}
    source_build = _integer(value.get("source_build"))
    if (
        value.get("schema") != BASELINE_SEGMENT_SCHEMA
        or value.get("segmentation_policy_version")
        != BASELINE_SEGMENT_POLICY_VERSION
        or source_build is None
        or source_build < 1
        or value.get("transcript_sha256") != transcript_sha256
        or value.get("segment_projection_sha256")
        != compute_baseline_projection_sha256(value)
    ):
        errors.append(f"{label} baseline segmentation identity is invalid")
    segments = value.get("segments")
    words = value.get("words")
    if not isinstance(segments, list) or not isinstance(words, list):
        errors.append(f"{label} baseline segmentation arrays are invalid")
        return {}
    segment_rows: dict[str, tuple[int, int, int]] = {}
    previous_segment_end = 0
    for index, segment in enumerate(segments):
        if not isinstance(segment, Mapping) or set(segment) != {
            "id",
            "source_start",
            "source_end",
            "text",
        }:
            errors.append(f"{label} baseline segment {index} is invalid")
            continue
        segment_id = segment.get("id")
        source_start = _integer(segment.get("source_start"))
        source_end = _integer(segment.get("source_end"))
        text = segment.get("text")
        if (
            not isinstance(segment_id, str)
            or not segment_id
            or segment_id in segment_rows
            or source_start is None
            or source_end is None
            or not previous_segment_end <= source_start < source_end <= len(transcript)
            or not isinstance(text, str)
            or transcript[source_start:source_end] != text
        ):
            errors.append(f"{label} baseline segment {index} source projection is invalid")
            continue
        segment_rows[segment_id] = (index, source_start, source_end)
        previous_segment_end = source_end
    rows_by_segment: dict[str, list[tuple[int, str, int, int, str]]] = {
        segment_id: [] for segment_id in segment_rows
    }
    seen_ids: set[str] = set()
    seen_spans: set[tuple[int, int]] = set()
    for index, word in enumerate(words):
        if not isinstance(word, Mapping) or set(word) != {
            "id",
            "segment_id",
            "text",
            "source_start",
            "source_end",
        }:
            errors.append(f"{label} baseline word {index} is invalid")
            continue
        word_id = word.get("id")
        segment_id = word.get("segment_id")
        text = word.get("text")
        source_start = _integer(word.get("source_start"))
        source_end = _integer(word.get("source_end"))
        segment = segment_rows.get(str(segment_id))
        if (
            not isinstance(word_id, str)
            or not word_id
            or word_id in seen_ids
            or not isinstance(segment_id, str)
            or segment is None
            or source_start is None
            or source_end is None
            or (source_start, source_end) in seen_spans
            or not segment[1] <= source_start < source_end <= segment[2]
            or not isinstance(text, str)
            or transcript[source_start:source_end] != text
        ):
            errors.append(f"{label} baseline word {index} source projection is invalid")
            continue
        seen_ids.add(word_id)
        seen_spans.add((source_start, source_end))
        rows_by_segment[segment_id].append(
            (index, word_id, source_start, source_end, text)
        )
    output: dict[str, dict[str, Any]] = {}
    for segment_id, rows in rows_by_segment.items():
        previous_end = segment_rows[segment_id][1]
        for position, (index, word_id, source_start, source_end, text) in enumerate(rows):
            if source_start < previous_end:
                errors.append(
                    f"{label} baseline word {index} is out of order or overlaps"
                )
            previous_end = max(previous_end, source_end)
            role = (
                "leading"
                if position == 0
                else "trailing"
                if position == len(rows) - 1
                else "interior"
            )
            output[word_id] = {
                "segment_id": segment_id,
                "text": text,
                "source_start": source_start,
                "source_end": source_end,
                "role": role,
            }
    return output


def _raw_boundaries(
    value: Mapping[str, Any],
    *,
    label: str,
    pseudonyms: set[str],
    duration_ms: int,
    errors: list[str],
) -> tuple[tuple[int, int], ...]:
    raw = value.get("raw_annotations")
    if not isinstance(raw, list) or not raw:
        errors.append(f"{label} lacks raw annotator boundaries")
        return ()
    seen: set[str] = set()
    output: list[tuple[int, int]] = []
    for raw_index, annotation in enumerate(raw):
        if not isinstance(annotation, Mapping) or set(annotation) != RAW_ANNOTATION_KEYS:
            errors.append(f"{label} raw annotation {raw_index} schema is invalid")
            continue
        annotator = annotation.get("annotator")
        start_ms = _integer(annotation.get("start_ms"))
        end_ms = _integer(annotation.get("end_ms"))
        if (
            not isinstance(annotator, str)
            or annotator not in pseudonyms
            or annotator in seen
        ):
            errors.append(f"{label} raw annotator identity is invalid or duplicate")
            continue
        if (
            start_ms is None
            or end_ms is None
            or not 0 <= start_ms < end_ms <= duration_ms
        ):
            errors.append(f"{label} raw timing exceeds clip duration")
            continue
        seen.add(annotator)
        output.append((start_ms, end_ms))
    return tuple(output)


def _lower_median(values: Sequence[int]) -> int:
    ordered = sorted(values)
    return ordered[(len(ordered) - 1) // 2]


def _validate_boundary_resolution(
    value: Mapping[str, Any],
    *,
    label: str,
    raw: Sequence[tuple[int, int]],
    final_start_ms: int | None,
    final_end_ms: int | None,
    deterministic_resolver: object,
    adjudicator_pseudonyms: set[str],
    duration_ms: int,
    errors: list[str],
) -> None:
    resolution = value.get("resolution")
    adjudication = value.get("adjudication")
    if final_start_ms is None or final_end_ms is None or not raw:
        errors.append(f"{label} resolution lacks valid final or raw boundaries")
        return
    if resolution == "single_annotation":
        if len(raw) != 1 or (final_start_ms, final_end_ms) != raw[0]:
            errors.append(f"{label} single-annotation resolution does not match raw")
        if adjudication is not None:
            errors.append(f"{label} single-annotation resolution has adjudication data")
        return
    if resolution == "deterministic_consensus":
        if deterministic_resolver != DETERMINISTIC_RESOLVER or len(raw) < 2:
            errors.append(f"{label} deterministic resolution policy is invalid")
            return
        start_delta = max(item[0] for item in raw) - min(item[0] for item in raw)
        end_delta = max(item[1] for item in raw) - min(item[1] for item in raw)
        expected = (
            _lower_median([item[0] for item in raw]),
            _lower_median([item[1] for item in raw]),
        )
        if max(start_delta, end_delta) > 80:
            errors.append(f"{label} over 80 ms disagreement requires adjudication")
        if (final_start_ms, final_end_ms) != expected:
            errors.append(f"{label} deterministic final does not match raw resolver")
        if adjudication is not None:
            errors.append(f"{label} deterministic resolution has adjudication data")
        return
    if resolution == "adjudicated":
        if not isinstance(adjudication, Mapping) or set(adjudication) != ADJUDICATION_KEYS:
            errors.append(f"{label} adjudication record is invalid")
            return
        adjudicator = adjudication.get("adjudicator")
        decided_at = adjudication.get("decided_at")
        start_ms = _integer(adjudication.get("start_ms"))
        end_ms = _integer(adjudication.get("end_ms"))
        if (
            not isinstance(adjudicator, str)
            or adjudicator not in adjudicator_pseudonyms
            or adjudication.get("policy_version") != ANNOTATION_POLICY_VERSION
            or start_ms is None
            or end_ms is None
            or not 0 <= start_ms < end_ms <= duration_ms
            or (final_start_ms, final_end_ms) != (start_ms, end_ms)
        ):
            errors.append(f"{label} adjudicated final is invalid")
        if not isinstance(decided_at, str):
            errors.append(f"{label} adjudication timestamp is invalid")
        else:
            try:
                parsed = datetime.fromisoformat(decided_at.replace("Z", "+00:00"))
                if parsed.tzinfo is None:
                    raise ValueError("timezone missing")
            except ValueError:
                errors.append(f"{label} adjudication timestamp is invalid")
        return
    errors.append(f"{label} resolution type is invalid")


def _nearest_rank_p95(values: Sequence[int]) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    index = max(0, math.ceil(0.95 * len(ordered)) - 1)
    return float(ordered[index])


def _median(values: Sequence[int]) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return float(ordered[middle])
    return (ordered[middle - 1] + ordered[middle]) / 2


def validate_natural_cantonese_gold(
    manifest: Mapping[str, Any],
    *,
    root: Path,
    duration_probe: Callable[[Path], float] = _default_duration_probe,
) -> GoldValidation:
    errors: list[str] = []
    if set(manifest) != MANIFEST_KEYS:
        errors.append("manifest top-level schema is invalid")
    if manifest.get("schema") != GOLD_SCHEMA:
        errors.append("schema must be CTS_NATURAL_CANTONESE_TIMING_GOLD_V1")
    if manifest.get("status") != "sealed":
        errors.append("manifest status must be sealed")
    if manifest.get("natural_human_speech") is not True:
        errors.append("natural_human_speech must be true")
    if manifest.get("synthetic_or_tts") is not False:
        errors.append("synthetic_or_tts must be false")
    if manifest.get("annotation_policy_version") != ANNOTATION_POLICY_VERSION:
        errors.append("annotation policy version is invalid")
    roles = manifest.get("role_identities")
    if (
        not isinstance(roles, Mapping)
        or set(roles) != ROLE_KEYS
        or any(not isinstance(value, str) or not value for value in roles.values())
        or len(set(roles.values())) != 4
    ):
        roles = {}
        errors.append("all four human roles must be distinct")
    lineage = manifest.get("collection_lineage")
    if not isinstance(lineage, Mapping) or set(lineage) != LINEAGE_KEYS:
        errors.append("collection lineage is incomplete")
    else:
        for key in LINEAGE_KEYS - {
            "finalization_execution_id",
            "renderer_policy_version",
        }:
            value = lineage.get(key)
            if (
                not isinstance(value, str)
                or len(value) != 64
                or any(character not in "0123456789abcdef" for character in value)
            ):
                errors.append(f"collection lineage hash is invalid: {key}")
        if lineage.get("renderer_policy_version") != RENDERER_POLICY_VERSION:
            errors.append("collection renderer policy version is invalid")
        if not isinstance(lineage.get("finalization_execution_id"), str) or not lineage.get(
            "finalization_execution_id"
        ):
            errors.append("collection finalization execution identity is invalid")

    clips = manifest.get("clips")
    if not isinstance(clips, list) or not clips:
        clips = []
        errors.append("clips must be a non-empty array")
    clip_text: dict[str, str] = {}
    baseline_words_by_clip: dict[str, dict[str, dict[str, Any]]] = {}
    clip_duration_ms: dict[str, int] = {}
    clip_split: dict[str, str] = {}
    clip_ids: set[str] = set()
    speaker_ids: set[str] = set()
    speakers_by_split = {key: set() for key in REQUIRED_SPLIT_RATIOS}
    duration_by_split = {key: 0.0 for key in REQUIRED_SPLIT_RATIOS}
    audio_paths: set[Path] = set()
    audio_hashes: set[str] = set()
    conditions: set[str] = set()
    total_duration = 0.0
    for index, clip in enumerate(clips):
        if not isinstance(clip, Mapping):
            errors.append(f"clip {index} is invalid")
            continue
        if set(clip) != CLIP_KEYS:
            errors.append(f"clip {index} schema is invalid")
        clip_id = clip.get("id")
        if not isinstance(clip_id, str) or not clip_id or clip_id in clip_ids:
            errors.append(f"clip {index} has invalid or duplicate id")
            continue
        clip_ids.add(clip_id)
        split = clip.get("split")
        if split not in REQUIRED_SPLIT_RATIOS:
            errors.append(f"clip {clip_id} split is invalid")
        else:
            clip_split[clip_id] = str(split)
        if clip.get("source_authority") not in {
            "public",
            "licensed",
            "private_expressly_authorized",
        }:
            errors.append(f"clip {clip_id} lacks source authority")
        if not isinstance(clip.get("source_reference"), str) or not clip.get(
            "source_reference"
        ):
            errors.append(f"clip {clip_id} lacks source reference")
        raw_speakers = clip.get("speaker_ids")
        if not isinstance(raw_speakers, list) or not raw_speakers:
            errors.append(f"clip {clip_id} lacks speakers")
        else:
            valid_speakers = {
                item for item in raw_speakers if isinstance(item, str) and item
            }
            if len(valid_speakers) != len(raw_speakers):
                errors.append(f"clip {clip_id} speaker identities are invalid or duplicate")
            speaker_ids.update(valid_speakers)
            if split in speakers_by_split:
                speakers_by_split[str(split)].update(valid_speakers)
        raw_conditions = clip.get("conditions")
        if (
            not isinstance(raw_conditions, list)
            or any(not isinstance(item, str) for item in raw_conditions)
            or len(raw_conditions) != len(set(raw_conditions))
            or any(item not in REQUIRED_CONDITIONS for item in raw_conditions)
        ):
            errors.append(f"clip {clip_id} conditions are invalid")
        else:
            conditions.update(raw_conditions)
        try:
            audio_path = _safe_file(Path(root), clip.get("audio_path"))
            transcript_path = _safe_file(Path(root), clip.get("transcript_path"))
            baseline_path = _safe_file(
                Path(root), clip.get("baseline_segments_path")
            )
            audio_sha = _sha256(audio_path)
            if audio_path in audio_paths or audio_sha in audio_hashes:
                errors.append(f"clip {clip_id} duplicates another audio source")
            audio_paths.add(audio_path)
            audio_hashes.add(audio_sha)
            if clip.get("audio_sha256") != audio_sha:
                errors.append(f"clip {clip_id} audio hash mismatch")
            transcript_sha = _sha256(transcript_path)
            if clip.get("transcript_sha256") != transcript_sha:
                errors.append(f"clip {clip_id} transcript hash mismatch")
            baseline_sha = _sha256(baseline_path)
            if clip.get("baseline_segments_sha256") != baseline_sha:
                errors.append(f"clip {clip_id} baseline segmentation hash mismatch")
            text = transcript_path.read_text(encoding="utf-8")
            clip_text[clip_id] = text
            baseline_words_by_clip[clip_id] = _baseline_word_roles(
                json.loads(baseline_path.read_text(encoding="utf-8")),
                label=f"clip {clip_id}",
                transcript=text,
                transcript_sha256=transcript_sha,
                errors=errors,
            )
            measured = float(duration_probe(audio_path))
            declared = float(clip.get("duration_seconds"))
            if not math.isfinite(measured) or measured <= 0:
                raise ValueError("measured duration invalid")
            if not math.isfinite(declared) or abs(measured - declared) > 0.10:
                errors.append(f"clip {clip_id} duration does not match media")
            clip_duration_ms[clip_id] = round(measured * 1_000)
            if split in duration_by_split:
                duration_by_split[str(split)] += measured
            total_duration += measured
        except (OSError, UnicodeError, TypeError, ValueError) as exc:
            errors.append(f"clip {clip_id} evidence invalid: {exc}")

    if total_duration < 1_800:
        errors.append("natural speech duration must be at least 30 minutes")
    if len(speaker_ids) < 4:
        errors.append("gold set must contain at least 4 speakers")
    for left_index, left in enumerate(REQUIRED_SPLIT_RATIOS):
        for right in tuple(REQUIRED_SPLIT_RATIOS)[left_index + 1 :]:
            overlap = speakers_by_split[left].intersection(speakers_by_split[right])
            if overlap:
                errors.append(
                    f"speaker identities cross {left}/{right} splits: "
                    + ", ".join(sorted(overlap))
                )
    missing_conditions = sorted(REQUIRED_CONDITIONS - conditions)
    if missing_conditions:
        errors.append("missing conditions: " + ", ".join(missing_conditions))

    annotations = manifest.get("annotations")
    if not isinstance(annotations, Mapping):
        annotations = {}
        errors.append("annotations must be an object")
    elif set(annotations) != ANNOTATIONS_KEYS:
        errors.append("annotations schema is invalid")
    if annotations.get("transcripts_frozen_before_timing") is not True:
        errors.append("transcripts must be frozen before timing annotation")
    if annotations.get("annotators_blind_to_model_timestamps") is not True:
        errors.append("annotators must be blind to model timestamps")
    pseudonyms = annotations.get("annotator_pseudonyms")
    pseudonym_set = (
        {item for item in pseudonyms if isinstance(item, str) and item}
        if isinstance(pseudonyms, list)
        else set()
    )
    if (
        not isinstance(pseudonyms, list)
        or len(pseudonym_set) != len(pseudonyms)
        or len(pseudonym_set) < 2
    ):
        errors.append("at least two annotator pseudonyms are required")
    elif roles and pseudonyms != [
        roles["primary_timing_annotator"],
        roles["secondary_timing_annotator"],
    ]:
        errors.append("timing annotators do not match bound human roles")
    adjudicator_pseudonyms = annotations.get("adjudicator_pseudonyms")
    adjudicator_set = (
        {item for item in adjudicator_pseudonyms if isinstance(item, str) and item}
        if isinstance(adjudicator_pseudonyms, list)
        else set()
    )
    if (
        not isinstance(adjudicator_pseudonyms, list)
        or len(adjudicator_set) != len(adjudicator_pseudonyms)
        or not adjudicator_set
    ):
        errors.append("at least one adjudicator pseudonym is required")
    elif roles and adjudicator_pseudonyms != [roles["adjudicator"]]:
        errors.append("adjudicator does not match bound human role")
    deterministic_resolver = annotations.get("deterministic_resolver")
    if deterministic_resolver != DETERMINISTIC_RESOLVER:
        errors.append("deterministic boundary resolver is invalid")
    if annotations.get("punctuation_interval_policy") != "no_invented_interval":
        errors.append("punctuation interval policy must forbid invented intervals")
    if annotations.get("raw_boundary_format") != "per_annotator_start_end_ms":
        errors.append("raw boundary format is invalid")

    words = annotations.get("words")
    if not isinstance(words, list):
        words = []
        errors.append("word annotations must be an array")
    roles = {"leading": 0, "trailing": 0, "interior": 0}
    split_counts = {key: 0 for key in REQUIRED_SPLIT_RATIOS}
    double_by_split = {key: 0 for key in REQUIRED_SPLIT_RATIOS}
    double_annotated = 0
    word_ids: set[str] = set()
    used_baseline_word_ids: set[tuple[str, str]] = set()
    word_spans: set[tuple[str, int, int]] = set()
    previous_word_end: dict[str, int] = {}
    raw_boundary_deltas: list[int] = []
    for index, word in enumerate(words):
        if not isinstance(word, Mapping):
            errors.append(f"word {index} is invalid")
            continue
        expected_word_keys = WORD_KEYS | (
            {"adjudication"} if "adjudication" in word else set()
        )
        if set(word) != expected_word_keys:
            errors.append(f"word {index} schema is invalid")
        clip_id = word.get("clip_id")
        word_id = word.get("id")
        baseline_word_id = word.get("baseline_word_id")
        segment_id = word.get("segment_id")
        text = word.get("text")
        source_start = _integer(word.get("source_start"))
        source_end = _integer(word.get("source_end"))
        start_ms = _integer(word.get("start_ms"))
        end_ms = _integer(word.get("end_ms"))
        transcript = clip_text.get(str(clip_id))
        duration_ms = clip_duration_ms.get(str(clip_id))
        split = clip_split.get(str(clip_id))
        if not isinstance(word_id, str) or not word_id or word_id in word_ids:
            errors.append(f"word {index} id is invalid or duplicate")
        else:
            word_ids.add(word_id)
        baseline = baseline_words_by_clip.get(str(clip_id), {}).get(
            str(baseline_word_id)
        )
        baseline_key = (str(clip_id), str(baseline_word_id))
        if (
            not isinstance(baseline_word_id, str)
            or not baseline_word_id
            or baseline is None
            or baseline_key in used_baseline_word_ids
            or segment_id != baseline.get("segment_id")
            or text != baseline.get("text")
            or source_start != baseline.get("source_start")
            or source_end != baseline.get("source_end")
        ):
            errors.append(f"word {index} baseline segment projection is invalid")
        else:
            used_baseline_word_ids.add(baseline_key)
        if (
            transcript is None
            or not isinstance(text, str)
            or source_start is None
            or source_end is None
            or not 0 <= source_start < source_end <= len(transcript)
            or transcript[source_start:source_end] != text
        ):
            errors.append(f"word {index} source span does not match frozen transcript")
        elif (str(clip_id), source_start, source_end) in word_spans:
            errors.append(f"word {index} duplicates a source span")
        else:
            word_spans.add((str(clip_id), source_start, source_end))
            previous = previous_word_end.get(str(clip_id))
            if previous is not None and source_start < previous:
                errors.append(f"word {index} source spans are out of order or overlap")
            previous_word_end[str(clip_id)] = source_end
        if (
            start_ms is None
            or end_ms is None
            or duration_ms is None
            or not 0 <= start_ms < end_ms <= duration_ms
        ):
            errors.append(f"word {index} timing exceeds clip duration")
        derived_role = baseline.get("role") if baseline is not None else None
        if derived_role in roles and word.get("role") == derived_role:
            roles[str(derived_role)] += 1
        else:
            errors.append(f"word {index} role does not match frozen baseline")
        if split in split_counts:
            split_counts[str(split)] += 1
        else:
            errors.append(f"word {index} clip split is invalid")
        if "split" in word and word.get("split") != split:
            errors.append(f"word {index} crosses its clip split")
        raw = _raw_boundaries(
            word,
            label=f"word {index}",
            pseudonyms=pseudonym_set,
            duration_ms=duration_ms or 0,
            errors=errors,
        )
        if len(raw) >= 2:
            double_annotated += 1
            if split in double_by_split:
                double_by_split[str(split)] += 1
            start_delta = max(item[0] for item in raw) - min(item[0] for item in raw)
            end_delta = max(item[1] for item in raw) - min(item[1] for item in raw)
            raw_boundary_deltas.extend((start_delta, end_delta))
        _validate_boundary_resolution(
            word,
            label=f"word {index}",
            raw=raw,
            final_start_ms=start_ms,
            final_end_ms=end_ms,
            deterministic_resolver=deterministic_resolver,
            adjudicator_pseudonyms=adjudicator_set,
            duration_ms=duration_ms or 0,
            errors=errors,
        )
        if not isinstance(word.get("ambiguous"), bool):
            errors.append(f"word {index} lacks ambiguous flag")

    if len(words) < 1_200:
        errors.append("gold set must contain at least 1200 words")
    if roles["leading"] < 200:
        errors.append("gold set must contain at least 200 segment-leading words")
    if roles["trailing"] < 200:
        errors.append("gold set must contain at least 200 segment-trailing words")
    if roles["interior"] < 600:
        errors.append("gold set must contain at least 600 interior controls")
    if words and double_annotated / len(words) < 0.25:
        errors.append("at least 25 percent of words must be double annotated")
    for split, count in split_counts.items():
        if count and double_by_split[split] / count < 0.25:
            errors.append(f"at least 25 percent of {split} words must be double annotated")

    cues = annotations.get("cues")
    if not isinstance(cues, list):
        cues = []
        errors.append("cue annotations must be an array")
    if len(cues) < 340:
        errors.append("gold set must contain at least 340 human cues")
    cue_ids: set[str] = set()
    cue_spans: set[tuple[str, int, int]] = set()
    previous_cue_end: dict[str, int] = {}
    cue_split_counts = {key: 0 for key in REQUIRED_SPLIT_RATIOS}
    double_cues_by_split = {key: 0 for key in REQUIRED_SPLIT_RATIOS}
    double_annotated_cues = 0
    for index, cue in enumerate(cues):
        if not isinstance(cue, Mapping) or cue.get("clip_id") not in clip_ids:
            errors.append(f"cue {index} clip identity is invalid")
            continue
        expected_cue_keys = CUE_KEYS | (
            {"adjudication"} if "adjudication" in cue else set()
        )
        if set(cue) != expected_cue_keys:
            errors.append(f"cue {index} schema is invalid")
        cue_id = cue.get("id")
        clip_id = str(cue.get("clip_id"))
        transcript = clip_text.get(clip_id)
        duration_ms = clip_duration_ms.get(clip_id)
        split = clip_split.get(clip_id)
        source_start = _integer(cue.get("source_start"))
        source_end = _integer(cue.get("source_end"))
        text = cue.get("text")
        if not isinstance(cue_id, str) or not cue_id or cue_id in cue_ids:
            errors.append(f"cue {index} id is invalid or duplicate")
        else:
            cue_ids.add(cue_id)
        if (
            transcript is None
            or not isinstance(text, str)
            or source_start is None
            or source_end is None
            or not 0 <= source_start < source_end <= len(transcript)
            or transcript[source_start:source_end] != text
        ):
            errors.append(f"cue {index} source span does not match frozen transcript")
        elif (clip_id, source_start, source_end) in cue_spans:
            errors.append(f"cue {index} duplicates a source span")
        else:
            cue_spans.add((clip_id, source_start, source_end))
            previous = previous_cue_end.get(clip_id)
            if previous is not None and source_start < previous:
                errors.append(f"cue {index} source spans are out of order or overlap")
            previous_cue_end[clip_id] = source_end
        start_ms = _integer(cue.get("appearance_ms"))
        end_ms = _integer(cue.get("disappearance_ms"))
        if (
            start_ms is None
            or end_ms is None
            or duration_ms is None
            or not 0 <= start_ms < end_ms <= duration_ms
        ):
            errors.append(f"cue {index} timing exceeds clip duration")
        if split in cue_split_counts:
            cue_split_counts[str(split)] += 1
        else:
            errors.append(f"cue {index} clip split is invalid")
        if "split" in cue and cue.get("split") != split:
            errors.append(f"cue {index} crosses its clip split")
        raw = _raw_boundaries(
            cue,
            label=f"cue {index}",
            pseudonyms=pseudonym_set,
            duration_ms=duration_ms or 0,
            errors=errors,
        )
        if len(raw) >= 2:
            double_annotated_cues += 1
            if split in double_cues_by_split:
                double_cues_by_split[str(split)] += 1
            start_delta = max(item[0] for item in raw) - min(item[0] for item in raw)
            end_delta = max(item[1] for item in raw) - min(item[1] for item in raw)
            raw_boundary_deltas.extend((start_delta, end_delta))
        _validate_boundary_resolution(
            cue,
            label=f"cue {index}",
            raw=raw,
            final_start_ms=start_ms,
            final_end_ms=end_ms,
            deterministic_resolver=deterministic_resolver,
            adjudicator_pseudonyms=adjudicator_set,
            duration_ms=duration_ms or 0,
            errors=errors,
        )
        if not isinstance(cue.get("ambiguous"), bool):
            errors.append(f"cue {index} lacks ambiguous flag")

    if cues and double_annotated_cues / len(cues) < 0.25:
        errors.append("at least 25 percent of cues must be double annotated")
    for split, count in cue_split_counts.items():
        if count and double_cues_by_split[split] / count < 0.25:
            errors.append(f"at least 25 percent of {split} cues must be double annotated")

    measured_median = _median(raw_boundary_deltas)
    measured_p95 = _nearest_rank_p95(raw_boundary_deltas)
    declared_median = annotations.get("pre_adjudication_median_ms")
    declared_p95 = annotations.get("pre_adjudication_p95_ms")
    if (
        isinstance(declared_median, bool)
        or not isinstance(declared_median, (int, float))
        or not math.isfinite(float(declared_median))
        or abs(float(declared_median) - measured_median) > 0.001
    ):
        errors.append("pre-adjudication median does not match raw annotations")
    if (
        isinstance(declared_p95, bool)
        or not isinstance(declared_p95, (int, float))
        or not math.isfinite(float(declared_p95))
        or abs(float(declared_p95) - measured_p95) > 0.001
    ):
        errors.append("pre-adjudication P95 does not match raw annotations")

    total_split = sum(split_counts.values())
    if total_split:
        for split, expected_ratio in REQUIRED_SPLIT_RATIOS.items():
            if abs(split_counts[split] / total_split - expected_ratio) > 0.02:
                errors.append(f"{split} split must be {expected_ratio:.0%} of words")
    total_cue_split = sum(cue_split_counts.values())
    if total_cue_split:
        for split, expected_ratio in REQUIRED_SPLIT_RATIOS.items():
            if abs(cue_split_counts[split] / total_cue_split - expected_ratio) > 0.02:
                errors.append(f"{split} split must be {expected_ratio:.0%} of cues")
    if total_duration:
        for split, expected_ratio in REQUIRED_SPLIT_RATIOS.items():
            if abs(duration_by_split[split] / total_duration - expected_ratio) > 0.02:
                errors.append(f"{split} split must be {expected_ratio:.0%} of duration")
    split_contract = manifest.get("split_contract")
    if not isinstance(split_contract, Mapping):
        split_contract = {}
        errors.append("split contract must be an object")
    elif set(split_contract) != SPLIT_CONTRACT_KEYS:
        errors.append("split contract schema is invalid")
    if split_contract.get("unit") != "clip":
        errors.append("split unit must be clip")
    if (
        split_contract.get("collection_contract_version")
        != GOLD_COLLECTION_CONTRACT_VERSION
    ):
        errors.append("gold collection contract version is invalid")
    if split_contract.get("speaker_disjoint") is not True:
        errors.append("splits must be declared speaker-disjoint")
    if split_contract.get("test_locked_before_development") is not True:
        errors.append("test split must be locked before development")
    sealed_at = split_contract.get("sealed_at")
    if not isinstance(sealed_at, str):
        errors.append("split seal timestamp is missing")
    else:
        try:
            parsed_sealed_at = datetime.fromisoformat(sealed_at.replace("Z", "+00:00"))
            if parsed_sealed_at.tzinfo is None:
                raise ValueError("timezone missing")
        except ValueError:
            errors.append("split seal timestamp is invalid")
    if split_contract.get("test_seal_sha256") != compute_test_seal(manifest):
        errors.append("test split seal mismatch")

    stats = {
        "duration_seconds": round(total_duration, 3),
        "speaker_count": len(speaker_ids),
        "word_count": len(words),
        "leading_word_count": roles["leading"],
        "trailing_word_count": roles["trailing"],
        "interior_word_count": roles["interior"],
        "cue_count": len(cues),
        "double_annotated_cue_fraction": (
            round(double_annotated_cues / len(cues), 6) if cues else 0.0
        ),
        "double_annotated_fraction": (
            round(double_annotated / len(words), 6) if words else 0.0
        ),
        "split_counts": split_counts,
        "cue_split_counts": cue_split_counts,
        "duration_by_split": {
            split: round(value, 3) for split, value in duration_by_split.items()
        },
        "speaker_overlap": False,
        "pre_adjudication_median_ms": measured_median,
        "pre_adjudication_p95_ms": measured_p95,
        "conditions": sorted(conditions),
    }
    return GoldValidation(not errors, tuple(errors), stats)


def _evaluate_timestamp_metric_thresholds(metrics: Mapping[str, Any]) -> GoldValidation:
    """Evaluate measurements only; authoritative proof is checked elsewhere."""
    def finite_at_most(key: str, maximum: float) -> bool:
        value = metrics.get(key)
        return (
            not isinstance(value, bool)
            and isinstance(value, (int, float))
            and math.isfinite(float(value))
            and float(value) <= maximum
        )

    def finite_at_least(key: str, minimum: float) -> bool:
        value = metrics.get(key)
        return (
            not isinstance(value, bool)
            and isinstance(value, (int, float))
            and math.isfinite(float(value))
            and float(value) >= minimum
        )

    def strict_zero(key: str) -> bool:
        value = metrics.get(key)
        return not isinstance(value, bool) and isinstance(value, int) and value == 0

    def positive_integer(key: str) -> bool:
        value = metrics.get(key)
        return not isinstance(value, bool) and isinstance(value, int) and value > 0

    checks = {
        "exact_text_unchanged": metrics.get("exact_text_unchanged") is True,
        "word_count>0": positive_integer("word_count"),
        "matched_word_count>0": positive_integer("matched_word_count"),
        "leading_word_count>0": positive_integer("leading_word_count"),
        "matched_leading_word_count>0": positive_integer(
            "matched_leading_word_count"
        ),
        "interior_word_count>0": positive_integer("interior_word_count"),
        "matched_interior_word_count>0": positive_integer(
            "matched_interior_word_count"
        ),
        "cue_count>0": positive_integer("cue_count"),
        "matched_cue_count>0": positive_integer("matched_cue_count"),
        "coverage_ratio>=0.995": finite_at_least("coverage_ratio", 0.995),
        "leading_coverage_ratio>=0.995": finite_at_least(
            "leading_coverage_ratio", 0.995
        ),
        "interior_coverage_ratio>=0.995": finite_at_least(
            "interior_coverage_ratio", 0.995
        ),
        "cue_coverage_ratio>=0.995": finite_at_least(
            "cue_coverage_ratio", 0.995
        ),
        "overall_start_p95_ms<=500": finite_at_most("overall_start_p95_ms", 500),
        "leading_start_p95_ms<=500": finite_at_most("leading_start_p95_ms", 500),
        "end_p95_ms<=500": finite_at_most("end_p95_ms", 500),
        "cue_start_p95_ms<=300": finite_at_most("cue_start_p95_ms", 300),
        "cue_end_p95_ms<=500": finite_at_most("cue_end_p95_ms", 500),
        "over_1000ms_count==0": strict_zero("over_1000ms_count"),
        "interior_p95_regression_ms<=50": finite_at_most(
            "interior_p95_regression_ms", 50
        ),
        "silent_fallback_count==0": strict_zero("silent_fallback_count"),
        "llm_timing_count==0": strict_zero("llm_timing_count"),
        "blinded_heldout_cues_correct>0": finite_at_least(
            "blinded_heldout_cues_correct", 1
        ),
        "blinded_heldout_cues_incorrect==0": strict_zero(
            "blinded_heldout_cues_incorrect"
        ),
    }
    failures = tuple(name for name, passed in checks.items() if not passed)
    return GoldValidation(not failures, failures, {"checks": checks})


__all__ = [
    "ANNOTATION_POLICY_VERSION",
    "BASELINE_SEGMENT_POLICY_VERSION",
    "BASELINE_SEGMENT_SCHEMA",
    "DETERMINISTIC_RESOLVER",
    "GOLD_COLLECTION_CONTRACT_VERSION",
    "GOLD_SCHEMA",
    "RENDERER_POLICY_VERSION",
    "GoldValidation",
    "compute_baseline_projection_sha256",
    "compute_test_seal",
    "validate_natural_cantonese_gold",
]
