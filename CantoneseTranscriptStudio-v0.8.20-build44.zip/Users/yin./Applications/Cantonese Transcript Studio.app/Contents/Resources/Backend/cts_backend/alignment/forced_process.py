"""Hard subprocess boundary for Qwen3 ForcedAligner.

The MLX forced aligner is a third-party native call and therefore cannot be
made interruptible with a Python ``Future``.  This module runs one complete
alignment stage in an isolated process group while retaining the important
performance property that the model is loaded only once for all remaining
chunks.

Transcript-bearing data uses a dedicated pipe and an owner-only atomic result
file.  The telemetry pipe accepts only a small metadata schema.  Integrity
digests below protect against accidental/stale-file corruption; they are not
an authentication boundary against a malicious process running as the same
macOS user.
"""

from __future__ import annotations

import errno
import hashlib
import hmac
import json
import math
import os
import selectors
import signal
import stat
import subprocess
import sys
import tempfile
import time
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Final

from ..asr.types import ASRCancelled, AudioChunk
from .forced_timestamps import (
    CharacterTimestamp,
    ChunkTimestampAudit,
    FORCED_ALIGNER_METHOD,
    FORCED_ALIGNER_MODEL_ID,
    FORCED_TIMESTAMP_POLICY_VERSION,
    ForcedTimestampAudit,
    ForcedTimestampChunkResult,
    ForcedTimestampResult,
    SubtitleCue,
    WordTimestamp,
    _build_blocks,
    _coerce_chunks,
    _coerce_resumed_chunk,
    _coerce_segment,
    _validate_resumed_chunk,
    validate_local_forced_aligner_model,
)


# Version 3 carries the split adjustment and quantization-repair audit fields
# in every durable chunk. Mixed older/newer parents and children must fail as
# a classified protocol error instead of treating distinct schemas as equal.
PROTOCOL_VERSION: Final[int] = 3
MAX_EVENT_LINE_BYTES: Final[int] = 16 * 1024
MAX_CHUNK_LINE_BYTES: Final[int] = 32 * 1024 * 1024
MAX_REQUEST_BYTES: Final[int] = 128 * 1024 * 1024
MAX_RESULT_BYTES: Final[int] = 256 * 1024 * 1024
MAX_EVENT_PIPE_BYTES: Final[int] = 64 * 1024 * 1024
MAX_CHUNK_PIPE_BYTES: Final[int] = 512 * 1024 * 1024
MAX_TRANSCRIPT_BYTES: Final[int] = 32 * 1024 * 1024
MAX_TIMESTAMP_ITEMS: Final[int] = 2_000_000

Cancelled = Callable[[], bool]
Telemetry = Callable[[dict[str, Any]], None]
ChunkCompleted = Callable[[ForcedTimestampChunkResult], None]


class ForcedProcessError(RuntimeError):
    """Base class for classified forced-alignment process failures."""

    category = "forced_process_error"


class ForcedProcessTimeout(ForcedProcessError):
    category = "forced_timeout"

    def __init__(self, message: str, *, timeout_kind: str) -> None:
        super().__init__(message)
        self.timeout_kind = timeout_kind


class ForcedChildCrashError(ForcedProcessError):
    category = "forced_child_crash"

    def __init__(
        self,
        message: str,
        *,
        returncode: int | None,
        child_category: str = "child_crash",
    ) -> None:
        super().__init__(message)
        self.returncode = returncode
        self.child_category = child_category


class ForcedProtocolError(ForcedChildCrashError):
    category = "forced_protocol_error"

    def __init__(self, message: str, *, returncode: int | None = None) -> None:
        super().__init__(
            message,
            returncode=returncode,
            child_category="protocol_error",
        )


class ForcedProcessCancelled(ASRCancelled):
    category = "forced_cancelled"


@dataclass(frozen=True)
class ForcedSupervisorConfig:
    """Finite deadlines for one persistent forced-alignment child."""

    model_load_timeout_seconds: float = 300.0
    first_chunk_wall_seconds: float = 300.0
    hard_no_progress_seconds: float = 300.0
    per_chunk_wall_seconds: float = 300.0
    hard_wall_seconds: float = 14_400.0
    termination_grace_seconds: float = 2.5
    poll_seconds: float = 0.05
    child_heartbeat_seconds: float = 2.0
    pipe_drain_timeout_seconds: float = 2.0

    def __post_init__(self) -> None:
        for name, value in asdict(self).items():
            if not math.isfinite(float(value)) or float(value) <= 0:
                raise ValueError(f"{name} must be a positive finite number")
        for name in (
            "model_load_timeout_seconds",
            "first_chunk_wall_seconds",
            "hard_no_progress_seconds",
            "per_chunk_wall_seconds",
        ):
            if float(getattr(self, name)) > 300.0:
                raise ValueError(f"{name} may not exceed 300 seconds")
        if self.first_chunk_wall_seconds > self.hard_wall_seconds:
            raise ValueError("first-chunk wall deadline may not exceed hard wall")
        if self.per_chunk_wall_seconds > self.hard_wall_seconds:
            raise ValueError("per-chunk wall deadline may not exceed hard wall")
        if self.termination_grace_seconds > 3.0:
            raise ValueError("termination grace may not exceed three seconds")
        if self.poll_seconds > 0.1:
            raise ValueError("poll interval may not exceed 100 ms")
        if self.pipe_drain_timeout_seconds > 10.0:
            raise ValueError("pipe drain timeout may not exceed ten seconds")


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant is not allowed: {value}")


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("non-finite float is not JSON safe")
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    raise TypeError(f"unsupported JSON value: {type(value).__name__}")


def _canonical_json(value: Mapping[str, Any]) -> bytes:
    return json.dumps(
        _json_safe(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Atomically replace an owner-only JSON file and fsync its directory."""

    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    encoded = _canonical_json(payload)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb", closefd=True) as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
        directory_fd = os.open(destination.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        raise


def _read_owner_json(path: Path, *, max_bytes: int) -> Any:
    candidate = Path(path)
    before = os.stat(candidate, follow_symlinks=False)
    if stat.S_ISLNK(before.st_mode) or not stat.S_ISREG(before.st_mode):
        raise ValueError("protocol file must be a non-symlink regular file")
    if stat.S_IMODE(before.st_mode) & 0o077:
        raise ValueError("protocol file permissions must be owner-only")
    if before.st_size > max_bytes:
        raise ValueError("protocol file exceeds size limit")
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(candidate, flags)
    try:
        opened = os.fstat(descriptor)
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
            raise ValueError("protocol file changed before read")
        data = bytearray()
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            data.extend(block)
            if len(data) > max_bytes:
                raise ValueError("protocol file exceeds size limit")
        after = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    pathname_after = os.stat(candidate, follow_symlinks=False)
    snapshots = (before, opened, after, pathname_after)
    identity = {(item.st_dev, item.st_ino) for item in snapshots}
    if len(identity) != 1 or before.st_size != after.st_size:
        raise ValueError("protocol file changed during read")
    try:
        return json.loads(
            bytes(data).decode("utf-8"), parse_constant=_reject_json_constant
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError("protocol file is not strict JSON") from exc


def _finite_number(value: Any, *, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be numeric")
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{label} must be finite")
    return number


def _strict_int(value: Any, *, label: str, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{label} must be an integer")
    if minimum is not None and value < minimum:
        raise ValueError(f"{label} is below its minimum")
    return value


def _strict_text(value: Any, *, label: str, max_bytes: int = MAX_TRANSCRIPT_BYTES) -> str:
    if not isinstance(value, str) or "\x00" in value:
        raise ValueError(f"{label} must be text without NUL")
    if len(value.encode("utf-8")) > max_bytes:
        raise ValueError(f"{label} exceeds size limit")
    return value


def _mapping(value: Any, *, fields: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields:
        raise ValueError(f"{label} schema is invalid")
    return value


def _serialize_chunk(chunk: AudioChunk) -> dict[str, Any]:
    return {
        "id": chunk.id,
        "path": str(chunk.path.expanduser().resolve()),
        "start": chunk.start,
        "end": chunk.end,
        "index": chunk.index,
        "core_start": chunk.core_start,
        "core_end": chunk.core_end,
    }


def _normalize_request_inputs(
    chunks: Iterable[Any], chosen_segments: Iterable[Any]
) -> tuple[list[AudioChunk], list[dict[str, Any]], list[Any], str]:
    items = _coerce_chunks(chunks)
    if len({item.id for item in items}) != len(items):
        raise ValueError("forced-alignment chunk ids must be unique")
    segments = [_coerce_segment(value) for value in chosen_segments]
    chosen = [
        {
            "start_ms": item.start_ms,
            "end_ms": item.end_ms,
            "chosen_text": item.text,
        }
        for item in segments
    ]
    blocks = [block for block in _build_blocks(items, segments) if block.text]
    return items, chosen, blocks, "".join(item.text for item in segments)


def _request_payload(
    *,
    model_path: Path,
    model_id: str,
    language: str,
    chunks: Sequence[AudioChunk],
    chosen_segments: Sequence[Mapping[str, Any]],
    resume_chunks: Sequence[ForcedTimestampChunkResult],
) -> dict[str, Any]:
    base = {
        "protocol_version": PROTOCOL_VERSION,
        "model_path": str(model_path),
        "model_id": str(model_id),
        "language": str(language),
        "chunks": [_serialize_chunk(item) for item in chunks],
        "chosen_segments": [dict(item) for item in chosen_segments],
        "resume_chunks": [item.to_dict() for item in resume_chunks],
    }
    request_id = hashlib.sha256(_canonical_json(base)).hexdigest()
    return {**base, "request_id": request_id}


def validate_request_payload(value: Any) -> dict[str, Any]:
    payload = dict(
        _mapping(
            value,
            fields={
                "protocol_version",
                "request_id",
                "model_path",
                "model_id",
                "language",
                "chunks",
                "chosen_segments",
                "resume_chunks",
            },
            label="forced request",
        )
    )
    if payload["protocol_version"] != PROTOCOL_VERSION:
        raise ValueError("unsupported forced child protocol")
    request_id = _strict_text(payload.pop("request_id"), label="request_id", max_bytes=128)
    if len(request_id) != 64:
        raise ValueError("request_id is invalid")
    expected = hashlib.sha256(_canonical_json(payload)).hexdigest()
    if not hmac.compare_digest(request_id, expected):
        raise ValueError("request_id does not match request content")
    model_path = Path(_strict_text(payload["model_path"], label="model_path", max_bytes=8192))
    if not model_path.is_absolute():
        raise ValueError("forced model_path must be absolute")
    if not _strict_text(payload["model_id"], label="model_id", max_bytes=1024):
        raise ValueError("model_id may not be empty")
    if not _strict_text(payload["language"], label="language", max_bytes=256):
        raise ValueError("language may not be empty")
    raw_chunks = payload["chunks"]
    raw_segments = payload["chosen_segments"]
    raw_resume = payload["resume_chunks"]
    if not isinstance(raw_chunks, list) or not raw_chunks:
        raise ValueError("forced request requires chunks")
    if not isinstance(raw_segments, list) or not isinstance(raw_resume, list):
        raise ValueError("forced request arrays are invalid")
    identifiers: set[str] = set()
    for raw in raw_chunks:
        chunk = _mapping(
            raw,
            fields={"id", "path", "start", "end", "index", "core_start", "core_end"},
            label="request chunk",
        )
        identifier = _strict_text(chunk["id"], label="chunk.id", max_bytes=4096)
        if not identifier or identifier in identifiers:
            raise ValueError("request chunk ids must be non-empty and unique")
        identifiers.add(identifier)
        path = Path(_strict_text(chunk["path"], label="chunk.path", max_bytes=8192))
        if not path.is_absolute():
            raise ValueError("request chunk path must be absolute")
        start = _finite_number(chunk["start"], label="chunk.start")
        end = _finite_number(chunk["end"], label="chunk.end")
        if end < start:
            raise ValueError("request chunk end precedes start")
        _strict_int(chunk["index"], label="chunk.index", minimum=0)
        for field in ("core_start", "core_end"):
            if chunk[field] is not None:
                _finite_number(chunk[field], label=f"chunk.{field}")
    total_text_bytes = 0
    for raw in raw_segments:
        segment = _mapping(
            raw,
            fields={"start_ms", "end_ms", "chosen_text"},
            label="chosen segment",
        )
        start_ms = _strict_int(segment["start_ms"], label="segment.start_ms", minimum=0)
        end_ms = _strict_int(segment["end_ms"], label="segment.end_ms", minimum=0)
        if end_ms < start_ms:
            raise ValueError("chosen segment end precedes start")
        text = _strict_text(segment["chosen_text"], label="chosen_text")
        total_text_bytes += len(text.encode("utf-8"))
        if total_text_bytes > MAX_TRANSCRIPT_BYTES:
            raise ValueError("chosen transcript exceeds size limit")
    # Full semantic resume validation happens against reconstructed blocks in
    # the aligner and parent.  Here the exact outer schema prevents opaque data.
    for raw in raw_resume:
        _mapping(
            raw,
            fields={
                "chunk_id",
                "text",
                "source_start",
                "source_end",
                "words",
                "characters",
                "audit",
            },
            label="resume chunk",
        )
    payload["request_id"] = request_id
    return payload


def load_request(path: Path) -> dict[str, Any]:
    return validate_request_payload(_read_owner_json(path, max_bytes=MAX_REQUEST_BYTES))


def completed_result_envelope(
    request: Mapping[str, Any], result: ForcedTimestampResult
) -> dict[str, Any]:
    unsigned = {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": str(request["request_id"]),
        "status": "completed",
        "result": result.to_dict(),
    }
    if len(_canonical_json(unsigned)) > MAX_RESULT_BYTES - 1024:
        raise ValueError("forced result exceeds durable file size bound")
    return {
        **unsigned,
        "payload_sha256": hashlib.sha256(_canonical_json(unsigned)).hexdigest(),
    }


def failed_result_envelope(
    request: Mapping[str, Any] | None, *, category: str, error_type: str
) -> dict[str, Any]:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": str(request.get("request_id", "unknown"))
        if isinstance(request, Mapping)
        else "unknown",
        "status": "failed",
        "error": {"category": str(category), "type": str(error_type)},
    }


def chunk_event_envelope(
    request_id: str, *, ordinal: int, chunk: ForcedTimestampChunkResult
) -> dict[str, Any]:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "event": "chunk",
        "request_id": request_id,
        "ordinal": ordinal,
        "chunk_id": chunk.chunk_id,
        "chunk": chunk.to_dict(),
    }


def _parse_word(value: Any) -> WordTimestamp:
    item = _mapping(
        value,
        fields={"text", "start_ms", "end_ms", "source_start", "source_end", "chunk_id"},
        label="word timestamp",
    )
    return WordTimestamp(
        text=_strict_text(item["text"], label="word.text"),
        start_ms=_strict_int(item["start_ms"], label="word.start_ms", minimum=0),
        end_ms=_strict_int(item["end_ms"], label="word.end_ms", minimum=0),
        source_start=_strict_int(item["source_start"], label="word.source_start", minimum=0),
        source_end=_strict_int(item["source_end"], label="word.source_end", minimum=0),
        chunk_id=_strict_text(item["chunk_id"], label="word.chunk_id", max_bytes=4096),
    )


def _parse_character(value: Any) -> CharacterTimestamp:
    item = _mapping(
        value,
        fields={"text", "start_ms", "end_ms", "source_index", "chunk_id"},
        label="character timestamp",
    )
    text = _strict_text(item["text"], label="character.text", max_bytes=16)
    if len(text) != 1:
        raise ValueError("character timestamp must contain one code point")
    return CharacterTimestamp(
        text=text,
        start_ms=_strict_int(item["start_ms"], label="character.start_ms", minimum=0),
        end_ms=_strict_int(item["end_ms"], label="character.end_ms", minimum=0),
        source_index=_strict_int(item["source_index"], label="character.source_index", minimum=0),
        chunk_id=_strict_text(item["chunk_id"], label="character.chunk_id", max_bytes=4096),
    )


def _parse_audit_chunk(value: Any) -> ChunkTimestampAudit:
    item = _mapping(
        value,
        fields={
            "chunk_id",
            "method",
            "core_start_ms",
            "core_end_ms",
            "word_count",
            "character_count",
            "clipped_word_count",
            "window_clamped_word_count",
            "intra_block_monotonic_adjusted_word_count",
            "seam_adjusted_word_count",
            "max_window_clamp_ms",
            "max_intra_block_shift_ms",
            "max_seam_shift_ms",
            "raw_zero_duration_word_count",
            "quantization_repaired_word_count",
            "max_quantization_repair_ms",
            "zero_duration_word_count",
            "fallback_reason",
        },
        label="chunk audit",
    )
    fallback = item["fallback_reason"]
    if fallback is not None:
        fallback = _strict_text(fallback, label="fallback_reason", max_bytes=1024)
    return ChunkTimestampAudit(
        chunk_id=_strict_text(item["chunk_id"], label="audit.chunk_id", max_bytes=4096),
        method=_strict_text(item["method"], label="audit.method", max_bytes=1024),
        core_start_ms=_strict_int(item["core_start_ms"], label="audit.core_start_ms", minimum=0),
        core_end_ms=_strict_int(item["core_end_ms"], label="audit.core_end_ms", minimum=0),
        word_count=_strict_int(item["word_count"], label="audit.word_count", minimum=0),
        character_count=_strict_int(item["character_count"], label="audit.character_count", minimum=0),
        clipped_word_count=_strict_int(item["clipped_word_count"], label="audit.clipped_word_count", minimum=0),
        window_clamped_word_count=_strict_int(
            item["window_clamped_word_count"],
            label="audit.window_clamped_word_count",
            minimum=0,
        ),
        intra_block_monotonic_adjusted_word_count=_strict_int(
            item["intra_block_monotonic_adjusted_word_count"],
            label="audit.intra_block_monotonic_adjusted_word_count",
            minimum=0,
        ),
        seam_adjusted_word_count=_strict_int(
            item["seam_adjusted_word_count"],
            label="audit.seam_adjusted_word_count",
            minimum=0,
        ),
        max_window_clamp_ms=_strict_int(
            item["max_window_clamp_ms"], label="audit.max_window_clamp_ms", minimum=0
        ),
        max_intra_block_shift_ms=_strict_int(
            item["max_intra_block_shift_ms"],
            label="audit.max_intra_block_shift_ms",
            minimum=0,
        ),
        max_seam_shift_ms=_strict_int(
            item["max_seam_shift_ms"], label="audit.max_seam_shift_ms", minimum=0
        ),
        raw_zero_duration_word_count=_strict_int(
            item["raw_zero_duration_word_count"],
            label="audit.raw_zero_duration_word_count",
            minimum=0,
        ),
        quantization_repaired_word_count=_strict_int(
            item["quantization_repaired_word_count"],
            label="audit.quantization_repaired_word_count",
            minimum=0,
        ),
        max_quantization_repair_ms=_strict_int(
            item["max_quantization_repair_ms"],
            label="audit.max_quantization_repair_ms",
            minimum=0,
        ),
        zero_duration_word_count=_strict_int(
            item["zero_duration_word_count"],
            label="audit.zero_duration_word_count",
            minimum=0,
        ),
        fallback_reason=fallback,
    )


def _parse_cue(value: Any) -> SubtitleCue:
    item = _mapping(
        value,
        fields={"index", "start_ms", "end_ms", "text", "source_start", "source_end"},
        label="subtitle cue",
    )
    return SubtitleCue(
        index=_strict_int(item["index"], label="cue.index", minimum=1),
        start_ms=_strict_int(item["start_ms"], label="cue.start_ms", minimum=0),
        end_ms=_strict_int(item["end_ms"], label="cue.end_ms", minimum=0),
        text=_strict_text(item["text"], label="cue.text"),
        source_start=_strict_int(item["source_start"], label="cue.source_start", minimum=0),
        source_end=_strict_int(item["source_end"], label="cue.source_end", minimum=0),
    )


def _parse_final_result(
    value: Any,
    *,
    expected_text: str,
    expected_model_id: str,
    expected_blocks: Sequence[Any],
    durable_chunks: Sequence[ForcedTimestampChunkResult],
) -> ForcedTimestampResult:
    item = _mapping(
        value,
        fields={"text", "words", "characters", "cues", "audit"},
        label="forced result",
    )
    text = _strict_text(item["text"], label="result.text")
    if text != expected_text:
        raise ValueError("forced result text does not match chosen transcript")
    if not all(isinstance(item[key], list) for key in ("words", "characters", "cues")):
        raise ValueError("forced result timestamp arrays are invalid")
    if any(len(item[key]) > MAX_TIMESTAMP_ITEMS for key in ("words", "characters", "cues")):
        raise ValueError("forced result exceeds timestamp item bound")
    words = tuple(_parse_word(raw) for raw in item["words"])
    characters = tuple(_parse_character(raw) for raw in item["characters"])
    cues = tuple(_parse_cue(raw) for raw in item["cues"])
    audit_value = _mapping(
        item["audit"],
        fields={"method", "model", "policy_version", "cue_policy", "fallback_reasons", "chunks"},
        label="forced audit",
    )
    if not isinstance(audit_value["fallback_reasons"], list) or not isinstance(
        audit_value["chunks"], list
    ):
        raise ValueError("forced audit arrays are invalid")
    audit_chunks = tuple(_parse_audit_chunk(raw) for raw in audit_value["chunks"])
    audit = ForcedTimestampAudit(
        method=_strict_text(audit_value["method"], label="audit.method", max_bytes=1024),
        model=_strict_text(audit_value["model"], label="audit.model", max_bytes=2048),
        policy_version=_strict_text(audit_value["policy_version"], label="audit.policy_version", max_bytes=1024),
        cue_policy=_strict_text(audit_value["cue_policy"], label="audit.cue_policy", max_bytes=4096),
        fallback_reasons=tuple(
            _strict_text(raw, label="audit.fallback_reason", max_bytes=1024)
            for raw in audit_value["fallback_reasons"]
        ),
        chunks=audit_chunks,
    )
    if len(durable_chunks) != len(expected_blocks) or len(audit_chunks) != len(expected_blocks):
        raise ValueError("forced result chunk count is invalid")
    for durable, block in zip(durable_chunks, expected_blocks):
        _validate_resumed_chunk(durable, block)
    expected_words = tuple(word for chunk in durable_chunks for word in chunk.words)
    expected_characters = tuple(character for chunk in durable_chunks for character in chunk.characters)
    if words != expected_words or characters != expected_characters:
        raise ValueError("forced result timestamps differ from durable chunks")
    if audit_chunks != tuple(chunk.audit for chunk in durable_chunks):
        raise ValueError("forced result audit differs from durable chunks")
    expected_fallbacks: list[str] = []
    for chunk in durable_chunks:
        reason = chunk.audit.fallback_reason
        if reason is not None and reason not in expected_fallbacks:
            expected_fallbacks.append(reason)
    expected_method = FORCED_ALIGNER_METHOD
    if expected_fallbacks:
        expected_method = (
            "deterministic_coarse_fallback"
            if all(chunk.audit.fallback_reason for chunk in durable_chunks)
            else "qwen3_forced_aligner_with_fallback"
        )
    if (
        audit.model != expected_model_id
        or audit.policy_version != FORCED_TIMESTAMP_POLICY_VERSION
        or audit.method != expected_method
        or audit.fallback_reasons != tuple(expected_fallbacks)
    ):
        raise ValueError("forced result stage audit is inconsistent")
    if len(characters) != len(text):
        raise ValueError("forced result character coverage is incomplete")
    previous_time = 0
    for index, character in enumerate(characters):
        if (
            character.text != text[index]
            or character.source_index != index
            or character.end_ms < character.start_ms
            or character.start_ms < previous_time
        ):
            raise ValueError("forced result character order is invalid")
        previous_time = character.end_ms
    previous_source = 0
    previous_time = 0
    for cue_index, cue in enumerate(cues, start=1):
        if (
            cue.index != cue_index
            or cue.source_start != previous_source
            or cue.source_end <= cue.source_start
            or cue.source_end > len(text)
            or cue.text != text[cue.source_start : cue.source_end]
            or cue.end_ms < cue.start_ms
            or cue.start_ms < previous_time
        ):
            raise ValueError("forced result cue order is invalid")
        previous_source = cue.source_end
        previous_time = cue.end_ms
    if previous_source != len(text) or "".join(cue.text for cue in cues) != text:
        raise ValueError("forced result cue coverage is incomplete")
    return ForcedTimestampResult(
        text=text,
        words=words,
        characters=characters,
        cues=cues,
        audit=audit,
    )


def _load_completed_result(
    path: Path,
    *,
    request_id: str,
    expected_text: str,
    expected_model_id: str,
    expected_blocks: Sequence[Any],
    durable_chunks: Sequence[ForcedTimestampChunkResult],
) -> ForcedTimestampResult:
    value = _read_owner_json(path, max_bytes=MAX_RESULT_BYTES)
    envelope = _mapping(
        value,
        fields={"protocol_version", "request_id", "status", "result", "payload_sha256"},
        label="forced result envelope",
    )
    if (
        envelope["protocol_version"] != PROTOCOL_VERSION
        or envelope["request_id"] != request_id
        or envelope["status"] != "completed"
    ):
        raise ValueError("forced result identity/status is invalid")
    digest = _strict_text(envelope["payload_sha256"], label="payload_sha256", max_bytes=128)
    if len(digest) != 64:
        raise ValueError("forced result digest is invalid")
    unsigned = dict(envelope)
    unsigned.pop("payload_sha256")
    actual = hashlib.sha256(_canonical_json(unsigned)).hexdigest()
    if not hmac.compare_digest(digest, actual):
        raise ValueError("forced result digest mismatch")
    return _parse_final_result(
        envelope["result"],
        expected_text=expected_text,
        expected_model_id=expected_model_id,
        expected_blocks=expected_blocks,
        durable_chunks=durable_chunks,
    )


def _failure_category(path: Path, request_id: str) -> str:
    try:
        value = _read_owner_json(path, max_bytes=MAX_RESULT_BYTES)
    except (OSError, ValueError):
        return "child_crash"
    if not isinstance(value, Mapping) or value.get("request_id") != request_id:
        return "child_crash"
    error = value.get("error")
    if isinstance(error, Mapping):
        category = error.get("category")
        if isinstance(category, str) and category in {
            "input_error",
            "protocol_error",
            "runtime_error",
            "child_crash",
            "cancelled",
        }:
            return category
    return "child_crash"


def _group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _signal_group(process_group_id: int, signum: int) -> None:
    try:
        os.killpg(process_group_id, signum)
    except ProcessLookupError:
        pass
    except PermissionError:
        # A hardened runner can deny process-group signalling even though the
        # directly spawned child remains ours.  Still terminate that child and
        # let the bounded wait below verify it exited; never leak a timeout
        # child merely because killpg itself was restricted.
        try:
            os.kill(process_group_id, signum)
        except ProcessLookupError:
            pass


def terminate_process_group(process: subprocess.Popen[bytes], *, grace_seconds: float) -> None:
    """Bounded TERM -> KILL for the child and every helper it spawned."""

    group_id = process.pid
    started = time.monotonic()
    final_deadline = started + 2.9
    _signal_group(group_id, signal.SIGTERM)
    term_deadline = started + min(2.5, max(0.0, float(grace_seconds)))
    while time.monotonic() < term_deadline:
        if process.poll() is not None and not _group_exists(group_id):
            break
        time.sleep(0.01)
    if _group_exists(group_id):
        _signal_group(group_id, signal.SIGKILL)
    try:
        process.wait(timeout=max(0.01, final_deadline - time.monotonic()))
    except subprocess.TimeoutExpired:
        _signal_group(group_id, signal.SIGKILL)


class ForcedProcessSupervisor:
    """Run one persistent, time-bounded local forced-alignment child."""

    def __init__(
        self,
        *,
        config: ForcedSupervisorConfig | None = None,
        child_command: Sequence[str] | None = None,
    ) -> None:
        self.config = config or ForcedSupervisorConfig()
        self.child_command = tuple(
            child_command
            or (sys.executable, "-m", "cts_backend.alignment.forced_child")
        )
        if not self.child_command or any(
            not isinstance(item, str) or not item for item in self.child_command
        ):
            raise ValueError("child command must contain non-empty strings")

    @staticmethod
    def _emit(callback: Telemetry | None, event: Mapping[str, Any]) -> None:
        if callback is not None:
            callback(dict(_json_safe(event)))

    def run(
        self,
        *,
        model_path: str | Path,
        chunks: Iterable[Any],
        chosen_segments: Iterable[Any],
        workspace: str | Path,
        model_id: str = FORCED_ALIGNER_MODEL_ID,
        language: str = "Cantonese",
        progress: Telemetry | None = None,
        cancelled: Cancelled | None = None,
        resume_chunks: Iterable[Any] = (),
        chunk_completed: ChunkCompleted | None = None,
    ) -> ForcedTimestampResult:
        model = validate_local_forced_aligner_model(model_path)
        items, chosen, blocks, final_text = _normalize_request_inputs(
            chunks, chosen_segments
        )
        resumed = tuple(_coerce_resumed_chunk(raw) for raw in resume_chunks)
        if len(resumed) > len(blocks):
            raise ValueError("resume chunks exceed expected blocks")
        for durable, block in zip(resumed, blocks):
            _validate_resumed_chunk(durable, block)
        root = Path(workspace)
        root.mkdir(parents=True, exist_ok=True)
        request = _request_payload(
            model_path=model,
            model_id=model_id,
            language=language,
            chunks=items,
            chosen_segments=chosen,
            resume_chunks=resumed,
        )
        request = validate_request_payload(request)
        if len(_canonical_json(request)) > MAX_REQUEST_BYTES:
            raise ValueError("forced request exceeds durable file size bound")
        request_id = str(request["request_id"])
        request_path = root / f"forced-{request_id}.request.json"
        result_path = root / f"forced-{request_id}.result.json"
        atomic_write_json(request_path, request)

        event_read_fd, event_write_fd = os.pipe()
        chunk_read_fd, chunk_write_fd = os.pipe()
        os.set_inheritable(event_write_fd, True)
        os.set_inheritable(chunk_write_fd, True)
        command = [
            *self.child_command,
            "--request",
            str(request_path),
            "--result",
            str(result_path),
            "--event-fd",
            str(event_write_fd),
            "--chunk-fd",
            str(chunk_write_fd),
            "--parent-pid",
            str(os.getpid()),
            "--heartbeat-seconds",
            str(self.config.child_heartbeat_seconds),
        ]

        process: subprocess.Popen[bytes] | None = None
        selector = selectors.DefaultSelector()
        buffers = {event_read_fd: bytearray(), chunk_read_fd: bytearray()}
        channels = {event_read_fd: "event", chunk_read_fd: "chunk"}
        open_pipes = {event_read_fd: True, chunk_read_fd: True}
        pipe_bytes = {event_read_fd: 0, chunk_read_fd: 0}
        limits = {event_read_fd: MAX_EVENT_PIPE_BYTES, chunk_read_fd: MAX_CHUNK_PIPE_BYTES}
        started = time.monotonic()
        last_substantive = started
        model_loaded = False
        stage_complete = False
        current_chunk_started: float | None = None
        current_chunk_ordinal: int | None = None
        next_ordinal = len(resumed)
        highest_progress_ordinal = len(resumed) - 1
        durable_chunks = list(resumed)
        progress_fractions: dict[int, float] = {}
        drain_deadline: float | None = None

        def decode(line: bytes, *, channel: str) -> Mapping[str, Any]:
            try:
                raw = json.loads(
                    line.decode("utf-8"), parse_constant=_reject_json_constant
                )
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
                raise ForcedProtocolError(f"forced child emitted invalid {channel} JSON") from exc
            if not isinstance(raw, Mapping) or raw.get("protocol_version") != PROTOCOL_VERSION:
                raise ForcedProtocolError("forced child protocol mismatch")
            return raw

        def accept_chunk(line: bytes) -> None:
            nonlocal next_ordinal, last_substantive, current_chunk_started
            nonlocal current_chunk_ordinal
            raw = decode(line, channel="chunk")
            try:
                _mapping(
                    raw,
                    fields={"protocol_version", "event", "request_id", "ordinal", "chunk_id", "chunk"},
                    label="chunk envelope",
                )
            except (TypeError, ValueError) as exc:
                raise ForcedProtocolError("forced chunk envelope schema is invalid") from exc
            if raw["event"] != "chunk" or raw["request_id"] != request_id:
                raise ForcedProtocolError("forced chunk envelope identity is invalid")
            ordinal = _strict_int(raw["ordinal"], label="chunk ordinal", minimum=0)
            if ordinal != next_ordinal or ordinal >= len(blocks):
                raise ForcedProtocolError("forced child chunk order is invalid")
            try:
                chunk = _coerce_resumed_chunk(raw["chunk"])
                if raw["chunk_id"] != chunk.chunk_id:
                    raise ValueError("chunk id mismatch")
                _validate_resumed_chunk(chunk, blocks[ordinal])
            except (TypeError, ValueError) as exc:
                raise ForcedProtocolError("forced child chunk payload is invalid") from exc
            # The durable journal callback runs before the ordinal advances.  A
            # callback failure therefore cannot be mistaken for completion.
            if chunk_completed is not None:
                chunk_completed(chunk)
            durable_chunks.append(chunk)
            next_ordinal += 1
            last_substantive = time.monotonic()
            if current_chunk_ordinal == ordinal:
                current_chunk_started = None
                current_chunk_ordinal = None
            self._emit(
                progress,
                {
                    "event": "chunk_completed",
                    "chunk_id": chunk.chunk_id,
                    "chunk_index": ordinal + 1,
                    "chunk_total": len(blocks),
                    "progress": next_ordinal / len(blocks) if blocks else 1.0,
                },
            )

        def accept_event(line: bytes) -> None:
            nonlocal model_loaded, last_substantive, current_chunk_started, stage_complete
            nonlocal current_chunk_ordinal, highest_progress_ordinal
            raw = decode(line, channel="event")
            event = raw.get("event")
            if event in {"ready", "heartbeat", "stage_complete"}:
                try:
                    _mapping(
                        raw,
                        fields={"protocol_version", "event"},
                        label=f"{event} event",
                    )
                except (TypeError, ValueError) as exc:
                    raise ForcedProtocolError(f"forced {event} event schema is invalid") from exc
                if event == "stage_complete":
                    stage_complete = True
                return
            if event == "error":
                try:
                    _mapping(
                        raw,
                        fields={"protocol_version", "event", "category", "error_type"},
                        label="error event",
                    )
                    category = _strict_text(raw["category"], label="error.category", max_bytes=128)
                    error_type = _strict_text(raw["error_type"], label="error.type", max_bytes=256)
                except (KeyError, TypeError, ValueError) as exc:
                    raise ForcedProtocolError("forced error event schema is invalid") from exc
                self._emit(progress, {"event": "child_error", "category": category, "error_type": error_type})
                return
            if event != "progress":
                raise ForcedProtocolError("forced child emitted an unknown event")
            try:
                _mapping(
                    raw,
                    fields={
                        "protocol_version",
                        "event",
                        "chunk_id",
                        "chunk_index",
                        "chunk_total",
                        "fraction",
                    },
                    label="progress event",
                )
                index = _strict_int(raw["chunk_index"], label="progress.chunk_index", minimum=1)
                total = _strict_int(raw["chunk_total"], label="progress.chunk_total", minimum=1)
                fraction = _finite_number(raw["fraction"], label="progress.fraction")
            except (KeyError, TypeError, ValueError) as exc:
                raise ForcedProtocolError("forced progress event schema is invalid") from exc
            if not 0.0 <= fraction <= 1.0 or total != len(blocks) or index > total:
                raise ForcedProtocolError("forced progress bounds are invalid")
            if raw["chunk_id"] != blocks[index - 1].chunk.id:
                raise ForcedProtocolError("forced progress chunk identity is invalid")
            ordinal = index - 1
            # The transcript and metadata pipes are intentionally independent.
            # Validate order *within this metadata pipe* rather than against
            # the durable pipe, which may legitimately be observed earlier or
            # later by the selector.
            if ordinal < highest_progress_ordinal or ordinal > highest_progress_ordinal + 1:
                raise ForcedProtocolError("forced progress order is invalid")
            previous = progress_fractions.get(ordinal, -1.0)
            if fraction < previous:
                raise ForcedProtocolError("forced progress regressed")
            if ordinal == highest_progress_ordinal + 1:
                if highest_progress_ordinal >= len(resumed) and progress_fractions.get(
                    highest_progress_ordinal, -1.0
                ) < 1.0:
                    raise ForcedProtocolError("forced progress skipped an incomplete chunk")
                highest_progress_ordinal = ordinal
                if ordinal >= next_ordinal:
                    current_chunk_started = time.monotonic()
                    current_chunk_ordinal = ordinal
            if fraction > previous:
                progress_fractions[ordinal] = fraction
                last_substantive = time.monotonic()
            model_loaded = True
            self._emit(
                progress,
                {
                    "event": "progress",
                    "chunk_id": str(raw["chunk_id"]),
                    "chunk_index": index,
                    "chunk_total": total,
                    # Wire ``fraction`` is intentionally local to this chunk
                    # for strict ordering validation.  UI/job progress remains
                    # monotonic across the complete alignment stage.
                    "progress": (ordinal + fraction) / total,
                },
            )

        try:
            try:
                process = subprocess.Popen(
                    command,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                    pass_fds=(event_write_fd, chunk_write_fd),
                    start_new_session=True,
                    shell=False,
                )
            except OSError as exc:
                raise ForcedChildCrashError(
                    "forced child could not be launched",
                    returncode=None,
                    child_category="launch_error",
                ) from exc
            os.close(event_write_fd)
            event_write_fd = -1
            os.close(chunk_write_fd)
            chunk_write_fd = -1
            for descriptor in (event_read_fd, chunk_read_fd):
                os.set_blocking(descriptor, False)
                selector.register(descriptor, selectors.EVENT_READ, channels[descriptor])
            self._emit(
                progress,
                {
                    "event": "child_started",
                    "pid": process.pid,
                    "chunk_index": next_ordinal + 1 if next_ordinal < len(blocks) else len(blocks),
                    "chunk_total": len(blocks),
                },
            )

            while True:
                now = time.monotonic()
                if cancelled is not None and cancelled():
                    terminate_process_group(process, grace_seconds=self.config.termination_grace_seconds)
                    raise ForcedProcessCancelled("已取消 forced timestamp alignment")
                if now - started >= self.config.hard_wall_seconds:
                    terminate_process_group(process, grace_seconds=self.config.termination_grace_seconds)
                    raise ForcedProcessTimeout(
                        "forced child exceeded hard wall deadline", timeout_kind="wall"
                    )
                if not model_loaded and now - started >= self.config.model_load_timeout_seconds:
                    terminate_process_group(process, grace_seconds=self.config.termination_grace_seconds)
                    raise ForcedProcessTimeout(
                        "forced model did not load before deadline", timeout_kind="model_load"
                    )
                if model_loaded and now - last_substantive >= self.config.hard_no_progress_seconds:
                    terminate_process_group(process, grace_seconds=self.config.termination_grace_seconds)
                    raise ForcedProcessTimeout(
                        "forced child made no substantive progress", timeout_kind="no_progress"
                    )
                if current_chunk_started is not None and current_chunk_ordinal is not None:
                    chunk_limit = (
                        self.config.first_chunk_wall_seconds
                        if current_chunk_ordinal == 0
                        else self.config.per_chunk_wall_seconds
                    )
                    if now - current_chunk_started >= chunk_limit:
                        terminate_process_group(process, grace_seconds=self.config.termination_grace_seconds)
                        raise ForcedProcessTimeout(
                            "forced child exceeded chunk wall deadline",
                            timeout_kind="first_chunk_wall"
                            if current_chunk_ordinal == 0
                            else "chunk_wall",
                        )

                ready = selector.select(timeout=self.config.poll_seconds)
                ready.sort(key=lambda pair: 0 if pair[0].data == "chunk" else 1)
                for key, _mask in ready:
                    descriptor = int(key.fd)
                    try:
                        block = os.read(descriptor, 65_536)
                    except BlockingIOError:
                        continue
                    if not block:
                        selector.unregister(descriptor)
                        open_pipes[descriptor] = False
                        continue
                    pipe_bytes[descriptor] += len(block)
                    if pipe_bytes[descriptor] > limits[descriptor]:
                        raise ForcedProtocolError(f"forced {channels[descriptor]} pipe exceeded byte cap")
                    buffer = buffers[descriptor]
                    buffer.extend(block)
                    line_limit = MAX_EVENT_LINE_BYTES if channels[descriptor] == "event" else MAX_CHUNK_LINE_BYTES
                    if len(buffer) > line_limit and b"\n" not in buffer:
                        raise ForcedProtocolError(f"forced {channels[descriptor]} line exceeded byte cap")
                    while b"\n" in buffer:
                        line, _, remainder = buffer.partition(b"\n")
                        buffer[:] = remainder
                        if not line:
                            continue
                        if len(line) > line_limit:
                            raise ForcedProtocolError(f"forced {channels[descriptor]} line exceeded byte cap")
                        if channels[descriptor] == "chunk":
                            accept_chunk(bytes(line))
                        else:
                            accept_event(bytes(line))

                returncode = process.poll()
                if returncode is not None:
                    if drain_deadline is None:
                        drain_deadline = time.monotonic() + self.config.pipe_drain_timeout_seconds
                    if not any(open_pipes.values()):
                        break
                    if time.monotonic() >= drain_deadline:
                        raise ForcedProtocolError(
                            "forced child pipes did not reach EOF before drain deadline",
                            returncode=returncode,
                        )

            for descriptor, buffer in buffers.items():
                if not buffer.strip():
                    continue
                if channels[descriptor] == "chunk":
                    accept_chunk(bytes(buffer))
                else:
                    accept_event(bytes(buffer))
            returncode = process.wait()
            if returncode != 0:
                raise ForcedChildCrashError(
                    "forced child exited unsuccessfully",
                    returncode=returncode,
                    child_category=_failure_category(result_path, request_id),
                )
            if next_ordinal != len(blocks):
                raise ForcedProtocolError(
                    "forced child exited before all chunks were received",
                    returncode=returncode,
                )
            if not stage_complete:
                raise ForcedProtocolError(
                    "forced child omitted stage_complete", returncode=returncode
                )
            try:
                result = _load_completed_result(
                    result_path,
                    request_id=request_id,
                    expected_text=final_text,
                    expected_model_id=model_id,
                    expected_blocks=blocks,
                    durable_chunks=durable_chunks,
                )
            except (OSError, TypeError, ValueError) as exc:
                raise ForcedProtocolError(
                    "forced child result failed validation", returncode=returncode
                ) from exc
            return result
        finally:
            selector.close()
            for descriptor in (
                event_write_fd,
                chunk_write_fd,
                event_read_fd,
                chunk_read_fd,
            ):
                if descriptor < 0:
                    continue
                try:
                    os.close(descriptor)
                except OSError:
                    pass
            if process is not None:
                terminate_process_group(
                    process, grace_seconds=self.config.termination_grace_seconds
                )


__all__ = [
    "ForcedChildCrashError",
    "ForcedProcessCancelled",
    "ForcedProcessError",
    "ForcedProcessSupervisor",
    "ForcedProcessTimeout",
    "ForcedProtocolError",
    "ForcedSupervisorConfig",
    "atomic_write_json",
    "chunk_event_envelope",
    "completed_result_envelope",
    "failed_result_envelope",
    "load_request",
    "terminate_process_group",
    "validate_request_payload",
]
