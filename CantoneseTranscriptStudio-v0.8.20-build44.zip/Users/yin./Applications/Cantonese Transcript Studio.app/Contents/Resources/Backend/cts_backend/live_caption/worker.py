"""Bounded background execution for the microphone-independent caption core."""

from __future__ import annotations

import threading
import time
from collections import deque
from enum import StrEnum
from typing import Any, Callable

from .core import LiveCaptionProcessor
from .timing_archive import LiveTimingArchive, LiveTimingArchivePrepared
from .types import (
    LiveCaptionEvent,
    LiveCaptionEventType,
    LiveCaptionStats,
    _PCMFrame,
)


class LiveCaptionWorkerState(StrEnum):
    CREATED = "created"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    CANCELLED = "cancelled"
    FAILED = "failed"


class _FlushCurrentUtteranceRequest:
    """A zero-audio FIFO control item owned by one caller.

    It sits behind already-accepted PCM in ``_BoundedAudioQueue``.  The
    decoding thread, not an RPC thread, performs the flush so an answer-end
    command cannot race the processor against an in-flight frame.
    """

    def __init__(self) -> None:
        self.done = threading.Event()
        self.error: BaseException | None = None

    def complete(self, error: BaseException | None = None) -> None:
        self.error = error
        self.done.set()


class _BoundedAudioQueue:
    def __init__(self, maximum_bytes: int) -> None:
        self.maximum_bytes = maximum_bytes
        self._pending_bytes = 0
        self._items: deque[_PCMFrame | _FlushCurrentUtteranceRequest] = deque()
        self._closed = False
        self._condition = threading.Condition()

    @property
    def pending_bytes(self) -> int:
        with self._condition:
            return self._pending_bytes

    def put_nowait(self, frame: _PCMFrame) -> bool:
        with self._condition:
            if self._closed:
                raise RuntimeError("live caption audio queue 已關閉")
            if self._pending_bytes + len(frame.data) > self.maximum_bytes:
                return False
            self._items.append(frame)
            self._pending_bytes += len(frame.data)
            self._condition.notify()
            return True

    def put_flush_request(self, request: _FlushCurrentUtteranceRequest) -> None:
        """Append a zero-byte control item behind accepted PCM frames."""

        with self._condition:
            if self._closed:
                raise RuntimeError("live caption audio queue 已關閉")
            self._items.append(request)
            self._condition.notify()

    def get(self) -> _PCMFrame | _FlushCurrentUtteranceRequest | None:
        with self._condition:
            while not self._items and not self._closed:
                self._condition.wait()
            if not self._items:
                return None
            item = self._items.popleft()
            if isinstance(item, _PCMFrame):
                self._pending_bytes -= len(item.data)
            return item

    def close(self, *, discard: bool) -> None:
        with self._condition:
            self._closed = True
            if discard:
                for item in self._items:
                    if isinstance(item, _FlushCurrentUtteranceRequest):
                        item.complete(RuntimeError("live caption audio queue 已取消"))
                self._items.clear()
                self._pending_bytes = 0
            self._condition.notify_all()


class LiveCaptionEventOverflow(RuntimeError):
    """A final was retained in the emergency slot and the session must stop."""


class _EventBuffer:
    """Bound memory without silently discarding confirmed caption text.

    The normal deque stays at ``maximum_events``.  Two emergency slots are
    reserved for the one final that crosses the limit and the resulting error
    event.  The producer then fails closed, so a client that stopped polling
    gets every confirmed final plus an explicit error instead of a plausible
    but incomplete transcript.
    """

    def __init__(self, maximum_events: int) -> None:
        self.maximum_events = maximum_events
        self._items: deque[LiveCaptionEvent] = deque()
        self._critical: deque[LiveCaptionEvent] = deque(maxlen=2)
        self._lock = threading.Lock()

    def put(self, event: LiveCaptionEvent) -> bool:
        with self._lock:
            if event.type is LiveCaptionEventType.PARTIAL:
                for index in range(len(self._items) - 1, -1, -1):
                    existing = self._items[index]
                    if (
                        existing.type is LiveCaptionEventType.PARTIAL
                        and existing.utterance_id == event.utterance_id
                    ):
                        del self._items[index]
                        break
            if len(self._items) >= self.maximum_events:
                partial_index = next(
                    (
                        index
                        for index, item in enumerate(self._items)
                        if item.type is LiveCaptionEventType.PARTIAL
                    ),
                    None,
                )
                if partial_index is not None:
                    del self._items[partial_index]
                elif event.type is LiveCaptionEventType.PARTIAL:
                    return False
                else:
                    disposable_index = next(
                        (
                            index
                            for index, item in enumerate(self._items)
                            if item.type
                            not in {
                                LiveCaptionEventType.FINAL,
                                LiveCaptionEventType.ERROR,
                                LiveCaptionEventType.CANCELLED,
                                LiveCaptionEventType.STOPPED,
                            }
                        ),
                        None,
                    )
                    if disposable_index is not None:
                        del self._items[disposable_index]
                    elif event.type is LiveCaptionEventType.FINAL:
                        self._critical.append(event)
                        raise LiveCaptionEventOverflow(
                            "即時字幕事件已滿；最後一句已保留，session 已安全停止"
                        )
                    elif event.type in {
                        LiveCaptionEventType.ERROR,
                        LiveCaptionEventType.CANCELLED,
                        LiveCaptionEventType.STOPPED,
                    }:
                        self._critical.append(event)
                        return True
                    else:
                        return False
            self._items.append(event)
            return True

    def drain(self, maximum: int | None = None) -> list[LiveCaptionEvent]:
        with self._lock:
            available = len(self._items) + len(self._critical)
            count = available if maximum is None else min(available, maximum)
            output: list[LiveCaptionEvent] = []
            while self._items and len(output) < count:
                output.append(self._items.popleft())
            while self._critical and len(output) < count:
                output.append(self._critical.popleft())
            return output


class LiveCaptionWorker:
    """Run ASR off the UI thread with bounded audio and event buffers."""

    def __init__(
        self,
        processor: LiveCaptionProcessor,
        *,
        maximum_pending_audio_seconds: float = 2.0,
        maximum_pending_events: int = 128,
        owns_engine: bool = True,
        on_clean_stop: Callable[[], dict[str, Any]] | None = None,
        timing_archive: LiveTimingArchive | None = None,
    ) -> None:
        if not 0.25 <= maximum_pending_audio_seconds <= 10.0:
            raise ValueError("maximum_pending_audio_seconds 必須係 0.25 至 10")
        if not 16 <= maximum_pending_events <= 4_096:
            raise ValueError("maximum_pending_events 必須係 16 至 4096")
        self.processor = processor
        self._maximum_pending_audio_seconds = float(maximum_pending_audio_seconds)
        maximum_bytes = round(
            processor.config.sample_rate * maximum_pending_audio_seconds
        ) * 2
        self._audio = _BoundedAudioQueue(maximum_bytes)
        self._events = _EventBuffer(maximum_pending_events)
        self._owns_engine = owns_engine
        # The callback is intentionally in-memory only. Worker-level callers
        # use it to capture a validated profile snapshot *after* the final
        # utterance, before native model teardown clears RAM. It is never
        # invoked on cancellation, processing failure, or polling.
        self._on_clean_stop = on_clean_stop
        self._profile_snapshot: dict[str, Any] | None = None
        # A timing archive is deliberately a separate opt-in transaction. It
        # only sees frames after bounded-queue admission and stays private in
        # staging until the one normal-stop RPC consumes its receipt.
        if (
            timing_archive is not None
            and timing_archive.sample_rate_hz != processor.config.sample_rate
        ):
            raise ValueError("timing archive sample rate 同 live caption 唔一致")
        self._timing_archive = timing_archive
        self._timing_archive_prepared: LiveTimingArchivePrepared | None = None
        # Terminal cleanup is one-shot and must not quietly collapse back to
        # ``disabled``.  This status contains no paths, audio bytes, caption
        # text, or hashes; it exists solely to surface an unprovable erase.
        self._timing_archive_terminal_status: dict[str, Any] | None = None
        self._lock = threading.Lock()
        self._state = LiveCaptionWorkerState.CREATED
        self._thread: threading.Thread | None = None
        self._cancel_requested = False
        # A stop request normally drains the bounded queue and finishes the
        # final utterance.  If the caller's deadline elapses while native ASR
        # is in flight, this flag turns that *failed* stop into an explicit
        # terminal failure once the cross-thread engine close interrupts it.
        # It also closes the clean-stop persistence channel immediately: an
        # over-deadline run must never later hand off a plausible snapshot.
        self._forced_stop_failure_requested = False
        # Engine close is allowed to originate from the owner thread after an
        # ASR timeout.  It must therefore be single-flight: the worker's
        # `finally` path and the timeout path must not race two native close
        # calls.  The concrete engines guarantee that `close()` is safe from
        # a non-worker thread; this worker adds ownership and bounded waiting.
        self._engine_close_lock = threading.Lock()
        self._engine_close_started = False
        self._engine_close_complete = threading.Event()
        self._engine_close_error: Exception | None = None
        # Keep these clocks separate.  ``_accepted_pcm_samples`` is the public
        # accepted-PCM clock used by stats and manual interview markers; it
        # must never advance for a frame the bounded queue rejects.  The
        # decoder still needs ``_timeline_samples`` to retain a real capture
        # gap after an overrun, so subtitle event timing is not silently
        # compressed when live PCM was dropped.
        self._accepted_pcm_samples = 0
        self._timeline_samples = 0
        self._dropped_samples = 0
        self._accepted_frames = 0
        self._dropped_frames = 0
        self._emitted_events = 0

    @property
    def state(self) -> LiveCaptionWorkerState:
        with self._lock:
            return self._state

    @property
    def maximum_pending_audio_seconds(self) -> float:
        """Return the bounded capture backlog configured by the owner."""

        return self._maximum_pending_audio_seconds

    def take_profile_snapshot(self) -> dict[str, Any] | None:
        """Consume the one clean-stop project snapshot, if one exists.

        A project snapshot is sensitive decrypted speaker-profile material.  It
        exists only long enough for the owning worker RPC to put it into the
        *single* normal-stop response.  Returning a copy without clearing the
        internal slot would leave a second, avoidable plaintext reference in a
        terminal worker (and allow a duplicate ``live.stop`` response to emit
        it again).
        """

        with self._lock:
            snapshot = self._profile_snapshot
            self._profile_snapshot = None
            return None if snapshot is None else dict(snapshot)

    def timing_archive_status(self) -> dict[str, Any]:
        """Expose retention state only; never expose microphone bytes or paths."""

        with self._lock:
            archive = self._timing_archive
            prepared = self._timing_archive_prepared
            terminal_status = self._timing_archive_terminal_status
        if archive is None and prepared is None:
            if terminal_status is not None:
                return dict(terminal_status)
            return {
                "enabled": False,
                "state": "disabled",
                "local_only": True,
                "review_only": True,
                "automatic_timestamp_mutation": False,
                "candidate_state": "not_run",
                "integrity_scope": None,
                "archive_id": None,
                "source_audio_sha256": None,
                "manifest_sha256": None,
                "detached_receipt_sha256": None,
                "accepted_samples": 0,
                "dropped_samples": 0,
                "sample_rate_hz": self.processor.config.sample_rate,
                "durability_warning": None,
                "error_code": None,
            }
        if archive is not None:
            return archive.status_value()
        # A prepared receipt is still private staging. The owner must either
        # atomically publish it from `live.stop` or abort it; callers may not
        # infer that it already survives the session boundary.
        return {
            "enabled": True,
            "state": "prepared",
            "local_only": True,
            "review_only": True,
            "automatic_timestamp_mutation": False,
            "candidate_state": "not_run",
            "integrity_scope": None,
            "archive_id": prepared.session_id if prepared is not None else None,
            "source_audio_sha256": None,
            "manifest_sha256": None,
            "detached_receipt_sha256": None,
            "accepted_samples": 0,
            "dropped_samples": 0,
            "sample_rate_hz": self.processor.config.sample_rate,
            "durability_warning": None,
            "error_code": None,
        }

    def take_timing_archive_prepared(self) -> LiveTimingArchivePrepared | None:
        """Consume a staged receipt only from the normal-stop owner path."""

        with self._lock:
            if self._state is not LiveCaptionWorkerState.STOPPED:
                return None
            prepared = self._timing_archive_prepared
            self._timing_archive_prepared = None
            self._timing_archive = None
            self._timing_archive_terminal_status = None
            return prepared

    def discard_timing_archive(self) -> dict[str, Any] | None:
        """Abort once and retain a sanitised terminal privacy status."""

        with self._lock:
            if self._timing_archive_terminal_status is not None:
                return dict(self._timing_archive_terminal_status)
            prepared = self._timing_archive_prepared
            archive = self._timing_archive
            self._timing_archive_prepared = None
            self._timing_archive = None
        if prepared is not None:
            erased = prepared.abort()
            status = {
                "enabled": True,
                "state": "aborted" if erased else "failed",
                "local_only": True,
                "review_only": True,
                "automatic_timestamp_mutation": False,
                "candidate_state": "not_run",
                "integrity_scope": None,
                "archive_id": prepared.session_id,
                "source_audio_sha256": None,
                "manifest_sha256": None,
                "detached_receipt_sha256": None,
                "accepted_samples": 0,
                "dropped_samples": 0,
                "sample_rate_hz": self.processor.config.sample_rate,
                "durability_warning": None,
                "error_code": (
                    None
                    if erased
                    else "discard_cleanup_failed_possible_local_retention"
                ),
            }
        elif archive is not None:
            archive.abort()
            status = archive.status_value()
        else:
            return None
        with self._lock:
            # A second terminal path returns this identical value and never
            # retries a delete whose proof already failed.
            self._timing_archive_terminal_status = dict(status)
            return dict(status)

    def _prepare_timing_archive_for_clean_stop(self) -> None:
        """Stage a receipt after final caption drain, never publish it here."""

        with self._lock:
            archive = (
                None
                if self._cancel_requested or self._forced_stop_failure_requested
                else self._timing_archive
            )
        if archive is None:
            return
        try:
            prepared = archive.prepare()
        except Exception:
            # A disk or hash failure must not disturb confirmed captions, but
            # it must not leave partial microphone bytes as a usable artifact.
            self.discard_timing_archive()
            return
        with self._lock:
            if self._cancel_requested or self._forced_stop_failure_requested:
                accepted = False
            else:
                self._timing_archive_prepared = prepared
                accepted = True
        if not accepted:
            self.discard_timing_archive()

    def _publish(self, events: list[LiveCaptionEvent]) -> None:
        published = 0
        for event in events:
            try:
                if self._events.put(event):
                    published += 1
            except LiveCaptionEventOverflow:
                # The overflow final is already retained in the emergency slot.
                published += 1
                raise
            finally:
                if published:
                    with self._lock:
                        self._emitted_events += published
                    published = 0

    def _forced_stop_failure_pending(self) -> bool:
        """Return whether a normal stop crossed its bounded shutdown deadline."""

        with self._lock:
            return self._forced_stop_failure_requested

    def _close_owned_engines(self) -> None:
        """Close owned native engines exactly once, across either thread.

        The live decoder normally owns teardown from its `finally` block.  A
        native ASR call can nevertheless be in flight past the caller's
        timeout, so `stop()` / `cancel()` may need to request that same close
        from their owner thread.  The first caller performs the close; later
        callers wait for its result instead of issuing a second native close.

        This intentionally has no timeout by itself.  Normal worker teardown
        must wait for resource release, whereas the public timeout paths use
        `_force_close_after_timeout()` to bound their wait separately.
        """

        if not self._owns_engine:
            return
        with self._engine_close_lock:
            if self._engine_close_started:
                wait_for_existing_close = True
            else:
                self._engine_close_started = True
                wait_for_existing_close = False
        if wait_for_existing_close:
            self._engine_close_complete.wait()
            with self._engine_close_lock:
                error = self._engine_close_error
            if error is not None:
                raise RuntimeError("live caption engine cleanup failed") from error
            return

        try:
            self.processor.close_engines()
        except Exception as exc:
            with self._engine_close_lock:
                self._engine_close_error = exc
            raise
        finally:
            self._engine_close_complete.set()

    def _request_forced_shutdown(self, *, cancelled: bool) -> None:
        """Fail closed after a bounded stop/cancel wait has elapsed."""

        with self._lock:
            if cancelled:
                self._cancel_requested = True
                # The decoder can complete in the tiny gap between the first
                # bounded join observing it alive and this escalation acquiring
                # the lock. A late cancel is still a privacy boundary: do not
                # leave that raced clean terminal eligible for a profile hand-off.
                if self._state is LiveCaptionWorkerState.STOPPED:
                    self._state = LiveCaptionWorkerState.CANCELLED
            else:
                self._forced_stop_failure_requested = True
                # Same race as above, but a normal stop that crossed its
                # deadline must not be reported as a clean `stopped` session.
                if self._state is LiveCaptionWorkerState.STOPPED:
                    self._state = LiveCaptionWorkerState.FAILED
            # A timeout cannot still qualify as a clean project stop.  Clear
            # both the completed and not-yet-invoked hand-off routes before
            # requesting native model teardown.
            self._profile_snapshot = None
            self._on_clean_stop = None
        # Discard queued PCM too. The thread may be blocked in one inference,
        # but it must not resume into additional stale audio afterwards.
        self._audio.close(discard=True)
        self.discard_timing_archive()

    def _force_close_after_timeout(
        self,
        *,
        thread: threading.Thread | None,
        timeout: float,
        cancelled: bool,
    ) -> bool:
        """Request cross-thread native close, then bounded-join the decoder.

        `processor.close_engines()` is deliberately invoked in a small daemon
        helper so a faulty native close cannot make the UI/RPC caller wait
        indefinitely.  A successful close should interrupt the in-flight ASR
        call and let the real decoder thread reach its own terminal `finally`.
        If it cannot, this method returns ``False`` and the public caller keeps
        the worker in `stopping` rather than falsely reporting a terminal state.
        """

        self._request_forced_shutdown(cancelled=cancelled)
        if thread is None:
            return True

        close_complete = threading.Event()

        def close_engines() -> None:
            try:
                self._close_owned_engines()
            except Exception:
                # `_close_owned_engines()` records its result for the decoder
                # thread. Avoid an unhandled daemon-thread traceback while the
                # public path stays bounded and reports the terminal state.
                pass
            finally:
                close_complete.set()

        closer = threading.Thread(
            target=close_engines,
            name="cts-live-caption-force-close",
            daemon=True,
        )
        closer.start()

        # Keep the escalation bounded even if a third-party native runtime
        # violates its interruptible-close contract.  The normal deadline has
        # already elapsed; this is only a short resource-release grace period.
        grace_seconds = min(2.0, max(0.25, float(timeout)))
        deadline = time.monotonic() + grace_seconds
        close_complete.wait(timeout=max(0.0, deadline - time.monotonic()))
        remaining = max(0.0, deadline - time.monotonic())
        thread.join(timeout=remaining)
        # Once the native close returned, let the decoder publish its terminal
        # event/finally state.  A tiny fixed join closes the scheduling race
        # without turning this bounded path into an unbounded wait.
        if thread.is_alive() and close_complete.is_set():
            thread.join(timeout=0.05)
        return not thread.is_alive()

    def start(self) -> None:
        with self._lock:
            if self._state is not LiveCaptionWorkerState.CREATED:
                raise RuntimeError("live caption worker 只可以 start 一次")
            self._state = LiveCaptionWorkerState.RUNNING
        self._publish(self.processor.start())
        thread = threading.Thread(
            target=self._run,
            name="cts-live-caption",
            daemon=True,
        )
        self._thread = thread
        thread.start()

    def push_pcm16(self, data: bytes | bytearray | memoryview) -> bool:
        frame = bytes(data)
        if not frame or len(frame) % 2:
            raise ValueError("frame 必須係非空 little-endian PCM16 bytes")
        if len(frame) > self.processor.maximum_frame_bytes:
            raise ValueError(
                f"frame 超過 {self.processor.config.maximum_frame_ms}ms 資源上限"
            )
        with self._lock:
            if self._state is not LiveCaptionWorkerState.RUNNING:
                raise RuntimeError("live caption worker 未開始或已停止")
            sample_count = len(frame) // 2
            # This remains the capture timeline sent to the decoder.  It
            # advances for an offered frame even if the queue rejects it, so
            # the existing bounded-overrun event continues to expose the
            # missing real-time interval instead of retiming subtitles.
            start_sample = self._timeline_samples
            self._timeline_samples += sample_count
            # Hold the worker lock through queue admission and accepted-clock
            # update.  Concurrent push callers therefore cannot receive the
            # same start sample or observe a marker/stat between admission and
            # its corresponding accepted PCM clock increment.  Queue methods
            # never acquire this worker lock, so this ordering does not create
            # a lock cycle with the decoder or close paths.
            accepted = self._audio.put_nowait(
                _PCMFrame(data=frame, start_sample=start_sample)
            )
            # This must stay *after* queue admission.  The archive's source
            # bytes therefore describe the same accepted-PCM clock used by
            # interview markers, while rejected frames remain explicit gaps in
            # its capture lineage rather than hidden audio or compressed time.
            archive = self._timing_archive
            if archive is not None:
                try:
                    archive.record_frame(
                        frame=frame,
                        accepted=accepted,
                        timeline_start_sample=start_sample,
                    )
                except Exception:
                    # A timing-review opt-in must never break normal captions.
                    # The archive reports failed/not-published at stop instead.
                    archive.abort()
            if accepted:
                self._accepted_pcm_samples += sample_count
                self._accepted_frames += 1
            else:
                self._dropped_frames += 1
                self._dropped_samples += sample_count
        return accepted

    def flush_current_utterance(self, *, timeout: float = 15.0) -> None:
        """Finish pre-boundary audio on the decoder FIFO without stopping it.

        A timeout is fail-closed: no caller may infer that a late final was
        retained merely because the control request was queued.  The session
        remains running so normal captions can continue or the owner can
        explicitly cancel it.
        """

        deadline = max(0.05, float(timeout))
        request = _FlushCurrentUtteranceRequest()
        with self._lock:
            if self._state is not LiveCaptionWorkerState.RUNNING:
                raise RuntimeError("live caption worker 未開始或已停止")
        self._audio.put_flush_request(request)
        if not request.done.wait(timeout=deadline):
            raise TimeoutError("live caption answer-end 未能喺限時內完成")
        if request.error is not None:
            raise RuntimeError("live caption answer-end 失敗") from request.error

    def _run(self) -> None:
        failed = False
        try:
            while True:
                if self._cancel_requested:
                    self._publish(self.processor.cancel())
                    break
                if self._forced_stop_failure_pending():
                    failed = True
                    self._publish(
                        self.processor.fail(
                            "即時字幕 ASR 未能喺限時內完成；已釋放本機模型"
                        )
                    )
                    break
                frame = self._audio.get()
                if self._cancel_requested:
                    self._publish(self.processor.cancel())
                    break
                if self._forced_stop_failure_pending():
                    failed = True
                    self._publish(
                        self.processor.fail(
                            "即時字幕 ASR 未能喺限時內完成；已釋放本機模型"
                        )
                    )
                    break
                if frame is None:
                    if self._forced_stop_failure_pending():
                        failed = True
                        self._publish(
                            self.processor.fail(
                                "即時字幕 ASR 未能喺限時內完成；已釋放本機模型"
                            )
                        )
                        break
                    with self._lock:
                        timeline_samples = self._timeline_samples
                    if timeline_samples > self.processor.processed_samples:
                        self._publish(
                            self.processor.skip_to(
                                timeline_samples,
                                reason="bounded_queue_overrun",
                            )
                        )
                    self._publish(self.processor.finish())
                    # Final captions are now drained.  Prepare (but do not
                    # publish) the optional audio receipt while cancellation
                    # can still revoke it before `live.stop` consumes it.
                    self._prepare_timing_archive_for_clean_stop()
                    # Detach the callback before calling it.  It closes over
                    # project metadata, and must not keep a decrypted start
                    # snapshot alive after the clean-stop hand-off.
                    with self._lock:
                        on_clean_stop = (
                            None
                            if (
                                self._cancel_requested
                                or self._forced_stop_failure_requested
                            )
                            else self._on_clean_stop
                        )
                        self._on_clean_stop = None
                    if on_clean_stop is not None:
                        # Snapshot failure must not discard confirmed caption
                        # events or turn a successful local session into a
                        # retry loop. The caller simply receives no update.
                        try:
                            snapshot = on_clean_stop()
                        except Exception:
                            snapshot = None
                        if isinstance(snapshot, dict):
                            with self._lock:
                                # Cancellation can race the snapshot supplier.
                                # A cancelled/error/timeout terminal session
                                # must never retain a persistence payload for
                                # a later RPC.
                                if (
                                    not self._cancel_requested
                                    and not self._forced_stop_failure_requested
                                ):
                                    self._profile_snapshot = dict(snapshot)
                    break
                if isinstance(frame, _FlushCurrentUtteranceRequest):
                    try:
                        self._publish(self.processor.flush_current_utterance())
                    except BaseException as exc:
                        frame.complete(exc)
                        raise
                    frame.complete()
                    continue
                self._publish(
                    self.processor.push_pcm16(
                        frame.data,
                        start_sample=frame.start_sample,
                    )
                )
        except Exception as exc:  # keep a bad local model away from the UI process
            if self._cancel_requested:
                # Closing an in-flight local model is the expected cancellation
                # path. Do not reclassify an explicit privacy cancellation as
                # a model failure merely because the native call was interrupted.
                try:
                    self._publish(self.processor.cancel())
                except Exception:
                    failed = True
            else:
                failed = True
                message = (
                    "即時字幕 ASR 未能喺限時內完成；已釋放本機模型"
                    if self._forced_stop_failure_pending()
                    else str(exc)
                )
                self._publish(self.processor.fail(message))
        finally:
            try:
                self._close_owned_engines()
            except Exception:
                failed = True
            discard_timing_archive = False
            with self._lock:
                # Explicit cancellation wins after a best-effort interrupt;
                # it is still a terminal privacy boundary. A normal stop that
                # crossed its deadline is never reported as `stopped`.
                if self._cancel_requested:
                    self._state = LiveCaptionWorkerState.CANCELLED
                elif failed or self._forced_stop_failure_requested:
                    self._state = LiveCaptionWorkerState.FAILED
                else:
                    self._state = LiveCaptionWorkerState.STOPPED
                if (
                    failed
                    or self._cancel_requested
                    or self._forced_stop_failure_requested
                ):
                    self._profile_snapshot = None
                    discard_timing_archive = True
                # The callback can capture project metadata.  It has either
                # already been consumed above or is ineligible on terminal
                # failure/cancellation; do not retain it in a dead worker.
                self._on_clean_stop = None
            if discard_timing_archive:
                self.discard_timing_archive()

    def stop(self, *, timeout: float = 5.0) -> None:
        with self._lock:
            if self._state in {
                LiveCaptionWorkerState.STOPPED,
                LiveCaptionWorkerState.CANCELLED,
                LiveCaptionWorkerState.FAILED,
            }:
                # ``_run`` can reach STOPPED in the narrow interval before the
                # owning ``live.stop`` RPC calls this method.  Preserve that
                # one-shot clean-stop payload so the *first* normal stop can
                # hand it off.  A duplicate stop is harmless because
                # ``take_profile_snapshot`` consumes it; cancellation and
                # failed terminals remain hard privacy boundaries.
                if self._state is not LiveCaptionWorkerState.STOPPED:
                    self._profile_snapshot = None
                self._on_clean_stop = None
                return
            if self._state is LiveCaptionWorkerState.CREATED:
                raise RuntimeError("live caption worker 未開始")
            if self._state is LiveCaptionWorkerState.RUNNING:
                self._state = LiveCaptionWorkerState.STOPPING
        self._audio.close(discard=False)
        thread = self._thread
        if thread is not None:
            deadline = max(0.05, float(timeout))
            thread.join(timeout=deadline)
            if thread.is_alive():
                if not self._force_close_after_timeout(
                    thread=thread,
                    timeout=deadline,
                    cancelled=False,
                ):
                    raise TimeoutError(
                        "live caption worker 未能喺限時內停止；本機模型釋放仍在進行"
                    )

    def cancel(self, *, timeout: float = 5.0) -> None:
        discard_terminal_archive = False
        with self._lock:
            if self._state in {
                LiveCaptionWorkerState.STOPPED,
                LiveCaptionWorkerState.CANCELLED,
                LiveCaptionWorkerState.FAILED,
            }:
                # Cancellation is a terminal privacy boundary even when the
                # clean stop completed just before this call.  A caller that
                # changes its mind must not leave a profile payload resident.
                self._profile_snapshot = None
                self._on_clean_stop = None
                discard_terminal_archive = True
            elif self._state is LiveCaptionWorkerState.CREATED:
                raise RuntimeError("live caption worker 未開始")
            else:
                self._cancel_requested = True
                self._state = LiveCaptionWorkerState.STOPPING
                # Clear any completed hand-off immediately.  `_run` rechecks this
                # flag before storing a supplier result, covering the callback race.
                self._profile_snapshot = None
                self._on_clean_stop = None
        if discard_terminal_archive:
            self.discard_timing_archive()
            return
        self._audio.close(discard=True)
        self.discard_timing_archive()
        thread = self._thread
        if thread is not None:
            deadline = max(0.05, float(timeout))
            thread.join(timeout=deadline)
            if thread.is_alive():
                if not self._force_close_after_timeout(
                    thread=thread,
                    timeout=deadline,
                    cancelled=True,
                ):
                    raise TimeoutError(
                        "live caption ASR decode 未能喺限時內取消；本機模型釋放仍在進行"
                    )

    def poll_events(self, maximum: int | None = None) -> list[LiveCaptionEvent]:
        if maximum is not None and maximum < 1:
            raise ValueError("maximum 必須大過 0")
        return self._events.drain(maximum)

    def stats(self) -> LiveCaptionStats:
        with self._lock:
            captured = self._accepted_pcm_samples
            dropped = self._dropped_samples
            accepted_frames = self._accepted_frames
            dropped_frames = self._dropped_frames
            emitted = self._emitted_events
        sample_rate = self.processor.config.sample_rate
        return LiveCaptionStats(
            captured_sample_index=captured,
            sample_rate_hz=sample_rate,
            captured_seconds=captured / sample_rate,
            processed_seconds=self.processor.processed_seconds,
            dropped_seconds=dropped / sample_rate,
            accepted_frames=accepted_frames,
            dropped_frames=dropped_frames,
            emitted_events=emitted,
            partial_inferences=self.processor.partial_inferences,
            final_inferences=self.processor.final_inferences,
            maximum_inference_latency_ms=self.processor.maximum_inference_latency_ms,
            pending_audio_seconds=self._audio.pending_bytes / 2 / sample_rate,
        )
