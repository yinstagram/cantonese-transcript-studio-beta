"""Opt-in loopback HTTP API used by Apple Shortcuts and local scripts.

The server is intentionally small: it reuses the running Worker dispatcher and
never exposes a filesystem endpoint.  It binds to 127.0.0.1 only and every
request (including health) requires the per-install token.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import stat
import threading
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import unquote, urlparse

from .jobs import present_job

logger = logging.getLogger(__name__)
MAX_BODY_BYTES = 128 * 1024
MAX_EXPORT_BYTES = 32 * 1024 * 1024
EXPORT_STREAM_CHUNK_BYTES = 256 * 1024
MAX_CONCURRENT_REQUESTS = 8
REQUEST_SOCKET_TIMEOUT_SECONDS = 10.0
ALLOWED_EXPORTS = {
    "txt": ("text/plain; charset=utf-8", "utf-8"),
    "timestamp_txt": ("text/plain; charset=utf-8", "utf-8"),
    "srt": ("application/x-subrip; charset=utf-8", "utf-8"),
    "vtt": ("text/vtt; charset=utf-8", "utf-8"),
    "json": ("application/json; charset=utf-8", "utf-8"),
    "csv": ("text/csv; charset=utf-8", "utf-8"),
}


def new_token() -> str:
    return secrets.token_urlsafe(32)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._request_slots = threading.BoundedSemaphore(MAX_CONCURRENT_REQUESTS)
        super().__init__(*args, **kwargs)

    def process_request(self, request: Any, client_address: Any) -> None:
        if not self._request_slots.acquire(blocking=False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._request_slots.release()
            raise

    def process_request_thread(self, request: Any, client_address: Any) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._request_slots.release()


def _open_verified_export(workspace: Path, export_path: str) -> tuple[int, int]:
    """Open a regular export under workspace without following any symlink."""

    root = workspace.expanduser().resolve(strict=True)
    raw = Path(export_path).expanduser()
    if not raw.is_absolute():
        raise ValueError("export path 必須係 absolute path")
    normalized = Path(os.path.abspath(raw))
    try:
        relative = normalized.relative_to(root)
    except ValueError as exc:
        raise ValueError("export 檔案超出工作目錄") from exc
    if not relative.parts or any(part in {"", ".", ".."} for part in relative.parts):
        raise ValueError("export path 無效")

    directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    file_flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    descriptor = os.open(root, directory_flags)
    try:
        for component in relative.parts[:-1]:
            child = os.open(component, directory_flags, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        file_descriptor = os.open(relative.parts[-1], file_flags, dir_fd=descriptor)
    finally:
        os.close(descriptor)
    try:
        file_stat = os.fstat(file_descriptor)
        if not stat.S_ISREG(file_stat.st_mode) or file_stat.st_size > MAX_EXPORT_BYTES:
            raise ValueError("export 檔案無效")
        return file_descriptor, int(file_stat.st_size)
    except BaseException:
        os.close(file_descriptor)
        raise


class LocalAPIServer:
    def __init__(self, worker: Any, *, host: str, port: int, token: str, status_path: Path) -> None:
        if host not in {"127.0.0.1", "localhost"}:
            raise ValueError("Local API 只可以綁定本機 loopback")
        if not token:
            raise ValueError("Local API token 唔可以留空")
        self.worker = worker
        self.host = "127.0.0.1"
        self.requested_port = port
        self.token = token
        self.status_path = status_path
        self.httpd: _Server | None = None
        self.thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return self.httpd is not None and self.thread is not None and self.thread.is_alive()

    @property
    def port(self) -> int | None:
        return self.httpd.server_port if self.httpd is not None else None

    def info(self, *, enabled: bool | None = None) -> dict[str, Any]:
        is_enabled = self.running if enabled is None else enabled
        return {
            "enabled": is_enabled,
            "host": self.host,
            "port": self.port or self.requested_port,
            "base_url": f"http://{self.host}:{self.port or self.requested_port}/v1",
            "status_path": str(self.status_path),
            "token_header": "X-CTS-Token",
        }

    def _write_status(self, enabled: bool) -> None:
        self.status_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {**self.info(enabled=enabled), "token": self.token if enabled else None, "updated_at": _now()}
        temporary = self.status_path.with_name(f".{self.status_path.name}.{secrets.token_hex(4)}")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        temporary.chmod(0o600)
        temporary.replace(self.status_path)
        self.status_path.chmod(0o600)

    def start(self) -> dict[str, Any]:
        if self.running:
            return self.info()
        server = _Server((self.host, self.requested_port), self._handler())
        self.httpd = server
        self.thread = threading.Thread(target=server.serve_forever, name="cts-local-api", daemon=True)
        self.thread.start()
        self._write_status(True)
        logger.info("Local API listening at %s", self.info()["base_url"])
        return self.info()

    def stop(self) -> None:
        server, thread = self.httpd, self.thread
        self.httpd = None
        self.thread = None
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=3)
        try:
            self._write_status(False)
        except OSError:
            logger.exception("Unable to write Local API disabled status")

    def _handler(self) -> type[BaseHTTPRequestHandler]:
        server_ref = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def setup(self) -> None:
                super().setup()
                self.connection.settimeout(REQUEST_SOCKET_TIMEOUT_SECONDS)

            def log_message(self, format: str, *args: Any) -> None:
                logger.info("local-api %s", format % args)

            def _authorized(self) -> bool:
                token = self.headers.get("X-CTS-Token", "")
                if not token:
                    auth = self.headers.get("Authorization", "")
                    if auth.startswith("Bearer "):
                        token = auth[7:].strip()
                return secrets.compare_digest(token, server_ref.token)

            def _send(self, status: int, body: bytes, content_type: str) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Connection", "close")
                self.end_headers()
                self.wfile.write(body)

            def _json(self, status: int, value: Any) -> None:
                body = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                self._send(status, body, "application/json; charset=utf-8")

            def _send_export(self, descriptor: int, size: int, content_type: str) -> None:
                try:
                    with os.fdopen(descriptor, "rb", closefd=True) as handle:
                        self.send_response(HTTPStatus.OK)
                        self.send_header("Content-Type", content_type)
                        self.send_header("Content-Length", str(size))
                        self.send_header("Cache-Control", "no-store")
                        self.send_header("Connection", "close")
                        self.end_headers()
                        while block := handle.read(EXPORT_STREAM_CHUNK_BYTES):
                            self.wfile.write(block)
                except (BrokenPipeError, ConnectionResetError, TimeoutError, OSError):
                    self.close_connection = True

            def _error(self, status: int, message: str) -> None:
                self._json(status, {"error": {"message": message}})

            def _read_json(self) -> dict[str, Any]:
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                except ValueError as exc:
                    raise ValueError("Content-Length 無效") from exc
                if length < 0 or length > MAX_BODY_BYTES:
                    raise ValueError("request body 太大")
                raw = self.rfile.read(length)
                value = json.loads(raw.decode("utf-8") or "{}")
                if not isinstance(value, dict):
                    raise ValueError("JSON body 必須係 object")
                return value

            def _dispatch(self, method: str, params: dict[str, Any]) -> Any:
                return server_ref.worker.dispatcher.dispatch(method, params)

            def _job_id_and_tail(self) -> tuple[str | None, list[str]]:
                parts = [unquote(item) for item in urlparse(self.path).path.split("/") if item]
                if len(parts) < 3 or parts[:2] != ["v1", "jobs"]:
                    return None, []
                job_id = parts[2]
                if Path(job_id).name != job_id or job_id in {".", ".."}:
                    return None, []
                return job_id, parts[3:]

            def do_GET(self) -> None:  # noqa: N802
                if not self._authorized():
                    self._error(HTTPStatus.UNAUTHORIZED, "需要 X-CTS-Token")
                    return
                path = urlparse(self.path).path.rstrip("/")
                try:
                    if path == "/v1/health":
                        self._json(HTTPStatus.OK, {**server_ref.worker._health({}), "local_api": server_ref.info()})
                        return
                    if path == "/v1/jobs":
                        self._json(HTTPStatus.OK, self._dispatch("jobs.list", {}))
                        return
                    job_id, tail = self._job_id_and_tail()
                    if job_id is None:
                        self._error(HTTPStatus.NOT_FOUND, "搵唔到 API 路徑")
                        return
                    if tail[:1] == ["export"] and len(tail) == 2:
                        extension = tail[1].lower()
                        if extension not in ALLOWED_EXPORTS:
                            self._error(HTTPStatus.NOT_FOUND, "不支援呢種 export")
                            return
                        job = self._dispatch("jobs.get", {"id": job_id})
                        export_path = (job.get("exports") or {}).get(extension)
                        if not isinstance(export_path, str):
                            self._error(HTTPStatus.NOT_FOUND, "呢份 export 未準備好")
                            return
                        workspace = Path(str(job.get("workspace_path") or ""))
                        descriptor, size = _open_verified_export(workspace, export_path)
                        self._send_export(descriptor, size, ALLOWED_EXPORTS[extension][0])
                        return
                    self._json(HTTPStatus.OK, self._dispatch("jobs.get", {"id": job_id}))
                except KeyError:
                    self._error(HTTPStatus.NOT_FOUND, "搵唔到呢份工作")
                except (OSError, ValueError) as exc:
                    self._error(HTTPStatus.BAD_REQUEST, str(exc))
                except Exception:
                    logger.exception("Local API GET failed")
                    self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "本機處理失敗")

            def do_POST(self) -> None:  # noqa: N802
                if not self._authorized():
                    self._error(HTTPStatus.UNAUTHORIZED, "需要 X-CTS-Token")
                    return
                path = urlparse(self.path).path.rstrip("/")
                try:
                    body = self._read_json()
                    if path == "/v1/jobs":
                        created = self._dispatch("jobs.create", body)
                        if body.get("auto_start", True):
                            # Starting from an HTTP worker thread must not synchronously
                            # write a UI event to the Swift protocol pipe.  A paused UI
                            # reader could otherwise hold this request open indefinitely;
                            # the API client polls the job resource for progress instead.
                            created = self._dispatch(
                                "jobs.start",
                                {"id": created["id"], "_suppress_event": True},
                            )
                        self._json(HTTPStatus.ACCEPTED, {"job": created})
                        return
                    job_id, tail = self._job_id_and_tail()
                    if job_id is None or len(tail) != 1 or tail[0] not in {"cancel", "retry"}:
                        self._error(HTTPStatus.NOT_FOUND, "搵唔到 API 路徑")
                        return
                    method = "jobs.cancel" if tail[0] == "cancel" else "jobs.retry"
                    self._json(HTTPStatus.OK, {"job": self._dispatch(method, {"id": job_id})})
                except KeyError:
                    self._error(HTTPStatus.NOT_FOUND, "搵唔到呢份工作")
                except ValueError as exc:
                    self._error(HTTPStatus.BAD_REQUEST, str(exc))
                except Exception:
                    logger.exception("Local API POST failed")
                    self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "本機處理失敗")

        return Handler


__all__ = ["LocalAPIServer", "new_token"]
