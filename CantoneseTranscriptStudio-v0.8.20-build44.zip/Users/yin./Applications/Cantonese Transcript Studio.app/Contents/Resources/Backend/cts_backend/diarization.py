"""Offline speaker diarization and deterministic transcript speaker assignment.

The diarizer deliberately returns anonymous, stable labels (``Speaker 1`` etc.).
It never attempts to infer a person's real identity.  sherpa-onnx performs the
segmentation, speaker embedding and clustering locally on CPU.
"""

from __future__ import annotations

import gc
import hashlib
import json
import math
import os
import signal
import subprocess
import threading
import time
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]


class DiarizationError(RuntimeError):
    pass


class DiarizationCancelled(DiarizationError):
    pass


SORTFORMER_HELPER_POLICY_VERSION = "cts-sortformer-subprocess-v1"
SORTFORMER_HELPER_NAME = "CTSSpeakerDiarizer"
SORTFORMER_MODEL_BUNDLE_NAME = "SortformerNvidiaHigh_v2.1.mlmodelc"
SORTFORMER_MAX_OUTPUT_BYTES = 32 * 1024 * 1024
SORTFORMER_MAX_PROGRESS_BYTES = 64 * 1024
SORTFORMER_MAX_LOG_BYTES = 64 * 1024


@dataclass(frozen=True)
class SpeakerTurn:
    start_ms: int
    end_ms: int
    speaker_index: int

    def __post_init__(self) -> None:
        if self.start_ms < 0 or self.end_ms <= self.start_ms:
            raise ValueError("speaker turn timestamps must be positive and ordered")
        if self.speaker_index < 0:
            raise ValueError("speaker index must be non-negative")

    @property
    def speaker_id(self) -> str:
        return f"speaker-{self.speaker_index + 1}"

    @property
    def label(self) -> str:
        return f"Speaker {self.speaker_index + 1}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "start_ms": self.start_ms,
            "end_ms": self.end_ms,
            "start": round(self.start_ms / 1000, 3),
            "end": round(self.end_ms / 1000, 3),
            "speaker_index": self.speaker_index,
            "speaker_id": self.speaker_id,
            "speaker_label": self.label,
        }


def _sha256_regular_file(path: Path) -> str:
    if path.is_symlink() or not path.is_file():
        raise DiarizationError(f"檔案不存在或唔安全：{path}")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _canonical_existing(path: Path, *, directory: bool, label: str) -> Path:
    value = Path(path).expanduser()
    if not value.is_absolute():
        raise DiarizationError(f"{label} 必須係 absolute path")
    try:
        resolved = value.resolve(strict=True)
    except OSError as exc:
        raise DiarizationError(f"{label} 不存在：{value}") from exc
    if resolved != value:
        raise DiarizationError(f"{label} 不允許 symlink 或非 canonical path：{value}")
    if directory and not value.is_dir():
        raise DiarizationError(f"{label} 唔係目錄：{value}")
    if not directory and not value.is_file():
        raise DiarizationError(f"{label} 唔係 regular file：{value}")
    return value


def _bundled_sortformer_helper() -> Path:
    # A normal packaged worker imports this module from
    # ``Contents/Resources/Backend``.  Local hotfix builds intentionally load
    # Python from an Application Support override while retaining the signed
    # app bundle as the worker's current directory.  Looking only at
    # ``__file__`` therefore made the real helper invisible and every
    # diarization-enabled job failed after ASR at roughly 90%.
    locations = [Path(__file__).resolve()]
    try:
        locations.append(Path.cwd().resolve(strict=True))
    except OSError:
        pass
    visited: set[Path] = set()
    for location in locations:
        for parent in location.parents:
            if parent in visited or parent.name != "Contents":
                continue
            visited.add(parent)
            candidate = parent / "MacOS" / SORTFORMER_HELPER_NAME
            if candidate.is_file():
                return _canonical_existing(
                    candidate,
                    directory=False,
                    label="Sortformer helper",
                )
    raise DiarizationError(
        "Sortformer 本機 helper 未安裝；請重新 build／安裝 Cantonese Transcript Studio"
    )


def _read_bounded_json(path: Path, *, maximum_bytes: int, label: str) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise DiarizationError(f"{label} 不存在或唔安全")
    size = path.stat(follow_symlinks=False).st_size
    if size <= 0 or size > maximum_bytes:
        raise DiarizationError(f"{label} 大小無效或超出安全上限")
    try:
        with path.open("rb") as stream:
            raw = stream.read(maximum_bytes + 1)
        if len(raw) > maximum_bytes:
            raise DiarizationError(f"{label} 超出安全上限")
        value = json.loads(raw)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DiarizationError(f"{label} JSON 無效") from exc
    if not isinstance(value, dict):
        raise DiarizationError(f"{label} 必須係 JSON object")
    return value


class _BoundedProcessOutput:
    def __init__(self, maximum_bytes: int) -> None:
        self.maximum_bytes = maximum_bytes
        self._value = bytearray()
        self._lock = threading.Lock()

    def drain(self, stream: Any) -> None:
        try:
            while block := stream.read(8192):
                with self._lock:
                    self._value.extend(block)
                    overflow = len(self._value) - self.maximum_bytes
                    if overflow > 0:
                        del self._value[:overflow]
        finally:
            try:
                stream.close()
            except OSError:
                pass

    def bytes(self) -> bytes:
        with self._lock:
            return bytes(self._value)


def _terminate_process_group(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=2.0)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        pass


def _write_bounded_log(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    try:
        temporary.write_bytes(value[-SORTFORMER_MAX_LOG_BYTES:])
        os.replace(temporary, path)
    except BaseException:
        # Preserve a failed app-owned write for diagnosis without touching any
        # source audio/model file.
        if temporary.exists():
            failed = temporary.with_name(f".failed-{temporary.name}")
            try:
                os.replace(temporary, failed)
            except OSError:
                pass
        raise


class SortformerCoreMLDiarizer:
    """Run the bundled Swift/Core ML Sortformer helper fully offline.

    FluidAudio's high-context Sortformer has four fixed anonymous slots.  The
    helper streams bounded AVAudioFile chunks and retains its speaker cache for
    the full recording; Python supervises it in a new process group so cancel
    and timeout cannot leave a Core ML child behind.
    """

    policy_version = SORTFORMER_HELPER_POLICY_VERSION

    def __init__(
        self,
        model_path: Path,
        *,
        helper_path: Path | None = None,
        run_directory: Path | None = None,
        expected_speakers: int | None = None,
        timeout_seconds: float | None = None,
    ) -> None:
        self.model_path = _canonical_existing(
            Path(model_path), directory=True, label="Sortformer CoreML model"
        )
        if self.model_path.name != SORTFORMER_MODEL_BUNDLE_NAME:
            raise DiarizationError("Sortformer CoreML model bundle 名稱不符")
        self.helper_path = (
            _canonical_existing(Path(helper_path), directory=False, label="Sortformer helper")
            if helper_path is not None
            else _bundled_sortformer_helper()
        )
        if not os.access(self.helper_path, os.X_OK):
            raise DiarizationError("Sortformer helper 無執行權限；請重新安裝 App")
        self.helper_sha256 = _sha256_regular_file(self.helper_path)
        self.run_directory = Path(run_directory) if run_directory is not None else None
        if expected_speakers is not None and (
            isinstance(expected_speakers, bool) or not 1 <= expected_speakers <= 4
        ):
            raise ValueError("Sortformer expected_speakers 必須係 1 至 4 或留空")
        if timeout_seconds is not None and (
            not math.isfinite(timeout_seconds) or timeout_seconds <= 0
        ):
            raise ValueError("Sortformer timeout_seconds 必須係正數")
        self.expected_speakers = expected_speakers
        self.timeout_seconds = timeout_seconds
        self.last_diagnostics: dict[str, Any] = {}

    @staticmethod
    def _wav_duration(path: Path) -> tuple[int, float]:
        try:
            with wave.open(str(path), "rb") as stream:
                if (
                    stream.getnchannels() != 1
                    or stream.getsampwidth() != 2
                    or stream.getframerate() != 16_000
                    or stream.getcomptype() != "NONE"
                    or stream.getnframes() <= 0
                ):
                    raise DiarizationError("Sortformer 音訊必須係 16kHz mono PCM16 WAV")
                frames = int(stream.getnframes())
        except (EOFError, OSError, wave.Error) as exc:
            raise DiarizationError("Sortformer 音訊不是有效 WAV") from exc
        return frames, frames / 16_000

    def _validate_output(
        self,
        value: dict[str, Any],
        *,
        duration_ms: int,
    ) -> tuple[tuple[SpeakerTurn, ...], dict[str, Any]]:
        required = {
            "schema",
            "engine",
            "policy_version",
            "model_name",
            "compute_units",
            "duration_ms",
            "padded_silence_ms",
            "frame_duration_ms",
            "num_speakers",
            "turns",
        }
        if set(value) != required:
            raise DiarizationError("Sortformer output JSON fields 不符固定 schema")
        if (
            value.get("schema") != 1
            or value.get("engine")
            != "FluidAudio Sortformer streaming high-context v2.1 palettized"
            or value.get("policy_version") != "cts-sortformer-streaming-v2"
            or value.get("model_name") != SORTFORMER_MODEL_BUNDLE_NAME
            or value.get("compute_units") != "cpuAndGPU"
            or value.get("frame_duration_ms") != 80
            or value.get("duration_ms") != duration_ms
        ):
            raise DiarizationError("Sortformer output metadata 同固定 runtime 不符")
        padding = value.get("padded_silence_ms")
        if isinstance(padding, bool) or not isinstance(padding, int) or not 0 <= padding <= 30_500:
            raise DiarizationError("Sortformer short-input padding audit 無效")
        raw_count = value.get("num_speakers")
        raw_turns = value.get("turns")
        if (
            isinstance(raw_count, bool)
            or not isinstance(raw_count, int)
            or not 0 <= raw_count <= 4
            or not isinstance(raw_turns, list)
        ):
            raise DiarizationError("Sortformer speaker count／turns 無效")
        maximum_turns = (duration_ms // 80 + 2) * 4
        if len(raw_turns) > maximum_turns:
            raise DiarizationError("Sortformer turn count 超出音訊長度安全上限")
        turns: list[SpeakerTurn] = []
        previous: tuple[int, int, int] | None = None
        for item in raw_turns:
            if not isinstance(item, dict) or set(item) != {
                "start_ms", "end_ms", "speaker_index", "activity"
            }:
                raise DiarizationError("Sortformer turn schema 無效")
            start = item.get("start_ms")
            end = item.get("end_ms")
            speaker = item.get("speaker_index")
            activity = item.get("activity")
            if (
                isinstance(start, bool)
                or not isinstance(start, int)
                or isinstance(end, bool)
                or not isinstance(end, int)
                or isinstance(speaker, bool)
                or not isinstance(speaker, int)
                or not isinstance(activity, (int, float))
                or isinstance(activity, bool)
                or not math.isfinite(float(activity))
                or not 0.0 <= float(activity) <= 1.0
                or not 0 <= start < end <= duration_ms
                or not 0 <= speaker < 4
            ):
                raise DiarizationError("Sortformer turn 值超出固定範圍")
            order = (start, end, speaker)
            if previous is not None and order < previous:
                raise DiarizationError("Sortformer turns 未按時間排序")
            previous = order
            turns.append(SpeakerTurn(start, end, speaker))
        observed = sorted({turn.speaker_index for turn in turns})
        if observed != list(range(len(observed))) or raw_count != len(observed):
            raise DiarizationError("Sortformer anonymous speaker labels 唔連續或 count 不符")

        suppressed_ids: list[int] = []
        suppressed_turn_count = 0
        suppressed_speech_ms = 0
        automatic_quarantine_threshold_ms: int | None = None
        suppression_reason = "none"
        if self.expected_speakers is not None and len(observed) > self.expected_speakers:
            statistics = {
                speaker: (
                    sum(
                        turn.end_ms - turn.start_ms
                        for turn in turns
                        if turn.speaker_index == speaker
                    ),
                    min(
                        turn.start_ms
                        for turn in turns
                        if turn.speaker_index == speaker
                    ),
                )
                for speaker in observed
            }
            keep = set(
                sorted(
                    observed,
                    key=lambda speaker: (
                        -statistics[speaker][0], statistics[speaker][1], speaker
                    ),
                )[: self.expected_speakers]
            )
            suppressed_ids = sorted(set(observed) - keep)
            suppression_reason = "explicit_expected_speaker_count"
        elif self.expected_speakers is None and len(observed) > 1:
            # The four fixed Sortformer slots can occasionally emit one or two
            # sub-second transient identities.  In automatic mode, quarantine
            # only identities with both very little total speech and no more
            # than two turns.  This is precision-first: omitted evidence stays
            # auditable and is never merge-guessed into a named speaker.
            automatic_quarantine_threshold_ms = min(
                2_000,
                max(800, round(duration_ms * 0.005)),
            )
            statistics = {
                speaker: {
                    "speech_ms": sum(
                        turn.end_ms - turn.start_ms
                        for turn in turns
                        if turn.speaker_index == speaker
                    ),
                    "turn_count": sum(
                        1 for turn in turns if turn.speaker_index == speaker
                    ),
                }
                for speaker in observed
            }
            candidates = {
                speaker
                for speaker, item in statistics.items()
                if item["turn_count"] <= 2
                and item["speech_ms"] < automatic_quarantine_threshold_ms
            }
            if len(candidates) == len(observed):
                keep_one = max(
                    observed,
                    key=lambda speaker: (
                        statistics[speaker]["speech_ms"],
                        statistics[speaker]["turn_count"],
                        -speaker,
                    ),
                )
                candidates.discard(keep_one)
            suppressed_ids = sorted(candidates)
            if suppressed_ids:
                suppression_reason = "automatic_transient_identity_quarantine"

        if suppressed_ids:
            suppressed_turns = [
                turn for turn in turns if turn.speaker_index in set(suppressed_ids)
            ]
            suppressed_turn_count = len(suppressed_turns)
            suppressed_speech_ms = sum(
                turn.end_ms - turn.start_ms for turn in suppressed_turns
            )
            # Never expose a quarantined transient as a stable speaker label.
            suppressed_set = set(suppressed_ids)
            turns = [
                turn for turn in turns if turn.speaker_index not in suppressed_set
            ]
        normalized = normalize_turns(turns)
        diagnostics = {
            "engine": "fluid_audio_sortformer_coreml",
            "policy_version": self.policy_version,
            "model_variant": "highContextV2_1",
            "model_precision": "palettized",
            "compute_units": "cpuAndGPU",
            "fixed_speaker_slots": 4,
            "raw_num_speakers": raw_count,
            "requested_num_speakers": self.expected_speakers,
            "final_num_speakers": len({turn.speaker_index for turn in normalized}),
            "extra_speaker_policy": "omit_to_unknown_never_merge_guess",
            "suppressed_source_speaker_indices": suppressed_ids,
            "suppressed_turn_count": suppressed_turn_count,
            "suppressed_speech_ms": suppressed_speech_ms,
            "suppression_reason": suppression_reason,
            "automatic_quarantine_threshold_ms": automatic_quarantine_threshold_ms,
            "short_input_padded_silence_ms": padding,
            "automatic_labels_usable": bool(normalized),
            "anonymous_labels": True,
        }
        return normalized, diagnostics

    def diarize_wav(
        self,
        audio_path: Path,
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> tuple[SpeakerTurn, ...]:
        audio = _canonical_existing(Path(audio_path), directory=False, label="Sortformer WAV")
        frames, duration_seconds = self._wav_duration(audio)
        duration_ms = round(duration_seconds * 1000)
        if cancelled and cancelled():
            raise DiarizationCancelled("已取消 speaker diarization")
        run_directory = self.run_directory or (audio.parent / "sortformer-helper")
        run_directory = Path(run_directory).expanduser()
        if not run_directory.is_absolute():
            raise DiarizationError("Sortformer run directory 必須係 absolute path")
        run_directory.mkdir(parents=True, exist_ok=True)
        run_directory = _canonical_existing(
            run_directory, directory=True, label="Sortformer run directory"
        )
        output_path = run_directory / "result.json"
        progress_path = run_directory / "progress.json"
        log_path = run_directory / "helper.log"
        for stale in (output_path, progress_path):
            if stale.exists() or stale.is_symlink():
                if stale.is_symlink() or not stale.is_file():
                    raise DiarizationError(f"Sortformer app-owned output path 唔安全：{stale}")
                os.replace(
                    stale,
                    stale.with_name(f".{stale.name}.stale-{time.time_ns()}"),
                )
        command = [
            str(self.helper_path),
            "--input", str(audio),
            "--model", str(self.model_path),
            "--output", str(output_path),
            "--progress", str(progress_path),
        ]
        environment = dict(os.environ)
        environment.update(
            {
                "HF_HUB_OFFLINE": "1",
                "TRANSFORMERS_OFFLINE": "1",
                "TOKENIZERS_PARALLELISM": "false",
            }
        )
        tail = _BoundedProcessOutput(SORTFORMER_MAX_LOG_BYTES)
        try:
            process = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                env=environment,
            )
        except OSError as exc:
            raise DiarizationError("無法啟動 Sortformer 本機 helper；請重新安裝 App") from exc
        assert process.stdout is not None
        reader = threading.Thread(target=tail.drain, args=(process.stdout,), daemon=True)
        reader.start()
        timeout = self.timeout_seconds or max(180.0, duration_seconds * 0.25 + 120.0)
        started = time.monotonic()
        last_progress = -1.0
        cancelled_run = False
        timed_out = False
        try:
            while process.poll() is None:
                if cancelled and cancelled():
                    cancelled_run = True
                    _terminate_process_group(process)
                    break
                if time.monotonic() - started > timeout:
                    timed_out = True
                    _terminate_process_group(process)
                    break
                if progress_path.is_file() and not progress_path.is_symlink():
                    try:
                        event = _read_bounded_json(
                            progress_path,
                            maximum_bytes=SORTFORMER_MAX_PROGRESS_BYTES,
                            label="Sortformer progress",
                        )
                        current = float(event.get("progress", -1))
                        if math.isfinite(current) and last_progress <= current <= 1.0:
                            if progress is not None and current > last_progress:
                                progress(
                                    {
                                        "phase": "speaker_diarization",
                                        "engine": "fluid_audio_sortformer_coreml",
                                        "progress": current,
                                        "processed_frames": event.get("processed_frames"),
                                        "total_frames": event.get("total_frames", frames),
                                    }
                                )
                            last_progress = current
                    except (DiarizationError, TypeError, ValueError):
                        # Atomic progress can be absent between renames; the
                        # final result remains strict and authoritative.
                        pass
                time.sleep(0.05)
            return_code = process.wait(timeout=2.0)
        finally:
            if process.poll() is None:
                _terminate_process_group(process)
            reader.join(timeout=2.0)
            _write_bounded_log(log_path, tail.bytes())
        if cancelled_run:
            raise DiarizationCancelled("已取消 speaker diarization；helper process group 已停止")
        if timed_out:
            raise DiarizationError(
                f"Sortformer speaker diarization 超時（{timeout:.0f} 秒）；請重試或檢查系統資源"
            )
        if return_code != 0:
            message = tail.bytes().decode("utf-8", errors="replace").strip()
            if len(message) > 500:
                message = message[-500:]
            raise DiarizationError(
                "Sortformer 本機 helper 執行失敗"
                + (f"：{message}" if message else "；請查看 helper.log")
            )
        value = _read_bounded_json(
            output_path,
            maximum_bytes=SORTFORMER_MAX_OUTPUT_BYTES,
            label="Sortformer result",
        )
        turns, diagnostics = self._validate_output(value, duration_ms=duration_ms)
        self.last_diagnostics = {
            **diagnostics,
            "helper_sha256": self.helper_sha256,
            "runtime_seconds": round(time.monotonic() - started, 3),
            "timeout_seconds": round(timeout, 3),
            "result_bytes": output_path.stat().st_size,
            "log_bytes_retained": len(tail.bytes()),
        }
        if progress is not None and last_progress < 1.0:
            progress(
                {
                    "phase": "speaker_diarization",
                    "engine": "fluid_audio_sortformer_coreml",
                    "progress": 1.0,
                    "processed_frames": frames,
                    "total_frames": frames,
                }
            )
        return turns


def _speaker_order(turns: Iterable[SpeakerTurn]) -> dict[int, int]:
    """Map engine cluster ids to first-appearance ids for stable output."""
    order: dict[int, int] = {}
    for turn in sorted(turns, key=lambda item: (item.start_ms, item.end_ms, item.speaker_index)):
        if turn.speaker_index not in order:
            order[turn.speaker_index] = len(order)
    return order


def normalize_turns(turns: Iterable[SpeakerTurn]) -> tuple[SpeakerTurn, ...]:
    raw = tuple(turns)
    order = _speaker_order(raw)
    return tuple(
        SpeakerTurn(item.start_ms, item.end_ms, order[item.speaker_index])
        for item in sorted(raw, key=lambda value: (value.start_ms, value.end_ms, value.speaker_index))
    )


def _overlap_ms(start_ms: int, end_ms: int, turn: SpeakerTurn) -> int:
    return max(0, min(end_ms, turn.end_ms) - max(start_ms, turn.start_ms))


def assign_speakers(
    segments: Iterable[Any],
    turns: Iterable[SpeakerTurn],
    *,
    max_nearest_gap_ms: int = 750,
) -> tuple[dict[str, Any], ...]:
    """Return per-segment speaker metadata using maximum temporal overlap.

    Overlapping turns are preserved in ``speaker_labels``.  ``speaker_label``
    is the dominant speaker for convenient UI/export display, or ``Unknown``
    when there is no reliable nearby turn.
    """
    normalized = normalize_turns(turns)
    result: list[dict[str, Any]] = []
    for segment in segments:
        if isinstance(segment, dict):
            start = int(segment.get("start_ms", 0))
            end = int(segment.get("end_ms", start))
        else:
            start = int(getattr(segment, "start_ms", 0))
            end = int(getattr(segment, "end_ms", start))
        overlaps: dict[int, int] = {}
        for turn in normalized:
            overlap = _overlap_ms(start, end, turn)
            if overlap:
                overlaps[turn.speaker_index] = overlaps.get(turn.speaker_index, 0) + overlap
        if overlaps:
            ranked = sorted(overlaps.items(), key=lambda item: (-item[1], item[0]))
            labels = [f"Speaker {index + 1}" for index, _ in ranked]
            dominant, overlap = ranked[0]
            result.append(
                {
                    "speaker_index": dominant,
                    "speaker_id": f"speaker-{dominant + 1}",
                    # The normal UI/export label is always the dominant person.
                    # Keep every overlapping label separately for advanced
                    # audit; joining them here made a long coarse ASR segment
                    # look as if several people spoke every subtitle cue.
                    "speaker_label": labels[0],
                    "speaker_labels": labels,
                    "speaker_overlap_ms": overlap,
                    "speaker_overlap_ratio": round(overlap / max(1, end - start), 4),
                    "speaker_overlap": len(labels) > 1,
                    "diarization_reason": "maximum temporal overlap",
                }
            )
            continue
        nearest = min(
            normalized,
            key=lambda turn: min(abs(start - turn.end_ms), abs(turn.start_ms - end)),
            default=None,
        )
        distance = (
            min(abs(start - nearest.end_ms), abs(nearest.start_ms - end))
            if nearest is not None
            else None
        )
        if nearest is not None and distance is not None and distance <= max_nearest_gap_ms:
            result.append(
                {
                    "speaker_index": nearest.speaker_index,
                    "speaker_id": nearest.speaker_id,
                    "speaker_label": nearest.label,
                    "speaker_labels": [nearest.label],
                    "speaker_overlap_ms": 0,
                    "speaker_overlap_ratio": 0.0,
                    "speaker_overlap": False,
                    "diarization_reason": "nearest turn within tolerance",
                }
            )
        else:
            result.append(
                {
                    "speaker_index": None,
                    "speaker_id": None,
                    "speaker_label": "Unknown",
                    "speaker_labels": [],
                    "speaker_overlap_ms": 0,
                    "speaker_overlap_ratio": 0.0,
                    "speaker_overlap": False,
                    "diarization_reason": "no reliable temporal match",
                }
            )
    return tuple(result)


class _WindowedPCM16Wav:
    """Read normalized float32 windows from a disk-backed PCM16 WAV.

    Conversion to float32 only happens for the requested window, avoiding the
    full-recording ``astype`` allocation which previously consumed about
    460.8 MB for a two-hour 16 kHz mono recording.  ``pread`` is intentional:
    a whole-file mmap remained virtually cheap but macOS counted all touched
    pages in process RSS during a sequential two-hour scan.
    """

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._handle: Any | None = None
        try:
            stream = wave.open(str(self.path), "rb")
        except (EOFError, OSError, wave.Error) as exc:
            raise DiarizationError("diarization 音訊不是有效 WAV") from exc
        try:
            if (
                stream.getnchannels() != 1
                or stream.getsampwidth() != 2
                or stream.getframerate() != 16000
                or stream.getcomptype() != "NONE"
            ):
                raise DiarizationError("diarization 音訊必須係 16kHz mono PCM16 WAV")
            self.frames = int(stream.getnframes())
            self.sample_rate = int(stream.getframerate())
            # ``Wave_read._data_chunk.offset`` is relative to the RIFF payload;
            # the outer RIFF chunk starts after its 8-byte header.  Seeking the
            # chunk and reading the underlying file position avoids assuming a
            # canonical 44-byte WAV header (FFmpeg may include extra chunks).
            stream.setpos(0)
            stream.readframes(0)
            data_file = stream._data_chunk.file  # type: ignore[attr-defined]
            while hasattr(data_file, "file"):
                data_file = data_file.file
            self.data_offset = int(data_file.tell())
        finally:
            stream.close()
        try:
            self._handle = self.path.open("rb", buffering=0)
            payload_end = self.data_offset + self.frames * 2
            if payload_end > self.path.stat().st_size:
                raise DiarizationError("diarization WAV PCM payload 不完整")
        except BaseException:
            self.close()
            raise

    @property
    def duration_seconds(self) -> float:
        return self.frames / self.sample_rate

    def read_float32(self, start_frame: int, end_frame: int) -> Any:
        if self._handle is None:
            raise DiarizationError("diarization WAV reader 已關閉")
        if start_frame < 0 or end_frame < start_frame or end_frame > self.frames:
            raise ValueError("WAV window frame range is invalid")
        try:
            import numpy as np
        except ImportError as exc:
            raise DiarizationError("runtime 未安裝 numpy") from exc
        byte_count = (end_frame - start_frame) * 2
        raw = os.pread(
            self._handle.fileno(),
            byte_count,
            self.data_offset + start_frame * 2,
        )
        if len(raw) != byte_count:
            raise DiarizationError("diarization WAV PCM window 不完整")
        samples = np.frombuffer(raw, dtype="<i2").astype(np.float32)
        samples *= 1.0 / 32768.0
        return samples

    def close(self) -> None:
        handle = self._handle
        self._handle = None
        if handle is not None:
            handle.close()

    def __enter__(self) -> "_WindowedPCM16Wav":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _wav_memmap(path: Path) -> _WindowedPCM16Wav:
    """Legacy name: return a bounded disk reader with no full float32 copy."""
    return _WindowedPCM16Wav(path)


def _window_ranges(
    total_frames: int,
    *,
    window_frames: int,
    overlap_frames: int,
) -> tuple[tuple[int, int], ...]:
    if total_frames < 0 or window_frames <= 0:
        raise ValueError("invalid diarization window length")
    if overlap_frames < 0 or overlap_frames >= window_frames:
        raise ValueError("diarization overlap must be shorter than the window")
    if total_frames == 0:
        return ()
    values: list[tuple[int, int]] = []
    step = window_frames - overlap_frames
    start = 0
    while start < total_frames:
        end = min(total_frames, start + window_frames)
        values.append((start, end))
        if end == total_frames:
            break
        start += step
    return tuple(values)


def _clip_turn(turn: SpeakerTurn, start_ms: int, end_ms: int) -> SpeakerTurn | None:
    start = max(turn.start_ms, start_ms)
    end = min(turn.end_ms, end_ms)
    if end <= start:
        return None
    return SpeakerTurn(start, end, turn.speaker_index)


def _coalesce_turns(turns: Iterable[SpeakerTurn], *, max_gap_ms: int = 20) -> list[SpeakerTurn]:
    result: list[SpeakerTurn] = []
    for turn in sorted(turns, key=lambda item: (item.start_ms, item.end_ms, item.speaker_index)):
        if (
            result
            and result[-1].speaker_index == turn.speaker_index
            and turn.start_ms <= result[-1].end_ms + max_gap_ms
        ):
            previous = result[-1]
            result[-1] = SpeakerTurn(
                previous.start_ms,
                max(previous.end_ms, turn.end_ms),
                previous.speaker_index,
            )
        else:
            result.append(turn)
    return result


def _temporal_speaker_mapping(
    previous: Iterable[SpeakerTurn],
    current: Iterable[SpeakerTurn],
    *,
    overlap_start_ms: int,
    overlap_end_ms: int,
) -> dict[int, int]:
    """Greedily map window-local clusters using shared overlap speech."""
    scores: dict[tuple[int, int], int] = {}
    previous_overlap = [
        clipped
        for turn in previous
        if (clipped := _clip_turn(turn, overlap_start_ms, overlap_end_ms)) is not None
    ]
    current_overlap = [
        clipped
        for turn in current
        if (clipped := _clip_turn(turn, overlap_start_ms, overlap_end_ms)) is not None
    ]
    for local in current_overlap:
        for known in previous_overlap:
            overlap = _overlap_ms(local.start_ms, local.end_ms, known)
            if overlap:
                key = (local.speaker_index, known.speaker_index)
                scores[key] = scores.get(key, 0) + overlap
    mapping: dict[int, int] = {}
    used_global: set[int] = set()
    for (local, known), score in sorted(
        scores.items(), key=lambda item: (-item[1], item[0][0], item[0][1])
    ):
        if score <= 0 or local in mapping or known in used_global:
            continue
        mapping[local] = known
        used_global.add(known)
    return mapping


def _cosine_similarity(left: Any, right: Any) -> float:
    try:
        import numpy as np
    except ImportError as exc:
        raise DiarizationError("runtime 未安裝 numpy") from exc
    left_value = np.asarray(left, dtype=np.float32)
    right_value = np.asarray(right, dtype=np.float32)
    denominator = float(np.linalg.norm(left_value) * np.linalg.norm(right_value))
    if denominator <= 0:
        return -1.0
    return float(np.dot(left_value, right_value) / denominator)


def _speaker_overlap_conflicts(
    turns: Iterable[SpeakerTurn],
    *,
    minimum_overlap_ms: int,
) -> set[frozenset[int]]:
    """Return source-speaker pairs that must not be merged.

    A short tolerance avoids treating millisecond-level segmentation jitter as
    genuine simultaneous speech.  Longer overlap is hard evidence that two
    anonymous source labels cannot represent the same person.
    """
    if minimum_overlap_ms <= 0:
        raise ValueError("minimum_overlap_ms must be positive")
    by_speaker: dict[int, list[SpeakerTurn]] = {}
    for turn in turns:
        by_speaker.setdefault(turn.speaker_index, []).append(turn)
    conflicts: set[frozenset[int]] = set()
    speakers = sorted(by_speaker)
    for offset, left_id in enumerate(speakers):
        left_turns = sorted(by_speaker[left_id], key=lambda item: item.start_ms)
        for right_id in speakers[offset + 1 :]:
            right_turns = sorted(by_speaker[right_id], key=lambda item: item.start_ms)
            left_index = 0
            right_index = 0
            while left_index < len(left_turns) and right_index < len(right_turns):
                left = left_turns[left_index]
                right = right_turns[right_index]
                if _overlap_ms(left.start_ms, left.end_ms, right) >= minimum_overlap_ms:
                    conflicts.add(frozenset((left_id, right_id)))
                    break
                if left.end_ms <= right.end_ms:
                    left_index += 1
                else:
                    right_index += 1
    return conflicts


def _coalesce_by_speaker(
    turns: Iterable[SpeakerTurn],
    *,
    max_gap_ms: int = 20,
) -> tuple[SpeakerTurn, ...]:
    """Union adjacent/overlapping turns independently for each speaker."""
    by_speaker: dict[int, list[SpeakerTurn]] = {}
    for turn in turns:
        by_speaker.setdefault(turn.speaker_index, []).append(turn)
    combined: list[SpeakerTurn] = []
    for speaker, values in sorted(by_speaker.items()):
        merged: list[SpeakerTurn] = []
        for turn in sorted(values, key=lambda item: (item.start_ms, item.end_ms)):
            if merged and turn.start_ms <= merged[-1].end_ms + max_gap_ms:
                previous = merged[-1]
                merged[-1] = SpeakerTurn(
                    previous.start_ms,
                    max(previous.end_ms, turn.end_ms),
                    speaker,
                )
            else:
                merged.append(turn)
        combined.extend(merged)
    return tuple(
        sorted(combined, key=lambda item: (item.start_ms, item.end_ms, item.speaker_index))
    )


def _auto_consolidate_speakers(
    turns: Iterable[SpeakerTurn],
    embeddings: dict[int, Any],
    *,
    overlap_guard_ms: int = 100,
    min_reliable_speech_ms: int = 1000,
    max_merge_distance: float = 0.35,
    max_automatic_speakers: int = 8,
) -> tuple[tuple[SpeakerTurn, ...], dict[str, Any]]:
    """Conservatively repair fragmentation and quarantine weak identities.

    The upstream unknown-count mode uses complete-link clustering at one fixed
    cosine-distance threshold.  Real meeting audio can therefore produce many
    short source labels.  A sub-second backchannel is useful *speech* evidence,
    but it is not enough evidence to mint a stable speaker identity.

    This deterministic second pass follows four fail-safe rules:

    * only source labels with at least ``min_reliable_speech_ms`` and a finite
      embedding may become a named speaker;
    * reliable labels merge only below a stricter recording-wide complete-link
      distance, never across confirmed simultaneous speech;
    * weak labels are omitted, so transcript assignment reports ``Unknown``
      instead of inventing Speaker 17 from a few hundred milliseconds;
    * more than ``max_automatic_speakers`` residual identities returns no
      automatic labels.  The user can still provide the known count, which
      bypasses this policy.

    The policy intentionally optimises for precision over coverage.  It does not
    infer a person's real identity and it never rewrites transcript text.
    """
    try:
        import numpy as np
    except ImportError as exc:
        raise DiarizationError("runtime 未安裝 numpy") from exc

    if overlap_guard_ms <= 0:
        raise ValueError("overlap_guard_ms must be positive")
    if min_reliable_speech_ms < 1000:
        raise ValueError("min_reliable_speech_ms must be at least 1000")
    if not 0.0 <= max_merge_distance <= 2.0:
        raise ValueError("max_merge_distance must be between zero and two")
    if not 1 <= max_automatic_speakers <= 20:
        raise ValueError("max_automatic_speakers must be between one and twenty")

    raw_turns = tuple(turns)
    source_ids = sorted({turn.speaker_index for turn in raw_turns})
    speech_ms = {
        speaker: sum(
            turn.end_ms - turn.start_ms
            for turn in raw_turns
            if turn.speaker_index == speaker
        )
        for speaker in source_ids
    }
    normalized: dict[int, Any] = {}
    for speaker in source_ids:
        if speaker not in embeddings:
            continue
        value = np.asarray(embeddings[speaker], dtype=np.float32)
        norm = float(np.linalg.norm(value))
        if norm > 0 and bool(np.all(np.isfinite(value))):
            normalized[speaker] = value / norm

    reliable_ids = [
        speaker
        for speaker in source_ids
        if speech_ms[speaker] >= min_reliable_speech_ms and speaker in normalized
    ]
    uncertain_ids = sorted(set(source_ids) - set(reliable_ids))
    uncertain_id_set = set(uncertain_ids)
    uncertain_turns = [
        turn for turn in raw_turns if turn.speaker_index in uncertain_id_set
    ]
    base_audit: dict[str, Any] = {
        "mode": "automatic_evidence_guard",
        "policy_version": "speaker-evidence-guard-v1",
        "raw_num_speakers": len(source_ids),
        "embedded_num_speakers": len(normalized),
        "reliable_source_speakers": len(reliable_ids),
        "uncertain_source_speakers": len(uncertain_ids),
        "uncertain_turn_count": len(uncertain_turns),
        "uncertain_speech_ms": sum(turn.end_ms - turn.start_ms for turn in uncertain_turns),
        "min_reliable_speech_ms": min_reliable_speech_ms,
        "merge_distance_threshold": max_merge_distance,
        "overlap_guard_ms": overlap_guard_ms,
        "automatic_speaker_hard_cap": max_automatic_speakers,
        "guard_applied": False,
        "automatic_labels_usable": False,
        "requires_expected_speaker_count": False,
        "fail_safe_suppressed_candidate_speakers": 0,
        "quality": "uncertain",
        "final_num_speakers": 0,
        "raw_speaker_ms": sum(turn.end_ms - turn.start_ms for turn in raw_turns),
        "returned_speaker_ms": 0,
        "identity_coverage_ratio": 0.0,
        "fragmentation_reduction_ratio": 0.0,
    }
    if not raw_turns:
        base_audit.update({"reason": "no speaker turns", "quality": "no_speech"})
        return (), base_audit
    if not reliable_ids:
        base_audit.update(
            {
                "guard_applied": bool(raw_turns),
                "requires_expected_speaker_count": True,
                "fail_safe_suppressed_candidate_speakers": len(source_ids),
                "reason": "no source label has enough reliable embedding evidence",
            }
        )
        return (), base_audit

    conflicts = _speaker_overlap_conflicts(
        raw_turns,
        minimum_overlap_ms=overlap_guard_ms,
    )

    def cluster_key(value: frozenset[int]) -> tuple[int, ...]:
        return tuple(sorted(value))

    def complete_link_distance(
        left: frozenset[int], right: frozenset[int]
    ) -> float:
        distances: list[float] = []
        for left_id in left:
            for right_id in right:
                if frozenset((left_id, right_id)) in conflicts:
                    return float("inf")
                similarity = _cosine_similarity(
                    normalized[left_id], normalized[right_id]
                )
                distances.append(max(0.0, min(2.0, 1.0 - similarity)))
        return max(distances, default=float("inf"))

    clusters: list[frozenset[int]] = [
        frozenset((speaker,)) for speaker in reliable_ids
    ]
    merge_distances: list[float] = []
    while len(clusters) > 1:
        best: tuple[float, tuple[int, ...], tuple[int, ...], int, int] | None = None
        for left_index, left in enumerate(clusters):
            for right_index in range(left_index + 1, len(clusters)):
                right = clusters[right_index]
                distance = complete_link_distance(left, right)
                candidate = (
                    distance,
                    cluster_key(left),
                    cluster_key(right),
                    left_index,
                    right_index,
                )
                if best is None or candidate < best:
                    best = candidate
        if (
            best is None
            or not np.isfinite(best[0])
            or best[0] > max_merge_distance
        ):
            break
        distance, _, _, left_index, right_index = best
        merged = clusters[left_index] | clusters[right_index]
        clusters = [
            cluster
            for index, cluster in enumerate(clusters)
            if index not in (left_index, right_index)
        ]
        clusters.append(merged)
        clusters.sort(key=cluster_key)
        merge_distances.append(float(distance))

    candidate_count = len(clusters)
    base_audit.update(
        {
            "candidate_num_speakers": candidate_count,
            "merged_source_speakers": len(reliable_ids) - candidate_count,
            "maximum_applied_merge_distance": (
                round(max(merge_distances), 6) if merge_distances else None
            ),
            "temporal_conflict_pairs": len(conflicts),
        }
    )
    if candidate_count > max_automatic_speakers:
        base_audit.update(
            {
                "guard_applied": True,
                "requires_expected_speaker_count": True,
                "fail_safe_suppressed_candidate_speakers": candidate_count,
                "reason": (
                    "automatic speaker count exceeds the safety cap; "
                    "set the expected speaker count to enable labels"
                ),
            }
        )
        return (), base_audit

    mapping: dict[int, int] = {}
    for cluster in clusters:
        representative = min(cluster)
        for speaker in cluster:
            mapping[speaker] = representative
    consolidated = _coalesce_by_speaker(
        SpeakerTurn(turn.start_ms, turn.end_ms, mapping[turn.speaker_index])
        for turn in raw_turns
        if turn.speaker_index in mapping
    )
    result = normalize_turns(consolidated)
    final_count = len({turn.speaker_index for turn in result})
    returned_speaker_ms = sum(turn.end_ms - turn.start_ms for turn in result)
    reasons: list[str] = []
    if uncertain_ids:
        reasons.append("quarantined source labels without reliable embedding evidence")
    if merge_distances:
        reasons.append("merged strongly matching complete-link speaker embeddings")
    if not reasons:
        reasons.append("all source labels passed conservative evidence checks")
    base_audit.update(
        {
            "guard_applied": bool(uncertain_ids or merge_distances),
            "automatic_labels_usable": bool(result),
            "quality": "accepted_with_unknown_turns" if uncertain_ids else "accepted",
            "final_num_speakers": final_count,
            "returned_turn_count": len(result),
            "returned_speaker_ms": returned_speaker_ms,
            "identity_coverage_ratio": round(
                returned_speaker_ms / max(1, base_audit["raw_speaker_ms"]), 6
            ),
            "fragmentation_reduction_ratio": round(
                1.0 - final_count / max(1, len(source_ids)), 6
            ),
            "reason": "; ".join(reasons),
        }
    )
    return result, base_audit


def _resolve_speaker_mapping(
    previous: Iterable[SpeakerTurn],
    current: Iterable[SpeakerTurn],
    *,
    overlap_start_ms: int,
    overlap_end_ms: int,
    embeddings: dict[int, Any],
    prototypes: dict[int, Any],
    embedding_threshold: float,
) -> dict[int, int]:
    """Resolve window-local labels to stable recording-wide speaker ids."""
    current_values = tuple(current)
    mapping = _temporal_speaker_mapping(
        previous,
        current_values,
        overlap_start_ms=overlap_start_ms,
        overlap_end_ms=overlap_end_ms,
    )
    used_global = set(mapping.values())
    local_order: dict[int, int] = {}
    for turn in sorted(current_values, key=lambda item: (item.start_ms, item.end_ms)):
        local_order.setdefault(turn.speaker_index, len(local_order))

    # A speaker can leave for longer than the overlap and return in a later
    # window.  Match its compact 3D-Speaker embedding before allocating a new
    # anonymous id; overlap mappings always take precedence.
    for local in local_order:
        if local in mapping or local not in embeddings:
            continue
        ranked = sorted(
            (
                (_cosine_similarity(embeddings[local], prototype), known)
                for known, prototype in prototypes.items()
                if known not in used_global
            ),
            key=lambda item: (-item[0], item[1]),
        )
        if ranked and ranked[0][0] >= embedding_threshold:
            mapping[local] = ranked[0][1]
            used_global.add(ranked[0][1])

    known_ids = {
        turn.speaker_index for turn in previous
    } | set(prototypes) | set(mapping.values())
    next_global = max(known_ids, default=-1) + 1
    for local in local_order:
        if local not in mapping:
            mapping[local] = next_global
            next_global += 1
    return mapping


def _update_prototypes(
    prototypes: dict[int, Any],
    prototype_counts: dict[int, int],
    mapping: dict[int, int],
    embeddings: dict[int, Any],
) -> None:
    try:
        import numpy as np
    except ImportError as exc:
        raise DiarizationError("runtime 未安裝 numpy") from exc
    for local, known in mapping.items():
        if local not in embeddings:
            continue
        value = np.asarray(embeddings[local], dtype=np.float32)
        norm = float(np.linalg.norm(value))
        if norm <= 0:
            continue
        value = value / norm
        count = prototype_counts.get(known, 0)
        if known in prototypes and count:
            value = (np.asarray(prototypes[known], dtype=np.float32) * count + value) / (
                count + 1
            )
            updated_norm = float(np.linalg.norm(value))
            if updated_norm > 0:
                value = value / updated_norm
        prototypes[known] = value
        prototype_counts[known] = count + 1


def _stitch_window_turns(
    previous: Iterable[SpeakerTurn],
    current: Iterable[SpeakerTurn],
    *,
    window_start_ms: int,
    overlap_ms: int,
) -> list[SpeakerTurn]:
    """Replace half of the shared overlap to avoid duplicated boundary turns."""
    previous_values = list(previous)
    current_values = list(current)
    if not previous_values:
        return _coalesce_turns(current_values)
    boundary = window_start_ms + overlap_ms // 2
    prefix = [
        clipped
        for turn in previous_values
        if (clipped := _clip_turn(turn, 0, boundary)) is not None
    ]
    suffix = [
        clipped
        for turn in current_values
        if (clipped := _clip_turn(turn, boundary, 2**63 - 1)) is not None
    ]
    return _coalesce_turns((*prefix, *suffix))


class SherpaOfflineDiarizer:
    """sherpa-onnx PyAnnote + 3D-Speaker offline diarization adapter."""

    def __init__(
        self,
        segmentation_model: Path,
        embedding_model: Path,
        *,
        num_threads: int = 2,
        num_speakers: int | None = None,
        threshold: float = 0.9,
        window_seconds: float = 300.0,
        window_overlap_seconds: float = 30.0,
        speaker_match_threshold: float = 0.55,
        max_embedding_seconds: float = 20.0,
    ) -> None:
        self.segmentation_model = Path(segmentation_model)
        self.embedding_model = Path(embedding_model)
        self.num_threads = num_threads
        self.num_speakers = num_speakers
        if not 0.0 <= threshold <= 2.0:
            raise ValueError("diarization threshold must be between zero and two")
        self.threshold = float(threshold)
        if window_seconds <= 0:
            raise ValueError("diarization window_seconds must be positive")
        if window_overlap_seconds < 0 or window_overlap_seconds >= window_seconds:
            raise ValueError("diarization overlap must be shorter than its window")
        if not 0 <= speaker_match_threshold <= 1:
            raise ValueError("speaker_match_threshold must be between zero and one")
        if max_embedding_seconds <= 0:
            raise ValueError("max_embedding_seconds must be positive")
        self.window_seconds = float(window_seconds)
        self.window_overlap_seconds = float(window_overlap_seconds)
        self.speaker_match_threshold = float(speaker_match_threshold)
        self.max_embedding_seconds = float(max_embedding_seconds)
        self.last_diagnostics: dict[str, Any] = {}

    def _config(self) -> Any:
        try:
            import sherpa_onnx
        except ImportError as exc:
            raise DiarizationError("runtime 未安裝 sherpa-onnx") from exc
        if not self.segmentation_model.is_file() or not self.embedding_model.is_file():
            raise FileNotFoundError("speaker diarization models 未完整下載")
        pyannote = sherpa_onnx.OfflineSpeakerSegmentationPyannoteModelConfig()
        pyannote.model = str(self.segmentation_model)
        segmentation = sherpa_onnx.OfflineSpeakerSegmentationModelConfig()
        segmentation.pyannote = pyannote
        segmentation.num_threads = self.num_threads
        segmentation.provider = "cpu"
        embedding = sherpa_onnx.SpeakerEmbeddingExtractorConfig()
        embedding.model = str(self.embedding_model)
        embedding.num_threads = self.num_threads
        embedding.provider = "cpu"
        clustering = sherpa_onnx.FastClusteringConfig()
        clustering.num_clusters = self.num_speakers or 0
        clustering.threshold = self.threshold
        return sherpa_onnx.OfflineSpeakerDiarizationConfig(
            segmentation, embedding, clustering, 0.3, 0.5
        )

    def _embedding_config(self) -> Any:
        try:
            import sherpa_onnx
        except ImportError as exc:
            raise DiarizationError("runtime 未安裝 sherpa-onnx") from exc
        return sherpa_onnx.SpeakerEmbeddingExtractorConfig(
            model=str(self.embedding_model),
            num_threads=self.num_threads,
            provider="cpu",
        )

    def _cluster_embeddings(
        self,
        extractor: Any,
        samples: Any,
        turns: Iterable[SpeakerTurn],
        *,
        cancelled: Cancelled | None,
    ) -> dict[int, Any]:
        try:
            import numpy as np
        except ImportError as exc:
            raise DiarizationError("runtime 未安裝 numpy") from exc
        by_speaker: dict[int, list[SpeakerTurn]] = {}
        for turn in turns:
            by_speaker.setdefault(turn.speaker_index, []).append(turn)
        limit = max(1, round(self.max_embedding_seconds * 16000))
        embeddings: dict[int, Any] = {}
        for speaker, values in sorted(by_speaker.items()):
            if cancelled and cancelled():
                raise DiarizationCancelled("已取消 speaker diarization")
            pieces: list[Any] = []
            remaining = limit
            for turn in values:
                start = max(0, min(len(samples), round(turn.start_ms * 16)))
                end = max(start, min(len(samples), round(turn.end_ms * 16)))
                if end <= start:
                    continue
                piece = samples[start : min(end, start + remaining)]
                if len(piece):
                    pieces.append(piece)
                    remaining -= len(piece)
                if remaining <= 0:
                    break
            sample_count = sum(len(piece) for piece in pieces)
            # ERes2Net accepts variable-length input, but sub-second snippets
            # are not reliable speaker evidence and some ONNX Runtime builds
            # abort inside the native model for extremely short inputs.  Keep
            # them as unembedded/uncertain turns instead of manufacturing a
            # confident identity from a few hundred milliseconds.
            if sample_count < 16000:
                continue
            waveform = np.concatenate(pieces).astype(np.float32, copy=False)
            stream = extractor.create_stream()
            try:
                stream.accept_waveform(16000, waveform)
                stream.input_finished()
                if extractor.is_ready(stream):
                    embeddings[speaker] = np.asarray(
                        extractor.compute(stream), dtype=np.float32
                    )
            finally:
                del stream
                del waveform
        return embeddings

    def diarize_wav(
        self,
        wav_path: Path,
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> tuple[SpeakerTurn, ...]:
        if cancelled and cancelled():
            raise DiarizationCancelled("已取消 speaker diarization")
        try:
            import sherpa_onnx
        except ImportError as exc:
            raise DiarizationError("runtime 未安裝 sherpa-onnx") from exc
        diarizer: Any | None = None
        extractor: Any | None = None
        try:
            diarizer = sherpa_onnx.OfflineSpeakerDiarization(self._config())
            with _wav_memmap(Path(wav_path)) as reader:
                window_frames = max(1, round(self.window_seconds * reader.sample_rate))
                overlap_frames = max(
                    0, round(self.window_overlap_seconds * reader.sample_rate)
                )
                overlap_frames = min(overlap_frames, window_frames - 1)
                windows = _window_ranges(
                    reader.frames,
                    window_frames=window_frames,
                    overlap_frames=overlap_frames,
                )
                if len(windows) > 1 or self.num_speakers is None:
                    extractor = sherpa_onnx.SpeakerEmbeddingExtractor(
                        self._embedding_config()
                    )
                stitched: list[SpeakerTurn] = []
                prototypes: dict[int, Any] = {}
                prototype_counts: dict[int, int] = {}
                for window_index, (start_frame, end_frame) in enumerate(windows):
                    if cancelled and cancelled():
                        raise DiarizationCancelled("已取消 speaker diarization")
                    samples = reader.read_float32(start_frame, end_frame)
                    result: Any | None = None
                    try:
                        def callback(processed: int, total: int) -> int:
                            if cancelled and cancelled():
                                return 1
                            if progress:
                                fraction = max(0.0, min(1.0, processed / max(1, total)))
                                progress(
                                    {
                                        "phase": "speaker_diarization",
                                        "progress": (window_index + fraction) / max(1, len(windows)),
                                        "window": window_index + 1,
                                        "window_count": len(windows),
                                    }
                                )
                            return 0

                        result = diarizer.process(samples, callback)
                        local_turns: list[SpeakerTurn] = []
                        window_start_ms = round(start_frame / reader.sample_rate * 1000)
                        window_end_ms = round(end_frame / reader.sample_rate * 1000)
                        for item in result.sort_by_start_time():
                            local_start_ms = max(0, round(float(item.start) * 1000))
                            local_end_ms = max(1, round(float(item.end) * 1000))
                            absolute_start = min(
                                window_end_ms, window_start_ms + local_start_ms
                            )
                            absolute_end = min(
                                window_end_ms, window_start_ms + local_end_ms
                            )
                            if absolute_end > absolute_start:
                                local_turns.append(
                                    SpeakerTurn(
                                        absolute_start,
                                        absolute_end,
                                        int(item.speaker),
                                    )
                                )
                        if cancelled and cancelled():
                            raise DiarizationCancelled("已取消 speaker diarization")
                        relative_turns = tuple(
                            SpeakerTurn(
                                turn.start_ms - window_start_ms,
                                turn.end_ms - window_start_ms,
                                turn.speaker_index,
                            )
                            for turn in local_turns
                        )
                        embeddings = (
                            self._cluster_embeddings(
                                extractor,
                                samples,
                                relative_turns,
                                cancelled=cancelled,
                            )
                            if extractor is not None
                            else {}
                        )
                        overlap_ms = (
                            0
                            if window_index == 0
                            else round(overlap_frames / reader.sample_rate * 1000)
                        )
                        mapping = _resolve_speaker_mapping(
                            stitched,
                            local_turns,
                            overlap_start_ms=window_start_ms,
                            overlap_end_ms=window_start_ms + overlap_ms,
                            embeddings=embeddings,
                            prototypes=prototypes,
                            embedding_threshold=self.speaker_match_threshold,
                        )
                        mapped_turns = [
                            SpeakerTurn(
                                turn.start_ms,
                                turn.end_ms,
                                mapping[turn.speaker_index],
                            )
                            for turn in local_turns
                        ]
                        _update_prototypes(
                            prototypes,
                            prototype_counts,
                            mapping,
                            embeddings,
                        )
                        stitched = _stitch_window_turns(
                            stitched,
                            mapped_turns,
                            window_start_ms=window_start_ms,
                            overlap_ms=overlap_ms,
                        )
                    finally:
                        result = None
                        del samples
                    if progress:
                        progress(
                            {
                                "phase": "speaker_diarization",
                                "progress": (window_index + 1) / max(1, len(windows)),
                                "window": window_index + 1,
                                "window_count": len(windows),
                            }
                        )
                if progress and not windows:
                    progress({"phase": "speaker_diarization", "progress": 1.0})
                if cancelled and cancelled():
                    raise DiarizationCancelled("已取消 speaker diarization")
                raw_count = len({turn.speaker_index for turn in stitched})
                if self.num_speakers is None:
                    finalized, diagnostics = _auto_consolidate_speakers(
                        stitched,
                        prototypes,
                    )
                    diagnostics["upstream_cluster_threshold"] = self.threshold
                else:
                    finalized = normalize_turns(stitched)
                    diagnostics = {
                        "mode": "manual_num_speakers",
                        "requested_num_speakers": self.num_speakers,
                        "raw_num_speakers": raw_count,
                        "final_num_speakers": len(
                            {turn.speaker_index for turn in finalized}
                        ),
                        "guard_applied": False,
                        "reason": "manual speaker count bypasses automatic consolidation",
                    }
                self.last_diagnostics = diagnostics
                return finalized
        finally:
            extractor = None
            diarizer = None
            gc.collect()


def write_turns(path: Path, turns: Iterable[SpeakerTurn], *, model: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": 1,
        "model": model,
        "anonymous_labels": True,
        "turns": [item.to_dict() for item in turns],
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return path


def read_turns(path: Path) -> tuple[SpeakerTurn, ...]:
    """Read the app-owned diarization audit with a fixed, bounded schema."""

    if path.is_symlink() or not path.is_file():
        raise DiarizationError("diarization turns 檔案不存在或唔安全")
    if path.stat().st_size > SORTFORMER_MAX_OUTPUT_BYTES:
        raise DiarizationError("diarization turns 檔案太大")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise DiarizationError("diarization turns JSON 無效") from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != {"schema", "model", "anonymous_labels", "turns"}
        or payload.get("schema") != 1
        or payload.get("anonymous_labels") is not True
        or not isinstance(payload.get("model"), str)
        or not isinstance(payload.get("turns"), list)
    ):
        raise DiarizationError("diarization turns schema 無效")
    raw_turns = payload["turns"]
    if len(raw_turns) > 1_000_000:
        raise DiarizationError("diarization turns 數量超出安全上限")
    turns: list[SpeakerTurn] = []
    expected_keys = {
        "start_ms",
        "end_ms",
        "start",
        "end",
        "speaker_index",
        "speaker_id",
        "speaker_label",
    }
    for item in raw_turns:
        if not isinstance(item, dict) or set(item) != expected_keys:
            raise DiarizationError("diarization turn item schema 無效")
        start = item.get("start_ms")
        end = item.get("end_ms")
        speaker = item.get("speaker_index")
        if any(isinstance(value, bool) or not isinstance(value, int) for value in (start, end, speaker)):
            raise DiarizationError("diarization turn 值無效")
        try:
            turn = SpeakerTurn(start, end, speaker)
        except ValueError as exc:
            raise DiarizationError("diarization turn 時間無效") from exc
        if item.get("speaker_id") != turn.speaker_id or item.get("speaker_label") != turn.label:
            raise DiarizationError("diarization turn label 同 index 不一致")
        turns.append(turn)
    return normalize_turns(turns)


__all__ = [
    "DiarizationError",
    "SherpaOfflineDiarizer",
    "SpeakerTurn",
    "_auto_consolidate_speakers",
    "assign_speakers",
    "normalize_turns",
    "read_turns",
    "write_turns",
]
