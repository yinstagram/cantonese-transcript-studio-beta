from __future__ import annotations

import fcntl
import hashlib
import json
import logging
import os
import tempfile
import threading
import uuid
from contextlib import contextmanager
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Iterator, Mapping, Sequence

from ..audio.media import validate_media_path
from ..constants import JOB_METADATA_FILENAME, SCHEMA_VERSION


logger = logging.getLogger(__name__)
MAX_JOB_METADATA_BYTES = 8 * 1024 * 1024


class JobState(str, Enum):
    CREATED = "created"
    QUEUED = "queued"
    PROBING = "probing"
    EXTRACTING = "extracting"
    CHUNKING = "chunking"
    PRIMARY_ASR = "primary_asr"
    VERIFYING = "verifying"
    RECONCILING = "reconciling"
    NORMALIZING = "normalizing"
    EXPORTING = "exporting"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


PIPELINE_STATES = (
    JobState.PROBING,
    JobState.EXTRACTING,
    JobState.CHUNKING,
    JobState.PRIMARY_ASR,
    JobState.VERIFYING,
    JobState.RECONCILING,
    JobState.NORMALIZING,
    JobState.EXPORTING,
)
ACTIVE_JOB_STATES = frozenset({JobState.QUEUED, *PIPELINE_STATES})
# A duplicate is dangerous only while another attempt can still consume model
# resources or is waiting to be started.  Historical completed work must not
# permanently ban the user from intentionally rerunning the same recording
# with a different vocabulary, model, or subtitle configuration.
DUPLICATE_BLOCKING_STATES = frozenset({JobState.CREATED, *ACTIVE_JOB_STATES})

ALLOWED_TRANSITIONS: Mapping[JobState, frozenset[JobState]] = {
    JobState.CREATED: frozenset({JobState.QUEUED, JobState.CANCELED}),
    JobState.QUEUED: frozenset({*PIPELINE_STATES, JobState.FAILED, JobState.CANCELED}),
    JobState.PROBING: frozenset({JobState.EXTRACTING, JobState.FAILED, JobState.CANCELED}),
    JobState.EXTRACTING: frozenset({JobState.CHUNKING, JobState.FAILED, JobState.CANCELED}),
    JobState.CHUNKING: frozenset({JobState.PRIMARY_ASR, JobState.FAILED, JobState.CANCELED}),
    JobState.PRIMARY_ASR: frozenset({JobState.VERIFYING, JobState.FAILED, JobState.CANCELED}),
    JobState.VERIFYING: frozenset({JobState.RECONCILING, JobState.FAILED, JobState.CANCELED}),
    JobState.RECONCILING: frozenset({JobState.NORMALIZING, JobState.FAILED, JobState.CANCELED}),
    JobState.NORMALIZING: frozenset({JobState.EXPORTING, JobState.FAILED, JobState.CANCELED}),
    JobState.EXPORTING: frozenset({JobState.COMPLETED, JobState.FAILED, JobState.CANCELED}),
    JobState.COMPLETED: frozenset(),
    JobState.FAILED: frozenset({JobState.QUEUED, JobState.CANCELED}),
    JobState.CANCELED: frozenset({JobState.QUEUED}),
}

CHECKPOINT_SEQUENCE: tuple[tuple[str, JobState], ...] = (
    ("probed", JobState.EXTRACTING),
    ("extracted", JobState.CHUNKING),
    ("chunked", JobState.PRIMARY_ASR),
    ("primary_asr", JobState.VERIFYING),
    ("verified", JobState.RECONCILING),
    # Reconciliation is complete here, but optional speaker diarization still
    # runs inside the alignment stage.  A retry must therefore visibly resume
    # in RECONCILING, not sit queued/pretend normalization has begun.
    ("reconciled", JobState.RECONCILING),
    ("normalized", JobState.NORMALIZING),
    ("timestamps", JobState.EXPORTING),
    ("exported", JobState.COMPLETED),
)
CHECKPOINT_NAMES = frozenset(name for name, _ in CHECKPOINT_SEQUENCE)

# These are the last *durably completed* fractions for each checkpoint.  They
# intentionally mirror the pipeline ranges without importing the heavyweight
# ASR pipeline into the persistence layer.  A retry must resume from one of
# these truthful floors instead of retaining (for example) 92% from work that
# never produced a valid checkpoint.
CHECKPOINT_PROGRESS_FLOORS: Mapping[str, tuple[float, float]] = {
    #                         standard, accuracy/MoE
    "probed": (0.01, 0.01),
    "extracted": (0.08, 0.08),
    "chunked": (0.10, 0.10),
    "primary_asr": (0.58, 0.50),
    "verified": (0.78, 0.82),
    "reconciled": (0.88, 0.90),
    "normalized": (0.92, 0.93),
    "timestamps": (0.96, 0.97),
    "exported": (1.0, 1.0),
}


class InvalidJobTransition(RuntimeError):
    pass


class JobAttemptOwnershipLost(InvalidJobTransition):
    """Raised when an obsolete runner tries to mutate a newer job attempt."""


class DuplicateJobError(RuntimeError):
    def __init__(self, existing_job_id: str) -> None:
        super().__init__(f"Media already exists in job {existing_job_id}")
        self.existing_job_id = existing_job_id


class JobMetadataError(RuntimeError):
    pass


class FingerprintCancelled(JobMetadataError):
    pass


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def fingerprint_file(
    path: str | Path,
    *,
    block_size: int = 1024 * 1024,
    progress: Callable[[float], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> str:
    if block_size <= 0:
        raise ValueError("block_size must be positive")
    source = Path(path).expanduser().resolve()
    before = source_identity_file(source)
    digest = hashlib.sha256()
    processed = 0
    last_reported = -1.0
    with source.open("rb") as handle:
        while block := handle.read(block_size):
            if cancelled and cancelled():
                raise FingerprintCancelled("Source fingerprint cancelled")
            digest.update(block)
            processed += len(block)
            if progress:
                fraction = processed / before["size"] if before["size"] else 1.0
                if fraction >= 1.0 or fraction - last_reported >= 0.01:
                    progress(min(1.0, fraction))
                    last_reported = fraction
    if progress and last_reported < 1.0:
        progress(1.0)
    after = source_identity_file(source)
    if before != after:
        raise JobMetadataError(f"Media changed while fingerprinting: {source}")
    return f"sha256:{digest.hexdigest()}"


def quick_fingerprint_file(
    path: str | Path, *, sample_size: int = 4 * 1024 * 1024
) -> str:
    """Bounded import-time identity; a full SHA-256 is sealed by the runner.

    At most the first and last ``sample_size`` bytes are read, so adding a
    multi-gigabyte video cannot block the JSON protocol for minutes.  File
    stat identity is checked before/after the sample to reject concurrent edits.
    """

    if sample_size <= 0:
        raise ValueError("sample_size must be positive")
    source = Path(path).expanduser().resolve()
    before = source.stat()
    digest = hashlib.sha256()
    digest.update(b"cts-quick-fingerprint-v1\0")
    digest.update(str(before.st_size).encode("ascii"))
    digest.update(b"\0")
    with source.open("rb") as handle:
        digest.update(handle.read(sample_size))
        if before.st_size > sample_size:
            handle.seek(max(0, before.st_size - sample_size))
            digest.update(handle.read(sample_size))
    after = source.stat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (
        after.st_dev,
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
    ):
        raise JobMetadataError(f"Media changed while fingerprinting: {source}")
    return f"quick-sha256:{digest.hexdigest()}"


def source_identity_file(path: str | Path) -> dict[str, int]:
    """Capture stable filesystem identity used between create and first seal.

    This catches ordinary replacement/edit races.  It is not intended as a
    defence against a malicious writer that preserves the same inode/size and
    restores nanosecond timestamps; the full SHA-256 seal is the content
    identity once the first runner owns the job.
    """

    source = Path(path).expanduser().resolve()
    stat = source.stat()
    identity = {
        "device": int(stat.st_dev),
        "inode": int(stat.st_ino),
        "size": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
    }
    birthtime_ns = getattr(stat, "st_birthtime_ns", None)
    if birthtime_ns is None:
        birthtime = getattr(stat, "st_birthtime", None)
        if birthtime is not None:
            birthtime_ns = int(round(float(birthtime) * 1_000_000_000))
    if birthtime_ns is not None:
        identity["birthtime_ns"] = int(birthtime_ns)
    return identity


@dataclass(frozen=True)
class JobCheckpoint:
    name: str
    completed_at: str
    artifacts: tuple[str, ...] = ()
    data: Mapping[str, Any] = field(default_factory=dict)

    def is_valid(self) -> bool:
        if not all(Path(path).is_file() and not Path(path).is_symlink() for path in self.artifacts):
            return False
        integrity_version = self.data.get("checkpoint_integrity_version")
        integrity_manifest = self.data.get("checkpoint_artifact_manifest")
        if integrity_version is not None or integrity_manifest is not None:
            if integrity_version != 1 or not isinstance(integrity_manifest, list):
                return False
            if len(integrity_manifest) != len(self.artifacts):
                return False
            for artifact, record in zip(self.artifacts, integrity_manifest, strict=True):
                if not isinstance(record, Mapping):
                    return False
                expected_path = str(Path(artifact).resolve())
                size = record.get("size")
                expected_sha = record.get("sha256")
                if (
                    record.get("path") != expected_path
                    or isinstance(size, bool)
                    or not isinstance(size, int)
                    or size < 0
                    or not isinstance(expected_sha, str)
                    or len(expected_sha) != 64
                ):
                    return False
                path = Path(expected_path)
                try:
                    if path.is_symlink() or path.stat().st_size != size:
                        return False
                    digest = hashlib.sha256()
                    with path.open("rb") as stream:
                        for block in iter(lambda: stream.read(1024 * 1024), b""):
                            digest.update(block)
                    if digest.hexdigest() != expected_sha:
                        return False
                except OSError:
                    return False
        manifest = self.data.get("artifact_manifest")
        if self.name == "exported" and not isinstance(manifest, list):
            # Older releases checkpointed exports.json only.  Resume at the
            # exporting stage so the six user-facing files are regenerated and
            # content-verified instead of marking a hollow directory complete.
            return False
        if manifest is None:
            return True
        if not isinstance(manifest, list) or len(manifest) != len(self.artifacts) - 1:
            return False
        artifact_paths = {str(Path(path).resolve()) for path in self.artifacts[1:]}
        for record in manifest:
            if not isinstance(record, Mapping):
                return False
            relative = record.get("relative_path")
            size = record.get("size")
            expected_sha = record.get("sha256")
            if (
                not isinstance(relative, str)
                or Path(relative).is_absolute()
                or ".." in Path(relative).parts
                or isinstance(size, bool)
                or not isinstance(size, int)
                or size < 0
                or not isinstance(expected_sha, str)
                or len(expected_sha) != 64
            ):
                return False
            matches = [path for path in artifact_paths if Path(path).name == Path(relative).name]
            if len(matches) != 1:
                return False
            path = Path(matches[0])
            try:
                if path.stat().st_size != size:
                    return False
                digest = hashlib.sha256()
                with path.open("rb") as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(block)
                if digest.hexdigest() != expected_sha:
                    return False
            except OSError:
                return False
        return True


def _sealed_json_digest(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _read_bounded_json(path: Path, maximum_bytes: int = 64 * 1024 * 1024) -> Any:
    before = path.stat()
    if before.st_size < 2 or before.st_size > maximum_bytes:
        raise ValueError("checkpoint JSON size is outside the recovery bound")
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    after = path.stat()
    if (
        before.st_dev,
        before.st_ino,
        before.st_size,
        before.st_mtime_ns,
    ) != (
        after.st_dev,
        after.st_ino,
        after.st_size,
        after.st_mtime_ns,
    ):
        raise OSError("checkpoint JSON changed during recovery")
    return value


@dataclass(frozen=True)
class JobRecord:
    job_id: str
    source_path: str
    fingerprint: str
    workspace: str
    state: JobState
    created_at: str
    updated_at: str
    revision: int = 0
    progress: float = 0.0
    retry_count: int = 0
    attempt_generation: int = 0
    retry_requested: bool = False
    resume_from: JobState | None = None
    error: Mapping[str, Any] | None = None
    checkpoints: Mapping[str, JobCheckpoint] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    version: int = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not 0.0 <= self.progress <= 1.0:
            raise ValueError("job progress must be between 0 and 1")
        if self.attempt_generation < 0:
            raise ValueError("job attempt_generation must be non-negative")

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["state"] = self.state.value
        payload["resume_from"] = self.resume_from.value if self.resume_from is not None else None
        return payload

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "JobRecord":
        raw_checkpoints = data.get("checkpoints", {})
        if not isinstance(raw_checkpoints, Mapping):
            raise JobMetadataError("checkpoints must be an object")
        checkpoints = {
            str(name): JobCheckpoint(
                name=str(item.get("name", name)),
                completed_at=str(item["completed_at"]),
                artifacts=tuple(str(path) for path in item.get("artifacts", ())),
                data=dict(item.get("data", {})),
            )
            for name, item in raw_checkpoints.items()
            if isinstance(item, Mapping)
        }
        return cls(
            job_id=str(data["job_id"]),
            source_path=str(data["source_path"]),
            fingerprint=str(data["fingerprint"]),
            workspace=str(data["workspace"]),
            state=JobState(str(data["state"])),
            created_at=str(data["created_at"]),
            updated_at=str(data["updated_at"]),
            revision=int(data.get("revision", 0)),
            progress=float(data.get("progress", 0.0)),
            retry_count=int(data.get("retry_count", 0)),
            attempt_generation=int(data.get("attempt_generation", 0)),
            retry_requested=bool(data.get("retry_requested", False)),
            resume_from=JobState(str(data["resume_from"])) if data.get("resume_from") else None,
            error=dict(data["error"]) if isinstance(data.get("error"), Mapping) else None,
            checkpoints=checkpoints,
            metadata=dict(data.get("metadata", {})),
            version=int(data.get("version", SCHEMA_VERSION)),
        )


class JobStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self._thread_lock = threading.RLock()
        self._lock_path = self.root / ".jobs.lock"

    @contextmanager
    def _locked(self) -> Iterator[None]:
        with self._thread_lock:
            with self._lock_path.open("a+b") as lock_handle:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

    def _metadata_path(self, job_id: str) -> Path:
        if (
            not job_id
            or Path(job_id).name != job_id
            or job_id in {".", ".."}
        ):
            raise ValueError("invalid job_id")
        return self.root / job_id / JOB_METADATA_FILENAME

    def _write(self, record: JobRecord) -> None:
        destination = self._metadata_path(record.job_id)
        destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{JOB_METADATA_FILENAME}.", dir=destination.parent
        )
        try:
            os.fchmod(descriptor, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(record.to_dict(), handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_name, destination)
            directory_descriptor = os.open(destination.parent, os.O_RDONLY)
            try:
                os.fsync(directory_descriptor)
            finally:
                os.close(directory_descriptor)
        except BaseException:
            try:
                Path(temporary_name).unlink(missing_ok=True)
            except OSError:
                pass
            raise

    def _read(self, metadata_path: Path) -> JobRecord:
        if (
            metadata_path.is_symlink()
            or not metadata_path.is_file()
            or metadata_path.stat().st_size > MAX_JOB_METADATA_BYTES
        ):
            raise JobMetadataError(f"Job metadata path/size invalid: {metadata_path}")
        try:
            with metadata_path.open("r", encoding="utf-8") as handle:
                payload = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            raise JobMetadataError(f"Unable to read job metadata {metadata_path}: {exc}") from exc
        if not isinstance(payload, Mapping):
            raise JobMetadataError(f"Job metadata root must be an object: {metadata_path}")
        try:
            record = JobRecord.from_dict(payload)
        except (KeyError, TypeError, ValueError) as exc:
            raise JobMetadataError(f"Invalid job metadata {metadata_path}: {exc}") from exc
        if record.job_id != metadata_path.parent.name:
            raise JobMetadataError(f"Job metadata id does not match workspace: {metadata_path}")
        try:
            if Path(record.workspace).expanduser().resolve() != metadata_path.parent.resolve():
                raise JobMetadataError(f"Job metadata workspace identity invalid: {metadata_path}")
        except OSError as exc:
            raise JobMetadataError(f"Job metadata workspace unreadable: {metadata_path}") from exc
        return record

    def _quarantine_corrupt_metadata(
        self,
        metadata_path: Path,
        error: JobMetadataError,
    ) -> JobRecord:
        workspace = metadata_path.parent
        job_id = workspace.name
        if workspace.parent.resolve() != self.root or Path(job_id).name != job_id:
            raise JobMetadataError(f"Unsafe corrupt job workspace: {workspace}") from error
        now = _utc_now()
        source_path = str(workspace)
        created_at = now
        digest = hashlib.sha256()
        try:
            if metadata_path.is_symlink():
                digest.update(os.readlink(metadata_path).encode("utf-8", errors="replace"))
            else:
                file_stat = metadata_path.stat(follow_symlinks=False)
                digest.update(str(file_stat.st_size).encode("ascii"))
                if file_stat.st_size <= MAX_JOB_METADATA_BYTES:
                    raw = metadata_path.read_bytes()
                    digest.update(raw)
                    try:
                        salvage = json.loads(raw.decode("utf-8"))
                    except (UnicodeDecodeError, json.JSONDecodeError):
                        salvage = None
                    if isinstance(salvage, Mapping):
                        if isinstance(salvage.get("source_path"), str) and salvage["source_path"]:
                            source_path = salvage["source_path"]
                        if isinstance(salvage.get("created_at"), str) and salvage["created_at"]:
                            created_at = salvage["created_at"]
                else:
                    with metadata_path.open("rb") as handle:
                        digest.update(handle.read(64 * 1024))
        except OSError:
            digest.update(str(metadata_path).encode("utf-8", errors="replace"))

        quarantine = workspace / f"job.corrupt-{uuid.uuid4().hex}.json"
        os.replace(metadata_path, quarantine)
        record = JobRecord(
            job_id=job_id,
            source_path=source_path,
            fingerprint=f"corrupt-metadata:{digest.hexdigest()}",
            workspace=str(workspace.resolve()),
            state=JobState.FAILED,
            created_at=created_at,
            updated_at=now,
            error={
                "code": "job_metadata_corrupt",
                "message": "工作記錄已損壞；原始 metadata 已隔離，workspace 同輸出檔案仍然保留。",
                "quarantined_path": str(quarantine),
            },
            metadata={
                "metadata_recovery": True,
                "retry_blocked": True,
                "quarantined_metadata_path": str(quarantine),
            },
        )
        self._write(record)
        logger.error("Quarantined corrupt job metadata: %s -> %s", metadata_path, quarantine)
        return record

    def _list_unlocked(self) -> list[JobRecord]:
        records: list[JobRecord] = []
        for path in self.root.glob(f"*/{JOB_METADATA_FILENAME}"):
            try:
                records.append(self._read(path))
            except JobMetadataError as exc:
                try:
                    records.append(self._quarantine_corrupt_metadata(path, exc))
                except (OSError, JobMetadataError):
                    logger.exception("Unable to quarantine corrupt job metadata: %s", path)
        return sorted(records, key=lambda item: (item.created_at, item.job_id))

    def list_jobs(self) -> tuple[JobRecord, ...]:
        with self._locked():
            return tuple(self._list_unlocked())

    def get(self, job_id: str) -> JobRecord:
        with self._locked():
            metadata_path = self._metadata_path(job_id)
            if not metadata_path.is_file():
                raise KeyError(job_id)
            return self._read(metadata_path)

    @staticmethod
    def _assert_attempt(
        record: JobRecord, expected_attempt_generation: int | None
    ) -> None:
        if (
            expected_attempt_generation is not None
            and record.attempt_generation != expected_attempt_generation
        ):
            raise JobAttemptOwnershipLost(
                f"stale attempt for {record.job_id}: expected "
                f"{expected_attempt_generation}, got {record.attempt_generation}"
            )

    @staticmethod
    def _resume_progress_floor(record: JobRecord) -> float:
        """Return progress backed by the contiguous valid checkpoint prefix."""

        accuracy_index = 1 if record.metadata.get("accuracy_mode") is True else 0
        floor = 0.0
        for checkpoint_name, _ in CHECKPOINT_SEQUENCE:
            checkpoint = record.checkpoints.get(checkpoint_name)
            if checkpoint is None or not checkpoint.is_valid():
                break
            floor = CHECKPOINT_PROGRESS_FLOORS[checkpoint_name][accuracy_index]
        return floor

    def create_job(
        self,
        source_path: str | Path,
        *,
        metadata: Mapping[str, Any] | None = None,
        queue: bool = True,
    ) -> JobRecord:
        source = validate_media_path(source_path)
        quick_fingerprint = quick_fingerprint_file(source)
        source_identity = source_identity_file(source)
        with self._locked():
            for existing in self._list_unlocked():
                if (
                    Path(existing.source_path) == source
                    and existing.state in DUPLICATE_BLOCKING_STATES
                ):
                    raise DuplicateJobError(existing.job_id)
            now = _utc_now()
            job_id = str(uuid.uuid4())
            workspace = self.root / job_id
            record = JobRecord(
                job_id=job_id,
                source_path=str(source),
                fingerprint=quick_fingerprint,
                workspace=str(workspace),
                state=JobState.QUEUED if queue else JobState.CREATED,
                created_at=now,
                updated_at=now,
                attempt_generation=1 if queue else 0,
                metadata={
                    **dict(metadata or {}),
                    "source_quick_fingerprint": quick_fingerprint,
                    "source_identity": source_identity,
                },
            )
            self._write(record)
            return record

    def seal_source_fingerprint(
        self,
        job_id: str,
        *,
        quick_fingerprint: str,
        content_fingerprint: str,
        expected_attempt_generation: int | None = None,
    ) -> JobRecord:
        """Persist the runner's full source hash and reject a latent duplicate."""

        if not quick_fingerprint.startswith("quick-sha256:"):
            raise JobMetadataError("invalid quick source fingerprint")
        if not content_fingerprint.startswith("sha256:"):
            raise JobMetadataError("invalid full source fingerprint")
        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            expected_quick = record.metadata.get("source_quick_fingerprint")
            if expected_quick != quick_fingerprint:
                raise JobMetadataError("source quick fingerprint changed before sealing")
            expected_identity = record.metadata.get("source_identity")
            if (
                isinstance(expected_identity, Mapping)
                and dict(expected_identity) != source_identity_file(record.source_path)
            ):
                raise JobMetadataError("source identity changed before sealing")
            for existing in self._list_unlocked():
                if existing.job_id == job_id:
                    continue
                # Only simultaneous work is a duplicate.  A completed job is
                # historical evidence, not a permanent lock on these bytes:
                # users can deliberately rerun it with new model/vocabulary
                # settings.  Failed/cancelled attempts are equally retryable.
                if existing.state not in DUPLICATE_BLOCKING_STATES:
                    continue
                existing_full = existing.metadata.get("source_content_fingerprint")
                if not isinstance(existing_full, str) and existing.fingerprint.startswith(
                    "sha256:"
                ):
                    existing_full = existing.fingerprint
                if existing_full == content_fingerprint:
                    raise DuplicateJobError(existing.job_id)
            metadata = {
                **dict(record.metadata),
                "source_content_fingerprint": content_fingerprint,
            }
            updated = replace(
                record,
                fingerprint=content_fingerprint,
                metadata=metadata,
                updated_at=_utc_now(),
                revision=record.revision + 1,
            )
            self._write(updated)
            return updated

    def transition(
        self,
        job_id: str,
        new_state: JobState,
        *,
        error: Mapping[str, Any] | None = None,
        expected_revision: int | None = None,
        expected_attempt_generation: int | None = None,
        resume_checkpoint_invalidated: bool = False,
    ) -> JobRecord:
        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            if expected_revision is not None and record.revision != expected_revision:
                raise InvalidJobTransition(
                    f"stale revision for {job_id}: expected {expected_revision}, got {record.revision}"
                )
            resume_rewind = (
                record.state == JobState.QUEUED
                and record.resume_from in PIPELINE_STATES
                and new_state in PIPELINE_STATES
                and PIPELINE_STATES.index(new_state)
                < PIPELINE_STATES.index(record.resume_from)
            )
            if (
                record.state == JobState.QUEUED
                and new_state != JobState.CANCELED
                and new_state != JobState.FAILED
                and new_state != JobState.PROBING
                and record.resume_from != new_state
                and not (resume_checkpoint_invalidated and resume_rewind)
            ):
                raise InvalidJobTransition(
                    f"Queued job may only start at probing or its resume point; got {new_state.value}"
                )
            if resume_checkpoint_invalidated and not resume_rewind:
                raise InvalidJobTransition(
                    "Checkpoint-invalidated resume rewind must target an earlier pipeline stage"
                )
            if new_state not in ALLOWED_TRANSITIONS[record.state]:
                raise InvalidJobTransition(f"Cannot transition {record.state.value} -> {new_state.value}")
            retry_count = record.retry_count
            attempt_generation = record.attempt_generation
            retry_requested = record.retry_requested
            resume_from = record.resume_from
            progress = record.progress
            if record.state in {JobState.FAILED, JobState.CANCELED} and new_state == JobState.QUEUED:
                retry_count += 1
                if resume_from is None:
                    resume_from = self._resume_state(record)
                attempt_generation += 1
                retry_requested = False
                progress = self._resume_progress_floor(record)
            elif record.state == JobState.CREATED and new_state == JobState.QUEUED:
                attempt_generation += 1
                retry_requested = False
                progress = 0.0
            if record.state == JobState.QUEUED and (
                new_state == record.resume_from or resume_rewind
            ):
                resume_from = None
            updated = replace(
                record,
                state=new_state,
                updated_at=_utc_now(),
                revision=record.revision + 1,
                progress=1.0 if new_state == JobState.COMPLETED else progress,
                retry_count=retry_count,
                attempt_generation=attempt_generation,
                retry_requested=retry_requested,
                resume_from=resume_from,
                error=dict(error) if error is not None else None,
            )
            self._write(updated)
            return updated

    def update_progress(
        self,
        job_id: str,
        progress: float,
        *,
        expected_attempt_generation: int | None = None,
    ) -> JobRecord:
        if not 0.0 <= progress <= 1.0:
            raise ValueError("progress must be between 0 and 1")
        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            if record.state not in ACTIVE_JOB_STATES:
                raise InvalidJobTransition("progress can only be updated for an active job")
            updated = replace(
                record,
                progress=progress,
                updated_at=_utc_now(),
                revision=record.revision + 1,
            )
            self._write(updated)
            return updated

    def checkpoint(
        self,
        job_id: str,
        name: str,
        *,
        artifacts: Sequence[str | Path] = (),
        data: Mapping[str, Any] | None = None,
        expected_attempt_generation: int | None = None,
    ) -> JobRecord:
        if name not in CHECKPOINT_NAMES:
            raise ValueError(f"Unknown checkpoint: {name}")
        artifact_paths = tuple(str(Path(path).expanduser().resolve()) for path in artifacts)
        missing = [
            path
            for path in artifact_paths
            if not Path(path).is_file() or Path(path).is_symlink()
        ]
        if missing:
            raise FileNotFoundError(f"Checkpoint artifacts do not exist: {missing}")
        checkpoint_data = dict(data or {})
        if name != "probed":
            integrity_manifest: list[dict[str, Any]] = []
            for artifact_path in artifact_paths:
                path = Path(artifact_path)
                before = path.stat()
                digest = hashlib.sha256()
                with path.open("rb") as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(block)
                after = path.stat()
                if (
                    path.is_symlink()
                    or before.st_dev != after.st_dev
                    or before.st_ino != after.st_ino
                    or before.st_size != after.st_size
                    or before.st_mtime_ns != after.st_mtime_ns
                ):
                    raise OSError(f"Checkpoint artifact changed while sealing: {path}")
                integrity_manifest.append(
                    {
                        "path": artifact_path,
                        "size": after.st_size,
                        "sha256": digest.hexdigest(),
                    }
                )
            checkpoint_data["checkpoint_integrity_version"] = 1
            checkpoint_data["checkpoint_artifact_manifest"] = integrity_manifest
        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            checkpoints = dict(record.checkpoints)
            checkpoints[name] = JobCheckpoint(
                name=name,
                completed_at=_utc_now(),
                artifacts=artifact_paths,
                data=checkpoint_data,
            )
            updated = replace(
                record,
                checkpoints=checkpoints,
                updated_at=_utc_now(),
                revision=record.revision + 1,
            )
            self._write(updated)
            return updated

    def cancel(
        self,
        job_id: str,
        *,
        expected_attempt_generation: int | None = None,
    ) -> JobRecord:
        """Cancel the current attempt and revoke any pending retry command."""

        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            if record.state == JobState.CANCELED and not record.retry_requested:
                return record
            if (
                record.state != JobState.CANCELED
                and JobState.CANCELED not in ALLOWED_TRANSITIONS[record.state]
            ):
                raise InvalidJobTransition(
                    f"Cannot transition {record.state.value} -> {JobState.CANCELED.value}"
                )
            updated = replace(
                record,
                state=JobState.CANCELED,
                retry_requested=False,
                error=None,
                updated_at=_utc_now(),
                revision=record.revision + 1,
            )
            self._write(updated)
            return updated

    def retry(self, job_id: str) -> JobRecord:
        """Queue one new durable attempt, or return an already queued attempt."""

        record = self.get(job_id)
        if record.metadata.get("retry_blocked") is True:
            raise InvalidJobTransition("損壞嘅工作記錄已安全隔離，唔可以直接重試")
        if record.state == JobState.QUEUED:
            return record
        if record.state == JobState.COMPLETED:
            with self._locked():
                current = self._read(self._metadata_path(job_id))
                if current.revision != record.revision:
                    raise InvalidJobTransition(
                        f"stale revision for {job_id}: expected {record.revision}, "
                        f"got {current.revision}"
                    )
                resume_from = self._resume_state(current)
                if resume_from == JobState.COMPLETED:
                    raise InvalidJobTransition("Completed job artifacts are still valid")
                updated = replace(
                    current,
                    state=JobState.QUEUED,
                    attempt_generation=current.attempt_generation + 1,
                    retry_count=current.retry_count + 1,
                    retry_requested=False,
                    resume_from=resume_from,
                    progress=self._resume_progress_floor(current),
                    error={
                        "code": "completed_artifact_invalid",
                        "message": "A completed output was missing or changed; queued for repair",
                        "previous_state": JobState.COMPLETED.value,
                    },
                    updated_at=_utc_now(),
                    revision=current.revision + 1,
                )
                self._write(updated)
                return updated
        if record.state not in {JobState.CREATED, JobState.FAILED, JobState.CANCELED}:
            raise InvalidJobTransition(f"Cannot retry job in {record.state.value}")
        if record.state in {JobState.FAILED, JobState.CANCELED}:
            resume_from = self._resume_state(record)
            if resume_from == JobState.COMPLETED:
                with self._locked():
                    current = self._read(self._metadata_path(job_id))
                    self._assert_attempt(current, record.attempt_generation)
                    if current.revision != record.revision:
                        raise InvalidJobTransition(
                            f"stale revision for {job_id}: expected {record.revision}, "
                            f"got {current.revision}"
                        )
                    completed = replace(
                        current,
                        state=JobState.COMPLETED,
                        retry_requested=False,
                        resume_from=None,
                        progress=1.0,
                        error=None,
                        updated_at=_utc_now(),
                        revision=current.revision + 1,
                    )
                    self._write(completed)
                    return completed
        return self.transition(
            job_id,
            JobState.QUEUED,
            expected_revision=record.revision,
            expected_attempt_generation=record.attempt_generation,
        )

    def request_retry(
        self,
        job_id: str,
        *,
        expected_attempt_generation: int,
    ) -> JobRecord:
        """Persist retry intent without advancing ownership of a live attempt.

        The old runner remains the sole owner until it unwinds.  A graceful
        finish calls :meth:`fulfill_retry`; crash recovery performs the same
        generation advance from this durable flag.
        """

        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            if record.state == JobState.COMPLETED:
                raise InvalidJobTransition("Completed jobs cannot be retried")
            if record.retry_requested:
                return record
            if record.state not in {
                JobState.CREATED,
                JobState.QUEUED,
                *PIPELINE_STATES,
                JobState.FAILED,
                JobState.CANCELED,
            }:
                raise InvalidJobTransition(f"Cannot request retry in {record.state.value}")
            updated = replace(
                record,
                state=JobState.CANCELED,
                retry_requested=True,
                updated_at=_utc_now(),
                revision=record.revision + 1,
            )
            self._write(updated)
            return updated

    def fulfill_retry(
        self,
        job_id: str,
        *,
        expected_attempt_generation: int,
    ) -> JobRecord:
        """Consume one persisted retry request and advance generation once."""

        with self._locked():
            record = self._read(self._metadata_path(job_id))
            self._assert_attempt(record, expected_attempt_generation)
            if not record.retry_requested:
                return record
            resume_from = self._resume_state(record)
            completed = resume_from == JobState.COMPLETED
            updated = replace(
                record,
                state=JobState.COMPLETED if completed else JobState.QUEUED,
                attempt_generation=record.attempt_generation + (0 if completed else 1),
                retry_count=record.retry_count + (0 if completed else 1),
                retry_requested=False,
                resume_from=None if completed else resume_from,
                progress=1.0 if completed else self._resume_progress_floor(record),
                error=None,
                updated_at=_utc_now(),
                revision=record.revision + 1,
            )
            self._write(updated)
            return updated

    @staticmethod
    def _repair_timestamp_enriched_normalized_checkpoint(
        record: JobRecord,
    ) -> tuple[JobRecord, bool]:
        """Repair the one legacy seal invalidated by timestamp enrichment.

        Builds before 36 sealed ``final.json`` at normalization and then
        legitimately rewrote it with forced timestamps.  The timestamp and
        final envelopes both carry independent payload digests.  Only when
        those sealed payloads agree exactly do we refresh the normalized
        artifact manifest; every other mismatch remains a real integrity
        failure and requires an explicit user retry.
        """

        normalized = record.checkpoints.get("normalized")
        timestamps = record.checkpoints.get("timestamps")
        if (
            normalized is None
            or normalized.is_valid()
            or timestamps is None
            or not timestamps.is_valid()
            or len(normalized.artifacts) != 1
            or len(timestamps.artifacts) != 1
        ):
            return record, False
        try:
            workspace = Path(record.workspace).resolve(strict=True)
            final_path = Path(normalized.artifacts[0]).resolve(strict=True)
            timestamps_path = Path(timestamps.artifacts[0]).resolve(strict=True)
            final_path.relative_to(workspace)
            timestamps_path.relative_to(workspace)
            if final_path.is_symlink() or timestamps_path.is_symlink():
                return record, False
            final_envelope = _read_bounded_json(final_path)
            timestamp_envelope = _read_bounded_json(timestamps_path)
            if not isinstance(final_envelope, Mapping) or not isinstance(
                timestamp_envelope, Mapping
            ):
                return record, False
            final_value = final_envelope.get("value")
            timestamp_value = timestamp_envelope.get("value")
            completed_at = timestamp_envelope.get("processing_completed_at")
            final_fingerprint = final_envelope.get("fingerprint")
            if (
                final_envelope.get("schema") != 1
                or final_envelope.get("complete") is not True
                or not isinstance(final_value, Mapping)
                or not isinstance(final_fingerprint, str)
                or len(final_fingerprint) != 64
                or final_envelope.get("payload_sha256")
                != _sealed_json_digest(
                    {"fingerprint": final_fingerprint, "value": final_value}
                )
                or timestamp_envelope.get("schema") != 1
                or timestamp_envelope.get("complete") is not True
                or not isinstance(timestamp_value, Mapping)
                or not isinstance(completed_at, str)
                or not completed_at.endswith("Z")
                or timestamp_envelope.get("payload_sha256")
                != _sealed_json_digest(
                    {"value": timestamp_value, "processing_completed_at": completed_at}
                )
                or final_value.get("processing_completed_at") != completed_at
            ):
                return record, False
            metadata = final_value.get("metadata")
            if not isinstance(metadata, Mapping):
                return record, False
            if set(timestamp_value) == {
                "subtitle_segments",
                "word_timestamps",
                "character_timestamps",
                "audit",
            }:
                audit = timestamp_value.get("audit")
                if not isinstance(audit, Mapping):
                    return record, False
                expected_audit = dict(audit)
                expected_audit["enabled"] = True
                if (
                    final_value.get("subtitle_segments")
                    != timestamp_value.get("subtitle_segments")
                    or final_value.get("word_timestamps")
                    != timestamp_value.get("word_timestamps")
                    or final_value.get("character_timestamps")
                    != timestamp_value.get("character_timestamps")
                    or metadata.get("forced_timestamps") != expected_audit
                ):
                    return record, False
            elif set(timestamp_value) == {"metadata"}:
                timestamp_metadata = timestamp_value.get("metadata")
                if (
                    not isinstance(timestamp_metadata, Mapping)
                    or metadata.get("forced_timestamps") != timestamp_metadata
                ):
                    return record, False
            else:
                return record, False

            stat = final_path.stat()
            digest = hashlib.sha256()
            with final_path.open("rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(block)
            data = dict(normalized.data)
            data["checkpoint_integrity_version"] = 1
            data["checkpoint_artifact_manifest"] = [
                {
                    "path": str(final_path),
                    "size": stat.st_size,
                    "sha256": digest.hexdigest(),
                }
            ]
            checkpoints = dict(record.checkpoints)
            checkpoints["normalized"] = JobCheckpoint(
                name="normalized",
                completed_at=_utc_now(),
                artifacts=(str(final_path),),
                data=data,
            )
            return replace(record, checkpoints=checkpoints), True
        except (OSError, UnicodeError, ValueError, json.JSONDecodeError):
            return record, False

    @staticmethod
    def _terminal_completion_is_valid(record: JobRecord) -> bool:
        """Validate completed workspace outputs without requiring the source.

        A user is allowed to move or unmount the original recording after a
        job finishes.  Recovery therefore validates the workspace-owned final,
        timestamp and export artifacts only.  Modern checkpoints remain
        content-hash strict; pre-manifest jobs get a bounded legacy existence
        check so an upgrade preserves their completed history without silently
        starting a new model run.
        """

        normalized = record.checkpoints.get("normalized")
        exported = record.checkpoints.get("exported")
        if normalized is None or exported is None or not normalized.is_valid():
            return False
        modern_export = exported.data.get("checkpoint_integrity_version") == 1
        content_manifest_export = isinstance(
            exported.data.get("artifact_manifest"), list
        )
        if modern_export or content_manifest_export:
            timestamps = record.checkpoints.get("timestamps")
            return (
                (timestamps is not None or not modern_export)
                and (timestamps is None or timestamps.is_valid())
                and exported.is_valid()
            )
        try:
            workspace = Path(record.workspace).resolve(strict=True)
            exports_root = (workspace / "exports").resolve(strict=True)
            if len(exported.artifacts) != 1:
                return False
            marker_path = Path(exported.artifacts[0]).resolve(strict=True)
            marker_path.relative_to(workspace)
            if marker_path.is_symlink():
                return False
            marker = _read_bounded_json(marker_path)
            if (
                not isinstance(marker, Mapping)
                or marker.get("schema") != 1
                or marker.get("complete") is not True
                or not isinstance(marker.get("value"), Mapping)
                or not marker["value"]
            ):
                return False
            for raw_path in marker["value"].values():
                if not isinstance(raw_path, str):
                    return False
                output = Path(raw_path).resolve(strict=True)
                output.relative_to(exports_root)
                if output.is_symlink() or not output.is_file():
                    return False
            timestamps = record.checkpoints.get("timestamps")
            return timestamps is None or timestamps.is_valid()
        except (OSError, UnicodeError, ValueError, json.JSONDecodeError):
            return False

    @staticmethod
    def _resume_state(record: JobRecord) -> JobState:
        resume_state = JobState.PROBING
        for checkpoint_name, next_state in CHECKPOINT_SEQUENCE:
            checkpoint = record.checkpoints.get(checkpoint_name)
            if checkpoint is None or not checkpoint.is_valid():
                break
            resume_state = next_state
        return resume_state

    def recover_interrupted(self) -> tuple[JobRecord, ...]:
        recovered: list[JobRecord] = []
        with self._locked():
            for record in self._list_unlocked():
                record, timestamp_seal_repaired = (
                    self._repair_timestamp_enriched_normalized_checkpoint(record)
                )
                resume_from = self._resume_state(record)
                completed = resume_from == JobState.COMPLETED
                terminal_completed = self._terminal_completion_is_valid(record)
                recovery_error: Mapping[str, Any] | None = None
                attempt_generation = record.attempt_generation
                retry_count = record.retry_count

                if record.retry_requested:
                    # A retry click made while the old attempt was unwinding is
                    # a durable command, not an in-memory convenience flag.
                    new_state = JobState.COMPLETED if completed else JobState.QUEUED
                    if not completed:
                        attempt_generation += 1
                        retry_count += 1
                elif (
                    record.state == JobState.CREATED
                    and record.metadata.get("manual_hold") is not True
                ):
                    # jobs.create and jobs.start are separate protocol writes.
                    # Treat a persisted CREATED record as the queue transaction
                    # that was interrupted between those two writes.
                    new_state = JobState.QUEUED
                    attempt_generation += 1
                    resume_from = JobState.PROBING
                elif record.state in PIPELINE_STATES:
                    new_state = JobState.COMPLETED if completed else JobState.QUEUED
                    if not completed:
                        attempt_generation += 1
                        recovery_error = {
                            "code": "interrupted",
                            "message": "Job was interrupted and queued for checkpoint-aware resume",
                            "previous_state": record.state.value,
                        }
                elif record.state == JobState.QUEUED and record.attempt_generation == 0:
                    # Backward-compatible migration for jobs created before
                    # attempt generations existed.
                    new_state = JobState.QUEUED
                    attempt_generation = 1
                elif (
                    record.state == JobState.QUEUED
                    and isinstance(record.error, Mapping)
                    and record.error.get("code") == "completed_artifact_invalid"
                    and record.error.get("previous_state") == JobState.COMPLETED.value
                ):
                    # Builds before 36 automatically queued a damaged completed
                    # job.  Migrate that unsafe implicit action into either a
                    # proven completed record or an explicit failed row which
                    # waits for the user to press Retry.
                    new_state = (
                        JobState.COMPLETED if terminal_completed else JobState.FAILED
                    )
                    attempt_generation = max(0, attempt_generation - 1)
                    retry_count = max(0, retry_count - 1)
                    if not terminal_completed:
                        recovery_error = {
                            "code": "completed_artifact_invalid",
                            "message": (
                                "A completed output is missing or changed; "
                                "press Retry to repair it"
                            ),
                            "previous_state": JobState.COMPLETED.value,
                            "requires_user_retry": True,
                        }
                elif record.state == JobState.COMPLETED and not terminal_completed:
                    # A terminal label cannot outrank the sealed export
                    # manifest.  If a user moved/tampered with one output, the
                    # next launch repairs only from the first invalid
                    # checkpoint instead of presenting a hollow completed job.
                    new_state = JobState.FAILED
                    recovery_error = {
                        "code": "completed_artifact_invalid",
                        "message": (
                            "A completed output is missing or changed; "
                            "press Retry to repair it"
                        ),
                        "previous_state": JobState.COMPLETED.value,
                        "requires_user_retry": True,
                    }
                else:
                    if timestamp_seal_repaired:
                        updated = replace(
                            record,
                            updated_at=_utc_now(),
                            revision=record.revision + 1,
                        )
                        self._write(updated)
                        recovered.append(updated)
                    continue

                updated = replace(
                    record,
                    state=new_state,
                    resume_from=None if new_state == JobState.COMPLETED else resume_from,
                    attempt_generation=attempt_generation,
                    retry_count=retry_count,
                    retry_requested=False,
                    error=recovery_error,
                    progress=(
                        1.0
                        if new_state == JobState.COMPLETED
                        else self._resume_progress_floor(record)
                    ),
                    updated_at=_utc_now(),
                    revision=record.revision + 1,
                )
                self._write(updated)
                recovered.append(updated)
        return tuple(recovered)
