"""Private child entry point for the forced-alignment supervisor."""

from __future__ import annotations

import argparse
import json
import math
import os
import signal
import threading
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ..asr.types import AudioChunk
from .forced_process import (
    PROTOCOL_VERSION,
    atomic_write_json,
    completed_result_envelope,
    failed_result_envelope,
    load_request,
)
from .forced_timestamps import QwenForcedTimestampAligner


class _JSONLineWriter:
    def __init__(self, descriptor: int) -> None:
        self._handle = os.fdopen(
            descriptor, "w", encoding="utf-8", buffering=1, closefd=True
        )
        self._lock = threading.Lock()

    def emit(self, event: str, **values: Any) -> None:
        payload = {
            "protocol_version": PROTOCOL_VERSION,
            "event": event,
            **values,
        }
        encoded = json.dumps(
            payload,
            ensure_ascii=False,
            allow_nan=False,
            separators=(",", ":"),
        )
        with self._lock:
            self._handle.write(encoded + "\n")
            self._handle.flush()

    def close(self) -> None:
        with self._lock:
            self._handle.close()


def _watch_parent(expected_parent_pid: int, stop: threading.Event) -> None:
    while not stop.wait(0.25):
        if os.getppid() != expected_parent_pid:
            # The supervisor vanished before its bounded finally path.  Kill
            # the whole isolated session, including native/helper children.
            os.killpg(os.getpgrp(), signal.SIGKILL)
            os._exit(73)


def _heartbeat(writer: _JSONLineWriter, interval: float, stop: threading.Event) -> None:
    while not stop.wait(interval):
        writer.emit("heartbeat")


def _failure_category(exc: BaseException) -> str:
    if isinstance(exc, (ValueError, KeyError, TypeError)):
        return "protocol_error"
    if isinstance(exc, FileNotFoundError):
        return "input_error"
    if isinstance(exc, RuntimeError):
        return "runtime_error"
    return "child_crash"


def _public_error_type(category: str) -> str:
    """Return a stable label; never expose a third-party dynamic class name."""

    return {
        "protocol_error": "InputValidationError",
        "input_error": "LocalInputError",
        "runtime_error": "ForcedAlignmentRuntimeError",
        "child_crash": "ForcedAlignmentChildError",
    }.get(category, "ForcedAlignmentChildError")


def _local_chunk_fraction(
    global_fraction: float, *, chunk_index: int, chunk_total: int
) -> float:
    """Translate aligner-wide progress into the supervisor's per-chunk protocol.

    ``QwenForcedTimestampAligner`` reports the completed fraction of the whole
    alignment stage.  The process protocol deliberately tracks a separate
    monotonic 0..1 fraction for each chunk so that advancing to a later chunk
    can be validated fail-closed.  Keep that translation at this child boundary
    rather than weakening the supervisor's ordering checks.
    """

    if chunk_total <= 0 or chunk_index < 1 or chunk_index > chunk_total:
        raise ValueError("forced aligner progress chunk bounds are invalid")
    if not math.isfinite(global_fraction) or not 0.0 <= global_fraction <= 1.0:
        raise ValueError("forced aligner global progress is invalid")
    local = global_fraction * chunk_total - (chunk_index - 1)
    # The endpoints are produced by division in the aligner and can differ by
    # a few binary floating-point ulps after multiplying back by chunk_total.
    epsilon = 1e-9
    if local < -epsilon or local > 1.0 + epsilon:
        raise ValueError("forced aligner progress does not belong to its chunk")
    if abs(local) <= epsilon:
        return 0.0
    if abs(local - 1.0) <= epsilon:
        return 1.0
    return min(1.0, max(0.0, local))


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--event-fd", type=int, required=True)
    parser.add_argument("--chunk-fd", type=int, required=True)
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--heartbeat-seconds", type=float, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    if (
        arguments.parent_pid <= 1
        or not math.isfinite(arguments.heartbeat_seconds)
        or arguments.heartbeat_seconds <= 0
    ):
        return 64
    if os.getsid(0) != os.getpid() or os.getpgrp() != os.getpid():
        # The parent promises start_new_session=True.  Refuse to run if TERM or
        # KILL could target an unrelated process group.
        return 64

    event_writer = _JSONLineWriter(arguments.event_fd)
    chunk_writer = _JSONLineWriter(arguments.chunk_fd)
    stop = threading.Event()
    parent_thread = threading.Thread(
        target=_watch_parent,
        args=(arguments.parent_pid, stop),
        name="forced-parent-watch",
        daemon=True,
    )
    heartbeat_thread = threading.Thread(
        target=_heartbeat,
        args=(event_writer, arguments.heartbeat_seconds, stop),
        name="forced-heartbeat",
        daemon=True,
    )
    parent_thread.start()
    heartbeat_thread.start()
    request: Mapping[str, Any] | None = None
    try:
        request = load_request(arguments.request)
        event_writer.emit("ready")
        chunks = [AudioChunk.coerce(raw) for raw in request["chunks"]]
        chosen_segments = list(request["chosen_segments"])
        resume_chunks = list(request["resume_chunks"])
        ordinal = len(resume_chunks)

        def progress(event: Mapping[str, Any]) -> None:
            # Never forward arbitrary aligner fields: exception messages or
            # third-party metadata may contain transcript text.
            chunk_id = event.get("chunk_id")
            chunk_index = event.get("chunk_index")
            chunk_total = event.get("chunk_total")
            fraction = event.get("progress")
            if (
                not isinstance(chunk_id, str)
                or isinstance(chunk_index, bool)
                or not isinstance(chunk_index, int)
                or isinstance(chunk_total, bool)
                or not isinstance(chunk_total, int)
                or isinstance(fraction, bool)
                or not isinstance(fraction, (int, float))
                or not math.isfinite(float(fraction))
            ):
                raise ValueError("forced aligner progress event is invalid")
            local_fraction = _local_chunk_fraction(
                float(fraction),
                chunk_index=chunk_index,
                chunk_total=chunk_total,
            )
            event_writer.emit(
                "progress",
                chunk_id=chunk_id,
                chunk_index=chunk_index,
                chunk_total=chunk_total,
                fraction=local_fraction,
            )

        def chunk_completed(chunk: Any) -> None:
            nonlocal ordinal
            chunk_writer.emit(
                "chunk",
                request_id=str(request["request_id"]),
                ordinal=ordinal,
                chunk_id=str(chunk.chunk_id),
                chunk=chunk.to_dict(),
            )
            ordinal += 1

        adapter = QwenForcedTimestampAligner(
            Path(str(request["model_path"])),
            model_id=str(request["model_id"]),
            language=str(request["language"]),
        )
        result = adapter.align(
            chunks,
            chosen_segments,
            progress=progress,
            resume_chunks=resume_chunks,
            chunk_completed=chunk_completed,
        )
        atomic_write_json(
            arguments.result, completed_result_envelope(request, result)
        )
        event_writer.emit("stage_complete")
        return 0
    except Exception as exc:
        category = _failure_category(exc)
        error_type = _public_error_type(category)
        try:
            atomic_write_json(
                arguments.result,
                failed_result_envelope(
                    request, category=category, error_type=error_type
                ),
            )
            event_writer.emit(
                "error", category=category, error_type=error_type
            )
        except (BrokenPipeError, OSError):
            pass
        return 70
    finally:
        stop.set()
        parent_thread.join(timeout=0.5)
        heartbeat_thread.join(timeout=0.5)
        try:
            event_writer.close()
        except (BrokenPipeError, OSError):
            pass
        try:
            chunk_writer.close()
        except (BrokenPipeError, OSError):
            pass


if __name__ == "__main__":
    raise SystemExit(main())
