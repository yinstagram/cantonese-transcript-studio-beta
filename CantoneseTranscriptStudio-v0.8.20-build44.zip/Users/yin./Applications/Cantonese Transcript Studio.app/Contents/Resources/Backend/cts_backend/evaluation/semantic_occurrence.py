"""Full-context, time-free occurrence evidence and conservative ownership gates.

Integrity and non-conflicting ownership are provable here. Same occurrence is
still a reviewer's inference, NOT acoustic truth, same extent, or timing success.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Sequence

SCHEMA = 'cts.semantic-occurrence-context/v1'
RELATIONS = {'same_occurrence', 'different_occurrence', 'uncertain',
             'source_occurrence_missing_or_unresolved'}


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def _text_rows(rows: Sequence[Mapping[str, Any]], id_key: str) -> list[dict[str, Any]]:
    result, seen = [], set()
    for ordinal, row in enumerate(rows, 1):
        if set(row) != {id_key, 'ordinal', 'text', 'text_sha256'}:
            raise ValueError('unexpected context field; timing aliases are forbidden')
        if (isinstance(row['ordinal'], bool) or not isinstance(row['ordinal'], int) or row['ordinal'] != ordinal
                or not isinstance(row[id_key], str) or not row[id_key]
                or row[id_key] in seen or not isinstance(row['text'], str)):
            raise ValueError('invalid context identity/order')
        if hashlib.sha256(row['text'].encode()).hexdigest() != row['text_sha256']:
            raise ValueError('context text hash mismatch')
        seen.add(row[id_key])
        result.append(dict(row))
    if not result:
        raise ValueError('full context cannot be empty')
    return result


def build_context_packet(references: Sequence[Mapping[str, Any]], atoms: Sequence[Mapping[str, Any]],
                         *, expected_reference_count: int, expected_atom_count: int) -> dict[str, Any]:
    if any(isinstance(n, bool) or not isinstance(n, int) or n <= 0
           for n in (expected_reference_count, expected_atom_count)):
        raise ValueError('full context counts must be positive integers')
    refs, source = _text_rows(references, 'unit_id'), _text_rows(atoms, 'atom_id')
    if len(refs) != expected_reference_count or len(source) != expected_atom_count:
        raise ValueError('full conversational context is incomplete')
    packet = {'schema': SCHEMA, 'reference_units': refs, 'source_atoms': source,
              'full_reference_count': len(refs), 'full_source_atom_count': len(source),
              'reference_segmentation_may_derive_from_timing': True,
              'timing_values_included': False}
    return {**packet, 'packet_sha256': digest(packet)}


def validate_context_packet(packet: Mapping[str, Any]) -> None:
    expected = build_context_packet(packet['reference_units'], packet['source_atoms'],
                                   expected_reference_count=packet['full_reference_count'],
                                   expected_atom_count=packet['full_source_atom_count'])
    if dict(packet) != expected:
        raise ValueError('context seal/schema mismatch')


def build_occurrence_ledger(packet: Mapping[str, Any], review: Mapping[str, Any]) -> dict[str, Any]:
    validate_context_packet(packet)
    if (set(review) != {'schema', 'packet_sha256', 'reviewer_id', 'full_context_provided',
                       'context_truncated', 'judgments'}
            or review['schema'] != 'cts.semantic-occurrence-review/v1'
            or review['packet_sha256'] != packet['packet_sha256']
            or review['full_context_provided'] is not True or review['context_truncated'] is not False
            or not isinstance(review['reviewer_id'], str) or not review['reviewer_id']
            or not isinstance(review['judgments'], list)):
        raise ValueError('review must bind complete untruncated context')
    refs = {r['unit_id']: r for r in packet['reference_units']}
    atoms = {r['atom_id']: r for r in packet['source_atoms']}
    rows = {key: {'unit_id': key, 'status': 'not_reviewed', 'judgment': None,
                  'conflicts_with': [], 'occurrence_evidence_eligible': False} for key in refs}
    seen = set()
    fields = {'unit_id', 'relation', 'selected_atom_ids', 'context_reference_ids',
              'context_atom_ids', 'competing_reference_ids', 'reason'}
    for raw in review['judgments']:
        if not isinstance(raw, Mapping) or set(raw) != fields:
            raise ValueError('review judgment schema mismatch')
        unit = raw['unit_id']
        if not isinstance(unit, str) or unit not in refs or unit in seen:
            raise ValueError('duplicate/unknown reference judgment')
        seen.add(unit)
        if raw['relation'] not in RELATIONS or not isinstance(raw['reason'], str):
            raise ValueError('invalid occurrence relation/reason')
        for key, allowed in [('selected_atom_ids', atoms), ('context_atom_ids', atoms),
                             ('context_reference_ids', refs), ('competing_reference_ids', refs)]:
            values = raw[key]
            if (not isinstance(values, list) or any(not isinstance(v, str) or v not in allowed for v in values)
                    or len(set(values)) != len(values)):
                raise ValueError('invalid evidence identity')
        selected = raw['selected_atom_ids']
        positions = [atoms[key]['ordinal'] for key in selected]
        if positions and positions != list(range(positions[0], positions[-1] + 1)):
            raise ValueError('selected source must be contiguous and ordered')
        if unit in raw['competing_reference_ids']:
            raise ValueError('reference cannot compete with itself')
        if raw['relation'] == 'same_occurrence':
            if (not selected or not any(key != unit for key in raw['context_reference_ids'])
                    or not set(raw['context_atom_ids']).difference(selected)):
                raise ValueError('same occurrence needs distinct conversational context')
        rows[unit].update(status=raw['relation'], judgment=dict(raw),
                          occurrence_evidence_eligible=raw['relation'] == 'same_occurrence')
    proposed = [row for row in rows.values() if row['occurrence_evidence_eligible']]
    conflicts = {key: set() for key in rows}
    # An uncertain/partial reviewer may identify a competitor that another
    # positive row omitted. Such evidence cannot disappear just because the
    # first row was not a positive proposal.
    for row in rows.values():
        if row['judgment'] is None:
            continue
        unit, judgment = row['unit_id'], row['judgment']
        for competitor in judgment['competing_reference_ids']:
            conflicts[unit].add(competitor)
            conflicts[competitor].add(unit)
    for i, left in enumerate(proposed):
        for right in proposed[i + 1:]:
            a, b = left['unit_id'], right['unit_id']
            left_positions = [atoms[key]['ordinal'] for key in left['judgment']['selected_atom_ids']]
            right_positions = [atoms[key]['ordinal'] for key in right['judgment']['selected_atom_ids']]
            # Rows are in full reference order. Crossing/overlap rejects both;
            # there is deliberately no maximum-cardinality or distance winner.
            if max(left_positions) >= min(right_positions):
                conflicts[a].add(b)
                conflicts[b].add(a)
    for unit, others in conflicts.items():
        if others:
            rows[unit]['status'] = 'conflict'
            rows[unit]['occurrence_evidence_eligible'] = False
            rows[unit]['conflicts_with'] = sorted(others, key=lambda key: refs[key]['ordinal'])
    ledger = {'schema': 'cts.semantic-occurrence-ledger/v1', 'packet_sha256': packet['packet_sha256'],
              'review_sha256': digest(review), 'claim_type': 'INFERENCE', 'rows': list(rows.values()),
              'full_reference_count': len(refs), 'reviewed_count': len(seen),
              'review_coverage_complete': len(seen) == len(refs),
              'ownership_scope': 'all_submitted_judgments_not_unreviewed_references',
              'occurrence_evidence_count': sum(row['occurrence_evidence_eligible'] for row in rows.values()),
              'same_extent_verified': False, 'acoustic_truth_verified': False,
              'timing_accuracy_accepted': False}
    return {**ledger, 'ledger_sha256': digest(ledger)}


def merge_occurrence_reviews(packet: Mapping[str, Any], reviews: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Combine disjoint batches BEFORE checking ownership, never merge ledgers.

    Duplicate units (including two independent reviewers of the same unit) must
    be resolved separately; silently choosing one would conceal disagreement.
    The caller must retain the input reviews and their hashes with this result.
    """
    if not reviews:
        raise ValueError('no occurrence review batches')
    judgments, seen = [], set()
    for review in reviews:
        build_occurrence_ledger(packet, review)
        for judgment in review['judgments']:
            if judgment['unit_id'] in seen:
                raise ValueError('overlapping review units cannot be silently merged')
            seen.add(judgment['unit_id'])
            judgments.append(dict(judgment))
    order = {r['unit_id']: r['ordinal'] for r in packet['reference_units']}
    judgments.sort(key=lambda row: order[row['unit_id']])
    return {'schema': 'cts.semantic-occurrence-review/v1', 'packet_sha256': packet['packet_sha256'],
            'reviewer_id': 'merged-disjoint-batches:' + digest(sorted(digest(r) for r in reviews)),
            'full_context_provided': True, 'context_truncated': False, 'judgments': judgments}
