"""Durable, low-memory audio windows dedicated to forced alignment.

Recognition chunks optimize ASR latency and crash recovery.  Forced alignment
needs wider acoustic context, especially around a word that crosses an ASR
chunk seam.  This module creates and validates a separate sequential window
plan without touching the source WAV or retaining audio in memory.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import time
import wave
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..asr.types import ASRCancelled, AudioChunk
from ..audio.chunking import _copy_wave_range, _validate_pcm_wav
from ..constants import CHUNK_PLAN_FILENAME
from ..schemas import ChunkPlan, ChunkSpec


ALIGNMENT_WINDOW_POLICY_VERSION = "qwen3-forced-alignment-windows-v3"
# Qwen's official forced-aligner contract supports up to five minutes, but a
# final reconciliation segment is normally far shorter.  One disk-backed
# window per segment prevents a long multi-sentence prompt from causing large
# timestamp excursions while retaining a small amount of acoustic context.
ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS = 300.0
ALIGNMENT_WINDOW_CONTEXT_SECONDS = 0.25
ALIGNMENT_WINDOW_STRATEGY = "one_window_per_reconciled_segment"
ALIGNMENT_WINDOW_MANIFEST = "alignment-window-manifest.json"

Cancelled = Callable[[], bool]


def _cancel(cancelled: Cancelled | None) -> None:
    if cancelled is not None and cancelled():
        raise ASRCancelled("已取消 forced timestamp alignment")


def _sha256(path: Path, *, cancelled: Cancelled | None) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(1024 * 1024):
            _cancel(cancelled)
            digest.update(block)
    return digest.hexdigest()


def _atomic_json(
    path: Path,
    value: Mapping[str, Any],
    *,
    cancelled: Cancelled | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            json.dump(value, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        # Cancellation observed before the atomic commit means the cache was
        # never sealed.  This is the final fail-closed boundary after every
        # chunk/hash has completed but before a later run could reuse it.
        _cancel(cancelled)
        os.replace(temporary, path)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _source_identity(source: Path, *, cancelled: Cancelled | None) -> dict[str, Any]:
    stat = source.stat()
    return {
        "path": str(source),
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "sha256": _sha256(source, cancelled=cancelled),
    }


def _to_audio_chunks(plan: ChunkPlan) -> list[AudioChunk]:
    return [
        AudioChunk(
            id=f"alignment-{item.index:05d}",
            path=Path(item.path),
            start=item.start_ms / 1000.0,
            end=item.end_ms / 1000.0,
            index=item.index,
            core_start=item.core_start_ms / 1000.0,
            core_end=item.core_end_ms / 1000.0,
        )
        for item in plan.chunks
    ]


def _ranges_identity(segment_ranges_ms: Sequence[tuple[int, int]]) -> dict[str, Any]:
    encoded = json.dumps(list(segment_ranges_ms), separators=(",", ":")).encode("ascii")
    return {
        "segment_range_count": len(segment_ranges_ms),
        "segment_ranges_sha256": hashlib.sha256(encoded).hexdigest(),
    }


def _coerce_segment_ranges(
    values: Sequence[tuple[int, int]],
) -> tuple[tuple[int, int], ...]:
    output: list[tuple[int, int]] = []
    previous_end = 0
    for index, value in enumerate(values):
        if not isinstance(value, (list, tuple)) or len(value) != 2:
            raise ValueError(f"alignment segment range {index} 必須係 start/end pair")
        start_ms, end_ms = value
        if any(
            isinstance(item, bool) or not isinstance(item, int)
            for item in (start_ms, end_ms)
        ):
            raise ValueError(f"alignment segment range {index} 必須係整數毫秒")
        if start_ms < previous_end or end_ms <= start_ms:
            raise ValueError(f"alignment segment range {index} 必須單調而且有正長度")
        output.append((start_ms, end_ms))
        previous_end = end_ms
    if not output:
        raise ValueError("forced alignment 至少需要一個非空 segment range")
    return tuple(output)


def _build_segment_window_plan(
    source: Path,
    output_dir: Path,
    *,
    segment_ranges_ms: Sequence[tuple[int, int]],
    cancelled: Cancelled | None,
) -> ChunkPlan:
    """Create one low-memory PCM window per reconciled transcript segment."""

    with wave.open(str(source), "rb") as reader:
        _validate_pcm_wav(reader)
        sample_rate = reader.getframerate()
        total_frames = reader.getnframes()
    if total_frames <= 0:
        raise ValueError("forced alignment source WAV 係空白")
    total_duration_ms = round(total_frames / sample_rate * 1000)
    context_frames = round(ALIGNMENT_WINDOW_CONTEXT_SECONDS * sample_rate)
    chunks: list[ChunkSpec] = []
    for index, (raw_start_ms, raw_end_ms) in enumerate(segment_ranges_ms):
        _cancel(cancelled)
        if raw_end_ms > total_duration_ms:
            raise ValueError(f"alignment segment range {index} 超出音訊長度")
        core_start = round(raw_start_ms / 1000 * sample_rate)
        core_end = round(raw_end_ms / 1000 * sample_rate)
        actual_start = max(0, core_start - context_frames)
        actual_end = min(total_frames, core_end + context_frames)
        chunk_path = output_dir / f"chunk-{index:05d}.wav"
        try:
            _copy_wave_range(
                source,
                chunk_path,
                start_frame=actual_start,
                end_frame=actual_end,
                cancel_requested=cancelled,
            )
        except InterruptedError as exc:
            raise ASRCancelled("已取消 forced timestamp alignment") from exc
        chunks.append(
            ChunkSpec(
                index=index,
                path=str(chunk_path),
                start_ms=round(actual_start / sample_rate * 1000),
                end_ms=round(actual_end / sample_rate * 1000),
                core_start_ms=round(core_start / sample_rate * 1000),
                core_end_ms=round(core_end / sample_rate * 1000),
            )
        )
    plan = ChunkPlan(
        source_path=str(source),
        sample_rate=sample_rate,
        total_duration_ms=total_duration_ms,
        overlap_ms=round(ALIGNMENT_WINDOW_CONTEXT_SECONDS * 1000),
        chunks=tuple(chunks),
    )
    _atomic_json(
        output_dir / CHUNK_PLAN_FILENAME,
        plan.to_dict(),
        cancelled=cancelled,
    )
    return plan


def _manifest_for(
    source: Path,
    plan: ChunkPlan,
    *,
    segment_ranges_ms: Sequence[tuple[int, int]],
    cancelled: Cancelled | None,
) -> dict[str, Any]:
    chunks = _to_audio_chunks(plan)
    return {
        "schema": 1,
        "policy_version": ALIGNMENT_WINDOW_POLICY_VERSION,
        "source": _source_identity(source, cancelled=cancelled),
        "settings": {
            "strategy": ALIGNMENT_WINDOW_STRATEGY,
            "context_seconds": ALIGNMENT_WINDOW_CONTEXT_SECONDS,
            "max_segment_seconds": ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS,
            **_ranges_identity(segment_ranges_ms),
        },
        "plan": {
            "path": CHUNK_PLAN_FILENAME,
            "sha256": _sha256(Path(plan.chunks[0].path).parent / CHUNK_PLAN_FILENAME, cancelled=cancelled),
        },
        "chunks": [
            {
                "id": item.id,
                "path": Path(item.path).name,
                "size": Path(item.path).stat().st_size,
                "sha256": _sha256(Path(item.path), cancelled=cancelled),
                "start_ms": round(item.start * 1000),
                "end_ms": round(item.end * 1000),
                "core_start_ms": round(item.transcript_start * 1000),
                "core_end_ms": round(item.transcript_end * 1000),
            }
            for item in chunks
        ],
    }


def _load_valid(
    source: Path,
    output_dir: Path,
    *,
    segment_ranges_ms: Sequence[tuple[int, int]],
    cancelled: Cancelled | None,
) -> list[AudioChunk] | None:
    manifest_path = output_dir / ALIGNMENT_WINDOW_MANIFEST
    plan_path = output_dir / CHUNK_PLAN_FILENAME
    if (
        not manifest_path.is_file()
        or manifest_path.is_symlink()
        or not plan_path.is_file()
        or plan_path.is_symlink()
    ):
        return None
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        plan = ChunkPlan.from_dict(json.loads(plan_path.read_text(encoding="utf-8")))
        if not isinstance(manifest, dict):
            return None
        expected_settings = {
            "strategy": ALIGNMENT_WINDOW_STRATEGY,
            "context_seconds": ALIGNMENT_WINDOW_CONTEXT_SECONDS,
            "max_segment_seconds": ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS,
            **_ranges_identity(segment_ranges_ms),
        }
        if (
            manifest.get("schema") != 1
            or manifest.get("policy_version") != ALIGNMENT_WINDOW_POLICY_VERSION
            or manifest.get("settings") != expected_settings
            or manifest.get("source") != _source_identity(source, cancelled=cancelled)
            or plan.source_path != str(source)
            or plan.overlap_ms != round(ALIGNMENT_WINDOW_CONTEXT_SECONDS * 1000)
        ):
            return None
        plan_manifest = manifest.get("plan")
        if not isinstance(plan_manifest, dict) or plan_manifest.get("path") != CHUNK_PLAN_FILENAME:
            return None
        if plan_manifest.get("sha256") != _sha256(plan_path, cancelled=cancelled):
            return None
        chunks = _to_audio_chunks(plan)
        records = manifest.get("chunks")
        if not isinstance(records, list) or len(records) != len(chunks) or not chunks:
            return None
        for chunk, record in zip(chunks, records):
            if not isinstance(record, dict):
                return None
            path = chunk.path
            if path.parent != output_dir or path.is_symlink() or not path.is_file():
                return None
            expected = {
                "id": chunk.id,
                "path": path.name,
                "size": path.stat().st_size,
                "sha256": _sha256(path, cancelled=cancelled),
                "start_ms": round(chunk.start * 1000),
                "end_ms": round(chunk.end * 1000),
                "core_start_ms": round(chunk.transcript_start * 1000),
                "core_end_ms": round(chunk.transcript_end * 1000),
            }
            if record != expected:
                return None
        return chunks
    except (OSError, UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError):
        return None


def prepare_alignment_windows(
    source_path: str | Path,
    output_dir: str | Path,
    *,
    segment_ranges_ms: Sequence[tuple[int, int]],
    cancelled: Cancelled | None = None,
) -> list[AudioChunk]:
    """Return a sealed reusable forced-alignment window plan."""

    raw_source = Path(source_path).expanduser()
    if raw_source.is_symlink():
        raise ValueError("forced alignment source 唔可以係 symlink")
    source = raw_source.resolve(strict=True)
    output = Path(output_dir).expanduser().resolve()
    ranges = _coerce_segment_ranges(segment_ranges_ms)
    _cancel(cancelled)
    cached = _load_valid(
        source,
        output,
        segment_ranges_ms=ranges,
        cancelled=cancelled,
    )
    if cached is not None:
        return cached

    if output.exists():
        quarantine = output.with_name(
            f"{output.name}.invalid-{time.time_ns()}-{os.getpid()}"
        )
        os.replace(output, quarantine)
    output.mkdir(parents=True, exist_ok=False)
    try:
        plan = _build_segment_window_plan(
            source,
            output,
            segment_ranges_ms=ranges,
            cancelled=cancelled,
        )
    except InterruptedError as exc:
        raise ASRCancelled("已取消 forced timestamp alignment") from exc
    manifest = _manifest_for(
        source, plan, segment_ranges_ms=ranges, cancelled=cancelled
    )
    _atomic_json(
        output / ALIGNMENT_WINDOW_MANIFEST,
        manifest,
        cancelled=cancelled,
    )
    chunks = _load_valid(
        source, output, segment_ranges_ms=ranges, cancelled=cancelled
    )
    if chunks is None:
        raise ValueError("forced alignment window manifest 驗證失敗")
    return chunks


__all__ = [
    "ALIGNMENT_WINDOW_CONTEXT_SECONDS",
    "ALIGNMENT_WINDOW_MANIFEST",
    "ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS",
    "ALIGNMENT_WINDOW_POLICY_VERSION",
    "ALIGNMENT_WINDOW_STRATEGY",
    "prepare_alignment_windows",
]
