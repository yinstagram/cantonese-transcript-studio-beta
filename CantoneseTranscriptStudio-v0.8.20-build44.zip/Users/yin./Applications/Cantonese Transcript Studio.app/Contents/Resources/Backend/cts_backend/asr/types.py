from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Mapping


class ASRCancelled(RuntimeError):
    pass


@dataclass(frozen=True)
class AudioChunk:
    id: str
    path: Path
    start: float
    end: float
    index: int = 0
    core_start: float | None = None
    core_end: float | None = None

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)

    @property
    def transcript_start(self) -> float:
        return self.start if self.core_start is None else self.core_start

    @property
    def transcript_end(self) -> float:
        return self.end if self.core_end is None else self.core_end

    @classmethod
    def coerce(cls, value: "AudioChunk | Mapping[str, Any] | Any") -> "AudioChunk":
        if isinstance(value, cls):
            return value
        if isinstance(value, Mapping):
            getter = value.get
        else:
            getter = lambda key, default=None: getattr(value, key, default)
        path = Path(getter("path"))
        raw_start_ms = getter("start_ms", None)
        raw_end_ms = getter("end_ms", None)
        start = (
            float(raw_start_ms) / 1000.0
            if raw_start_ms is not None
            else float(getter("start", getter("start_time", 0.0)))
        )
        end = getter("end", getter("end_time", None))
        if end is None and raw_end_ms is not None:
            end = float(raw_end_ms) / 1000.0
        if end is None:
            duration = getter("duration", None)
            if duration is None and getter("duration_ms", None) is not None:
                duration = float(getter("duration_ms")) / 1000.0
            if duration is None:
                raise ValueError(f"chunk 缺少 end/duration：{path}")
            end = start + float(duration)
        index = int(getter("index", 0) or 0)
        identifier = str(getter("id", getter("chunk_id", f"chunk-{index:05d}" if index else path.stem)))
        core_start_ms = getter("core_start_ms", None)
        core_end_ms = getter("core_end_ms", None)
        core_start = getter("core_start", None)
        core_end = getter("core_end", None)
        if core_start is None and core_start_ms is not None:
            core_start = float(core_start_ms) / 1000.0
        if core_end is None and core_end_ms is not None:
            core_end = float(core_end_ms) / 1000.0
        return cls(
            id=identifier,
            path=path,
            start=start,
            end=float(end),
            index=index,
            core_start=float(core_start) if core_start is not None else None,
            core_end=float(core_end) if core_end is not None else None,
        )


@dataclass
class VerifierToken:
    token: str
    timestamp: float
    log_probability: float | None = None


@dataclass
class TranscriptSegment:
    id: str
    start: float
    end: float
    text: str
    language: str = "Cantonese"
    source: str = "primary"
    tokens: list[VerifierToken] = field(default_factory=list)
    truncated: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def segments_to_dict(segments: list[TranscriptSegment]) -> list[dict[str, Any]]:
    return [item.to_dict() for item in segments]
