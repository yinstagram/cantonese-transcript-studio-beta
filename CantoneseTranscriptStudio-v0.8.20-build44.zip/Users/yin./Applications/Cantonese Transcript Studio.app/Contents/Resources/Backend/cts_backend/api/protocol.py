"""Strict version-1 JSONL protocol helpers."""

from __future__ import annotations

import json
from typing import Any


class ProtocolError(ValueError):
    def __init__(self, code: str, message: str, request_id: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.request_id = request_id


def parse_request(line: str) -> dict[str, Any]:
    try:
        request = json.loads(line)
    except json.JSONDecodeError as exc:
        raise ProtocolError("invalid_json", "收到嘅資料唔係有效 JSON") from exc
    if not isinstance(request, dict):
        raise ProtocolError("invalid_request", "request 必須係 JSON object")
    request_id = request.get("id")
    if request.get("v") != 1:
        raise ProtocolError("unsupported_version", "只支援 protocol v1", request_id)
    if not isinstance(request_id, str) or not request_id:
        raise ProtocolError("invalid_request", "request 缺少 id")
    method = request.get("method")
    if not isinstance(method, str) or not method:
        raise ProtocolError("invalid_request", "request 缺少 method", request_id)
    params = request.get("params", {})
    if not isinstance(params, dict):
        raise ProtocolError("invalid_input", "params 必須係 JSON object", request_id)
    return {"v": 1, "id": request_id, "method": method, "params": params}


def result_message(request_id: str, result: Any) -> dict[str, Any]:
    return {"v": 1, "id": request_id, "type": "result", "result": result}


def error_message(request_id: str | None, code: str, message: str) -> dict[str, Any]:
    value: dict[str, Any] = {
        "v": 1,
        "type": "error",
        "error": {"code": code, "message": message},
    }
    if request_id is not None:
        value["id"] = request_id
    return value


def event_message(event: str, **payload: Any) -> dict[str, Any]:
    return {"v": 1, "type": "event", "event": event, **payload}
