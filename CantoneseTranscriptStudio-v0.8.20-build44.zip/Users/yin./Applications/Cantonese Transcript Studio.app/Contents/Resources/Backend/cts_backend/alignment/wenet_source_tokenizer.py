"""Experimental, source-preserving WeNet BPE target construction.

No subtitle is rewritten. OpenCC t2s and punctuation-to-space are explicit
model-input policies, NOT upstream WeNet defaults or semantic equivalence.
OOVs abstain the entire selected segment; <unk> is never forced to a clock.
SentencePiece IDs are diagnostic only: the acoustic IDs come from tokens.txt.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata
from pathlib import Path
from typing import Any, Mapping


BPE_SHA256 = "ee1b3b4dbe74bbad77f76efd271577db44377ca5a502a8aa44ac4d7dfd58c2d2"
TOKENS_SHA256 = "c7750677a1183606d2fd6f16d792e06e70d9843dba8a0c6e23a9dec78e06977a"
BASIC_CJK = re.compile(r"([\u4e00-\u9fff])")


def load_source_tokenizer(bpe_path: Path, tokens_path: Path) -> tuple[Any, Any]:
    import sentencepiece
    from opencc import OpenCC

    for path, expected in ((bpe_path, BPE_SHA256), (tokens_path, TOKENS_SHA256)):
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"experimental tokenizer asset SHA mismatch: {path.name}")
    return sentencepiece.SentencePieceProcessor(model_file=str(bpe_path)), OpenCC("t2s")


def tokenize_source(
    raw_text: str, *, by_token: Mapping[str, int], sentencepiece: Any, converter: Any
) -> dict[str, Any]:
    """Mirror upstream CJK/BPE split after declared model-only preprocessing.

    Immutable-proto offsets are validated against each exact input substring;
    codepoint maps retain expansions (e.g. ß -> SS) and repeated occurrences.
    A zero-width SentencePiece dummy prefix is a real model token but owns no
    raw character, so it can never invent a source/display edge.
    """
    if not isinstance(raw_text, str):
        raise ValueError("source text must be a string")
    for name in ("<blank>", "<unk>", "<sos/eos>"):
        if name not in by_token:
            raise ValueError("missing acoustic special token")
    model_chars: list[str] = []
    owners: list[int] = []
    transformations: list[dict[str, Any]] = []
    ignored: list[int] = []
    issues: list[dict[str, Any]] = []
    spoken_indices: list[int] = []
    for index, char in enumerate(raw_text):
        category = unicodedata.category(char)
        if char.isspace() or category.startswith("P"):
            converted = " "
            ignored.append(index)
        else:
            spoken_indices.append(index)
            if category.startswith("C"):
                issues.append({"reason": "unsupported_control", "raw_indices": [index]})
            converted = converter.convert(char).upper()
            if not converted or converted.isspace():
                issues.append({"reason": "source_character_erased", "raw_indices": [index]})
        if converted != char:
            transformations.append({"raw_index": index, "raw": char, "model": converted})
        model_chars.extend(converted)
        owners.extend([index] * len(converted))
    model_text = "".join(model_chars)
    rows: list[dict[str, Any]] = []
    cursor = 0
    covered: set[int] = set()
    for span in BASIC_CJK.split(model_text):
        start = cursor
        cursor += len(span)
        if not span or span.isspace():
            continue
        if BASIC_CJK.fullmatch(span):
            pieces = [(span, None, span, 0, 1)]
        else:
            proto = sentencepiece.encode(span, out_type="immutable_proto")
            pieces = [(p.piece, p.id, p.surface, p.begin, p.end) for p in proto.pieces]
            if [p[0] for p in pieces] != sentencepiece.encode_as_pieces(span):
                raise ValueError("SentencePiece proto/pieces disagree")
        previous_end = 0
        for piece, sp_id, surface, begin, end in pieces:
            if not (0 <= begin <= end <= len(span)) or span[begin:end] != surface:
                raise ValueError("SentencePiece offset/surface mismatch")
            if begin < previous_end:
                raise ValueError("SentencePiece offsets overlap")
            previous_end = end
            raw_indices = sorted({owners[i] for i in range(start + begin, start + end)
                                  if not model_text[i].isspace()})
            is_dummy = begin == end and piece == "▁"
            if begin == end and not is_dummy:
                issues.append({"reason": "unsupported_zero_width_piece", "piece": piece,
                               "raw_indices": raw_indices})
            token_id = by_token.get(piece)
            unknown = (token_id is None or token_id in {
                by_token["<blank>"], by_token["<unk>"], by_token["<sos/eos>"]
            } or (sp_id is not None and sp_id == sentencepiece.unk_id()))
            if unknown:
                issues.append({"reason": "out_of_vocabulary", "piece": piece,
                               "raw_indices": raw_indices,
                               "raw_text": "".join(raw_text[i] for i in raw_indices)})
            else:
                covered.update(raw_indices)
            rows.append({"token_index": len(rows), "piece": piece,
                         "token_id": None if unknown else token_id,
                         "sentencepiece_id_diagnostic_only": sp_id,
                         "model_start": start + begin, "model_end": start + end,
                         "surface": surface, "raw_indices": raw_indices,
                         "raw_text": "".join(raw_text[i] for i in raw_indices),
                         "zero_width_dummy_prefix": is_dummy})
    missing = sorted(set(spoken_indices) - covered)
    if missing:
        issues.append({"reason": "uncovered_source_characters", "raw_indices": missing})
    if not spoken_indices or not rows:
        issues.append({"reason": "empty_spoken_target"})
    return {
        "schema": "cts.wenet-source-tokenization/v1", "raw_text": raw_text,
        "raw_text_sha256": hashlib.sha256(raw_text.encode()).hexdigest(),
        "model_text": model_text, "model_character_raw_indices": owners,
        "raw_spoken_indices": spoken_indices, "ignored_punctuation_or_space_indices": ignored,
        "transformations": transformations, "tokens": rows, "issues": issues,
        "complete_tokenization": not issues,
        "policy": {"upstream_split": "basic_cjk_direct_else_sentencepiece_pieces",
                   "model_only_orthography": "per_codepoint_opencc_t2s_then_uppercase",
                   "punctuation": "unicode_P_and_whitespace_replaced_with_space",
                   "subtitle_text_rewritten": False, "oov": "whole_segment_abstention",
                   "acoustic_id_source": "tokens.txt_not_sentencepiece_ids",
                   "semantic_equivalence_proven": False,
                   "source_boundary_precision": "shared_piece_interval_not_per_letter_acoustics"},
    }


def align_source_diagnostic(
    matrix: Any, tokenization: Mapping[str, Any], *, frame_step_ms: int,
    wrapper_reproduction_pass: bool,
) -> dict[str, Any]:
    from cts_backend.alignment.ctc_posterior import force_align_ctc

    result: dict[str, Any] = {
        "schema": "cts.wenet-full-source-ctc-diagnostic/v1",
        "tokenization": dict(tokenization), "path_computed": False,
        "timing_accuracy_proven": False, "automatic_timing_mutation": False,
        "end_semantics": "ctc_emission_end_not_phonation_or_display_end",
        "reference_clocks_accepted_by_this_function": False,
        "source_role": "caller_selected_text_no_provenance_inferred",
        "abstentions": [], "tokens": [],
    }
    if not wrapper_reproduction_pass:
        result["abstentions"].append("wrapper_reproduction_gate_failed")
    if tokenization.get("complete_tokenization") is not True:
        result["abstentions"].append("whole_source_tokenization_incomplete")
    if result["abstentions"]:
        return result
    import numpy as np
    matrix = np.asarray(matrix)
    if matrix.ndim != 2 or not matrix.size or not np.all(np.isfinite(matrix)):
        raise ValueError("expected finite frame by vocabulary matrix")
    row_max = np.max(matrix, axis=1)
    logsum = row_max + np.log(np.exp(matrix - row_max[:, None]).sum(axis=1))
    if float(np.max(matrix)) > 1e-5 or float(np.max(np.abs(logsum))) > 1e-3:
        raise ValueError("posterior must contain normalized log probabilities")
    rows = tokenization["tokens"]
    ids = [row["token_id"] for row in rows]
    if any(isinstance(value, bool) or not isinstance(value, int) or value in {0, 1, 8628}
           for value in ids):
        raise ValueError("full source contains invalid or special acoustic token IDs")
    if isinstance(frame_step_ms, bool) or not isinstance(frame_step_ms, int) or frame_step_ms <= 0:
        raise ValueError("frame step must be positive integer milliseconds")
    try:
        alignment = force_align_ctc(matrix, ids, blank_id=0)
    except ValueError as exc:
        result["abstentions"].append("no_finite_full_source_path")
        result["detail"] = str(exc)
        return result
    result["path_computed"] = True
    result["path_log_probability_per_frame"] = alignment.path_log_probability_per_frame
    for row, aligned in zip(rows, alignment.tokens, strict=True):
        result["tokens"].append({**row, "start_ms": aligned.start_frame * frame_step_ms,
                                 "end_ms": aligned.end_frame * frame_step_ms,
                                 "peak_ms": aligned.peak_frame * frame_step_ms,
                                 "peak_probability": aligned.peak_probability,
                                 "mean_log_probability": aligned.mean_log_probability,
                                 "requires_review": True})
    result["raw_character_intervals"] = [
        {"raw_index": index, "text": tokenization["raw_text"][index],
         "start_ms": min(row["start_ms"] for row in result["tokens"] if index in row["raw_indices"]),
         "end_ms": max(row["end_ms"] for row in result["tokens"] if index in row["raw_indices"]),
         "token_indices": [row["token_index"] for row in result["tokens"] if index in row["raw_indices"]],
         "requires_review": True}
        for index in tokenization["raw_spoken_indices"]
    ]
    return result
