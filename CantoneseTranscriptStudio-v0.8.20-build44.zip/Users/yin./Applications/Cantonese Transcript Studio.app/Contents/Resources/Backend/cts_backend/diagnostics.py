"""Read-only performance doctor for the local macOS ASR runtime."""

from __future__ import annotations

import argparse
import fcntl
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import wave
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .asr import AudioChunk, QwenASR
from .asr.qwen import mlx_memory_snapshot
from .models import ModelManager, QWEN_FALLBACK_ID, QWEN_PRIMARY_ID
from .settings import AppPaths, _atomic_json

_BYTE_PATTERN = re.compile(r"(total|used|free)\s*=\s*([0-9.]+)([MG])", re.IGNORECASE)


def _command(*arguments: str) -> str:
    try:
        result = subprocess.run(
            arguments,
            check=False,
            capture_output=True,
            text=True,
            timeout=15,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def _sysctl_int(name: str) -> int | None:
    value = _command("/usr/sbin/sysctl", "-n", name)
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def parse_swapusage(value: str) -> dict[str, int]:
    """Parse macOS `vm.swapusage` output into byte counts."""
    parsed: dict[str, int] = {}
    for key, number, unit in _BYTE_PATTERN.findall(value or ""):
        multiplier = 1024**2 if unit.upper() == "M" else 1024**3
        parsed[f"{key.lower()}_bytes"] = round(float(number) * multiplier)
    return parsed


def _directory_bytes(path: Path) -> int:
    total = 0
    if not path.is_dir():
        return total
    for candidate in path.rglob("*"):
        try:
            if candidate.is_file():
                total += candidate.stat().st_size
        except OSError:
            continue
    return total


def evaluate_report(report: dict[str, Any]) -> list[dict[str, str]]:
    """Return deterministic findings ordered from most to least serious."""
    findings: list[dict[str, str]] = []
    mlx = report.get("mlx", {})
    if mlx.get("device") != "Device(gpu, 0)" or mlx.get("metal_available") is not True:
        findings.append(
            {
                "severity": "fail",
                "code": "metal_unavailable",
                "message": "MLX 未確認使用 Metal GPU。",
            }
        )
    swap_used = int(report.get("memory", {}).get("swap", {}).get("used_bytes", 0) or 0)
    if swap_used >= 4 * 1024**3:
        findings.append(
            {
                "severity": "warning",
                "code": "high_swap",
                "message": "Swap 已超過 4 GB；開始 1.7B 前請先確保有足夠可用記憶體。App 唔會自動關閉任何程式。",
            }
        )
    ram = int(report.get("hardware", {}).get("memory_bytes", 0) or 0)
    if ram and ram <= 16 * 1024**3:
        findings.append(
            {
                "severity": "info",
                "code": "sixteen_gb_profile",
                "message": "16 GB 裝置會強制單工作並使用已修正嘅 loader cache policy。",
            }
        )
    primary = report.get("models", {}).get("primary", {})
    if not primary.get("installed"):
        findings.append(
            {
                "severity": "fail",
                "code": "primary_missing",
                "message": "Qwen3-ASR-1.7B 模型未完整安裝。",
            }
        )
    elif not primary.get("verified"):
        findings.append(
            {
                "severity": "fail",
                "code": "primary_unverified",
                "message": "Qwen3-ASR-1.7B 完整性驗證已失效；請喺模型設定重新驗證。",
            }
        )
    benchmark = report.get("benchmark")
    if isinstance(benchmark, dict) and benchmark.get("ok"):
        rtf = float(benchmark.get("real_time_factor", 0.0) or 0.0)
        if rtf > 3.0:
            findings.append(
                {
                    "severity": "fail",
                    "code": "benchmark_too_slow",
                    "message": "短片實測超過 3× real time，仍有 performance cliff。",
                }
            )
        elif rtf > 1.5:
            findings.append(
                {
                    "severity": "warning",
                    "code": "benchmark_slow",
                    "message": "短片實測慢過 1.5× real time。",
                }
            )
    return findings


def collect_report(paths: AppPaths | None = None) -> dict[str, Any]:
    paths = (paths or AppPaths.default()).ensure()
    manager = ModelManager(paths)
    primary_path = manager.path_for(QWEN_PRIMARY_ID)
    fallback_path = manager.path_for(QWEN_FALLBACK_ID)
    model_status = {
        item["id"]: item
        for item in manager.status().get("models", [])
        if isinstance(item, dict) and isinstance(item.get("id"), str)
    }
    swap_raw = _command("/usr/sbin/sysctl", "-n", "vm.swapusage")
    memory_bytes = _sysctl_int("hw.memsize") or 0
    disk = shutil.disk_usage(paths.root)
    mlx = mlx_memory_snapshot()
    try:
        import mlx.core as mx

        metal_available = bool(mx.metal.is_available())
        mlx_version = getattr(mx, "__version__", None)
    except (ImportError, AttributeError, RuntimeError):
        metal_available = False
        mlx_version = None
    report: dict[str, Any] = {
        "schema": 1,
        "created_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "system": {
            "macos": platform.mac_ver()[0],
            "architecture": platform.machine(),
            "python": platform.python_version(),
        },
        "hardware": {
            "chip": mlx.get("device_name"),
            "memory_bytes": memory_bytes,
            "cpu_count": os.cpu_count(),
        },
        "memory": {"swap": {**parse_swapusage(swap_raw), "raw": swap_raw}},
        "disk": {"free_bytes": disk.free, "total_bytes": disk.total},
        "mlx": {**mlx, "metal_available": metal_available, "version": mlx_version},
        "models": {
            "primary": {
                "id": QWEN_PRIMARY_ID,
                "path": str(primary_path),
                "installed": bool(model_status.get(QWEN_PRIMARY_ID, {}).get("installed")),
                "verified": bool(model_status.get(QWEN_PRIMARY_ID, {}).get("verified")),
                "bytes": _directory_bytes(primary_path),
            },
            "fallback": {
                "id": QWEN_FALLBACK_ID,
                "path": str(fallback_path),
                "installed": bool(model_status.get(QWEN_FALLBACK_ID, {}).get("installed")),
                "verified": bool(model_status.get(QWEN_FALLBACK_ID, {}).get("verified")),
                "bytes": _directory_bytes(fallback_path),
            },
        },
    }
    report["findings"] = evaluate_report(report)
    report["ok"] = not any(item["severity"] == "fail" for item in report["findings"])
    return report


def _wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as reader:
        if reader.getframerate() <= 0:
            raise ValueError("WAV sample rate 無效")
        return reader.getnframes() / reader.getframerate()


def benchmark(report: dict[str, Any], *, audio: Path, model_id: str, paths: AppPaths) -> None:
    lock_handle = (paths.root / "worker.lock").open("a+", encoding="utf-8")
    try:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as exc:
        lock_handle.close()
        raise RuntimeError("App 正在處理工作；請完成或關閉 App 後先跑真模型 benchmark") from exc
    try:
        _benchmark_unlocked(report, audio=audio, model_id=model_id, paths=paths)
    finally:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
        lock_handle.close()


def _benchmark_unlocked(
    report: dict[str, Any], *, audio: Path, model_id: str, paths: AppPaths
) -> None:
    duration = _wav_duration(audio)
    if not 0 < duration <= 30:
        raise ValueError("Doctor benchmark WAV 必須大過 0 秒及不超過 30 秒")
    model_path = ModelManager(paths).require_local(model_id)
    started = time.perf_counter()
    segments = QwenASR(model_path).transcribe_chunks(
        [AudioChunk("doctor-000", audio, 0.0, duration)]
    )
    elapsed = time.perf_counter() - started
    segment = segments[0]
    model_chunks = segment.metadata.get("model_chunks") or []
    generated_tokens = sum(
        int(item.get("generated_tokens", 0) or 0)
        for item in model_chunks
        if isinstance(item, dict)
    )
    report["benchmark"] = {
        "ok": True,
        "audio": str(audio),
        "audio_seconds": duration,
        "model": model_id,
        "elapsed_seconds": elapsed,
        "real_time_factor": elapsed / duration,
        "generated_tokens": generated_tokens,
        "finish_reason": segment.metadata.get("finish_reason"),
        "truncated": segment.truncated,
        "mlx_memory": segment.metadata.get("mlx_memory"),
    }
    report["findings"] = evaluate_report(report)
    report["ok"] = not any(item["severity"] == "fail" for item in report["findings"])


def _print_summary(report: dict[str, Any]) -> None:
    print("Cantonese Transcript Studio doctor")
    print(
        f"macOS {report['system']['macos']} · {report['hardware']['chip']} · "
        f"{report['hardware']['memory_bytes'] / 1024**3:.0f} GB"
    )
    print(
        f"MLX {report['mlx'].get('version')} · {report['mlx'].get('device')} · "
        f"Metal={'OK' if report['mlx'].get('metal_available') else 'FAIL'}"
    )
    swap = report["memory"]["swap"].get("used_bytes", 0) / 1024**3
    print(f"Swap used: {swap:.2f} GB")
    if report.get("benchmark", {}).get("ok"):
        item = report["benchmark"]
        print(
            f"Benchmark: {item['audio_seconds']:.2f}s audio in {item['elapsed_seconds']:.2f}s "
            f"(RTF {item['real_time_factor']:.2f})"
        )
    elif report.get("benchmark"):
        print(f"Benchmark failed: {report['benchmark'].get('error', 'unknown error')}")
    for finding in report["findings"]:
        print(f"[{finding['severity'].upper()}] {finding['message']}")
    print("doctor result:", "OK" if report["ok"] else "FAIL")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="CTS read-only MLX performance doctor")
    parser.add_argument("--benchmark-audio", type=Path)
    parser.add_argument("--model", choices=("1.7B", "0.6B"), default="1.7B")
    parser.add_argument("--json", type=Path, dest="json_path")
    parser.add_argument("--stdout-json", action="store_true")
    args = parser.parse_args(argv)
    paths = AppPaths.default().ensure()
    report = collect_report(paths)
    if args.benchmark_audio:
        model_id = QWEN_PRIMARY_ID if args.model == "1.7B" else QWEN_FALLBACK_ID
        try:
            benchmark(
                report,
                audio=args.benchmark_audio.expanduser().resolve(),
                model_id=model_id,
                paths=paths,
            )
        except Exception as exc:
            report["benchmark"] = {"ok": False, "error": str(exc)}
            report["findings"].insert(
                0,
                {"severity": "fail", "code": "benchmark_failed", "message": str(exc)},
            )
            report["ok"] = False
    if args.json_path:
        _atomic_json(args.json_path.expanduser().resolve(), report)
    if args.stdout_json:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    else:
        _print_summary(report)
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
