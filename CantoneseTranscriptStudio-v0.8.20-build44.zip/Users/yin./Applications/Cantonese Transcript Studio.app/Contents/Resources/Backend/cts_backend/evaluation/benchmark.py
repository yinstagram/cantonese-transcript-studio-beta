from __future__ import annotations

import itertools
import json
import math
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from ..normalization import HongKongNormalizer
from .loaders import load_timed_transcript, load_timed_transcripts
from .metrics import (
    comparison_windows,
    coverage_repetition_metrics,
    english_token_metrics,
    entity_accuracy,
    entity_occurrences,
    metric_pair,
    observed_cantonese_forms,
    system_hei_confusion,
    system_hei_counts,
)
from .models import TimedTranscript


DEFAULT_ENTITIES = (
    "Antigravity",
    "Anti-Gravity",
    "IG Reels",
    "Codex",
    "Gemini API",
    "JSONL",
)
DEFAULT_TERMS = ("Anti-Gravity", "Gemini API", "JSONL", "IG Reels")
_SYSTEM_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._ +()-]{0,79}$")
_SAFE_METADATA_KEYS = {
    "app_version",
    "device",
    "engine_version",
    "language",
    "model",
    "precision",
    "quantization",
    "runtime",
}


@dataclass(frozen=True)
class _SystemInput:
    identifier: str
    transcript: TimedTranscript
    processing_seconds: float | None
    metadata: Mapping[str, str | int | float | bool | None]


def _number(value: Any, *, field: str, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a number")
    number = float(value)
    if not math.isfinite(number) or number < 0 or (positive and number <= 0):
        qualifier = "positive " if positive else "non-negative "
        raise ValueError(f"{field} must be a finite {qualifier}number")
    return number


def _metadata(value: Any) -> dict[str, str | int | float | bool | None]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError("system metadata must be an object")
    output: dict[str, str | int | float | bool | None] = {}
    for key in sorted(_SAFE_METADATA_KEYS):
        item = value.get(key)
        if item is None or isinstance(item, (str, int, float, bool)):
            if key in value:
                output[key] = item
    return output


def _transcript_entry(entry: Mapping[str, Any], base: Path) -> TimedTranscript:
    source = entry.get("path")
    sources = entry.get("paths")
    if source is not None and sources is not None:
        raise ValueError("transcript entry must use path or paths, not both")
    format_name = entry.get("format", "auto")
    if not isinstance(format_name, str):
        raise ValueError("transcript format must be a string")
    if sources is not None:
        if (
            not isinstance(sources, list)
            or not sources
            or any(not isinstance(item, str) or not item for item in sources)
        ):
            raise ValueError("transcript entry paths must be a non-empty string array")
        paths = [Path(item).expanduser() for item in sources]
        paths = [path if path.is_absolute() else base / path for path in paths]
        raw_offsets = entry.get("offsets_ms")
        if raw_offsets is not None and not isinstance(raw_offsets, list):
            raise ValueError("transcript entry offsets_ms must be an array")
        return load_timed_transcripts(
            paths,
            format_name=format_name,
            offsets_ms=raw_offsets,
        )
    if not isinstance(source, str) or not source:
        raise ValueError("transcript entry path must be a non-empty string")
    path = Path(source).expanduser()
    if not path.is_absolute():
        path = base / path
    return load_timed_transcript(path, format_name=format_name)


def _load_inputs(
    manifest: Mapping[str, Any],
    base: Path,
) -> tuple[list[_SystemInput], TimedTranscript | None, tuple[str, ...], float]:
    raw_systems = manifest.get("systems")
    if not isinstance(raw_systems, list) or not raw_systems:
        raise ValueError("manifest systems must be a non-empty array")
    systems: list[_SystemInput] = []
    seen_ids: set[str] = set()
    for index, entry in enumerate(raw_systems, start=1):
        if not isinstance(entry, Mapping):
            raise ValueError(f"system {index} must be an object")
        identifier = entry.get("id")
        if not isinstance(identifier, str) or not _SYSTEM_ID_RE.fullmatch(identifier):
            raise ValueError(f"system {index} has an invalid id")
        if identifier in seen_ids:
            raise ValueError(f"duplicate system id: {identifier}")
        seen_ids.add(identifier)
        processing = entry.get("processing_seconds")
        processing_seconds = (
            None
            if processing is None
            else _number(processing, field=f"{identifier}.processing_seconds")
        )
        systems.append(
            _SystemInput(
                identifier=identifier,
                transcript=_transcript_entry(entry, base),
                processing_seconds=processing_seconds,
                metadata=_metadata(entry.get("metadata")),
            )
        )

    gold_value = manifest.get("gold")
    if gold_value is None:
        gold = None
    elif isinstance(gold_value, Mapping):
        gold = _transcript_entry(gold_value, base)
    else:
        raise ValueError("manifest gold must be an object")

    extras = manifest.get("entities", [])
    if not isinstance(extras, list) or any(not isinstance(item, str) for item in extras):
        raise ValueError("manifest entities must be an array of strings")
    entities: list[str] = []
    for entity in (*DEFAULT_ENTITIES, *extras):
        normalized = " ".join(entity.split())
        if normalized and normalized not in entities:
            entities.append(normalized)

    configured_duration = manifest.get("audio_duration_seconds")
    if configured_duration is None:
        durations = [system.transcript.duration_ms for system in systems]
        if gold is not None:
            durations.append(gold.duration_ms)
        duration_seconds = max(durations, default=0) / 1000.0
        if duration_seconds <= 0:
            raise ValueError("audio duration cannot be derived from empty timestamp ranges")
    else:
        duration_seconds = _number(
            configured_duration,
            field="audio_duration_seconds",
            positive=True,
        )
    return systems, gold, tuple(entities), duration_seconds


def _source_summary(transcript: TimedTranscript) -> dict[str, Any]:
    return {
        "sha256": transcript.sha256,
        "segment_count": len(transcript.segments),
        "timestamp_duration_seconds": round(transcript.duration_ms / 1000.0, 3),
    }


def _runtime_summary(system: _SystemInput, duration_seconds: float) -> dict[str, Any]:
    processing = system.processing_seconds
    return {
        "processing_seconds": None if processing is None else round(processing, 3),
        "audio_duration_seconds": round(duration_seconds, 3),
        "rtf": None if processing is None else round(processing / duration_seconds, 6),
    }


def _entity_presence_agreement(
    left_text: str,
    right_text: str,
    entities: tuple[str, ...],
) -> dict[str, Any]:
    left = entity_occurrences(left_text, entities)
    right = entity_occurrences(right_text, entities)
    matches = sum(bool(left[entity]) == bool(right[entity]) for entity in entities)
    return {
        "presence_agreement_rate": round(matches / len(entities), 6) if entities else None,
        "per_entity": {
            entity: {
                "left_present": bool(left[entity]),
                "right_present": bool(right[entity]),
                "agreement": bool(left[entity]) == bool(right[entity]),
            }
            for entity in entities
        },
    }


def _leaders(
    systems: list[dict[str, Any]],
    value_for: Any,
    *,
    lowest: bool = False,
) -> list[str]:
    measured = [
        (str(system["id"]), value_for(system))
        for system in systems
        if value_for(system) is not None
    ]
    if not measured:
        return []
    target = min(value for _, value in measured) if lowest else max(
        value for _, value in measured
    )
    return sorted(identifier for identifier, value in measured if value == target)


def _product_recommendation(
    systems: list[dict[str, Any]],
    agreement: list[dict[str, Any]],
    *,
    human_gold_available: bool,
) -> dict[str, Any]:
    fastest = _leaders(
        systems,
        lambda system: system["runtime"]["rtf"],
        lowest=True,
    )
    coverage = _leaders(
        systems,
        lambda system: system["coverage_repetition"]["timestamp_coverage_rate"],
    )
    terms = _leaders(
        systems,
        lambda system: sum(system["specified_terms"].values()),
    )
    pairwise_means: dict[str, list[float]] = {
        str(system["id"]): [] for system in systems
    }
    for pair in agreement:
        rate = pair["hk_normalized"]["character_disagreement_rate"]
        pairwise_means[str(pair["left_system_id"])].append(rate)
        pairwise_means[str(pair["right_system_id"])].append(rate)
    mean_disagreement = {
        identifier: round(sum(values) / len(values), 6)
        for identifier, values in pairwise_means.items()
        if values
    }
    consensus_leaders = []
    if mean_disagreement:
        lowest_mean = min(mean_disagreement.values())
        consensus_leaders = sorted(
            identifier
            for identifier, value in mean_disagreement.items()
            if value == lowest_mean
        )
    return {
        "accuracy_winner_system_id": None,
        "recommended_execution": (
            "Keep the configured primary as the deterministic backbone; use the other "
            "ASR outputs as bounded candidates and route disagreement windows to audit or "
            "human review. Do not switch the primary from this report alone."
        ),
        "operational_observations": {
            "lowest_measured_rtf_system_ids": fastest,
            "highest_timestamp_coverage_system_ids": coverage,
            "highest_observed_specified_term_count_system_ids": terms,
            "lowest_mean_pairwise_hk_disagreement_system_ids": consensus_leaders,
            "mean_pairwise_hk_disagreement": mean_disagreement,
        },
        "evidence_limits": [
            "Pairwise agreement is not accuracy and correlated ASR errors can agree.",
            "Observed Cantonese forms and specified terms are presence signals, not recall.",
            "RTF and timestamp coverage are operational metrics, not WER or CER.",
            (
                "Human gold is available for separate reference metrics."
                if human_gold_available
                else "No human gold is present, so no WER or CER winner is available."
            ),
        ],
    }


def _accuracy_result(
    system: _SystemInput,
    gold: TimedTranscript,
    entities: tuple[str, ...],
    normalizer: HongKongNormalizer,
) -> dict[str, Any]:
    return {
        "system_id": system.identifier,
        **metric_pair(gold.text, system.transcript.text, normalizer, rate_name="cer"),
        "english_word_exact_match": english_token_metrics(gold.text, system.transcript.text),
        "proper_noun_exact_match": entity_accuracy(gold.text, system.transcript.text, entities),
        "系_係_confusion": system_hei_confusion(gold.text, system.transcript.text),
        "segments": comparison_windows(
            gold,
            system.transcript,
            normalizer,
            rate_name="cer",
        ),
    }


def _winner(accuracy_results: list[dict[str, Any]]) -> dict[str, Any]:
    best = min(result["hk_normalized"]["cer"] for result in accuracy_results)
    winners = sorted(
        result["system_id"]
        for result in accuracy_results
        if math.isclose(result["hk_normalized"]["cer"], best, abs_tol=1e-12)
    )
    return {
        "metric": "hk_normalized.cer",
        "lowest_value": best,
        "system_ids": winners,
        "tie": len(winners) > 1,
    }


def build_benchmark_report(manifest: Mapping[str, Any], *, base_dir: str | Path) -> dict[str, Any]:
    base = Path(base_dir).expanduser().resolve()
    systems, gold, entities, duration_seconds = _load_inputs(manifest, base)
    normalizer = HongKongNormalizer()

    system_summaries: list[dict[str, Any]] = []
    for system in systems:
        occurrences = entity_occurrences(system.transcript.text, entities)
        system_summaries.append(
            {
                "id": system.identifier,
                "source": _source_summary(system.transcript),
                "runtime": _runtime_summary(system, duration_seconds),
                "metadata": dict(system.metadata),
                "coverage_repetition": coverage_repetition_metrics(
                    system.transcript,
                    audio_duration_ms=round(duration_seconds * 1000),
                    normalizer=normalizer,
                ),
                "observed_cantonese_colloquial_forms": observed_cantonese_forms(
                    system.transcript.text
                ),
                "系_係_counts": system_hei_counts(system.transcript.text),
                "specified_terms": {
                    term: occurrences.get(term, 0) for term in DEFAULT_TERMS
                },
                "configured_entity_presence": {
                    entity: bool(count) for entity, count in occurrences.items()
                },
            }
        )

    agreement: list[dict[str, Any]] = []
    for left, right in itertools.combinations(systems, 2):
        agreement.append(
            {
                "left_system_id": left.identifier,
                "right_system_id": right.identifier,
                **metric_pair(
                    left.transcript.text,
                    right.transcript.text,
                    normalizer,
                    rate_name="character_disagreement_rate",
                ),
                "english_word_agreement": english_token_metrics(
                    left.transcript.text,
                    right.transcript.text,
                ),
                "proper_noun_presence_agreement": _entity_presence_agreement(
                    left.transcript.text,
                    right.transcript.text,
                    entities,
                ),
                "directional_系_係_differences": system_hei_confusion(
                    left.transcript.text,
                    right.transcript.text,
                ),
                "segments": comparison_windows(
                    left.transcript,
                    right.transcript,
                    normalizer,
                    rate_name="character_disagreement_rate",
                ),
            }
        )

    if gold is None:
        accuracy: dict[str, Any] = {
            "available": False,
            "basis": None,
            "winner": None,
            "reason": "Human gold transcript required; pairwise agreement cannot establish accuracy.",
        }
    else:
        accuracy_results = [
            _accuracy_result(system, gold, entities, normalizer) for system in systems
        ]
        accuracy = {
            "available": True,
            "basis": "human_gold",
            "reference": _source_summary(gold),
            "systems": accuracy_results,
            "winner": _winner(accuracy_results),
        }

    winner_by_cer = accuracy.get("winner") if gold is not None else None
    recommendation = _product_recommendation(
        system_summaries,
        agreement,
        human_gold_available=gold is not None,
    )
    return {
        "schema_version": 1,
        "benchmark_version": "1.1",
        "privacy": {
            "contains_audio": False,
            "contains_transcript_text": False,
            "source_paths_included": False,
        },
        "audio_duration_seconds": round(duration_seconds, 3),
        "entities": list(entities),
        "systems": system_summaries,
        "agreement": agreement,
        "accuracy": accuracy,
        "winner_by_WER": None,
        "winner_by_CER": winner_by_cer,
        "product_recommendation": recommendation,
    }


def render_benchmark_markdown(report: Mapping[str, Any]) -> str:
    """Render a transcript-free human report from computed evidence only."""

    systems = report.get("systems")
    agreement = report.get("agreement")
    if not isinstance(systems, list) or not isinstance(agreement, list):
        raise ValueError("benchmark report is missing systems/agreement")

    lines = [
        "# Local ASR Evidence Report",
        "",
        "> 本報告只比較系統之間嘅分歧、時間覆蓋及運行證據。",
        "> 無人工 gold 不能宣稱任何 WER/CER winner。",
        "",
        "## Accuracy guardrail",
        "",
        f"- Human gold available: `{str(bool(report.get('accuracy', {}).get('available'))).lower()}`",
        f"- `winner_by_WER`: `{json.dumps(report.get('winner_by_WER'))}`",
        f"- `winner_by_CER`: `{json.dumps(report.get('winner_by_CER'), ensure_ascii=False)}`",
        "",
        "## System evidence",
        "",
        "| System | Segments | Timestamp coverage | Repeated segments | Cantonese forms observed | Specified terms observed | RTF |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for system in systems:
        quality = system["coverage_repetition"]
        cantonese = system["observed_cantonese_colloquial_forms"]
        rtf = system["runtime"]["rtf"]
        rtf_text = "n/a" if rtf is None else f"{float(rtf):.4f}"
        lines.append(
            "| {id} | {segments} | {coverage:.2%} | {repeated} | {cantonese} | {terms} | {rtf} |".format(
                id=str(system["id"]).replace("|", "\\|"),
                segments=quality["segment_count"],
                coverage=float(quality["timestamp_coverage_rate"]),
                repeated=quality["repeated_segment_instances"],
                cantonese=cantonese["observed_occurrences"],
                terms=sum(system["specified_terms"].values()),
                rtf=rtf_text,
            )
        )

    lines.extend(
        [
            "",
            "## Specified term observations",
            "",
            "| Term | " + " | ".join(str(system["id"]) for system in systems) + " |",
            "|---|" + "---:|" * len(systems),
        ]
    )
    for term in DEFAULT_TERMS:
        lines.append(
            "| {term} | {counts} |".format(
                term=term,
                counts=" | ".join(
                    str(system["specified_terms"].get(term, 0)) for system in systems
                ),
            )
        )

    lines.extend(
        [
            "",
            "## HK-normalized pairwise disagreement",
            "",
            "| Left | Right | Raw edit disagreement | HK-normalized edit disagreement |",
            "|---|---|---:|---:|",
        ]
    )
    for pair in agreement:
        lines.append(
            "| {left} | {right} | {raw:.4f} | {hk:.4f} |".format(
                left=str(pair["left_system_id"]).replace("|", "\\|"),
                right=str(pair["right_system_id"]).replace("|", "\\|"),
                raw=float(pair["raw"]["character_disagreement_rate"]),
                hk=float(pair["hk_normalized"]["character_disagreement_rate"]),
            )
        )

    recommendation = report.get("product_recommendation", {})
    lines.extend(
        [
            "",
            "## Evidence-backed product recommendation",
            "",
            str(recommendation.get("recommended_execution", "")),
            "",
        ]
    )
    for limit in recommendation.get("evidence_limits", []):
        lines.append(f"- {limit}")
    lines.append("")
    return "\n".join(lines)


def _atomic_json_write(path: Path, value: Mapping[str, Any]) -> None:
    destination = path.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        dir=destination.parent,
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
    except BaseException:
        try:
            Path(temporary_name).unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _atomic_text_write(path: Path, value: str) -> None:
    destination = path.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        dir=destination.parent,
    )
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
    except BaseException:
        try:
            Path(temporary_name).unlink(missing_ok=True)
        except OSError:
            pass
        raise


def write_benchmark_outputs(
    report: Mapping[str, Any],
    *,
    json_path: str | Path,
    markdown_path: str | Path,
) -> None:
    _atomic_json_write(Path(json_path), report)
    _atomic_text_write(Path(markdown_path), render_benchmark_markdown(report))


def run_benchmark(
    manifest_path: str | Path,
    output_path: str | Path,
    markdown_output_path: str | Path | None = None,
) -> dict[str, Any]:
    source = Path(manifest_path).expanduser().resolve(strict=True)
    try:
        manifest = json.loads(source.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid benchmark manifest at line {exc.lineno}, column {exc.colno}") from exc
    if not isinstance(manifest, Mapping):
        raise ValueError("benchmark manifest must be a JSON object")
    if manifest.get("schema_version", 1) != 1:
        raise ValueError("unsupported benchmark manifest schema_version")
    report = build_benchmark_report(manifest, base_dir=source.parent)
    _atomic_json_write(Path(output_path), report)
    if markdown_output_path is not None:
        _atomic_text_write(
            Path(markdown_output_path),
            render_benchmark_markdown(report),
        )
    return report


__all__ = [
    "DEFAULT_ENTITIES",
    "DEFAULT_TERMS",
    "build_benchmark_report",
    "render_benchmark_markdown",
    "run_benchmark",
    "write_benchmark_outputs",
]
