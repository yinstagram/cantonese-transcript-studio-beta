"""Public, JSON-safe types for the local live-caption core."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import Any


class LiveCaptionEventType(StrEnum):
    SESSION_STARTED = "session_started"
    SPEECH_STARTED = "speech_started"
    PARTIAL = "partial"
    FINAL = "final"
    SPEAKER_SWITCH_CANDIDATE = "speaker_switch_candidate"
    SPEAKER_SWITCH_SUSPECTED = "speaker_switch_suspected"
    SPEAKER_SWITCHED = "speaker_switched"
    SPEECH_ENDED = "speech_ended"
    OVERRUN = "overrun"
    CANCELLED = "cancelled"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass(frozen=True)
class RecognitionResult:
    """One local ASR pass over the current bounded utterance buffer."""

    text: str
    tokens: tuple[str, ...] = ()
    timestamps: tuple[float, ...] = ()
    confidence: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LiveCaptionEvent:
    """An event whose timestamps are seconds from the start of capture."""

    type: LiveCaptionEventType
    sequence: int
    start: float
    end: float
    utterance_id: int | None = None
    text: str = ""
    is_final: bool = False
    engine: str = ""
    inference_latency_ms: float | None = None
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["type"] = self.type.value
        return value


@dataclass(frozen=True)
class LiveCaptionStats:
    # This is the worker-owned count of accepted PCM16 mono samples since this
    # live session started.  It is an audio-timeline coordinate, not a wall
    # clock and not an ASR timestamp.
    captured_sample_index: int
    sample_rate_hz: int
    captured_seconds: float
    processed_seconds: float
    dropped_seconds: float
    accepted_frames: int
    dropped_frames: int
    emitted_events: int
    partial_inferences: int
    final_inferences: int
    maximum_inference_latency_ms: float
    pending_audio_seconds: float


@dataclass(frozen=True)
class _PCMFrame:
    data: bytes
    start_sample: int

    @property
    def sample_count(self) -> int:
        return len(self.data) // 2
