"""Small deterministic PCM16 VAD used to bound local live ASR work.

This detector intentionally does not pretend to identify speech content.  It
only supplies hysteresis and endpoint timing; ASR still decides the words.
"""

from __future__ import annotations

import math
from array import array
from dataclasses import dataclass


@dataclass(frozen=True)
class EnergyVADConfig:
    sample_rate: int = 16_000
    speech_threshold: float = 0.012
    release_threshold: float = 0.008
    min_speech_ms: int = 120
    min_silence_ms: int = 500
    noise_multiplier: float = 3.0
    maximum_noise_floor: float = 0.006

    def __post_init__(self) -> None:
        if self.sample_rate != 16_000:
            raise ValueError("live caption VAD 只接受 16kHz")
        if not 0.0 < self.release_threshold <= self.speech_threshold < 1.0:
            raise ValueError("VAD threshold 設定無效")
        if not 20 <= self.min_speech_ms <= 2_000:
            raise ValueError("min_speech_ms 必須係 20 至 2000")
        if not 100 <= self.min_silence_ms <= 5_000:
            raise ValueError("min_silence_ms 必須係 100 至 5000")
        if not 1.0 <= self.noise_multiplier <= 10.0:
            raise ValueError("noise_multiplier 必須係 1 至 10")


@dataclass(frozen=True)
class VADDecision:
    rms: float
    voiced: bool
    speech_started_at_sample: int | None = None
    speech_ended_at_sample: int | None = None


def pcm16_rms(data: bytes) -> float:
    if not data or len(data) % 2:
        raise ValueError("PCM16 frame 必須係非空及偶數 bytes")
    values = array("h")
    values.frombytes(data)
    if values.itemsize != 2:  # pragma: no cover - every supported CPython uses int16 h
        raise RuntimeError("平台 short size 唔係 16-bit")
    if values and values[0] != int.from_bytes(data[:2], "little", signed=True):
        values.byteswap()
    square_sum = sum(int(value) * int(value) for value in values)
    return math.sqrt(square_sum / len(values)) / 32768.0


class EnergyVAD:
    """Hysteretic VAD with delayed start confirmation and trailing silence."""

    def __init__(self, config: EnergyVADConfig | None = None) -> None:
        self.config = config or EnergyVADConfig()
        self._minimum_speech_samples = round(
            self.config.sample_rate * self.config.min_speech_ms / 1000
        )
        self._minimum_silence_samples = round(
            self.config.sample_rate * self.config.min_silence_ms / 1000
        )
        self.reset()

    @property
    def in_speech(self) -> bool:
        return self._in_speech

    def reset(self) -> None:
        self._in_speech = False
        self._candidate_start: int | None = None
        self._candidate_samples = 0
        self._silence_start: int | None = None
        self._silence_samples = 0
        self._noise_floor = 0.001

    def process(self, data: bytes, *, start_sample: int) -> VADDecision:
        rms = pcm16_rms(data)
        frame_samples = len(data) // 2
        dynamic_start = max(
            self.config.speech_threshold,
            min(self._noise_floor, self.config.maximum_noise_floor)
            * self.config.noise_multiplier,
        )
        dynamic_release = max(
            self.config.release_threshold,
            min(self._noise_floor, self.config.maximum_noise_floor)
            * max(1.5, self.config.noise_multiplier * 0.65),
        )
        threshold = dynamic_release if self._in_speech else dynamic_start
        voiced = rms >= threshold
        started: int | None = None
        ended: int | None = None

        if not self._in_speech:
            if voiced:
                if self._candidate_start is None:
                    self._candidate_start = start_sample
                    self._candidate_samples = 0
                self._candidate_samples += frame_samples
                if self._candidate_samples >= self._minimum_speech_samples:
                    self._in_speech = True
                    started = self._candidate_start
                    self._candidate_start = None
                    self._candidate_samples = 0
            else:
                self._candidate_start = None
                self._candidate_samples = 0
                if rms <= self.config.maximum_noise_floor:
                    self._noise_floor = 0.98 * self._noise_floor + 0.02 * rms
        elif voiced:
            self._silence_start = None
            self._silence_samples = 0
        else:
            if self._silence_start is None:
                self._silence_start = start_sample
                self._silence_samples = 0
            self._silence_samples += frame_samples
            if self._silence_samples >= self._minimum_silence_samples:
                ended = self._silence_start
                self._in_speech = False
                self._silence_start = None
                self._silence_samples = 0

        return VADDecision(
            rms=rms,
            voiced=voiced,
            speech_started_at_sample=started,
            speech_ended_at_sample=ended,
        )
