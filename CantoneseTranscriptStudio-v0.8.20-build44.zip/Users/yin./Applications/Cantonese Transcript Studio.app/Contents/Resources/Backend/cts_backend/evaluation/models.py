from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TimedSegment:
    start_ms: int
    end_ms: int
    text: str

    def __post_init__(self) -> None:
        if self.start_ms < 0 or self.end_ms < self.start_ms:
            raise ValueError("segment timestamps must satisfy 0 <= start_ms <= end_ms")


@dataclass(frozen=True)
class TimedTranscript:
    segments: tuple[TimedSegment, ...]
    sha256: str

    @property
    def text(self) -> str:
        return " ".join(segment.text.strip() for segment in self.segments if segment.text.strip())

    @property
    def duration_ms(self) -> int:
        return max((segment.end_ms for segment in self.segments), default=0)
