from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

from .models import TimedSegment, TimedTranscript


_TIME = r"\d{1,3}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?"
_RANGE_RE = re.compile(
    rf"^\s*\[?(?P<start>{_TIME})\s*(?:-->|→|–|—|-)\s*"
    rf"(?P<end>{_TIME})\]?\s*(?P<text>.*)$"
)
_POINT_RE = re.compile(rf"^\s*\[(?P<start>{_TIME})\]\s*(?P<text>.*)$")
_ATTOSECONDS_PER_SECOND = 1_000_000_000_000_000_000
_DURATION_LIMB_ATTOSECONDS = 1 << 64


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def _timestamp_ms(value: Any, *, milliseconds: bool = False) -> int:
    if isinstance(value, bool):
        raise ValueError("boolean is not a timestamp")
    if isinstance(value, (int, float)):
        number = float(value)
        return round(number if milliseconds else number * 1000.0)
    # Aiko serializes Swift Duration as two fixed-width attosecond limbs:
    # [high_uint64_count, low_attoseconds].  A positive time is therefore
    # (high * 2**64 + low) / 1e18 seconds.  This is not a [start, end] pair;
    # it appears separately inside each segment's start and end fields.
    if (
        isinstance(value, Sequence)
        and not isinstance(value, (str, bytes, bytearray))
        and len(value) == 2
        and all(isinstance(item, int) and not isinstance(item, bool) for item in value)
    ):
        total_attoseconds = int(value[0]) * _DURATION_LIMB_ATTOSECONDS + int(value[1])
        if total_attoseconds < 0:
            raise ValueError("duration timestamp cannot be negative")
        return round(total_attoseconds * 1000 / _ATTOSECONDS_PER_SECOND)
    if not isinstance(value, str):
        raise ValueError("timestamp must be a number or timecode")
    pieces = value.strip().replace(",", ".").split(":")
    if len(pieces) not in {2, 3}:
        raise ValueError("timestamp must use MM:SS or HH:MM:SS")
    try:
        numbers = [float(piece) for piece in pieces]
    except ValueError as exc:
        raise ValueError("timestamp contains a non-numeric component") from exc
    if len(numbers) == 2:
        hours = 0.0
        minutes, seconds = numbers
    else:
        hours, minutes, seconds = numbers
    if min(hours, minutes, seconds) < 0 or minutes >= 60 or seconds >= 60:
        raise ValueError("timestamp component is out of range")
    return round((hours * 3600.0 + minutes * 60.0 + seconds) * 1000.0)


def _segment_text(item: Mapping[str, Any]) -> str:
    for key in ("text", "chosen_text", "transcript"):
        value = item.get(key)
        if isinstance(value, str):
            return value.strip()
    raise ValueError("JSON segment is missing text")


def _mapping_segment(item: Mapping[str, Any]) -> TimedSegment:
    if "start_ms" in item and "end_ms" in item:
        start_ms = _timestamp_ms(item["start_ms"], milliseconds=True)
        end_ms = _timestamp_ms(item["end_ms"], milliseconds=True)
    elif isinstance(item.get("offsets"), Mapping):
        offsets = item["offsets"]
        if "from" not in offsets or "to" not in offsets:
            raise ValueError("JSON segment offsets are missing from/to")
        start_ms = _timestamp_ms(offsets["from"], milliseconds=True)
        end_ms = _timestamp_ms(offsets["to"], milliseconds=True)
    elif isinstance(item.get("timestamps"), Mapping):
        timestamps = item["timestamps"]
        if "from" not in timestamps or "to" not in timestamps:
            raise ValueError("JSON segment timestamps are missing from/to")
        start_ms = _timestamp_ms(timestamps["from"])
        end_ms = _timestamp_ms(timestamps["to"])
    else:
        start = next(
            (item[key] for key in ("start", "start_time", "startTime") if key in item),
            None,
        )
        end = next(
            (item[key] for key in ("end", "end_time", "endTime") if key in item),
            None,
        )
        timestamp = item.get("timestamp")
        if (start is None or end is None) and isinstance(timestamp, Sequence) and len(timestamp) == 2:
            start, end = timestamp
        if start is None or end is None:
            raise ValueError("JSON segment is missing start/end timestamps")
        start_ms = _timestamp_ms(start)
        end_ms = _timestamp_ms(end)
    return TimedSegment(start_ms=start_ms, end_ms=end_ms, text=_segment_text(item))


def _unwrap_json(value: Any) -> Sequence[Any]:
    if isinstance(value, list):
        return value
    if not isinstance(value, Mapping):
        raise ValueError("transcript JSON must be an object or segment array")
    if value.get("complete") is True and isinstance(value.get("value"), Mapping):
        value = value["value"]
    for key in ("segments", "transcription", "result"):
        candidate = value.get(key)
        if isinstance(candidate, list):
            return candidate
        if isinstance(candidate, Mapping) and isinstance(candidate.get("segments"), list):
            return candidate["segments"]
    raise ValueError("transcript JSON does not contain a segment array")


def _load_json(path: Path) -> tuple[TimedSegment, ...]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid transcript JSON at line {exc.lineno}, column {exc.colno}") from exc
    segments: list[TimedSegment] = []
    for index, item in enumerate(_unwrap_json(value), start=1):
        if not isinstance(item, Mapping):
            raise ValueError(f"transcript JSON segment {index} is not an object")
        try:
            segments.append(_mapping_segment(item))
        except ValueError as exc:
            raise ValueError(f"invalid transcript JSON segment {index}: {exc}") from exc
    return tuple(sorted(segments, key=lambda segment: (segment.start_ms, segment.end_ms)))


def _load_timestamp_text(path: Path) -> tuple[TimedSegment, ...]:
    records: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    def flush() -> None:
        nonlocal current
        if current is not None:
            records.append(current)
            current = None

    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line == "WEBVTT" or line.isdecimal():
            continue
        match = _RANGE_RE.match(line)
        if match:
            flush()
            current = {
                "line": line_number,
                "start_ms": _timestamp_ms(match.group("start")),
                "end_ms": _timestamp_ms(match.group("end")),
                "parts": [match.group("text").strip()] if match.group("text").strip() else [],
            }
            continue
        match = _POINT_RE.match(line)
        if match:
            flush()
            current = {
                "line": line_number,
                "start_ms": _timestamp_ms(match.group("start")),
                "end_ms": None,
                "parts": [match.group("text").strip()] if match.group("text").strip() else [],
            }
            continue
        if current is None:
            raise ValueError(f"invalid timestamp transcript at line {line_number}")
        current["parts"].append(line)
    flush()

    segments: list[TimedSegment] = []
    for index, record in enumerate(records):
        start_ms = int(record["start_ms"])
        end_ms = record["end_ms"]
        if end_ms is None:
            end_ms = records[index + 1]["start_ms"] if index + 1 < len(records) else start_ms + 1
        try:
            segments.append(
                TimedSegment(
                    start_ms=start_ms,
                    end_ms=int(end_ms),
                    text="\n".join(record["parts"]).strip(),
                )
            )
        except ValueError as exc:
            raise ValueError(f"invalid timestamp transcript at line {record['line']}: {exc}") from exc
    return tuple(sorted(segments, key=lambda segment: (segment.start_ms, segment.end_ms)))


def load_timed_transcript(path: str | Path, *, format_name: str = "auto") -> TimedTranscript:
    source = Path(path).expanduser().resolve(strict=True)
    selected = format_name.lower()
    if selected == "auto":
        selected = "json" if source.suffix.lower() == ".json" else "timestamp_text"
    if selected == "json":
        segments = _load_json(source)
    elif selected in {"timestamp_text", "txt", "srt", "vtt"}:
        segments = _load_timestamp_text(source)
    else:
        raise ValueError("format must be auto, json, timestamp_text, txt, srt, or vtt")
    if not segments:
        raise ValueError("transcript contains no timestamp segments")
    return TimedTranscript(segments=segments, sha256=_sha256(source))


def load_timed_transcripts(
    paths: Sequence[str | Path],
    *,
    format_name: str = "auto",
    offsets_ms: Sequence[int] | None = None,
) -> TimedTranscript:
    """Load and merge one or more transcript artifacts with explicit offsets.

    Raw whisper.cpp JSON timestamps restart at zero for each input WAV.  To
    prevent silently false timeline coverage, multiple artifacts therefore
    require one explicit absolute offset per file.
    """

    if not paths:
        raise ValueError("at least one transcript path is required")
    if offsets_ms is None:
        if len(paths) != 1:
            raise ValueError("multiple transcript paths require offsets_ms")
        normalized_offsets = (0,)
    else:
        if len(offsets_ms) != len(paths):
            raise ValueError("offsets_ms must match transcript path count")
        if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in offsets_ms):
            raise ValueError("offsets_ms must contain non-negative integers")
        normalized_offsets = tuple(offsets_ms)

    loaded = [load_timed_transcript(path, format_name=format_name) for path in paths]
    segments = tuple(
        sorted(
            (
                TimedSegment(
                    start_ms=segment.start_ms + offset,
                    end_ms=segment.end_ms + offset,
                    text=segment.text,
                )
                for transcript, offset in zip(loaded, normalized_offsets)
                for segment in transcript.segments
            ),
            key=lambda segment: (segment.start_ms, segment.end_ms),
        )
    )
    digest = hashlib.sha256()
    for transcript, offset in zip(loaded, normalized_offsets):
        digest.update(transcript.sha256.encode("ascii"))
        digest.update(b":")
        digest.update(str(offset).encode("ascii"))
        digest.update(b"\n")
    return TimedTranscript(segments=segments, sha256=digest.hexdigest())


__all__ = ["load_timed_transcript", "load_timed_transcripts"]
