"""Strict, versioned schemas for editable subtitle projects."""

from __future__ import annotations

import json
import math
import re
from dataclasses import asdict, dataclass, field, replace
from typing import Any, Mapping, Sequence


PROJECT_SCHEMA = 1
MAX_PROJECT_BYTES = 16 * 1024 * 1024
MAX_CUES = 50_000
MAX_CUE_TEXT_BYTES = 16 * 1024
MAX_FONT_FAMILY_BYTES = 256
MAX_SEGMENTATION_AUDIT_BYTES = 256 * 1024
MAX_SPEAKERS = 256
MAX_SPEAKER_NAME_BYTES = 256
RGBA_PATTERN = re.compile(r"^#[0-9A-Fa-f]{8}$")
SHA256_PATTERN = re.compile(r"^sha256:[0-9a-f]{64}$")
SPEAKER_ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

SPEAKER_COLOUR_PALETTE = (
    "#7DD3FCFF",
    "#FCA5A5FF",
    "#86EFACFF",
    "#FDE68AFF",
    "#C4B5FDFF",
    "#FDA4AFFF",
    "#67E8F9FF",
    "#FDBA74FF",
)


def _strict_int(value: Any, name: str, *, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} 必須係整數")
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} 超出範圍")
    return value


def _finite_number(value: Any, name: str, *, minimum: float, maximum: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} 必須係數字")
    result = float(value)
    if not math.isfinite(result) or not minimum <= result <= maximum:
        raise ValueError(f"{name} 超出範圍")
    return result


def _boolean(value: Any, name: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{name} 必須係 true 或 false")
    return value


def _rgba(value: Any, name: str) -> str:
    if not isinstance(value, str) or not RGBA_PATTERN.fullmatch(value):
        raise ValueError(f"{name} 必須係 #RRGGBBAA 顏色")
    return value.upper()


def _optional_bounded_text(value: Any, name: str, *, maximum_bytes: int = 256) -> str | None:
    if value is None:
        return None
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value.encode("utf-8")) > maximum_bytes
        or any(character in value for character in ("\x00", "\r", "\n"))
    ):
        raise ValueError(f"{name} 無效")
    return value.strip()


def _speaker_id(value: Any, name: str) -> str:
    if not isinstance(value, str) or not SPEAKER_ID_PATTERN.fullmatch(value):
        raise ValueError(f"{name} 無效")
    return value


def _speaker_name(value: Any, name: str) -> str:
    if (
        not isinstance(value, str)
        or not value.strip()
        or len(value.encode("utf-8")) > MAX_SPEAKER_NAME_BYTES
        or any(character in value for character in ("\x00", "\r", "\n"))
    ):
        raise ValueError(f"{name} 無效")
    return value.strip()


def _optional_source_offset(value: Any, name: str) -> int | None:
    if value is None:
        return None
    return _strict_int(value, name, minimum=0, maximum=2_147_483_647)


def _segmentation_audit(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError("segmentation_audit 必須係 object")
    try:
        encoded = json.dumps(
            value,
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        if len(encoded) > MAX_SEGMENTATION_AUDIT_BYTES:
            raise ValueError("segmentation_audit 超出大小限制")
        decoded = json.loads(encoded)
    except (TypeError, ValueError, RecursionError) as exc:
        if isinstance(exc, ValueError) and str(exc).startswith("segmentation_audit"):
            raise
        raise ValueError(f"segmentation_audit JSON 無效：{exc}") from exc
    if not isinstance(decoded, dict):
        raise ValueError("segmentation_audit 必須係 object")
    return decoded


@dataclass(frozen=True)
class SubtitleSegmentationPreferences:
    """Saved user preference; adding it keeps schema-1 projects readable."""

    max_characters: int = 18
    mode: str = "precise"

    @classmethod
    def from_dict(cls, value: Any) -> "SubtitleSegmentationPreferences":
        if value is None:
            return cls()
        if not isinstance(value, Mapping):
            raise ValueError("segmentation_preferences 必須係 object")
        maximum = _strict_int(
            value.get("max_characters", 18),
            "max_characters",
            minimum=6,
            maximum=60,
        )
        mode = value.get("mode", "precise")
        if mode not in {"precise", "semantic"}:
            raise ValueError("mode 必須係 precise 或 semantic")
        return cls(max_characters=maximum, mode=mode)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SubtitleStyle:
    preset_id: str = "classic"
    font_family: str = "PingFang HK"
    font_size_px: float = 64.0
    text_color_rgba: str = "#FFFFFFFF"
    italic: bool = False
    shadow_enabled: bool = True
    shadow_depth_px: float = 3.0
    shadow_color_rgba: str = "#000000CC"
    background_enabled: bool = False
    background_color_rgba: str = "#000000B8"
    background_padding_px: float = 14.0
    alignment: str = "bottom_center"
    margin_bottom_px: float = 84.0

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SubtitleStyle":
        if not isinstance(value, Mapping):
            raise ValueError("style 必須係 object")
        preset = value.get("preset_id", "classic")
        if not isinstance(preset, str) or not preset.strip() or len(preset.encode("utf-8")) > 64:
            raise ValueError("preset_id 無效")
        font = value.get("font_family", "PingFang HK")
        if (
            not isinstance(font, str)
            or not font.strip()
            or len(font.encode("utf-8")) > MAX_FONT_FAMILY_BYTES
            or any(character in font for character in (",", "\r", "\n", "\x00"))
            or any(ord(character) < 32 for character in font)
        ):
            raise ValueError("font_family 無效")
        alignment = value.get("alignment", "bottom_center")
        if alignment != "bottom_center":
            raise ValueError("alignment 目前只支援 bottom_center")
        return cls(
            preset_id=preset.strip(),
            font_family=font.strip(),
            font_size_px=_finite_number(
                value.get("font_size_px", 64), "font_size_px", minimum=8, maximum=240
            ),
            text_color_rgba=_rgba(value.get("text_color_rgba", "#FFFFFFFF"), "text_color_rgba"),
            italic=_boolean(value.get("italic", False), "italic"),
            shadow_enabled=_boolean(value.get("shadow_enabled", True), "shadow_enabled"),
            shadow_depth_px=_finite_number(
                value.get("shadow_depth_px", 3), "shadow_depth_px", minimum=0, maximum=32
            ),
            shadow_color_rgba=_rgba(
                value.get("shadow_color_rgba", "#000000CC"), "shadow_color_rgba"
            ),
            background_enabled=_boolean(
                value.get("background_enabled", False), "background_enabled"
            ),
            background_color_rgba=_rgba(
                value.get("background_color_rgba", "#000000B8"), "background_color_rgba"
            ),
            background_padding_px=_finite_number(
                value.get("background_padding_px", 14),
                "background_padding_px",
                minimum=0,
                maximum=64,
            ),
            alignment=alignment,
            margin_bottom_px=_finite_number(
                value.get("margin_bottom_px", 84),
                "margin_bottom_px",
                minimum=0,
                maximum=2000,
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SubtitleSpeakerStyle:
    """Small, explicit overrides layered on top of the whole-video style."""

    text_color_rgba: str = SPEAKER_COLOUR_PALETTE[0]
    italic: bool | None = None
    background_enabled: bool | None = None
    background_color_rgba: str | None = None

    @classmethod
    def from_dict(cls, value: Any) -> "SubtitleSpeakerStyle":
        if value is None:
            return cls()
        if not isinstance(value, Mapping):
            raise ValueError("speaker style 必須係 object")
        italic = value.get("italic")
        if italic is not None:
            italic = _boolean(italic, "speaker style italic")
        background_enabled = value.get("background_enabled")
        if background_enabled is not None:
            background_enabled = _boolean(
                background_enabled, "speaker style background_enabled"
            )
        raw_background = value.get("background_color_rgba")
        background = (
            None
            if raw_background is None
            else _rgba(raw_background, "speaker style background_color_rgba")
        )
        return cls(
            text_color_rgba=_rgba(
                value.get("text_color_rgba", SPEAKER_COLOUR_PALETTE[0]),
                "speaker style text_color_rgba",
            ),
            italic=italic,
            background_enabled=background_enabled,
            background_color_rgba=background,
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def resolve(self, base: SubtitleStyle) -> SubtitleStyle:
        return replace(
            base,
            text_color_rgba=self.text_color_rgba,
            italic=base.italic if self.italic is None else self.italic,
            background_enabled=(
                base.background_enabled
                if self.background_enabled is None
                else self.background_enabled
            ),
            background_color_rgba=(
                base.background_color_rgba
                if self.background_color_rgba is None
                else self.background_color_rgba
            ),
        )


@dataclass(frozen=True)
class SubtitleSpeakerProfile:
    """An editable anonymous label; it is never a biometric identity claim."""

    id: str
    display_name: str
    source_label: str | None
    show_name: bool
    style: SubtitleSpeakerStyle

    @classmethod
    def from_dict(cls, value: Any) -> "SubtitleSpeakerProfile":
        if not isinstance(value, Mapping):
            raise ValueError("每位講者必須係 object")
        speaker_id = _speaker_id(value.get("id"), "講者 id")
        return cls(
            id=speaker_id,
            display_name=_speaker_name(value.get("display_name"), f"講者 {speaker_id} 名稱"),
            source_label=_optional_bounded_text(
                value.get("source_label"), f"講者 {speaker_id} source_label"
            ),
            show_name=_boolean(value.get("show_name", True), f"講者 {speaker_id} show_name"),
            style=SubtitleSpeakerStyle.from_dict(value.get("style")),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "display_name": self.display_name,
            "source_label": self.source_label,
            "show_name": self.show_name,
            "style": self.style.to_dict(),
        }


@dataclass(frozen=True)
class SubtitleCue:
    id: str
    source_segment_index: int
    start_ms: int
    end_ms: int
    text: str
    source_confidence: float | None = None
    source_low_confidence: bool = False
    source_start: int | None = None
    source_end: int | None = None
    boundary_reason: str | None = None
    speaker_id: str | None = None
    speaker_label: str | None = None

    @classmethod
    def from_dict(cls, value: Mapping[str, Any], *, duration_ms: int) -> "SubtitleCue":
        if not isinstance(value, Mapping):
            raise ValueError("每段字幕必須係 object")
        cue_id = value.get("id")
        if (
            not isinstance(cue_id, str)
            or not cue_id.strip()
            or len(cue_id.encode("utf-8")) > 256
            or any(character in cue_id for character in ("/", "\\", "\x00", "\r", "\n"))
        ):
            raise ValueError("字幕 id 無效")
        text = value.get("text")
        if not isinstance(text, str):
            raise ValueError(f"字幕 {cue_id} text 必須係文字")
        if len(text.encode("utf-8")) > MAX_CUE_TEXT_BYTES:
            raise ValueError(f"字幕 {cue_id} 文字超過 16 KiB")
        start = _strict_int(value.get("start_ms"), f"字幕 {cue_id} start_ms", minimum=0, maximum=duration_ms)
        end = _strict_int(value.get("end_ms"), f"字幕 {cue_id} end_ms", minimum=0, maximum=duration_ms)
        if end <= start:
            raise ValueError(f"字幕 {cue_id} 結束時間必須遲過開始時間")
        confidence_value = value.get("source_confidence")
        confidence = None
        if confidence_value is not None:
            confidence = _finite_number(
                confidence_value, f"字幕 {cue_id} source_confidence", minimum=0, maximum=1
            )
        source_start = _optional_source_offset(
            value.get("source_start"), f"字幕 {cue_id} source_start"
        )
        source_end = _optional_source_offset(
            value.get("source_end"), f"字幕 {cue_id} source_end"
        )
        if (source_start is None) != (source_end is None):
            raise ValueError(f"字幕 {cue_id} source range 必須完整")
        if source_start is not None and source_end is not None and source_end <= source_start:
            raise ValueError(f"字幕 {cue_id} source range 無效")
        return cls(
            id=cue_id,
            source_segment_index=_strict_int(
                value.get("source_segment_index", 0),
                f"字幕 {cue_id} source_segment_index",
                minimum=0,
                maximum=MAX_CUES - 1,
            ),
            start_ms=start,
            end_ms=end,
            text=text,
            source_confidence=confidence,
            source_low_confidence=_boolean(
                value.get("source_low_confidence", False),
                f"字幕 {cue_id} source_low_confidence",
            ),
            source_start=source_start,
            source_end=source_end,
            boundary_reason=_optional_bounded_text(
                value.get("boundary_reason"), f"字幕 {cue_id} boundary_reason"
            ),
            speaker_id=(
                None
                if value.get("speaker_id") is None
                else _speaker_id(value.get("speaker_id"), f"字幕 {cue_id} speaker_id")
            ),
            speaker_label=_optional_bounded_text(
                value.get("speaker_label"), f"字幕 {cue_id} speaker_label"
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SubtitleProject:
    schema: int
    revision: int
    job_id: str
    source_path: str
    source_fingerprint: str
    source_final_sha256: str
    duration_ms: int
    created_at: str
    updated_at: str
    style: SubtitleStyle
    segments: tuple[SubtitleCue, ...]
    speakers: tuple[SubtitleSpeakerProfile, ...] = ()
    segmentation_preferences: SubtitleSegmentationPreferences = SubtitleSegmentationPreferences()
    segmentation_audit: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any], *, expected_job_id: str | None = None) -> "SubtitleProject":
        if not isinstance(value, Mapping):
            raise ValueError("project 必須係 object")
        try:
            payload_size = len(
                json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
            )
        except (TypeError, ValueError) as exc:
            raise ValueError(f"project JSON 無效：{exc}") from exc
        if payload_size > MAX_PROJECT_BYTES:
            raise ValueError("project 超過 16 MiB")
        schema = _strict_int(value.get("schema"), "schema", minimum=1, maximum=1)
        revision = _strict_int(value.get("revision"), "revision", minimum=1, maximum=2_147_483_647)
        job_id = value.get("job_id")
        if not isinstance(job_id, str) or not job_id or job_id != job_id.strip() or "/" in job_id:
            raise ValueError("job_id 無效")
        if expected_job_id is not None and job_id != expected_job_id:
            raise ValueError("project job_id 同工作唔一致")
        source_path = value.get("source_path")
        if not isinstance(source_path, str) or not source_path or "\x00" in source_path:
            raise ValueError("source_path 無效")
        fingerprint = value.get("source_fingerprint", "")
        if not isinstance(fingerprint, str) or len(fingerprint.encode("utf-8")) > 512:
            raise ValueError("source_fingerprint 無效")
        final_sha = value.get("source_final_sha256")
        if not isinstance(final_sha, str) or not SHA256_PATTERN.fullmatch(final_sha):
            raise ValueError("source_final_sha256 無效")
        duration = _strict_int(
            value.get("duration_ms"), "duration_ms", minimum=1, maximum=86_400_000 * 7
        )
        created_at = value.get("created_at")
        updated_at = value.get("updated_at")
        if not isinstance(created_at, str) or not created_at or len(created_at) > 64:
            raise ValueError("created_at 無效")
        if not isinstance(updated_at, str) or not updated_at or len(updated_at) > 64:
            raise ValueError("updated_at 無效")
        raw_segments = value.get("segments")
        if not isinstance(raw_segments, Sequence) or isinstance(raw_segments, (str, bytes, bytearray)):
            raise ValueError("segments 必須係 array")
        if len(raw_segments) > MAX_CUES:
            raise ValueError("segments 超過 50,000 段")
        segments = tuple(SubtitleCue.from_dict(item, duration_ms=duration) for item in raw_segments)
        raw_speakers = value.get("speakers")
        if raw_speakers is None:
            # Schema-1 projects created before speaker editing only carried the
            # diarizer's label on each cue.  Upgrade them deterministically in
            # memory, without claiming that a label identifies a real person.
            profiles: list[SubtitleSpeakerProfile] = []
            by_source: dict[str, str] = {}
            upgraded_segments: list[SubtitleCue] = []
            for cue in segments:
                label = cue.speaker_label
                if label in {None, "", "Unknown"} and cue.speaker_id is None:
                    upgraded_segments.append(cue)
                    continue
                source_key = cue.speaker_id or str(label)
                speaker_id = by_source.get(source_key)
                if speaker_id is None:
                    candidate = cue.speaker_id or f"speaker-{len(profiles) + 1}"
                    while any(profile.id == candidate for profile in profiles):
                        candidate = f"speaker-{len(profiles) + 1}"
                    display_name = label or candidate
                    profile = SubtitleSpeakerProfile(
                        id=candidate,
                        display_name=str(display_name),
                        source_label=label,
                        show_name=True,
                        style=SubtitleSpeakerStyle(
                            text_color_rgba=SPEAKER_COLOUR_PALETTE[
                                len(profiles) % len(SPEAKER_COLOUR_PALETTE)
                            ]
                        ),
                    )
                    profiles.append(profile)
                    by_source[source_key] = candidate
                    speaker_id = candidate
                upgraded_segments.append(replace(cue, speaker_id=speaker_id))
            if len(profiles) > MAX_SPEAKERS:
                raise ValueError("speakers 超過 256 位")
            speakers = tuple(profiles)
            segments = tuple(upgraded_segments)
        else:
            if not isinstance(raw_speakers, Sequence) or isinstance(
                raw_speakers, (str, bytes, bytearray)
            ):
                raise ValueError("speakers 必須係 array")
            if len(raw_speakers) > MAX_SPEAKERS:
                raise ValueError("speakers 超過 256 位")
            speakers = tuple(SubtitleSpeakerProfile.from_dict(item) for item in raw_speakers)
        speaker_ids = [speaker.id for speaker in speakers]
        if len(set(speaker_ids)) != len(speaker_ids):
            raise ValueError("講者 id 重複")
        known_speakers = set(speaker_ids)
        for cue in segments:
            if cue.speaker_id is not None and cue.speaker_id not in known_speakers:
                raise ValueError(f"字幕 {cue.id} 引用咗不存在嘅講者")
        seen: set[str] = set()
        previous_end = 0
        previous_key: tuple[int, int, str] | None = None
        for cue in segments:
            if cue.id in seen:
                raise ValueError(f"字幕 id 重複：{cue.id}")
            seen.add(cue.id)
            key = (cue.start_ms, cue.end_ms, cue.id)
            if previous_key is not None and key < previous_key:
                raise ValueError("segments 必須按時間排序")
            if cue.start_ms < previous_end:
                raise ValueError(f"字幕時間重疊：{cue.id}")
            previous_key = key
            previous_end = cue.end_ms
        return cls(
            schema=schema,
            revision=revision,
            job_id=job_id,
            source_path=source_path,
            source_fingerprint=fingerprint,
            source_final_sha256=final_sha,
            duration_ms=duration,
            created_at=created_at,
            updated_at=updated_at,
            style=SubtitleStyle.from_dict(value.get("style", {})),
            segments=segments,
            speakers=speakers,
            segmentation_preferences=SubtitleSegmentationPreferences.from_dict(
                value.get("segmentation_preferences")
            ),
            segmentation_audit=_segmentation_audit(value.get("segmentation_audit")),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": self.schema,
            "revision": self.revision,
            "job_id": self.job_id,
            "source_path": self.source_path,
            "source_fingerprint": self.source_fingerprint,
            "source_final_sha256": self.source_final_sha256,
            "duration_ms": self.duration_ms,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "style": self.style.to_dict(),
            "segments": [cue.to_dict() for cue in self.segments],
            "speakers": [speaker.to_dict() for speaker in self.speakers],
            "segmentation_preferences": self.segmentation_preferences.to_dict(),
            "segmentation_audit": _segmentation_audit(self.segmentation_audit),
        }


__all__ = [
    "MAX_CUE_TEXT_BYTES",
    "MAX_CUES",
    "MAX_PROJECT_BYTES",
    "MAX_SPEAKERS",
    "MAX_SEGMENTATION_AUDIT_BYTES",
    "PROJECT_SCHEMA",
    "SubtitleCue",
    "SubtitleProject",
    "SubtitleSpeakerProfile",
    "SubtitleSpeakerStyle",
    "SubtitleSegmentationPreferences",
    "SubtitleStyle",
]
