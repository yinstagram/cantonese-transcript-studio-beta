"""Scoped AI semantic-to-timing measurement for the O8 YouTube reference.

This module is deliberately an evaluation sidecar.  It lets the current Yin
feedback authority treat the user-identified O8 YouTube captions as scoped
gold while keeping three boundaries intact:

* the semantic model never sees timing fields;
* only exact ``same_meaning`` immutable-ID proposals on a unique monotonic
  candidate path can expose the already sealed CTS cue edges; and
* the result never becomes human confirmation, production mutation, or a
  release verdict.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import math
from typing import Any, Mapping, Sequence

from .semantic_pairing import (
    SemanticPairingError,
    assert_no_timestamp_fields,
    canonical_sha256,
    validate_blind_review_packet_shape,
    validate_bundle,
)


SCOPED_AI_SEMANTIC_TIMING_POLICY_VERSION = (
    "o8-scoped-ai-semantic-timing-m0-2026-09-08"
)
SCOPED_VIDEO_ID = "O8IB7nao2K4"
SCOPED_YOUTUBE_URL = "https://www.youtube.com/watch?v=O8IB7nao2K4"
SCOPED_REGISTRY_IDS = frozenset(
    {"cts-release", "cts-field-acceptance", "cts-timestamp-v3-validation"}
)


class ScopedAISemanticTimingError(ValueError):
    """A scoped semantic timing result cannot be derived safely."""


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _require_mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise ScopedAISemanticTimingError(f"{label} must be an object")
    return value


def _require_list(value: object, label: str) -> list[object]:
    if not isinstance(value, list):
        raise ScopedAISemanticTimingError(f"{label} must be an array")
    return value


def _require_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ScopedAISemanticTimingError(f"{label} must be non-empty text")
    return value.strip()


def _require_int(value: object, label: str, *, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ScopedAISemanticTimingError(f"{label} must be an integer")
    if minimum is not None and value < minimum:
        raise ScopedAISemanticTimingError(f"{label} is below its minimum")
    return value


def _validate_canonical(
    value: Mapping[str, object], *, schema: str, hash_field: str, label: str
) -> None:
    if value.get("schema") != schema:
        raise ScopedAISemanticTimingError(f"{label} schema mismatch")
    claimed = value.get(hash_field)
    body = dict(value)
    body.pop(hash_field, None)
    if not isinstance(claimed, str) or canonical_sha256(body) != claimed:
        raise ScopedAISemanticTimingError(f"{label} canonical hash mismatch")


def _validate_scope(scope: object, *, label: str) -> Mapping[str, object]:
    scoped = _require_mapping(scope, f"{label} scope")
    if scoped.get("video_id") != SCOPED_VIDEO_ID:
        raise ScopedAISemanticTimingError(f"{label} video identity mismatch")
    if scoped.get("youtube_url") != SCOPED_YOUTUBE_URL:
        raise ScopedAISemanticTimingError(f"{label} YouTube URL mismatch")
    if scoped.get("production_wide_human_gold_claim") is not False:
        raise ScopedAISemanticTimingError(f"{label} broader human-gold boundary is unsafe")
    return scoped


def _validate_yin_feedback(feedback: Mapping[str, object]) -> Mapping[str, object]:
    if feedback.get("schema") != "codex.open-loop.user-feedback/v1":
        raise ScopedAISemanticTimingError("Yin feedback schema mismatch")
    entries = _require_list(feedback.get("entries"), "Yin feedback entries")
    matching: list[Mapping[str, object]] = []
    for raw in entries:
        if not isinstance(raw, Mapping):
            continue
        registry_ids = raw.get("registry_ids")
        if isinstance(registry_ids, list) and set(registry_ids) == SCOPED_REGISTRY_IDS:
            matching.append(raw)
    if len(matching) != 1:
        raise ScopedAISemanticTimingError("Yin feedback authority is missing or ambiguous")
    decision = matching[0]
    if decision.get("decision") != "AI_VALIDATE_WITH_REFERENCE":
        raise ScopedAISemanticTimingError("Yin feedback does not authorize scoped AI validation")
    execution = decision.get("execution")
    if not isinstance(execution, str) or "do not generalize" not in execution.lower():
        raise ScopedAISemanticTimingError("Yin feedback broader-gold boundary is missing")
    return decision


def _percentile(values: Sequence[int], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return float(ordered[0])
    rank = (len(ordered) - 1) * percentile
    lower = math.floor(rank)
    upper = math.ceil(rank)
    if lower == upper:
        return float(ordered[lower])
    fraction = rank - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction


def _stats(values: Sequence[int]) -> dict[str, float | int | None]:
    if not values:
        return {"count": 0, "median": None, "p90": None, "p95": None, "max": None}
    return {
        "count": len(values),
        "median": _percentile(values, 0.5),
        "p90": _percentile(values, 0.9),
        "p95": _percentile(values, 0.95),
        "max": max(values),
    }


def _timing_grade(start_abs_ms: int, end_abs_ms: int) -> str:
    if start_abs_ms <= 500 and end_abs_ms <= 500:
        return "ON_TIME"
    if start_abs_ms <= 2000 and end_abs_ms <= 2000:
        return "SLIGHT_OFFSET"
    return "OFF_TIME"


def evaluate_scoped_ai_semantic_timing(
    *,
    proposals: Mapping[str, object],
    blind_packet: Mapping[str, object],
    bundle: Mapping[str, object],
    model_run: Mapping[str, object],
    yin_feedback: Mapping[str, object],
    file_hashes: Mapping[str, str],
) -> dict[str, object]:
    """Join blind AI semantic selections to sealed CTS cue edges.

    ``file_hashes`` must contain ``proposals``, ``blind_packet``, ``bundle``,
    ``model_run``, and ``yin_feedback``.  The caller computes those hashes from
    actual files immediately before evaluation.
    """

    required_hashes = {"proposals", "blind_packet", "bundle", "model_run", "yin_feedback"}
    if set(file_hashes) != required_hashes or any(
        not isinstance(value, str) or len(value) != 64 for value in file_hashes.values()
    ):
        raise ScopedAISemanticTimingError("actual file-hash binding is incomplete")

    _validate_canonical(
        proposals,
        schema="cts.semantic-pairing-proposals/v1",
        hash_field="proposals_canonical_sha256",
        label="pairing proposals",
    )
    _validate_canonical(
        blind_packet,
        schema="cts.semantic-pairing-blind-review-packet/v1",
        hash_field="packet_canonical_sha256",
        label="blind packet",
    )
    _validate_canonical(
        model_run,
        schema="cts.local-semantic-pair-judge-run/v1",
        hash_field="run_canonical_sha256",
        label="local semantic run",
    )
    try:
        validate_bundle(bundle)
        validate_blind_review_packet_shape(blind_packet)
        assert_no_timestamp_fields(blind_packet)
    except SemanticPairingError as exc:
        raise ScopedAISemanticTimingError(str(exc)) from exc

    proposal_scope = _validate_scope(proposals.get("scope"), label="pairing proposals")
    packet_scope = _validate_scope(blind_packet.get("scope"), label="blind packet")
    bundle_scope = _validate_scope(bundle.get("scope"), label="semantic timing bundle")
    if proposal_scope != packet_scope:
        raise ScopedAISemanticTimingError("proposal and blind-packet scope mismatch")
    _ = bundle_scope
    _validate_yin_feedback(yin_feedback)

    authority = _require_mapping(proposals.get("authority"), "proposal authority")
    packet_authority = _require_mapping(blind_packet.get("authority"), "blind authority")
    for field in (
        "bundle_file_sha256",
        "bundle_canonical_sha256",
        "candidate_text_projection_sha256",
    ):
        if authority.get(field) != packet_authority.get(field):
            raise ScopedAISemanticTimingError(f"proposal/blind authority mismatch: {field}")
    if authority.get("bundle_file_sha256") != file_hashes["bundle"]:
        raise ScopedAISemanticTimingError("semantic timing bundle file hash mismatch")
    if authority.get("bundle_canonical_sha256") != bundle.get("bundle_canonical_sha256"):
        raise ScopedAISemanticTimingError("semantic timing bundle canonical hash mismatch")
    feedback_authority = _require_mapping(
        authority.get("yin_feedback_authority"), "Yin feedback authority"
    )
    if feedback_authority.get("sha256") != file_hashes["yin_feedback"]:
        raise ScopedAISemanticTimingError("current Yin feedback file hash mismatch")

    run_authority = _require_mapping(model_run.get("input_authority"), "model-run authority")
    if (
        run_authority.get("proposals_sha256") != file_hashes["proposals"]
        or run_authority.get("proposals_canonical_sha256")
        != proposals.get("proposals_canonical_sha256")
        or run_authority.get("blind_packet_sha256") != file_hashes["blind_packet"]
        or run_authority.get("blind_packet_canonical_sha256")
        != blind_packet.get("packet_canonical_sha256")
    ):
        raise ScopedAISemanticTimingError("model run is bound to different semantic inputs")
    if model_run.get("semantic_selection_used_candidate_timing") is not False:
        raise ScopedAISemanticTimingError("model semantic selection used timing")
    if model_run.get("blind_packet_contains_numeric_timing_values") is not False:
        raise ScopedAISemanticTimingError("model semantic input contained timing")
    if model_run.get("timing_metric_rows") != 0:
        raise ScopedAISemanticTimingError("source model run already claims timing metrics")
    if model_run.get("automatic_timing_mutation") is not False:
        raise ScopedAISemanticTimingError("source model run mutation boundary is unsafe")
    if model_run.get("production_release_verdict") is not False:
        raise ScopedAISemanticTimingError("source model run release boundary is unsafe")

    references_raw = _require_list(proposals.get("reference_units"), "reference units")
    spans_raw = _require_list(proposals.get("candidate_spans"), "candidate spans")
    atoms_raw = _require_list(proposals.get("candidate_atoms"), "candidate atoms")
    packet_units_raw = _require_list(blind_packet.get("units"), "blind units")
    bundle_units_raw = _require_list(bundle.get("units"), "bundle units")
    bundle_cues_raw = _require_list(bundle.get("candidate_cues"), "bundle candidate cues")

    references: dict[str, Mapping[str, object]] = {}
    for raw in references_raw:
        row = _require_mapping(raw, "reference unit")
        unit_id = _require_text(row.get("unit_id"), "reference unit ID")
        ordinal = _require_int(row.get("ordinal"), "reference ordinal", minimum=1)
        text = _require_text(row.get("text"), "reference text")
        if row.get("text_sha256") != _sha256_text(text) or unit_id in references:
            raise ScopedAISemanticTimingError("reference text identity is invalid")
        references[unit_id] = row

    atoms: dict[str, Mapping[str, object]] = {}
    for raw in atoms_raw:
        row = _require_mapping(raw, "candidate atom")
        atom_id = _require_text(row.get("atom_id"), "candidate atom ID")
        ordinal = _require_int(row.get("ordinal"), "candidate atom ordinal", minimum=1)
        text = _require_text(row.get("text"), "candidate atom text")
        if row.get("text_sha256") != _sha256_text(text) or atom_id in atoms:
            raise ScopedAISemanticTimingError("candidate atom identity is invalid")
        atoms[atom_id] = row
        _ = ordinal

    spans: dict[str, Mapping[str, object]] = {}
    for raw in spans_raw:
        row = _require_mapping(raw, "candidate span")
        span_id = _require_text(row.get("span_id"), "candidate span ID")
        atom_ids = _require_list(row.get("atom_ids"), "candidate span atom IDs")
        if (
            span_id in spans
            or not atom_ids
            or any(not isinstance(atom, str) or atom not in atoms for atom in atom_ids)
            or len(atom_ids) != len(set(atom_ids))
        ):
            raise ScopedAISemanticTimingError("candidate span identity is invalid")
        first = _require_int(row.get("first_ordinal"), "candidate span first ordinal", minimum=1)
        last = _require_int(row.get("last_ordinal"), "candidate span last ordinal", minimum=first)
        ordinals = [_require_int(atoms[str(atom)]["ordinal"], "candidate atom ordinal") for atom in atom_ids]
        if ordinals != list(range(first, last + 1)):
            raise ScopedAISemanticTimingError("candidate span is not contiguous")
        spans[span_id] = row

    packet_units: dict[str, Mapping[str, object]] = {}
    for raw in packet_units_raw:
        row = _require_mapping(raw, "blind unit")
        unit_id = _require_text(row.get("reference_unit_id"), "blind reference ID")
        if unit_id in packet_units or unit_id not in references:
            raise ScopedAISemanticTimingError("blind reference ownership is invalid")
        packet_units[unit_id] = row

    bundle_units: dict[str, Mapping[str, object]] = {}
    for raw in bundle_units_raw:
        row = _require_mapping(raw, "bundle unit")
        unit_id = _require_text(row.get("unit_id"), "bundle unit ID")
        if unit_id in bundle_units or unit_id not in references:
            raise ScopedAISemanticTimingError("bundle reference ownership is invalid")
        if row.get("reference_text") != references[unit_id].get("text"):
            raise ScopedAISemanticTimingError("bundle/proposal reference text mismatch")
        start = _require_int(row.get("reference_start_ms"), "reference start", minimum=0)
        end = _require_int(row.get("reference_end_ms"), "reference end", minimum=start + 1)
        bundle_units[unit_id] = row
        _ = end

    bundle_cues: dict[str, Mapping[str, object]] = {}
    for raw in bundle_cues_raw:
        row = _require_mapping(raw, "bundle cue")
        cue_id = _require_text(row.get("cue_id"), "bundle cue ID")
        if cue_id in bundle_cues or cue_id not in atoms:
            raise ScopedAISemanticTimingError("bundle candidate cue ownership is invalid")
        if row.get("text") != atoms[cue_id].get("text"):
            raise ScopedAISemanticTimingError("bundle/proposal candidate text mismatch")
        start = _require_int(row.get("start_ms"), "candidate start", minimum=0)
        end = _require_int(row.get("end_ms"), "candidate end", minimum=start + 1)
        bundle_cues[cue_id] = row
        _ = end

    run_scope = _require_mapping(model_run.get("scope"), "model-run scope")
    start_ordinal = _require_int(
        run_scope.get("sample_reference_ordinal_start"), "sample start ordinal", minimum=1
    )
    end_ordinal = _require_int(
        run_scope.get("sample_reference_ordinal_end"),
        "sample end ordinal",
        minimum=start_ordinal,
    )
    sample_count = _require_int(
        run_scope.get("sample_reference_units"), "sample reference count", minimum=1
    )
    if end_ordinal - start_ordinal + 1 != sample_count:
        raise ScopedAISemanticTimingError("model-run sample window is not contiguous")

    judgments_raw = _require_list(model_run.get("judgments"), "model judgments")
    if len(judgments_raw) != sample_count:
        raise ScopedAISemanticTimingError("model judgment count mismatch")

    rows: list[dict[str, object]] = []
    previous_reference_ordinal = 0
    previous_candidate_last = 0
    owned_atoms: set[str] = set()
    start_abs_values: list[int] = []
    end_abs_values: list[int] = []
    max_edge_values: list[int] = []
    structural_rejections = Counter()

    for offset, raw in enumerate(judgments_raw):
        wrapper = _require_mapping(raw, "model judgment wrapper")
        expected_ordinal = start_ordinal + offset
        unit_id = _require_text(wrapper.get("reference_unit_id"), "judgment reference ID")
        ordinal = _require_int(wrapper.get("reference_ordinal"), "judgment ordinal", minimum=1)
        if ordinal != expected_ordinal or ordinal <= previous_reference_ordinal:
            raise ScopedAISemanticTimingError("model judgments are not a complete ordered window")
        reference = references.get(unit_id)
        if reference is None or reference.get("ordinal") != ordinal:
            raise ScopedAISemanticTimingError("model judgment reference identity mismatch")
        bundle_unit = bundle_units.get(unit_id)
        packet_unit = packet_units.get(unit_id)
        if bundle_unit is None or packet_unit is None:
            raise ScopedAISemanticTimingError("model judgment is not bound to source units")
        judgment = _require_mapping(wrapper.get("judgment"), "model judgment")
        audit = _require_mapping(judgment.get("audit"), "model judgment audit")
        status = str(audit.get("status") or "unknown")
        relation = judgment.get("relation")
        span_id = judgment.get("candidate_span_id")
        evidence = judgment.get("evidence_atom_ids")
        row: dict[str, object] = {
            "reference_unit_id": unit_id,
            "reference_ordinal": ordinal,
            "reference_text": reference["text"],
            "reference_start_ms": bundle_unit["reference_start_ms"],
            "reference_end_ms": bundle_unit["reference_end_ms"],
            "model_status": status,
            "model_relation": relation,
            "candidate_span_id": span_id,
            "candidate_atom_ids": evidence if isinstance(evidence, list) else [],
            "candidate_text": None,
            "semantic_timing_status": "UNASSESSABLE",
            "timing_grade": "UNASSESSABLE",
            "reason": "model_did_not_propose_same_meaning",
        }
        previous_reference_ordinal = ordinal
        if status != "model_proposed" or relation != "same_meaning":
            structural_rejections[row["reason"]] += 1
            rows.append(row)
            continue
        if not isinstance(span_id, str) or span_id not in spans:
            raise ScopedAISemanticTimingError("model selected unknown candidate span")
        span = spans[span_id]
        span_atoms = span.get("atom_ids")
        if not isinstance(span_atoms, list) or evidence != span_atoms:
            raise ScopedAISemanticTimingError("model evidence does not own the full candidate span")
        options = packet_unit.get("candidate_options")
        if not isinstance(options, list) or not any(
            isinstance(option, Mapping)
            and option.get("candidate_span_id") == span_id
            and option.get("candidate_atom_ids") == span_atoms
            for option in options
        ):
            raise ScopedAISemanticTimingError("model span is not in its blind candidate options")
        first = _require_int(span.get("first_ordinal"), "span first ordinal", minimum=1)
        last = _require_int(span.get("last_ordinal"), "span last ordinal", minimum=first)
        if first <= previous_candidate_last or owned_atoms.intersection(str(atom) for atom in span_atoms):
            row["reason"] = "duplicate_or_non_monotonic_candidate_path"
            structural_rejections[row["reason"]] += 1
            rows.append(row)
            continue
        selected_cues = [bundle_cues[str(atom)] for atom in span_atoms]
        candidate_start = min(int(cue["start_ms"]) for cue in selected_cues)
        candidate_end = max(int(cue["end_ms"]) for cue in selected_cues)
        reference_start = int(bundle_unit["reference_start_ms"])
        reference_end = int(bundle_unit["reference_end_ms"])
        start_error = candidate_start - reference_start
        end_error = candidate_end - reference_end
        start_abs = abs(start_error)
        end_abs = abs(end_error)
        max_edge = max(start_abs, end_abs)
        row.update(
            {
                "candidate_atom_ids": list(span_atoms),
                "candidate_text": span.get("text"),
                "candidate_start_ms": candidate_start,
                "candidate_end_ms": candidate_end,
                "start_error_ms": start_error,
                "end_error_ms": end_error,
                "start_absolute_error_ms": start_abs,
                "end_absolute_error_ms": end_abs,
                "max_edge_absolute_error_ms": max_edge,
                "semantic_timing_status": "ELIGIBLE_AI_SCOPED_REFERENCE_ONLY",
                "timing_grade": _timing_grade(start_abs, end_abs),
                "reason": "same_meaning_unique_monotonic_path",
            }
        )
        previous_candidate_last = last
        owned_atoms.update(str(atom) for atom in span_atoms)
        start_abs_values.append(start_abs)
        end_abs_values.append(end_abs)
        max_edge_values.append(max_edge)
        rows.append(row)

    eligible = len(start_abs_values)
    grade_counts = Counter(str(row["timing_grade"]) for row in rows)
    relation_counts = Counter(str(row.get("model_relation")) for row in rows)
    status_counts = Counter(str(row.get("model_status")) for row in rows)
    worst = sorted(
        (row for row in rows if row["semantic_timing_status"].startswith("ELIGIBLE")),
        key=lambda row: int(row["max_edge_absolute_error_ms"]),
        reverse=True,
    )[:10]
    report: dict[str, object] = {
        "schema": "cts.o8-scoped-ai-semantic-timing-report/v1",
        "policy_version": SCOPED_AI_SEMANTIC_TIMING_POLICY_VERSION,
        "scope": {
            "video_id": SCOPED_VIDEO_ID,
            "youtube_url": SCOPED_YOUTUBE_URL,
            "scoped_reference_role": "gold for this O8 comparison only",
            "ai_semantic_validation": True,
            "human_confirmation": False,
            "production_wide_human_gold_claim": False,
            "broader_human_gold_gate_overwritten": False,
            "automatic_timing_mutation": False,
            "production_release_verdict": False,
        },
        "input_bindings": {
            "file_sha256": dict(file_hashes),
            "proposals_canonical_sha256": proposals["proposals_canonical_sha256"],
            "blind_packet_canonical_sha256": blind_packet["packet_canonical_sha256"],
            "bundle_canonical_sha256": bundle["bundle_canonical_sha256"],
            "model_run_canonical_sha256": model_run["run_canonical_sha256"],
        },
        "sample": {
            "reference_ordinal_start": start_ordinal,
            "reference_ordinal_end": end_ordinal,
            "reference_units": sample_count,
            "full_reference_units": len(references),
            "eligible_timing_rows": eligible,
            "eligible_coverage": eligible / sample_count,
        },
        "semantic_model_counts": {
            "status": dict(sorted(status_counts.items())),
            "relation": dict(sorted(relation_counts.items())),
            "structural_rejections": dict(sorted(structural_rejections.items())),
        },
        "timing": {
            "grade_counts": {
                grade: grade_counts.get(grade, 0)
                for grade in ("ON_TIME", "SLIGHT_OFFSET", "OFF_TIME", "UNASSESSABLE")
            },
            "start_absolute_error_ms": _stats(start_abs_values),
            "end_absolute_error_ms": _stats(end_abs_values),
            "max_edge_absolute_error_ms": _stats(max_edge_values),
            "bands": {
                "ON_TIME": "both selected cue edges <= 500 ms",
                "SLIGHT_OFFSET": "both selected cue edges <= 2000 ms but not ON_TIME",
                "OFF_TIME": "at least one selected cue edge > 2000 ms",
                "UNASSESSABLE": "no accepted same-meaning unique monotonic semantic path",
            },
            "percentile_method": "linear interpolation at rank (n-1)*p",
            "measurement_target": "sealed CTS display cue edges versus grouped O8 reference cue edges",
            "acoustic_onset_or_offset_proof": False,
        },
        "rows": rows,
        "failure_samples": worst,
        "claims": [
            {
                "label": "FACT",
                "confidence": 100,
                "claim": "The local semantic model saw only the timestamp-free blind packet; CTS and reference times were joined after immutable-ID selection.",
            },
            {
                "label": "FACT",
                "confidence": 100,
                "claim": "Only same_meaning selections on a unique forward-only candidate path contribute timing rows.",
            },
            {
                "label": "INFERENCE",
                "confidence": 70,
                "claim": "Accepted rows estimate edit burden for this scoped O8 reference; they do not establish acoustic speech boundaries.",
            },
            {
                "label": "UNKNOWN",
                "confidence": 100,
                "claim": "Production-wide accuracy and release readiness remain unproven.",
            },
        ],
    }
    report["report_canonical_sha256"] = canonical_sha256(report)
    return report


__all__ = [
    "SCOPED_AI_SEMANTIC_TIMING_POLICY_VERSION",
    "SCOPED_VIDEO_ID",
    "SCOPED_YOUTUBE_URL",
    "ScopedAISemanticTimingError",
    "evaluate_scoped_ai_semantic_timing",
]
