"""Fail-closed receipt handling for a timestamp-free external model crosscheck.

This module is intentionally parallel to the existing human-confirmation path.
It can capture agreement between the local semantic proposer and one external
model for a *single scoped semantic diagnostic*.  It must never impersonate a
human confirmation, mutate a CTS Job, or make a timing/release verdict.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping, Sequence
from typing import Any

from .semantic_pairing import (
    BLIND_REVIEW_PACKET_SCHEMA,
    SemanticPairingError,
    assert_no_timestamp_fields,
    canonical_sha256,
    validate_blind_review_packet_shape,
)


REQUEST_SCHEMA = "cts.semantic-pairing-independent-model-crosscheck-request/v1"
RESPONSE_SCHEMA = "cts.semantic-pairing-independent-model-crosscheck-response/v1"
RECEIPT_SCHEMA = "cts.semantic-pairing-independent-model-crosscheck-receipt/v1"
AGREEMENT_SCHEMA = "cts.semantic-pairing-model-agreement/v1"
POLICY_VERSION = "independent-semantic-crosscheck-m0-2026-09-03"
_LOCAL_RUN_SCHEMA = "cts.local-semantic-pair-judge-run/v1"
_HEX = frozenset("0123456789abcdef")
_NONCE = re.compile(r"[0-9a-f]{32}\Z")
_CHATGPT_CONVERSATION_URL = re.compile(r"https://chatgpt\.com/c/[A-Za-z0-9-]+\Z")
_RELATIONS = frozenset({"same_meaning", "partial", "different", "uncertain"})
_ABSTAIN_RELATIONS = frozenset({"uncertain", "different"})
_SCOPED_VIDEO_ID = "O8IB7nao2K4"
_RESPONSE_LIMITATIONS = [
    "Meaning-only review; no timing was provided or assessed.",
    "This response is not a human confirmation receipt.",
    "This response cannot create a production or release verdict.",
]


class IndependentModelCrosscheckError(ValueError):
    """The external-model evidence is incomplete, unbound, or unsafe."""


def _is_sha256(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in _HEX for character in value)
    )


def _mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise IndependentModelCrosscheckError(f"{label} 必須係 object")
    return value


def _list(value: object, label: str) -> Sequence[object]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise IndependentModelCrosscheckError(f"{label} 必須係 array")
    return value


def _text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise IndependentModelCrosscheckError(f"{label} 必須係非空文字")
    return value


def _validate_canonical(value: Mapping[str, object], *, schema: str, field: str, label: str) -> None:
    if value.get("schema") != schema:
        raise IndependentModelCrosscheckError(f"{label} schema 不符合")
    claimed = value.get(field)
    if not _is_sha256(claimed):
        raise IndependentModelCrosscheckError(f"{label} canonical hash 無效")
    body = dict(value)
    body.pop(field, None)
    if canonical_sha256(body) != claimed:
        raise IndependentModelCrosscheckError(f"{label} canonical hash mismatch")


def _response_contract() -> dict[str, object]:
    return {
        "schema": RESPONSE_SCHEMA,
        "required_response_keys": [
            "schema",
            "request_canonical_sha256",
            "reviewer_identity",
            "responses",
            "review_limitations",
        ],
        "response_row_keys": [
            "reference_unit_id",
            "candidate_span_id",
            "relation",
            "evidence_atom_ids",
        ],
        "allowed_relations": ["same_meaning", "partial", "different", "uncertain"],
        "abstention": {
            "candidate_span_id": "abstain",
            "relations": ["uncertain", "different"],
            "evidence_atom_ids": [],
        },
    }


def _request_scope() -> dict[str, object]:
    return {
        "scoped_reference_only": True,
        "production_wide_human_gold_claim": False,
        "semantic_only": True,
        "automatic_timing_mutation": False,
        "production_release_verdict": False,
    }


def _receipt_scope() -> dict[str, object]:
    return {
        **_request_scope(),
        "timing_metric_rows": 0,
    }


def _assert_no_human_claim(value: object) -> None:
    if isinstance(value, Mapping):
        for key, child in value.items():
            if not isinstance(key, str):
                raise IndependentModelCrosscheckError("receipt key 必須係文字")
            if key == "human_confirmed" or key.startswith("human_confirmation_"):
                raise IndependentModelCrosscheckError("external-model receipt 不可聲稱 human confirmation")
            _assert_no_human_claim(child)
    elif isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        for child in value:
            _assert_no_human_claim(child)


def _packet_units(packet: Mapping[str, object]) -> dict[str, Mapping[str, object]]:
    try:
        assert_no_timestamp_fields(packet)
        validate_blind_review_packet_shape(packet)
        _validate_canonical(
            packet,
            schema=BLIND_REVIEW_PACKET_SCHEMA,
            field="packet_canonical_sha256",
            label="blind review packet",
        )
    except SemanticPairingError as exc:
        raise IndependentModelCrosscheckError("blind review packet 無效") from exc
    units = _list(packet.get("units"), "blind review packet units")
    result: dict[str, Mapping[str, object]] = {}
    for raw_unit in units:
        unit = _mapping(raw_unit, "blind review packet unit")
        identifier = _text(unit.get("reference_unit_id"), "reference unit ID")
        text = _text(unit.get("reference_text"), "reference text")
        if unit.get("reference_text_sha256") != hashlib.sha256(text.encode("utf-8")).hexdigest():
            raise IndependentModelCrosscheckError("reference text hash 無效")
        if identifier in result:
            raise IndependentModelCrosscheckError("duplicate reference unit ID")
        result[identifier] = unit
    return result


def _validate_request(
    request: Mapping[str, object], blind_review_packet: Mapping[str, object]
) -> list[Mapping[str, object]]:
    expected_keys = {
        "schema",
        "policy_version",
        "request_nonce",
        "scope",
        "source_binding",
        "response_contract",
        "units",
        "request_canonical_sha256",
    }
    if set(request) != expected_keys:
        raise IndependentModelCrosscheckError("external request schema keys 不符合")
    _validate_canonical(
        request,
        schema=REQUEST_SCHEMA,
        field="request_canonical_sha256",
        label="external request",
    )
    try:
        assert_no_timestamp_fields(request)
    except SemanticPairingError as exc:
        raise IndependentModelCrosscheckError("external request 洩漏 timestamp field") from exc
    if request.get("policy_version") != POLICY_VERSION:
        raise IndependentModelCrosscheckError("external request policy 不符合")
    nonce = request.get("request_nonce")
    if not isinstance(nonce, str) or _NONCE.fullmatch(nonce) is None:
        raise IndependentModelCrosscheckError("external request nonce 無效")
    if request.get("scope") != _request_scope():
        raise IndependentModelCrosscheckError("external request scope 不符合")
    if request.get("response_contract") != _response_contract():
        raise IndependentModelCrosscheckError("external request response contract 不符合")

    packet_units = _packet_units(blind_review_packet)
    packet_hash = blind_review_packet.get("packet_canonical_sha256")
    authority = _mapping(blind_review_packet.get("authority"), "blind review packet authority")
    packet_scope = _mapping(blind_review_packet.get("scope"), "blind review packet scope")
    if (
        packet_scope.get("video_id") != _SCOPED_VIDEO_ID
        or packet_scope.get("production_wide_human_gold_claim") is not False
    ):
        raise IndependentModelCrosscheckError("external crosscheck 只接受 O8 scoped non-production packet")
    binding = _mapping(request.get("source_binding"), "external request source binding")
    if set(binding) != {
        "blind_review_packet_canonical_sha256",
        "blind_review_packet_file_sha256",
        "candidate_text_projection_sha256",
    }:
        raise IndependentModelCrosscheckError("external request source binding keys 不符合")
    if (
        binding.get("blind_review_packet_canonical_sha256") != packet_hash
        or not _is_sha256(binding.get("blind_review_packet_file_sha256"))
        or binding.get("candidate_text_projection_sha256")
        != authority.get("candidate_text_projection_sha256")
    ):
        raise IndependentModelCrosscheckError("external request 未綁定 blind packet")

    raw_units = _list(request.get("units"), "external request units")
    if not 1 <= len(raw_units) <= 30:
        raise IndependentModelCrosscheckError("external request unit count 不符合")
    selected: list[Mapping[str, object]] = []
    seen: set[str] = set()
    for raw_unit in raw_units:
        unit = _mapping(raw_unit, "external request unit")
        identifier = _text(unit.get("reference_unit_id"), "external request reference unit ID")
        packet_unit = packet_units.get(identifier)
        if packet_unit is None or identifier in seen or dict(unit) != dict(packet_unit):
            raise IndependentModelCrosscheckError("external request unit 未精確綁定 blind packet")
        seen.add(identifier)
        selected.append(packet_unit)
    return selected


def parse_external_model_response(raw_response: str) -> dict[str, object]:
    """Parse one captured raw model response; prose/code fences fail closed."""

    if not isinstance(raw_response, str) or not raw_response.strip():
        raise IndependentModelCrosscheckError("external raw response 為空")
    try:
        response = json.loads(raw_response)
    except json.JSONDecodeError as exc:
        raise IndependentModelCrosscheckError("external raw response 不是 strict JSON") from exc
    if not isinstance(response, dict):
        raise IndependentModelCrosscheckError("external raw response root 必須係 object")
    return response


def _validate_decisions(
    responses: object, selected_units: Sequence[Mapping[str, object]]
) -> list[dict[str, object]]:
    rows = _list(responses, "external response rows")
    if len(rows) != len(selected_units):
        raise IndependentModelCrosscheckError("external response row count 不符合")
    result: list[dict[str, object]] = []
    for expected_unit, raw_row in zip(selected_units, rows):
        row = _mapping(raw_row, "external response row")
        if set(row) != {
            "reference_unit_id",
            "candidate_span_id",
            "relation",
            "evidence_atom_ids",
        }:
            raise IndependentModelCrosscheckError("external response row schema 不符合")
        reference_id = expected_unit.get("reference_unit_id")
        if row.get("reference_unit_id") != reference_id:
            raise IndependentModelCrosscheckError("external response row order 或 ID 不符合")
        candidate_span_id = row.get("candidate_span_id")
        relation = row.get("relation")
        evidence = row.get("evidence_atom_ids")
        if candidate_span_id == "abstain":
            if relation not in _ABSTAIN_RELATIONS or evidence != []:
                raise IndependentModelCrosscheckError("external response abstention 不符合")
            result.append(dict(row))
            continue
        if not isinstance(candidate_span_id, str) or relation not in _RELATIONS:
            raise IndependentModelCrosscheckError("external response candidate 或 relation 無效")
        options = _list(expected_unit.get("candidate_options"), "blind candidate options")
        option = next(
            (
                _mapping(item, "blind candidate option")
                for item in options
                if isinstance(item, Mapping) and item.get("candidate_span_id") == candidate_span_id
            ),
            None,
        )
        if option is None:
            raise IndependentModelCrosscheckError("external response candidate 不屬於該 reference unit")
        if evidence != option.get("candidate_atom_ids"):
            raise IndependentModelCrosscheckError("external response evidence 必須完整、按序覆蓋 candidate atoms")
        result.append(dict(row))
    return result


def validate_external_model_response(
    response: Mapping[str, object],
    *,
    request: Mapping[str, object],
    blind_review_packet: Mapping[str, object],
) -> list[dict[str, object]]:
    """Validate a strict, blind external-model response without granting a gate."""

    selected_units = _validate_request(request, blind_review_packet)
    if set(response) != {
        "schema",
        "request_canonical_sha256",
        "reviewer_identity",
        "responses",
        "review_limitations",
    }:
        raise IndependentModelCrosscheckError("external response schema keys 不符合")
    if (
        response.get("schema") != RESPONSE_SCHEMA
        or response.get("request_canonical_sha256")
        != request.get("request_canonical_sha256")
        or not isinstance(response.get("reviewer_identity"), str)
        or not response["reviewer_identity"].strip()
        or response.get("review_limitations") != _RESPONSE_LIMITATIONS
    ):
        raise IndependentModelCrosscheckError("external response binding 或 limitations 不符合")
    return _validate_decisions(response.get("responses"), selected_units)


def _validate_capture(capture: Mapping[str, object]) -> dict[str, object]:
    expected_keys = {
        "fresh_isolated_chat",
        "provider_readback",
        "provider_identity_status",
        "conversation_url",
    }
    if set(capture) != expected_keys:
        raise IndependentModelCrosscheckError("external capture schema keys 不符合")
    if (
        capture.get("fresh_isolated_chat") is not True
        or capture.get("provider_readback") is not True
        or capture.get("provider_identity_status") not in {"OBSERVED", "UNKNOWN"}
        or not isinstance(capture.get("conversation_url"), str)
        or _CHATGPT_CONVERSATION_URL.fullmatch(str(capture["conversation_url"])) is None
    ):
        raise IndependentModelCrosscheckError("external capture 未通過 fresh/readback gate")
    return dict(capture)


def build_external_model_crosscheck_receipt(
    *,
    request: Mapping[str, object],
    blind_review_packet: Mapping[str, object],
    raw_response: str,
    capture: Mapping[str, object],
) -> dict[str, object]:
    """Capture external-model output as non-human, non-timing evidence only."""

    response = parse_external_model_response(raw_response)
    decisions = validate_external_model_response(
        response, request=request, blind_review_packet=blind_review_packet
    )
    checked_capture = _validate_capture(capture)
    packet_hash = blind_review_packet.get("packet_canonical_sha256")
    receipt: dict[str, object] = {
        "schema": RECEIPT_SCHEMA,
        "policy_version": POLICY_VERSION,
        "actor_kind": "external_model_not_human",
        "scope": _receipt_scope(),
        "authority": {
            "blind_review_packet_canonical_sha256": packet_hash,
            "external_request_canonical_sha256": request["request_canonical_sha256"],
            "external_request_nonce": request["request_nonce"],
            "raw_response_sha256": hashlib.sha256(raw_response.encode("utf-8")).hexdigest(),
        },
        "capture": checked_capture,
        "reviewer_identity": response["reviewer_identity"],
        "decisions": decisions,
        "boundaries": {
            "human_confirmation": False,
            "timing_metric_rows": 0,
            "automatic_timing_mutation": False,
            "production_release_verdict": False,
        },
    }
    receipt["receipt_canonical_sha256"] = canonical_sha256(receipt)
    _assert_no_human_claim(receipt)
    return receipt


def validate_external_model_crosscheck_receipt(
    receipt: Mapping[str, object],
    *,
    request: Mapping[str, object],
    blind_review_packet: Mapping[str, object],
) -> list[dict[str, object]]:
    """Recheck a stored receipt without trusting its local canonical hash alone."""

    expected_keys = {
        "schema",
        "policy_version",
        "actor_kind",
        "scope",
        "authority",
        "capture",
        "reviewer_identity",
        "decisions",
        "boundaries",
        "receipt_canonical_sha256",
    }
    _assert_no_human_claim(receipt)
    if set(receipt) != expected_keys:
        raise IndependentModelCrosscheckError("external receipt schema keys 不符合")
    _validate_canonical(
        receipt,
        schema=RECEIPT_SCHEMA,
        field="receipt_canonical_sha256",
        label="external-model receipt",
    )
    if (
        receipt.get("policy_version") != POLICY_VERSION
        or receipt.get("actor_kind") != "external_model_not_human"
        or receipt.get("scope") != _receipt_scope()
        or receipt.get("boundaries")
        != {
            "human_confirmation": False,
            "timing_metric_rows": 0,
            "automatic_timing_mutation": False,
            "production_release_verdict": False,
        }
        or not isinstance(receipt.get("reviewer_identity"), str)
        or not receipt["reviewer_identity"].strip()
    ):
        raise IndependentModelCrosscheckError("external receipt policy boundary 不符合")
    selected = _validate_request(request, blind_review_packet)
    authority = _mapping(receipt.get("authority"), "external receipt authority")
    if set(authority) != {
        "blind_review_packet_canonical_sha256",
        "external_request_canonical_sha256",
        "external_request_nonce",
        "raw_response_sha256",
    } or (
        authority.get("blind_review_packet_canonical_sha256")
        != blind_review_packet.get("packet_canonical_sha256")
        or authority.get("external_request_canonical_sha256")
        != request.get("request_canonical_sha256")
        or authority.get("external_request_nonce") != request.get("request_nonce")
        or not _is_sha256(authority.get("raw_response_sha256"))
    ):
        raise IndependentModelCrosscheckError("external receipt authority binding 不符合")
    _validate_capture(_mapping(receipt.get("capture"), "external receipt capture"))
    return _validate_decisions(receipt.get("decisions"), selected)


def build_scoped_model_agreement(
    *,
    reference_unit_id: str,
    local_run: Mapping[str, object],
    external_receipt: Mapping[str, object],
    request: Mapping[str, object],
    blind_review_packet: Mapping[str, object],
) -> dict[str, object]:
    """Make a semantic-only agreement record; it is never a human/timing gate."""

    selected = _validate_request(request, blind_review_packet)
    external = validate_external_model_crosscheck_receipt(
        external_receipt, request=request, blind_review_packet=blind_review_packet
    )
    if not isinstance(reference_unit_id, str) or not reference_unit_id:
        raise IndependentModelCrosscheckError("reference unit ID 無效")
    unit = next(
        (item for item in selected if item.get("reference_unit_id") == reference_unit_id),
        None,
    )
    external_row = next(
        (item for item in external if item.get("reference_unit_id") == reference_unit_id),
        None,
    )
    if unit is None or external_row is None:
        raise IndependentModelCrosscheckError("reference unit 不在 crosscheck sample")

    _validate_canonical(
        local_run,
        schema=_LOCAL_RUN_SCHEMA,
        field="run_canonical_sha256",
        label="local semantic run",
    )
    if (
        local_run.get("blind_packet_contains_numeric_timing_values") is not False
        or local_run.get("semantic_selection_used_candidate_timing") is not False
        or local_run.get("timing_metric_rows") != 0
        or local_run.get("automatic_timing_mutation") is not False
        or local_run.get("production_release_verdict") is not False
    ):
        raise IndependentModelCrosscheckError("local semantic run policy boundary 不符合")
    local_authority = _mapping(local_run.get("input_authority"), "local semantic run authority")
    if local_authority.get("blind_packet_canonical_sha256") != blind_review_packet.get(
        "packet_canonical_sha256"
    ):
        raise IndependentModelCrosscheckError("local semantic run 未綁定同一 blind packet")
    local_rows = _list(local_run.get("judgments"), "local semantic judgments")
    local_judgment: Mapping[str, object] | None = None
    for raw_row in local_rows:
        row = _mapping(raw_row, "local semantic judgment row")
        if row.get("reference_unit_id") == reference_unit_id:
            judgment = _mapping(row.get("judgment"), "local semantic judgment")
            local_judgment = judgment
            break
    if local_judgment is None:
        raise IndependentModelCrosscheckError("local semantic judgment missing")
    local_model = _mapping(local_run.get("model"), "local semantic model")
    local_model_identity = _text(local_model.get("requested_model"), "local semantic model identity")
    external_capture = _mapping(external_receipt.get("capture"), "external-model capture")
    if external_capture.get("provider_identity_status") != "OBSERVED":
        raise IndependentModelCrosscheckError("external provider identity 未觀察，不能形成 model agreement")
    if str(external_receipt.get("reviewer_identity", "")).strip() == local_model_identity:
        raise IndependentModelCrosscheckError("external reviewer identity 不可等於本機模型")
    if (
        local_judgment.get("relation") != "same_meaning"
        or external_row.get("relation") != "same_meaning"
        or local_judgment.get("candidate_span_id") != external_row.get("candidate_span_id")
    ):
        raise IndependentModelCrosscheckError("models 未達 same-span same-meaning agreement")
    candidate_span_id = external_row.get("candidate_span_id")
    options = _list(unit.get("candidate_options"), "blind candidate options")
    option = next(
        (
            _mapping(item, "blind candidate option")
            for item in options
            if isinstance(item, Mapping) and item.get("candidate_span_id") == candidate_span_id
        ),
        None,
    )
    if option is None:
        raise IndependentModelCrosscheckError("agreed candidate span missing")
    atoms = option.get("candidate_atom_ids")
    if (
        local_judgment.get("evidence_atom_ids") != atoms
        or external_row.get("evidence_atom_ids") != atoms
    ):
        raise IndependentModelCrosscheckError("model evidence 未完整、按序覆蓋 candidate atoms")
    agreement: dict[str, object] = {
        "schema": AGREEMENT_SCHEMA,
        "policy_version": POLICY_VERSION,
        "status": "MODEL_AGREEMENT_SCOPED_SEMANTIC_ONLY_NOT_HUMAN_GOLD",
        "scope": {
            "scoped_reference_only": True,
            "production_wide_human_gold_claim": False,
            "human_confirmation": False,
            "timing_metric_rows": 0,
            "automatic_timing_mutation": False,
            "production_release_verdict": False,
        },
        "authority": {
            "blind_review_packet_canonical_sha256": blind_review_packet[
                "packet_canonical_sha256"
            ],
            "external_request_canonical_sha256": request["request_canonical_sha256"],
            "local_run_canonical_sha256": local_run["run_canonical_sha256"],
            "external_receipt_canonical_sha256": external_receipt[
                "receipt_canonical_sha256"
            ],
        },
        "decision": {
            "reference_unit_id": reference_unit_id,
            "candidate_span_id": candidate_span_id,
            "relation": "same_meaning",
            "evidence_atom_ids": atoms,
            "candidate_text_sha256": option.get("candidate_text_sha256"),
        },
    }
    agreement["agreement_canonical_sha256"] = canonical_sha256(agreement)
    _assert_no_human_claim(agreement)
    return agreement


__all__ = [
    "AGREEMENT_SCHEMA",
    "IndependentModelCrosscheckError",
    "POLICY_VERSION",
    "RECEIPT_SCHEMA",
    "REQUEST_SCHEMA",
    "RESPONSE_SCHEMA",
    "build_external_model_crosscheck_receipt",
    "build_scoped_model_agreement",
    "parse_external_model_response",
    "validate_external_model_crosscheck_receipt",
    "validate_external_model_response",
]
