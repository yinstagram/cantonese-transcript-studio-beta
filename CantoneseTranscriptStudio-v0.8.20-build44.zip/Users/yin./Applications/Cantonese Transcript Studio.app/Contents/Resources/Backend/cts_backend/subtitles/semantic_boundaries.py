"""Fail-closed local-LLM selector for subtitle boundary identifiers.

The model is never allowed to generate subtitle text.  A caller first derives
safe integer offsets from the deterministic segmenter, then this optional
provider may select a subset of those offsets.  Any transport, schema, or
validation failure returns an empty selection so the normal precise splitter
can continue without the local model.
"""

from __future__ import annotations

import json
import socket
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any, Sequence


SEMANTIC_BOUNDARY_POLICY_VERSION = "local-boundary-selector-v1"
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "::1"})
_CHAT_COMPLETIONS_PATH = "/v1/chat/completions"
_MAX_CANDIDATES = 512
_MAX_TRANSCRIPT_CHARACTERS = 100_000
_MAX_SELECTED_BOUNDARIES = 24


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Prevent a loopback server from redirecting private text off-device."""

    def redirect_request(self, *_: object, **__: object) -> None:
        return None


@dataclass(frozen=True)
class SemanticBoundaryAudit:
    """Privacy-safe selector audit; deliberately contains no transcript text."""

    status: str
    model: str
    candidate_count: int
    selected_count: int
    reason: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class SemanticBoundarySelectionResult:
    """Validated model selection plus non-text audit metadata."""

    boundary_ids: tuple[int, ...]
    audit: SemanticBoundaryAudit

    def to_dict(self) -> dict[str, object]:
        return {
            "boundary_ids": list(self.boundary_ids),
            "audit": self.audit.to_dict(),
        }


def _validated_endpoint(endpoint: str) -> str:
    if not isinstance(endpoint, str) or not endpoint:
        raise ValueError("semantic boundary endpoint 唔可以空白")
    try:
        parsed = urllib.parse.urlsplit(endpoint)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("semantic boundary endpoint 無效") from exc
    if (
        parsed.scheme != "http"
        or parsed.hostname not in _LOOPBACK_HOSTS
        or port is None
        or not 1024 <= port <= 65_535
        or parsed.path.rstrip("/") != _CHAT_COMPLETIONS_PATH
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or not parsed.netloc
    ):
        raise ValueError(
            "semantic boundary endpoint 必須係本機 loopback chat completions"
        )
    return endpoint


def _strict_boundary_ids(
    content: str, candidate_boundary_ids: Sequence[int]
) -> tuple[bool, tuple[int, ...], str]:
    """Validate one exact JSON object and preserve deterministic caller order."""

    try:
        value = json.loads(content)
    except (TypeError, json.JSONDecodeError):
        return False, (), "invalid_json"
    if not isinstance(value, dict) or set(value) != {"boundary_ids"}:
        return False, (), "invalid_schema"
    selected = value.get("boundary_ids")
    if not isinstance(selected, list):
        return False, (), "invalid_schema"
    if len(selected) > _MAX_SELECTED_BOUNDARIES:
        return False, (), "invalid_schema"
    if any(isinstance(item, bool) or not isinstance(item, int) for item in selected):
        return False, (), "non_integer_boundary"
    if len(selected) != len(set(selected)):
        return False, (), "duplicate_boundary"
    allowed = frozenset(candidate_boundary_ids)
    if any(item not in allowed for item in selected):
        return False, (), "unknown_boundary"
    selected_set = frozenset(selected)
    canonical = tuple(
        boundary for boundary in candidate_boundary_ids if boundary in selected_set
    )
    return True, canonical, "selected" if canonical else "model_abstained"


class LocalSemanticBoundarySelector:
    """Ask one OpenAI-compatible loopback endpoint to select safe boundaries.

    Proxies are explicitly disabled.  Runtime failures are represented as an
    abstention and never raised into the subtitle pipeline.  Configuration
    errors are rejected at construction so an invalid non-local URL cannot be
    used accidentally.
    """

    policy_version = SEMANTIC_BOUNDARY_POLICY_VERSION

    def __init__(
        self,
        *,
        endpoint: str,
        model: str,
        timeout_seconds: float = 8.0,
        max_response_bytes: int = 16_384,
    ) -> None:
        self.endpoint = _validated_endpoint(endpoint)
        if not isinstance(model, str) or not model.strip():
            raise ValueError("semantic boundary model 唔可以空白")
        self.model = model.strip()
        try:
            self.model.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise ValueError("semantic boundary model 無效") from exc
        if (
            isinstance(timeout_seconds, bool)
            or not isinstance(timeout_seconds, (int, float))
            or not 0.1 <= float(timeout_seconds) <= 120.0
        ):
            raise ValueError("semantic boundary timeout 必須係 0.1 至 120 秒")
        self.timeout_seconds = float(timeout_seconds)
        if (
            isinstance(max_response_bytes, bool)
            or not isinstance(max_response_bytes, int)
            or not 256 <= max_response_bytes <= 65_536
        ):
            raise ValueError("semantic boundary response cap 必須係 256 至 65536 bytes")
        self.max_response_bytes = max_response_bytes
        self._opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), _NoRedirectHandler()
        )

    def _abstain(
        self, reason: str, *, candidate_count: int
    ) -> SemanticBoundarySelectionResult:
        return SemanticBoundarySelectionResult(
            boundary_ids=(),
            audit=SemanticBoundaryAudit(
                status="abstained",
                model=self.model,
                candidate_count=candidate_count,
                selected_count=0,
                reason=reason,
            ),
        )

    def select(
        self,
        transcript: str,
        candidate_boundary_ids: Sequence[int],
        *,
        source_offset: int = 0,
        context_characters: int = 12,
    ) -> SemanticBoundarySelectionResult:
        """Return only a validated subset of caller-supplied source offsets."""

        candidate_count = (
            len(candidate_boundary_ids)
            if isinstance(candidate_boundary_ids, Sequence)
            else 0
        )
        if (
            not isinstance(transcript, str)
            or not transcript
            or len(transcript) > _MAX_TRANSCRIPT_CHARACTERS
            or isinstance(source_offset, bool)
            or not isinstance(source_offset, int)
            or source_offset < 0
            or isinstance(context_characters, bool)
            or not isinstance(context_characters, int)
            or not 4 <= context_characters <= 48
            or not isinstance(candidate_boundary_ids, Sequence)
            or isinstance(candidate_boundary_ids, (str, bytes, bytearray))
            or not 1 <= candidate_count <= _MAX_CANDIDATES
        ):
            return self._abstain("invalid_request", candidate_count=candidate_count)
        try:
            transcript.encode("utf-8")
        except UnicodeEncodeError:
            return self._abstain("invalid_request", candidate_count=candidate_count)

        candidates = tuple(candidate_boundary_ids)
        if (
            any(isinstance(value, bool) or not isinstance(value, int) for value in candidates)
            or len(set(candidates)) != len(candidates)
            or any(
                not source_offset < value < source_offset + len(transcript)
                for value in candidates
            )
        ):
            return self._abstain("invalid_candidates", candidate_count=candidate_count)

        contexts: list[dict[str, Any]] = []
        for boundary in candidates:
            local_boundary = boundary - source_offset
            contexts.append(
                {
                    "id": boundary,
                    "left": transcript[
                        max(0, local_boundary - context_characters) : local_boundary
                    ],
                    "right": transcript[
                        local_boundary : local_boundary + context_characters
                    ],
                }
            )

        user_payload = {
            "task": (
                "Select natural subtitle breakpoints from the allowed integer IDs. "
                "Never rewrite transcript text."
            ),
            "transcript": transcript,
            "allowed_boundary_ids": list(candidates),
            "boundary_contexts": contexts,
        }
        request_payload = {
            "model": self.model,
            "temperature": 0,
            "max_tokens": 256,
            "reasoning_effort": "none",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你係香港廣東話字幕斷句器。你只可以由 "
                        "allowed_boundary_ids 揀零個或多個整數斷點，"
                        "唔准新增、刪除、改寫、翻譯或重排 transcript。"
                        "只揀最自然嘅斷點，最多 24 個；唔肯定就回傳空 list。"
                        "只輸出一個 JSON object："
                        '{"boundary_ids":[整數]}。'
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        user_payload, ensure_ascii=False, separators=(",", ":")
                    ),
                },
            ],
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "subtitle_boundary_selection",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {
                            "boundary_ids": {
                                "type": "array",
                                "items": {"type": "integer", "enum": list(candidates)},
                                "uniqueItems": True,
                                "maxItems": min(
                                    _MAX_SELECTED_BOUNDARIES, len(candidates)
                                ),
                            }
                        },
                        "required": ["boundary_ids"],
                        "additionalProperties": False,
                    },
                },
            },
        }
        request = urllib.request.Request(
            self.endpoint,
            data=json.dumps(request_payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )

        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                status = getattr(response, "status", None)
                if status is None:
                    status = response.getcode()
                if status != 200:
                    return self._abstain(
                        "http_error", candidate_count=candidate_count
                    )
                raw = response.read(self.max_response_bytes + 1)
            if len(raw) > self.max_response_bytes:
                return self._abstain(
                    "response_too_large", candidate_count=candidate_count
                )
            payload = json.loads(raw.decode("utf-8"))
            content = payload["choices"][0]["message"]["content"]
            if not isinstance(content, str):
                return self._abstain(
                    "invalid_response", candidate_count=candidate_count
                )
            valid, selected, reason = _strict_boundary_ids(content, candidates)
            if not valid:
                return self._abstain(reason, candidate_count=candidate_count)
            status = "selected" if selected else "abstained"
            return SemanticBoundarySelectionResult(
                boundary_ids=selected,
                audit=SemanticBoundaryAudit(
                    status=status,
                    model=self.model,
                    candidate_count=candidate_count,
                    selected_count=len(selected),
                    reason=reason,
                ),
            )
        except (socket.timeout, TimeoutError):
            return self._abstain("timeout", candidate_count=candidate_count)
        except urllib.error.HTTPError:
            return self._abstain("http_error", candidate_count=candidate_count)
        except urllib.error.URLError as exc:
            reason = (
                "timeout"
                if isinstance(exc.reason, (socket.timeout, TimeoutError))
                else "unavailable"
            )
            return self._abstain(reason, candidate_count=candidate_count)
        except (
            OSError,
            KeyError,
            IndexError,
            TypeError,
            ValueError,
            UnicodeError,
            json.JSONDecodeError,
        ):
            return self._abstain("unavailable", candidate_count=candidate_count)
        except Exception:
            # This provider is optional.  A malformed local implementation must
            # never prevent deterministic subtitle segmentation from running.
            return self._abstain("internal_error", candidate_count=candidate_count)


__all__ = [
    "LocalSemanticBoundarySelector",
    "SEMANTIC_BOUNDARY_POLICY_VERSION",
    "SemanticBoundaryAudit",
    "SemanticBoundarySelectionResult",
]
