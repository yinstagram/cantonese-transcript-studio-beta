"""Gold-free planning for one experimental bracketed Qwen re-alignment trial."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from ..alignment.forced_timestamps import WordTimestamp
from .acoustic_witness import DualTokenAnchor, WitnessSegment


BRACKETED_REALIGN_POLICY_VERSION = "dual-witness-bracketed-qwen-realign-v1-trial"
MAX_WITNESS_DISAGREEMENT_MS = 250
WINDOW_LEFT_MARGIN_MS = 320
WINDOW_RIGHT_MARGIN_MS = 750
MAX_WINDOW_MS = 8_000
MAX_TOTAL_WINDOW_MS = 60_000


@dataclass(frozen=True)
class RepairSuspect:
    source_start: int
    source_end: int
    baseline_start_ms: int
    first_witness_start_ms: int
    second_witness_start_ms: int


@dataclass(frozen=True)
class RepairIslandPlan:
    segment_index: int
    projected_source_start: int
    projected_source_end: int
    interior_source_start: int
    interior_source_end: int
    left_guard_source_start: int
    left_guard_source_end: int
    right_guard_source_start: int
    right_guard_source_end: int
    left_guard_first_start_ms: int
    left_guard_second_start_ms: int
    left_guard_baseline_start_ms: int
    left_guard_baseline_end_ms: int
    right_guard_first_start_ms: int
    right_guard_second_start_ms: int
    right_guard_baseline_start_ms: int
    right_guard_baseline_end_ms: int
    window_start_ms: int
    window_end_ms: int
    suspects: tuple[RepairSuspect, ...]
    baseline_minimum_witness_disagreement_ms: int

    @property
    def window_duration_ms(self) -> int:
        return self.window_end_ms - self.window_start_ms


def _literal_occurrence_count(haystack: str, needle: str) -> int:
    if not needle:
        return 0
    count = 0
    offset = 0
    while True:
        found = haystack.find(needle, offset)
        if found < 0:
            return count
        count += 1
        offset = found + 1


def plan_bracketed_realign_islands(
    source_text: str,
    segments: Sequence[WitnessSegment],
    baseline_words: Sequence[WordTimestamp],
    dual_anchors: Sequence[DualTokenAnchor],
    *,
    maximum_total_window_ms: int = MAX_TOTAL_WINDOW_MS,
) -> tuple[RepairIslandPlan, ...]:
    """Create an immutable, gold-free, fail-closed repair plan.

    At most one island is selected per reconciled segment.  Witness timestamps
    only construct the audio brackets; they are never emitted as candidate word
    timestamps.
    """

    if not source_text:
        raise ValueError("source_text must not be empty")
    if not 0 < maximum_total_window_ms <= MAX_TOTAL_WINDOW_MS:
        raise ValueError("maximum_total_window_ms is invalid")
    baseline_by_span: dict[tuple[int, int, str], WordTimestamp] = {}
    for word in baseline_words:
        key = (word.source_start, word.source_end, word.text)
        if key in baseline_by_span:
            raise ValueError("baseline word source spans must be unique")
        if source_text[word.source_start : word.source_end] != word.text:
            raise ValueError("baseline word differs from immutable transcript")
        baseline_by_span[key] = word

    candidates: list[RepairIslandPlan] = []
    for segment in segments:
        segment_text = source_text[segment.source_start : segment.source_end]
        anchors = [
            anchor
            for anchor in dual_anchors
            if anchor.segment_index == segment.index
            and segment.source_start <= anchor.source_start
            and anchor.source_end <= segment.source_end
        ]
        anchored_baseline: list[tuple[DualTokenAnchor, WordTimestamp]] = []
        for anchor in anchors:
            key = (anchor.source_start, anchor.source_end, anchor.text)
            baseline = baseline_by_span.get(key)
            if baseline is not None:
                anchored_baseline.append((anchor, baseline))
        anchored_baseline.sort(key=lambda item: (item[0].source_start, item[0].source_end))

        stable = [
            item
            for item in anchored_baseline
            if abs(item[1].start_ms - item[0].first_start_ms)
            <= MAX_WITNESS_DISAGREEMENT_MS
            and abs(item[1].start_ms - item[0].second_start_ms)
            <= MAX_WITNESS_DISAGREEMENT_MS
        ]
        suspects = [
            item
            for item in anchored_baseline
            if abs(item[1].start_ms - item[0].first_start_ms)
            > MAX_WITNESS_DISAGREEMENT_MS
            and abs(item[1].start_ms - item[0].second_start_ms)
            > MAX_WITNESS_DISAGREEMENT_MS
        ]
        suspects.sort(
            key=lambda item: (
                -min(
                    abs(item[1].start_ms - item[0].first_start_ms),
                    abs(item[1].start_ms - item[0].second_start_ms),
                ),
                item[0].source_start,
            )
        )

        selected: RepairIslandPlan | None = None
        for suspect_anchor, suspect_baseline in suspects:
            left_options = [
                item for item in stable if item[0].source_end <= suspect_anchor.source_start
            ]
            right_options = [
                item for item in stable if item[0].source_start >= suspect_anchor.source_end
            ]
            if not left_options or not right_options:
                continue
            left_anchor, left_baseline = max(
                left_options, key=lambda item: item[0].source_end
            )
            right_anchor, right_baseline = min(
                right_options, key=lambda item: item[0].source_start
            )
            projected_start = left_anchor.source_start
            projected_end = right_anchor.source_end
            projected_text = source_text[projected_start:projected_end]
            if _literal_occurrence_count(segment_text, projected_text) != 1:
                continue
            interior_words = [
                word
                for word in baseline_words
                if left_anchor.source_end <= word.source_start
                and word.source_end <= right_anchor.source_start
            ]
            if not interior_words:
                continue
            interior_start = interior_words[0].source_start
            interior_end = interior_words[-1].source_end
            if not (
                interior_start <= suspect_baseline.source_start
                and suspect_baseline.source_end <= interior_end
            ):
                continue
            window_start = max(
                segment.start_ms,
                min(
                    left_anchor.first_start_ms,
                    left_anchor.second_start_ms,
                )
                - WINDOW_LEFT_MARGIN_MS,
            )
            window_end = min(
                segment.end_ms,
                max(
                    right_anchor.first_start_ms,
                    right_anchor.second_start_ms,
                )
                + WINDOW_RIGHT_MARGIN_MS,
            )
            if not 0 < window_end - window_start <= MAX_WINDOW_MS:
                continue
            island_suspects = tuple(
                RepairSuspect(
                    source_start=anchor.source_start,
                    source_end=anchor.source_end,
                    baseline_start_ms=baseline.start_ms,
                    first_witness_start_ms=anchor.first_start_ms,
                    second_witness_start_ms=anchor.second_start_ms,
                )
                for anchor, baseline in suspects
                if interior_start <= anchor.source_start
                and anchor.source_end <= interior_end
                and abs(baseline.start_ms - anchor.first_start_ms)
                > MAX_WITNESS_DISAGREEMENT_MS
                and abs(baseline.start_ms - anchor.second_start_ms)
                > MAX_WITNESS_DISAGREEMENT_MS
            )
            selected = RepairIslandPlan(
                segment_index=segment.index,
                projected_source_start=projected_start,
                projected_source_end=projected_end,
                interior_source_start=interior_start,
                interior_source_end=interior_end,
                left_guard_source_start=left_anchor.source_start,
                left_guard_source_end=left_anchor.source_end,
                right_guard_source_start=right_anchor.source_start,
                right_guard_source_end=right_anchor.source_end,
                left_guard_first_start_ms=left_anchor.first_start_ms,
                left_guard_second_start_ms=left_anchor.second_start_ms,
                left_guard_baseline_start_ms=left_baseline.start_ms,
                left_guard_baseline_end_ms=left_baseline.end_ms,
                right_guard_first_start_ms=right_anchor.first_start_ms,
                right_guard_second_start_ms=right_anchor.second_start_ms,
                right_guard_baseline_start_ms=right_baseline.start_ms,
                right_guard_baseline_end_ms=right_baseline.end_ms,
                window_start_ms=window_start,
                window_end_ms=window_end,
                suspects=island_suspects,
                baseline_minimum_witness_disagreement_ms=min(
                    abs(suspect_baseline.start_ms - suspect_anchor.first_start_ms),
                    abs(suspect_baseline.start_ms - suspect_anchor.second_start_ms),
                ),
            )
            break
        if selected is not None:
            candidates.append(selected)

    candidates.sort(
        key=lambda item: (
            -item.baseline_minimum_witness_disagreement_ms,
            item.projected_source_start,
        )
    )
    selected_candidates: list[RepairIslandPlan] = []
    total_duration = 0
    for candidate in candidates:
        if total_duration + candidate.window_duration_ms > maximum_total_window_ms:
            continue
        selected_candidates.append(candidate)
        total_duration += candidate.window_duration_ms
    return tuple(
        sorted(
            selected_candidates,
            key=lambda item: (item.segment_index, item.projected_source_start),
        )
    )


__all__ = [
    "BRACKETED_REALIGN_POLICY_VERSION",
    "MAX_TOTAL_WINDOW_MS",
    "MAX_WINDOW_MS",
    "MAX_WITNESS_DISAGREEMENT_MS",
    "RepairIslandPlan",
    "RepairSuspect",
    "WINDOW_LEFT_MARGIN_MS",
    "WINDOW_RIGHT_MARGIN_MS",
    "plan_bracketed_realign_islands",
]
