"""Protocol method dispatcher independent from stdin/stdout transport."""

from __future__ import annotations

from typing import Any, Callable


class MethodNotFound(ValueError):
    pass


class Dispatcher:
    def __init__(self) -> None:
        self._methods: dict[str, Callable[[dict[str, Any]], Any]] = {}

    def add(self, name: str, handler: Callable[[dict[str, Any]], Any]) -> None:
        self._methods[name] = handler

    def dispatch(self, name: str, params: dict[str, Any]) -> Any:
        try:
            handler = self._methods[name]
        except KeyError as exc:
            raise MethodNotFound(f"未知 method：{name}") from exc
        return handler(params)

    @property
    def methods(self) -> tuple[str, ...]:
        return tuple(sorted(self._methods))
