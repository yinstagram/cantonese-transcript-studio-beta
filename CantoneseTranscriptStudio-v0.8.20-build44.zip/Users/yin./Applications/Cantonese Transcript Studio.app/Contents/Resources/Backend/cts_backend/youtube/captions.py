"""Canonical VTT/SRT parsing while retaining immutable raw caption evidence."""

from __future__ import annotations

import hashlib
import html
import os
import re
import tempfile
import unicodedata
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable


MAX_CAPTION_BYTES = 32 * 1024 * 1024
_TIMING_RE = re.compile(
    r"^\s*(?P<start>(?:\d{1,6}:)?\d{1,2}:\d{2}[.,]\d{1,3})\s*-->\s*"
    r"(?P<end>(?:\d{1,6}:)?\d{1,2}:\d{2}[.,]\d{1,3})(?:\s+(?P<settings>.*))?$"
)
_TAG_RE = re.compile(r"<[^>\r\n]*>")
_BR_RE = re.compile(r"<br\s*/?>", re.IGNORECASE)
_ZERO_WIDTH_RE = re.compile(r"[\u200b\u200c\u200d\ufeff]")


class CaptionParseError(ValueError):
    pass


@dataclass(frozen=True)
class CaptionCue:
    start_ms: int
    end_ms: int
    text: str
    settings: str = ""

    def __post_init__(self) -> None:
        if self.start_ms < 0 or self.end_ms <= self.start_ms:
            raise ValueError("caption cue timestamps 無效")
        if not self.text.strip():
            raise ValueError("caption cue text 唔可以係空白")


@dataclass(frozen=True)
class CaptionNormalizationResult:
    raw_path: str
    normalized_path: str
    raw_sha256: str
    normalized_sha256: str
    raw_size_bytes: int
    normalized_size_bytes: int
    cue_count: int
    source_format: str
    output_format: str


def _timestamp_ms(value: str) -> int:
    normalized = value.replace(",", ".")
    clock, fraction = normalized.rsplit(".", 1)
    units = clock.split(":")
    if len(units) == 2:
        hours = 0
        minutes, seconds = (int(item) for item in units)
    elif len(units) == 3:
        hours, minutes, seconds = (int(item) for item in units)
    else:
        raise CaptionParseError("caption timestamp 無效")
    if minutes >= 60 or seconds >= 60:
        raise CaptionParseError("caption timestamp 超出範圍")
    milliseconds = int(fraction.ljust(3, "0"))
    return ((hours * 60 + minutes) * 60 + seconds) * 1_000 + milliseconds


def _clean_text(lines: list[str]) -> str:
    value = "\n".join(lines)
    value = _BR_RE.sub("\n", value)
    value = _TAG_RE.sub("", value)
    value = html.unescape(value)
    value = _ZERO_WIDTH_RE.sub("", value)
    value = unicodedata.normalize("NFC", value)
    cleaned = [" ".join(line.split()) for line in value.splitlines()]
    return "\n".join(line for line in cleaned if line).strip()


def _blocks(value: str) -> list[list[str]]:
    normalized = value.replace("\r\n", "\n").replace("\r", "\n").lstrip("\ufeff")
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in normalized.split("\n"):
        if line.strip():
            current.append(line)
        elif current:
            blocks.append(current)
            current = []
    if current:
        blocks.append(current)
    return blocks


def _parse_blocks(blocks: list[list[str]], *, webvtt: bool) -> tuple[CaptionCue, ...]:
    cues: list[CaptionCue] = []
    for block in blocks:
        if not block:
            continue
        first = block[0].strip()
        upper = first.upper()
        if webvtt and (upper == "WEBVTT" or upper.startswith("NOTE") or upper in {"STYLE", "REGION"}):
            continue
        timing_index = next((index for index, line in enumerate(block[:2]) if "-->" in line), None)
        if timing_index is None:
            continue
        match = _TIMING_RE.fullmatch(block[timing_index])
        if match is None:
            raise CaptionParseError("caption timing line 無效")
        start_ms = _timestamp_ms(match.group("start"))
        end_ms = _timestamp_ms(match.group("end"))
        text = _clean_text(block[timing_index + 1 :])
        if not text:
            continue
        try:
            cues.append(
                CaptionCue(
                    start_ms=start_ms,
                    end_ms=end_ms,
                    text=text,
                    settings=(match.group("settings") or "").strip(),
                )
            )
        except ValueError as exc:
            raise CaptionParseError(str(exc)) from exc
    return tuple(cues)


def parse_vtt(value: str) -> tuple[CaptionCue, ...]:
    if not isinstance(value, str):
        raise CaptionParseError("VTT 必須係文字")
    blocks = _blocks(value)
    if not blocks or not blocks[0] or not blocks[0][0].lstrip("\ufeff").startswith("WEBVTT"):
        raise CaptionParseError("缺少 WEBVTT header")
    return _parse_blocks(blocks, webvtt=True)


def parse_srt(value: str) -> tuple[CaptionCue, ...]:
    if not isinstance(value, str):
        raise CaptionParseError("SRT 必須係文字")
    return _parse_blocks(_blocks(value), webvtt=False)


def parse_caption(value: str, format_name: str) -> tuple[CaptionCue, ...]:
    selected = format_name.lower().lstrip(".")
    if selected == "vtt":
        return parse_vtt(value)
    if selected == "srt":
        return parse_srt(value)
    raise CaptionParseError("只支援 VTT／SRT")


def _flat_text(value: str) -> str:
    return " ".join(value.split())


def _rolling_merge(previous: str, current: str) -> str | None:
    before = _flat_text(previous)
    after = _flat_text(current)
    minimum = 3
    if before == after:
        return before
    if len(before) >= minimum and after.startswith(before):
        return after
    if len(after) >= minimum and before.startswith(after):
        return before
    maximum = min(len(before), len(after))
    for overlap in range(maximum, minimum - 1, -1):
        if before[-overlap:] != after[:overlap]:
            continue
        if overlap / min(len(before), len(after)) < 0.4:
            continue
        suffix = after[overlap:]
        return (before + suffix).strip()
    return None


def normalize_rolling_captions(
    cues: tuple[CaptionCue, ...] | list[CaptionCue],
    *,
    maximum_chain_ms: int = 12_000,
    maximum_characters: int = 240,
) -> tuple[CaptionCue, ...]:
    """De-duplicate overlapping rolling captions without inventing any text."""

    if maximum_chain_ms <= 0 or maximum_characters <= 0:
        raise ValueError("rolling caption limits 必須係正數")
    ordered = sorted(enumerate(cues), key=lambda item: (item[1].start_ms, item[0]))
    result: list[CaptionCue] = []
    for _, cue in ordered:
        text = _clean_text(cue.text.splitlines())
        if not text:
            continue
        current = replace(cue, text=text)
        if not result:
            result.append(current)
            continue
        previous = result[-1]
        touching = current.start_ms <= previous.end_ms + 250
        merged_text = _rolling_merge(previous.text, current.text) if touching else None
        merged_end = max(previous.end_ms, current.end_ms)
        if (
            merged_text is not None
            and merged_end - previous.start_ms <= maximum_chain_ms
            and len(merged_text) <= maximum_characters
        ):
            result[-1] = CaptionCue(
                start_ms=previous.start_ms,
                end_ms=merged_end,
                text=merged_text,
                settings=previous.settings,
            )
        else:
            result.append(current)
    return tuple(result)


def _format_timestamp(milliseconds: int, decimal: str) -> str:
    hours, remainder = divmod(max(0, milliseconds), 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}{decimal}{millis:03d}"


def serialize_vtt(cues: tuple[CaptionCue, ...] | list[CaptionCue]) -> str:
    blocks = ["WEBVTT"]
    for cue in cues:
        blocks.append(
            f"{_format_timestamp(cue.start_ms, '.')} --> {_format_timestamp(cue.end_ms, '.')}\n"
            f"{cue.text}"
        )
    return "\n\n".join(blocks) + "\n"


def serialize_srt(cues: tuple[CaptionCue, ...] | list[CaptionCue]) -> str:
    blocks: list[str] = []
    for index, cue in enumerate(cues, start=1):
        blocks.append(
            f"{index}\n"
            f"{_format_timestamp(cue.start_ms, ',')} --> {_format_timestamp(cue.end_ms, ',')}\n"
            f"{cue.text}"
        )
    return "\n\n".join(blocks) + ("\n" if blocks else "")


def _atomic_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _sha256(value: bytes) -> str:
    return f"sha256:{hashlib.sha256(value).hexdigest()}"


def _safe_read(path: Path) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise FileNotFoundError("caption source 唔存在或者唔安全")
    if path.stat().st_size > MAX_CAPTION_BYTES:
        raise ValueError("caption source 超出大小限制")
    return path.read_bytes()


def preserve_and_normalize_caption(
    source: str | Path,
    raw_destination: str | Path,
    normalized_destination: str | Path,
    *,
    source_format: str | None = None,
    output_format: str | None = None,
    text_normalizer: Callable[[str], str] | None = None,
) -> CaptionNormalizationResult:
    """Publish byte-exact raw evidence and a separate canonical caption file."""

    source_input = Path(source).expanduser()
    if source_input.is_symlink():
        raise ValueError("caption source 唔可以係 symlink")
    source_path = source_input.resolve(strict=True)
    raw_path = Path(raw_destination).expanduser().resolve(strict=False)
    normalized_path = Path(normalized_destination).expanduser().resolve(strict=False)
    if raw_path == normalized_path:
        raise ValueError("raw 同 normalized caption 必須係兩個檔案")
    if normalized_path == source_path:
        raise ValueError("normalized caption 唔可以覆蓋 source")
    if raw_path.is_symlink() or normalized_path.is_symlink():
        raise ValueError("caption destination 唔可以係 symlink")

    source_bytes = _safe_read(source_path)
    if raw_path == source_path:
        raw_bytes = source_bytes
    elif raw_path.exists():
        raw_bytes = _safe_read(raw_path)
        if raw_bytes != source_bytes:
            raise FileExistsError("raw caption evidence 已存在而且內容唔同")
    else:
        _atomic_bytes(raw_path, source_bytes)
        raw_bytes = source_bytes

    selected_source = (source_format or source_path.suffix).lower().lstrip(".")
    selected_output = (output_format or normalized_path.suffix).lower().lstrip(".")
    try:
        decoded = raw_bytes.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise CaptionParseError("caption 唔係有效 UTF-8") from exc
    cues = normalize_rolling_captions(parse_caption(decoded, selected_source))
    if text_normalizer is None:
        from ..normalization.hong_kong import normalize_text

        text_normalizer = normalize_text
    normalized_cues: list[CaptionCue] = []
    for cue in cues:
        normalized_text = text_normalizer(cue.text)
        if not isinstance(normalized_text, str) or not normalized_text.strip():
            raise ValueError("caption text normalizer 回傳無效結果")
        normalized_cues.append(replace(cue, text=normalized_text.strip()))
    cues = tuple(normalized_cues)
    if selected_output == "vtt":
        rendered = serialize_vtt(cues)
    elif selected_output == "srt":
        rendered = serialize_srt(cues)
    else:
        raise CaptionParseError("normalized caption 只支援 VTT／SRT")
    normalized_bytes = rendered.encode("utf-8")
    _atomic_bytes(normalized_path, normalized_bytes)

    if _safe_read(raw_path) != raw_bytes:
        raise RuntimeError("raw caption evidence 喺 normalization 期間被修改")
    return CaptionNormalizationResult(
        raw_path=str(raw_path),
        normalized_path=str(normalized_path),
        raw_sha256=_sha256(raw_bytes),
        normalized_sha256=_sha256(normalized_bytes),
        raw_size_bytes=len(raw_bytes),
        normalized_size_bytes=len(normalized_bytes),
        cue_count=len(cues),
        source_format=selected_source,
        output_format=selected_output,
    )
