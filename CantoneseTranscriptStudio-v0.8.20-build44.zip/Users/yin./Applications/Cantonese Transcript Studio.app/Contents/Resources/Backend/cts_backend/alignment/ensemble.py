"""Conservative three-ASR hypothesis combination for Accuracy Mode.

This is late ASR system combination, not a jointly trained neural MoE.  Qwen
remains the timestamp-bearing primary ASR, while Whisper Large v3 is the
Accuracy Mode text fallback. Secondary engines can contribute only bounded,
ASR-grounded candidates; deterministic agreement is applied first, and an
optional local text arbiter may select an exact candidate ID or abstain.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import asdict, replace
from difflib import SequenceMatcher
from typing import Any, Iterable, Mapping, Sequence

from rapidfuzz import fuzz
from rapidfuzz.distance import Levenshtein

from .arbiter import ArbitrationResult, Candidate
from .reconcile import reconcile_text
from ..schemas import AlignmentAudit, Correction, ReconciledSegment, TranscriptSegment


ENSEMBLE_POLICY_VERSION = "2026-08-29.1"
_ASCII_PHRASE = re.compile(
    r"(?<![A-Za-z0-9])[A-Za-z][A-Za-z0-9]*(?:[ _-]+[A-Za-z][A-Za-z0-9]*)*(?![A-Za-z0-9])"
)
_ASCII_KEY = re.compile(r"[^a-z0-9]+")
_MIXED_UNIT = re.compile(r"[A-Za-z][A-Za-z0-9]*(?:[-'’][A-Za-z0-9]+)*|[\u3400-\u9fff]|[0-9]+")
_SHORT_MIXED_GLOSSARY_SPAN = re.compile(r"[A-Za-z0-9\u3400-\u9fff _'’\-]{1,24}")


def comparison_key(text: str) -> str:
    output: list[str] = []
    for character in unicodedata.normalize("NFKC", text).casefold():
        category = unicodedata.category(character)
        if character.isspace() or category.startswith(("P", "S", "Z", "C")):
            continue
        output.append(character)
    return "".join(output)


def mixed_units(text: str) -> tuple[str, ...]:
    """Use Han characters and Latin/alphanumeric words as comparable units."""
    return tuple(match.group(0).casefold() for match in _MIXED_UNIT.finditer(text))


def _join_fragments(fragments: Sequence[str]) -> str:
    output = ""
    for fragment in fragments:
        fragment = fragment.strip()
        if not fragment:
            continue
        if (
            output
            and output[-1].isascii()
            and output[-1].isalnum()
            and fragment[0].isascii()
            and fragment[0].isalnum()
        ):
            output += " "
        output += fragment
    return output


def _ascii_key(text: str) -> str:
    return _ASCII_KEY.sub("", unicodedata.normalize("NFKC", text).casefold())


def _ascii_terms(vocabulary: Iterable[str]) -> tuple[str, ...]:
    terms: list[str] = []
    for term in vocabulary:
        term = " ".join(str(term).split())
        if term and term.isascii() and any(character.isalpha() for character in term):
            if term not in terms:
                terms.append(term)
    return tuple(sorted(terms, key=lambda value: (-len(value), value.casefold())))


def _glossary_candidate(
    primary_text: str,
    secondary_text: str,
    vocabulary: Iterable[str],
) -> tuple[str, tuple[Correction, ...]]:
    """Create, but do not automatically accept, exact glossary candidates.

    A term must occur exactly in a secondary hypothesis.  The primary span must
    be a similar Latin phrase (or share the same leading word and word count),
    so glossary text cannot be inserted into unrelated speech.
    """
    secondary_spans = [(match.start(), match.end(), match.group(0)) for match in _ASCII_PHRASE.finditer(secondary_text)]
    replacements: list[tuple[int, int, str, Correction]] = []
    occupied: list[tuple[int, int]] = []
    for term in _ascii_terms(vocabulary):
        term_key = _ascii_key(term)
        if not term_key or not any(_ascii_key(span) == term_key for _, _, span in secondary_spans):
            continue
        primary_spans = [
            (match.start(), match.end(), match.group(0))
            for match in _ASCII_PHRASE.finditer(primary_text)
            if _ascii_key(match.group(0)) != term_key
        ]
        if any(_ascii_key(match.group(0)) == term_key for match in _ASCII_PHRASE.finditer(primary_text)):
            continue
        term_words = re.findall(r"[A-Za-z][A-Za-z0-9]*", term)
        best: tuple[float, int, int, str] | None = None
        for start, end, span in primary_spans:
            if any(start < used_end and used_start < end for used_start, used_end in occupied):
                continue
            span_words = re.findall(r"[A-Za-z][A-Za-z0-9]*", span)
            score = fuzz.ratio(_ascii_key(span), term_key) / 100.0
            same_shape = len(span_words) == len(term_words)
            same_lead = bool(
                span_words
                and term_words
                and span_words[0].casefold() == term_words[0].casefold()
            )
            allowed = score >= 0.72 or (same_shape and same_lead and score >= 0.45)
            if not allowed:
                continue
            candidate = (score, start, end, span)
            if best is None or candidate > best:
                best = candidate
        if best is None:
            continue
        _, start, end, before = best
        occupied.append((start, end))
        correction = Correction(
            primary_start=start,
            primary_end=end,
            before=before,
            after=term,
            reason="vocabulary_candidate",
        )
        replacements.append((start, end, term, correction))

    text = primary_text
    for start, end, replacement, _ in sorted(replacements, reverse=True):
        text = text[:start] + replacement + text[end:]
    corrections = tuple(item[3] for item in sorted(replacements, key=lambda value: value[0]))
    return text, corrections


def _nearest_han_anchor(
    text: str,
    offset: int,
    *,
    before: bool,
) -> tuple[int, int, str] | None:
    """Find a directly adjacent two-Han anchor around a glossary term."""

    if before:
        lower = max(0, offset - 16)
        indices = range(offset - 2, lower - 1, -1)
    else:
        upper = min(len(text) - 1, offset + 16)
        indices = range(offset, upper)
    for index in indices:
        candidate = text[index : index + 2]
        if len(candidate) != 2 or not all("\u3400" <= char <= "\u9fff" for char in candidate):
            continue
        separator = text[index + 2 : offset] if before else text[offset:index]
        if comparison_key(separator):
            continue
        return index, index + 2, candidate
    return None


def _unique_short_gap(
    text: str,
    left_anchor: str,
    right_anchor: str,
) -> tuple[int, int, str] | None:
    """Return one unambiguous short mixed-script span between exact anchors."""

    matches: list[tuple[int, int, str]] = []
    left_start = 0
    while True:
        left_index = text.find(left_anchor, left_start)
        if left_index < 0:
            break
        gap_start = left_index + len(left_anchor)
        right_start = gap_start
        while True:
            right_index = text.find(right_anchor, right_start)
            if right_index < 0 or right_index - gap_start > 24:
                break
            gap = text[gap_start:right_index]
            if gap and _SHORT_MIXED_GLOSSARY_SPAN.fullmatch(gap):
                matches.append((gap_start, right_index, gap))
            right_start = right_index + 1
        left_start = left_index + 1
    return matches[0] if len(matches) == 1 else None


def _three_model_glossary_anchor_candidate(
    primary_text: str,
    exact_secondary_text: str,
    corroborating_secondary_text: str,
    vocabulary: Iterable[str],
) -> tuple[str, tuple[Correction, ...]]:
    """Offer a closed-world vocabulary candidate backed by all three ASRs.

    One secondary must emit the exact user-supplied ASCII term.  The same
    unique two-Han anchors must bracket short Latin-bearing spans in Qwen and
    the other secondary, and those two phonetic spans must be similar but not
    identical.  The function only creates an immutable candidate for the local
    arbiter; it never auto-selects it.  This is a bounded text candidate, not
    proof of acoustic consensus or phonetic compatibility with the glossary
    term.  Multiple possible glossary edits fail closed instead of being
    bundled into one all-or-nothing candidate.
    """

    replacements: list[tuple[int, int, str, Correction]] = []
    occupied: list[tuple[int, int]] = []
    exact_spans = [
        (match.start(), match.end(), match.group(0))
        for match in _ASCII_PHRASE.finditer(exact_secondary_text)
    ]
    for term in _ascii_terms(vocabulary):
        term_key = _ascii_key(term)
        term_spans = [span for span in exact_spans if _ascii_key(span[2]) == term_key]
        if len(term_spans) != 1:
            continue
        term_start, term_end, _ = term_spans[0]
        left = _nearest_han_anchor(exact_secondary_text, term_start, before=True)
        right = _nearest_han_anchor(exact_secondary_text, term_end, before=False)
        if left is None or right is None:
            continue
        primary_gap = _unique_short_gap(primary_text, left[2], right[2])
        corroborating_gap = _unique_short_gap(
            corroborating_secondary_text,
            left[2],
            right[2],
        )
        if primary_gap is None or corroborating_gap is None:
            continue
        start, end, before_text = primary_gap
        other_text = corroborating_gap[2]
        if any(start < used_end and used_start < end for used_start, used_end in occupied):
            continue
        if _ascii_key(before_text) == term_key:
            continue
        primary_ascii = _ascii_key(before_text)
        other_ascii = _ascii_key(other_text)
        if len(primary_ascii) < 2 or len(other_ascii) < 2:
            continue
        # Two ASRs agreeing on the existing primary spelling is stronger than
        # one prompt-conditioned exact glossary hit, so fail closed.
        if comparison_key(before_text) == comparison_key(other_text):
            continue
        if fuzz.ratio(primary_ascii, other_ascii) / 100.0 < 0.60:
            continue
        correction = Correction(
            primary_start=start,
            primary_end=end,
            before=before_text,
            after=term,
            reason="bounded_vocabulary_anchor_candidate",
        )
        occupied.append((start, end))
        replacements.append((start, end, term, correction))

    if len(replacements) != 1:
        return primary_text, ()
    text = primary_text
    for start, end, replacement, _ in sorted(replacements, reverse=True):
        text = text[:start] + replacement + text[end:]
    corrections = tuple(item[3] for item in sorted(replacements, key=lambda value: value[0]))
    return text, corrections


def _pair_candidate(
    primary_text: str,
    secondary_text: str,
    *,
    vocabulary: Iterable[str],
) -> tuple[str, AlignmentAudit]:
    candidate, audit = reconcile_text(primary_text, secondary_text, vocabulary=vocabulary)
    glossary_text, glossary_corrections = _glossary_candidate(candidate, secondary_text, vocabulary)
    if not glossary_corrections:
        return candidate, audit
    reasons = tuple(dict.fromkeys((*audit.reasons, "vocabulary_candidate")))
    return glossary_text, replace(
        audit,
        reasons=reasons,
        corrections=(*audit.corrections, *glossary_corrections),
        conflict_candidate=True,
    )


def _apply_corrections(
    primary_text: str,
    corrections: Sequence[Correction],
) -> str:
    text = primary_text
    for correction in sorted(
        corrections,
        key=lambda item: (item.primary_start, item.primary_end),
        reverse=True,
    ):
        start = correction.primary_start
        end = correction.primary_end
        if primary_text[start:end] != correction.before:
            # Fail closed if a future candidate producer reports offsets in a
            # coordinate system other than the immutable primary transcript.
            return primary_text
        text = text[:start] + correction.after + text[end:]
    return text


def _unit_projection(text: str) -> tuple[tuple[str, ...], tuple[tuple[int, int], ...]]:
    matches = tuple(_MIXED_UNIT.finditer(text))
    return (
        tuple(unicodedata.normalize("NFKC", match.group(0)).casefold() for match in matches),
        tuple((match.start(), match.end()) for match in matches),
    )


def _raw_unit_slice(
    text: str,
    spans: Sequence[tuple[int, int]],
    start: int,
    end: int,
) -> tuple[int, int, str]:
    if start == end:
        if start < len(spans):
            offset = spans[start][0]
        elif spans:
            # Keep terminal punctuation on the primary skeleton.
            offset = spans[-1][1]
        else:
            offset = 0
        return offset, offset, ""
    raw_start = spans[start][0]
    raw_end = spans[end - 1][1]
    return raw_start, raw_end, text[raw_start:raw_end]


def _bounded_secondary_edits(
    primary_text: str,
    secondary_text: str,
    *,
    anchor_units: int = 2,
    maximum_primary_units: int = 4,
    maximum_secondary_units: int = 8,
) -> dict[tuple[int, int, tuple[str, ...]], Correction]:
    """Return locally anchored edits without deciding whether to apply them.

    The edit key is expressed in immutable primary-unit coordinates plus the
    normalized replacement units.  This lets two independent secondary ASRs
    vote for the same local insertion/replacement/deletion even when their
    punctuation differs.  A single model can never apply one of these edits.
    """

    primary_units, primary_spans = _unit_projection(primary_text)
    secondary_units, secondary_spans = _unit_projection(secondary_text)
    if not primary_units or not secondary_units:
        return {}
    opcodes = SequenceMatcher(
        a=primary_units,
        b=secondary_units,
        autojunk=False,
    ).get_opcodes()
    output: dict[tuple[int, int, tuple[str, ...]], Correction] = {}
    for index, (tag, i1, i2, j1, j2) in enumerate(opcodes):
        if tag == "equal":
            continue
        primary_length = i2 - i1
        secondary_length = j2 - j1
        if primary_length > maximum_primary_units or secondary_length > maximum_secondary_units:
            continue
        if primary_length == 0 and secondary_length == 0:
            continue
        left_anchor = 0
        right_anchor = 0
        if index > 0 and opcodes[index - 1][0] == "equal":
            left_anchor = opcodes[index - 1][2] - opcodes[index - 1][1]
        if index + 1 < len(opcodes) and opcodes[index + 1][0] == "equal":
            right_anchor = opcodes[index + 1][2] - opcodes[index + 1][1]
        internal = left_anchor >= anchor_units and right_anchor >= anchor_units
        edge = (
            (i1 == 0 and right_anchor >= anchor_units * 2)
            or (i2 == len(primary_units) and left_anchor >= anchor_units * 2)
        )
        if not (internal or edge):
            continue
        raw_start, raw_end, before = _raw_unit_slice(
            primary_text,
            primary_spans,
            i1,
            i2,
        )
        _, _, after = _raw_unit_slice(
            secondary_text,
            secondary_spans,
            j1,
            j2,
        )
        replacement_key = tuple(secondary_units[j1:j2])
        output[(i1, i2, replacement_key)] = Correction(
            primary_start=raw_start,
            primary_end=raw_end,
            before=before,
            after=after,
            reason=f"secondary_{tag}_candidate",
        )
    return output


def _secondary_deletes_primary_content(primary_text: str, secondary_text: str) -> bool:
    primary_units, _ = _unit_projection(primary_text)
    secondary_units, _ = _unit_projection(secondary_text)
    if not primary_units:
        return False
    if not secondary_units:
        return True
    for tag, i1, i2, j1, j2 in SequenceMatcher(
        a=primary_units,
        b=secondary_units,
        autojunk=False,
    ).get_opcodes():
        if tag == "delete" or (tag == "replace" and (i2 - i1) > (j2 - j1)):
            return True
    return False


def _two_secondary_consensus_fusion(
    primary_text: str,
    verifier_text: str,
    whisper_text: str,
    *,
    maximum_corrections: int = 4,
) -> tuple[str, tuple[Correction, ...], tuple[dict[str, Any], ...]]:
    """Apply only identical, locally anchored edits emitted by both secondaries.

    This is the phrase-level system-combination path: Qwen supplies the timing
    skeleton, while Whisper and Wenet may jointly restore a missing phrase or
    correct a bounded span.  Disjoint, overlapping, excessive or single-source
    edits fail closed and leave the Qwen wording untouched.
    """

    verifier_edits = _bounded_secondary_edits(primary_text, verifier_text)
    whisper_edits = _bounded_secondary_edits(primary_text, whisper_text)
    shared_keys = sorted(
        set(verifier_edits).intersection(whisper_edits),
        key=lambda item: (item[0], item[1], item[2]),
    )
    if not shared_keys or len(shared_keys) > maximum_corrections:
        return primary_text, (), ()

    corrections: list[Correction] = []
    evidence: list[dict[str, Any]] = []
    previous_end = -1
    previous_was_insertion = False
    for key in shared_keys:
        verifier = verifier_edits[key]
        whisper = whisper_edits[key]
        # Never auto-delete content.  In particular, fillers, profanity and
        # Cantonese particles must survive unless a user explicitly requests
        # a clean-transcript mode.
        if not key[2]:
            continue
        starts_before_previous_end = verifier.primary_start < previous_end
        duplicate_insertion_position = (
            previous_was_insertion
            and verifier.primary_start == previous_end
            and verifier.primary_start == verifier.primary_end
        )
        if starts_before_previous_end or duplicate_insertion_position:
            return primary_text, (), ()
        reason = (
            "two_secondary_consensus_insertion"
            if verifier.primary_start == verifier.primary_end
            else "two_secondary_consensus_replacement"
        )
        # Prefer Whisper's surface form for spacing/case, but only after Wenet
        # independently emitted the exact same normalized replacement units.
        correction = Correction(
            primary_start=verifier.primary_start,
            primary_end=verifier.primary_end,
            before=verifier.before,
            after=whisper.after,
            reason=reason,
        )
        corrections.append(correction)
        evidence.append(
            {
                "primary_unit_range": [key[0], key[1]],
                "before": verifier.before,
                "after": whisper.after,
                "normalized_after_units": list(key[2]),
                "supported_by": ["verifier", "whisper"],
                "verifier_surface": verifier.after,
                "whisper_surface": whisper.after,
                "reason": reason,
            }
        )
        previous_end = verifier.primary_end
        previous_was_insertion = verifier.primary_start == verifier.primary_end

    if not corrections:
        return primary_text, (), ()
    candidate = _apply_corrections(primary_text, corrections)
    if candidate == primary_text:
        return primary_text, (), ()
    return candidate, tuple(corrections), tuple(evidence)


def _primary_context_supported_by_other_model(
    primary_text: str,
    correction: Correction,
    other_text: str,
    *,
    anchor_characters: int = 2,
) -> bool:
    """Return true only for a local two-model vote to keep primary wording.

    The other ASR must contain the primary token with the same nearby context,
    and must not contain the proposed replacement in that same context.  This
    prevents a single verifier from changing a correct Cantonese word such as
    ``搵附近`` to ``穩附近`` when Qwen and Whisper independently agree.
    """

    before = comparison_key(correction.before)
    after = comparison_key(correction.after)
    if not before or before == after or not other_text:
        return False
    left = comparison_key(primary_text[: correction.primary_start])[-anchor_characters:]
    right = comparison_key(primary_text[correction.primary_end :])[:anchor_characters]
    if len(left) + len(right) < anchor_characters * 2:
        return False
    other = comparison_key(other_text)
    primary_context = f"{left}{before}{right}"
    replacement_context = f"{left}{after}{right}"
    return primary_context in other and replacement_context not in other


def _veto_single_source_corrections(
    primary_text: str,
    candidate_text: str,
    audit: AlignmentAudit,
    other_text: str,
) -> tuple[str, AlignmentAudit, tuple[Correction, ...]]:
    vetoed = tuple(
        correction
        for correction in audit.corrections
        if _primary_context_supported_by_other_model(
            primary_text,
            correction,
            other_text,
        )
    )
    if not vetoed:
        return candidate_text, audit, ()
    vetoed_ids = {id(item) for item in vetoed}
    kept = tuple(item for item in audit.corrections if id(item) not in vetoed_ids)
    candidate = _apply_corrections(primary_text, kept)
    kept_reasons = {item.reason for item in kept}
    correction_reasons = {item.reason for item in audit.corrections}
    reasons = tuple(
        dict.fromkeys(
            [
                *(
                    reason
                    for reason in audit.reasons
                    if reason not in correction_reasons or reason in kept_reasons
                ),
                "cross_model_primary_support_veto",
            ]
        )
    )
    return candidate, replace(audit, corrections=kept, reasons=reasons), vetoed


def _corrections_from_choice(primary: str, chosen: str, reason: str) -> tuple[Correction, ...]:
    matcher = SequenceMatcher(a=primary, b=chosen, autojunk=False)
    output: list[Correction] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        output.append(
            Correction(
                primary_start=i1,
                primary_end=i2,
                before=primary[i1:i2],
                after=chosen[j1:j2],
                reason=reason,
            )
        )
    return tuple(output)


def _pair_metrics(primary: str, secondary: str) -> dict[str, Any]:
    left = mixed_units(primary)
    right = mixed_units(secondary)
    distance = int(Levenshtein.distance(left, right))
    denominator = max(len(left), len(right), 1)
    return {
        "mixed_unit_similarity": round(fuzz.ratio(left, right) / 100.0, 6),
        "mixed_unit_edit_distance": distance,
        "mixed_unit_disagreement_ratio": round(distance / denominator, 6),
        "primary_units": len(left),
        "secondary_units": len(right),
    }


def reconcile_three_texts(
    primary_text: str,
    verifier_text: str,
    whisper_text: str,
    *,
    vocabulary: Iterable[str] = (),
    arbiter: Any | None = None,
) -> tuple[str, AlignmentAudit, dict[str, Any]]:
    """Reconcile Accuracy Mode as phrase-level evidence fusion.

    Qwen is the immutable timestamp/text backbone. Whisper and Wenet may
    jointly correct bounded local spans; neither raw secondary transcript is a
    whole-segment fallback. Gemma is an optional local selector for immutable,
    ASR-grounded candidates only and can never write transcript text.
    """
    vocabulary_tuple = tuple(vocabulary)
    verifier_candidate, verifier_audit = _pair_candidate(
        primary_text, verifier_text, vocabulary=vocabulary_tuple
    )
    whisper_candidate, whisper_audit = _pair_candidate(
        primary_text, whisper_text, vocabulary=vocabulary_tuple
    )
    verifier_candidate, verifier_audit, verifier_vetoed = _veto_single_source_corrections(
        primary_text,
        verifier_candidate,
        verifier_audit,
        whisper_text,
    )
    whisper_candidate, whisper_audit, whisper_vetoed = _veto_single_source_corrections(
        primary_text,
        whisper_candidate,
        whisper_audit,
        verifier_text,
    )
    verifier_anchor_candidate, verifier_anchor_corrections = (
        _three_model_glossary_anchor_candidate(
            primary_text,
            verifier_text,
            whisper_text,
            vocabulary_tuple,
        )
    )
    whisper_anchor_candidate, whisper_anchor_corrections = (
        _three_model_glossary_anchor_candidate(
            primary_text,
            whisper_text,
            verifier_text,
            vocabulary_tuple,
        )
    )
    consensus_fusion_candidate, consensus_fusion_corrections, consensus_fusion_evidence = (
        _two_secondary_consensus_fusion(
            primary_text,
            verifier_text,
            whisper_text,
        )
    )
    verifier_local_edits = _bounded_secondary_edits(primary_text, verifier_text)
    whisper_local_edits = _bounded_secondary_edits(primary_text, whisper_text)
    shared_local_edit_keys = set(verifier_local_edits).intersection(whisper_local_edits)
    verifier_only_edits = [
        asdict(verifier_local_edits[key])
        for key in sorted(
            set(verifier_local_edits).difference(shared_local_edit_keys),
            key=lambda item: (item[0], item[1], item[2]),
        )
    ]
    whisper_only_edits = [
        asdict(whisper_local_edits[key])
        for key in sorted(
            set(whisper_local_edits).difference(shared_local_edit_keys),
            key=lambda item: (item[0], item[1], item[2]),
        )
    ]
    primary_key = comparison_key(primary_text)
    verifier_key = comparison_key(verifier_text)
    whisper_key = comparison_key(whisper_text)
    all_raw_agree = bool(primary_key and primary_key == verifier_key == whisper_key)
    qwen_whisper_agree = bool(primary_key and primary_key == whisper_key)
    qwen_verifier_agree = bool(primary_key and primary_key == verifier_key)
    whisper_verifier_agree = bool(whisper_key and whisper_key == verifier_key)
    two_secondary_full_agreement_safe = bool(
        whisper_verifier_agree
        and not _secondary_deletes_primary_content(primary_text, whisper_text)
    )

    records: list[dict[str, Any]] = [
        {
            "id": "c0",
            "text": primary_text,
            "supported_by": ["qwen"],
            "kind": "qwen_timing_backbone",
            "evidence": [
                {
                    "source": "qwen",
                    "kind": "raw_asr",
                    "text": primary_text,
                }
            ],
        }
    ]
    if qwen_whisper_agree:
        records[0]["supported_by"].append("whisper")
    if qwen_verifier_agree:
        records[0]["supported_by"].append("verifier")

    def add_candidate(
        text: str,
        sources: tuple[str, ...],
        *,
        kind: str,
        evidence: tuple[dict[str, Any], ...],
    ) -> None:
        key = comparison_key(text)
        if not key:
            return
        for record in records:
            if comparison_key(str(record["text"])) == key:
                # Equal text is not automatically a second acoustic vote.  A
                # Qwen-indexed candidate can happen to stay unchanged after a
                # Whisper comparison; that only means no safe edit was found,
                # not that Whisper emitted the same wording.
                if record.get("kind") == kind:
                    for source in sources:
                        if source not in record["supported_by"]:
                            record["supported_by"].append(source)
                return
        if len(records) >= 4:
            return
        records.append(
            {
                "id": f"c{len(records)}",
                "text": text,
                "supported_by": list(sources),
                "kind": kind,
                "evidence": list(evidence),
            }
        )

    if two_secondary_full_agreement_safe and not qwen_whisper_agree:
        add_candidate(
            whisper_text,
            ("verifier", "whisper"),
            kind="two_secondary_full_agreement",
            evidence=(
                {"source": "verifier", "kind": "raw_asr", "text": verifier_text},
                {"source": "whisper", "kind": "raw_asr", "text": whisper_text},
            ),
        )
    if consensus_fusion_corrections:
        add_candidate(
            consensus_fusion_candidate,
            ("qwen", "verifier", "whisper"),
            kind="deterministic_phrase_consensus_fusion",
            evidence=(
                {"source": "qwen", "kind": "timing_backbone", "text": primary_text},
                {"source": "verifier", "kind": "raw_asr", "text": verifier_text},
                {"source": "whisper", "kind": "raw_asr", "text": whisper_text},
                {
                    "source": "deterministic_alignment",
                    "kind": "two_secondary_phrase_consensus",
                    "corrections": [asdict(item) for item in consensus_fusion_corrections],
                    "evidence": list(consensus_fusion_evidence),
                },
            ),
        )
    if verifier_anchor_corrections:
        add_candidate(
            verifier_anchor_candidate,
            ("qwen", "verifier", "whisper"),
            kind="bounded_three_asr_vocabulary_anchor",
            evidence=(
                {"source": "qwen", "kind": "raw_asr", "text": primary_text},
                {"source": "verifier", "kind": "raw_asr", "text": verifier_text},
                {"source": "whisper", "kind": "raw_asr", "text": whisper_text},
                {
                    "source": "deterministic_alignment",
                    "kind": "vocabulary_anchor",
                    "corrections": [asdict(item) for item in verifier_anchor_corrections],
                },
            ),
        )
    if whisper_anchor_corrections:
        add_candidate(
            whisper_anchor_candidate,
            ("qwen", "verifier", "whisper"),
            kind="bounded_three_asr_vocabulary_anchor",
            evidence=(
                {"source": "qwen", "kind": "raw_asr", "text": primary_text},
                {"source": "verifier", "kind": "raw_asr", "text": verifier_text},
                {"source": "whisper", "kind": "raw_asr", "text": whisper_text},
                {
                    "source": "deterministic_alignment",
                    "kind": "vocabulary_anchor",
                    "corrections": [asdict(item) for item in whisper_anchor_corrections],
                },
            ),
        )

    choice = "c0"
    method = "qwen_backbone_no_consensus"
    arbiter_result = ArbitrationResult("abstain", "disabled", "")
    eligible_records = {str(record["id"]): record for record in records}
    consensus_fusion_choice = next(
        (
            str(record["id"])
            for record in records
            if comparison_key(str(record["text"]))
            == comparison_key(consensus_fusion_candidate)
        ),
        "",
    ) if consensus_fusion_corrections else ""
    rejected_arbiter_choice = ""
    # Loading Gemma 12B is deliberately deferred until there is a genuinely
    # unresolved, selectable disagreement.  Consensus needs no language-model
    # judgement, and eagerly loading it here would add a large cold-start cost
    # to otherwise deterministic jobs.
    requires_local_arbiter = bool(
        not (all_raw_agree or qwen_whisper_agree or qwen_verifier_agree or whisper_verifier_agree)
        and not consensus_fusion_choice
        and len(eligible_records) > 1
    )
    if all_raw_agree:
        method = "three_asr_agreement"
    elif qwen_whisper_agree:
        method = "qwen_whisper_agreement"
    elif qwen_verifier_agree:
        method = "qwen_verifier_agreement"
    elif two_secondary_full_agreement_safe:
        secondary_record = next(
            (
                record
                for record in records
                if record.get("kind") == "two_secondary_full_agreement"
            ),
            None,
        )
        if secondary_record is not None:
            choice = str(secondary_record["id"])
        method = "whisper_verifier_agreement"
    elif consensus_fusion_choice:
        choice = consensus_fusion_choice
        method = "deterministic_phrase_consensus_fusion"
    elif arbiter is not None and len(eligible_records) > 1:
        try:
            raw_result = arbiter.choose(
                [
                    Candidate(
                        str(record["id"]),
                        str(record["text"]),
                        tuple(str(item) for item in record["supported_by"]),
                        tuple(dict(item) for item in record.get("evidence", [])),
                    )
                    for record in eligible_records.values()
                ],
                vocabulary=vocabulary_tuple,
            )
            if isinstance(raw_result, ArbitrationResult):
                arbiter_result = raw_result
        except Exception:
            arbiter_result = ArbitrationResult(
                "abstain", "unavailable", type(arbiter).__name__
            )
        if (
            arbiter_result.status == "selected"
            and arbiter_result.choice in eligible_records
        ):
            choice = arbiter_result.choice
            method = (
                "local_arbiter_kept_qwen_backbone"
                if choice == "c0"
                else "local_arbiter_evidence_rewrite"
            )
        elif arbiter_result.status == "selected" and arbiter_result.choice != "abstain":
            rejected_arbiter_choice = arbiter_result.choice
            choice = "c0"
            method = "arbiter_choice_rejected_qwen_backbone"
        else:
            method = f"local_arbiter_{arbiter_result.status}_qwen_backbone"

    chosen_record = next(record for record in records if record["id"] == choice)
    chosen_text = str(chosen_record["text"])
    qv_metrics = _pair_metrics(primary_text, verifier_text)
    qw_metrics = _pair_metrics(primary_text, whisper_text)
    raw_disagreement = not all_raw_agree
    resolved_by_agreement = method in {
        "three_asr_agreement",
        "qwen_whisper_agreement",
        "qwen_verifier_agreement",
        "whisper_verifier_agreement",
    }
    # A Gemma choice is evidence-bounded, not a fresh acoustic observation;
    # retain the low-confidence marker whenever the raw ASRs disagree.
    unresolved = raw_disagreement and not resolved_by_agreement

    reasons = [method]
    if raw_disagreement:
        reasons.append("three_asr_disagreement")
    if unresolved:
        reasons.append("unresolved_disagreement")
    edit_distance = max(
        int(qv_metrics["mixed_unit_edit_distance"]),
        int(qw_metrics["mixed_unit_edit_distance"]),
    )
    ratio = max(
        float(qv_metrics["mixed_unit_disagreement_ratio"]),
        float(qw_metrics["mixed_unit_disagreement_ratio"]),
    )
    similarity = min(
        float(qv_metrics["mixed_unit_similarity"]),
        float(qw_metrics["mixed_unit_similarity"]),
    )
    missing = not verifier_key or not whisper_key
    if all_raw_agree:
        confidence = 0.96
    elif method == "qwen_whisper_agreement":
        confidence = 0.93
    elif method == "qwen_verifier_agreement":
        confidence = 0.90
    elif method == "whisper_verifier_agreement":
        confidence = 0.90
    elif method == "deterministic_phrase_consensus_fusion":
        confidence = 0.84
    elif method == "local_arbiter_evidence_rewrite":
        confidence = 0.72
    elif method == "local_arbiter_kept_qwen_backbone":
        confidence = 0.66
    else:
        confidence = max(0.30, min(0.62, 0.62 * similarity * (1.0 - ratio)))
    confidence = round(confidence, 6)
    low_confidence_score = confidence <= 0.30
    if low_confidence_score:
        reasons.append("low_confidence_score")
    corrections = _corrections_from_choice(primary_text, chosen_text, method)
    audit = AlignmentAudit(
        similarity=round(similarity, 6),
        edit_distance=edit_distance,
        disagreement_count=edit_distance,
        missing_in_verifier=not verifier_key,
        conflict=unresolved,
        low_confidence=(
            unresolved
            or low_confidence_score
        ),
        reasons=tuple(reasons),
        corrections=corrections,
        disagreement_ratio=round(ratio, 6),
        missing=missing,
        conflict_candidate=raw_disagreement,
    )
    ensemble_audit = {
        "policy_version": ENSEMBLE_POLICY_VERSION,
        "method": method,
        "choice": choice,
        "candidates": [
            {
                "id": record["id"],
                "text": record["text"],
                "supported_by": list(record["supported_by"]),
                "kind": record.get("kind", "unknown"),
                "evidence": list(record.get("evidence", [])),
            }
            for record in records
        ],
        "pair_metrics": {"qwen_verifier": qv_metrics, "qwen_whisper": qw_metrics},
        "pair_audit": {
            "verifier": asdict(verifier_audit),
            "whisper": asdict(whisper_audit),
        },
        "raw_hypotheses": {
            "verifier": {
                "text": verifier_text,
                "selectable": False,
                "reason": "single_model_raw_hypothesis",
            },
            "qwen": {
                "text": primary_text,
                "selectable": bool(primary_key),
                "reason": "timestamp_bearing_primary_candidate",
            },
            "whisper": {
                "text": whisper_text,
                "selectable": False,
                "reason": "single_model_raw_hypothesis",
            },
        },
        "safety_gate": {
            "eligible_candidate_ids": list(eligible_records),
            "eligible_candidate_kinds": sorted(
                {str(record.get("kind", "unknown")) for record in eligible_records.values()}
            ),
            "raw_hypotheses_selectable": {
                "qwen": bool(primary_key),
                "whisper": False,
                "verifier": False,
            },
            "rejected_choice": rejected_arbiter_choice,
            "cross_model_correction_vetoes": {
                "verifier": [asdict(item) for item in verifier_vetoed],
                "whisper": [asdict(item) for item in whisper_vetoed],
            },
            "bounded_vocabulary_anchor_candidates": {
                "verifier_exact": [asdict(item) for item in verifier_anchor_corrections],
                "whisper_exact": [asdict(item) for item in whisper_anchor_corrections],
                "acoustic_consensus_claimed": False,
                "auto_selected": False,
            },
            "phrase_consensus_fusion": {
                "corrections": [asdict(item) for item in consensus_fusion_corrections],
                "evidence": list(consensus_fusion_evidence),
                "two_secondary_support_required": True,
                "single_source_insertions_auto_applied": False,
                "single_source_requires_calibrated_acoustic_evidence": True,
                "calibrated_word_acoustic_evidence_available": False,
                "unapplied_single_source_edits": {
                    "verifier": verifier_only_edits,
                    "whisper": whisper_only_edits,
                },
                "auto_selected": method == "deterministic_phrase_consensus_fusion",
            },
            "deletion_protection": {
                "auto_delete_allowed": False,
                "two_secondary_full_agreement_vetoed": bool(
                    whisper_verifier_agree and not two_secondary_full_agreement_safe
                ),
            },
        },
        "arbiter": arbiter_result.to_dict(),
        "requires_local_arbiter": requires_local_arbiter,
        "confidence": confidence,
        "free_text_generation_allowed": False,
        "evidence_bounded_rewriting_allowed": True,
        "fallback_policy": "qwen_timing_backbone_when_local_evidence_is_insufficient",
    }
    return chosen_text, audit, ensemble_audit


def reconcile_three_segments(
    primary_segments: Sequence[TranscriptSegment],
    verifier_segments: Sequence[TranscriptSegment],
    whisper_segments: Sequence[TranscriptSegment],
    *,
    vocabulary: Iterable[str] = (),
    arbiter: Any | None = None,
) -> tuple[ReconciledSegment, ...]:
    def assign_once(
        secondary_segments: Sequence[TranscriptSegment],
    ) -> dict[int, list[TranscriptSegment]]:
        assigned: dict[int, list[TranscriptSegment]] = {}
        for secondary in secondary_segments:
            overlaps = [
                (
                    max(
                        0,
                        min(primary.end_ms, secondary.end_ms)
                        - max(primary.start_ms, secondary.start_ms),
                    ),
                    index,
                )
                for index, primary in enumerate(primary_segments)
            ]
            positive_overlaps = [item for item in overlaps if item[0] > 0]
            # Without word-level timestamps, assigning one whole secondary
            # segment to multiple Qwen segments duplicates words.  A segment
            # spanning more than one primary interval is therefore ambiguous
            # and fails closed instead of being copied or guessed apart.
            if len(positive_overlaps) != 1:
                continue
            overlap_ms, index = positive_overlaps[0]
            if overlap_ms <= 0 or index < 0:
                continue
            assigned.setdefault(index, []).append(secondary)
        for segments in assigned.values():
            segments.sort(key=lambda item: (item.start_ms, item.end_ms, item.text))
        return assigned

    verifier_assignments = assign_once(verifier_segments)
    whisper_assignments = assign_once(whisper_segments)
    output: list[ReconciledSegment] = []
    for primary_index, primary in enumerate(primary_segments):
        verifier_text = _join_fragments(
            [segment.text for segment in verifier_assignments.get(primary_index, ())]
        )
        whisper_text = _join_fragments(
            [segment.text for segment in whisper_assignments.get(primary_index, ())]
        )
        text, audit, ensemble_audit = reconcile_three_texts(
            primary.text,
            verifier_text,
            whisper_text,
            vocabulary=vocabulary,
            arbiter=arbiter,
        )
        output.append(
            ReconciledSegment(
                start_ms=primary.start_ms,
                end_ms=primary.end_ms,
                primary_text=primary.text,
                verifier_text=verifier_text,
                whisper_text=whisper_text,
                text=text,
                confidence=float(ensemble_audit["confidence"]),
                audit=audit,
                ensemble_audit=ensemble_audit,
            )
        )
    return tuple(output)


__all__ = [
    "ENSEMBLE_POLICY_VERSION",
    "comparison_key",
    "mixed_units",
    "reconcile_three_segments",
    "reconcile_three_texts",
]
