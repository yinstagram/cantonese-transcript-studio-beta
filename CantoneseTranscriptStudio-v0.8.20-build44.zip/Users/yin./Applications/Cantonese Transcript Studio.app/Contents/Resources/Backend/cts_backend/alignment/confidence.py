"""Central deterministic confidence policy for two-model reconciliation."""

from __future__ import annotations


def disagreement_ratio(edit_distance: int, primary_length: int, verifier_length: int) -> float:
    denominator = max(primary_length, verifier_length, 1)
    return round(max(0, edit_distance) / denominator, 6)


def reconciliation_confidence(
    *,
    similarity: float,
    ratio: float,
    missing: bool,
    conflict: bool,
    corrected: bool,
    primary_confidence: float | None = None,
) -> float:
    """Score agreement evidence; never treats absent verifier probabilities as confidence."""
    if missing:
        score = 0.30
    elif conflict:
        score = max(0.20, 0.62 * similarity * (1.0 - min(1.0, ratio)))
    elif corrected:
        score = max(0.70, 0.88 * similarity)
    else:
        score = 0.96 if similarity >= 0.999999 else 0.82 * similarity
    if primary_confidence is not None:
        score = min(score, max(0.0, min(1.0, primary_confidence)))
    return round(max(0.0, min(1.0, score)), 6)


__all__ = ["disagreement_ratio", "reconciliation_confidence"]
