"""Model registry, resumable downloads, integrity checks and safe extraction."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable

from .settings import AppPaths, _atomic_json


QWEN_PRIMARY_ID = "Qwen/Qwen3-ASR-1.7B"
QWEN_FALLBACK_ID = "Qwen/Qwen3-ASR-0.6B"
QWEN_ALIGNER_ID = "Qwen/Qwen3-ForcedAligner-0.6B"
QWEN_PRIMARY_RUNTIME_DIRECTORY = "Qwen3-ASR-1.7B-MLX-8bit"
QWEN_PRIMARY_REVISION = "7278e1e70fe206f11671096ffdd38061171dd6e5"
QWEN_FALLBACK_REVISION = "5eb144179a02acc5e5ba31e748d22b0cf3e303b0"
QWEN_ALIGNER_REVISION = "c7cbfc2048c462b0d63a45797104fc9db3ad62b7"
SHERPA_MODEL_NAME = (
    "sherpa-onnx-wenetspeech-yue-u2pp-conformer-ctc-zh-en-cantonese-"
    "int8-2025-09-10"
)
SHERPA_ARCHIVE_NAME = f"{SHERPA_MODEL_NAME}.tar.bz2"
SHERPA_URL = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
    + SHERPA_ARCHIVE_NAME
)
SHERPA_SHA256 = "8636295785a43538a1b4620f167bcb89c10ce5ebdcee61c72a388738b783f992"
SHERPA_ARCHIVE_BYTES = 117_203_117
SENSEVOICE_YUE_MODEL_NAME = (
    "sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09"
)
SENSEVOICE_YUE_ARCHIVE_NAME = f"{SENSEVOICE_YUE_MODEL_NAME}.tar.bz2"
SENSEVOICE_YUE_URL = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
    + SENSEVOICE_YUE_ARCHIVE_NAME
)
SENSEVOICE_YUE_SHA256 = (
    "7305f7905bfcf77fa0b39388a313f3da35c68d971661a65475b56fb2162c8e63"
)
SENSEVOICE_YUE_ARCHIVE_BYTES = 165_783_878
WHISPER_LARGE_V2_ID = "whisper.cpp/large-v2"
WHISPER_LARGE_V2_FILENAME = "ggml-large-v2.bin"
WHISPER_LARGE_V2_URL = (
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
    + WHISPER_LARGE_V2_FILENAME
)
WHISPER_LARGE_V2_SHA256 = (
    "9a423fe4d40c82774b6af34115b8b935f34152246eb19e80e376071d3f999487"
)
WHISPER_LARGE_V2_BYTES = 3_094_623_691
WHISPER_LARGE_V3_ID = "whisper.cpp/large-v3"
WHISPER_LARGE_V3_FILENAME = "ggml-large-v3.bin"
WHISPER_LARGE_V3_URL = (
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
    + WHISPER_LARGE_V3_FILENAME
)
WHISPER_LARGE_V3_SHA256 = (
    "64d182b440b98d5203c4f9bd541544d84c605196c4f7b845dfa11fb23594d1e2"
)
WHISPER_LARGE_V3_BYTES = 3_095_033_483
WHISPER_MODEL_IDS = frozenset({WHISPER_LARGE_V3_ID, WHISPER_LARGE_V2_ID})
WHISPER_MODEL_FILENAMES = {
    WHISPER_LARGE_V3_ID: WHISPER_LARGE_V3_FILENAME,
    WHISPER_LARGE_V2_ID: WHISPER_LARGE_V2_FILENAME,
}
# ``small`` is the multilingual 244M-parameter Whisper model.  It is not a
# "v3 small" model (OpenAI has never released one), but it is deliberately
# used only for low-latency *provisional* live captions.  The final live
# caption is decoded by the Cantonese-aware ``large-v3`` model below.
WHISPER_SMALL_ID = "whisper.cpp/small"
WHISPER_SMALL_FILENAME = "ggml-small.bin"
WHISPER_SMALL_URL = (
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
    + WHISPER_SMALL_FILENAME
)
# Hugging Face LFS SHA-256, obtained from the upstream file metadata at the
# pinned public artifact path above.  Keep this separate from the Git blob ID
# published in whisper.cpp's human-readable model table.
WHISPER_SMALL_SHA256 = (
    "1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b"
)
WHISPER_SMALL_BYTES = 487_601_967
LIVE_WHISPER_MODEL_IDS = frozenset({WHISPER_SMALL_ID, WHISPER_LARGE_V3_ID})
SPEAKER_SEGMENTATION_ID = "sherpa-onnx-pyannote-segmentation-3-0"
SPEAKER_SEGMENTATION_ARCHIVE = f"{SPEAKER_SEGMENTATION_ID}.tar.bz2"
SPEAKER_SEGMENTATION_URL = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/"
    "speaker-segmentation-models/" + SPEAKER_SEGMENTATION_ARCHIVE
)
SPEAKER_SEGMENTATION_SHA256 = "24615ee884c897d9d2ba09bb4d30da6bb1b15e685065962db5b02e76e4996488"
SPEAKER_SEGMENTATION_BYTES = 6_958_444
SPEAKER_EMBEDDING_ID = "3dspeaker_speech_campplus_sv_zh-cn_16k-common"
SPEAKER_EMBEDDING_FILENAME = f"{SPEAKER_EMBEDDING_ID}.onnx"
SPEAKER_EMBEDDING_URL = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/"
    "speaker-recongition-models/" + SPEAKER_EMBEDDING_FILENAME
)
SPEAKER_EMBEDDING_SHA256 = "f682b514c05d947ee3fa91cd6ec6c5c7543479a128373fa29b1faedccd21fd11"
SPEAKER_EMBEDDING_BYTES = 28_281_138
SORTFORMER_COREML_ID = "FluidInference/diar-streaming-sortformer-coreml"
SORTFORMER_COREML_REVISION = "ae9a27ab45dc0aa3abede7d2d6bad2b7a69aa6d1"
SORTFORMER_COREML_PREFIX = (
    "v3/palettized/SortformerNvidiaHigh_v2.1.mlmodelc/"
)
SORTFORMER_COREML_BUNDLE = SORTFORMER_COREML_PREFIX.rstrip("/")
SORTFORMER_COREML_BYTES = 103_793_339
# Immutable revision metadata plus local SHA-256 values pin every file in the
# compiled CoreML bundle.  ``remote_hash`` is either the Hugging Face LFS
# SHA-256 or Git blob SHA-1 declared by that immutable snapshot.
SORTFORMER_COREML_FILES: dict[str, dict[str, Any]] = {
    SORTFORMER_COREML_PREFIX + "analytics/coremldata.bin": {
        "size": 202,
        "sha256": "a38c7a98a0a0e848646705230ba4bd814eeadbd758f308067d5c91fab4262d89",
        "remote_hash": "a38c7a98a0a0e848646705230ba4bd814eeadbd758f308067d5c91fab4262d89",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "coremldata.bin": {
        "size": 1_099,
        "sha256": "ea45dd28184fb8cd3753cc8cdb4a3d1d904184b19b398fe56bfac5b029f4bb21",
        "remote_hash": "ea45dd28184fb8cd3753cc8cdb4a3d1d904184b19b398fe56bfac5b029f4bb21",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "model0/analytics/coremldata.bin": {
        "size": 108,
        "sha256": "5a8281049b2a65a3be541cfd9f949e84b8fe1c5251ce90e46da1626fed54e58a",
        "remote_hash": "5a8281049b2a65a3be541cfd9f949e84b8fe1c5251ce90e46da1626fed54e58a",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "model0/coremldata.bin": {
        "size": 634,
        "sha256": "084ef78025bb430de8c0bfeb17bed408b7a8a50c223ff7a1bbadc7532618f5bd",
        "remote_hash": "084ef78025bb430de8c0bfeb17bed408b7a8a50c223ff7a1bbadc7532618f5bd",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "model0/model.mil": {
        "size": 63_578,
        "sha256": "ec218ddb7cf8b3d7d52b0876f701d93fdb2ec99c6d4741c13b562f3f8229a084",
        "remote_hash": "1d307d7df89373b7e980f03ec000c4bbeab2b052",
        "remote_hash_kind": "git_blob_sha1",
    },
    SORTFORMER_COREML_PREFIX + "model0/weights/0-weight.bin": {
        "size": 8_948_544,
        "sha256": "88a98803e35186b1dfb41d7f748f7cee5093bb6efeb117f56953c17549792fa4",
        "remote_hash": "88a98803e35186b1dfb41d7f748f7cee5093bb6efeb117f56953c17549792fa4",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "model1/analytics/coremldata.bin": {
        "size": 108,
        "sha256": "5a8281049b2a65a3be541cfd9f949e84b8fe1c5251ce90e46da1626fed54e58a",
        "remote_hash": "5a8281049b2a65a3be541cfd9f949e84b8fe1c5251ce90e46da1626fed54e58a",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "model1/coremldata.bin": {
        "size": 595,
        "sha256": "ee4f9113fe06577518e5a896c8ec309c7bc7ecf4b2c1c2024f2d82e503adcfae",
        "remote_hash": "ee4f9113fe06577518e5a896c8ec309c7bc7ecf4b2c1c2024f2d82e503adcfae",
        "remote_hash_kind": "lfs_sha256",
    },
    SORTFORMER_COREML_PREFIX + "model1/model.mil": {
        "size": 3_097_255,
        "sha256": "d7a848361b92f83ea138383dd69e58c4ff87c5f85dc974ebda23dc6e292a68d1",
        "remote_hash": "b7cdd7b547d5ce976a6416b75107affd983e2cab",
        "remote_hash_kind": "git_blob_sha1",
    },
    SORTFORMER_COREML_PREFIX + "model1/weights/1-weight.bin": {
        "size": 91_681_216,
        "sha256": "304e22e94254b7c4c5618ab49eb0246dabe83553e4e338d1a2bf5a0027fd0b7d",
        "remote_hash": "304e22e94254b7c4c5618ab49eb0246dabe83553e4e338d1a2bf5a0027fd0b7d",
        "remote_hash_kind": "lfs_sha256",
    },
}
HF_ALLOW_PATTERNS = ("*.json", "*.safetensors", "*.txt", "*.model")
HF_METADATA_MAX_BYTES = 8 * 1024 * 1024
MODEL_DOWNLOAD_FREE_SPACE_RESERVE_BYTES = 2 * 1024 * 1024 * 1024
VERIFICATION_STAMP_FILENAME = ".verification.json"

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]


class ModelError(RuntimeError):
    pass


class DownloadCancelled(ModelError):
    pass


@dataclass(frozen=True)
class ModelSpec:
    key: str
    kind: str
    source: str
    directory: str
    revision: str | None = None
    sha256: str | None = None
    archive: str | None = None
    prefix: str | None = None


MODEL_REGISTRY: dict[str, ModelSpec] = {
    QWEN_PRIMARY_ID: ModelSpec(
        key=QWEN_PRIMARY_ID, kind="huggingface", source=QWEN_PRIMARY_ID,
        directory="Qwen3-ASR-1.7B", revision=QWEN_PRIMARY_REVISION,
    ),
    QWEN_FALLBACK_ID: ModelSpec(
        key=QWEN_FALLBACK_ID, kind="huggingface", source=QWEN_FALLBACK_ID,
        directory="Qwen3-ASR-0.6B", revision=QWEN_FALLBACK_REVISION,
    ),
    QWEN_ALIGNER_ID: ModelSpec(
        key=QWEN_ALIGNER_ID, kind="huggingface", source=QWEN_ALIGNER_ID,
        directory="Qwen3-ForcedAligner-0.6B", revision=QWEN_ALIGNER_REVISION,
    ),
    SHERPA_MODEL_NAME: ModelSpec(
        key=SHERPA_MODEL_NAME,
        kind="sherpa",
        source=SHERPA_URL,
        directory=SHERPA_MODEL_NAME,
        sha256=SHERPA_SHA256,
        archive=SHERPA_ARCHIVE_NAME,
    ),
    SENSEVOICE_YUE_MODEL_NAME: ModelSpec(
        key=SENSEVOICE_YUE_MODEL_NAME,
        kind="sherpa",
        source=SENSEVOICE_YUE_URL,
        directory=SENSEVOICE_YUE_MODEL_NAME,
        sha256=SENSEVOICE_YUE_SHA256,
        archive=SENSEVOICE_YUE_ARCHIVE_NAME,
    ),
    WHISPER_LARGE_V2_ID: ModelSpec(
        key=WHISPER_LARGE_V2_ID,
        kind="whisper",
        source=WHISPER_LARGE_V2_URL,
        directory="Whisper-Large-v2",
        sha256=WHISPER_LARGE_V2_SHA256,
        archive=WHISPER_LARGE_V2_FILENAME,
    ),
    WHISPER_LARGE_V3_ID: ModelSpec(
        key=WHISPER_LARGE_V3_ID,
        kind="whisper",
        source=WHISPER_LARGE_V3_URL,
        directory="Whisper-Large-v3",
        sha256=WHISPER_LARGE_V3_SHA256,
        archive=WHISPER_LARGE_V3_FILENAME,
    ),
    WHISPER_SMALL_ID: ModelSpec(
        key=WHISPER_SMALL_ID,
        kind="whisper",
        source=WHISPER_SMALL_URL,
        directory="Whisper-Small",
        sha256=WHISPER_SMALL_SHA256,
        archive=WHISPER_SMALL_FILENAME,
    ),
    SPEAKER_SEGMENTATION_ID: ModelSpec(
        key=SPEAKER_SEGMENTATION_ID,
        kind="speaker_segmentation",
        source=SPEAKER_SEGMENTATION_URL,
        directory=SPEAKER_SEGMENTATION_ID,
        sha256=SPEAKER_SEGMENTATION_SHA256,
        archive=SPEAKER_SEGMENTATION_ARCHIVE,
    ),
    SPEAKER_EMBEDDING_ID: ModelSpec(
        key=SPEAKER_EMBEDDING_ID,
        kind="speaker_embedding",
        source=SPEAKER_EMBEDDING_URL,
        directory=SPEAKER_EMBEDDING_ID,
        sha256=SPEAKER_EMBEDDING_SHA256,
        archive=SPEAKER_EMBEDDING_FILENAME,
    ),
    SORTFORMER_COREML_ID: ModelSpec(
        key=SORTFORMER_COREML_ID,
        kind="huggingface_prefix",
        source=SORTFORMER_COREML_ID,
        directory="Sortformer-Streaming-High-v2.1-CoreML",
        revision=SORTFORMER_COREML_REVISION,
        prefix=SORTFORMER_COREML_PREFIX,
    ),
}


def _primary_runtime_path(source_path: Path) -> Path:
    """Return the fixed app-owned Q8 derivative without importing ASR.

    ``models`` is imported by audio setup and worker startup.  Importing the
    ASR package here creates a circular dependency through ``audio.media``.
    Keep the registry-side path calculation literal and covered against the
    same fixed directory name used by the converter.
    """

    return Path(source_path).with_name(QWEN_PRIMARY_RUNTIME_DIRECTORY)

MODEL_UI: dict[str, dict[str, Any]] = {
    QWEN_PRIMARY_ID: {
        "name": "Qwen3-ASR-1.7B",
        "display_name": "Qwen3-ASR 1.7B",
        "size_bytes": round(4.38 * 1024**3),
        "is_required": True,
    },
    QWEN_FALLBACK_ID: {
        "name": "Qwen3-ASR-0.6B",
        "display_name": "Qwen3-ASR 0.6B",
        "size_bytes": round(1.75 * 1024**3),
        "is_required": False,
    },
    QWEN_ALIGNER_ID: {
        "name": "Qwen3-ForcedAligner-0.6B",
        "display_name": "Qwen3 Forced Aligner 0.6B",
        "size_bytes": round(1.71 * 1024**3),
        "is_required": False,
    },
    SHERPA_MODEL_NAME: {
        "name": SHERPA_MODEL_NAME,
        "display_name": "WenetSpeech-Yue 覆核模型",
        "size_bytes": 117_203_117,
        "is_required": True,
    },
    SENSEVOICE_YUE_MODEL_NAME: {
        "name": SENSEVOICE_YUE_MODEL_NAME,
        "display_name": "SenseVoice Yue 時間碼覆核",
        "size_bytes": SENSEVOICE_YUE_ARCHIVE_BYTES,
        "is_required": False,
    },
    WHISPER_LARGE_V2_ID: {
        "name": "Whisper-Large-v2",
        "display_name": "Whisper Large v2",
        "size_bytes": WHISPER_LARGE_V2_BYTES,
        "is_required": False,
    },
    WHISPER_LARGE_V3_ID: {
        "name": "Whisper-Large-v3",
        "display_name": "Whisper Large v3（廣東話）",
        "size_bytes": WHISPER_LARGE_V3_BYTES,
        "is_required": False,
    },
    WHISPER_SMALL_ID: {
        "name": "Whisper-Small",
        "display_name": "Whisper Small（即時草稿）",
        "size_bytes": WHISPER_SMALL_BYTES,
        "is_required": False,
    },
    SPEAKER_SEGMENTATION_ID: {
        "name": SPEAKER_SEGMENTATION_ID,
        "display_name": "Speaker segmentation（PyAnnote）",
        "size_bytes": SPEAKER_SEGMENTATION_BYTES,
        "is_required": True,
    },
    SPEAKER_EMBEDDING_ID: {
        "name": SPEAKER_EMBEDDING_ID,
        "display_name": "3D-Speaker voice embedding",
        "size_bytes": SPEAKER_EMBEDDING_BYTES,
        "is_required": True,
    },
    SORTFORMER_COREML_ID: {
        "name": "Sortformer-Streaming-High-v2.1-CoreML",
        "display_name": "Sortformer 講者辨認（Core ML）",
        "size_bytes": SORTFORMER_COREML_BYTES,
        "is_required": True,
    },
}


def sha256_file(path: Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def git_blob_sha1_file(path: Path, block_size: int = 1024 * 1024) -> str:
    size = path.stat().st_size
    digest = hashlib.sha1(usedforsecurity=False)
    digest.update(f"blob {size}\0".encode("ascii"))
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def _hash_open_fd(fd: int, algorithm: str, *, git_blob_size: int | None = None) -> str:
    if algorithm == "sha256":
        digest = hashlib.sha256()
    elif algorithm == "git-blob-sha1":
        if git_blob_size is None:
            raise ValueError("git blob hash requires a size")
        digest = hashlib.sha1(usedforsecurity=False)
        digest.update(f"blob {git_blob_size}\0".encode("ascii"))
    else:  # pragma: no cover - private helper contract
        raise ValueError(f"unsupported hash: {algorithm}")
    os.lseek(fd, 0, os.SEEK_SET)
    while True:
        block = os.read(fd, 1024 * 1024)
        if not block:
            break
        digest.update(block)
    return digest.hexdigest()


def _open_partial_fd(partial: Path, *, expected_size: int, create: bool) -> int:
    """Open a partial file without following a last-component symlink."""
    nofollow = getattr(os, "O_NOFOLLOW", None)
    if nofollow is None:  # pragma: no cover - supported on the target macOS runtime
        raise ModelError("目前 runtime 不支援安全 partial download（O_NOFOLLOW）")
    flags = os.O_RDWR | getattr(os, "O_CLOEXEC", 0) | nofollow
    if create:
        flags |= os.O_CREAT | os.O_EXCL
    try:
        fd = os.open(partial, flags, 0o600)
    except OSError as exc:
        raise ModelError(f"partial download path 開啟失敗：{partial}") from exc
    try:
        current = os.fstat(fd)
        if not stat.S_ISREG(current.st_mode) or current.st_size != expected_size:
            raise ModelError(f"partial download file identity／size 已改變：{partial}")
        return fd
    except BaseException:
        os.close(fd)
        raise


def _path_matches_fd(path: Path, fd: int) -> bool:
    try:
        opened = os.fstat(fd)
        current = path.stat(follow_symlinks=False)
        return (
            stat.S_ISREG(current.st_mode)
            and current.st_dev == opened.st_dev
            and current.st_ino == opened.st_ino
        )
    except OSError:
        return False


def move_to_trash(path: Path) -> Path | None:
    """Move an app-owned path to the user's Trash without deleting it."""
    if not path.exists() and not path.is_symlink():
        return None
    trash = Path.home() / ".Trash"
    trash.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    destination = trash / f"{path.name}-{stamp}-{uuid.uuid4().hex[:8]}"
    shutil.move(str(path), str(destination))
    return destination


def _files_for_manifest(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            relative = path.relative_to(root)
            if not (relative.parts and relative.parts[0] == ".cache"):
                raise ModelError(f"模型目錄不允許 symlink：{relative}")
            continue
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if relative.parts and relative.parts[0] == ".cache":
            continue
        if relative.as_posix() in {"manifest.json", VERIFICATION_STAMP_FILENAME}:
            continue
        yield path


def _manifest_file_entries(manifest: Any) -> dict[str, dict[str, Any]]:
    """Return a canonical, duplicate-free manifest file map."""
    if not isinstance(manifest, dict) or manifest.get("schema") != 1:
        raise ModelError("模型 manifest schema 無效")
    raw_files = manifest.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        raise ModelError("模型 manifest files 無效")
    entries: dict[str, dict[str, Any]] = {}
    for entry in raw_files:
        if not isinstance(entry, dict):
            raise ModelError("模型 manifest file entry 無效")
        raw_path = entry.get("path")
        if not isinstance(raw_path, str) or not raw_path or "\\" in raw_path or "\0" in raw_path:
            raise ModelError(f"非法 manifest path：{raw_path}")
        relative = PurePosixPath(raw_path)
        canonical = relative.as_posix()
        if (
            relative.is_absolute()
            or not relative.parts
            or ".." in relative.parts
            or "." in relative.parts
            or canonical != raw_path
            or canonical in {"manifest.json", VERIFICATION_STAMP_FILENAME}
        ):
            raise ModelError(f"非法 manifest path：{raw_path}")
        if canonical in entries:
            raise ModelError(f"重複 manifest path：{canonical}")
        size = entry.get("size")
        sha256 = entry.get("sha256")
        if isinstance(size, bool) or not isinstance(size, int) or size < 0:
            raise ModelError(f"manifest size 無效：{canonical}")
        if (
            not isinstance(sha256, str)
            or len(sha256) != 64
            or any(character not in "0123456789abcdef" for character in sha256.lower())
        ):
            raise ModelError(f"manifest SHA-256 無效：{canonical}")
        entries[canonical] = entry
    return entries


def build_manifest(root: Path, *, spec: ModelSpec, revision: str | None = None) -> dict[str, Any]:
    files = []
    for path in _files_for_manifest(root):
        files.append(
            {
                "path": path.relative_to(root).as_posix(),
                "size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    if not files:
        raise ModelError(f"模型目錄無檔案：{root}")
    manifest = {
        "schema": 1,
        "model": spec.key,
        "kind": spec.kind,
        "source": spec.source,
        "revision": revision,
        "files": files,
    }
    _atomic_json(root / "manifest.json", manifest)
    return manifest


def verify_manifest(root: Path) -> dict[str, Any]:
    manifest_path = root / "manifest.json"
    if root.is_symlink() or manifest_path.is_symlink() or not manifest_path.is_file():
        raise ModelError(f"模型缺少 manifest：{root}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ModelError(f"模型 manifest JSON 無效：{root}") from exc
    entries = _manifest_file_entries(manifest)
    failures: list[str] = []
    try:
        actual_files = {
            candidate.relative_to(root).as_posix(): candidate
            for candidate in _files_for_manifest(root)
        }
    except ModelError as exc:
        failures.append(str(exc))
        actual_files = {}
    missing = sorted(set(entries) - set(actual_files))
    unexpected = sorted(set(actual_files) - set(entries))
    failures.extend(f"缺少：{relative}" for relative in missing)
    failures.extend(f"manifest 未列出：{relative}" for relative in unexpected)
    for relative_text, entry in entries.items():
        relative = PurePosixPath(relative_text)
        path = root.joinpath(*relative.parts)
        if path.is_symlink():
            failures.append(f"不允許 symlink：{relative}")
            continue
        if not path.is_file():
            failures.append(f"缺少：{relative}")
            continue
        if path.stat().st_size != int(entry.get("size", -1)):
            failures.append(f"大小不符：{relative}")
            continue
        if sha256_file(path) != entry.get("sha256"):
            failures.append(f"SHA-256 不符：{relative}")
    if failures:
        raise ModelError("；".join(failures))
    return manifest


def _directory_bytes(path: Path) -> int:
    total = 0
    if not path.exists():
        return total
    for candidate in path.rglob("*"):
        try:
            if candidate.is_file():
                total += candidate.stat().st_size
        except OSError:
            continue
    return total


def _emit(callback: Progress | None, **payload: Any) -> None:
    if callback is not None:
        callback(payload)


def _safe_extract_tar(archive: Path, destination: Path) -> None:
    """Extract regular files/directories only, rejecting traversal and links."""
    destination.mkdir(parents=True, exist_ok=False)
    root = destination.resolve()
    with tarfile.open(archive, mode="r:bz2") as bundle:
        for member in bundle.getmembers():
            pure = PurePosixPath(member.name)
            if pure.is_absolute() or not pure.parts or ".." in pure.parts:
                raise ModelError(f"archive 有非法 path：{member.name}")
            if member.issym() or member.islnk() or member.isdev() or member.isfifo():
                raise ModelError(f"archive 有不允許 member：{member.name}")
            target = destination.joinpath(*pure.parts)
            resolved_parent = target.parent.resolve()
            if root != resolved_parent and root not in resolved_parent.parents:
                raise ModelError(f"archive path traversal：{member.name}")
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            if not member.isfile():
                raise ModelError(f"archive member 類型不支援：{member.name}")
            target.parent.mkdir(parents=True, exist_ok=True)
            source = bundle.extractfile(member)
            if source is None:
                raise ModelError(f"讀唔到 archive member：{member.name}")
            with source, target.open("xb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)


class ModelManager:
    def __init__(self, paths: AppPaths | None = None) -> None:
        self.paths = (paths or AppPaths.default()).ensure()
        self.downloads = self.paths.models / ".downloads"
        self.downloads.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._verified: dict[str, tuple[Any, ...]] = {}

    def spec(self, key: str) -> ModelSpec:
        try:
            return MODEL_REGISTRY[key]
        except KeyError as exc:
            raise ValueError(f"未知模型：{key}") from exc

    def path_for(self, key: str) -> Path:
        return self.paths.models / self.spec(key).directory

    def _partial_bytes(self, spec: ModelSpec) -> int:
        installed_or_resumed = _directory_bytes(self.path_for(spec.key))
        if spec.kind in {"huggingface", "huggingface_prefix"}:
            return installed_or_resumed + _directory_bytes(self.downloads / spec.directory)
        if spec.archive:
            archive = self.downloads / spec.archive
            partial = archive.with_suffix(archive.suffix + ".part")
            if archive.is_file() and not archive.is_symlink():
                return installed_or_resumed + archive.stat().st_size
            if partial.is_file() and not partial.is_symlink():
                return installed_or_resumed + partial.stat().st_size
        return installed_or_resumed

    def _ensure_download_space(self, spec: ModelSpec) -> None:
        expected = int(MODEL_UI[spec.key]["size_bytes"])
        remaining = max(0, expected - min(expected, self._partial_bytes(spec)))
        # Tar-based models need room for the archive and extracted model at the
        # same time.  Other downloads atomically promote each partial file.
        extraction_headroom = (
            expected
            if spec.kind in {"sherpa", "speaker_segmentation"}
            else 0
        )
        required = remaining + extraction_headroom + MODEL_DOWNLOAD_FREE_SPACE_RESERVE_BYTES
        try:
            free = shutil.disk_usage(self.paths.models).free
        except OSError as exc:
            raise ModelError("無法確認模型下載可用磁碟空間") from exc
        if free < required:
            raise ModelError(
                "模型下載空間不足；請保留至少 "
                f"{required} bytes 可用空間（包括安全預留）。"
            )

    def _verification_stamp_valid(self, key: str, path: Path) -> bool:
        """Quickly validate a previous full hash verification without reading GBs.

        The full verifier records the manifest hash plus the size and mtime of
        every manifested file. Any changed manifest or model file invalidates
        the cache and causes the next explicit use/verification to hash again.
        """
        stamp_path = path / VERIFICATION_STAMP_FILENAME
        manifest_path = path / "manifest.json"
        try:
            if stamp_path.is_symlink() or manifest_path.is_symlink():
                return False
            stamp = json.loads(stamp_path.read_text(encoding="utf-8"))
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            spec = self.spec(key)
            if (
                stamp.get("schema") != 1
                or stamp.get("model") != key
                or stamp.get("manifest_sha256") != sha256_file(manifest_path)
                or manifest.get("model") != key
                or manifest.get("source") != spec.source
                or (
                    spec.kind in {"huggingface", "huggingface_prefix"}
                    and manifest.get("revision") != spec.revision
                )
            ):
                return False
            raw_stamped = stamp.get("files")
            manifest_entries = _manifest_file_entries(manifest)
            if not isinstance(raw_stamped, list):
                return False
            stamped: dict[str, dict[str, Any]] = {}
            for item in raw_stamped:
                if not isinstance(item, dict) or not isinstance(item.get("path"), str):
                    return False
                relative_text = str(item["path"])
                relative = PurePosixPath(relative_text)
                if relative.as_posix() != relative_text or relative_text in stamped:
                    return False
                stamped[relative_text] = item
            if set(stamped) != set(manifest_entries):
                return False
            actual_files = {
                candidate.relative_to(path).as_posix()
                for candidate in _files_for_manifest(path)
            }
            if actual_files != set(manifest_entries):
                return False
            for relative_text, entry in manifest_entries.items():
                relative = PurePosixPath(relative_text)
                candidate = path.joinpath(*relative.parts)
                if candidate.is_symlink() or not candidate.is_file():
                    return False
                actual = candidate.stat(follow_symlinks=False)
                cached = stamped.get(relative.as_posix())
                if not isinstance(cached, dict):
                    return False
                if (
                    actual.st_size != int(entry.get("size", -1))
                    or actual.st_size != int(cached.get("size", -1))
                    or actual.st_mtime_ns != int(cached.get("mtime_ns", -1))
                    or actual.st_ctime_ns != int(cached.get("ctime_ns", -1))
                    or actual.st_dev != int(cached.get("device", -1))
                    or actual.st_ino != int(cached.get("inode", -1))
                ):
                    return False
            for candidate in path.rglob("*"):
                relative = candidate.relative_to(path)
                if candidate.is_symlink() and not (relative.parts and relative.parts[0] == ".cache"):
                    return False
            return True
        except (OSError, ValueError, TypeError, json.JSONDecodeError, ModelError):
            return False

    def _verification_identity(self, key: str, path: Path) -> tuple[Any, ...] | None:
        if not self._verification_stamp_valid(key, path):
            return None
        try:
            stamp = path.joinpath(VERIFICATION_STAMP_FILENAME).stat(follow_symlinks=False)
            manifest = path.joinpath("manifest.json").stat(follow_symlinks=False)
            return (
                stamp.st_dev,
                stamp.st_ino,
                stamp.st_size,
                stamp.st_mtime_ns,
                stamp.st_ctime_ns,
                manifest.st_dev,
                manifest.st_ino,
                manifest.st_size,
                manifest.st_mtime_ns,
                manifest.st_ctime_ns,
            )
        except OSError:
            return None

    def _write_verification_stamp(self, key: str, path: Path, manifest: dict[str, Any]) -> None:
        files = []
        for relative_text in _manifest_file_entries(manifest):
            relative = PurePosixPath(relative_text)
            candidate = path.joinpath(*relative.parts)
            if candidate.is_symlink():
                raise ModelError(f"不允許 symlink：{relative}")
            actual = candidate.stat(follow_symlinks=False)
            files.append(
                {
                    "path": relative.as_posix(),
                    "size": actual.st_size,
                    "mtime_ns": actual.st_mtime_ns,
                    "ctime_ns": actual.st_ctime_ns,
                    "device": actual.st_dev,
                    "inode": actual.st_ino,
                }
            )
        _atomic_json(
            path / VERIFICATION_STAMP_FILENAME,
            {
                "schema": 1,
                "model": key,
                "manifest_sha256": sha256_file(path / "manifest.json"),
                "verified_at_unix": time.time(),
                "files": files,
            },
        )

    def status(self, key: str | None = None) -> dict[str, Any]:
        keys = [key] if key else list(MODEL_REGISTRY)
        values = []
        for model_key in keys:
            spec = self.spec(model_key)
            path = self.path_for(model_key)
            ui = MODEL_UI[model_key]
            installed = path.is_dir() and (path / "manifest.json").is_file()
            identity = self._verification_identity(model_key, path) if installed else None
            previous_identity = self._verified.get(model_key)
            identity_changed = previous_identity is not None and previous_identity != identity
            verified_this_session = previous_identity is not None and previous_identity == identity
            verified_cached = identity is not None and not identity_changed
            verified = verified_cached
            actual_bytes = _directory_bytes(path)
            partial_bytes = actual_bytes
            if spec.kind in {"huggingface", "huggingface_prefix"}:
                partial_bytes += _directory_bytes(self.downloads / spec.directory)
            elif spec.archive:
                partial = (self.downloads / spec.archive).with_suffix(Path(spec.archive).suffix + ".part")
                if partial.is_file():
                    partial_bytes = partial.stat().st_size
            expected_bytes = int(ui["size_bytes"])
            download_progress = (
                1.0
                if installed
                else min(0.999, partial_bytes / expected_bytes)
                if expected_bytes and partial_bytes
                else 0.0
            )
            values.append(
                {
                    **asdict(spec),
                    "id": model_key,
                    "name": ui["name"],
                    "display_name": ui["display_name"],
                    "size_bytes": expected_bytes,
                    "installed": installed,
                    "verified": verified,
                    "path": str(path),
                    "download_progress": download_progress,
                    "is_required": bool(ui["is_required"]),
                    "downloaded": installed,
                    "verified_this_session": verified_this_session,
                    "verification_cached": verified_cached,
                    "bytes": actual_bytes,
                    **(
                        {
                            "runtime_path": str(
                                _primary_runtime_path(self.path_for(QWEN_PRIMARY_ID))
                            ),
                            "runtime_installed": (
                                _primary_runtime_path(self.path_for(QWEN_PRIMARY_ID))
                                / "manifest.json"
                            ).is_file(),
                            "runtime_bytes": _directory_bytes(
                                _primary_runtime_path(self.path_for(QWEN_PRIMARY_ID))
                            ),
                        }
                        if model_key == QWEN_PRIMARY_ID
                        else {}
                    ),
                }
            )
        return {"models": values}

    def require_local(self, key: str, *, verify: bool = True) -> Path:
        path = self.path_for(key)
        if not path.is_dir():
            raise ModelError(f"模型未下載：{key}")
        if verify:
            identity = self._verification_identity(key, path)
            previous_identity = self._verified.get(key)
            if identity is not None and (previous_identity is None or previous_identity == identity):
                self._verified[key] = identity
            else:
                self.verify(key)
        return path

    def verify(self, key: str) -> dict[str, Any]:
        path = self.require_local(key, verify=False)
        manifest = verify_manifest(path)
        spec = self.spec(key)
        if (
            manifest.get("model") != key
            or manifest.get("source") != spec.source
            or (
                spec.kind in {"huggingface", "huggingface_prefix"}
                and manifest.get("revision") != spec.revision
            )
        ):
            raise ModelError("模型 manifest source／revision 同 App 固定版本不符；請重新下載")
        if spec.kind == "sherpa":
            if not (path / "model.int8.onnx").is_file() or not (path / "tokens.txt").is_file():
                raise ModelError("sherpa 模型缺少 model.int8.onnx 或 tokens.txt")
        elif spec.kind == "whisper":
            if not spec.archive or not spec.sha256:
                raise ModelError("Whisper 模型規格不完整")
            model_file = path / spec.archive
            if not model_file.is_file():
                raise ModelError(f"Whisper 模型缺少 {spec.archive}")
            expected_size = int(MODEL_UI[key]["size_bytes"])
            if model_file.stat().st_size != expected_size:
                raise ModelError("Whisper 模型大小不符")
            model_entry = next(
                (
                    entry
                    for entry in manifest.get("files", [])
                    if entry.get("path") == spec.archive
                ),
                None,
            )
            if not isinstance(model_entry, dict) or model_entry.get("sha256") != spec.sha256:
                raise ModelError("Whisper 模型 SHA-256 不符")
        elif spec.kind == "speaker_segmentation":
            if not (path / "model.onnx").is_file():
                raise ModelError("speaker segmentation 模型缺少 model.onnx")
        elif spec.kind == "speaker_embedding":
            model_file = path / SPEAKER_EMBEDDING_FILENAME
            if not model_file.is_file() or model_file.stat().st_size != SPEAKER_EMBEDDING_BYTES:
                raise ModelError("3D-Speaker embedding 模型大小不符")
            model_entry = next(
                (entry for entry in manifest.get("files", []) if entry.get("path") == SPEAKER_EMBEDDING_FILENAME),
                None,
            )
            if not isinstance(model_entry, dict) or model_entry.get("sha256") != SPEAKER_EMBEDDING_SHA256:
                raise ModelError("3D-Speaker embedding SHA-256 不符")
        elif spec.kind == "huggingface_prefix":
            if key != SORTFORMER_COREML_ID or spec.prefix != SORTFORMER_COREML_PREFIX:
                raise ModelError("prefix-restricted CoreML 模型規格無效")
            entries = _manifest_file_entries(manifest)
            expected = SORTFORMER_COREML_FILES
            if set(entries) != set(expected):
                raise ModelError("Sortformer manifest file set 同固定版本不符")
            for relative, pinned in expected.items():
                entry = entries[relative]
                if (
                    int(entry.get("size", -1)) != int(pinned["size"])
                    or entry.get("sha256") != pinned["sha256"]
                ):
                    raise ModelError(f"Sortformer 固定檔案 hash／大小不符：{relative}")
            bundle = path.joinpath(*PurePosixPath(SORTFORMER_COREML_BUNDLE).parts)
            if bundle.is_symlink() or not bundle.is_dir():
                raise ModelError("Sortformer compiled CoreML bundle 缺失")
            if sum(int(item["size"]) for item in expected.values()) != SORTFORMER_COREML_BYTES:
                raise ModelError("Sortformer 固定模型大小規格錯誤")
        elif not (path / "config.json").is_file() or not list(path.glob("*.safetensors")):
            raise ModelError("Qwen 模型缺少 config.json 或 safetensors")
        self._write_verification_stamp(key, path, manifest)
        identity = self._verification_identity(key, path)
        if identity is None:
            raise ModelError("模型 verification stamp 寫入後驗證失敗")
        self._verified[key] = identity
        return {"ok": True, "model": key, "path": str(path), "manifest": manifest}

    def delete(self, key: str) -> dict[str, Any]:
        spec = self.spec(key)
        moved = []
        paths = [self.path_for(key)]
        if key == QWEN_PRIMARY_ID:
            # This directory is derived only from the pinned source checkpoint.
            # Re-download/delete must remove both generations together so a
            # stale Q8 runtime can never survive a source revision change.
            paths.append(_primary_runtime_path(self.path_for(key)))
        if spec.kind in {"huggingface", "huggingface_prefix"}:
            paths.append(self.downloads / spec.directory)
        elif spec.archive:
            paths.append(self.downloads / spec.archive)
            paths.append((self.downloads / spec.archive).with_suffix(Path(spec.archive).suffix + ".part"))
        for path in paths:
            if path.exists() or path.is_symlink():
                destination = move_to_trash(path)
                if destination:
                    moved.append(str(destination))
        self._verified.pop(key, None)
        return {"model": key, "moved_to_trash": moved}

    def download(
        self,
        key: str,
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
        redownload: bool = False,
    ) -> dict[str, Any]:
        spec = self.spec(key)
        with self._lock:
            if not redownload and (self.path_for(key) / "manifest.json").is_file():
                # A cancelled/interrupted download may leave a manifest behind
                # after its payload has been moved aside.  Treat that as a
                # failed install, preserve it in Trash for inspection, and
                # allow the resumable download to recover instead of trapping
                # the user in a permanent verification loop.
                try:
                    return self.verify(key)
                except ModelError:
                    move_to_trash(self.path_for(key))
            self._ensure_download_space(spec)
            if redownload:
                self.delete(key)
            if spec.kind in {"sherpa", "whisper", "speaker_segmentation", "speaker_embedding"} and self.path_for(key).exists():
                move_to_trash(self.path_for(key))
            if spec.kind in {"huggingface", "huggingface_prefix"}:
                self._download_huggingface(spec, progress=progress, cancelled=cancelled)
            elif spec.kind == "sherpa":
                self._download_sherpa(spec, progress=progress, cancelled=cancelled)
            elif spec.kind == "whisper":
                self._download_whisper(spec, progress=progress, cancelled=cancelled)
            elif spec.kind == "speaker_segmentation":
                self._download_speaker_segmentation(spec, progress=progress, cancelled=cancelled)
            elif spec.kind == "speaker_embedding":
                self._download_speaker_embedding(spec, progress=progress, cancelled=cancelled)
            else:
                raise ModelError(f"未知模型種類：{spec.kind}")
            return self.verify(key)

    def _download_whisper(
        self, spec: ModelSpec, *, progress: Progress | None, cancelled: Cancelled | None
    ) -> None:
        assert spec.archive and spec.sha256
        target = self.path_for(spec.key)
        target.mkdir(parents=True, exist_ok=False)
        destination = target / spec.archive
        partial = (self.downloads / spec.archive).with_suffix(Path(spec.archive).suffix + ".part")
        expected_size = int(MODEL_UI[spec.key]["size_bytes"])
        try:
            self._resumable_url_download(
                spec.source,
                partial,
                final=destination,
                progress=progress,
                cancelled=cancelled,
                model=spec.key,
                expected_size=expected_size,
                expected_sha256=spec.sha256,
            )
            _emit(progress, phase="hash", model=spec.key, progress=0.0)
            build_manifest(target, spec=spec, revision=spec.sha256)
            _emit(
                progress,
                phase="download",
                model=spec.key,
                bytes_downloaded=expected_size,
                bytes_total=expected_size,
                progress=1.0,
            )
        except BaseException:
            if target.exists():
                move_to_trash(target)
            raise

    def _download_huggingface(
        self, spec: ModelSpec, *, progress: Progress | None, cancelled: Cancelled | None
    ) -> None:
        target = self.path_for(spec.key)
        target.mkdir(parents=True, exist_ok=True)
        if not spec.revision or len(spec.revision) != 40:
            raise ModelError(f"Hugging Face 模型未固定 immutable revision：{spec.key}")
        metadata_url = (
            "https://huggingface.co/api/models/"
            + urllib.parse.quote(spec.source, safe="/")
            + "/revision/"
            + urllib.parse.quote(spec.revision, safe="")
            + "?blobs=true"
        )
        metadata_request = urllib.request.Request(
            metadata_url,
            headers={
                "Accept": "application/json",
                "User-Agent": "CantoneseTranscriptStudio/0.5",
            },
        )
        try:
            with urllib.request.urlopen(metadata_request, timeout=30) as response:
                if response.getcode() != 200:
                    raise ModelError(
                        f"Hugging Face metadata HTTP {response.getcode()}：{spec.key}"
                    )
                raw_metadata = response.read(HF_METADATA_MAX_BYTES + 1)
        except (OSError, urllib.error.URLError) as exc:
            raise ModelError(f"下載 Hugging Face metadata 失敗：{spec.key}") from exc
        if len(raw_metadata) > HF_METADATA_MAX_BYTES:
            raise ModelError(f"Hugging Face metadata 超出安全上限：{spec.key}")
        try:
            info = json.loads(raw_metadata)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ModelError(f"Hugging Face metadata JSON 無效：{spec.key}") from exc
        if not isinstance(info, dict) or str(info.get("sha")) != spec.revision:
            raise ModelError(
                "Hugging Face revision 回應不符："
                f"預期 {spec.revision}，收到 {info.get('sha') if isinstance(info, dict) else None}"
            )
        siblings = info.get("siblings")
        if not isinstance(siblings, list):
            raise ModelError(f"Hugging Face metadata 缺少 siblings：{spec.key}")
        allowed: list[tuple[str, int, str | None, str | None]] = []
        total = 0
        prefix_files: set[str] = set()
        for sibling in siblings:
            if not isinstance(sibling, dict):
                raise ModelError(f"Hugging Face sibling metadata 無效：{spec.key}")
            name = sibling.get("rfilename")
            if not isinstance(name, str):
                raise ModelError(f"Hugging Face sibling 缺少檔名：{spec.key}")
            if spec.kind == "huggingface_prefix":
                if not spec.prefix or not name.startswith(spec.prefix):
                    continue
            elif not any(Path(name).match(pattern) for pattern in HF_ALLOW_PATTERNS):
                continue
            relative = PurePosixPath(name)
            if (
                relative.is_absolute()
                or ".." in relative.parts
                or "." in relative.parts
                or relative.as_posix() != name
                or "\\" in name
                or "\0" in name
            ):
                raise ModelError(f"Hugging Face model 有非法 path：{name}")
            size = sibling.get("size")
            lfs = sibling.get("lfs")
            if size is None and lfs:
                size = lfs.get("size") if isinstance(lfs, dict) else None
            if size is None:
                raise ModelError(f"Hugging Face metadata 缺少檔案大小：{name}")
            lfs_sha = None
            git_blob_sha1 = None
            if lfs:
                lfs_sha = lfs.get("sha256") if isinstance(lfs, dict) else None
                if not isinstance(lfs_sha, str) or len(lfs_sha) != 64:
                    raise ModelError(f"Hugging Face LFS metadata 缺少 SHA-256：{name}")
            else:
                git_blob_sha1 = sibling.get("blobId")
                if (
                    not isinstance(git_blob_sha1, str)
                    or len(git_blob_sha1) != 40
                    or any(character not in "0123456789abcdef" for character in git_blob_sha1.lower())
                ):
                    raise ModelError(f"Hugging Face blob metadata 缺少 Git SHA-1：{name}")
            if spec.kind == "huggingface_prefix":
                pinned = SORTFORMER_COREML_FILES.get(name)
                if pinned is None:
                    raise ModelError(f"Sortformer snapshot 有未預期 sibling：{name}")
                if int(size) != int(pinned["size"]):
                    raise ModelError(f"Sortformer metadata 大小不符：{name}")
                remote_kind = str(pinned["remote_hash_kind"])
                remote_hash = str(pinned["remote_hash"])
                if remote_kind == "lfs_sha256":
                    if lfs_sha != remote_hash or git_blob_sha1 is not None:
                        raise ModelError(f"Sortformer metadata LFS hash 不符：{name}")
                elif remote_kind == "git_blob_sha1":
                    if git_blob_sha1 != remote_hash or lfs_sha is not None:
                        raise ModelError(f"Sortformer metadata Git blob hash 不符：{name}")
                else:
                    raise ModelError(f"Sortformer 固定 remote hash kind 無效：{name}")
                prefix_files.add(name)
            allowed.append((name, int(size), lfs_sha, git_blob_sha1))
            total += int(size)
        if not allowed:
            raise ModelError(f"Hugging Face snapshot 無可下載檔案：{spec.source}")
        if spec.kind == "huggingface_prefix":
            missing = sorted(set(SORTFORMER_COREML_FILES) - prefix_files)
            if missing:
                raise ModelError(f"Sortformer snapshot 缺少固定 sibling：{missing[0]}")
            if total != SORTFORMER_COREML_BYTES:
                raise ModelError("Sortformer snapshot 總大小同固定版本不符")

        completed = 0
        staging_root = self.downloads / spec.directory
        for name, expected_size, expected_sha, expected_git_blob_sha1 in allowed:
            if cancelled and cancelled():
                raise DownloadCancelled("已取消模型下載；partial 保留供續傳")
            relative = PurePosixPath(name)
            destination = target.joinpath(*relative.parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            if destination.is_file() and destination.stat().st_size == expected_size:
                sha_matches = expected_sha is None or sha256_file(destination) == expected_sha
                blob_matches = (
                    expected_git_blob_sha1 is None
                    or git_blob_sha1_file(destination) == expected_git_blob_sha1
                )
                if sha_matches and blob_matches:
                    completed += expected_size
                    _emit(
                        progress,
                        phase="download",
                        model=spec.key,
                        file=name,
                        bytes_downloaded=completed,
                        bytes_total=total,
                        progress=completed / total,
                    )
                    continue
            if destination.exists() or destination.is_symlink():
                move_to_trash(destination)

            partial = staging_root.joinpath(*relative.parts).with_name(relative.name + ".part")
            url = (
                "https://huggingface.co/"
                + urllib.parse.quote(spec.source, safe="/")
                + "/resolve/"
                + urllib.parse.quote(spec.revision, safe="")
                + "/"
                + urllib.parse.quote(name, safe="/")
            )

            def file_progress(event: dict[str, Any], *, base: int = completed, file_name: str = name) -> None:
                file_bytes = int(event.get("bytes_downloaded", 0))
                aggregate = min(total, base + file_bytes)
                payload = dict(event)
                payload.update(
                    {
                        "model": spec.key,
                        "file": file_name,
                        "bytes_downloaded": aggregate,
                        "bytes_total": total,
                        "progress": aggregate / total if total else None,
                    }
                )
                _emit(progress, **payload)

            self._resumable_url_download(
                url,
                partial,
                final=destination,
                progress=file_progress,
                cancelled=cancelled,
                model=spec.key,
                expected_size=expected_size,
                expected_sha256=expected_sha,
                expected_git_blob_sha1=expected_git_blob_sha1,
            )
            completed += expected_size

        _emit(progress, phase="hash", model=spec.key, progress=0.0)
        build_manifest(target, spec=spec, revision=spec.revision)
        _emit(progress, phase="download", model=spec.key, bytes_downloaded=total, bytes_total=total, progress=1.0)

    def _download_sherpa(
        self, spec: ModelSpec, *, progress: Progress | None, cancelled: Cancelled | None
    ) -> None:
        assert spec.archive and spec.sha256
        archive = self.downloads / spec.archive
        partial = archive.with_suffix(archive.suffix + ".part")
        if archive.is_file() and sha256_file(archive) != spec.sha256:
            move_to_trash(archive)
        if not archive.is_file():
            self._resumable_url_download(
                spec.source,
                partial,
                final=archive,
                progress=progress,
                cancelled=cancelled,
                model=spec.key,
                expected_size=int(MODEL_UI[spec.key]["size_bytes"]),
                expected_sha256=spec.sha256,
            )
        actual = sha256_file(archive)
        if actual != spec.sha256:
            moved = move_to_trash(archive)
            raise ModelError(f"sherpa archive SHA-256 不符；已移去 Trash：{moved}")

        extract_parent = Path(tempfile.mkdtemp(prefix=".extract-", dir=self.paths.models))
        payload = extract_parent / "payload"
        try:
            _safe_extract_tar(archive, payload)
            children = [item for item in payload.iterdir()]
            if len(children) != 1 or not children[0].is_dir():
                raise ModelError("sherpa archive 頂層 layout 不符")
            extracted = children[0]
            if extracted.name != spec.directory:
                raise ModelError(f"sherpa archive 目錄名不符：{extracted.name}")
            if not (extracted / "model.int8.onnx").is_file() or not (extracted / "tokens.txt").is_file():
                raise ModelError("sherpa archive 缺少 model.int8.onnx 或 tokens.txt")
            target = self.path_for(spec.key)
            os.replace(extracted, target)
            build_manifest(target, spec=spec, revision=spec.sha256)
            move_to_trash(extract_parent)
        except BaseException:
            move_to_trash(extract_parent)
            raise

    def _download_speaker_segmentation(
        self, spec: ModelSpec, *, progress: Progress | None, cancelled: Cancelled | None
    ) -> None:
        assert spec.archive and spec.sha256
        archive = self.downloads / spec.archive
        partial = archive.with_suffix(archive.suffix + ".part")
        if archive.is_file() and sha256_file(archive) != spec.sha256:
            move_to_trash(archive)
        if not archive.is_file():
            self._resumable_url_download(
                spec.source, partial, final=archive, progress=progress, cancelled=cancelled,
                model=spec.key, expected_size=SPEAKER_SEGMENTATION_BYTES,
                expected_sha256=spec.sha256,
            )
        if sha256_file(archive) != spec.sha256:
            moved = move_to_trash(archive)
            raise ModelError(f"speaker segmentation archive SHA-256 不符；已移去 Trash：{moved}")
        extract_parent = Path(tempfile.mkdtemp(prefix=".extract-speaker-", dir=self.paths.models))
        payload = extract_parent / "payload"
        try:
            _safe_extract_tar(archive, payload)
            children = [item for item in payload.iterdir()]
            if len(children) != 1 or children[0].name != spec.directory:
                raise ModelError("speaker segmentation archive layout 不符")
            extracted = children[0]
            if not (extracted / "model.onnx").is_file():
                raise ModelError("speaker segmentation archive 缺少 model.onnx")
            target = self.path_for(spec.key)
            os.replace(extracted, target)
            build_manifest(target, spec=spec, revision=spec.sha256)
            move_to_trash(extract_parent)
        except BaseException:
            move_to_trash(extract_parent)
            raise

    def _download_speaker_embedding(
        self, spec: ModelSpec, *, progress: Progress | None, cancelled: Cancelled | None
    ) -> None:
        assert spec.archive and spec.sha256
        target = self.path_for(spec.key)
        target.mkdir(parents=True, exist_ok=False)
        destination = target / spec.archive
        partial = (self.downloads / spec.archive).with_suffix(Path(spec.archive).suffix + ".part")
        self._resumable_url_download(
            spec.source, partial, final=destination, progress=progress, cancelled=cancelled,
            model=spec.key, expected_size=SPEAKER_EMBEDDING_BYTES,
            expected_sha256=spec.sha256,
        )
        build_manifest(target, spec=spec, revision=spec.sha256)

    @staticmethod
    def _resumable_url_download(
        url: str,
        partial: Path,
        *,
        final: Path,
        progress: Progress | None,
        cancelled: Cancelled | None,
        model: str,
        expected_size: int | None = None,
        expected_sha256: str | None = None,
        expected_git_blob_sha1: str | None = None,
    ) -> None:
        partial.parent.mkdir(parents=True, exist_ok=True)
        try:
            initial = partial.stat(follow_symlinks=False)
        except FileNotFoundError:
            initial = None
        if initial is not None and not stat.S_ISREG(initial.st_mode):
            raise ModelError(f"partial download path 唔係安全 regular file：{partial}")
        partial_existed = initial is not None
        existing = initial.st_size if initial is not None else 0
        if expected_size is not None and existing > expected_size:
            move_to_trash(partial)
            partial_existed = False
            existing = 0
        if expected_size is not None and existing == expected_size:
            fd = _open_partial_fd(partial, expected_size=existing, create=False)
            try:
                sha_matches = (
                    expected_sha256 is None
                    or _hash_open_fd(fd, "sha256") == expected_sha256
                )
                blob_matches = (
                    expected_git_blob_sha1 is None
                    or _hash_open_fd(fd, "git-blob-sha1", git_blob_size=existing)
                    == expected_git_blob_sha1
                )
                if not sha_matches or not blob_matches:
                    if not _path_matches_fd(partial, fd):
                        raise ModelError(f"partial download file identity 已改變：{partial}")
                    move_to_trash(partial)
                    partial_existed = False
                    existing = 0
                else:
                    if not _path_matches_fd(partial, fd):
                        raise ModelError(f"partial download file identity 已改變：{partial}")
                    final.parent.mkdir(parents=True, exist_ok=True)
                    os.replace(partial, final)
                    if not _path_matches_fd(final, fd):
                        raise ModelError(f"下載檔案 atomic finalize identity 不符：{final}")
            finally:
                os.close(fd)
            if sha_matches and blob_matches:
                final.parent.mkdir(parents=True, exist_ok=True)
                _emit(
                    progress,
                    phase="download",
                    model=model,
                    bytes_downloaded=existing,
                    bytes_total=expected_size,
                    progress=1.0,
                )
                return
        headers = {"User-Agent": "CantoneseTranscriptStudio/0.1"}
        if existing:
            headers["Range"] = f"bytes={existing}-"
        request = urllib.request.Request(url, headers=headers)
        response = urllib.request.urlopen(request, timeout=60)
        status = getattr(response, "status", response.getcode())
        if existing and status != 206:
            response.close()
            move_to_trash(partial)
            existing = 0
            partial_existed = False
            request = urllib.request.Request(url, headers={"User-Agent": headers["User-Agent"]})
            response = urllib.request.urlopen(request, timeout=60)
            status = getattr(response, "status", response.getcode())
        if status not in {200, 206}:
            response.close()
            raise ModelError(f"模型下載 HTTP status 異常：{status}")
        content_range = response.headers.get("Content-Range", "")
        if existing and status == 206 and not content_range.startswith(f"bytes {existing}-"):
            response.close()
            raise ModelError(f"Range response 起點不符：expected={existing}, got={content_range}")
        if "/" in content_range:
            total = int(content_range.rsplit("/", 1)[1])
            if expected_size is not None and total != expected_size:
                response.close()
                raise ModelError(f"Range response 總大小不符：expected={expected_size}, got={total}")
        else:
            total = existing + int(response.headers.get("Content-Length", "0") or 0)
        if expected_size is not None:
            total = expected_size
        try:
            fd = _open_partial_fd(partial, expected_size=existing, create=not partial_existed)
        except BaseException:
            response.close()
            raise
        try:
            if not existing:
                os.ftruncate(fd, 0)
            os.lseek(fd, 0, os.SEEK_END)
            with response:
                downloaded = existing
                while True:
                    if cancelled and cancelled():
                        raise DownloadCancelled("已取消模型下載；partial 保留供續傳")
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    view = memoryview(block)
                    while view:
                        written = os.write(fd, view)
                        if written <= 0:  # pragma: no cover - OS write contract
                            raise ModelError(f"partial download write 失敗：{partial}")
                        view = view[written:]
                    downloaded += len(block)
                    _emit(
                        progress,
                        phase="download",
                        model=model,
                        bytes_downloaded=downloaded,
                        bytes_total=total,
                        progress=downloaded / total if total else None,
                    )
                os.fsync(fd)
            actual_size = os.fstat(fd).st_size
            if expected_size is not None and actual_size != expected_size:
                raise ModelError(
                    f"下載檔案大小不符：{model}；expected={expected_size}, actual={actual_size}"
                )
            if expected_sha256 is not None and _hash_open_fd(fd, "sha256") != expected_sha256:
                if not _path_matches_fd(partial, fd):
                    raise ModelError(f"partial download file identity 已改變：{partial}")
                moved = move_to_trash(partial)
                raise ModelError(f"下載檔案 SHA-256 不符；已移去 Trash：{moved}")
            if (
                expected_git_blob_sha1 is not None
                and _hash_open_fd(fd, "git-blob-sha1", git_blob_size=actual_size)
                != expected_git_blob_sha1
            ):
                if not _path_matches_fd(partial, fd):
                    raise ModelError(f"partial download file identity 已改變：{partial}")
                moved = move_to_trash(partial)
                raise ModelError(f"下載檔案 Git blob SHA-1 不符；已移去 Trash：{moved}")
            if not _path_matches_fd(partial, fd):
                raise ModelError(f"partial download file identity 已改變：{partial}")
            final.parent.mkdir(parents=True, exist_ok=True)
            os.replace(partial, final)
            if not _path_matches_fd(final, fd):
                raise ModelError(f"下載檔案 atomic finalize identity 不符：{final}")
        finally:
            os.close(fd)


def required_model_keys(settings: Any) -> tuple[str, ...]:
    primary = settings.fallback_model if settings.use_fallback else settings.primary_model
    if primary not in {QWEN_PRIMARY_ID, QWEN_FALLBACK_ID}:
        raise ModelError(f"primary model 唔支援：{primary}")
    if settings.verifier_model != SHERPA_MODEL_NAME:
        raise ModelError(f"verifier model 必須係 {SHERPA_MODEL_NAME}")
    required = [primary, SHERPA_MODEL_NAME]
    if bool(getattr(settings, "forced_alignment_enabled", True)):
        aligner = getattr(settings, "forced_aligner_model", QWEN_ALIGNER_ID)
        if aligner != QWEN_ALIGNER_ID:
            raise ModelError(f"Forced aligner 必須係 {QWEN_ALIGNER_ID}")
        required.append(QWEN_ALIGNER_ID)
    if bool(getattr(settings, "accuracy_mode", False)):
        whisper = getattr(settings, "whisper_model", WHISPER_LARGE_V3_ID)
        if whisper not in WHISPER_MODEL_IDS:
            raise ModelError("Whisper model 必須係 Large v3 或 Large v2")
        required.append(whisper)
    # Live captions are a first-class offline feature.  A small multilingual
    # Whisper model makes rolling draft captions responsive, while Large v3
    # supplies the Cantonese-aware final caption.  These are deliberately
    # separate from the optional batch Accuracy Mode setting above.
    required.extend((WHISPER_SMALL_ID, WHISPER_LARGE_V3_ID))
    if bool(getattr(settings, "speaker_diarization_enabled", False)):
        requested_speakers = getattr(settings, "speaker_num_speakers", None)
        if requested_speakers is not None and int(requested_speakers) > 4:
            required.append(SPEAKER_SEGMENTATION_ID)
        else:
            required.append(SORTFORMER_COREML_ID)
            # Sortformer is preferred for up to four speakers.  Keep the small
            # CPU segmentation model installed as an independent local
            # fallback so a Core ML runtime failure cannot sink the transcript.
            required.append(SPEAKER_SEGMENTATION_ID)
        # File diarization needs anonymous speaker embeddings.  Live captions
        # discover this model independently and degrade to captions without a
        # speaker label when it is absent; it must not block ordinary batches.
        required.append(SPEAKER_EMBEDDING_ID)
    return tuple(dict.fromkeys(required))


def download_required(
    manager: ModelManager,
    settings: Any,
    *,
    progress: Progress | None = None,
) -> dict[str, Any]:
    results = []
    for key in required_model_keys(settings):
        results.append(manager.download(key, progress=progress))
    return {"ok": True, "models": results}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m cts_backend.models")
    parser.add_argument("command", choices=("download-required", "status"))
    arguments = parser.parse_args(argv)
    paths = AppPaths.default().ensure()
    manager = ModelManager(paths)
    if arguments.command == "status":
        result = manager.status()
    else:
        from .settings import SettingsStore

        result = download_required(
            manager,
            SettingsStore(paths).get(),
            progress=lambda event: print(json.dumps(event, ensure_ascii=False), flush=True),
        )
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0


__all__ = [
    "MODEL_REGISTRY",
    "MODEL_UI",
    "ModelError",
    "ModelManager",
    "ModelSpec",
    "DownloadCancelled",
    "QWEN_PRIMARY_ID",
    "QWEN_PRIMARY_REVISION",
    "QWEN_FALLBACK_ID",
    "QWEN_FALLBACK_REVISION",
    "QWEN_ALIGNER_ID",
    "QWEN_ALIGNER_REVISION",
    "SHERPA_MODEL_NAME",
    "SHERPA_SHA256",
    "SHERPA_URL",
    "SENSEVOICE_YUE_MODEL_NAME",
    "SENSEVOICE_YUE_ARCHIVE_NAME",
    "SENSEVOICE_YUE_ARCHIVE_BYTES",
    "SENSEVOICE_YUE_SHA256",
    "SENSEVOICE_YUE_URL",
    "WHISPER_LARGE_V2_BYTES",
    "WHISPER_LARGE_V2_FILENAME",
    "WHISPER_LARGE_V2_ID",
    "WHISPER_LARGE_V2_SHA256",
    "WHISPER_LARGE_V2_URL",
    "WHISPER_LARGE_V3_BYTES",
    "WHISPER_LARGE_V3_FILENAME",
    "WHISPER_LARGE_V3_ID",
    "WHISPER_LARGE_V3_SHA256",
    "WHISPER_LARGE_V3_URL",
    "WHISPER_SMALL_BYTES",
    "WHISPER_SMALL_FILENAME",
    "WHISPER_SMALL_ID",
    "WHISPER_SMALL_SHA256",
    "WHISPER_SMALL_URL",
    "LIVE_WHISPER_MODEL_IDS",
    "WHISPER_MODEL_FILENAMES",
    "WHISPER_MODEL_IDS",
    "SPEAKER_SEGMENTATION_ID",
    "SPEAKER_EMBEDDING_ID",
    "SORTFORMER_COREML_ID",
    "SORTFORMER_COREML_REVISION",
    "SORTFORMER_COREML_PREFIX",
    "SORTFORMER_COREML_BUNDLE",
    "SORTFORMER_COREML_BYTES",
    "SORTFORMER_COREML_FILES",
    "build_manifest",
    "download_required",
    "move_to_trash",
    "sha256_file",
    "verify_manifest",
    "required_model_keys",
    "_safe_extract_tar",
]


if __name__ == "__main__":
    raise SystemExit(main())
