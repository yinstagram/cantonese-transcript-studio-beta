"""sherpa-onnx 1.13.4 offline WeNet CTC verifier."""

from __future__ import annotations

import gc
import multiprocessing
import queue
import time
import wave
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Callable, Iterable

from .types import ASRCancelled, AudioChunk, TranscriptSegment, VerifierToken

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]
DEFAULT_DECODE_TIMEOUT_SECONDS = 8 * 60 * 60.0
DEFAULT_NO_PROGRESS_TIMEOUT_SECONDS = 20 * 60.0


def _read_pcm16_mono(path: Path) -> tuple[Any, int]:
    try:
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("runtime 未安裝 numpy") from exc
    with wave.open(str(path), "rb") as source:
        channels = source.getnchannels()
        width = source.getsampwidth()
        sample_rate = source.getframerate()
        frames = source.readframes(source.getnframes())
    if channels != 1 or width != 2 or sample_rate != 16000:
        raise ValueError(f"sherpa chunk 必須係 16kHz mono PCM16 WAV：{path}")
    return np.frombuffer(frames, dtype="<i2").astype(np.float32) / 32768.0, sample_rate


def _decode_in_spawned_child(
    model_path: str,
    tokens_path: str,
    chunks: tuple[dict[str, Any], ...],
    result_queue: Any,
) -> None:
    """Load sherpa once in a disposable process and stream bounded results."""

    recognizer: Any | None = None
    try:
        import sherpa_onnx

        recognizer = sherpa_onnx.OfflineRecognizer.from_wenet_ctc(
            model=model_path,
            tokens=tokens_path,
            num_threads=2,
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
        )
        for index, payload in enumerate(chunks):
            samples, sample_rate = _read_pcm16_mono(Path(str(payload["path"])))
            stream = recognizer.create_stream()
            stream.accept_waveform(sample_rate, samples)
            recognizer.decode_stream(stream)
            result = stream.result
            result_queue.put(
                {
                    "kind": "result",
                    "index": index,
                    "text": str(getattr(result, "text", ""))[:2_000_000],
                    "tokens": [
                        str(item)
                        for item in list(getattr(result, "tokens", []) or [])[:200_000]
                    ],
                    "timestamps": [
                        float(item)
                        for item in list(getattr(result, "timestamps", []) or [])[:200_000]
                    ],
                    "log_probabilities": [
                        float(item)
                        for item in list(getattr(result, "ys_log_probs", []) or [])[:200_000]
                    ],
                }
            )
            del samples, stream, result
        result_queue.put({"kind": "done", "count": len(chunks)})
    except BaseException as exc:
        try:
            result_queue.put(
                {
                    "kind": "error",
                    "message": f"{type(exc).__name__}: {str(exc)[:500]}",
                }
            )
        except BaseException:
            pass
    finally:
        if recognizer is not None:
            del recognizer
        gc.collect()


def _terminate_spawned_process(process: Any, *, grace_seconds: float = 0.5) -> None:
    """Bound verifier shutdown so cancellation cannot stall the queue.

    The verifier process owns no user-visible output and every completed chunk
    is already checkpointed by the parent.  A short TERM window is therefore
    sufficient; if native teardown is slow we prefer a prompt KILL over making
    the UI wait several seconds (or paying the grace period twice from
    ``except`` and ``finally``).
    """

    if not process.is_alive():
        process.join(timeout=0.1)
        return
    process.terminate()
    process.join(timeout=max(0.0, grace_seconds))
    if process.is_alive():
        process.kill()
        process.join(timeout=0.5)


class SherpaYueVerifier:
    def __init__(
        self,
        model_dir: Path,
        *,
        num_threads: int = 2,
        recognizer_factory: Callable[..., Any] | None = None,
        decode_timeout_seconds: float = DEFAULT_DECODE_TIMEOUT_SECONDS,
        no_progress_timeout_seconds: float = DEFAULT_NO_PROGRESS_TIMEOUT_SECONDS,
        child_target: Callable[..., None] = _decode_in_spawned_child,
    ) -> None:
        self.model_dir = Path(model_dir)
        if num_threads != 2:
            raise ValueError("M1 verifier 固定 num_threads=2")
        if not 0.05 <= float(decode_timeout_seconds) <= 24 * 60 * 60:
            raise ValueError("sherpa decode timeout 必須係 0.05 秒至 24 小時")
        if not 0.05 <= float(no_progress_timeout_seconds) <= 24 * 60 * 60:
            raise ValueError("sherpa no-progress timeout 必須係 0.05 秒至 24 小時")
        self.num_threads = num_threads
        self._recognizer_factory = recognizer_factory
        self.decode_timeout_seconds = float(decode_timeout_seconds)
        self.no_progress_timeout_seconds = float(no_progress_timeout_seconds)
        self._child_target = child_target

    def _validate_local(self) -> tuple[Path, Path]:
        model = self.model_dir / "model.int8.onnx"
        tokens = self.model_dir / "tokens.txt"
        if not model.is_file() or not tokens.is_file():
            raise FileNotFoundError(f"sherpa local model 不完整：{self.model_dir}")
        return model, tokens

    @staticmethod
    def _segment_from_result(
        chunk: AudioChunk,
        raw: Mapping[str, Any],
        *,
        is_last: bool,
        model_dir: Path,
    ) -> TranscriptSegment:
        raw_tokens = list(raw.get("tokens", []) or [])
        raw_times = list(raw.get("timestamps", []) or [])
        raw_probs = list(raw.get("log_probabilities", []) or [])
        token_items: list[VerifierToken] = []
        for token_index, (token, relative) in enumerate(zip(raw_tokens, raw_times)):
            probability = raw_probs[token_index] if token_index < len(raw_probs) else None
            absolute = chunk.start + float(relative)
            within_end = (
                absolute <= chunk.transcript_end
                if is_last
                else absolute < chunk.transcript_end
            )
            if chunk.transcript_start <= absolute and within_end:
                token_items.append(
                    VerifierToken(
                        token=str(token),
                        timestamp=absolute,
                        log_probability=(
                            float(probability) if probability is not None else None
                        ),
                    )
                )
        if len(token_items) == len(raw_tokens):
            text = str(raw.get("text", ""))
        elif token_items:
            text = "".join(
                token.token.replace("▁", " ") for token in token_items
            ).strip()
        else:
            text = str(raw.get("text", ""))
        return TranscriptSegment(
            id=chunk.id,
            start=chunk.transcript_start,
            end=chunk.transcript_end,
            text=text,
            source="verifier",
            tokens=token_items,
            metadata={
                "model_path": str(model_dir),
                "confidence_available": bool(raw_probs),
            },
        )

    def verify_chunks(
        self,
        chunks: Iterable[AudioChunk | dict[str, Any] | Any],
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> list[TranscriptSegment]:
        model, tokens_path = self._validate_local()
        items = [AudioChunk.coerce(item) for item in chunks]
        if not items:
            return []
        if self._recognizer_factory is not None:
            return self._verify_in_process_for_injected_runtime(
                model,
                tokens_path,
                items,
                progress=progress,
                cancelled=cancelled,
            )
        return self._verify_in_spawned_process(
            model,
            tokens_path,
            items,
            progress=progress,
            cancelled=cancelled,
        )

    def _verify_in_spawned_process(
        self,
        model: Path,
        tokens_path: Path,
        items: list[AudioChunk],
        *,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> list[TranscriptSegment]:
        context = multiprocessing.get_context("spawn")
        result_queue = context.Queue(maxsize=2)
        payload = tuple({"path": str(chunk.path)} for chunk in items)
        process = context.Process(
            target=self._child_target,
            args=(str(model), str(tokens_path), payload, result_queue),
            name="cts-sherpa-verifier",
            daemon=False,
        )
        started = time.monotonic()
        last_progress = started
        received: dict[int, Mapping[str, Any]] = {}
        done = False
        process.start()
        try:
            while not done:
                now = time.monotonic()
                if cancelled and cancelled():
                    raise ASRCancelled("已取消 verifier transcription")
                if now - started >= self.decode_timeout_seconds:
                    raise RuntimeError("sherpa verifier decode deadline exceeded")
                if now - last_progress >= self.no_progress_timeout_seconds:
                    raise RuntimeError("sherpa verifier no-progress deadline exceeded")
                try:
                    message = result_queue.get(timeout=0.1)
                except queue.Empty:
                    if not process.is_alive():
                        process.join(timeout=0.1)
                        if process.exitcode not in {0, None}:
                            raise RuntimeError(
                                f"sherpa verifier child exited ({process.exitcode})"
                            )
                        if len(received) != len(items):
                            raise RuntimeError(
                                "sherpa verifier child returned incomplete results"
                            )
                        done = True
                    continue
                if not isinstance(message, Mapping):
                    raise RuntimeError("sherpa verifier child returned invalid data")
                kind = message.get("kind")
                if kind == "error":
                    raise RuntimeError(
                        f"sherpa verifier child failed: {message.get('message', '')}"
                    )
                if kind == "done":
                    done = True
                    continue
                if kind != "result" or isinstance(message.get("index"), bool):
                    raise RuntimeError("sherpa verifier child returned invalid data")
                index = int(message["index"])
                if not 0 <= index < len(items) or index in received:
                    raise RuntimeError(
                        "sherpa verifier child returned invalid result index"
                    )
                received[index] = message
                last_progress = time.monotonic()
                if progress:
                    processed = sum(
                        items[item_index].duration for item_index in received
                    )
                    total_duration = sum(chunk.duration for chunk in items)
                    progress(
                        {
                            "phase": "verifier",
                            "chunk_id": items[index].id,
                            "chunk_index": index + 1,
                            "chunk_total": len(items),
                            "progress": (
                                processed / total_duration if total_duration else 1.0
                            ),
                        }
                    )
            process.join(timeout=1.0)
            if len(received) != len(items):
                raise RuntimeError("sherpa verifier child returned incomplete results")
            return [
                self._segment_from_result(
                    chunk,
                    received[index],
                    is_last=index == len(items) - 1,
                    model_dir=self.model_dir,
                )
                for index, chunk in enumerate(items)
            ]
        except BaseException:
            _terminate_spawned_process(process)
            raise
        finally:
            if process.is_alive():
                _terminate_spawned_process(process)
            result_queue.cancel_join_thread()
            result_queue.close()

    def _verify_in_process_for_injected_runtime(
        self,
        model: Path,
        tokens_path: Path,
        items: list[AudioChunk],
        *,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> list[TranscriptSegment]:
        assert self._recognizer_factory is not None
        recognizer = self._recognizer_factory(
            model=str(model),
            tokens=str(tokens_path),
            num_threads=2,
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
        )
        output: list[TranscriptSegment] = []
        total_duration = sum(chunk.duration for chunk in items)
        processed = 0.0
        try:
            for index, chunk in enumerate(items, start=1):
                if cancelled and cancelled():
                    raise ASRCancelled("已取消 verifier transcription")
                samples, sample_rate = _read_pcm16_mono(chunk.path)
                stream = recognizer.create_stream()
                stream.accept_waveform(sample_rate, samples)
                recognizer.decode_stream(stream)
                result = stream.result
                raw = {
                    "text": str(getattr(result, "text", "")),
                    "tokens": list(getattr(result, "tokens", []) or []),
                    "timestamps": list(getattr(result, "timestamps", []) or []),
                    "log_probabilities": list(
                        getattr(result, "ys_log_probs", []) or []
                    ),
                }
                output.append(
                    self._segment_from_result(
                        chunk,
                        raw,
                        is_last=index == len(items),
                        model_dir=self.model_dir,
                    )
                )
                processed += chunk.duration
                if progress:
                    progress(
                        {
                            "phase": "verifier",
                            "chunk_id": chunk.id,
                            "chunk_index": index,
                            "chunk_total": len(items),
                            "progress": (
                                processed / total_duration if total_duration else 1.0
                            ),
                        }
                    )
                del samples, stream, result
            return output
        finally:
            del recognizer
            gc.collect()
