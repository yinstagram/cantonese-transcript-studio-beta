"""Safe, local-first YouTube import foundations.

The foundation validates public YouTube targets and builds inert argv tuples;
the worker-facing service executes them only after explicit rights consent.
Normal ASR remains offline and tests inject an executor instead of networking.
"""

from .cancel import cancel_process_group, process_group_popen_kwargs
from .captions import (
    CaptionCue,
    CaptionNormalizationResult,
    CaptionParseError,
    normalize_rolling_captions,
    parse_caption,
    parse_srt,
    parse_vtt,
    preserve_and_normalize_caption,
    serialize_srt,
    serialize_vtt,
)
from .commands import (
    PROGRESS_PREFIX,
    PROGRESS_TEMPLATE,
    YtDlpRuntimePaths,
    build_artifact_argv,
    build_metadata_argv,
)
from .exports import export_caption_bundle
from .manifest import ArtifactManifestStore, ManifestError
from .playlist import plan_flat_playlist
from .progress import DownloadProgress, parse_artifact_line, parse_progress_line
from .ranking import rank_subtitle_tracks, select_best_subtitle_track
from .service import (
    CommandExecutor,
    CommandResult,
    SubprocessYtDlpExecutor,
    YouTubeImportError,
    YouTubeImportService,
    YouTubeImportStore,
)
from .schemas import (
    ArtifactKind,
    ArtifactManifest,
    ArtifactState,
    PlaylistEntryFailure,
    PlaylistEntryPlan,
    PlaylistPlan,
    SubtitleSource,
    SubtitleTrack,
    YouTubeImportRequest,
)
from .urls import (
    YouTubeResourceKind,
    YouTubeURL,
    YouTubeURLValidationError,
    validate_youtube_url,
)

__all__ = [
    "ArtifactKind",
    "ArtifactManifest",
    "ArtifactManifestStore",
    "ArtifactState",
    "CaptionCue",
    "CaptionNormalizationResult",
    "CaptionParseError",
    "DownloadProgress",
    "CommandExecutor",
    "CommandResult",
    "ManifestError",
    "PROGRESS_PREFIX",
    "PROGRESS_TEMPLATE",
    "PlaylistEntryFailure",
    "PlaylistEntryPlan",
    "PlaylistPlan",
    "SubtitleSource",
    "SubtitleTrack",
    "YouTubeImportRequest",
    "YouTubeResourceKind",
    "YouTubeURL",
    "YouTubeURLValidationError",
    "YtDlpRuntimePaths",
    "SubprocessYtDlpExecutor",
    "YouTubeImportError",
    "YouTubeImportService",
    "YouTubeImportStore",
    "build_artifact_argv",
    "build_metadata_argv",
    "cancel_process_group",
    "export_caption_bundle",
    "normalize_rolling_captions",
    "parse_caption",
    "parse_artifact_line",
    "parse_progress_line",
    "parse_srt",
    "parse_vtt",
    "plan_flat_playlist",
    "preserve_and_normalize_caption",
    "process_group_popen_kwargs",
    "rank_subtitle_tracks",
    "select_best_subtitle_track",
    "serialize_srt",
    "serialize_vtt",
    "validate_youtube_url",
]
