"""Conservative Wenet CTC anchors for CTS subtitle timing.

The selected transcript remains immutable.  Exact normalised text runs bind
existing Qwen forced-alignment timestamps to Wenet's native CTC token clock.
Characters without a nearby trusted anchor retain their existing timing and
are reported for review instead of receiving fabricated precision.
"""

from __future__ import annotations

import math
import statistics
import unicodedata
from copy import deepcopy
from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence

from rapidfuzz.distance import Levenshtein

from ..evaluation.metrics import comparison_text
from ..normalization import HongKongNormalizer
from .forced_timestamps import (
    CharacterTimestamp,
    SubtitleCue,
    WordTimestamp,
    regroup_word_timestamps,
)


# v11 intentionally removes the legacy synthetic rescue clock.  That rescue
# interpolated verifier edges over a whole source segment after the actual
# native-anchor proposal had failed the monotonic preflight.  The result could
# look monotonic while no longer preserving the available clock evidence.
WENET_TIMING_POLICY_VERSION = "wenet-ctc-anchor-retime-v11-preflight-abstain"
WENET_TIMING_MODEL = (
    "sherpa-onnx-wenetspeech-yue-u2pp-conformer-ctc-zh-en-cantonese-"
    "int8-2025-09-10"
)
MINIMUM_EQUAL_RUN = 2
MINIMUM_SEGMENT_ANCHORS = 4
MINIMUM_SEGMENT_ANCHOR_COVERAGE = 0.25
MAXIMUM_NEAREST_ANCHOR_DISTANCE_CHARACTERS = 48
MAXIMUM_ANCHOR_ISLAND_SOURCE_GAP_CHARACTERS = 12
MAXIMUM_ANCHOR_ISLAND_CLOCK_DELTA_MS = 1_000
MINIMUM_ANCHOR_ISLAND_ANCHORS = 4
MINIMUM_ANCHOR_ISLAND_SPAN_CHARACTERS = 6
TIMING_FIRST_MIN_CUE_MS = 300
TIMING_FIRST_TARGET_CUE_MS = 800
TIMING_FIRST_MAX_CUE_MS = 1_800
TIMING_REVIEW_SHIFT_MS = 6_000
TIMING_REVIEW_MONOTONIC_REPAIR_MS = 2_000
MAXIMUM_SEGMENT_PREFLIGHT_REPAIR_MS = 2_000
TIMING_REVIEW_MAX_ACOUSTIC_CHARACTER_MS = 1_000
TIMING_REVIEW_MAX_INTER_ACOUSTIC_GAP_MS = 1_000
NATIVE_START_REPAIR_REVIEW_MS = 300  # Existing engineering start target, not acoustic gold.
MINIMUM_UNIQUE_NATIVE_RUN_CHARACTERS = 6
MAXIMUM_UNIQUE_NATIVE_RUN_GAP_MS = 1_000


@dataclass(frozen=True)
class _ProjectedCharacter:
    text: str
    source_index: int


@dataclass(frozen=True)
class _TimedProjectedCharacter:
    text: str
    start_ms: float
    end_ms: float
    has_native_start: bool = True


@dataclass(frozen=True)
class _Anchor:
    source_index: int
    current_start_ms: float
    current_end_ms: float
    wenet_start_ms: float
    wenet_end_ms: float
    anchor_clock: str = "legacy_midpoint"
    witness_index: int | None = None
    exact_match_run: tuple[int, int, int, int] | None = None
    exact_match_unique: bool = False
    source_projection_unique: bool = False

    @property
    def current_mid_ms(self) -> float:
        return (self.current_start_ms + self.current_end_ms) / 2

    @property
    def wenet_mid_ms(self) -> float:
        return (self.wenet_start_ms + self.wenet_end_ms) / 2

    @property
    def offset_ms(self) -> float:
        if self.anchor_clock == "ctc_onset":
            return self.wenet_start_ms - self.current_start_ms
        return self.wenet_mid_ms - self.current_mid_ms

    @property
    def witness_clock_ms(self) -> float:
        return self.wenet_start_ms if self.anchor_clock == "ctc_onset" else self.wenet_mid_ms

    @property
    def current_clock_ms(self) -> float:
        return self.current_start_ms if self.anchor_clock == "ctc_onset" else self.current_mid_ms


@dataclass(frozen=True)
class _SegmentTimingRange:
    source_start: int
    source_end: int
    anchors: tuple[_Anchor, ...]
    anchor_islands: tuple[tuple[_Anchor, ...], ...]
    verifier_start_ms: int | None
    verifier_end_ms: int | None
    original_qwen_anchor_islands: tuple[tuple[_Anchor, ...], ...] | None = None


@dataclass(frozen=True)
class WenetTimingResult:
    words: tuple[dict[str, Any], ...]
    characters: tuple[dict[str, Any], ...]
    cues: tuple[dict[str, Any], ...]
    audit: dict[str, Any]


def _member(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        if name not in value:
            raise ValueError(f"timing row missing {name}")
        return value[name]
    try:
        return getattr(value, name)
    except AttributeError as exc:
        raise ValueError(f"timing row missing {name}") from exc


def _normalised_piece(text: str, normalizer: HongKongNormalizer) -> str:
    return comparison_text(
        normalizer.normalize(unicodedata.normalize("NFKC", text))
    )


def _project_source(
    text: str,
    normalizer: HongKongNormalizer,
    *,
    source_offset: int,
) -> list[_ProjectedCharacter]:
    output: list[_ProjectedCharacter] = []
    for raw_index, raw_character in enumerate(text):
        for character in _normalised_piece(raw_character, normalizer):
            output.append(
                _ProjectedCharacter(
                    text=character,
                    source_index=source_offset + raw_index,
                )
            )
    return output


def _project_wenet_tokens(
    tokens: Sequence[Mapping[str, Any]],
    normalizer: HongKongNormalizer,
    *,
    segment_start_ms: int,
    segment_end_ms: int,
    native_starts_only: bool = False,
) -> list[_TimedProjectedCharacter]:
    starts: list[tuple[str, int]] = []
    for token in tokens:
        raw_text = str(token.get("token", "")).replace("▁", " ")
        normalised = _normalised_piece(raw_text, normalizer)
        raw_timestamp = token.get("timestamp")
        if (
            not normalised
            or isinstance(raw_timestamp, bool)
            or not isinstance(raw_timestamp, (int, float))
            or not math.isfinite(float(raw_timestamp))
        ):
            continue
        start_ms = round(float(raw_timestamp) * 1_000)
        if not segment_start_ms <= start_ms <= segment_end_ms:
            continue
        starts.append((normalised, start_ms))

    output: list[_TimedProjectedCharacter] = []
    for index, (normalised, start_ms) in enumerate(starts):
        if native_starts_only:
            # CTC supplies one token timestamp, not its acoustic end. Keep the
            # full normalized text for matching, but do not distribute letters
            # across a pause or manufacture clocks inside a multi-char token.
            output.extend(
                _TimedProjectedCharacter(character, start_ms, start_ms, part == 0)
                for part, character in enumerate(normalised)
            )
            continue
        later = next(
            (
                later_start
                for _later_text, later_start in starts[index + 1 :]
                if later_start > start_ms
            ),
            start_ms + 80,
        )
        end_ms = min(segment_end_ms, max(start_ms + 1, later))
        span = end_ms - start_ms
        for character_index, character in enumerate(normalised):
            output.append(
                _TimedProjectedCharacter(
                    text=character,
                    start_ms=start_ms
                    + span * character_index / len(normalised),
                    end_ms=start_ms
                    + span * (character_index + 1) / len(normalised),
                )
            )
    return output


def _anchors(
    source: Sequence[_ProjectedCharacter],
    witness: Sequence[_TimedProjectedCharacter],
    current_by_source: Mapping[int, Mapping[str, Any]],
    *,
    anchor_clock: str = "legacy_midpoint",
) -> list[_Anchor]:
    source_text = "".join(item.text for item in source)
    witness_text = "".join(item.text for item in witness)
    candidates: list[_Anchor] = []
    for tag, source_start, source_end, witness_start, _witness_end in (
        Levenshtein.opcodes(source_text, witness_text)
    ):
        if tag != "equal" or source_end - source_start < MINIMUM_EQUAL_RUN:
            continue
        piece = source_text[source_start:source_end]
        unique = all(value.find(piece) >= 0 and value.find(piece, value.find(piece) + 1) < 0
                     for value in (source_text, witness_text))
        raw_indices = [item.source_index for item in source[source_start:source_end]]
        for delta in range(source_end - source_start):
            source_item = source[source_start + delta]
            witness_item = witness[witness_start + delta]
            if not witness_item.has_native_start:
                continue
            current = current_by_source.get(source_item.source_index)
            if current is None:
                continue
            candidates.append(
                _Anchor(
                    source_index=source_item.source_index,
                    current_start_ms=float(current["start_ms"]),
                    current_end_ms=float(current["end_ms"]),
                    wenet_start_ms=witness_item.start_ms,
                    wenet_end_ms=witness_item.end_ms,
                    anchor_clock=anchor_clock,
                    witness_index=witness_start + delta,
                    exact_match_run=(source_start, source_end, witness_start, _witness_end),
                    exact_match_unique=unique,
                    source_projection_unique=raw_indices.count(source_item.source_index) == 1,
                )
            )

    deduplicated: dict[int, _Anchor] = {}
    for anchor in candidates:
        previous = deduplicated.get(anchor.source_index)
        if previous is None or abs(anchor.offset_ms) < abs(previous.offset_ms):
            deduplicated[anchor.source_index] = anchor
    monotonic: list[_Anchor] = []
    for anchor in sorted(deduplicated.values(), key=lambda item: item.source_index):
        if monotonic and anchor.witness_clock_ms < monotonic[-1].witness_clock_ms:
            continue
        monotonic.append(anchor)
    return monotonic


def _offset_for_source(
    source_index: int,
    anchor_islands: Sequence[Sequence[_Anchor]],
) -> float | None:
    anchors = next(
        (
            island
            for island in anchor_islands
            if island
            and island[0].source_index
            <= source_index
            <= island[-1].source_index
        ),
        (),
    )
    if not anchors:
        return None
    before = next(
        (anchor for anchor in reversed(anchors) if anchor.source_index <= source_index),
        None,
    )
    after = next(
        (anchor for anchor in anchors if anchor.source_index >= source_index),
        None,
    )
    if before is not None and after is not None:
        if before.source_index == after.source_index:
            return before.offset_ms
        if (
            source_index - before.source_index
            <= MAXIMUM_NEAREST_ANCHOR_DISTANCE_CHARACTERS
            and after.source_index - source_index
            <= MAXIMUM_NEAREST_ANCHOR_DISTANCE_CHARACTERS
        ):
            weight = (source_index - before.source_index) / (
                after.source_index - before.source_index
            )
            return before.offset_ms * (1 - weight) + after.offset_ms * weight
    nearest = min(anchors, key=lambda anchor: abs(anchor.source_index - source_index))
    if (
        abs(nearest.source_index - source_index)
        <= MAXIMUM_NEAREST_ANCHOR_DISTANCE_CHARACTERS
    ):
        return nearest.offset_ms
    return None


def _trusted_anchor_islands(
    anchors: Sequence[_Anchor],
) -> tuple[list[_Anchor], list[tuple[_Anchor, ...]]]:
    """Keep only locally coherent runs of text/time anchors.

    A large absolute Qwen-to-Wenet correction is not itself evidence of a bad
    match: correcting that drift is the purpose of this stage.  Discontinuity
    inside a short local run is evidence.  Split on a wide text gap or a sudden
    disagreement between the two clocks, then abstain from isolated runs that
    do not have enough neighbouring anchors to be independently supported.
    """

    islands: list[list[_Anchor]] = []
    for anchor in anchors:
        if not islands:
            islands.append([anchor])
            continue
        previous = islands[-1][-1]
        source_gap = anchor.source_index - previous.source_index
        current_delta = anchor.current_clock_ms - previous.current_clock_ms
        wenet_delta = anchor.witness_clock_ms - previous.witness_clock_ms
        if (
            source_gap > MAXIMUM_ANCHOR_ISLAND_SOURCE_GAP_CHARACTERS
            or abs(wenet_delta - current_delta)
            > MAXIMUM_ANCHOR_ISLAND_CLOCK_DELTA_MS
        ):
            islands.append([anchor])
        else:
            islands[-1].append(anchor)

    trusted_islands = [
        tuple(island)
        for island in islands
        if len(island) >= MINIMUM_ANCHOR_ISLAND_ANCHORS
        and island[-1].source_index - island[0].source_index + 1
        >= MINIMUM_ANCHOR_ISLAND_SPAN_CHARACTERS
    ]
    return [anchor for island in trusted_islands for anchor in island], trusted_islands


def _augment_unique_native_runs(
    anchors: Sequence[_Anchor],
    trusted_islands: Sequence[Sequence[_Anchor]],
) -> tuple[list[_Anchor], list[tuple[_Anchor, ...]], dict[str, Any]]:
    """Recover long unique native text runs independently of Qwen drift.

    A coherent native sequence must not be rejected solely because its Qwen
    clock is corrupt. This explicit experiment adds evidence, not precision
    for unmatched text: existing islands stay, and only uniquely located
    exact runs with real token starts can add new anchors. No reference or
    claimed acoustic end enters this decision.
    """
    runs: dict[tuple[int, int, int, int], list[_Anchor]] = {}
    for anchor in anchors:
        run = anchor.exact_match_run
        if (run is not None and anchor.anchor_clock == "ctc_onset"
                and anchor.exact_match_unique and anchor.source_projection_unique
                and run[1] - run[0] >= MINIMUM_UNIQUE_NATIVE_RUN_CHARACTERS):
            runs.setdefault(run, []).append(anchor)
    native_groups: list[tuple[_Anchor, ...]] = []
    for run in runs.values():
        pieces: list[list[_Anchor]] = []
        for anchor in sorted(run, key=lambda a: a.source_index):
            if (not pieces or anchor.source_index - pieces[-1][-1].source_index > MAXIMUM_ANCHOR_ISLAND_SOURCE_GAP_CHARACTERS
                    or not 0 < anchor.wenet_start_ms - pieces[-1][-1].wenet_start_ms <= MAXIMUM_UNIQUE_NATIVE_RUN_GAP_MS):
                pieces.append([anchor])
            else:
                pieces[-1].append(anchor)
        native_groups.extend(tuple(piece) for piece in pieces
                             if len(piece) >= MINIMUM_ANCHOR_ISLAND_ANCHORS
                             and piece[-1].source_index-piece[0].source_index+1 >= MINIMUM_UNIQUE_NATIVE_RUN_CHARACTERS)
    # Overlapping source intervals share the same monotonic native candidate
    # sequence. Merge their support so newly recovered inner points actually
    # replace interpolation/fallback, without extending outside either span.
    merged: list[tuple[_Anchor, ...]] = []
    for group in sorted([*trusted_islands, *native_groups], key=lambda x: x[0].source_index):
        if merged and group[0].source_index <= merged[-1][-1].source_index:
            by_source = {a.source_index:a for a in [*merged[-1],*group]}
            merged[-1] = tuple(by_source[i] for i in sorted(by_source))
        else:
            merged.append(tuple(group))
    original = {a.source_index for group in trusted_islands for a in group}
    result = [a for group in merged for a in group]
    added = [a.source_index for a in result if a.source_index not in original]
    return result, merged, {"native_unique_run_groups": len(native_groups),
                            "native_unique_run_added_source_indices": added,
                            "native_unique_run_added_anchors": len(added),
                            "qwen_islands_preserved": True}


def _review_spans(reasons: Sequence[str | None]) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    start: int | None = None
    active_reason: str | None = None
    for index, reason in enumerate((*reasons, None)):
        if reason is not None and start is None:
            start = index
            active_reason = reason
        elif start is not None and reason != active_reason:
            output.append(
                {
                    "source_start": start,
                    "source_end": index,
                    "character_count": index - start,
                    "reason": active_reason,
                }
            )
            start = index if reason is not None else None
            active_reason = reason
    return output


def _add_acoustic_clock_review_reasons(
    characters: Sequence[Mapping[str, Any]],
    reasons: list[str | None],
) -> dict[str, Any]:
    """Flag clock plateaus/gaps that cannot support a precise display edge.

    A gap may be a genuine pause, so this is deliberately an abstention signal
    rather than a timing rewrite.  The 1,000 ms ceiling is twice the scoped
    500 ms cue-edge band: a character or adjacent-acoustic gap wider than that
    cannot establish which half contains the spoken boundary.
    """

    if len(characters) != len(reasons):
        raise ValueError("character review reasons do not cover timing rows")

    def acoustic(text: str) -> bool:
        return bool(text) and any(
            not character.isspace()
            and not unicodedata.category(character).startswith("P")
            for character in text
        )

    long_character_indices: list[int] = []
    gap_rows: list[dict[str, int]] = []
    previous_acoustic: tuple[int, int] | None = None
    for index, row in enumerate(characters):
        text = str(row.get("text", ""))
        if not acoustic(text):
            continue
        start_ms = int(row["start_ms"])
        end_ms = int(row["end_ms"])
        if end_ms - start_ms > TIMING_REVIEW_MAX_ACOUSTIC_CHARACTER_MS:
            long_character_indices.append(index)
            if reasons[index] is None:
                reasons[index] = "acoustic_character_span_over_1000ms_review"
        if previous_acoustic is not None:
            previous_index, previous_end_ms = previous_acoustic
            gap_ms = start_ms - previous_end_ms
            if gap_ms > TIMING_REVIEW_MAX_INTER_ACOUSTIC_GAP_MS:
                gap_rows.append(
                    {
                        "source_start": previous_index,
                        "source_end": index + 1,
                        "gap_ms": gap_ms,
                    }
                )
                for source_index in range(previous_index, index + 1):
                    if reasons[source_index] is None:
                        reasons[source_index] = (
                            "inter_acoustic_gap_over_1000ms_review"
                        )
        previous_acoustic = (index, end_ms)

    return {
        "maximum_acoustic_character_duration_ms": max(
            (
                int(characters[index]["end_ms"])
                - int(characters[index]["start_ms"])
                for index in long_character_indices
            ),
            default=0,
        ),
        "acoustic_character_span_review_count": len(long_character_indices),
        "maximum_inter_acoustic_gap_ms": max(
            (row["gap_ms"] for row in gap_rows), default=0
        ),
        "inter_acoustic_gap_review_count": len(gap_rows),
    }


def _render_candidate_rows(
    rows: Sequence[Mapping[str, Any]],
    *,
    initial_cursor_ms: int,
    duration_ms: int,
) -> tuple[list[dict[str, Any]], int, int, int]:
    rendered: list[dict[str, Any]] = []
    cursor = initial_cursor_ms
    repair_count = 0
    maximum_repair_ms = 0
    for row in rows:
        raw_start = max(0, min(duration_ms, round(float(row["start_ms"]))))
        raw_end = max(raw_start, min(duration_ms, round(float(row["end_ms"]))))
        start_ms = max(cursor, raw_start)
        # A trailing punctuation mark can legitimately inherit a zero-duration
        # forced interval exactly at media end.  Moving its start backwards to
        # manufacture 1 ms would overlap the previous character.  Preserve a
        # monotonic zero-duration interval when no media time remains; otherwise
        # retain the ordinary positive-duration display interval.
        end_ms = (
            duration_ms
            if start_ms >= duration_ms
            else min(duration_ms, max(start_ms + 1, raw_end))
        )
        repair = max(abs(start_ms - raw_start), abs(end_ms - raw_end))
        if repair:
            repair_count += 1
            maximum_repair_ms = max(maximum_repair_ms, repair)
        rendered.append({**row, "start_ms": start_ms, "end_ms": end_ms})
        cursor = end_ms
    return rendered, cursor, repair_count, maximum_repair_ms


def _cap_adjacent_native_ends(
    rows: Sequence[Mapping[str, Any]], segment: _SegmentTimingRange
) -> list[dict[str, Any]]:
    """Cap inherited duration, never invent an onset or claim a speech end.

    Both characters must already have trusted, adjacent token-start anchors in
    the SAME exact text-match run. A Qwen-offset island break may itself be
    caused by its overlong duration; crossing it is an explicitly reviewed
    experiment, not a relaxation of anchor selection or the render gate.
    Unanchored text, punctuation, multi-char token interiors and different
    match runs are not spanned or repositioned by this policy.
    """
    result = [dict(row) for row in rows]
    by_source = {row["source_index"]: row for row in result}
    original_islands = segment.anchor_islands if segment.original_qwen_anchor_islands is None else segment.original_qwen_anchor_islands
    island_ids = {anchor.source_index: i for i, island in enumerate(original_islands) for anchor in island}
    selected_ids = {anchor.source_index: i for i, island in enumerate(segment.anchor_islands) for anchor in island}
    for left, right in zip(segment.anchors, segment.anchors[1:]):
        if (right.source_index != left.source_index + 1
            or left.witness_index is None or right.witness_index != left.witness_index + 1
            or left.exact_match_run is None or left.exact_match_run != right.exact_match_run):
            continue
        row = by_source[left.source_index]
        limit = float(right.wenet_start_ms)
        if limit < float(row["start_ms"]) + 1 or limit >= float(row["end_ms"]):
            continue
        left_original, right_original = island_ids.get(left.source_index), island_ids.get(right.source_index)
        unknown_original = left_original is None or right_original is None
        cross_island = not unknown_original and left_original != right_original
        row["native_end_cap"] = {
            "policy": "adjacent_trusted_exact_run_only_v1",
            "before_end_ms": float(row["end_ms"]),
            "cap_ms": limit,
            "trim_ms": float(row["end_ms"]) - limit,
            "next_source_index": right.source_index,
            "next_witness_index": right.witness_index,
            "exact_match_run": list(left.exact_match_run),
            "crosses_qwen_offset_island": cross_island,
            "original_qwen_island_unknown": unknown_original,
            "original_qwen_island_ids": [left_original, right_original],
            "selected_island_ids": [selected_ids[left.source_index], selected_ids[right.source_index]],
            "acoustic_end_verified": False,
        }
        row["end_ms"] = limit
        if cross_island:
            by_source[right.source_index]["native_end_cap_cross_island_receiving_boundary"] = True
        if unknown_original:
            by_source[right.source_index]["native_end_cap_unknown_original_island_receiving_boundary"] = True
    return result


def _direct_rescue_offsets(
    segment: _SegmentTimingRange,
    current_by_source: Mapping[int, Mapping[str, Any]],
) -> list[float] | None:
    """Return a legacy synthetic rescue clock for diagnostic comparison only.

    Production retiming must not call this helper.  Its source-monotonic
    interpolation can conceal a rejected native-anchor clock by creating
    artificial intra-segment positions.  It remains private only so historical
    evidence can be reproduced and compared without changing it.
    """

    if (
        not segment.anchors
        or segment.verifier_start_ms is None
        or segment.verifier_end_ms is None
        or segment.verifier_end_ms <= segment.verifier_start_ms
    ):
        return None
    source_start = segment.source_start
    source_end = segment.source_end
    if source_end <= source_start:
        return None
    if source_end - source_start == 1:
        target_mid = (
            segment.verifier_start_ms + segment.verifier_end_ms
        ) / 2
        current = current_by_source[source_start]
        current_mid = (float(current["start_ms"]) + float(current["end_ms"])) / 2
        return [target_mid - current_mid]

    boundary_start = float(segment.verifier_start_ms) + 0.5
    boundary_end = float(segment.verifier_end_ms) - 0.5
    knots_by_source = {
        anchor.source_index: anchor.wenet_mid_ms for anchor in segment.anchors
    }
    # Verified segment edges override a coincident text anchor.  This prevents
    # a repeated phrase from pulling the whole segment beyond its coarse audio
    # region while retaining every interior native CTC anchor.
    knots_by_source[source_start] = boundary_start
    knots_by_source[source_end - 1] = boundary_end
    knots = sorted(knots_by_source.items())
    if any(
        knots[index][1] > knots[index + 1][1]
        for index in range(len(knots) - 1)
    ):
        return None

    offsets: list[float] = []
    right_index = 0
    for source_index in range(source_start, source_end):
        while (
            right_index + 1 < len(knots)
            and knots[right_index][0] < source_index
        ):
            right_index += 1
        after = knots[right_index]
        before = knots[max(0, right_index - 1)]
        if after[0] < source_index and right_index + 1 < len(knots):
            before = after
            after = knots[right_index + 1]
        if before[0] == after[0]:
            target_mid = before[1]
        else:
            weight = (source_index - before[0]) / (after[0] - before[0])
            target_mid = before[1] * (1 - weight) + after[1] * weight
        current = current_by_source[source_index]
        current_mid = (float(current["start_ms"]) + float(current["end_ms"])) / 2
        offsets.append(target_mid - current_mid)
    return offsets


def _retime_characters(
    text: str,
    current_rows: Sequence[Any],
    segment_ranges: Sequence[_SegmentTimingRange],
    *,
    duration_ms: int,
    anchor_clock: str = "legacy_midpoint",
    cap_adjacent_native_ends: bool = False,
) -> tuple[list[dict[str, Any]], dict[str, Any], list[dict[str, Any]]]:
    current_by_source = {
        int(_member(row, "source_index")): {
            "source_index": int(_member(row, "source_index")),
            "text": str(_member(row, "text")),
            "start_ms": int(_member(row, "start_ms")),
            "end_ms": int(_member(row, "end_ms")),
            "chunk_id": str(_member(row, "chunk_id")),
        }
        for row in current_rows
    }
    if len(current_by_source) != len(text):
        raise ValueError("character timestamps do not cover transcript")

    repaired: list[dict[str, Any]] = []
    offsets: list[float] = []
    supported: list[bool] = []
    fallback_reasons: list[str | None] = []
    cursor = 0
    monotonic_repairs = 0
    maximum_repair_ms = 0
    segment_strategies: list[dict[str, Any]] = []
    expected_source_start = 0
    for segment_index, segment in enumerate(segment_ranges):
        if (
            segment.source_start != expected_source_start
            or segment.source_end <= segment.source_start
            or segment.source_end > len(text)
        ):
            raise ValueError("segment source ranges do not cover transcript")
        expected_source_start = segment.source_end

        primary_offsets: list[float | None] = []
        for source_index in range(segment.source_start, segment.source_end):
            current = current_by_source[source_index]
            if current["text"] != text[source_index]:
                raise ValueError("character timestamps changed transcript")
            primary_offsets.append(
                _offset_for_source(source_index, segment.anchor_islands)
            )

        def proposed_rows(
            candidate_offsets: Sequence[float | None], timing_source: str
        ) -> list[dict[str, Any]]:
            rows: list[dict[str, Any]] = []
            for relative_index, source_index in enumerate(
                range(segment.source_start, segment.source_end)
            ):
                current = current_by_source[source_index]
                offset = candidate_offsets[relative_index]
                applied_offset = 0.0 if offset is None else float(offset)
                rows.append(
                    {
                        **current,
                        "start_ms": float(current["start_ms"]) + applied_offset,
                        "end_ms": float(current["end_ms"]) + applied_offset,
                        "timing_source": (
                            timing_source
                            if offset is not None
                            else "qwen_forced_fallback"
                        ),
                    }
                )
            return rows

        chosen_offsets: list[float | None] = primary_offsets
        chosen_rows = proposed_rows(primary_offsets, "wenet_ctc_anchor")
        if cap_adjacent_native_ends:
            chosen_rows = _cap_adjacent_native_ends(chosen_rows, segment)
        rendered, next_cursor, repair_count, maximum_segment_repair = (
            _render_candidate_rows(
                chosen_rows,
                initial_cursor_ms=cursor,
                duration_ms=duration_ms,
            )
        )
        primary_maximum_repair = maximum_segment_repair
        strategy = (
            "wenet_ctc_anchor"
            if any(value is not None for value in primary_offsets)
            else "qwen_forced_fallback_untrusted"
        )
        # Do not synthesize a new clock from verifier edges here.  A failed
        # native-anchor preflight is evidence to abstain, not permission to
        # spread a coarse edge range over every character in the segment.
        synthetic_rescue_maximum_repair: int | None = None

        chosen_maximum_offset = max(
            (abs(float(value)) for value in chosen_offsets if value is not None),
            default=0.0,
        )
        if maximum_segment_repair > MAXIMUM_SEGMENT_PREFLIGHT_REPAIR_MS:
            chosen_offsets = [None] * (segment.source_end - segment.source_start)
            fallback_rows = proposed_rows(
                chosen_offsets, "qwen_forced_fallback_preflight_rejected"
            )
            rendered, next_cursor, repair_count, maximum_segment_repair = (
                _render_candidate_rows(
                    fallback_rows,
                    initial_cursor_ms=cursor,
                    duration_ms=duration_ms,
                )
            )
            strategy = "qwen_forced_fallback_preflight_rejected"

        if anchor_clock == "ctc_onset":
            direct_starts = {anchor.source_index: anchor.wenet_start_ms for anchor in segment.anchors}
            original_islands = segment.anchor_islands if segment.original_qwen_anchor_islands is None else segment.original_qwen_anchor_islands
            original_ids = {a.source_index:i for i,g in enumerate(original_islands) for a in g}
            selected_ids = {a.source_index:i for i,g in enumerate(segment.anchor_islands) for a in g}
            for relative_index, row in enumerate(rendered):
                source_index = row["source_index"]
                offset = chosen_offsets[relative_index]
                direct_start = direct_starts.get(source_index) if offset is not None else None
                row["start_clock_evidence"] = (
                    "direct_native_token_timestamp" if direct_start is not None
                    else "interpolated_offset" if offset is not None else "qwen_fallback"
                )
                row["native_token_start_ms"] = direct_start
                row["original_qwen_island_id"] = original_ids.get(source_index)
                row["selected_anchor_island_id"] = selected_ids.get(source_index)
                row["anchor_selection_support"] = (
                    "original_qwen_offset_island" if direct_start is not None and source_index in original_ids
                    else "unique_native_run_added_anchor" if direct_start is not None
                    else "interpolated_within_selected_island" if offset is not None else "qwen_fallback")
                row["newly_bridged_interpolated_clock"] = (
                    offset is not None and direct_start is None
                    and _offset_for_source(source_index, original_islands) is None)
                row["moved_from_native_token_start_ms"] = (
                    row["start_ms"] - direct_start if direct_start is not None else None
                )
                row["end_clock_evidence"] = "inherited_qwen_duration_then_monotonic_repair_not_acoustic_offset"
                if row.get("native_end_cap"):
                    row["end_clock_evidence"] = "inherited_qwen_duration_capped_by_next_native_start_then_monotonic_repair_not_acoustic_offset"
                    # A proposal is not a final constraint: the monotonic
                    # renderer may push even a capped end past the witness.
                    # Keep that counterevidence and quarantine every excess,
                    # including a 1 ms minimum-duration repair.
                    cap = dict(row["native_end_cap"])
                    cap["final_end_ms"] = row["end_ms"]
                    cap["final_excess_ms"] = max(0, row["end_ms"] - cap["cap_ms"])
                    cap["survived_final_render"] = cap["final_excess_ms"] == 0
                    row["native_end_cap"] = cap
        repaired.extend(rendered)
        offsets.extend(
            0.0 if value is None else float(value) for value in chosen_offsets
        )
        supported.extend(value is not None for value in chosen_offsets)
        fallback_reason = {
            "qwen_forced_fallback_untrusted": "no_nearby_trusted_wenet_anchor",
            "qwen_forced_fallback_preflight_rejected": (
                "segment_preflight_repair_gate_rejected"
            ),
        }.get(strategy, "no_nearby_trusted_wenet_anchor")
        for relative_index, value in enumerate(chosen_offsets):
            if value is None:
                source_index = segment.source_start + relative_index
                current = current_by_source[source_index]
                final_row = rendered[relative_index]
                moved_for_monotonic_display = (
                    int(final_row["start_ms"]) != int(current["start_ms"])
                    or int(final_row["end_ms"]) != int(current["end_ms"])
                )
                fallback_reasons.append(
                    "fallback_moved_for_monotonic_display_review"
                    if moved_for_monotonic_display
                    else fallback_reason
                )
            elif abs(float(value)) > TIMING_REVIEW_SHIFT_MS:
                fallback_reasons.append("large_wenet_clock_correction_review")
            elif maximum_segment_repair > TIMING_REVIEW_MONOTONIC_REPAIR_MS:
                fallback_reasons.append("segment_monotonic_repair_review")
            elif rendered[relative_index].get("newly_bridged_interpolated_clock"):
                fallback_reasons.append("newly_bridged_interpolated_clock_review")
            elif rendered[relative_index].get("native_end_cap", {}).get("survived_final_render") is False:
                fallback_reasons.append("native_end_cap_lost_after_monotonic_repair_review")
            elif (
                rendered[relative_index].get("native_end_cap", {}).get("crosses_qwen_offset_island")
                or rendered[relative_index].get("native_end_cap_cross_island_receiving_boundary")
            ):
                fallback_reasons.append("native_end_cap_cross_island_review")
            elif (rendered[relative_index].get("native_end_cap", {}).get("original_qwen_island_unknown")
                  or rendered[relative_index].get("native_end_cap_unknown_original_island_receiving_boundary")):
                fallback_reasons.append("native_end_cap_unknown_original_island_review")
            elif rendered[relative_index].get("native_end_cap", {}).get("trim_ms", 0) > 500:
                fallback_reasons.append("native_inherited_end_trim_over_500ms_review")
            elif (
                anchor_clock == "ctc_onset"
                and rendered[relative_index].get("moved_from_native_token_start_ms") is not None
                and abs(rendered[relative_index]["moved_from_native_token_start_ms"]) > NATIVE_START_REPAIR_REVIEW_MS
            ):
                fallback_reasons.append("native_token_start_moved_over_300ms_review")
            else:
                fallback_reasons.append(None)
        cursor = next_cursor
        monotonic_repairs += repair_count
        maximum_repair_ms = max(maximum_repair_ms, maximum_segment_repair)
        segment_strategies.append(
            {
                "segment_index": segment_index,
                "source_start": segment.source_start,
                "source_end": segment.source_end,
                "strategy": strategy,
                "primary_maximum_monotonic_repair_ms": primary_maximum_repair,
                "synthetic_rescue_maximum_monotonic_repair_ms": (
                    synthetic_rescue_maximum_repair
                ),
                "chosen_maximum_absolute_offset_ms": round(
                    chosen_maximum_offset, 3
                ),
                "final_maximum_monotonic_repair_ms": maximum_segment_repair,
            }
        )
    if expected_source_start != len(text):
        raise ValueError("segment source ranges do not cover transcript")

    acoustic_clock_audit = _add_acoustic_clock_review_reasons(
        repaired, fallback_reasons
    )
    absolute_offsets = [abs(value) for value in offsets]
    audit = {
        "character_count": len(repaired),
        "native_end_cap_attempted_character_count": sum(bool(row.get("native_end_cap")) for row in repaired),
        "native_end_cap_survived_character_count": sum(row.get("native_end_cap", {}).get("survived_final_render") is True for row in repaired),
        "native_end_cap_lost_character_count": sum(row.get("native_end_cap", {}).get("survived_final_render") is False for row in repaired),
        "anchored_character_count": sum(supported),
        "fallback_character_count": supported.count(False),
        "shifted_character_count": sum(abs(value) >= 0.5 for value in offsets),
        "offset_absolute_median_ms": (
            round(statistics.median(absolute_offsets), 3) if offsets else None
        ),
        "offset_absolute_max_ms": (
            round(max(absolute_offsets), 3) if offsets else None
        ),
        "monotonic_repaired_character_count": monotonic_repairs,
        "maximum_monotonic_repair_ms": maximum_repair_ms,
        "maximum_segment_preflight_repair_ms": (
            MAXIMUM_SEGMENT_PREFLIGHT_REPAIR_MS
        ),
        "segment_strategies": segment_strategies,
        "synthetic_rescue_enabled": False,
        "bounded_direct_rescue_segment_count": 0,
        "preflight_rejected_segment_count": sum(
            item["strategy"] == "qwen_forced_fallback_preflight_rejected"
            for item in segment_strategies
        ),
        "large_shift_review_character_count": sum(
            abs(value) > TIMING_REVIEW_SHIFT_MS for value in offsets
        ),
        "fallback_moved_for_monotonic_display_character_count": sum(
            reason == "fallback_moved_for_monotonic_display_review"
            for reason in fallback_reasons
        ),
        "timing_review_max_acoustic_character_ms": (
            TIMING_REVIEW_MAX_ACOUSTIC_CHARACTER_MS
        ),
        "timing_review_max_inter_acoustic_gap_ms": (
            TIMING_REVIEW_MAX_INTER_ACOUSTIC_GAP_MS
        ),
        **acoustic_clock_audit,
    }
    return repaired, audit, _review_spans(fallback_reasons)


def _retime_source_spans(
    rows: Sequence[Any], characters: Sequence[Mapping[str, Any]]
) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    for row in rows:
        source_start = int(_member(row, "source_start"))
        source_end = int(_member(row, "source_end"))
        owned = characters[source_start:source_end]
        if not owned:
            raise ValueError("source timing span has no characters")
        updated = asdict(row) if not isinstance(row, Mapping) else dict(row)
        updated["start_ms"] = int(owned[0]["start_ms"])
        updated["end_ms"] = int(owned[-1]["end_ms"])
        output.append(updated)
    return output


def _bounded_merge_short_cues(
    cues: Sequence[SubtitleCue], *, duration_ms: int
) -> list[SubtitleCue]:
    """Merge a short cue only when the union stays within the hard ceiling."""

    working = list(cues)
    index = 0
    while index < len(working):
        cue = working[index]
        if cue.end_ms - cue.start_ms >= TIMING_FIRST_MIN_CUE_MS:
            index += 1
            continue
        if cue.start_ms >= duration_ms and index > 0:
            # regroup_word_timestamps guarantees positive display duration and
            # can therefore put a final zero-duration punctuation mark 1 ms
            # beyond sealed media.  It cannot stand alone as a valid subtitle.
            # Merge it into the previous cue and clamp to media end.  This can
            # retain an already-overlong final acoustic interval, so the caller
            # records an explicit overflow review count below.
            previous = working[index - 1]
            working[index - 1 : index + 1] = [
                SubtitleCue(
                    index=previous.index,
                    start_ms=previous.start_ms,
                    end_ms=duration_ms,
                    text=previous.text + cue.text,
                    source_start=previous.source_start,
                    source_end=cue.source_end,
                )
            ]
            index = max(0, index - 1)
            continue
        if index + 1 < len(working):
            following = working[index + 1]
            if following.end_ms - cue.start_ms <= TIMING_FIRST_MAX_CUE_MS:
                working[index : index + 2] = [
                    SubtitleCue(
                        index=cue.index,
                        start_ms=cue.start_ms,
                        end_ms=following.end_ms,
                        text=cue.text + following.text,
                        source_start=cue.source_start,
                        source_end=following.source_end,
                    )
                ]
                continue
        if index > 0:
            previous = working[index - 1]
            if cue.end_ms - previous.start_ms <= TIMING_FIRST_MAX_CUE_MS:
                working[index - 1 : index + 1] = [
                    SubtitleCue(
                        index=previous.index,
                        start_ms=previous.start_ms,
                        end_ms=cue.end_ms,
                        text=previous.text + cue.text,
                        source_start=previous.source_start,
                        source_end=cue.source_end,
                    )
                ]
                index = max(0, index - 1)
                continue
        # Timing wins over readability: retain the short supported interval
        # instead of stretching it across unrelated speech or silence.
        index += 1
    return [
        SubtitleCue(
            index=cue_index,
            start_ms=cue.start_ms,
            end_ms=cue.end_ms,
            text=cue.text,
            source_start=cue.source_start,
            source_end=cue.source_end,
        )
        for cue_index, cue in enumerate(working, start=1)
    ]


def bound_experimental_display_speech_ends(
    *,
    fine_cues: Sequence[Mapping[str, Any]],
    character_timestamps: Sequence[Mapping[str, Any]],
    text: str,
    speech_islands: Sequence[Mapping[str, Any]],
    duration_ms: int,
    enabled: bool = False,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Shrink already-rendered display ends using coarse full-audio Silero VAD.

    This independent, default-off experiment never changes transcript, starts,
    or character clocks. Caller must verify the VAD/audio lineage; these plain
    intervals do not constitute an accepted witness or acoustic gold. Inputs
    must already include the existing display trim: no second trim is applied.
    A strict whole-cue native-clock requirement intentionally abstains on mixed
    unknown/interpolated content rather than searching past it for a witness.
    """
    output = deepcopy(list(fine_cues))
    audit: dict[str, Any] = {
        "policy": "experimental-display-silero-end-shrink-v1",
        "enabled": enabled,
        "applied": False,
        "changed_cue_count": 0,
        "reference_timing_used": False,
        "accepted_posterior_context_claimed": False,
        "acoustic_gold_claimed": False,
        "release_verdict": None,
        "model_scope": "single_full_audio_silero_vad_coarse_speech_islands",
        "input_lineage": "caller_must_verify_audio_and_vad_receipt",
        "input_display_trim": "already_applied_no_additional_trim",
        "whole_cue_evidence": "every_spoken_source_character_direct_native_in_same_island",
        "limits": {"maximum_trim_ms": 1000, "minimum_retained_ms": 200,
                   "minimum_silence_ms": 250, "maximum_native_displacement_ms": 300},
        "cues": [],
    }
    if enabled is not True:
        audit["abstention_reason"] = "disabled" if enabled is False else "invalid_enabled_flag"
        return output, audit

    def number(value: Any) -> bool:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)

    def integer(value: Any) -> bool:
        return isinstance(value, int) and not isinstance(value, bool)

    def invalid(reason: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        audit["abstention_reason"] = reason
        return output, audit

    if not isinstance(text, str) or not text or not integer(duration_ms) or duration_ms <= 0:
        return invalid("invalid_transcript_or_duration")
    if not speech_islands:
        return invalid("no_speech_islands")
    previous_end = -1
    for island in speech_islands:
        if (not isinstance(island, Mapping)
                or not integer(island.get("start_ms")) or not integer(island.get("end_ms"))
                or not 0 <= island["start_ms"] < island["end_ms"] <= duration_ms
                or island["start_ms"] < previous_end):
            return invalid("invalid_or_overlapping_speech_islands")
        previous_end = island["end_ms"]

    characters: dict[int, Mapping[str, Any]] = {}
    for row in character_timestamps:
        if not isinstance(row, Mapping) or not integer(row.get("source_index")):
            return invalid("invalid_character_source")
        source = row["source_index"]
        if (source in characters or not 0 <= source < len(text) or row.get("text") != text[source]
                or not number(row.get("start_ms")) or not number(row.get("end_ms"))
                or not 0 <= row["start_ms"] < row["end_ms"] <= duration_ms):
            return invalid("invalid_or_ambiguous_character_coverage")
        characters[source] = row
    if len(characters) != len(text):
        return invalid("incomplete_character_coverage")
    expected_source = 0
    previous_start = -1
    for cue in output:
        if (not isinstance(cue, dict)
                or any(not integer(cue.get(key)) for key in ("source_start", "source_end", "start_ms", "end_ms"))
                or cue["source_start"] != expected_source
                or not expected_source < cue["source_end"] <= len(text)
                or cue.get("text") != text[expected_source:cue["source_end"]]
                or not 0 <= cue["start_ms"] < cue["end_ms"] <= duration_ms
                or cue["start_ms"] < previous_start):
            return invalid("invalid_or_incomplete_display_coverage")
        for seconds_key, milliseconds_key in (("start", "start_ms"), ("end", "end_ms")):
            if seconds_key in cue and (not number(cue[seconds_key])
                    or abs(cue[seconds_key] * 1000 - cue[milliseconds_key]) > 1e-6):
                return invalid("inconsistent_display_seconds_alias")
        expected_source = cue["source_end"]
        previous_start = cue["start_ms"]
    if expected_source != len(text):
        return invalid("invalid_or_incomplete_display_coverage")

    def spoken(source: int) -> bool:
        char = text[source]
        return not (char.isspace() or unicodedata.category(char).startswith("P"))

    def native_clock(source: int) -> tuple[float | None, str | None]:
        row = characters[source]
        native = row.get("native_token_start_ms")
        displacement = row.get("moved_from_native_token_start_ms")
        if (row.get("timing_source") != "wenet_ctc_anchor"
                or row.get("start_clock_evidence") != "direct_native_token_timestamp"
                or not number(native) or not 0 <= native < duration_ms
                or not number(displacement)):
            return None, "missing_or_untrusted_native_clock"
        actual_displacement = row["start_ms"] - native
        if abs(actual_displacement - displacement) > 1e-6:
            return None, "inconsistent_native_displacement"
        if abs(actual_displacement) > 300:
            return None, "native_displacement_over_300ms"
        return native, None

    def island_at(clock: float) -> int | None:
        return next((index for index, island in enumerate(speech_islands)
                     if island["start_ms"] <= clock < island["end_ms"]), None)

    for cue_index, cue in enumerate(output):
        row_audit: dict[str, Any] = {
            "cue_position": cue_index, "source_start": cue["source_start"],
            "source_end": cue["source_end"], "text": cue["text"],
            "original_display_start_ms": cue["start_ms"],
            "original_display_end_ms": cue["end_ms"],
            "original_display_end_seconds": cue.get("end"),
            "after_display_end_ms": cue["end_ms"], "changed": False,
        }
        audit["cues"].append(row_audit)
        sources = [source for source in range(cue["source_start"], cue["source_end"]) if spoken(source)]
        next_source = next((source for source in range(cue["source_end"], len(text)) if spoken(source)), None)
        row_audit.update(last_spoken_source_index=sources[-1] if sources else None,
                         next_spoken_source_index=next_source)
        if not sources or next_source is None:
            row_audit["abstention_reason"] = "no_spoken_content_or_no_immediate_next_spoken_character"
            continue
        native_points = []
        for source in [*sources, next_source]:
            native, reason = native_clock(source)
            if reason:
                row_audit.update(abstention_reason=reason, rejected_source_index=source)
                break
            native_points.append(native)
        if "abstention_reason" in row_audit:
            continue
        row_audit.update(last_native_start_ms=native_points[-2], next_native_start_ms=native_points[-1])
        row_audit["whole_cue_native_source_indices"] = sources
        row_audit["whole_cue_native_start_ms"] = native_points[:-1]
        if any(left >= right for left, right in zip(native_points, native_points[1:])):
            row_audit["abstention_reason"] = "non_increasing_native_source_clocks"
            continue
        indices = [island_at(point) for point in native_points]
        last_island, next_island = indices[-2:]
        row_audit.update(last_speech_island_index=last_island, next_speech_island_index=next_island)
        if last_island is None or any(index != last_island for index in indices[:-1]):
            row_audit["abstention_reason"] = "whole_cue_not_bounded_in_single_speech_island"
            continue
        if next_island != last_island + 1:
            row_audit["abstention_reason"] = "next_spoken_character_not_in_immediate_following_island"
            continue
        proposed_end = speech_islands[last_island]["end_ms"]
        row_audit["last_speech_island"] = dict(speech_islands[last_island])
        row_audit["next_speech_island"] = dict(speech_islands[next_island])
        silence = speech_islands[next_island]["start_ms"] - proposed_end
        trim = cue["end_ms"] - proposed_end
        row_audit.update(proposed_display_end_ms=proposed_end, silence_ms=silence, trim_ms=trim)
        if silence < 250:
            reason = "silence_below_250ms_or_artificial_split"
        elif trim <= 0:
            reason = "no_late_end_to_shrink"
        elif trim > 1000:
            reason = "trim_over_1000ms"
        elif proposed_end - cue["start_ms"] < 200:
            reason = "retained_display_below_200ms"
        elif any(characters[source]["start_ms"] >= proposed_end for source in sources):
            reason = "proposed_end_precedes_rendered_spoken_start"
        elif cue_index + 1 < len(output) and proposed_end > output[cue_index + 1]["start_ms"]:
            reason = "proposed_end_overlaps_next_display_cue"
        else:
            reason = None
        if reason:
            row_audit["abstention_reason"] = reason
            continue
        cue["end_ms"] = proposed_end
        if "end" in cue:
            cue["end"] = proposed_end / 1000
        cue["timing_review_required"] = True
        cue["low_confidence"] = True
        row_audit.update(after_display_end_ms=proposed_end, changed=True)
        audit["changed_cue_count"] += 1
    audit["applied"] = audit["changed_cue_count"] > 0
    return output, audit


def retime_with_wenet_anchors(
    *,
    text: str,
    final_segments: Sequence[Mapping[str, Any]],
    verifier_segments: Sequence[Mapping[str, Any]],
    words: Sequence[Any],
    characters: Sequence[Any],
    duration_ms: int,
    anchor_clock: str = "legacy_midpoint",
    cap_adjacent_native_ends: bool = False,
    anchor_selection: str = "qwen_offset_islands",
) -> WenetTimingResult:
    """Return Wenet-anchored timings without changing transcript content."""

    if not text or duration_ms <= 0:
        raise ValueError("transcript and duration are required")
    if anchor_clock not in {"legacy_midpoint", "ctc_onset"}:
        raise ValueError("unknown Wenet anchor clock")
    if not isinstance(cap_adjacent_native_ends, bool) or (cap_adjacent_native_ends and anchor_clock != "ctc_onset"):
        raise ValueError("native end cap requires explicit ctc_onset mode")
    if anchor_selection not in {"qwen_offset_islands", "qwen_islands_plus_unique_native_runs"}:
        raise ValueError("unknown anchor selection policy")
    if anchor_selection != "qwen_offset_islands" and anchor_clock != "ctc_onset":
        raise ValueError("unique native runs require explicit ctc_onset mode")
    reconstructed = "".join(
        str(row.get("text", row.get("chosen_text", "")))
        for row in final_segments
    )
    if reconstructed != text:
        raise ValueError("final segments do not reconstruct transcript")
    verifier_by_id = {
        str(row.get("id", "")): row for row in verifier_segments if row.get("id")
    }
    normalizer = HongKongNormalizer()
    current_by_source = {
        int(_member(row, "source_index")): {
            "start_ms": int(_member(row, "start_ms")),
            "end_ms": int(_member(row, "end_ms")),
        }
        for row in characters
    }

    source_offset = 0
    segment_ranges: list[_SegmentTimingRange] = []
    segment_audits: list[dict[str, Any]] = []
    for segment_index, final_segment in enumerate(final_segments):
        segment_text = str(
            final_segment.get("text", final_segment.get("chosen_text", ""))
        )
        source_end = source_offset + len(segment_text)
        final_segment_id = str(final_segment.get("id", ""))
        verifier = verifier_by_id.get(final_segment_id)
        verifier_match = "id"
        if verifier is None and segment_index < len(verifier_segments):
            ordered = verifier_segments[segment_index]
            # Reconciliation currently strips recognition chunk IDs.  Ordered
            # fallback is accepted only when any available coarse ranges still
            # identify the same audio region.
            final_start = final_segment.get("start_ms")
            final_end = final_segment.get("end_ms")
            ordered_start = ordered.get("start")
            ordered_end = ordered.get("end")
            ranges_compatible = False
            if (
                isinstance(final_start, int)
                and not isinstance(final_start, bool)
                and isinstance(final_end, int)
                and not isinstance(final_end, bool)
                and isinstance(ordered_start, (int, float))
                and not isinstance(ordered_start, bool)
                and isinstance(ordered_end, (int, float))
                and not isinstance(ordered_end, bool)
            ):
                ranges_compatible = (
                    abs(final_start - round(float(ordered_start) * 1_000)) <= 3_000
                    and abs(final_end - round(float(ordered_end) * 1_000)) <= 3_000
                )
            if ranges_compatible:
                verifier = ordered
                verifier_match = "ordered_coarse_range"
        if verifier is None:
            verifier_match = "none"
        source_projection = _project_source(
            segment_text,
            normalizer,
            source_offset=source_offset,
        )
        candidate_anchors: list[_Anchor] = []
        verifier_start_ms: int | None = None
        verifier_end_ms: int | None = None
        if verifier is not None:
            raw_tokens = verifier.get("tokens")
            if isinstance(raw_tokens, Sequence) and not isinstance(
                raw_tokens, (str, bytes, bytearray)
            ):
                segment_start_ms = round(float(verifier.get("start", 0.0)) * 1_000)
                segment_end_ms = round(float(verifier.get("end", 0.0)) * 1_000)
                verifier_start_ms = segment_start_ms
                verifier_end_ms = segment_end_ms
                witness = _project_wenet_tokens(
                    [token for token in raw_tokens if isinstance(token, Mapping)],
                    normalizer,
                    segment_start_ms=segment_start_ms,
                    segment_end_ms=segment_end_ms,
                    native_starts_only=anchor_clock == "ctc_onset",
                )
                candidate_anchors = _anchors(
                    source_projection,
                    witness,
                    current_by_source,
                    anchor_clock=anchor_clock,
                )
        trusted_island_anchors, trusted_islands = _trusted_anchor_islands(
            candidate_anchors
        )
        original_qwen_islands = tuple(trusted_islands)
        selection_audit: dict[str, Any] = {}
        if anchor_selection == "qwen_islands_plus_unique_native_runs":
            trusted_island_anchors, trusted_islands, selection_audit = _augment_unique_native_runs(candidate_anchors, trusted_islands)
        coverage = len(trusted_island_anchors) / max(1, len(source_projection))
        trusted = (
            len(trusted_island_anchors) >= MINIMUM_SEGMENT_ANCHORS
            and coverage >= MINIMUM_SEGMENT_ANCHOR_COVERAGE
        )
        anchors = trusted_island_anchors if trusted else []
        segment_ranges.append(
            _SegmentTimingRange(
                source_start=source_offset,
                source_end=source_end,
                anchors=tuple(anchors),
                anchor_islands=(
                    tuple(trusted_islands) if trusted else ()
                ),
                verifier_start_ms=verifier_start_ms,
                verifier_end_ms=verifier_end_ms,
                original_qwen_anchor_islands=original_qwen_islands,
            )
        )
        segment_audits.append(
            {
                "segment_id": str(final_segment.get("id", "")),
                "segment_index": segment_index,
                "verifier_match": verifier_match,
                "source_start": source_offset,
                "source_end": source_end,
                "projected_character_count": len(source_projection),
                "candidate_anchor_count": len(candidate_anchors),
                "anchor_count": len(trusted_island_anchors),
                "anchor_coverage": round(coverage, 6),
                "trusted_anchor_island_count": len(trusted_islands),
                "trusted_anchor_island_sizes": [
                    len(island) for island in trusted_islands
                ],
                "trusted": trusted,
                **selection_audit,
            }
        )
        source_offset = source_end

    retimed_characters, character_audit, review_spans = _retime_characters(
        text,
        characters,
        segment_ranges,
        duration_ms=duration_ms,
        anchor_clock=anchor_clock,
        cap_adjacent_native_ends=cap_adjacent_native_ends,
    )
    strategy_by_index = {
        int(item["segment_index"]): item
        for item in character_audit.get("segment_strategies", ())
        if isinstance(item, Mapping)
    }
    for segment_audit in segment_audits:
        strategy = strategy_by_index.get(int(segment_audit["segment_index"]))
        if strategy is not None:
            segment_audit.update(
                {
                    "timing_strategy": strategy["strategy"],
                    "primary_maximum_monotonic_repair_ms": strategy[
                        "primary_maximum_monotonic_repair_ms"
                    ],
                    # Kept as an explicit null for readers of the v10 audit
                    # schema.  v11 never executes the legacy rescue path.
                    "rescue_maximum_monotonic_repair_ms": None,
                    "synthetic_rescue_maximum_monotonic_repair_ms": strategy[
                        "synthetic_rescue_maximum_monotonic_repair_ms"
                    ],
                    "chosen_maximum_absolute_offset_ms": strategy[
                        "chosen_maximum_absolute_offset_ms"
                    ],
                    "final_maximum_monotonic_repair_ms": strategy[
                        "final_maximum_monotonic_repair_ms"
                    ],
                }
            )
    retimed_words = _retime_source_spans(words, retimed_characters)
    word_objects = tuple(
        WordTimestamp(
            text=str(row["text"]),
            start_ms=int(row["start_ms"]),
            end_ms=int(row["end_ms"]),
            source_start=int(row["source_start"]),
            source_end=int(row["source_end"]),
            chunk_id=str(row["chunk_id"]),
        )
        for row in retimed_words
    )
    character_objects = tuple(
        CharacterTimestamp(
            text=str(row["text"]),
            start_ms=int(row["start_ms"]),
            end_ms=int(row["end_ms"]),
            source_index=int(row["source_index"]),
            chunk_id=str(row["chunk_id"]),
        )
        for row in retimed_characters
    )
    raw_cues = regroup_word_timestamps(
        text,
        word_objects,
        character_objects,
        min_cue_ms=TIMING_FIRST_MIN_CUE_MS,
        target_cue_ms=TIMING_FIRST_TARGET_CUE_MS,
        max_cue_ms=TIMING_FIRST_MAX_CUE_MS,
    )
    cues = _bounded_merge_short_cues(raw_cues, duration_ms=duration_ms)
    short_cue_count = sum(
        cue.end_ms - cue.start_ms < TIMING_FIRST_MIN_CUE_MS for cue in cues
    )
    overlong_cue_count = sum(
        cue.end_ms - cue.start_ms > TIMING_FIRST_MAX_CUE_MS for cue in cues
    )
    if "".join(cue.text for cue in cues) != text:
        raise AssertionError("Wenet retiming changed transcript content")

    applied = character_audit["anchored_character_count"] > 0
    maximum_shift = character_audit["offset_absolute_max_ms"] or 0
    maximum_repair = character_audit["maximum_monotonic_repair_ms"]
    audit = {
        "policy_version": WENET_TIMING_POLICY_VERSION,
        "model": WENET_TIMING_MODEL,
        "applied": applied,
        "transcript_text_changed": False,
        "minimum_equal_run": MINIMUM_EQUAL_RUN,
        "minimum_segment_anchors": MINIMUM_SEGMENT_ANCHORS,
        "minimum_segment_anchor_coverage": MINIMUM_SEGMENT_ANCHOR_COVERAGE,
        "maximum_nearest_anchor_distance_characters": (
            MAXIMUM_NEAREST_ANCHOR_DISTANCE_CHARACTERS
        ),
        "maximum_anchor_island_source_gap_characters": (
            MAXIMUM_ANCHOR_ISLAND_SOURCE_GAP_CHARACTERS
        ),
        "maximum_anchor_island_clock_delta_ms": (
            MAXIMUM_ANCHOR_ISLAND_CLOCK_DELTA_MS
        ),
        "minimum_anchor_island_anchors": MINIMUM_ANCHOR_ISLAND_ANCHORS,
        "minimum_anchor_island_span_characters": (
            MINIMUM_ANCHOR_ISLAND_SPAN_CHARACTERS
        ),
        "maximum_segment_preflight_repair_ms": (
            MAXIMUM_SEGMENT_PREFLIGHT_REPAIR_MS
        ),
        "cue_policy": {
            "min_cue_ms": TIMING_FIRST_MIN_CUE_MS,
            "target_cue_ms": TIMING_FIRST_TARGET_CUE_MS,
            "max_cue_ms": TIMING_FIRST_MAX_CUE_MS,
            "short_cue_overflow": "leave_and_flag",
            "media_end_zero_duration_merge": (
                "merge_into_previous_clamp_to_media_end_and_flag_overflow"
            ),
        },
        "segments": segment_audits,
        "trusted_segment_count": sum(item["trusted"] for item in segment_audits),
        "applied_segment_count": sum(
            item.get("timing_strategy")
            == "wenet_ctc_anchor"
            for item in segment_audits
        ),
        "total_anchor_count": sum(item["anchor_count"] for item in segment_audits),
        **character_audit,
        "review_spans": review_spans,
        "short_cue_count": short_cue_count,
        "overlong_cue_count": overlong_cue_count,
        "cue_count": len(cues),
        "timing_review_required": bool(
            review_spans
            or short_cue_count
            or overlong_cue_count
            or maximum_shift > TIMING_REVIEW_SHIFT_MS
            or maximum_repair > TIMING_REVIEW_MONOTONIC_REPAIR_MS
        ),
    }
    if anchor_clock == "ctc_onset":
        audit.update({
            "experimental_anchor_clock": "ctc_onset",
            "experimental_policy_version": "wenet-native-token-start-v1",
            "coarse_midpoint_rescue_enabled": False,
            "acoustic_onset_or_offset_verified": False,
            "end_clock_policy": "inherit_qwen_duration_then_monotonic_repair",
            "native_start_repair_review_threshold_ms": NATIVE_START_REPAIR_REVIEW_MS,
            "adjacent_native_end_cap_enabled": cap_adjacent_native_ends,
            "adjacent_native_end_cap_policy": "adjacent_trusted_exact_run_only_v1" if cap_adjacent_native_ends else None,
            "anchor_selection": anchor_selection,
            "native_run_policy": ({"minimum_unique_run_characters": MINIMUM_UNIQUE_NATIVE_RUN_CHARACTERS,
                                   "maximum_native_gap_ms": MAXIMUM_UNIQUE_NATIVE_RUN_GAP_MS,
                                   "reference_timing_used": False,
                                   "posterior_acceptance_context_claimed": False,
                                   "existing_qwen_islands_preserved": True}
                                  if anchor_selection != "qwen_offset_islands" else None),
        })
    return WenetTimingResult(
        words=tuple(retimed_words),
        characters=tuple(retimed_characters),
        cues=tuple(asdict(cue) for cue in cues),
        audit=audit,
    )


__all__ = [
    "WENET_TIMING_MODEL",
    "WENET_TIMING_POLICY_VERSION",
    "WenetTimingResult",
    "retime_with_wenet_anchors",
]
