from __future__ import annotations

import hashlib
import re
from dataclasses import asdict, dataclass, replace
from typing import Iterable

from opencc import OpenCC
from rapidfuzz.distance import Levenshtein

from ..schemas import ReconciledSegment, TranscriptDocument

BUILTIN_PROTECTED_CANTONESE = (
    "係",
    "喺",
    "嘅",
    "咗",
    "冇",
    "佢",
    "哋",
    "啲",
    "嚟",
    "嗰",
    "咁",
    "唔",
    "畀",
    "睇",
    "而家",
    "搵",
)

# Bump this whenever a deterministic normalization rule changes.  Pipeline
# checkpoints include the value, so an app update cannot silently reuse output
# produced by an older language policy.
HK_NORMALIZATION_POLICY_VERSION = "2026-08-07.3"


def _project_segment_boundaries(
    segments: list[ReconciledSegment], target_text: str
) -> list[ReconciledSegment]:
    """Re-slice whole-document normalization without changing its text.

    OpenCC phrase rules can cross an ASR segment boundary, so independently
    normalized segments are not guaranteed to concatenate to the canonical
    whole-document result.  RapidFuzz supplies a deterministic edit path; only
    boundary offsets are projected and the transcript itself is never rewritten.
    """

    if not segments:
        return segments
    source_text = "".join(segment.text for segment in segments)
    if source_text == target_text:
        return segments
    mapping: list[int | None] = [None] * (len(source_text) + 1)
    mapping[0] = 0
    for tag, source_start, source_end, target_start, target_end in Levenshtein.opcodes(
        source_text, target_text
    ).as_list():
        source_length = source_end - source_start
        target_length = target_end - target_start
        if tag == "insert":
            # Attach a boundary insertion to the segment on its left (except at
            # offset zero, where it naturally belongs to the first segment).
            mapping[source_start] = target_end if source_start > 0 else 0
            continue
        if source_length <= 0:
            continue
        for offset in range(source_length + 1):
            if tag == "equal":
                projected = target_start + offset
            elif tag == "delete":
                projected = target_start
            else:
                projected = target_start + round(offset * target_length / source_length)
            index = source_start + offset
            previous = mapping[index]
            mapping[index] = projected if previous is None else max(previous, projected)
    mapping[-1] = len(target_text)
    last = 0
    for index, value in enumerate(mapping):
        if value is None:
            value = round(index * len(target_text) / max(1, len(source_text)))
        last = max(last, min(len(target_text), int(value)))
        mapping[index] = last

    boundaries = [0]
    cursor = 0
    for segment in segments:
        cursor += len(segment.text)
        projected = mapping[cursor]
        assert projected is not None
        boundaries.append(int(projected))
    boundaries[-1] = len(target_text)
    output = [
        replace(segment, text=target_text[boundaries[index] : boundaries[index + 1]])
        for index, segment in enumerate(segments)
    ]
    if "".join(segment.text for segment in output) != target_text:
        raise AssertionError("normalized segment projection must preserve document text")
    return output

# ``系`` is a valid character in technical/kinship compounds.  These terms are
# deliberately protected before applying the small, context-bound copula rules
# below; this is not a global ``系 -> 係`` replacement.
NON_COPULA_SYSTEM_TERMS = (
    "銀河系",
    "生態系",
    "系學會",
    "系辦公室",
    "系主任",
    "本科系",
    "系統",
    "系列",
    "體系",
    "父系",
    "母系",
    "直系",
    "旁系",
    "語系",
    "水系",
    "星系",
    "系數",
    "學系",
    "院系",
    "科系",
    "全系",
    "本系",
    "外系",
    "跨系",
    "轉系",
    "系所",
    "系館",
    "系辦",
    "系務",
    "系級",
    "系友",
    "系隊",
    "系譜",
    "系別",
)

_INLINE_SPACE = r"[ \t\u3000]*"
_CLAUSE_BOUNDARY = r"(?:^|[，。！？、；：,.!?\s])"
_COPULA_LEFT_CONTEXTS = (
    "我哋",
    "你哋",
    "佢哋",
    "呢個",
    "嗰個",
    "呢啲",
    "嗰啲",
    "邊個",
    "乜嘢",
    "其實",
    "可能",
    "一定",
    "應該",
    "原來",
    "總之",
    "所以",
    "因為",
    "如果",
    "通常",
    "始終",
    "反而",
    "同埋",
    "件事",
    "印象中",
    "重點",
    "頭尾位",
    "純粹",
    "睇下",
    "認得",
    "覺得",
    "咧",
    "我",
    "你",
    "妳",
    "佢",
    "即",
    "就",
    "唔",
    "都",
    "只",
    "仲",
    "先",
    "但",
    "淨",
    "真",
)
_COPULA_RIGHT_CONTEXTS = (
    "點樣",
    "中意",
    "鍾意",
    "可以",
    "應該",
    "想",
    "用",
    "少",
    "多",
    "要",
    "點",
    "搵",
    "揾",
    "做",
    "講",
    "叫",
    "咪",
    "啦",
    "喇",
    "咯",
    "囉",
    "啊",
    "呀",
    "吖",
    "㗎",
    "喎",
    "啫",
    "嘛",
    "嘅",
)
_COPULA_PATTERNS = (
    # Pronouns and common Cantonese adverb/negation cues remain strong signals
    # even when an ASR engine inserts an inline space before ``系``.
    re.compile(
        rf"(?:{'|'.join(map(re.escape, _COPULA_LEFT_CONTEXTS))}){_INLINE_SPACE}系"
    ),
    # A right-hand predicate is only accepted at a clause boundary or after an
    # ASCII token.  This covers ``reels 系揾`` and ``Cloud MD系點`` without
    # corrupting department phrases such as ``會計系想招生``.
    re.compile(
        rf"(?:{_CLAUSE_BOUNDARY}|[A-Za-z0-9])系{_INLINE_SPACE}"
        rf"(?:{'|'.join(map(re.escape, _COPULA_RIGHT_CONTEXTS))})"
    ),
    # Recover short ASR replies such as ``想系啊`` and ``係啊系啊`` only when
    # both a clause/particle boundary and a following final particle agree.
    re.compile(
        rf"(?:{_CLAUSE_BOUNDARY}想|[啊呀吖啦喇囉咯嘛喎啫]){_INLINE_SPACE}系"
        rf"{_INLINE_SPACE}(?:啊|呀|吖|啦|喇|囉|咯|嘛|喎|啫)"
    ),
    # ``系會`` is especially ambiguous with a department association.  Only
    # accept it at a clause boundary; ``會計系會開會`` remains untouched.
    re.compile(rf"{_CLAUSE_BOUNDARY}系{_INLINE_SPACE}會"),
)
_COPULA_REPLY_PATTERN = re.compile(
    rf"{_CLAUSE_BOUNDARY}(?:(?:繫{_INLINE_SPACE})?系(?:{_INLINE_SPACE}系)*)"
    rf"(?=(?:啊|呀|吖|啦|喇|囉|咯|嘛|喎|啫)?(?:$|[，。！？；,.!?;]))"
)
_COPULA_REPEAT_AFTER_DISCOURSE_PATTERN = re.compile(
    rf"(?<=[好哦喂誒])(?:[繫系](?:{_INLINE_SPACE}[繫系])+)(?=$|[啊呀吖啦喇囉咯嘛喎啫，。！？；,.!?;])"
)
_COPULA_REPLY_CHAIN_PATTERN = re.compile(
    rf"{_CLAUSE_BOUNDARY}"
    rf"(?:(?:[係繫系]){_INLINE_SPACE}(?:啊|呀|吖|啦|喇|囉|咯|嘛|喎|啫)?{_INLINE_SPACE}){{2,}}"
    rf"(?=$|[，。！？；,.!?;])"
)
_MISCONVERTED_NEGATIVE_COPULA_PATTERN = re.compile(
    rf"唔{_INLINE_SPACE}繫{_INLINE_SPACE}"
    rf"(?=(?:可以|應該|需要|知道|明白|有|冇|要|會|想|係|好|得|使))"
)

_FINAL_PUNCTUATION_OR_SPACE = r"(?:$|[，。！？、；：,.!?\s])"
_GA_BARE_LEFT_CONTEXTS = (
    "可以",
    "應該",
    "一定",
    "係",
    "得",
    "有",
    "嚟",
    "做",
    "講",
    "話",
    "要",
    "想",
    "會",
    "好",
    "啱",
    "真",
    "假",
    "快",
    "慢",
    "多",
    "少",
    "完",
    "晒",
    "咗",
    "唔",
    "冇",
)
_ASPECTUAL_SAAI_VERBS = (
    "搞掂",
    "處理",
    "清理",
    "刪除",
    "完成",
    "用",
    "俾",
    "畀",
    "食",
    "飲",
    "做",
    "講",
    "睇",
    "聽",
    "寫",
    "讀",
    "使",
    "花",
    "買",
    "賣",
    "拎",
    "攞",
    "執",
    "整",
    "搞",
    "清",
    "刪",
    "走",
    "死",
    "冇",
    "輸",
    "贏",
    "叫",
    "搵",
    "揾",
    "影",
    "拍",
    "剪",
    "交",
)
_ASPECTUAL_SAAI_FOLLOWERS = (
    "佢哋",
    "我哋",
    "你哋",
    "所有",
    "全部",
    "成個",
    "成班",
    "佢",
    "我",
    "你",
    "啲",
    "嗰",
    "呢",
    "先",
    "啦",
    "喇",
    "㗎",
    "囉",
    "咯",
    "喎",
    "啫",
    "嘛",
    "呀",
    "啊",
    "吖",
)
_PARTICLE_RULES = (
    # Mainland ASR lexicons often spell the Cantonese topic/final particle as
    # ``咧``.  Convert only at a clause boundary or before a short Cantonese
    # continuation; lexical Mandarin forms such as ``咧嘴`` remain unchanged.
    (
        re.compile(
            rf"咧(?=(?:{_FINAL_PUNCTUATION_OR_SPACE}|系|係|繫|誒|啊|哦|咁|我|你|佢|就|應該))"
        ),
        "咧",
        "呢",
        "cantonese_final_particle",
    ),
    # ``噶`` is changed only when Cantonese sentence-final grammar is explicit.
    # This intentionally leaves names such as 噶瑪蘭 and 噶舉派 untouched.
    (
        re.compile(
            rf"噶(?=(?:嘛|喎|啦|喇|啫|咩|呀|啊|吖){_FINAL_PUNCTUATION_OR_SPACE})"
        ),
        "噶",
        "㗎",
        "cantonese_final_particle",
    ),
    (
        re.compile(
            rf"(?:{'|'.join(map(re.escape, _GA_BARE_LEFT_CONTEXTS))})噶"
            rf"(?={_FINAL_PUNCTUATION_OR_SPACE})"
        ),
        "噶",
        "㗎",
        "cantonese_final_particle",
    ),
    (
        re.compile(rf"(?<=[A-Za-z0-9 \t\u3000])噶(?={_FINAL_PUNCTUATION_OR_SPACE})"),
        "噶",
        "㗎",
        "cantonese_final_particle",
    ),
    # ``咯`` is a Cantonese final particle at a clause boundary.  The negative
    # look-behind protects the chemical/lexical word ``吡咯``.
    (
        re.compile(rf"(?<!吡)咯(?={_FINAL_PUNCTUATION_OR_SPACE})"),
        "咯",
        "囉",
        "cantonese_final_particle",
    ),
    # ASR frequently omits punctuation between a final particle and the next
    # short clause.  A following Cantonese clause cue makes the reading safe;
    # lexical words such as 咯血／咯痰／咯咯笑 and 吡咯 remain unmatched.
    (
        re.compile(
            rf"(?<!吡)咯(?={_INLINE_SPACE}(?:"
            rf"可以|就|我|你|佢|先|但|即|咁|咪|都|會|要|想|得|唔|冇|係|系))"
        ),
        "咯",
        "囉",
        "cantonese_final_particle",
    ),
    # ``曬`` is also a standard word in 日曬／曝曬.  Convert it only after a
    # high-confidence aspectual verb and before a pronoun, quantifier, final
    # particle or clause ending.
    (
        re.compile(
            rf"(?:{'|'.join(map(re.escape, _ASPECTUAL_SAAI_VERBS))})"
            rf"(?:唔|撚|埋|鬼)?{_INLINE_SPACE}曬"
            rf"(?={_INLINE_SPACE}(?:"
            rf"{'|'.join(map(re.escape, _ASPECTUAL_SAAI_FOLLOWERS))}"
            rf"|$|[，。！？、；：,.!?]))"
        ),
        "曬",
        "晒",
        "cantonese_aspect_particle",
    ),
)
_ASCII_VOCABULARY_KEY = re.compile(r"[^a-z0-9]+")
_CANONICAL_VOCABULARY_PATTERNS = {
    "antigravity": (
        "Antigravity",
        re.compile(r"(?<![A-Za-z0-9])anti(?:[\s_-]*)gravity(?![A-Za-z0-9])", re.IGNORECASE),
    ),
    "igreels": (
        "IG Reels",
        re.compile(r"(?<![A-Za-z0-9])ig(?:[\s_-]*)reels(?![A-Za-z0-9])", re.IGNORECASE),
    ),
}


@dataclass(frozen=True)
class NormalizationDecision:
    before: str
    after: str
    reason: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


class HongKongNormalizer:
    """OpenCC s2hk conversion with collision-safe protected vocabulary placeholders."""

    def __init__(self, protected_vocabulary: Iterable[str] = ()) -> None:
        terms = {*BUILTIN_PROTECTED_CANTONESE, *(term for term in protected_vocabulary if term)}
        self.protected_vocabulary = tuple(sorted(terms, key=lambda value: (-len(value), value)))
        self._converter = OpenCC("s2hk")

    @staticmethod
    def _placeholder(text: str, term: str, index: int) -> str:
        digest = hashlib.blake2s(f"{index}\0{term}".encode("utf-8"), digest_size=8).hexdigest()
        placeholder = f"\ue000CTS{digest}\ue001"
        salt = 0
        while placeholder in text:
            salt += 1
            placeholder = f"\ue000CTS{digest}{salt:x}\ue001"
        return placeholder

    def normalize(self, text: str) -> str:
        normalized, _ = self.normalize_with_audit(text)
        return normalized

    @staticmethod
    def _protected_system_ranges(text: str) -> tuple[tuple[int, int], ...]:
        ranges: list[tuple[int, int]] = []
        for term in NON_COPULA_SYSTEM_TERMS:
            start = 0
            while True:
                index = text.find(term, start)
                if index < 0:
                    break
                ranges.append((index, index + len(term)))
                start = index + 1
        return tuple(ranges)

    @staticmethod
    def _is_protected_index(index: int, ranges: tuple[tuple[int, int], ...]) -> bool:
        return any(start <= index < end for start, end in ranges)

    def _canonicalize_copulas(
        self,
        text: str,
        decisions: list[NormalizationDecision],
    ) -> str:
        # OpenCC treats repeated ``系系`` as ``繫系``.  At a complete clause
        # boundary these forms are unambiguously affirmative replies.  Keep the
        # rule bounded on both sides so ``會計系。`` and ``太陽系。`` are safe.
        def replace_reply_copulas(match: re.Match[str]) -> str:
            matched = match.group(0)
            replacement = matched.replace("繫", "係").replace("系", "係")
            if replacement != matched:
                decisions.append(
                    NormalizationDecision(
                        before=matched,
                        after=replacement,
                        reason="cantonese_copula",
                    )
                )
            return replacement

        text = _COPULA_REPLY_PATTERN.sub(replace_reply_copulas, text)
        text = _COPULA_REPLY_CHAIN_PATTERN.sub(replace_reply_copulas, text)
        # Telephone greetings and acknowledgement fillers often arrive without
        # punctuation (for example ``好系系系系，請講``).  OpenCC can turn that
        # run into alternating ``繫系`` characters.  Two-or-more repeated forms
        # immediately after a discourse cue are still an unambiguous Cantonese
        # affirmative response, while a single lexical ``繫`` remains untouched.
        text = _COPULA_REPEAT_AFTER_DISCOURSE_PATTERN.sub(
            replace_reply_copulas,
            text,
        )

        # OpenCC can also emit ``唔繫`` from an ASR ``唔系`` sequence.  Require
        # a following copular predicate so the literal verb in ``唔繫安全帶``
        # is never changed.
        def replace_misconverted_negative_copula(match: re.Match[str]) -> str:
            matched = match.group(0)
            relative_index = matched.index("繫")
            replacement = matched[:relative_index] + "係" + matched[relative_index + 1:]
            decisions.append(
                NormalizationDecision(
                    before=matched,
                    after=replacement,
                    reason="cantonese_copula",
                )
            )
            return replacement

        text = _MISCONVERTED_NEGATIVE_COPULA_PATTERN.sub(
            replace_misconverted_negative_copula,
            text,
        )

        # Every replacement is one code point, so ranges remain valid across
        # the sequential patterns.
        protected_ranges = self._protected_system_ranges(text)
        for pattern in _COPULA_PATTERNS:
            def replace_copula(match: re.Match[str]) -> str:
                matched = match.group(0)
                relative_index = matched.index("系")
                absolute_index = match.start() + relative_index
                if self._is_protected_index(absolute_index, protected_ranges):
                    return matched
                replacement = matched[:relative_index] + "係" + matched[relative_index + 1:]
                if replacement != matched:
                    decisions.append(
                        NormalizationDecision(
                            before=matched,
                            after=replacement,
                            reason="cantonese_copula",
                        )
                    )
                return replacement

            text = pattern.sub(replace_copula, text)
        return text

    def _canonicalize_vocabulary(
        self,
        text: str,
        decisions: list[NormalizationDecision],
    ) -> str:
        vocabulary_keys = {
            _ASCII_VOCABULARY_KEY.sub("", term.casefold())
            for term in self.protected_vocabulary
            if term.isascii()
        }
        for key, (canonical, pattern) in _CANONICAL_VOCABULARY_PATTERNS.items():
            if key not in vocabulary_keys:
                continue

            def replace_vocabulary(match: re.Match[str]) -> str:
                matched = match.group(0)
                if matched != canonical:
                    decisions.append(
                        NormalizationDecision(
                            before=matched,
                            after=canonical,
                            reason="vocabulary_canonicalization",
                        )
                    )
                return canonical

            text = pattern.sub(replace_vocabulary, text)

        # Every all-ASCII vocabulary item supplied by the user is also an
        # exact, closed-world spelling hint.  Canonicalize only the same
        # alphanumeric sequence, allowing ASR-inserted spaces/hyphens between
        # characters (``run down`` -> ``Rundown`` and ``check point`` ->
        # ``checkpoint``).  This is deliberately not phonetic fuzzy matching:
        # it cannot invent a vocabulary term that no engine actually emitted.
        separator = r"[\s_-]*"
        for canonical in self.protected_vocabulary:
            if not canonical.isascii() or not any(character.isalnum() for character in canonical):
                continue
            collapsed = "".join(character for character in canonical if character.isalnum())
            if len(collapsed) < 2:
                continue
            flexible = separator.join(re.escape(character) for character in collapsed)
            pattern = re.compile(
                rf"(?<![A-Za-z0-9]){flexible}(?![A-Za-z0-9])",
                re.IGNORECASE,
            )

            def replace_general_vocabulary(match: re.Match[str]) -> str:
                matched = match.group(0)
                if matched != canonical:
                    decisions.append(
                        NormalizationDecision(
                            before=matched,
                            after=canonical,
                            reason="vocabulary_canonicalization",
                        )
                    )
                return canonical

            text = pattern.sub(replace_general_vocabulary, text)
        return text

    def _canonicalize_particles(
        self,
        text: str,
        decisions: list[NormalizationDecision],
    ) -> str:
        for pattern, source, replacement, reason in _PARTICLE_RULES:
            def replace_particle(match: re.Match[str]) -> str:
                matched = match.group(0)
                relative_index = matched.rfind(source)
                if relative_index < 0:  # Defensive guard for future rule edits.
                    return matched
                normalized = (
                    matched[:relative_index]
                    + replacement
                    + matched[relative_index + len(source):]
                )
                if normalized != matched:
                    decisions.append(
                        NormalizationDecision(
                            before=matched,
                            after=normalized,
                            reason=reason,
                        )
                    )
                return normalized

            text = pattern.sub(replace_particle, text)
        return text

    def normalize_with_audit(
        self,
        text: str,
    ) -> tuple[str, tuple[NormalizationDecision, ...]]:
        decisions: list[NormalizationDecision] = []
        # Repair bounded Cantonese copulas before OpenCC sees them.  Otherwise
        # s2hk can first turn ``反而系``／``好系系`` into lexical ``繫`` forms,
        # which destroys the original copula evidence.  A second pass below
        # handles phrase conversions produced by OpenCC itself.
        protected_text = self._canonicalize_copulas(text, decisions)
        replacements: list[tuple[str, str]] = []
        # OpenCC has phrase-level mappings such as ``就系 -> 就係``.  Protect
        # valid ``系`` compounds before conversion as well as before our own
        # copula pass, otherwise ``就系統而言`` becomes ``就係統而言`` before
        # the context-aware rules get a chance to inspect it.
        protected_terms = tuple(
            sorted(
                {*self.protected_vocabulary, *NON_COPULA_SYSTEM_TERMS},
                key=lambda value: (-len(value), value),
            )
        )
        for index, term in enumerate(protected_terms):
            if term not in protected_text:
                continue
            placeholder = self._placeholder(protected_text, term, index)
            protected_text = protected_text.replace(term, placeholder)
            replacements.append((placeholder, term))

        converted = self._converter.convert(protected_text)
        for placeholder, term in replacements:
            converted = converted.replace(placeholder, term)

        converted = self._canonicalize_copulas(converted, decisions)
        converted = self._canonicalize_particles(converted, decisions)
        converted = self._canonicalize_vocabulary(converted, decisions)
        return converted, tuple(decisions)

    def normalize_segment(self, segment: ReconciledSegment) -> ReconciledSegment:
        return replace(segment, text=self.normalize(segment.text))

    def normalize_document(self, document: TranscriptDocument) -> TranscriptDocument:
        normalized_text, document_decisions = self.normalize_with_audit(document.text)
        normalized_segments: list[ReconciledSegment] = []
        segment_audit: list[dict[str, object]] = []
        for index, segment in enumerate(document.segments):
            normalized_segment_text, decisions = self.normalize_with_audit(segment.text)
            normalized_segments.append(replace(segment, text=normalized_segment_text))
            if decisions:
                segment_audit.append(
                    {
                        "segment_index": index,
                        "start_ms": segment.start_ms,
                        "end_ms": segment.end_ms,
                        "decisions": [decision.to_dict() for decision in decisions],
                    }
                )

        segmentwise_text = "".join(segment.text for segment in normalized_segments)
        reprojected = segmentwise_text != normalized_text
        if reprojected:
            normalized_segments = _project_segment_boundaries(
                normalized_segments, normalized_text
            )

        metadata = dict(document.metadata)
        existing_audit = metadata.get("normalization_audit")
        existing_audit_is_current = (
            isinstance(existing_audit, dict)
            and existing_audit.get("policy_version") == HK_NORMALIZATION_POLICY_VERSION
        )
        if document_decisions or segment_audit or not existing_audit_is_current:
            metadata["normalization_audit"] = {
                "policy_version": HK_NORMALIZATION_POLICY_VERSION,
                "document_decisions": [decision.to_dict() for decision in document_decisions],
                "segments": segment_audit,
                "segment_boundary_projection": {
                    "applied": reprojected,
                    "method": "levenshtein_boundary_projection" if reprojected else "identity",
                    "segment_count": len(normalized_segments),
                    "source_length": len(segmentwise_text),
                    "target_length": len(normalized_text),
                },
            }
        return replace(
            document,
            text=normalized_text,
            segments=tuple(normalized_segments),
            metadata=metadata,
        )


def normalize_text(text: str, protected_vocabulary: Iterable[str] = ()) -> str:
    return HongKongNormalizer(protected_vocabulary).normalize(text)


def normalize_document(document: TranscriptDocument) -> TranscriptDocument:
    return HongKongNormalizer(document.vocabulary).normalize_document(document)


__all__ = [
    "BUILTIN_PROTECTED_CANTONESE",
    "HK_NORMALIZATION_POLICY_VERSION",
    "HongKongNormalizer",
    "NON_COPULA_SYSTEM_TERMS",
    "NormalizationDecision",
    "normalize_document",
    "normalize_text",
]
