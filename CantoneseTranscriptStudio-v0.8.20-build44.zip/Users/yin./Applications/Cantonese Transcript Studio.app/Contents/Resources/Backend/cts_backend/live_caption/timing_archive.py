"""Opt-in, local-only source-audio receipts for later live timing review.

The live caption path normally retains no microphone recording.  When an
operator explicitly opts in, this module preserves only PCM frames that the
bounded live queue actually accepted, plus an exact capture-timeline map for
rejected frames.  It intentionally does *not* invoke an aligner, infer timing,
or mutate a subtitle project.  A later reviewer must independently verify the
published bytes and decide whether any candidate is usable.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import stat
import tempfile
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping


LIVE_TIMING_ARCHIVE_SCHEMA = "cts.live_timing_archive/v1"
LIVE_TIMING_ARCHIVE_MANIFEST = "manifest.json"
LIVE_TIMING_ARCHIVE_AUDIO = "accepted.pcm16le"
LIVE_TIMING_ARCHIVE_RECEIPT_SCHEMA = "cts.live_timing_archive_receipt/v1"
LIVE_TIMING_ARCHIVE_STAGING_DIRECTORY = "LiveTimingArchiveStaging"
LIVE_TIMING_ARCHIVE_RECEIPTS_DIRECTORY = "LiveTimingArchiveReceipts"
LIVE_TIMING_ARCHIVE_OUTPUT_DIRECTORY = "LiveTimingArchives"
LIVE_TIMING_ARCHIVE_INTEGRITY_SCOPE = (
    "detached_local_hash_receipt_not_keychain_sealed"
)
_STAGING_DIRECTORY_PREFIX = ".live-timing-"
_STAGING_MARKER = ".timing-archive-staging.json"
_STAGING_MARKER_SCHEMA = "cts.live_timing_archive_staging/v1"
_CHUNK_KEYS = frozenset(
    {
        "id",
        "kind",
        "timeline_start_sample",
        "timeline_end_sample",
        "accepted_start_sample",
        "accepted_end_sample",
        "archive_byte_start",
        "archive_byte_end",
        "sha256",
    }
)
_MANIFEST_KEYS = frozenset(
    {
        "schema",
        "session_id",
        "local_only",
        "review_only",
        "automatic_timestamp_mutation",
        "candidate_state",
        "source_audio",
        "capture_timeline",
    }
)
_SOURCE_AUDIO_KEYS = frozenset(
    {"filename", "encoding", "channels", "byte_count", "sample_count", "sha256"}
)
_TIMELINE_KEYS = frozenset(
    {
        "domain",
        "sample_rate_hz",
        "total_offered_samples",
        "accepted_samples",
        "dropped_samples",
        "chunks",
    }
)
_STAGING_MARKER_KEYS = frozenset({"schema", "session_id"})
_DETACHED_RECEIPT_KEYS = frozenset(
    {
        "schema",
        "session_id",
        "archive_manifest_sha256",
        "source_audio_sha256",
        "local_only",
        "review_only",
        "automatic_timestamp_mutation",
        "candidate_state",
        "integrity_scope",
    }
)


def _canonical_session_id(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("timing archive session_id 無效")
    try:
        return str(uuid.UUID(value))
    except (ValueError, AttributeError) as exc:
        raise ValueError("timing archive session_id 無效") from exc


def _nonnegative_int(value: object, *, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field_name} 無效")
    return value


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1_048_576), b""):
            digest.update(block)
    return digest.hexdigest()


def _is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
    except ValueError:
        return False
    return True


def _canonical_existing_directory(path: Path, *, field_name: str) -> Path:
    """Return a non-symlinked directory without crossing a symlinked parent."""

    absolute = Path(os.path.abspath(Path(path).expanduser()))
    if absolute.is_symlink() or not absolute.is_dir():
        raise ValueError(f"{field_name} 無效")
    resolved = absolute.resolve(strict=True)
    if resolved != absolute:
        raise ValueError(f"{field_name} 唔可以經 symlink")
    return resolved


def _ensure_owned_directory(path: Path) -> Path:
    absolute = Path(os.path.abspath(Path(path).expanduser()))
    absolute.mkdir(mode=0o700, parents=True, exist_ok=True)
    if absolute.is_symlink() or not absolute.is_dir():
        raise ValueError("timing archive storage path 無效")
    resolved = absolute.resolve(strict=True)
    if resolved != absolute:
        raise ValueError("timing archive storage path 唔可以經 symlink")
    try:
        os.chmod(resolved, 0o700)
    except OSError as exc:
        raise ValueError("timing archive storage path 權限無效") from exc
    if resolved.stat().st_uid != os.geteuid():
        raise ValueError("timing archive storage path 唔屬於目前使用者")
    return resolved


def _fsync_directory(path: Path) -> str | None:
    descriptor: int | None = None
    try:
        descriptor = os.open(path, os.O_RDONLY)
        os.fsync(descriptor)
    except OSError:
        return "directory_fsync_failed_after_atomic_publish"
    finally:
        if descriptor is not None:
            os.close(descriptor)
    return None


def _atomic_json_write(path: Path, value: Mapping[str, Any]) -> None:
    descriptor, temporary_name = tempfile.mkstemp(prefix=".manifest-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, path)
    except BaseException:
        try:
            Path(temporary_name).unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _staging_directory_name(session_id: str) -> str:
    return f"{_STAGING_DIRECTORY_PREFIX}{session_id}-"


def _safe_staging_directory(
    staging_root: Path,
    candidate: Path,
    *,
    session_id: str,
) -> Path | None:
    """Accept only our one direct, non-symlink staging child."""

    root = _canonical_existing_directory(
        staging_root, field_name="timing archive staging root"
    )
    raw = Path(candidate).expanduser()
    expected_prefix = _staging_directory_name(_canonical_session_id(session_id))
    if (
        not raw.name.startswith(expected_prefix)
        or raw.name == expected_prefix
        or raw.is_symlink()
        or not raw.is_dir()
    ):
        return None
    try:
        parent = _canonical_existing_directory(
            raw.parent, field_name="timing archive staging parent"
        )
        resolved = raw.resolve(strict=True)
    except (OSError, ValueError):
        return None
    if parent != root or resolved.parent != root or resolved.is_symlink():
        return None
    return resolved


def _read_staging_marker(staging_directory: Path) -> str | None:
    marker = staging_directory / _STAGING_MARKER
    if marker.is_symlink() or not marker.is_file():
        return None
    try:
        value = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or set(value) != _STAGING_MARKER_KEYS:
        return None
    if value.get("schema") != _STAGING_MARKER_SCHEMA:
        return None
    try:
        session_id = _canonical_session_id(value.get("session_id"))
    except ValueError:
        return None
    return session_id if value.get("session_id") == session_id else None


def _write_staging_marker(staging_directory: Path, *, session_id: str) -> None:
    """Create a durable ownership marker for crash/pending-commit cleanup."""

    marker = staging_directory / _STAGING_MARKER
    descriptor = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(
                {"schema": _STAGING_MARKER_SCHEMA, "session_id": session_id},
                stream,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        # A marker file alone is not enough after a power loss: its directory
        # entry must also be durable before raw PCM can be captured beneath it.
        if _fsync_directory(staging_directory) is not None:
            raise OSError("timing archive staging marker directory sync failed")
    except BaseException:
        try:
            marker.unlink(missing_ok=True)
            _fsync_directory(staging_directory)
        except OSError:
            pass
        raise


def _remove_staging_marker(directory: Path) -> None:
    marker = directory / _STAGING_MARKER
    if marker.is_symlink() or not marker.is_file():
        raise ValueError("timing archive staging marker 無效")
    marker.unlink()


def _directory_identity(path: Path) -> tuple[int, int]:
    value = os.lstat(path)
    if not stat.S_ISDIR(value.st_mode):
        raise ValueError("timing archive directory 無效")
    return (value.st_dev, value.st_ino)


def _rmtree_direct_child(root: Path, name: str) -> bool:
    """Delete one known direct child through a protected directory FD only."""

    if (
        not name
        or Path(name).name != name
        or name in {".", ".."}
        or not getattr(shutil.rmtree, "avoids_symlink_attacks", False)
    ):
        return False
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
    descriptor: int | None = None
    try:
        descriptor = os.open(root, flags)
        child = os.stat(name, dir_fd=descriptor, follow_symlinks=False)
        if not stat.S_ISDIR(child.st_mode):
            return False
        shutil.rmtree(name, dir_fd=descriptor)
        # Deletion is not a privacy proof until the parent directory has been
        # synced.  A false result means the caller must report retention as
        # possible, even if this process can no longer see the directory.
        return _fsync_directory(root) is None
    except OSError:
        return False
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _discard_staging_directory(
    staging_root: Path,
    path: Path,
    *,
    session_id: str,
    require_marker: bool,
) -> bool:
    """Erase a known private staging directory, never an arbitrary path."""

    try:
        root = _canonical_existing_directory(
            staging_root, field_name="timing archive staging root"
        )
        directory = _safe_staging_directory(root, path, session_id=session_id)
    except ValueError:
        return False
    if directory is None:
        return False
    if require_marker and _read_staging_marker(directory) != _canonical_session_id(session_id):
        return False
    return _rmtree_direct_child(root, directory.name)


@dataclass(frozen=True)
class LiveTimingArchiveStagingRecovery:
    """Aggregate-only startup cleanup result; it never exposes audio paths."""

    removed_count: int
    skipped_count: int
    failed_count: int


@dataclass(frozen=True)
class LiveTimingArchivePublicationRecovery:
    """Aggregate-only cleanup of a crash-interrupted pending publication."""

    removed_count: int
    skipped_count: int
    failed_count: int


def recover_stale_live_timing_archive_staging(
    runtime_root: Path,
) -> LiveTimingArchiveStagingRecovery:
    """Remove only marked, abandoned opt-in staging directories after worker lock."""

    runtime = _canonical_existing_directory(
        runtime_root, field_name="timing archive runtime root"
    )
    staging_root = runtime / LIVE_TIMING_ARCHIVE_STAGING_DIRECTORY
    if not staging_root.exists():
        return LiveTimingArchiveStagingRecovery(0, 0, 0)
    if staging_root.is_symlink() or not staging_root.is_dir():
        raise ValueError("timing archive staging root 無效")
    staging_root = _canonical_existing_directory(
        staging_root, field_name="timing archive staging root"
    )
    if staging_root.parent != runtime:
        raise ValueError("timing archive staging root 位置無效")
    removed = 0
    skipped = 0
    failed = 0
    for candidate in staging_root.iterdir():
        if candidate.is_symlink() or not candidate.is_dir():
            skipped += 1
            continue
        marker_session_id = _read_staging_marker(candidate)
        if marker_session_id is None:
            skipped += 1
            continue
        directory = _safe_staging_directory(
            staging_root, candidate, session_id=marker_session_id
        )
        if directory is None:
            skipped += 1
            continue
        if _discard_staging_directory(
            staging_root,
            directory,
            session_id=marker_session_id,
            require_marker=True,
        ):
            removed += 1
        else:
            failed += 1
    return LiveTimingArchiveStagingRecovery(removed, skipped, failed)


def recover_pending_live_timing_archive_publications(
    jobs_root: Path,
) -> LiveTimingArchivePublicationRecovery:
    """Erase only a crash-interrupted archive that still carries our marker.

    A clean archive is committed by removing its marker only after the moved
    bytes and detached receipt have both passed verification.  Therefore this
    startup pass never scans or deletes a normal published archive; it looks
    only at one direct canonical-UUID child that still has a matching marker.
    """

    jobs = _canonical_existing_directory(
        jobs_root, field_name="timing archive jobs root"
    )
    output_root = jobs / LIVE_TIMING_ARCHIVE_OUTPUT_DIRECTORY
    if not output_root.exists():
        return LiveTimingArchivePublicationRecovery(0, 0, 0)
    if output_root.is_symlink() or not output_root.is_dir():
        raise ValueError("timing archive output root 無效")
    output_root = _canonical_existing_directory(
        output_root, field_name="timing archive output root"
    )
    if output_root.parent != jobs:
        raise ValueError("timing archive output root 位置無效")
    receipt_root = jobs / LIVE_TIMING_ARCHIVE_RECEIPTS_DIRECTORY
    if receipt_root.exists():
        if receipt_root.is_symlink() or not receipt_root.is_dir():
            raise ValueError("timing archive receipt root 無效")
        receipt_root = _canonical_existing_directory(
            receipt_root, field_name="timing archive receipt root"
        )
        if receipt_root.parent != jobs:
            raise ValueError("timing archive receipt root 位置無效")
    else:
        receipt_root = None

    removed = 0
    skipped = 0
    failed = 0
    for candidate in output_root.iterdir():
        if candidate.is_symlink() or not candidate.is_dir():
            continue
        try:
            session_id = _canonical_session_id(candidate.name)
        except ValueError:
            continue
        if _read_staging_marker(candidate) != session_id:
            # A marker-free archive is a completed receipt or unrelated
            # content. It is explicitly outside crash cleanup authority.
            continue
        directory = _safe_published_directory(
            output_root, candidate, session_id=session_id
        )
        if directory is None:
            failed += 1
            continue
        try:
            identity = _directory_identity(directory)
        except OSError:
            failed += 1
            continue
        receipt_sha256 = (
            None
            if receipt_root is None
            else _detached_receipt_sha256_for_session(
                receipt_root,
                session_id=session_id,
            )
        )
        if not _discard_published_directory(
            output_root,
            session_id=session_id,
            expected_identity=identity,
        ):
            failed += 1
            continue
        removed += 1
        # A receipt is metadata rather than raw audio. Only remove one when
        # its full schema and session identity prove it belongs to this
        # pending archive; otherwise preserve it and make no cleanup claim.
        if receipt_sha256 is not None and receipt_root is not None:
            if not _discard_detached_receipt(
                receipt_root,
                session_id=session_id,
                expected_sha256=receipt_sha256,
            ):
                skipped += 1
    return LiveTimingArchivePublicationRecovery(removed, skipped, failed)


@dataclass
class _ArchiveChunk:
    id: str
    kind: str
    timeline_start_sample: int
    timeline_end_sample: int
    accepted_start_sample: int | None
    accepted_end_sample: int | None
    archive_byte_start: int | None
    archive_byte_end: int | None
    digest: Any | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "kind": self.kind,
            "timeline_start_sample": self.timeline_start_sample,
            "timeline_end_sample": self.timeline_end_sample,
            "accepted_start_sample": self.accepted_start_sample,
            "accepted_end_sample": self.accepted_end_sample,
            "archive_byte_start": self.archive_byte_start,
            "archive_byte_end": self.archive_byte_end,
            "sha256": None if self.digest is None else self.digest.hexdigest(),
        }


@dataclass(frozen=True)
class LiveTimingArchiveVerification:
    """A byte-level verification result, never a timing verdict."""

    directory: Path
    manifest: dict[str, Any]
    manifest_sha256: str


@dataclass(frozen=True)
class LiveTimingArchiveIntervalProjection:
    """Projection from compact accepted PCM back to real capture samples.

    ``exact`` is deliberately limited to one uninterrupted accepted chunk.
    A Wenet interval that straddles a queue-drop gap cannot be stretched or
    interpolated into original capture time and is therefore unassessable.
    """

    status: str
    accepted_start_sample: int
    accepted_end_sample: int
    timeline_start_sample: int | None
    timeline_end_sample: int | None
    reason_codes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "accepted_start_sample": self.accepted_start_sample,
            "accepted_end_sample": self.accepted_end_sample,
            "timeline_start_sample": self.timeline_start_sample,
            "timeline_end_sample": self.timeline_end_sample,
            "reason_codes": list(self.reason_codes),
            "automatic_timestamp_mutation": False,
        }


@dataclass(frozen=True)
class LiveTimingArchiveDetachedReceiptVerification:
    """A separate local hash receipt, explicitly not a cryptographic seal."""

    archive_verification: LiveTimingArchiveVerification
    receipt_path: Path
    receipt_sha256: str
    integrity_scope: str


class LiveTimingArchivePublicationError(RuntimeError):
    """A failed finalization that tells the caller whether raw PCM was erased."""

    def __init__(
        self,
        message: str,
        *,
        raw_audio_cleanup_succeeded: bool,
        receipt_cleanup_succeeded: bool,
    ) -> None:
        super().__init__(message)
        self.raw_audio_cleanup_succeeded = raw_audio_cleanup_succeeded
        self.receipt_cleanup_succeeded = receipt_cleanup_succeeded


def _safe_published_directory(
    output_root: Path,
    candidate: Path,
    *,
    session_id: str,
) -> Path | None:
    root = _canonical_existing_directory(
        output_root, field_name="timing archive output root"
    )
    canonical_session_id = _canonical_session_id(session_id)
    raw = Path(candidate).expanduser()
    if raw.name != canonical_session_id or raw.is_symlink() or not raw.is_dir():
        return None
    try:
        parent = _canonical_existing_directory(
            raw.parent, field_name="timing archive output parent"
        )
        resolved = raw.resolve(strict=True)
    except (OSError, ValueError):
        return None
    if parent != root or resolved.parent != root or resolved.is_symlink():
        return None
    return resolved


def _discard_published_directory(
    output_root: Path,
    *,
    session_id: str,
    expected_identity: tuple[int, int],
) -> bool:
    """Remove only the directory proven to be this publication's raw PCM."""

    try:
        root = _canonical_existing_directory(
            output_root, field_name="timing archive output root"
        )
    except ValueError:
        return False
    destination = root / _canonical_session_id(session_id)
    if not destination.exists():
        return True
    directory = _safe_published_directory(
        root, destination, session_id=session_id
    )
    if directory is None:
        return False
    try:
        if _directory_identity(directory) != expected_identity:
            return False
    except OSError:
        return False
    return _rmtree_direct_child(root, directory.name)


def _detached_receipt_path(receipt_root: Path, *, session_id: str) -> Path:
    root = _canonical_existing_directory(
        receipt_root, field_name="timing archive receipt root"
    )
    return root / f"{_canonical_session_id(session_id)}.json"


def _detached_receipt_sha256_for_session(
    receipt_root: Path,
    *,
    session_id: str,
) -> str | None:
    """Return a durable-looking detached receipt only for its own session.

    Startup recovery uses this only to decide whether an orphan receipt is
    safe to remove alongside an already marker-proven pending archive.  It
    deliberately does not attempt to make a timing-validity claim.
    """

    try:
        path = _detached_receipt_path(receipt_root, session_id=session_id)
    except ValueError:
        return None
    if path.is_symlink() or not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    canonical_session_id = _canonical_session_id(session_id)
    if (
        not isinstance(value, dict)
        or set(value) != _DETACHED_RECEIPT_KEYS
        or value.get("schema") != LIVE_TIMING_ARCHIVE_RECEIPT_SCHEMA
        or value.get("session_id") != canonical_session_id
        or value.get("local_only") is not True
        or value.get("review_only") is not True
        or value.get("automatic_timestamp_mutation") is not False
        or value.get("candidate_state") != "not_run"
        or value.get("integrity_scope") != LIVE_TIMING_ARCHIVE_INTEGRITY_SCOPE
    ):
        return None
    try:
        return _sha256_file(path)
    except OSError:
        return None


def _discard_detached_receipt(
    receipt_root: Path,
    *,
    session_id: str,
    expected_sha256: str | None,
) -> bool:
    """Remove only the receipt written by this attempt, never an arbitrary file."""

    try:
        path = _detached_receipt_path(receipt_root, session_id=session_id)
    except ValueError:
        return False
    if not path.exists():
        return True
    if path.is_symlink() or not path.is_file():
        return False
    try:
        if expected_sha256 is not None and _sha256_file(path) != expected_sha256:
            return False
        path.unlink()
        return _fsync_directory(path.parent) is None
    except OSError:
        return False


def _write_detached_receipt(
    verification: LiveTimingArchiveVerification,
    *,
    receipt_root: Path,
) -> LiveTimingArchiveDetachedReceiptVerification:
    """Persist a separate local hash record before publishing raw PCM."""

    session_id = verification.manifest["session_id"]
    receipt_path = _detached_receipt_path(receipt_root, session_id=session_id)
    if receipt_path.exists() or receipt_path.is_symlink():
        raise ValueError("timing archive detached receipt 已存在或無效")
    source_audio = verification.manifest["source_audio"]
    value = {
        "schema": LIVE_TIMING_ARCHIVE_RECEIPT_SCHEMA,
        "session_id": session_id,
        "archive_manifest_sha256": verification.manifest_sha256,
        "source_audio_sha256": source_audio["sha256"],
        "local_only": True,
        "review_only": True,
        "automatic_timestamp_mutation": False,
        "candidate_state": "not_run",
        "integrity_scope": LIVE_TIMING_ARCHIVE_INTEGRITY_SCOPE,
    }
    receipt_sha256: str | None = None
    try:
        _atomic_json_write(receipt_path, value)
        if receipt_path.is_symlink() or not receipt_path.is_file():
            raise ValueError("timing archive detached receipt 無效")
        os.chmod(receipt_path, 0o600)
        receipt_sha256 = _sha256_file(receipt_path)
        if _fsync_directory(receipt_path.parent) is not None:
            raise OSError("timing archive detached receipt directory sync failed")
        return verify_live_timing_archive_detached_receipt(
            verification.directory,
            receipt_path,
        )
    except BaseException:
        _discard_detached_receipt(
            receipt_root,
            session_id=session_id,
            expected_sha256=receipt_sha256,
        )
        raise


@dataclass(frozen=True)
class LiveTimingArchivePublication:
    """A final, local receipt available only after normal session stop."""

    directory: Path
    verification: LiveTimingArchiveVerification
    detached_receipt: LiveTimingArchiveDetachedReceiptVerification
    durability_warning: str | None = None

    def status_value(self) -> dict[str, Any]:
        timeline = self.verification.manifest["capture_timeline"]
        source_audio = self.verification.manifest["source_audio"]
        return {
            "enabled": True,
            "state": "published",
            "local_only": True,
            "review_only": True,
            "automatic_timestamp_mutation": False,
            "candidate_state": "not_run",
            "integrity_scope": self.detached_receipt.integrity_scope,
            "archive_id": self.verification.manifest["session_id"],
            "source_audio_sha256": source_audio["sha256"],
            "manifest_sha256": self.verification.manifest_sha256,
            "detached_receipt_sha256": self.detached_receipt.receipt_sha256,
            "accepted_samples": timeline["accepted_samples"],
            "dropped_samples": timeline["dropped_samples"],
            "sample_rate_hz": timeline["sample_rate_hz"],
            "durability_warning": self.durability_warning,
            "error_code": None,
        }


@dataclass
class LiveTimingArchivePrepared:
    """A verified staging directory which has not yet become a public receipt."""

    staging_directory: Path
    staging_root: Path
    output_root: Path
    receipt_root: Path
    session_id: str
    _consumed: bool = field(default=False, init=False, repr=False)
    _abort_cleanup_succeeded: bool | None = field(default=None, init=False, repr=False)

    def publish(self) -> LiveTimingArchivePublication:
        if self._consumed:
            raise RuntimeError("timing archive prepared receipt 已處理")
        verify_live_timing_archive(self.staging_directory)
        output_root = _canonical_existing_directory(
            self.output_root, field_name="timing archive output root"
        )
        destination = output_root / _canonical_session_id(self.session_id)
        if destination.exists() or destination.is_symlink():
            raise ValueError("timing archive destination 已存在或無效")
        source_identity = _directory_identity(self.staging_directory)
        os.replace(self.staging_directory, destination)
        # The staging directory no longer exists after the atomic hand-off.
        # Treat it as consumed before the final read-back so a read-back I/O
        # error can never make ``abort()`` target a subsequently re-used path.
        self._consumed = True
        detached_receipt: LiveTimingArchiveDetachedReceiptVerification | None = None
        try:
            if _directory_identity(destination) != source_identity:
                raise RuntimeError("timing archive destination identity 不一致")
            # The marker remains in place from staging through every durable
            # verification step. A crash here is recoverable on next startup;
            # no marker-free archive can be guessed pending.
            if _read_staging_marker(destination) != self.session_id:
                raise RuntimeError("timing archive pending marker 無效")
            if _fsync_directory(output_root) is not None:
                raise OSError("timing archive output move directory sync failed")
            final_verification = verify_live_timing_archive(destination)
            detached_receipt = _write_detached_receipt(
                final_verification,
                receipt_root=self.receipt_root,
            )
            final_receipt = verify_live_timing_archive_detached_receipt(
                destination,
                detached_receipt.receipt_path,
            )
            _remove_staging_marker(destination)
            # Marker removal is the commit point. If the directory sync below
            # cannot be proven, retain the receipt but surface an explicit
            # durability warning rather than reporting a green completion.
            durability_warning = _fsync_directory(destination)
            if durability_warning is None:
                durability_warning = _fsync_directory(output_root)
        except BaseException as exc:
            raw_audio_cleanup_succeeded = _discard_published_directory(
                output_root,
                session_id=self.session_id,
                expected_identity=source_identity,
            )
            receipt_cleanup_succeeded = (
                True
                if detached_receipt is None
                else _discard_detached_receipt(
                    self.receipt_root,
                    session_id=self.session_id,
                    expected_sha256=detached_receipt.receipt_sha256,
                )
            )
            if raw_audio_cleanup_succeeded:
                raise LiveTimingArchivePublicationError(
                    "timing archive publish 驗證失敗；本機原始音訊已清除",
                    raw_audio_cleanup_succeeded=True,
                    receipt_cleanup_succeeded=receipt_cleanup_succeeded,
                ) from exc
            raise LiveTimingArchivePublicationError(
                "timing archive publish 驗證失敗；未能證明原始音訊已清除",
                raw_audio_cleanup_succeeded=False,
                receipt_cleanup_succeeded=receipt_cleanup_succeeded,
            ) from exc
        return LiveTimingArchivePublication(
            directory=destination,
            verification=final_verification,
            detached_receipt=final_receipt,
            durability_warning=durability_warning,
        )

    def abort(self) -> bool:
        """Erase only the private staging directory for a cancelled/failed run."""

        if self._abort_cleanup_succeeded is not None:
            return self._abort_cleanup_succeeded
        if self._consumed:
            return True
        self._consumed = True
        self._abort_cleanup_succeeded = _discard_staging_directory(
            self.staging_root,
            self.staging_directory,
            session_id=self.session_id,
            require_marker=True,
        )
        return self._abort_cleanup_succeeded


class LiveTimingArchive:
    """Capture a queue-accepted PCM lineage without affecting caption decode."""

    def __init__(
        self,
        *,
        session_id: str,
        sample_rate_hz: int,
        staging_directory: Path,
        staging_root: Path,
        output_root: Path,
        receipt_root: Path,
    ) -> None:
        self.session_id = _canonical_session_id(session_id)
        self.sample_rate_hz = _nonnegative_int(
            sample_rate_hz, field_name="timing archive sample rate"
        )
        if self.sample_rate_hz < 1:
            raise ValueError("timing archive sample rate 無效")
        self._staging_root = _canonical_existing_directory(
            staging_root, field_name="timing archive staging root"
        )
        safe_staging_directory = _safe_staging_directory(
            self._staging_root,
            staging_directory,
            session_id=self.session_id,
        )
        if safe_staging_directory is None or _read_staging_marker(
            safe_staging_directory
        ) != self.session_id:
            raise ValueError("timing archive staging directory 無效")
        self._staging_directory = safe_staging_directory
        self._output_root = _canonical_existing_directory(
            output_root, field_name="timing archive output root"
        )
        self._receipt_root = _canonical_existing_directory(
            receipt_root, field_name="timing archive receipt root"
        )
        self._audio_path = self._staging_directory / LIVE_TIMING_ARCHIVE_AUDIO
        if self._audio_path.exists() or self._audio_path.is_symlink():
            raise ValueError("timing archive staging audio 已存在")
        self._stream = self._audio_path.open("xb")
        os.chmod(self._audio_path, 0o600)
        self._lock = threading.Lock()
        self._state = "capturing"
        self._error_code: str | None = None
        self._abort_cleanup_succeeded: bool | None = None
        self._timeline_samples = 0
        self._accepted_samples = 0
        self._dropped_samples = 0
        self._chunks: list[_ArchiveChunk] = []
        self._chunk_number = 0

    @classmethod
    def create(
        cls,
        *,
        runtime_root: Path,
        jobs_root: Path,
        session_id: str,
        sample_rate_hz: int,
    ) -> "LiveTimingArchive":
        canonical_session_id = _canonical_session_id(session_id)
        staging_root = _ensure_owned_directory(
            Path(runtime_root) / LIVE_TIMING_ARCHIVE_STAGING_DIRECTORY
        )
        output_root = _ensure_owned_directory(
            Path(jobs_root) / LIVE_TIMING_ARCHIVE_OUTPUT_DIRECTORY
        )
        receipt_root = _ensure_owned_directory(
            Path(jobs_root) / LIVE_TIMING_ARCHIVE_RECEIPTS_DIRECTORY
        )
        staging_directory = Path(
            tempfile.mkdtemp(
                prefix=_staging_directory_name(canonical_session_id),
                dir=staging_root,
            )
        )
        os.chmod(staging_directory, 0o700)
        try:
            if _fsync_directory(staging_root) is not None:
                raise OSError("timing archive staging root directory sync failed")
            _write_staging_marker(staging_directory, session_id=canonical_session_id)
            return cls(
                session_id=canonical_session_id,
                sample_rate_hz=sample_rate_hz,
                staging_directory=staging_directory,
                staging_root=staging_root,
                output_root=output_root,
                receipt_root=receipt_root,
            )
        except BaseException:
            _discard_staging_directory(
                staging_root,
                staging_directory,
                session_id=canonical_session_id,
                require_marker=False,
            )
            raise

    def _next_chunk_id_locked(self) -> str:
        self._chunk_number += 1
        return f"chunk-{self._chunk_number:06d}"

    def _record_accepted_locked(
        self, *, frame: bytes, timeline_start_sample: int, sample_count: int
    ) -> None:
        accepted_start = self._accepted_samples
        archive_start = accepted_start * 2
        try:
            self._stream.write(frame)
        except OSError:
            self._fail_locked("audio_write_failed")
            return
        prior = self._chunks[-1] if self._chunks else None
        if (
            prior is not None
            and prior.kind == "accepted"
            and prior.timeline_end_sample == timeline_start_sample
            and prior.accepted_end_sample == accepted_start
            and prior.archive_byte_end == archive_start
            and prior.digest is not None
        ):
            prior.timeline_end_sample += sample_count
            prior.accepted_end_sample = accepted_start + sample_count
            prior.archive_byte_end = archive_start + len(frame)
            prior.digest.update(frame)
        else:
            digest = hashlib.sha256(frame)
            self._chunks.append(
                _ArchiveChunk(
                    id=self._next_chunk_id_locked(),
                    kind="accepted",
                    timeline_start_sample=timeline_start_sample,
                    timeline_end_sample=timeline_start_sample + sample_count,
                    accepted_start_sample=accepted_start,
                    accepted_end_sample=accepted_start + sample_count,
                    archive_byte_start=archive_start,
                    archive_byte_end=archive_start + len(frame),
                    digest=digest,
                )
            )
        self._accepted_samples += sample_count

    def _record_dropped_locked(
        self, *, timeline_start_sample: int, sample_count: int
    ) -> None:
        prior = self._chunks[-1] if self._chunks else None
        if (
            prior is not None
            and prior.kind == "dropped"
            and prior.timeline_end_sample == timeline_start_sample
        ):
            prior.timeline_end_sample += sample_count
        else:
            self._chunks.append(
                _ArchiveChunk(
                    id=self._next_chunk_id_locked(),
                    kind="dropped",
                    timeline_start_sample=timeline_start_sample,
                    timeline_end_sample=timeline_start_sample + sample_count,
                    accepted_start_sample=None,
                    accepted_end_sample=None,
                    archive_byte_start=None,
                    archive_byte_end=None,
                    digest=None,
                )
            )
        self._dropped_samples += sample_count

    def _fail_locked(self, code: str) -> None:
        self._state = "failed"
        self._error_code = code
        try:
            self._stream.close()
        except OSError:
            pass

    def record_frame(
        self,
        *,
        frame: bytes,
        accepted: bool,
        timeline_start_sample: int,
    ) -> None:
        """Record one post-admission frame; never call this before queue admission."""

        if not isinstance(frame, bytes) or not frame or len(frame) % 2:
            raise ValueError("timing archive frame 無效")
        sample_count = len(frame) // 2
        with self._lock:
            if self._state != "capturing":
                return
            if timeline_start_sample != self._timeline_samples:
                self._fail_locked("timeline_discontinuity")
                return
            self._timeline_samples += sample_count
            if accepted:
                self._record_accepted_locked(
                    frame=frame,
                    timeline_start_sample=timeline_start_sample,
                    sample_count=sample_count,
                )
            else:
                self._record_dropped_locked(
                    timeline_start_sample=timeline_start_sample,
                    sample_count=sample_count,
                )

    def _manifest_locked(self) -> dict[str, Any]:
        return {
            "schema": LIVE_TIMING_ARCHIVE_SCHEMA,
            "session_id": self.session_id,
            "local_only": True,
            "review_only": True,
            "automatic_timestamp_mutation": False,
            "candidate_state": "not_run",
            "source_audio": {
                "filename": LIVE_TIMING_ARCHIVE_AUDIO,
                "encoding": "pcm_s16le",
                "channels": 1,
                "byte_count": self._accepted_samples * 2,
                "sample_count": self._accepted_samples,
                "sha256": _sha256_file(self._audio_path),
            },
            "capture_timeline": {
                "domain": "capture_timeline_sample_index",
                "sample_rate_hz": self.sample_rate_hz,
                "total_offered_samples": self._timeline_samples,
                "accepted_samples": self._accepted_samples,
                "dropped_samples": self._dropped_samples,
                "chunks": [chunk.to_dict() for chunk in self._chunks],
            },
        }

    def prepare(self) -> LiveTimingArchivePrepared:
        """Durably stage an immutable receipt after the worker's clean stop."""

        with self._lock:
            if self._state == "failed":
                raise RuntimeError("timing archive recording failed")
            if self._state != "capturing":
                raise RuntimeError("timing archive 無法重複完成")
            try:
                self._stream.flush()
                os.fsync(self._stream.fileno())
                self._stream.close()
                manifest = self._manifest_locked()
                _atomic_json_write(
                    self._staging_directory / LIVE_TIMING_ARCHIVE_MANIFEST,
                    manifest,
                )
            except OSError as exc:
                self._fail_locked("finalize_failed")
                raise RuntimeError("timing archive 無法完成") from exc
            self._state = "prepared"
            prepared = LiveTimingArchivePrepared(
                staging_directory=self._staging_directory,
                staging_root=self._staging_root,
                output_root=self._output_root,
                receipt_root=self._receipt_root,
                session_id=self.session_id,
            )
        verify_live_timing_archive(prepared.staging_directory)
        return prepared

    def status_value(self) -> dict[str, Any]:
        with self._lock:
            return {
                "enabled": True,
                "state": self._state,
                "local_only": True,
                "review_only": True,
                "automatic_timestamp_mutation": False,
                "candidate_state": "not_run",
                "integrity_scope": None,
                "archive_id": self.session_id,
                "source_audio_sha256": None,
                "manifest_sha256": None,
                "detached_receipt_sha256": None,
                "accepted_samples": self._accepted_samples,
                "dropped_samples": self._dropped_samples,
                "sample_rate_hz": self.sample_rate_hz,
                "durability_warning": None,
                "error_code": self._error_code,
            }

    def abort(self) -> bool:
        """Discard only un-published, opt-in raw audio after cancellation/error."""

        with self._lock:
            if self._abort_cleanup_succeeded is not None:
                return self._abort_cleanup_succeeded
            if self._state == "published":
                self._abort_cleanup_succeeded = True
                return True
            try:
                self._stream.close()
            except OSError:
                pass
            staging_directory = self._staging_directory
            staging_root = self._staging_root
            session_id = self.session_id
        erased = _discard_staging_directory(
            staging_root,
            staging_directory,
            session_id=session_id,
            require_marker=True,
        )
        with self._lock:
            self._abort_cleanup_succeeded = erased
            if erased:
                self._state = "aborted"
                self._error_code = None
            else:
                self._state = "failed"
                self._error_code = "discard_cleanup_failed_possible_local_retention"
        return erased


def verify_live_timing_archive(directory: Path) -> LiveTimingArchiveVerification:
    """Re-hash a published/staged receipt; reject every ambiguous lineage."""

    directory = Path(directory)
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError("timing archive directory 無效")
    directory = directory.resolve(strict=True)
    manifest_path = directory / LIVE_TIMING_ARCHIVE_MANIFEST
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("timing archive manifest 無效")
    try:
        value = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("timing archive manifest 無效") from exc
    if not isinstance(value, dict) or set(value) != _MANIFEST_KEYS:
        raise ValueError("timing archive manifest 欄位無效")
    if value["schema"] != LIVE_TIMING_ARCHIVE_SCHEMA:
        raise ValueError("timing archive schema 無效")
    session_id = _canonical_session_id(value["session_id"])
    if value["session_id"] != session_id:
        raise ValueError("timing archive session_id 非 canonical")
    if (
        value["local_only"] is not True
        or value["review_only"] is not True
        or value["automatic_timestamp_mutation"] is not False
        or value["candidate_state"] != "not_run"
    ):
        raise ValueError("timing archive policy metadata 無效")

    source_audio = value["source_audio"]
    if not isinstance(source_audio, dict) or set(source_audio) != _SOURCE_AUDIO_KEYS:
        raise ValueError("timing archive source audio metadata 無效")
    if (
        source_audio["filename"] != LIVE_TIMING_ARCHIVE_AUDIO
        or source_audio["encoding"] != "pcm_s16le"
        or source_audio["channels"] != 1
    ):
        raise ValueError("timing archive source audio format 無效")
    audio_path = directory / LIVE_TIMING_ARCHIVE_AUDIO
    if audio_path.is_symlink() or not audio_path.is_file():
        raise ValueError("timing archive audio file 無效")
    byte_count = _nonnegative_int(source_audio["byte_count"], field_name="audio byte_count")
    sample_count = _nonnegative_int(source_audio["sample_count"], field_name="audio sample_count")
    if byte_count != sample_count * 2 or audio_path.stat().st_size != byte_count:
        raise ValueError("timing archive audio length 不一致")
    sha256 = source_audio["sha256"]
    if (
        not isinstance(sha256, str)
        or len(sha256) != 64
        or any(char not in "0123456789abcdef" for char in sha256)
        or _sha256_file(audio_path) != sha256
    ):
        raise ValueError("timing archive source audio hash 不一致")

    timeline = value["capture_timeline"]
    if not isinstance(timeline, dict) or set(timeline) != _TIMELINE_KEYS:
        raise ValueError("timing archive capture timeline metadata 無效")
    if timeline["domain"] != "capture_timeline_sample_index":
        raise ValueError("timing archive clock domain 無效")
    sample_rate_hz = _nonnegative_int(
        timeline["sample_rate_hz"], field_name="timeline sample_rate_hz"
    )
    if sample_rate_hz < 1:
        raise ValueError("timing archive sample_rate_hz 無效")
    total_offered = _nonnegative_int(
        timeline["total_offered_samples"], field_name="total_offered_samples"
    )
    accepted_samples = _nonnegative_int(
        timeline["accepted_samples"], field_name="accepted_samples"
    )
    dropped_samples = _nonnegative_int(
        timeline["dropped_samples"], field_name="dropped_samples"
    )
    if (
        total_offered != accepted_samples + dropped_samples
        or accepted_samples != sample_count
    ):
        raise ValueError("timing archive sample totals 不一致")
    chunks = timeline["chunks"]
    if not isinstance(chunks, list):
        raise ValueError("timing archive chunks 無效")
    expected_timeline = 0
    expected_accepted = 0
    expected_byte = 0
    observed_dropped = 0
    with audio_path.open("rb") as stream:
        for index, raw_chunk in enumerate(chunks, start=1):
            if not isinstance(raw_chunk, dict) or set(raw_chunk) != _CHUNK_KEYS:
                raise ValueError("timing archive chunk 欄位無效")
            if raw_chunk["id"] != f"chunk-{index:06d}":
                raise ValueError("timing archive chunk id 無效")
            kind = raw_chunk["kind"]
            timeline_start = _nonnegative_int(
                raw_chunk["timeline_start_sample"], field_name="chunk timeline start"
            )
            timeline_end = _nonnegative_int(
                raw_chunk["timeline_end_sample"], field_name="chunk timeline end"
            )
            if timeline_start != expected_timeline or timeline_end <= timeline_start:
                raise ValueError("timing archive timeline chunk 無連續性")
            expected_timeline = timeline_end
            length = timeline_end - timeline_start
            if kind == "accepted":
                accepted_start = _nonnegative_int(
                    raw_chunk["accepted_start_sample"], field_name="chunk accepted start"
                )
                accepted_end = _nonnegative_int(
                    raw_chunk["accepted_end_sample"], field_name="chunk accepted end"
                )
                byte_start = _nonnegative_int(
                    raw_chunk["archive_byte_start"], field_name="chunk archive byte start"
                )
                byte_end = _nonnegative_int(
                    raw_chunk["archive_byte_end"], field_name="chunk archive byte end"
                )
                chunk_sha256 = raw_chunk["sha256"]
                if (
                    accepted_start != expected_accepted
                    or accepted_end != accepted_start + length
                    or byte_start != expected_byte
                    or byte_end != byte_start + length * 2
                    or not isinstance(chunk_sha256, str)
                    or len(chunk_sha256) != 64
                    or any(char not in "0123456789abcdef" for char in chunk_sha256)
                ):
                    raise ValueError("timing archive accepted chunk metadata 無效")
                stream.seek(byte_start)
                if hashlib.sha256(stream.read(byte_end - byte_start)).hexdigest() != chunk_sha256:
                    raise ValueError("timing archive accepted chunk hash 不一致")
                expected_accepted = accepted_end
                expected_byte = byte_end
            elif kind == "dropped":
                if any(
                    raw_chunk[key] is not None
                    for key in (
                        "accepted_start_sample",
                        "accepted_end_sample",
                        "archive_byte_start",
                        "archive_byte_end",
                        "sha256",
                    )
                ):
                    raise ValueError("timing archive dropped chunk metadata 無效")
                observed_dropped += length
            else:
                raise ValueError("timing archive chunk kind 無效")
    if (
        expected_timeline != total_offered
        or expected_accepted != accepted_samples
        or expected_byte != byte_count
        or observed_dropped != dropped_samples
    ):
        raise ValueError("timing archive chunk totals 不一致")
    return LiveTimingArchiveVerification(
        directory=directory,
        manifest=dict(value),
        manifest_sha256=_sha256_file(manifest_path),
    )


def verify_live_timing_archive_detached_receipt(
    directory: Path,
    receipt_path: Path,
) -> LiveTimingArchiveDetachedReceiptVerification:
    """Cross-check an archive against its separately stored local hash receipt.

    The receipt catches a rewrite of archive bytes and manifest that did not
    also rewrite the separate receipt.  It has no keychain-backed signing key,
    so a user who can replace both files can still replace both values.
    """

    verification = verify_live_timing_archive(directory)
    receipt = Path(receipt_path).expanduser()
    if receipt.is_symlink() or not receipt.is_file():
        raise ValueError("timing archive detached receipt 無效")
    receipt = receipt.resolve(strict=True)
    if _is_relative_to(receipt, verification.directory):
        raise ValueError("timing archive detached receipt 唔可以放入 archive")
    try:
        value = json.loads(receipt.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("timing archive detached receipt 無效") from exc
    if not isinstance(value, dict) or set(value) != _DETACHED_RECEIPT_KEYS:
        raise ValueError("timing archive detached receipt 欄位無效")
    if value["schema"] != LIVE_TIMING_ARCHIVE_RECEIPT_SCHEMA:
        raise ValueError("timing archive detached receipt schema 無效")
    session_id = _canonical_session_id(value["session_id"])
    source_audio = verification.manifest["source_audio"]
    if (
        value["session_id"] != session_id
        or session_id != verification.manifest["session_id"]
        or value["archive_manifest_sha256"] != verification.manifest_sha256
        or value["source_audio_sha256"] != source_audio["sha256"]
        or value["local_only"] is not True
        or value["review_only"] is not True
        or value["automatic_timestamp_mutation"] is not False
        or value["candidate_state"] != "not_run"
        or value["integrity_scope"] != LIVE_TIMING_ARCHIVE_INTEGRITY_SCOPE
    ):
        raise ValueError("timing archive detached receipt 同 archive 不一致")
    return LiveTimingArchiveDetachedReceiptVerification(
        archive_verification=verification,
        receipt_path=receipt,
        receipt_sha256=_sha256_file(receipt),
        integrity_scope=LIVE_TIMING_ARCHIVE_INTEGRITY_SCOPE,
    )


def verify_published_live_timing_archive(
    jobs_root: Path,
    *,
    session_id: str,
) -> LiveTimingArchiveDetachedReceiptVerification:
    """Verify one marker-free direct archive before any later review reads it.

    The generic detached-receipt verifier intentionally accepts a staging
    directory for finalization read-back. A post-session review must be
    stricter: it can read only a direct, marker-free publication under the
    canonical CTS Jobs root.
    """

    jobs = _canonical_existing_directory(
        jobs_root, field_name="timing archive jobs root"
    )
    canonical_session_id = _canonical_session_id(session_id)
    output_root = _canonical_existing_directory(
        jobs / LIVE_TIMING_ARCHIVE_OUTPUT_DIRECTORY,
        field_name="timing archive output root",
    )
    if output_root.parent != jobs:
        raise ValueError("timing archive output root 位置無效")
    directory = _safe_published_directory(
        output_root,
        output_root / canonical_session_id,
        session_id=canonical_session_id,
    )
    if directory is None:
        raise ValueError("timing archive published directory 無效")
    marker = directory / _STAGING_MARKER
    if marker.exists() or marker.is_symlink():
        raise ValueError("timing archive publication 仍未完成")
    receipt_root = _canonical_existing_directory(
        jobs / LIVE_TIMING_ARCHIVE_RECEIPTS_DIRECTORY,
        field_name="timing archive receipt root",
    )
    if receipt_root.parent != jobs:
        raise ValueError("timing archive receipt root 位置無效")
    return verify_live_timing_archive_detached_receipt(
        directory,
        _detached_receipt_path(receipt_root, session_id=canonical_session_id),
    )


def project_accepted_interval_to_capture_timeline(
    verification: LiveTimingArchiveVerification,
    *,
    accepted_start_sample: int,
    accepted_end_sample: int,
) -> LiveTimingArchiveIntervalProjection:
    """Project one Wenet interval only when its source mapping is exact.

    Wenet sees compacted accepted PCM.  Any bounded-queue overrun has removed
    a real-time interval from that compacted stream, so it is unsafe to map a
    candidate across the gap by arithmetic alone.  This helper converts only
    intervals entirely contained in one verified accepted chunk.
    """

    start = _nonnegative_int(
        accepted_start_sample, field_name="accepted interval start"
    )
    end = _nonnegative_int(accepted_end_sample, field_name="accepted interval end")
    timeline = verification.manifest["capture_timeline"]
    accepted_total = _nonnegative_int(
        timeline["accepted_samples"], field_name="accepted_samples"
    )
    if not start < end <= accepted_total:
        raise ValueError("accepted interval 超出 archive 範圍")
    for chunk in timeline["chunks"]:
        if chunk["kind"] != "accepted":
            continue
        chunk_start = chunk["accepted_start_sample"]
        chunk_end = chunk["accepted_end_sample"]
        if chunk_start <= start and end <= chunk_end:
            timeline_start = chunk["timeline_start_sample"] + (start - chunk_start)
            timeline_end = chunk["timeline_start_sample"] + (end - chunk_start)
            return LiveTimingArchiveIntervalProjection(
                status="exact",
                accepted_start_sample=start,
                accepted_end_sample=end,
                timeline_start_sample=timeline_start,
                timeline_end_sample=timeline_end,
                reason_codes=(),
            )
    return LiveTimingArchiveIntervalProjection(
        status="unassessable",
        accepted_start_sample=start,
        accepted_end_sample=end,
        timeline_start_sample=None,
        timeline_end_sample=None,
        reason_codes=("crosses_dropped_capture_gap",),
    )


__all__ = [
    "LIVE_TIMING_ARCHIVE_AUDIO",
    "LIVE_TIMING_ARCHIVE_MANIFEST",
    "LIVE_TIMING_ARCHIVE_SCHEMA",
    "LiveTimingArchive",
    "LiveTimingArchiveIntervalProjection",
    "LiveTimingArchivePrepared",
    "LiveTimingArchivePublication",
    "LiveTimingArchiveVerification",
    "verify_live_timing_archive",
    "project_accepted_interval_to_capture_timeline",
]
