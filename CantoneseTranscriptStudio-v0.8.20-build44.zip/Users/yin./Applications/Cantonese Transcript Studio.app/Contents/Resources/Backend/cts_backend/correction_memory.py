"""Local, auditable correction memory for names and specialised vocabulary.

The store never rewrites transcript text by itself.  It exposes bounded
replacement candidates and prompt vocabulary that a caller may feed into the
existing reconciliation policy.  Entries can only be created from an explicit
user action (or an accepted, narrowly-scoped subtitle edit).
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import stat
import threading
import time
import unicodedata
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Iterator, Mapping, Sequence

from .settings import AppPaths, _atomic_json


SCHEMA_VERSION = 2
CORRECTION_MEMORY_SCHEMA_VERSION = SCHEMA_VERSION
MAX_ENTRIES = 2_048
MAX_ALIASES = 32
MAX_PHRASE_CHARACTERS = 120
MAX_STORE_BYTES = 2 * 1024 * 1024
MAX_IMPORT_BYTES = MAX_STORE_BYTES
MAX_CONFIRMATIONS = 1_000_000
_ASCII_WORD = re.compile(r"[A-Za-z0-9]")
EXPORT_KIND = "cantonese-transcript-studio-personal-dictionary"
AUTOMATIC_APPLICATION_POLICY = "manual_or_two_confirmations"


class CorrectionMemoryError(ValueError):
    """Raised when correction memory is corrupt or an update is unsafe."""


@dataclass(frozen=True)
class CorrectionAlias:
    value: str
    accepted_count: int
    created_at: int
    updated_at: int
    last_source: str

    def to_json(self) -> dict[str, object]:
        return {
            "value": self.value,
            "accepted_count": self.accepted_count,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "last_source": self.last_source,
        }


@dataclass(frozen=True)
class CorrectionEntry:
    canonical: str
    aliases: tuple[CorrectionAlias, ...]
    accepted_count: int
    created_at: int
    updated_at: int

    @property
    def last_source(self) -> str:
        if not self.aliases:
            return "manual_alias"
        latest = max(self.aliases, key=lambda item: (item.updated_at, item.value.casefold()))
        return latest.last_source

    @property
    def alias_values(self) -> tuple[str, ...]:
        return tuple(item.value for item in self.aliases)

    def to_json(self) -> dict[str, object]:
        return {
            "canonical": self.canonical,
            "aliases": [item.to_json() for item in self.aliases],
            "accepted_count": self.accepted_count,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "last_source": self.last_source,
        }


@dataclass(frozen=True)
class CorrectionCandidate:
    start: int
    end: int
    before: str
    after: str
    accepted_count: int
    last_source: str
    reason: str = "local_correction_memory"

    @property
    def approved_for_automatic_application(self) -> bool:
        """Only deterministic, user-confirmed mappings may edit final text.

        A manual alias/import is an explicit instruction.  An inferred subtitle
        edit needs to be accepted at least twice before it becomes an automatic
        replacement; the first observation remains prompt vocabulary only.
        """

        # A one-character CJK alias has no lexical boundary.  Even repeated or
        # manually entered ``系 -> 係`` must not corrupt ``系統／太陽系／系列``;
        # those Cantonese copula cases belong to the context-aware HK policy.
        if len(self.before) == 1 and not self.before.isascii():
            return False
        return self.last_source in {"manual_alias", "import"} or self.accepted_count >= 2


def _phrase(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise CorrectionMemoryError(f"{label} 必須係文字")
    normalized = unicodedata.normalize("NFC", value)
    # Reject hidden/control content before whitespace folding. Otherwise a
    # JSON string containing an escaped newline or tab would be silently
    # converted into an ordinary space and evade the import audit.
    if any(
        unicodedata.category(character) in {"Cc", "Cf", "Cs"}
        for character in normalized
    ):
        raise CorrectionMemoryError(f"{label} 包含控制或隱藏格式字元")
    normalized = " ".join(normalized.split()).strip()
    if not normalized:
        raise CorrectionMemoryError(f"{label} 不可以留空")
    if len(normalized) > MAX_PHRASE_CHARACTERS:
        raise CorrectionMemoryError(f"{label} 過長")
    return normalized


def _key(value: str) -> str:
    return unicodedata.normalize("NFC", value).casefold()


def _latin_boundary_is_clear(text: str, start: int, end: int) -> bool:
    """Keep ASCII aliases out of larger Latin/number/combining sequences.

    Chinese characters deliberately remain valid neighbours so natural mixed
    Cantonese such as ``用Antigravity剪片`` can still learn the proper noun.
    """

    def blocks(character: str) -> bool:
        category = unicodedata.category(character)
        name = unicodedata.name(character, "")
        return (
            category.startswith(("M", "N"))
            or "LATIN" in name
            or "GREEK" in name
            or "CYRILLIC" in name
            or character in "_'"
        )

    return not (
        (start > 0 and blocks(text[start - 1]))
        or (end < len(text) and blocks(text[end]))
    )


def infer_single_replacement(before: str, after: str) -> tuple[str, str] | None:
    """Return one narrow replacement from an accepted cue edit.

    Broad rewrites, pure insertions/deletions, and edits without enough stable
    surrounding text are deliberately ignored.  This keeps ordinary subtitle
    editing from silently becoming free-form training data.
    """

    if not isinstance(before, str) or not isinstance(after, str):
        return None
    before = unicodedata.normalize("NFC", before)
    after = unicodedata.normalize("NFC", after)
    if before == after or not before or not after:
        return None

    prefix = 0
    limit = min(len(before), len(after))
    while prefix < limit and before[prefix] == after[prefix]:
        prefix += 1

    suffix = 0
    before_remaining = len(before) - prefix
    after_remaining = len(after) - prefix
    while (
        suffix < before_remaining
        and suffix < after_remaining
        and before[len(before) - 1 - suffix] == after[len(after) - 1 - suffix]
    ):
        suffix += 1

    before_end = len(before) - suffix if suffix else len(before)
    after_end = len(after) - suffix if suffix else len(after)

    # A one-letter edit inside a Latin proper noun must remember the complete
    # token, never a dangerous global mapping such as ``E -> A``.
    token_character = lambda value: value.isascii() and (value.isalnum() or value in "_'-")
    start = prefix
    while (
        start > 0
        and start <= len(before)
        and start <= len(after)
        and token_character(before[start - 1])
        and token_character(after[start - 1])
    ):
        start -= 1
    while (
        before_end < len(before)
        and after_end < len(after)
        and token_character(before[before_end])
        and token_character(after[after_end])
    ):
        before_end += 1
        after_end += 1

    # Keep a short shared acronym attached to a corrected Latin token.  This
    # learns ``IG VIOS -> IG Reels`` instead of the over-broad ``VIOS -> Reels``.
    # Ordinary preceding words (for example ``use Entigravity``) are not added.
    if start > 1 and before[start - 1] == " " and after[start - 1] == " ":
        acronym_end = start - 1
        acronym_start = acronym_end
        while acronym_start > 0 and token_character(before[acronym_start - 1]):
            acronym_start -= 1
        acronym_before = before[acronym_start:acronym_end]
        acronym_after = after[acronym_start:acronym_end]
        if (
            acronym_before == acronym_after
            and 2 <= len(acronym_before) <= 6
            and acronym_before.isascii()
            and any(character.isalpha() for character in acronym_before)
            and acronym_before.upper() == acronym_before
        ):
            start = acronym_start

    old = before[start:before_end].strip(" \t\r\n,，。.!！？:：;；()（）[]【】\"'“”‘’")
    new = after[start:after_end].strip(" \t\r\n,，。.!！？:：;；()（）[]【】\"'“”‘’")
    if not old or not new or old == new:
        return None
    # Numbers, dates, prices and quantities are facts, not vocabulary.  A
    # subtitle correction such as ``50 -> 45`` must never become a persistent
    # global alias. Manual/imported mappings remain an explicit user choice.
    if not any(unicodedata.category(character).startswith("L") for character in old) or not any(
        unicodedata.category(character).startswith("L") for character in new
    ):
        return None
    if len(old) > 64 or len(new) > 64:
        return None

    unchanged = start + (len(before) - before_end)
    longest = max(len(before), len(after))
    if unchanged < 2 or unchanged / longest < 0.20:
        return None
    # A cue where most characters changed is a rewrite, not a spelling fix.
    if max(len(old), len(new)) > max(16, unchanged * 2):
        return None
    return old, new


class CorrectionMemoryStore:
    def __init__(
        self,
        paths: AppPaths | None = None,
        *,
        path: str | Path | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.paths = (paths or AppPaths.default()).ensure()
        candidate = (
            Path(path).expanduser()
            if path is not None
            else self.paths.root / "correction-memory.json"
        )
        # Resolve only the parent. Resolving the full path would follow a
        # pre-existing terminal symlink before our lstat guard can reject it.
        self.path = candidate.parent.resolve(strict=False) / candidate.name
        self.lock_path = self.paths.runtime / "correction-memory.lock"
        self._clock = clock
        self._thread_lock = threading.RLock()

    @contextmanager
    def _locked(self) -> Iterator[None]:
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        descriptor = os.open(self.lock_path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            os.fchmod(descriptor, 0o600)
            with self._thread_lock:
                fcntl.flock(descriptor, fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)

    def _read_unlocked(self) -> tuple[CorrectionEntry, ...]:
        if self.path.is_symlink():
            raise CorrectionMemoryError("修正記憶檔案必須係普通本機檔案")
        if not self.path.exists():
            return ()
        metadata = self.path.lstat()
        if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISREG(metadata.st_mode):
            raise CorrectionMemoryError("修正記憶檔案必須係普通本機檔案")
        if metadata.st_size > MAX_STORE_BYTES:
            raise CorrectionMemoryError("修正記憶檔案過大")
        if stat.S_IMODE(metadata.st_mode) & 0o077:
            raise CorrectionMemoryError("修正記憶檔案權限必須只限目前用戶")
        try:
            document = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise CorrectionMemoryError("修正記憶檔案損壞") from exc
        if not isinstance(document, dict) or document.get("schema") not in {1, SCHEMA_VERSION}:
            raise CorrectionMemoryError("修正記憶 schema 不支援")
        raw_entries = document.get("entries")
        if not isinstance(raw_entries, list) or len(raw_entries) > MAX_ENTRIES:
            raise CorrectionMemoryError("修正記憶 entries 無效")
        return correction_entries_from_snapshot(
            raw_entries,
            schema=int(document["schema"]),
        )

    def _write_unlocked(self, entries: Sequence[CorrectionEntry]) -> None:
        if self.path.is_symlink():
            raise CorrectionMemoryError("修正記憶檔案必須係普通本機檔案")
        if self.path.exists() and not stat.S_ISREG(self.path.lstat().st_mode):
            raise CorrectionMemoryError("修正記憶檔案必須係普通本機檔案")
        ordered = sorted(entries, key=lambda item: (-item.updated_at, -item.accepted_count, item.canonical.casefold()))
        _atomic_json(
            self.path,
            {"schema": SCHEMA_VERSION, "entries": [item.to_json() for item in ordered]},
        )
        os.chmod(self.path, 0o600)

    def entries(self) -> tuple[CorrectionEntry, ...]:
        with self._locked():
            return self._read_unlocked()

    def export_document(self) -> dict[str, object]:
        """Return the portable, truthful public dictionary contract."""

        return {
            "kind": EXPORT_KIND,
            "schema": SCHEMA_VERSION,
            "local_only": True,
            "free_form_rewrite": False,
            "automatic_application": True,
            "automatic_application_policy": AUTOMATIC_APPLICATION_POLICY,
            "entries": [entry.to_json() for entry in self.entries()],
        }

    def export_to_path(
        self,
        path: str | Path,
        *,
        overwrite_confirmed: bool,
    ) -> Path:
        """Atomically export to a path explicitly selected by the user."""

        destination = Path(path).expanduser()
        if not destination.is_absolute():
            raise CorrectionMemoryError("匯出位置必須係完整路徑")
        try:
            parent = destination.parent.resolve(strict=True)
        except OSError as exc:
            raise CorrectionMemoryError("匯出資料夾不存在") from exc
        if not parent.is_dir():
            raise CorrectionMemoryError("匯出位置唔係資料夾")
        destination = parent / destination.name
        if destination == self.path:
            raise CorrectionMemoryError("唔可以用匯出檔覆蓋 App 詞庫")
        if destination.is_symlink():
            raise CorrectionMemoryError("匯出檔案唔可以係連結")
        if destination.exists():
            metadata = destination.lstat()
            if not stat.S_ISREG(metadata.st_mode):
                raise CorrectionMemoryError("匯出檔案必須係普通檔案")
            if not overwrite_confirmed:
                raise CorrectionMemoryError("覆蓋現有檔案前需要確認")
        _atomic_json(destination, self.export_document())
        os.chmod(destination, 0o600)
        return destination

    def import_from_path(self, path: str | Path) -> tuple[CorrectionEntry, ...]:
        """Read one bounded regular file and atomically merge every mapping."""

        source = Path(path).expanduser()
        if not source.is_absolute():
            raise CorrectionMemoryError("匯入位置必須係完整路徑")
        if source.is_symlink():
            raise CorrectionMemoryError("匯入檔案唔可以係連結")
        try:
            metadata = source.lstat()
        except OSError as exc:
            raise CorrectionMemoryError("搵唔到匯入檔案") from exc
        if not stat.S_ISREG(metadata.st_mode):
            raise CorrectionMemoryError("匯入檔案必須係普通檔案")
        if metadata.st_size > MAX_IMPORT_BYTES:
            raise CorrectionMemoryError("匯入檔案過大")
        flags = os.O_RDONLY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        try:
            descriptor = os.open(source, flags)
            try:
                opened = os.fstat(descriptor)
                if not stat.S_ISREG(opened.st_mode):
                    raise CorrectionMemoryError("匯入檔案必須係普通檔案")
                if opened.st_size > MAX_IMPORT_BYTES:
                    raise CorrectionMemoryError("匯入檔案過大")
                chunks: list[bytes] = []
                remaining = MAX_IMPORT_BYTES + 1
                while remaining > 0:
                    chunk = os.read(descriptor, min(64 * 1024, remaining))
                    if not chunk:
                        break
                    chunks.append(chunk)
                    remaining -= len(chunk)
                payload = b"".join(chunks)
            finally:
                os.close(descriptor)
        except CorrectionMemoryError:
            raise
        except OSError as exc:
            raise CorrectionMemoryError("未能讀取匯入檔案") from exc
        if len(payload) > MAX_IMPORT_BYTES:
            raise CorrectionMemoryError("匯入檔案過大")
        return self.import_document(payload)

    def import_document(self, payload: bytes | str) -> tuple[CorrectionEntry, ...]:
        """Validate and merge a portable export as one all-or-nothing write."""

        if isinstance(payload, bytes):
            if len(payload) > MAX_IMPORT_BYTES:
                raise CorrectionMemoryError("匯入檔案過大")
            try:
                text = payload.decode("utf-8", errors="strict")
            except UnicodeError as exc:
                raise CorrectionMemoryError("匯入檔案必須使用 UTF-8") from exc
        elif isinstance(payload, str):
            if len(payload.encode("utf-8", errors="surrogatepass")) > MAX_IMPORT_BYTES:
                raise CorrectionMemoryError("匯入檔案過大")
            text = payload
        else:
            raise CorrectionMemoryError("匯入內容必須係 JSON")

        def strict_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
            output: dict[str, object] = {}
            for key, value in pairs:
                if key in output:
                    raise CorrectionMemoryError("匯入 JSON 有重複欄位")
                output[key] = value
            return output

        try:
            document = json.loads(text, object_pairs_hook=strict_object)
        except CorrectionMemoryError:
            raise
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise CorrectionMemoryError("匯入檔案唔係有效 JSON") from exc
        expected_keys = {
            "kind",
            "schema",
            "local_only",
            "free_form_rewrite",
            "automatic_application",
            "automatic_application_policy",
            "entries",
        }
        if not isinstance(document, dict) or set(document) != expected_keys:
            raise CorrectionMemoryError("匯入詞庫格式不完整")
        if document.get("kind") != EXPORT_KIND:
            raise CorrectionMemoryError("匯入詞庫類型不支援")
        if document.get("schema") != SCHEMA_VERSION:
            raise CorrectionMemoryError("匯入詞庫 schema 不支援")
        if document.get("local_only") is not True:
            raise CorrectionMemoryError("匯入詞庫必須標示只限本機")
        if document.get("free_form_rewrite") is not False:
            raise CorrectionMemoryError("匯入詞庫唔可以容許自由改寫")
        if document.get("automatic_application") is not True:
            raise CorrectionMemoryError("匯入詞庫自動套用規則無效")
        if document.get("automatic_application_policy") != AUTOMATIC_APPLICATION_POLICY:
            raise CorrectionMemoryError("匯入詞庫自動套用規則不支援")

        raw_entries = document.get("entries")
        if not isinstance(raw_entries, list):
            raise CorrectionMemoryError("匯入詞庫 entries 無效")
        entry_keys = {
            "canonical",
            "aliases",
            "accepted_count",
            "created_at",
            "updated_at",
            "last_source",
        }
        alias_keys = {
            "value",
            "accepted_count",
            "created_at",
            "updated_at",
            "last_source",
        }
        for raw_entry in raw_entries:
            if not isinstance(raw_entry, dict) or set(raw_entry) != entry_keys:
                raise CorrectionMemoryError("匯入詞庫 entry 格式無效")
            raw_aliases = raw_entry.get("aliases")
            if not isinstance(raw_aliases, list):
                raise CorrectionMemoryError("匯入詞庫 aliases 無效")
            if any(
                not isinstance(raw_alias, dict) or set(raw_alias) != alias_keys
                for raw_alias in raw_aliases
            ):
                raise CorrectionMemoryError("匯入詞庫 alias 格式無效")

        imported = correction_entries_from_snapshot(
            raw_entries,
            schema=SCHEMA_VERSION,
        )
        with self._locked():
            current = self._read_unlocked()
            merged = self._merge_explicit_import(current, imported)
            self._write_unlocked(merged)
            return tuple(merged)

    def _merge_explicit_import(
        self,
        current: Sequence[CorrectionEntry],
        imported: Sequence[CorrectionEntry],
    ) -> list[CorrectionEntry]:
        entries = list(current)
        now = max(0, int(self._clock()))

        for incoming in imported:
            canonical_key = _key(incoming.canonical)
            canonical_indices = {
                _key(entry.canonical): index for index, entry in enumerate(entries)
            }
            canonical_keys = set(canonical_indices)
            alias_owners = {
                _key(alias.value): _key(entry.canonical)
                for entry in entries
                for alias in entry.aliases
            }
            owner = alias_owners.get(canonical_key)
            if owner is not None and owner != canonical_key:
                raise CorrectionMemoryError("匯入 canonical 已經係另一個詞語嘅 alias")

            index = canonical_indices.get(canonical_key)
            if index is None:
                target = CorrectionEntry(
                    canonical=incoming.canonical,
                    aliases=(),
                    accepted_count=max(1, incoming.accepted_count),
                    created_at=now,
                    updated_at=now,
                )
                entries.append(target)
                index = len(entries) - 1
                canonical_keys.add(canonical_key)
            else:
                existing = entries[index]
                if existing.accepted_count >= MAX_CONFIRMATIONS:
                    raise CorrectionMemoryError("匯入詞庫確認次數超過上限")
                target = CorrectionEntry(
                    canonical=existing.canonical,
                    aliases=existing.aliases,
                    accepted_count=min(
                        MAX_CONFIRMATIONS,
                        max(existing.accepted_count + 1, incoming.accepted_count),
                    ),
                    created_at=existing.created_at,
                    updated_at=max(existing.updated_at, now),
                )

            merged_aliases = list(target.aliases)
            for incoming_alias in incoming.aliases:
                alias_key = _key(incoming_alias.value)
                if alias_key in canonical_keys and alias_key != canonical_key:
                    raise CorrectionMemoryError("匯入 alias 同另一個 canonical 衝突")
                alias_owner = alias_owners.get(alias_key)
                if alias_owner is not None and alias_owner != canonical_key:
                    raise CorrectionMemoryError("匯入 alias 已經屬於另一個 canonical")
                alias_index = next(
                    (
                        position
                        for position, alias in enumerate(merged_aliases)
                        if _key(alias.value) == alias_key
                    ),
                    None,
                )
                if alias_index is None:
                    merged_aliases.append(
                        CorrectionAlias(
                            value=incoming_alias.value,
                            accepted_count=max(1, incoming_alias.accepted_count),
                            created_at=now,
                            updated_at=now,
                            last_source="import",
                        )
                    )
                else:
                    existing_alias = merged_aliases[alias_index]
                    if existing_alias.accepted_count >= MAX_CONFIRMATIONS:
                        raise CorrectionMemoryError("匯入 alias 確認次數超過上限")
                    merged_aliases[alias_index] = CorrectionAlias(
                        value=existing_alias.value,
                        accepted_count=min(
                            MAX_CONFIRMATIONS,
                            max(
                                existing_alias.accepted_count + 1,
                                incoming_alias.accepted_count,
                            ),
                        ),
                        created_at=existing_alias.created_at,
                        updated_at=max(existing_alias.updated_at, now),
                        last_source="import",
                    )
                alias_owners[alias_key] = canonical_key

            if len(merged_aliases) > MAX_ALIASES:
                raise CorrectionMemoryError("匯入後 alias 數量過多")
            highest_alias_count = max(
                (alias.accepted_count for alias in merged_aliases),
                default=1,
            )
            entries[index] = CorrectionEntry(
                canonical=target.canonical,
                aliases=tuple(merged_aliases),
                accepted_count=max(target.accepted_count, highest_alias_count),
                created_at=target.created_at,
                updated_at=target.updated_at,
            )

        if len(entries) > MAX_ENTRIES:
            raise CorrectionMemoryError("匯入後詞庫項目過多")
        return entries

    def remember(
        self,
        *,
        canonical: str,
        aliases: Iterable[str] = (),
        source: str = "manual_alias",
    ) -> CorrectionEntry:
        canonical = _phrase(canonical, "canonical")
        if source not in {"accepted_edit", "manual_alias", "import"}:
            raise CorrectionMemoryError("修正記憶 source 無效")
        normalized_aliases: list[str] = []
        for raw_alias in aliases:
            alias = _phrase(raw_alias, "alias")
            if alias != canonical and _key(alias) not in {_key(item) for item in normalized_aliases}:
                normalized_aliases.append(alias)
        if len(normalized_aliases) > MAX_ALIASES:
            raise CorrectionMemoryError("alias 數量過多")

        with self._locked():
            entries = list(self._read_unlocked())
            canonical_key = _key(canonical)
            canonical_owners = {_key(entry.canonical): entry.canonical for entry in entries}
            alias_owners = {
                _key(alias.value): entry.canonical
                for entry in entries
                for alias in entry.aliases
            }
            existing_canonical = canonical_owners.get(canonical_key)
            alias_owner = alias_owners.get(canonical_key)
            if existing_canonical is None and alias_owner is not None:
                raise CorrectionMemoryError("canonical 已經係另一個詞語嘅 alias")
            for alias in normalized_aliases:
                alias_key = _key(alias)
                canonical_owner = canonical_owners.get(alias_key)
                if canonical_owner is not None and _key(canonical_owner) != canonical_key:
                    raise CorrectionMemoryError("alias 同另一個 canonical 衝突")
            for entry in entries:
                if _key(entry.canonical) == canonical_key:
                    continue
                foreign_aliases = {_key(alias.value) for alias in entry.aliases}
                if any(_key(alias) in foreign_aliases for alias in normalized_aliases):
                    raise CorrectionMemoryError("alias 已經屬於另一個 canonical")

            now = max(0, int(self._clock()))
            found_index = next(
                (index for index, item in enumerate(entries) if _key(item.canonical) == canonical_key),
                None,
            )
            if found_index is None:
                evidence = tuple(
                    CorrectionAlias(
                        value=alias,
                        accepted_count=1,
                        created_at=now,
                        updated_at=now,
                        last_source=source,
                    )
                    for alias in normalized_aliases
                )
                entry = CorrectionEntry(
                    canonical=canonical,
                    aliases=evidence,
                    accepted_count=1,
                    created_at=now,
                    updated_at=now,
                )
                entries.append(entry)
            else:
                current = entries[found_index]
                if current.accepted_count >= MAX_CONFIRMATIONS:
                    raise CorrectionMemoryError("修正記憶確認次數超過上限")
                merged = list(current.aliases)
                for alias in normalized_aliases:
                    alias_key = _key(alias)
                    evidence_index = next(
                        (
                            index
                            for index, item in enumerate(merged)
                            if _key(item.value) == alias_key
                        ),
                        None,
                    )
                    if evidence_index is None:
                        merged.append(
                            CorrectionAlias(
                                value=alias,
                                accepted_count=1,
                                created_at=now,
                                updated_at=now,
                                last_source=source,
                            )
                        )
                    else:
                        evidence = merged[evidence_index]
                        if evidence.accepted_count >= MAX_CONFIRMATIONS:
                            raise CorrectionMemoryError("alias 確認次數超過上限")
                        merged[evidence_index] = CorrectionAlias(
                            value=evidence.value,
                            accepted_count=evidence.accepted_count + 1,
                            created_at=evidence.created_at,
                            updated_at=max(evidence.updated_at, now),
                            last_source=source,
                        )
                if len(merged) > MAX_ALIASES:
                    raise CorrectionMemoryError("alias 數量過多")
                entry = CorrectionEntry(
                    canonical=current.canonical,
                    aliases=tuple(merged),
                    accepted_count=current.accepted_count + 1,
                    created_at=current.created_at,
                    updated_at=max(current.updated_at, now),
                )
                entries[found_index] = entry

            if len(entries) > MAX_ENTRIES:
                entries.sort(key=lambda item: (item.accepted_count, item.updated_at, item.canonical.casefold()))
                entries = entries[-MAX_ENTRIES:]
            self._write_unlocked(entries)
            return entry

    def remember_accepted_edit(self, before: str, after: str) -> CorrectionEntry | None:
        replacement = infer_single_replacement(before, after)
        if replacement is None:
            return None
        alias, canonical = replacement
        return self.remember(canonical=canonical, aliases=(alias,), source="accepted_edit")

    def delete(self, canonical: str) -> bool:
        canonical_key = _key(_phrase(canonical, "canonical"))
        with self._locked():
            entries = list(self._read_unlocked())
            kept = [item for item in entries if _key(item.canonical) != canonical_key]
            if len(kept) == len(entries):
                return False
            self._write_unlocked(kept)
            return True

    def clear(self) -> None:
        with self._locked():
            self._write_unlocked(())

    def prompt_terms(self, *, limit: int = 100) -> tuple[str, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 500:
            raise CorrectionMemoryError("prompt term limit 必須係 1 至 500")
        values = sorted(
            self.entries(),
            key=lambda item: (-item.accepted_count, -item.updated_at, item.canonical.casefold()),
        )
        return tuple(item.canonical for item in values[:limit])

    def candidates(self, text: str) -> tuple[CorrectionCandidate, ...]:
        if not isinstance(text, str):
            raise CorrectionMemoryError("candidate text 必須係文字")
        candidates: list[CorrectionCandidate] = []
        for entry in self.entries():
            for evidence in sorted(
                entry.aliases,
                key=lambda value: (-len(value.value), value.value.casefold()),
            ):
                alias = evidence.value
                if all(ord(character) < 128 for character in alias) and _ASCII_WORD.search(alias):
                    pattern = re.compile(
                        rf"(?<![A-Za-z0-9]){re.escape(alias)}(?![A-Za-z0-9])",
                        flags=re.IGNORECASE,
                    )
                    matches = pattern.finditer(text)
                else:
                    matches = re.finditer(re.escape(alias), text)
                for match in matches:
                    if all(ord(character) < 128 for character in alias) and not _latin_boundary_is_clear(
                        text, match.start(), match.end()
                    ):
                        continue
                    if text[match.start() : match.end()] == entry.canonical:
                        continue
                    candidates.append(
                        CorrectionCandidate(
                            start=match.start(),
                            end=match.end(),
                            before=text[match.start() : match.end()],
                            after=entry.canonical,
                            accepted_count=evidence.accepted_count,
                            last_source=evidence.last_source,
                        )
                    )
        candidates.sort(key=lambda item: (item.start, -(item.end - item.start), -item.accepted_count, item.after.casefold()))
        selected: list[CorrectionCandidate] = []
        occupied_until = -1
        for candidate in candidates:
            if candidate.start < occupied_until:
                continue
            selected.append(candidate)
            occupied_until = candidate.end
        return tuple(selected)


def apply_approved_corrections(
    text: str,
    entries: Sequence[CorrectionEntry],
) -> tuple[str, tuple[dict[str, object], ...]]:
    """Apply bounded aliases and return a complete, replayable audit trail.

    This function cannot invent text: every replacement must match one stored
    alias exactly (case-insensitively for ASCII terms), and overlapping aliases
    are resolved deterministically by longest match then confirmation count.
    """

    if not isinstance(text, str):
        raise CorrectionMemoryError("修正文字必須係文字")

    candidates: list[CorrectionCandidate] = []
    for entry in entries:
        for evidence in sorted(
            entry.aliases,
            key=lambda value: (-len(value.value), value.value.casefold()),
        ):
            alias = evidence.value
            if all(ord(character) < 128 for character in alias) and _ASCII_WORD.search(alias):
                matches = re.finditer(
                    rf"(?<![A-Za-z0-9]){re.escape(alias)}(?![A-Za-z0-9])",
                    text,
                    flags=re.IGNORECASE,
                )
            else:
                matches = re.finditer(re.escape(alias), text)
            for match in matches:
                if all(ord(character) < 128 for character in alias) and not _latin_boundary_is_clear(
                    text, match.start(), match.end()
                ):
                    continue
                if text[match.start() : match.end()] == entry.canonical:
                    continue
                candidate = CorrectionCandidate(
                    start=match.start(),
                    end=match.end(),
                    before=text[match.start() : match.end()],
                    after=entry.canonical,
                    accepted_count=evidence.accepted_count,
                    last_source=evidence.last_source,
                )
                if candidate.approved_for_automatic_application:
                    candidates.append(candidate)

    candidates.sort(
        key=lambda item: (
            item.start,
            -(item.end - item.start),
            -item.accepted_count,
            item.after.casefold(),
        )
    )
    selected: list[CorrectionCandidate] = []
    occupied_until = -1
    for candidate in candidates:
        if candidate.start < occupied_until:
            continue
        selected.append(candidate)
        occupied_until = candidate.end

    if not selected:
        return text, ()

    output: list[str] = []
    cursor = 0
    audit: list[dict[str, object]] = []
    output_offset = 0
    for candidate in selected:
        prefix = text[cursor : candidate.start]
        output.append(prefix)
        output_offset += len(prefix)
        start_after = output_offset
        output.append(candidate.after)
        output_offset += len(candidate.after)
        audit.append(
            {
                "source_start": candidate.start,
                "source_end": candidate.end,
                "output_start": start_after,
                "output_end": output_offset,
                "before": candidate.before,
                "after": candidate.after,
                "accepted_count": candidate.accepted_count,
                "last_source": candidate.last_source,
                "reason": candidate.reason,
            }
        )
        cursor = candidate.end
    output.append(text[cursor:])
    return "".join(output), tuple(audit)


def correction_entries_from_snapshot(
    values: object,
    *,
    schema: int | None = None,
) -> tuple[CorrectionEntry, ...]:
    """Validate immutable job metadata before it can affect a transcript."""

    if schema is None:
        alias_shapes: set[str] = set()
        if isinstance(values, (list, tuple)):
            for entry in values:
                if not isinstance(entry, Mapping):
                    alias_shapes.add("invalid")
                    continue
                aliases = entry.get("aliases")
                if not isinstance(aliases, (list, tuple)):
                    alias_shapes.add("invalid")
                    continue
                for alias in aliases:
                    alias_shapes.add(
                        "mapping"
                        if isinstance(alias, Mapping)
                        else "string"
                        if isinstance(alias, str)
                        else "invalid"
                    )
        else:
            alias_shapes.add("invalid")
        if "invalid" in alias_shapes or {"mapping", "string"}.issubset(alias_shapes):
            raise CorrectionMemoryError("job 修正記憶 schema shape 混合或無效")
        schema = 1 if alias_shapes == {"string"} else SCHEMA_VERSION
    if schema not in {1, SCHEMA_VERSION}:
        raise CorrectionMemoryError("job 修正記憶 schema 無效")
    if not isinstance(values, (list, tuple)) or len(values) > MAX_ENTRIES:
        raise CorrectionMemoryError("job 修正記憶 snapshot 無效")
    entries: list[CorrectionEntry] = []
    canonical_keys: set[str] = set()
    alias_owners: dict[str, str] = {}
    for raw in values:
        if not isinstance(raw, Mapping):
            raise CorrectionMemoryError("job 修正記憶 entry 無效")
        canonical = _phrase(raw.get("canonical"), "canonical")
        canonical_key = _key(canonical)
        if canonical_key in canonical_keys:
            raise CorrectionMemoryError("job 修正記憶 canonical 重複")
        canonical_keys.add(canonical_key)
        raw_aliases = raw.get("aliases")
        if not isinstance(raw_aliases, (list, tuple)) or len(raw_aliases) > MAX_ALIASES:
            raise CorrectionMemoryError("job 修正記憶 aliases 無效")
        count = raw.get("accepted_count")
        created_at = raw.get("created_at")
        updated_at = raw.get("updated_at")
        legacy_source = raw.get("last_source")
        if (
            isinstance(count, bool)
            or not isinstance(count, int)
            or not 1 <= count <= MAX_CONFIRMATIONS
            or isinstance(created_at, bool)
            or not isinstance(created_at, int)
            or created_at < 0
            or isinstance(updated_at, bool)
            or not isinstance(updated_at, int)
            or updated_at < created_at
            or (
                schema == 1
                and legacy_source not in {"accepted_edit", "manual_alias", "import"}
            )
        ):
            raise CorrectionMemoryError("job 修正記憶 metadata 無效")

        aliases: list[CorrectionAlias] = []
        for raw_alias in raw_aliases:
            if schema == 1:
                # V1 stored evidence at entry level, so per-alias confidence is
                # unknowable. Migrate conservatively as one inferred sighting.
                alias = _phrase(raw_alias, "alias")
                alias_count = 1
                alias_created_at = created_at
                alias_updated_at = updated_at
                alias_source = "accepted_edit"
            else:
                if not isinstance(raw_alias, Mapping):
                    raise CorrectionMemoryError("job 修正記憶 alias evidence 無效")
                alias = _phrase(raw_alias.get("value"), "alias")
                alias_count = raw_alias.get("accepted_count")
                alias_created_at = raw_alias.get("created_at")
                alias_updated_at = raw_alias.get("updated_at")
                alias_source = raw_alias.get("last_source")
                if (
                    isinstance(alias_count, bool)
                    or not isinstance(alias_count, int)
                    or not 1 <= alias_count <= MAX_CONFIRMATIONS
                    or isinstance(alias_created_at, bool)
                    or not isinstance(alias_created_at, int)
                    or alias_created_at < 0
                    or isinstance(alias_updated_at, bool)
                    or not isinstance(alias_updated_at, int)
                    or alias_updated_at < alias_created_at
                    or alias_updated_at > updated_at
                    or alias_source not in {"accepted_edit", "manual_alias", "import"}
                ):
                    raise CorrectionMemoryError("job 修正記憶 alias metadata 無效")
            alias_key = _key(alias)
            if alias == canonical:
                if schema == SCHEMA_VERSION:
                    raise CorrectionMemoryError("job 修正記憶 alias 同 canonical 重複")
                continue
            if alias_key in {_key(item.value) for item in aliases}:
                if schema == SCHEMA_VERSION:
                    raise CorrectionMemoryError("job 修正記憶 alias evidence 重複")
                continue
            owner = alias_owners.get(alias_key)
            if owner is not None and owner != canonical_key:
                raise CorrectionMemoryError("job 修正記憶 alias 有衝突")
            alias_owners[alias_key] = canonical_key
            aliases.append(
                CorrectionAlias(
                    value=alias,
                    accepted_count=int(alias_count),
                    created_at=int(alias_created_at),
                    updated_at=int(alias_updated_at),
                    last_source=str(alias_source),
                )
            )
        if any(alias.accepted_count > count for alias in aliases):
            raise CorrectionMemoryError("job 修正記憶 alias count 超過 entry count")
        entries.append(
            CorrectionEntry(
                canonical=canonical,
                aliases=tuple(aliases),
                accepted_count=count,
                created_at=created_at,
                updated_at=updated_at,
            )
        )
    for alias_key, owner in alias_owners.items():
        if alias_key in canonical_keys and alias_key != owner:
            raise CorrectionMemoryError("job 修正記憶 canonical 同 alias namespace 衝突")
    return tuple(entries)


__all__ = [
    "AUTOMATIC_APPLICATION_POLICY",
    "CorrectionCandidate",
    "CorrectionAlias",
    "CORRECTION_MEMORY_SCHEMA_VERSION",
    "CorrectionEntry",
    "CorrectionMemoryError",
    "CorrectionMemoryStore",
    "EXPORT_KIND",
    "apply_approved_corrections",
    "correction_entries_from_snapshot",
    "infer_single_replacement",
]
