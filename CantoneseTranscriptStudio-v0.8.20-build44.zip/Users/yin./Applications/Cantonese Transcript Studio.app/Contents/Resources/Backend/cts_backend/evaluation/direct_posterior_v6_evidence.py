"""Hash-pinned resolver for the current CTS multi-video direct evidence set.

This is deliberately a narrow research adapter, not an installed-app timing
integration.  It accepts a sample ID only, never caller-provided paths or
hashes, then replays the existing batch harness validators against the known
2026-09-03 v6 evidence bundle.  Any source drift, bundle mismatch, failed
wrapper gate, or unlisted sample fails closed.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from .direct_posterior_witness import (
    DIRECT_POSTERIOR_CONTEXT_SCHEMA,
    DirectPosteriorWitnessError,
    VerifiedDirectPosteriorContext,
    _mint_verified_direct_posterior_context,
)


class DirectPosteriorV6EvidenceError(DirectPosteriorWitnessError):
    """The selected v6 evidence bundle cannot be freshly verified."""


_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_EVIDENCE_ROOT = _PROJECT_ROOT / "dist" / "evidence"
_MANIFEST_PATH = _EVIDENCE_ROOT / "cts-multivideo-direct-posterior-batch-20260903-v6-manifest.json"
_RUN_ROOT = _EVIDENCE_ROOT / "cts-multivideo-direct-posterior-batch-20260903-v6-file-backed-witness-run"
_EXECUTION_PATH = _RUN_ROOT / "batch-execution-receipt.json"
_SHA256SUMS_PATH = _RUN_ROOT / "SHA256SUMS.txt"
_YIN_AUTHORITY_PATH = (
    _PROJECT_ROOT.parent
    / "codex-open-loop-audit"
    / "yin-feedback-2026-08-30-v13.json"
)

# These bind this adapter to the one actual run performed for the current
# scoped gate.  A later run requires a new explicit adapter/authority review;
# it cannot silently substitute itself through caller input.
_MANIFEST_FILE_SHA256 = "b2a99c8b1e6ff4e716f8dec44b0fc06b333049a9074dbd23fee5f186352b964a"
_EXECUTION_FILE_SHA256 = "1c106c8a8a995a3d435e1d26f7dbc044945c2de89ff517cc8cfa359fdb01f756"
_SHA256SUMS_FILE_SHA256 = "8dd3418b9c1f3aa7b6babe44294aca39bb7dcae9a71b1bbf513216a217cc49b2"
_YIN_AUTHORITY_FILE_SHA256 = "c4892e237c50c488012dda339d9550095b8365bfc5bd65772bb8fe891e45b4e1"
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _sha256_file(path: Path, label: str) -> str:
    try:
        if not path.is_absolute() or not path.is_file():
            raise DirectPosteriorV6EvidenceError(f"{label} 唔係可讀檔案")
        digest = hashlib.sha256()
        with path.open("rb") as source:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except OSError as exc:
        raise DirectPosteriorV6EvidenceError(f"{label} 無法讀取") from exc


def _require_exact_file_hash(path: Path, expected: str, label: str) -> None:
    if _sha256_file(path, label) != expected:
        raise DirectPosteriorV6EvidenceError(f"{label} SHA-256 與受信 v6 evidence 不一致")


def _load_sha256sums() -> dict[str, str]:
    _require_exact_file_hash(_SHA256SUMS_PATH, _SHA256SUMS_FILE_SHA256, "v6 SHA256SUMS")
    try:
        lines = _SHA256SUMS_PATH.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise DirectPosteriorV6EvidenceError("v6 SHA256SUMS 無法讀取") from exc
    rows: dict[str, str] = {}
    for line in lines:
        digest, separator, raw_relative = line.partition("  ")
        relative = raw_relative.strip()
        candidate = Path(relative)
        if (
            not separator
            or _SHA256_RE.fullmatch(digest) is None
            or not relative
            or candidate.is_absolute()
            or ".." in candidate.parts
            or relative in rows
        ):
            raise DirectPosteriorV6EvidenceError("v6 SHA256SUMS 格式或路徑無效")
        rows[relative] = digest
    if not rows:
        raise DirectPosteriorV6EvidenceError("v6 SHA256SUMS 冇 evidence entry")
    expected_files = {
        path.relative_to(_RUN_ROOT).as_posix()
        for path in _RUN_ROOT.rglob("*")
        if path.is_file() and path != _SHA256SUMS_PATH
    }
    if set(rows) != expected_files:
        raise DirectPosteriorV6EvidenceError("v6 SHA256SUMS 未完整覆蓋 run bundle")
    for relative, expected in rows.items():
        _require_exact_file_hash(_RUN_ROOT / relative, expected, f"v6 bundle {relative}")
    return rows


def _verify_yin_authority() -> None:
    _require_exact_file_hash(
        _YIN_AUTHORITY_PATH,
        _YIN_AUTHORITY_FILE_SHA256,
        "Yin CTS authority",
    )
    try:
        payload = json.loads(_YIN_AUTHORITY_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise DirectPosteriorV6EvidenceError("Yin CTS authority 無法讀取") from exc
    entries = payload.get("entries") if isinstance(payload, dict) else None
    if not isinstance(entries, list) or not any(
        isinstance(entry, dict)
        and entry.get("registry_ids")
        == ["cts-release", "cts-field-acceptance", "cts-timestamp-v3-validation"]
        and entry.get("decision") == "AI_VALIDATE_WITH_REFERENCE"
        for entry in entries
    ):
        raise DirectPosteriorV6EvidenceError("Yin CTS authority 不再授權 scoped reference validation")


def _batch_harness() -> Any:
    try:
        # Pytest imports the backend package directly, while the resolver is
        # intentionally rooted in this source workspace's exact harness.
        # Put only this verified project root on sys.path before the import.
        if str(_PROJECT_ROOT) not in sys.path:
            sys.path.insert(0, str(_PROJECT_ROOT))
        from scripts import wenet_direct_posterior_batch as harness
    except ImportError as exc:
        raise DirectPosteriorV6EvidenceError(
            "CTS batch harness 唔可由現有 source workspace 載入"
        ) from exc
    return harness


def _verified_context_payload(sample_id: object) -> Mapping[str, object]:
    if not isinstance(sample_id, str) or not sample_id.strip():
        raise DirectPosteriorV6EvidenceError("v6 direct evidence sample ID 無效")
    _verify_yin_authority()
    _require_exact_file_hash(_MANIFEST_PATH, _MANIFEST_FILE_SHA256, "v6 batch manifest")
    _require_exact_file_hash(_EXECUTION_PATH, _EXECUTION_FILE_SHA256, "v6 batch execution")
    hashes = _load_sha256sums()
    if hashes.get(_EXECUTION_PATH.relative_to(_RUN_ROOT).as_posix()) != _EXECUTION_FILE_SHA256:
        raise DirectPosteriorV6EvidenceError("v6 execution receipt 未由 SHA256SUMS 綁定")

    harness = _batch_harness()
    try:
        manifest, validated = harness._validate_manifest(_MANIFEST_PATH)
        execution = harness._load_json(_EXECUTION_PATH, "trusted v6 batch execution")
        if execution.get("schema") != harness.EXECUTION_SCHEMA:
            raise ValueError("unexpected batch execution schema")
        harness._verify_digest(execution, "receipt_sha256", "trusted v6 batch execution")
        harness._scope_is_non_mutating(execution.get("scope"), "trusted v6 batch execution")
        if execution.get("manifest") != harness._artifact(_MANIFEST_PATH):
            raise ValueError("execution raw manifest binding differs")
        if execution.get("manifest_sha256") != manifest.get("manifest_sha256"):
            raise ValueError("execution canonical manifest binding differs")
        if execution.get("source_imports") != validated["source_imports"]:
            raise ValueError("execution source-import authority differs")
        if execution.get("runtime_environment") != validated["runtime_environment"]:
            raise ValueError("execution runtime authority differs")
        post_run = execution.get("post_run_input_validation")
        if (
            execution.get("execution_complete") is not True
            or not isinstance(post_run, dict)
            or post_run.get("passed") is not True
            or post_run.get("manifest_sha256") != manifest.get("manifest_sha256")
            or post_run.get("batch_harness_sha256")
            != validated["source_imports"]["batch_harness"]["sha256"]
            or post_run.get("runtime_environment") != validated["runtime_environment"]
        ):
            raise ValueError("execution/post-run validation is incomplete")
        records = execution.get("samples")
        if not isinstance(records, list):
            raise ValueError("execution has no sample records")
        records_by_id = {
            record.get("sample_id"): record
            for record in records
            if isinstance(record, dict) and isinstance(record.get("sample_id"), str)
        }
        manifest_samples = {
            sample["sample_id"]: sample for sample in validated["samples"]
        }
        if set(records_by_id) != set(manifest_samples):
            raise ValueError("execution sample IDs differ from manifest")
        sample = manifest_samples.get(sample_id)
        record = records_by_id.get(sample_id)
        if sample is None or record is None:
            raise ValueError("sample is not in the fixed v6 evidence set")
        if (
            record.get("status") != "accepted"
            or record.get("wrapper_reproduction_gate_passed") is not True
        ):
            raise ValueError("sample did not pass the wrapper gate")
        receipt_path = harness._verify_artifact(
            record.get("receipt"), f"trusted {sample_id} direct receipt"
        )
        relative_receipt = receipt_path.relative_to(_RUN_ROOT).as_posix()
        if hashes.get(relative_receipt) != _sha256_file(
            receipt_path, f"trusted {sample_id} direct receipt"
        ):
            raise ValueError("direct receipt is not bound by v6 SHA256SUMS")
        harness._validate_direct_receipt(
            receipt_path,
            sample=sample,
            authority=validated,
        )
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise DirectPosteriorV6EvidenceError(
            f"v6 direct evidence read-back failed: {exc}"
        ) from exc

    return {
        "schema": DIRECT_POSTERIOR_CONTEXT_SCHEMA,
        "batch_manifest_path": str(_MANIFEST_PATH),
        "batch_manifest_file_sha256": _MANIFEST_FILE_SHA256,
        "batch_execution_receipt_path": str(_EXECUTION_PATH),
        "batch_execution_receipt_file_sha256": _EXECUTION_FILE_SHA256,
        "direct_receipt_path": str(receipt_path),
        "direct_receipt_file_sha256": hashes[relative_receipt],
        "sample_id": sample_id,
    }


def resolve_verified_v6_direct_evidence(
    sample_id: str,
) -> VerifiedDirectPosteriorContext:
    """Return a revalidating handle for one accepted fixed-v6 sample only."""

    payload = _verified_context_payload(sample_id)
    return _mint_verified_direct_posterior_context(
        payload,
        fresh_resolver=lambda: _verified_context_payload(sample_id),
    )


__all__ = [
    "DirectPosteriorV6EvidenceError",
    "resolve_verified_v6_direct_evidence",
]
