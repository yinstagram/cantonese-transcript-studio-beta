"""Conservative anonymous speaker continuity for local live captions.

The tracker deliberately answers only "does this voice match a stable session
prototype?".  It never guesses a person's identity, never persists a voice
print, and returns ``Unknown`` whenever the available utterance is too short or
the embedding evidence is ambiguous.
"""

from __future__ import annotations

import base64
import binascii
import gc
import json
import math
import struct
import sys
import threading
import time
import uuid
from array import array
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable


LIVE_SPEAKER_SNAPSHOT_SCHEMA_VERSION = 1
LIVE_SPEAKER_SNAPSHOT_ENCODING = "f32le-base64"
LIVE_SPEAKER_SNAPSHOT_MAXIMUM_BYTES = 1_048_576
LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS = 15


class LiveSpeakerError(RuntimeError):
    """A bounded local speaker-embedding operation could not complete."""


@runtime_checkable
class LocalSpeakerEmbeddingEngine(Protocol):
    """Small injectable contract used by the deterministic tracker tests."""

    name: str
    is_local: bool
    sample_rate: int

    def embed_pcm16(self, data: bytes) -> Sequence[float]: ...

    def close(self) -> None: ...


@dataclass(frozen=True)
class LiveSpeakerConfig:
    """Evidence thresholds and hard resource bounds for one live session."""

    sample_rate: int = 16_000
    minimum_audio_seconds: float = 1.0
    # A sub-second turn can never create or relabel a speaker by itself.  It
    # may, however, be retained *only in RAM* as a candidate when a following
    # full turn independently proves that it was a different voice.  The
    # limit is based on this Mac's controlled 3D-Speaker integration smoke,
    # not presented as a universal acoustic calibration.
    candidate_minimum_audio_seconds: float = 0.65
    candidate_confirmation_similarity: float = 0.60
    # A voice that is neither a safe match nor clearly dissimilar can be kept
    # as one bounded, RAM-only *suspected* change.  It still cannot become a
    # speaker unless the immediately following completed turn corroborates it.
    # Keep this below the normal match threshold so microphone distance/noise
    # does not turn a merely plausible return of the active speaker into B.
    uncertain_candidate_max_source_similarity: float = 0.65
    uncertain_candidate_max_gap_seconds: float = 3.0
    maximum_audio_seconds: float = 20.0
    enrollment_minimum_audio_seconds: float = 6.0
    enrollment_maximum_audio_seconds: float = 15.0
    # Enrollment is judged on effective speech, not wall-clock recording
    # length.  The profile is an aggregate of several temporally separated
    # voiced windows so one cough, pause, or microphone bump cannot become the
    # saved anchor for a person.
    enrollment_frame_ms: int = 20
    enrollment_minimum_voiced_rms: float = 0.012
    enrollment_maximum_clipping_ratio: float = 0.02
    enrollment_window_seconds: float = 2.0
    enrollment_window_hop_seconds: float = 1.0
    enrollment_minimum_window_voiced_ratio: float = 0.65
    enrollment_maximum_windows: int = 3
    enrollment_minimum_consistency_similarity: float = 0.55
    enrollment_maximum_cross_similarity: float = 0.72
    # Named-project identification is a closed-roster search, not anonymous
    # prototype creation.  sherpa-onnx's own live speaker-ID example uses 0.4
    # for this model family; keep it separate so private-session behaviour and
    # its deliberately stricter prototype threshold do not change.
    enrolled_match_similarity: float = 0.40
    enrolled_ambiguity_margin: float = 0.05
    match_similarity: float = 0.72
    new_speaker_similarity: float = 0.42
    ambiguity_margin: float = 0.12
    # Recognition and retention are intentionally different thresholds. A
    # plausible match can remain useful for this live caption session, but a
    # named project must not let one merely-plausible utterance permanently
    # pull its encrypted prototype toward the wrong person.
    profile_adaptation_similarity: float = 0.88
    profile_adaptation_margin: float = 0.18
    maximum_speakers: int = LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS
    maximum_prototype_observations: int = 32
    maximum_embedding_dimensions: int = 4_096

    def __post_init__(self) -> None:
        if self.sample_rate != 16_000:
            raise ValueError("live speaker tracker 只接受 16kHz PCM16")
        if self.minimum_audio_seconds < 1.0:
            raise ValueError("speaker identity evidence 最少需要一秒")
        if not 0.5 <= self.candidate_minimum_audio_seconds < self.minimum_audio_seconds:
            raise ValueError("speaker candidate evidence 必須介乎 0.5 秒同正式門檻之間")
        if not -1.0 <= self.candidate_confirmation_similarity <= 1.0:
            raise ValueError("speaker candidate cosine threshold 必須係 -1 至 1")
        if not (
            self.new_speaker_similarity
            < self.uncertain_candidate_max_source_similarity
            < self.match_similarity
        ):
            raise ValueError("uncertain speaker candidate threshold 必須介乎 new 同 match threshold")
        if not 0.25 <= self.uncertain_candidate_max_gap_seconds <= 10.0:
            raise ValueError("uncertain speaker candidate gap 必須係 0.25 至 10 秒")
        if not self.minimum_audio_seconds <= self.maximum_audio_seconds <= 30.0:
            raise ValueError("maximum_audio_seconds 必須介乎 minimum 同 30 秒")
        if not 4.0 <= self.enrollment_minimum_audio_seconds < self.enrollment_maximum_audio_seconds <= 30.0:
            raise ValueError("speaker enrollment 必須由至少 4 秒開始，而且少於 maximum")
        if not 10 <= self.enrollment_frame_ms <= 100:
            raise ValueError("speaker enrollment frame 必須係 10 至 100ms")
        if not 0.001 <= self.enrollment_minimum_voiced_rms <= 0.25:
            raise ValueError("speaker enrollment voiced RMS threshold 無效")
        if not 0.0 <= self.enrollment_maximum_clipping_ratio <= 0.10:
            raise ValueError("speaker enrollment clipping threshold 無效")
        if not 1.0 <= self.enrollment_window_seconds <= 4.0:
            raise ValueError("speaker enrollment window 必須係 1 至 4 秒")
        if not 0.25 <= self.enrollment_window_hop_seconds <= self.enrollment_window_seconds:
            raise ValueError("speaker enrollment window hop 無效")
        if not 0.25 <= self.enrollment_minimum_window_voiced_ratio <= 1.0:
            raise ValueError("speaker enrollment voiced window ratio 無效")
        if not 2 <= self.enrollment_maximum_windows <= 6:
            raise ValueError("speaker enrollment 最少聚合兩個 windows")
        if not -1.0 <= self.enrollment_minimum_consistency_similarity <= 1.0:
            raise ValueError("speaker enrollment consistency threshold 無效")
        if not -1.0 <= self.enrollment_maximum_cross_similarity <= 1.0:
            raise ValueError("speaker enrollment cross-similarity 必須係 -1 至 1")
        if not -1.0 <= self.enrolled_match_similarity <= 1.0:
            raise ValueError("enrolled speaker match threshold 必須係 -1 至 1")
        if not 0.0 <= self.enrolled_ambiguity_margin <= 1.0:
            raise ValueError("enrolled speaker ambiguity margin 必須係 0 至 1")
        if not -1.0 <= self.new_speaker_similarity < self.match_similarity <= 1.0:
            raise ValueError("speaker cosine thresholds 次序不正確")
        if not 0.0 < self.ambiguity_margin <= 1.0:
            raise ValueError("ambiguity_margin 必須係 0 至 1")
        if not self.match_similarity <= self.profile_adaptation_similarity <= 1.0:
            raise ValueError("profile adaptation similarity 必須唔低過 match threshold")
        if not self.ambiguity_margin <= self.profile_adaptation_margin <= 1.0:
            raise ValueError("profile adaptation margin 必須唔低過 ambiguity margin")
        if not 1 <= self.maximum_speakers <= 20:
            raise ValueError("maximum_speakers 必須係 1 至 20")
        if not 1 <= self.maximum_prototype_observations <= 1_000:
            raise ValueError("maximum_prototype_observations 必須係 1 至 1000")
        if not 16 <= self.maximum_embedding_dimensions <= 16_384:
            raise ValueError("maximum_embedding_dimensions 超出安全範圍")


@dataclass(frozen=True)
class LiveSpeakerAssignment:
    """JSON-safe anonymous label decision for one utterance."""

    speaker_index: int | None
    confidence: float | None
    reason: str
    similarity: float | None = None
    similarity_margin: float | None = None
    embedding_latency_ms: float | None = None
    candidate_state: str | None = None
    candidate_from_speaker_index: int | None = None
    candidate_evidence_seconds: float | None = None
    candidate_similarity: float | None = None
    candidate_observed_at_seconds: float | None = None

    @property
    def speaker_id(self) -> str | None:
        return (
            None
            if self.speaker_index is None
            else f"speaker-{self.speaker_index + 1}"
        )

    @property
    def label(self) -> str:
        return (
            "Unknown"
            if self.speaker_index is None
            else f"Speaker {self.speaker_index + 1}"
        )

    @property
    def is_unknown(self) -> bool:
        return self.speaker_index is None

    def to_metadata(self) -> dict[str, object]:
        """Use the same public keys as offline diarization where possible."""

        value: dict[str, object] = {
            "speaker_index": self.speaker_index,
            "speaker_id": self.speaker_id,
            "speaker_label": self.label,
            "speaker_confidence": self.confidence,
            "speaker_reason": self.reason,
            "speaker_similarity": self.similarity,
            "speaker_similarity_margin": self.similarity_margin,
            "speaker_embedding_latency_ms": self.embedding_latency_ms,
            "speaker_unknown": self.is_unknown,
            "speaker_tracking": "anonymous_session_continuity",
        }
        # Candidate metadata proves only a bounded, anonymous, in-session
        # state transition.  It never carries an embedding, raw audio, or a
        # person identity.
        if self.candidate_state is not None:
            value["speaker_candidate_state"] = self.candidate_state
            value["speaker_candidate_from_speaker_id"] = (
                None
                if self.candidate_from_speaker_index is None
                else f"speaker-{self.candidate_from_speaker_index + 1}"
            )
            value["speaker_candidate_evidence_seconds"] = self.candidate_evidence_seconds
            value["speaker_candidate_similarity"] = self.candidate_similarity
            value["speaker_candidate_observed_at_seconds"] = (
                self.candidate_observed_at_seconds
            )
        return value


@dataclass(frozen=True)
class LiveSpeakerEnrollmentQuality:
    """Audio-only quality evidence; never contains PCM or a voice vector."""

    recorded_seconds: float
    effective_voiced_seconds: float
    voiced_ratio: float
    rms: float
    voiced_rms: float
    peak: float
    clipping_ratio: float
    candidate_window_count: int
    enrollment_ready: bool
    rejection_reason: str | None

    def to_metadata(self) -> dict[str, int | float | bool | str | None]:
        return {
            "recorded_seconds": round(self.recorded_seconds, 3),
            "effective_voiced_seconds": round(self.effective_voiced_seconds, 3),
            "voiced_ratio": round(self.voiced_ratio, 6),
            "rms": round(self.rms, 6),
            "voiced_rms": round(self.voiced_rms, 6),
            "peak": round(self.peak, 6),
            "clipping_ratio": round(self.clipping_ratio, 8),
            "candidate_window_count": self.candidate_window_count,
            "enrollment_ready": self.enrollment_ready,
            "rejection_reason": self.rejection_reason,
        }


@dataclass
class _Prototype:
    index: int
    vector: tuple[float, ...]
    observations: int = 1


@dataclass(frozen=True)
class _PendingNewSpeakerCandidate:
    """One bounded, session-only sub-second voice candidate.

    This is deliberately not a prototype: it is never exported, persisted,
    or used to label rolling captions.  It can only turn into a new anonymous
    speaker after the following full utterance independently confirms it.
    """

    vector: tuple[float, ...]
    from_speaker_index: int
    evidence_seconds: float
    source_similarity: float


@dataclass(frozen=True)
class _PendingUncertainSpeakerCandidate:
    """One bounded, in-RAM uncertain voice window awaiting corroboration.

    Unlike a short clearly-dissimilar candidate, this records only a turn in
    the intentionally conservative similarity dead-zone.  It is never a
    prototype and is never exported/persisted.  The next completed turn must
    be both close to this vector and sufficiently unlike the last known
    speaker before it can mint a new anonymous label.
    """

    vector: tuple[float, ...]
    from_speaker_index: int
    evidence_seconds: float
    source_similarity: float
    observed_at_seconds: float


def _canonical_project_id(value: object, *, field: str = "project_id") -> str:
    """Accept a UUID string, then return the one stable wire representation."""

    if not isinstance(value, str):
        raise ValueError(f"{field} 必須係 UUID 字串")
    try:
        return str(uuid.UUID(value))
    except (ValueError, AttributeError) as exc:
        raise ValueError(f"{field} UUID 格式無效") from exc


def _canonical_sha256(value: object, *, field: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError(f"{field} 必須係 SHA-256 十六進位值")
    normalized = value.lower()
    if any(character not in "0123456789abcdef" for character in normalized):
        raise ValueError(f"{field} 必須係 SHA-256 十六進位值")
    return normalized


def _snapshot_size(value: Mapping[str, object]) -> int:
    """Bound the decoded JSON-shaped snapshot before it reaches any store."""

    try:
        encoded = json.dumps(
            value,
            ensure_ascii=True,
            separators=(",", ":"),
            sort_keys=True,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError("tracker_snapshot 必須係 JSON-safe object") from exc
    return len(encoded)


def _normalize_embedding(
    value: Sequence[float], *, maximum_dimensions: int
) -> tuple[float, ...] | None:
    if not value or len(value) > maximum_dimensions:
        return None
    try:
        vector = tuple(float(item) for item in value)
    except (TypeError, ValueError, OverflowError):
        return None
    if not all(math.isfinite(item) for item in vector):
        return None
    norm = math.sqrt(sum(item * item for item in vector))
    if not math.isfinite(norm) or norm <= 1e-8:
        return None
    return tuple(item / norm for item in vector)


def _cosine(left: Sequence[float], right: Sequence[float]) -> float:
    if len(left) != len(right) or not left:
        return -1.0
    return max(-1.0, min(1.0, sum(a * b for a, b in zip(left, right))))


def _pcm16_values(data: bytes) -> array[int]:
    if not data or len(data) % 2:
        raise ValueError("speaker PCM 必須係非空 little-endian PCM16 bytes")
    values = array("h")
    values.frombytes(data)
    if sys.byteorder != "little":  # pragma: no cover - Apple Silicon is little endian
        values.byteswap()
    return values


def analyze_enrollment_pcm16(
    data: bytes | bytearray | memoryview,
    *,
    config: LiveSpeakerConfig,
) -> LiveSpeakerEnrollmentQuality:
    """Measure effective speech without embedding or retaining the recording."""

    pcm = bytes(data)
    if not pcm:
        return LiveSpeakerEnrollmentQuality(
            recorded_seconds=0.0,
            effective_voiced_seconds=0.0,
            voiced_ratio=0.0,
            rms=0.0,
            voiced_rms=0.0,
            peak=0.0,
            clipping_ratio=0.0,
            candidate_window_count=0,
            enrollment_ready=False,
            rejection_reason="recording_too_short",
        )
    values = _pcm16_values(pcm)
    sample_count = len(values)
    recorded_seconds = sample_count / config.sample_rate
    frame_samples = max(
        1,
        round(config.sample_rate * config.enrollment_frame_ms / 1_000),
    )
    square_sum = 0
    clipped_samples = 0
    peak_sample = 0
    voiced_samples = 0
    voiced_square_sum = 0
    frame_voiced: list[bool] = []
    for start in range(0, sample_count, frame_samples):
        frame = values[start : min(sample_count, start + frame_samples)]
        if not frame:
            continue
        frame_square_sum = sum(int(item) * int(item) for item in frame)
        square_sum += frame_square_sum
        frame_rms = math.sqrt(frame_square_sum / len(frame)) / 32768.0
        voiced = frame_rms >= config.enrollment_minimum_voiced_rms
        frame_voiced.append(voiced)
        if voiced:
            voiced_samples += len(frame)
            voiced_square_sum += frame_square_sum
        for item in frame:
            absolute = abs(int(item))
            peak_sample = max(peak_sample, absolute)
            if absolute >= 32_604:  # 99.5% full scale
                clipped_samples += 1

    effective_voiced_seconds = voiced_samples / config.sample_rate
    voiced_ratio = voiced_samples / sample_count if sample_count else 0.0
    rms = math.sqrt(square_sum / sample_count) / 32768.0 if sample_count else 0.0
    voiced_rms = (
        math.sqrt(voiced_square_sum / voiced_samples) / 32768.0
        if voiced_samples
        else 0.0
    )
    clipping_ratio = clipped_samples / sample_count if sample_count else 0.0

    window_frames = max(
        1,
        round(config.enrollment_window_seconds * 1_000 / config.enrollment_frame_ms),
    )
    hop_frames = max(
        1,
        round(config.enrollment_window_hop_seconds * 1_000 / config.enrollment_frame_ms),
    )
    candidate_window_count = 0
    if len(frame_voiced) >= window_frames:
        for frame_start in range(0, len(frame_voiced) - window_frames + 1, hop_frames):
            window = frame_voiced[frame_start : frame_start + window_frames]
            if sum(window) / len(window) >= config.enrollment_minimum_window_voiced_ratio:
                candidate_window_count += 1

    rejection_reason: str | None = None
    if recorded_seconds < config.enrollment_minimum_audio_seconds:
        rejection_reason = "recording_too_short"
    elif clipping_ratio > config.enrollment_maximum_clipping_ratio:
        rejection_reason = "audio_clipping"
    elif voiced_samples == 0 and peak_sample > 0:
        rejection_reason = "signal_too_low"
    elif effective_voiced_seconds + 1e-6 < config.enrollment_minimum_audio_seconds:
        rejection_reason = "insufficient_voiced_speech"
    elif voiced_rms < config.enrollment_minimum_voiced_rms:
        rejection_reason = "signal_too_low"
    elif candidate_window_count < 2:
        rejection_reason = "insufficient_clean_windows"
    return LiveSpeakerEnrollmentQuality(
        recorded_seconds=recorded_seconds,
        effective_voiced_seconds=effective_voiced_seconds,
        voiced_ratio=voiced_ratio,
        rms=rms,
        voiced_rms=voiced_rms,
        peak=peak_sample / 32768.0,
        clipping_ratio=clipping_ratio,
        candidate_window_count=candidate_window_count,
        enrollment_ready=rejection_reason is None,
        rejection_reason=rejection_reason,
    )


def _enrollment_windows(
    pcm: bytes,
    *,
    config: LiveSpeakerConfig,
) -> tuple[bytes, ...]:
    """Select at most three clean, time-separated windows for aggregation."""

    values = _pcm16_values(pcm)
    frame_samples = max(
        1,
        round(config.sample_rate * config.enrollment_frame_ms / 1_000),
    )
    window_samples = round(config.sample_rate * config.enrollment_window_seconds)
    hop_samples = round(config.sample_rate * config.enrollment_window_hop_seconds)
    candidates: list[tuple[float, int, int]] = []
    for start in range(0, len(values) - window_samples + 1, hop_samples):
        end = start + window_samples
        voiced_frames = 0
        total_frames = 0
        for frame_start in range(start, end, frame_samples):
            frame = values[frame_start : min(end, frame_start + frame_samples)]
            if not frame:
                continue
            total_frames += 1
            square_sum = sum(int(item) * int(item) for item in frame)
            frame_rms = math.sqrt(square_sum / len(frame)) / 32768.0
            if frame_rms >= config.enrollment_minimum_voiced_rms:
                voiced_frames += 1
        ratio = voiced_frames / total_frames if total_frames else 0.0
        if ratio >= config.enrollment_minimum_window_voiced_ratio:
            candidates.append((ratio, start, end))
    if len(candidates) < 2:
        return ()
    # Temporal diversity is more important than selecting three adjacent
    # near-identical windows.  Pick evenly across the eligible recording.
    candidates.sort(key=lambda item: item[1])
    count = min(config.enrollment_maximum_windows, len(candidates))
    if count == 1:  # defensive: the quality gate always requires at least two
        selected = [candidates[0]]
    else:
        indices = [
            round(index * (len(candidates) - 1) / (count - 1))
            for index in range(count)
        ]
        selected = [candidates[index] for index in indices]
    return tuple(pcm[start * 2 : end * 2] for _, start, end in selected)


class SherpaSpeakerEmbeddingEngine:
    """One reusable local CPU 3D-Speaker embedding extractor."""

    name = "sherpa-onnx-3d-speaker-eres2net"
    is_local = True
    sample_rate = 16_000

    def __init__(
        self,
        model_path: str | Path,
        *,
        num_threads: int = 2,
        extractor_factory: Any | None = None,
    ) -> None:
        if not 1 <= int(num_threads) <= 4:
            raise ValueError("live speaker num_threads 必須係 1 至 4")
        self.model_path = Path(model_path).expanduser().resolve()
        if not self.model_path.is_file():
            raise FileNotFoundError(f"本地 speaker embedding 模型不存在：{self.model_path}")
        self.num_threads = int(num_threads)
        self._lock = threading.Lock()
        self._closed = False
        if extractor_factory is None:
            try:
                import sherpa_onnx
            except ImportError as exc:  # pragma: no cover - pinned production dependency
                raise LiveSpeakerError("runtime 未安裝 sherpa-onnx==1.13.4") from exc
            config = sherpa_onnx.SpeakerEmbeddingExtractorConfig(
                model=str(self.model_path),
                num_threads=self.num_threads,
                provider="cpu",
            )
            self._extractor = sherpa_onnx.SpeakerEmbeddingExtractor(config)
        else:
            self._extractor = extractor_factory(
                model=str(self.model_path),
                num_threads=self.num_threads,
                provider="cpu",
            )

    @property
    def resident_model_bytes(self) -> int:
        return self.model_path.stat().st_size

    def embed_pcm16(self, data: bytes) -> Sequence[float]:
        if not data or len(data) % 2:
            raise ValueError("speaker input 必須係非空 PCM16 bytes")
        pcm = array("h")
        pcm.frombytes(data)
        if sys.byteorder != "little":  # pragma: no cover - Apple Silicon is little endian
            pcm.byteswap()
        samples = array("f", (value / 32768.0 for value in pcm))
        with self._lock:
            if self._closed:
                raise LiveSpeakerError("speaker embedding engine 已關閉")
            stream = self._extractor.create_stream()
            try:
                stream.accept_waveform(self.sample_rate, samples)
                stream.input_finished()
                if not self._extractor.is_ready(stream):
                    raise LiveSpeakerError("speaker embedding audio 未達模型輸入要求")
                value = self._extractor.compute(stream)
                return tuple(float(item) for item in value)
            finally:
                del stream

    def close(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._closed = True
            extractor = self._extractor
            self._extractor = None
        del extractor
        gc.collect()


class LiveSpeakerTracker:
    """Keep bounded, anonymous voice prototypes for one in-memory session."""

    def __init__(
        self,
        engine: LocalSpeakerEmbeddingEngine,
        *,
        config: LiveSpeakerConfig | None = None,
        owns_engine: bool = True,
        clock: Any = time.perf_counter,
    ) -> None:
        if not getattr(engine, "is_local", False):
            raise ValueError("live speaker tracker 禁止使用非本地 engine")
        self.config = config or LiveSpeakerConfig()
        if int(getattr(engine, "sample_rate", 0)) != self.config.sample_rate:
            raise ValueError("speaker engine sample rate 同 tracker 唔一致")
        self.engine = engine
        self._owns_engine = bool(owns_engine)
        self._clock = clock
        self._lock = threading.RLock()
        self._inference_lock = threading.Lock()
        self._prototypes: list[_Prototype] = []
        self._active: LiveSpeakerAssignment | None = None
        self._last_known: LiveSpeakerAssignment | None = None
        self._pending_new_speaker: _PendingNewSpeakerCandidate | None = None
        self._pending_uncertain_speaker: _PendingUncertainSpeakerCandidate | None = None
        self._explicitly_enrolled = False
        self._closed = False
        self._cancelled = False
        self._assignments = 0
        self._unknown_assignments = 0
        self._maximum_latency_ms = 0.0
        # A project can suggest an expected headcount, but this is deliberately
        # only a cap for *new* anonymous labels. It never lowers a similarity
        # threshold or forces an unfamiliar voice onto an existing profile.
        self._expected_speaker_count: int | None = None

    @property
    def sample_rate(self) -> int:
        return self.config.sample_rate

    @property
    def speaker_count(self) -> int:
        with self._lock:
            return len(self._prototypes)

    @property
    def maximum_embedding_latency_ms(self) -> float:
        with self._lock:
            return self._maximum_latency_ms

    @property
    def expected_speaker_count(self) -> int | None:
        with self._lock:
            return self._expected_speaker_count

    @property
    def enrolled_roster_complete(self) -> bool:
        """True only for a closed roster with every expected anchor loaded."""

        with self._lock:
            return (
                self._explicitly_enrolled
                and self._expected_speaker_count is not None
                and len(self._prototypes) == self._expected_speaker_count
                and all(
                    prototype.index == index
                    for index, prototype in enumerate(self._prototypes)
                )
            )

    def set_expected_speaker_count(self, value: int | None) -> None:
        """Set a soft new-speaker cap for this process-only session."""

        if value is not None and (
            isinstance(value, bool)
            or not isinstance(value, int)
            or not 1 <= value <= self.config.maximum_speakers
        ):
            raise ValueError(
                "expected_speaker_count 必須係 1 至 "
                f"{self.config.maximum_speakers} 或留空"
            )
        with self._lock:
            self._ensure_open()
            self._expected_speaker_count = value
            if len(self._prototypes) >= self._new_speaker_cap():
                self._clear_pending_new_speaker()

    def _new_speaker_cap(self) -> int:
        """The hard safety cap always wins; expected count never forces a match."""

        expected = self._expected_speaker_count
        return self.config.maximum_speakers if expected is None else min(
            self.config.maximum_speakers,
            expected,
        )

    @staticmethod
    def _snapshot_identity(
        *,
        project_id: object,
        embedding_model_key: object,
        embedding_model_sha256: object,
    ) -> tuple[str, str, str]:
        canonical_project_id = _canonical_project_id(project_id)
        if not isinstance(embedding_model_key, str) or not embedding_model_key:
            raise ValueError("embedding_model_key 必須係非空字串")
        return (
            canonical_project_id,
            embedding_model_key,
            _canonical_sha256(
                embedding_model_sha256,
                field="embedding_model_sha256",
            ),
        )

    def restore_project_snapshot(
        self,
        snapshot: Mapping[str, object],
        *,
        project_id: object,
        embedding_model_key: object,
        embedding_model_sha256: object,
        require_complete: bool = True,
    ) -> None:
        """Load a strictly bounded encrypted-app payload into RAM only.

        The Python worker owns neither the encrypted file nor its key. This
        method receives a decoded JSON object from the native app, validates
        every field, and retains it for this one live session only. Normal
        live sessions require the whole closed roster. The explicit sequential
        enrollment RPC is the only caller allowed to restore a contiguous
        prefix while it records the next slot.
        """

        if not isinstance(require_complete, bool):
            raise ValueError("require_complete 必須係布林值")

        expected_project_id, expected_model_key, expected_model_sha256 = (
            self._snapshot_identity(
                project_id=project_id,
                embedding_model_key=embedding_model_key,
                embedding_model_sha256=embedding_model_sha256,
            )
        )
        if not isinstance(snapshot, Mapping):
            raise ValueError("tracker_snapshot 必須係 object")
        value = dict(snapshot)
        expected_keys = {
            "schema",
            "project_id",
            "embedding_model_key",
            "embedding_model_sha256",
            "sample_rate",
            "encoding",
            "profiles",
        }
        if set(value) != expected_keys:
            raise ValueError("tracker_snapshot 欄位不正確")
        if _snapshot_size(value) > LIVE_SPEAKER_SNAPSHOT_MAXIMUM_BYTES:
            raise ValueError("tracker_snapshot 超過 1MiB 安全上限")
        if (
            isinstance(value["schema"], bool)
            or not isinstance(value["schema"], int)
            or value["schema"] != LIVE_SPEAKER_SNAPSHOT_SCHEMA_VERSION
        ):
            raise ValueError("tracker_snapshot schema 不支援")
        snapshot_project_id = _canonical_project_id(value["project_id"])
        if snapshot_project_id != expected_project_id:
            raise ValueError("tracker_snapshot project_id 不一致")
        if (
            not isinstance(value["embedding_model_key"], str)
            or value["embedding_model_key"] != expected_model_key
        ):
            raise ValueError("tracker_snapshot 模型 key 不一致")
        snapshot_model_sha256 = _canonical_sha256(
            value["embedding_model_sha256"],
            field="tracker_snapshot embedding_model_sha256",
        )
        if snapshot_model_sha256 != expected_model_sha256:
            raise ValueError("tracker_snapshot 模型 SHA-256 不一致")
        if (
            isinstance(value["sample_rate"], bool)
            or not isinstance(value["sample_rate"], int)
            or value["sample_rate"] != self.config.sample_rate
        ):
            raise ValueError("tracker_snapshot sample_rate 必須係 16000")
        if (
            not isinstance(value["encoding"], str)
            or value["encoding"] != LIVE_SPEAKER_SNAPSHOT_ENCODING
        ):
            raise ValueError("tracker_snapshot encoding 不支援")
        raw_profiles = value["profiles"]
        maximum_snapshot_speakers = min(
            self.config.maximum_speakers,
            LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS,
        )
        if not isinstance(raw_profiles, list) or len(raw_profiles) > maximum_snapshot_speakers:
            raise ValueError("tracker_snapshot profiles 超出安全上限")

        restored: list[_Prototype] = []
        common_dimensions: int | None = None
        for expected_slot, raw_profile in enumerate(raw_profiles):
            if not isinstance(raw_profile, Mapping):
                raise ValueError("tracker_snapshot profile 必須係 object")
            profile = dict(raw_profile)
            if set(profile) != {
                "slot",
                "observations",
                "dimensions",
                "vector_f32le_base64",
            }:
                raise ValueError("tracker_snapshot profile 欄位不正確")
            slot = profile["slot"]
            observations = profile["observations"]
            dimensions = profile["dimensions"]
            encoded_vector = profile["vector_f32le_base64"]
            if isinstance(slot, bool) or not isinstance(slot, int) or slot != expected_slot:
                raise ValueError("tracker_snapshot profile slot 必須由 0 連續排序")
            if (
                isinstance(observations, bool)
                or not isinstance(observations, int)
                or not 1 <= observations <= self.config.maximum_prototype_observations
            ):
                raise ValueError("tracker_snapshot observations 超出安全範圍")
            if (
                isinstance(dimensions, bool)
                or not isinstance(dimensions, int)
                or not 1 <= dimensions <= self.config.maximum_embedding_dimensions
            ):
                raise ValueError("tracker_snapshot dimensions 超出安全範圍")
            if common_dimensions is None:
                common_dimensions = dimensions
            elif dimensions != common_dimensions:
                raise ValueError("tracker_snapshot embedding dimensions 不一致")
            if not isinstance(encoded_vector, str):
                raise ValueError("tracker_snapshot vector 必須係 base64 字串")
            # Base64 is 4/3 the source. This early check avoids allocating an
            # oversized decoded object even before the whole JSON size guard.
            maximum_base64_bytes = ((dimensions * 4 + 2) // 3) * 4
            if len(encoded_vector) > maximum_base64_bytes:
                raise ValueError("tracker_snapshot vector 長度不正確")
            try:
                packed = base64.b64decode(encoded_vector.encode("ascii"), validate=True)
            except (UnicodeEncodeError, binascii.Error, ValueError) as exc:
                raise ValueError("tracker_snapshot vector base64 無效") from exc
            if len(packed) != dimensions * 4:
                raise ValueError("tracker_snapshot vector dimensions 不正確")
            try:
                raw_vector = struct.unpack(f"<{dimensions}f", packed)
            except struct.error as exc:  # defensive; length was checked above
                raise ValueError("tracker_snapshot vector 格式無效") from exc
            normalized = _normalize_embedding(
                raw_vector,
                maximum_dimensions=self.config.maximum_embedding_dimensions,
            )
            if normalized is None:
                raise ValueError("tracker_snapshot vector 含無效數值")
            # Snapshots produced by this app are already normalized. Preserve
            # their decoded float32 anchors exactly so a clean project stop is
            # byte-identical; live matching must never rewrite enrolled data.
            raw_norm = math.sqrt(sum(float(item) * float(item) for item in raw_vector))
            vector = (
                tuple(float(item) for item in raw_vector)
                if 0.99 <= raw_norm <= 1.01
                else normalized
            )
            restored.append(
                _Prototype(index=slot, vector=vector, observations=observations)
            )

        with self._lock:
            self._ensure_open()
            if self._prototypes or self._assignments:
                raise LiveSpeakerError("speaker tracker 只可以喺 session 開始時載入 snapshot")
            if self._expected_speaker_count is None:
                raise ValueError("tracker_snapshot 必須有預期講者數目")
            if require_complete and len(restored) != self._expected_speaker_count:
                raise ValueError("tracker_snapshot 必須完整包含所有預期講者")
            if not require_complete and len(restored) > self._expected_speaker_count:
                raise ValueError("tracker_snapshot 講者數目超過預期上限")
            self._prototypes = restored
            self._explicitly_enrolled = True
            self._active = None
            self._last_known = None
            self._pending_new_speaker = None
            self._pending_uncertain_speaker = None

    def export_project_snapshot(
        self,
        *,
        project_id: object,
        embedding_model_key: object,
        embedding_model_sha256: object,
    ) -> dict[str, object]:
        """Return a small JSON-safe voiceprint payload without ever writing it.

        The native macOS layer immediately encrypts and persists this return
        value. No audio, transcript, user label, colour, path, or key crosses
        this boundary.
        """

        canonical_project_id, model_key, model_sha256 = self._snapshot_identity(
            project_id=project_id,
            embedding_model_key=embedding_model_key,
            embedding_model_sha256=embedding_model_sha256,
        )
        with self._lock:
            self._ensure_open()
            if len(self._prototypes) > LIVE_SPEAKER_SNAPSHOT_MAXIMUM_SPEAKERS:
                raise LiveSpeakerError("speaker snapshot 最多只可保留 8 位講者")
            profiles = [
                {
                    "slot": prototype.index,
                    "observations": prototype.observations,
                    "dimensions": len(prototype.vector),
                    "vector_f32le_base64": base64.b64encode(
                        struct.pack(f"<{len(prototype.vector)}f", *prototype.vector)
                    ).decode("ascii"),
                }
                for prototype in self._prototypes
            ]
        value: dict[str, object] = {
            "schema": LIVE_SPEAKER_SNAPSHOT_SCHEMA_VERSION,
            "project_id": canonical_project_id,
            "embedding_model_key": model_key,
            "embedding_model_sha256": model_sha256,
            "sample_rate": self.config.sample_rate,
            "encoding": LIVE_SPEAKER_SNAPSHOT_ENCODING,
            "profiles": profiles,
        }
        if _snapshot_size(value) > LIVE_SPEAKER_SNAPSHOT_MAXIMUM_BYTES:
            raise LiveSpeakerError("speaker snapshot 超過 1MiB 安全上限")
        return value

    def _ensure_open(self) -> None:
        if self._closed:
            raise LiveSpeakerError("live speaker tracker 已關閉")
        if self._cancelled:
            raise LiveSpeakerError("live speaker tracker 已取消")

    @staticmethod
    def _unknown(
        reason: str,
        *,
        similarity: float | None = None,
        margin: float | None = None,
        latency_ms: float | None = None,
        candidate_state: str | None = None,
        candidate_from_speaker_index: int | None = None,
        candidate_evidence_seconds: float | None = None,
        candidate_similarity: float | None = None,
        candidate_observed_at_seconds: float | None = None,
    ) -> LiveSpeakerAssignment:
        return LiveSpeakerAssignment(
            speaker_index=None,
            confidence=None,
            reason=reason,
            similarity=similarity,
            similarity_margin=margin,
            embedding_latency_ms=latency_ms,
            candidate_state=candidate_state,
            candidate_from_speaker_index=candidate_from_speaker_index,
            candidate_evidence_seconds=candidate_evidence_seconds,
            candidate_similarity=candidate_similarity,
            candidate_observed_at_seconds=candidate_observed_at_seconds,
        )

    def begin_utterance(self, *, continue_previous: bool = False) -> None:
        """Reset partial state; a forced continuous split may reuse its label."""

        with self._lock:
            self._ensure_open()
            if continue_previous and self._last_known is not None:
                previous = self._last_known
                self._active = LiveSpeakerAssignment(
                    speaker_index=previous.speaker_index,
                    confidence=previous.confidence,
                    reason="continuation_of_previous_utterance",
                    similarity=previous.similarity,
                    similarity_margin=previous.similarity_margin,
                )
            else:
                self._active = None

    def partial_assignment(self) -> LiveSpeakerAssignment:
        """Partials never create a speaker; most remain Unknown until final."""

        with self._lock:
            self._ensure_open()
            return self._active or self._unknown("awaiting_final_utterance")

    def _record(self, assignment: LiveSpeakerAssignment) -> LiveSpeakerAssignment:
        self._active = assignment
        self._assignments += 1
        if assignment.is_unknown:
            self._unknown_assignments += 1
        else:
            self._last_known = assignment
        return assignment

    def enroll_pcm16(
        self,
        data: bytes | bytearray | memoryview,
        *,
        target_slot: int,
    ) -> dict[str, int | float | bool | str | None]:
        """Explicitly replace or append one operator-confirmed voice slot.

        Enrollment audio is used only for this call and never retained.  Slots
        must be registered in order (speaker 1, then 2, ...), while re-recording
        an existing slot intentionally replaces its old prototype.  A voice too
        similar to another enrolled slot is rejected rather than allowed to
        poison both profiles.
        """

        pcm = bytes(data)
        if not pcm or len(pcm) % 2:
            raise ValueError("speaker enrollment 必須係非空 PCM16 bytes")
        if isinstance(target_slot, bool) or not isinstance(target_slot, int):
            raise ValueError("speaker enrollment target slot 必須係整數")
        quality = analyze_enrollment_pcm16(pcm, config=self.config)
        duration = quality.recorded_seconds
        if duration > self.config.enrollment_maximum_audio_seconds + 1e-6:
            raise ValueError("聲音註冊超過 15 秒上限")
        if not quality.enrollment_ready:
            messages = {
                "recording_too_short": "聲音註冊證據不足；請同一個講者連續講約 10 秒",
                "insufficient_voiced_speech": "實際講話時間不足 6 秒；請保持安靜環境再講約 10 秒",
                "signal_too_low": "收音太細聲；請靠近咪高峰重新講約 10 秒",
                "audio_clipping": "收音爆音過多；請降低音量或離咪高峰遠少少",
                "insufficient_clean_windows": "乾淨講話片段不足；請避免停頓及背景聲再錄一次",
            }
            raise ValueError(
                messages.get(
                    quality.rejection_reason,
                    "聲音註冊質量不足；請重新講約 10 秒",
                )
            )
        windows = _enrollment_windows(pcm, config=self.config)
        if len(windows) < 2:
            raise ValueError("乾淨講話片段不足；請避免停頓及背景聲再錄一次")
        with self._inference_lock:
            with self._lock:
                self._ensure_open()
                if not 0 <= target_slot < self._new_speaker_cap():
                    raise ValueError("speaker enrollment target slot 超出預期講者數")
                if target_slot > len(self._prototypes):
                    raise ValueError("請先註冊前一個講者，再註冊下一個")
            window_vectors: list[tuple[float, ...]] = []
            for window in windows:
                raw = self.engine.embed_pcm16(window)
                normalized = _normalize_embedding(
                    raw,
                    maximum_dimensions=self.config.maximum_embedding_dimensions,
                )
                if normalized is None:
                    raise LiveSpeakerError("聲音註冊 embedding 無效，請重新收音")
                if window_vectors and len(normalized) != len(window_vectors[0]):
                    raise LiveSpeakerError("聲音註冊 embedding 維度不一致")
                window_vectors.append(normalized)
        centroid = tuple(
            sum(vector[index] for vector in window_vectors) / len(window_vectors)
            for index in range(len(window_vectors[0]))
        )
        vector = _normalize_embedding(
            centroid,
            maximum_dimensions=self.config.maximum_embedding_dimensions,
        )
        minimum_consistency = (
            None
            if vector is None
            else min(_cosine(vector, window) for window in window_vectors)
        )
        with self._lock:
            self._ensure_open()
            if vector is None:
                raise LiveSpeakerError("聲音註冊 embedding 無效，請重新收音")
            if (
                minimum_consistency is None
                or minimum_consistency
                < self.config.enrollment_minimum_consistency_similarity
            ):
                raise LiveSpeakerError(
                    "錄音似乎包含多把聲或背景干擾；請只由同一位講者重新錄音"
                )
            if self._prototypes and len(vector) != len(self._prototypes[0].vector):
                raise LiveSpeakerError("聲音註冊 embedding 維度不一致")
            for prototype in self._prototypes:
                if prototype.index == target_slot:
                    continue
                similarity = _cosine(vector, prototype.vector)
                if similarity > self.config.enrollment_maximum_cross_similarity:
                    raise LiveSpeakerError(
                        "兩位講者聲音太相似，請分開重新錄 10 秒"
                    )
            if target_slot == len(self._prototypes):
                self._prototypes.append(
                    _Prototype(
                        index=target_slot,
                        vector=vector,
                        observations=len(window_vectors),
                    )
                )
                operation = "registered"
            else:
                existing = self._prototypes[target_slot]
                existing.vector = vector
                existing.observations = len(window_vectors)
                operation = "replaced"
            self._clear_pending_candidates()
            self._active = None
            self._last_known = None
            self._explicitly_enrolled = True
            return {
                "operation": operation,
                "slot": target_slot,
                "speaker_id": f"speaker-{target_slot + 1}",
                "duration_seconds": round(duration, 6),
                "profile_count": len(self._prototypes),
                "profile_window_count": len(window_vectors),
                "profile_minimum_consistency": round(minimum_consistency, 6),
                **quality.to_metadata(),
            }

    def enrollment_quality(
        self,
        data: bytes | bytearray | memoryview,
    ) -> dict[str, int | float | bool | str | None]:
        """Expose live quality progress without invoking the embedding model."""

        with self._lock:
            self._ensure_open()
        return analyze_enrollment_pcm16(data, config=self.config).to_metadata()

    def _clear_pending_new_speaker(self) -> None:
        """Drop provisional embedding evidence at every unsafe boundary."""

        self._pending_new_speaker = None

    def _clear_pending_uncertain_speaker(self) -> None:
        """Drop the one bounded dead-zone candidate without exporting it."""

        self._pending_uncertain_speaker = None

    def _clear_pending_candidates(self) -> None:
        self._clear_pending_new_speaker()
        self._clear_pending_uncertain_speaker()

    def _expire_pending_uncertain_speaker(self, observed_at_seconds: float) -> None:
        candidate = self._pending_uncertain_speaker
        if candidate is None:
            return
        if (
            observed_at_seconds < candidate.observed_at_seconds
            or observed_at_seconds - candidate.observed_at_seconds
            > self.config.uncertain_candidate_max_gap_seconds
        ):
            self._clear_pending_uncertain_speaker()

    def _mint(
        self,
        vector: tuple[float, ...],
        *,
        reason: str,
        confidence: float,
        similarity: float | None,
        margin: float | None,
        latency_ms: float,
        observations: int = 1,
        candidate_state: str | None = None,
        candidate_from_speaker_index: int | None = None,
        candidate_evidence_seconds: float | None = None,
        candidate_similarity: float | None = None,
        candidate_observed_at_seconds: float | None = None,
    ) -> LiveSpeakerAssignment:
        index = len(self._prototypes)
        self._prototypes.append(
            _Prototype(
                index=index,
                vector=vector,
                observations=min(max(1, observations), self.config.maximum_prototype_observations),
            )
        )
        return LiveSpeakerAssignment(
            speaker_index=index,
            confidence=round(max(0.0, min(1.0, confidence)), 6),
            reason=reason,
            similarity=None if similarity is None else round(similarity, 6),
            similarity_margin=None if margin is None else round(margin, 6),
            embedding_latency_ms=round(latency_ms, 3),
            candidate_state=candidate_state,
            candidate_from_speaker_index=candidate_from_speaker_index,
            candidate_evidence_seconds=candidate_evidence_seconds,
            candidate_similarity=candidate_similarity,
            candidate_observed_at_seconds=candidate_observed_at_seconds,
        )

    def _candidate_assignment(
        self,
        *,
        vector: tuple[float, ...],
        from_speaker_index: int,
        duration: float,
        similarity: float,
        latency_ms: float,
    ) -> LiveSpeakerAssignment:
        """Store exactly one short, dissimilar candidate in session RAM."""

        self._clear_pending_uncertain_speaker()
        self._pending_new_speaker = _PendingNewSpeakerCandidate(
            vector=vector,
            from_speaker_index=from_speaker_index,
            evidence_seconds=round(duration, 6),
            source_similarity=round(similarity, 6),
        )
        return self._unknown(
            "new_speaker_candidate_pending",
            similarity=round(similarity, 6),
            latency_ms=round(latency_ms, 3),
            candidate_state="pending",
            candidate_from_speaker_index=from_speaker_index,
            candidate_evidence_seconds=round(duration, 6),
        )

    def _uncertain_candidate_assignment(
        self,
        *,
        vector: tuple[float, ...],
        from_speaker_index: int,
        duration: float,
        similarity: float,
        latency_ms: float,
        observed_at_seconds: float,
    ) -> LiveSpeakerAssignment:
        """Retain one dead-zone turn for a possible, never-assumed handoff."""

        self._clear_pending_new_speaker()
        self._pending_uncertain_speaker = _PendingUncertainSpeakerCandidate(
            vector=vector,
            from_speaker_index=from_speaker_index,
            evidence_seconds=round(duration, 6),
            source_similarity=round(similarity, 6),
            observed_at_seconds=round(observed_at_seconds, 6),
        )
        return self._unknown(
            "uncertain_new_speaker_pending",
            similarity=round(similarity, 6),
            latency_ms=round(latency_ms, 3),
            candidate_state="suspected",
            candidate_from_speaker_index=from_speaker_index,
            candidate_evidence_seconds=round(duration, 6),
            candidate_observed_at_seconds=round(observed_at_seconds, 6),
        )

    def _candidate_confirmation_vector(
        self,
        candidate: _PendingNewSpeakerCandidate | _PendingUncertainSpeakerCandidate,
        vector: tuple[float, ...],
    ) -> tuple[float, ...]:
        """Use both corroborating turns for the new anonymous prototype."""

        combined = tuple((old + new) / 2 for old, new in zip(candidate.vector, vector))
        normalized = _normalize_embedding(
            combined,
            maximum_dimensions=self.config.maximum_embedding_dimensions,
        )
        # Both inputs were already normalized and dimension-checked.  Keep a
        # defensive fallback so a malformed native result can never crash a
        # live caption session.
        return vector if normalized is None else normalized

    def _confirmed_uncertain_candidate_assignment(
        self,
        *,
        vector: tuple[float, ...],
        best: _Prototype,
        best_similarity: float,
        decision_margin: float,
        reported_margin: float | None,
        duration: float,
        latency_ms: float,
    ) -> LiveSpeakerAssignment | None:
        """Promote one adjacent dead-zone candidate only with two safe signals."""

        candidate = self._pending_uncertain_speaker
        if (
            candidate is None
            or len(self._prototypes) >= self._new_speaker_cap()
            or candidate.from_speaker_index != best.index
            or len(candidate.vector) != len(vector)
            or candidate.source_similarity
            > self.config.uncertain_candidate_max_source_similarity
            or best_similarity > self.config.uncertain_candidate_max_source_similarity
            or decision_margin < self.config.ambiguity_margin
        ):
            return None
        candidate_similarity = _cosine(candidate.vector, vector)
        if candidate_similarity < self.config.candidate_confirmation_similarity:
            return None
        confirmed_vector = self._candidate_confirmation_vector(candidate, vector)
        candidate_seconds = candidate.evidence_seconds + duration
        self._clear_pending_candidates()
        return self._mint(
            confirmed_vector,
            reason="confirmed_uncertain_candidate_new_speaker",
            confidence=candidate_similarity,
            similarity=best_similarity,
            margin=reported_margin,
            latency_ms=latency_ms,
            observations=2,
            candidate_state="confirmed",
            candidate_from_speaker_index=candidate.from_speaker_index,
            candidate_evidence_seconds=round(candidate_seconds, 6),
            candidate_similarity=round(candidate_similarity, 6),
            candidate_observed_at_seconds=candidate.observed_at_seconds,
        )

    def _update_prototype(
        self, prototype: _Prototype, vector: tuple[float, ...]
    ) -> None:
        effective = min(
            prototype.observations,
            self.config.maximum_prototype_observations,
        )
        combined = tuple(
            (old * effective + new) / (effective + 1)
            for old, new in zip(prototype.vector, vector)
        )
        normalized = _normalize_embedding(
            combined,
            maximum_dimensions=self.config.maximum_embedding_dimensions,
        )
        if normalized is not None:
            prototype.vector = normalized
            prototype.observations = min(
                prototype.observations + 1,
                self.config.maximum_prototype_observations,
            )

    def assign_pcm16(
        self,
        data: bytes | bytearray | memoryview,
        *,
        overlap_detected: bool = False,
        observed_at_seconds: float | None = None,
    ) -> LiveSpeakerAssignment:
        """Assign one final VAD utterance, failing safe instead of guessing."""

        pcm = bytes(data)
        if not pcm or len(pcm) % 2:
            raise ValueError("speaker utterance 必須係非空 PCM16 bytes")
        samples = len(pcm) // 2
        duration = samples / self.config.sample_rate
        raw_observed_at = self._clock() if observed_at_seconds is None else observed_at_seconds
        try:
            observed_at = float(raw_observed_at)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("speaker observation time 必須係有限數字") from exc
        if not math.isfinite(observed_at) or observed_at < 0:
            raise ValueError("speaker observation time 必須係有限非負數字")
        short_candidate_eligible = False
        with self._lock:
            self._ensure_open()
            self._expire_pending_uncertain_speaker(observed_at)
            if overlap_detected:
                self._clear_pending_candidates()
                return self._record(self._unknown("overlapping_speech"))
            if duration > self.config.maximum_audio_seconds + 1e-6:
                raise ValueError(
                    f"speaker utterance {duration:.2f}s 超過 "
                    f"{self.config.maximum_audio_seconds:.2f}s 上限"
                )
            if duration < self.config.minimum_audio_seconds:
                previous = self._last_known
                short_candidate_eligible = (
                    duration >= self.config.candidate_minimum_audio_seconds
                    and (
                        self.enrolled_roster_complete
                        or (
                            previous is not None
                            and previous.speaker_index is not None
                            and len(self._prototypes) < self._new_speaker_cap()
                        )
                    )
                )
                if not short_candidate_eligible:
                    self._clear_pending_candidates()
                    return self._record(self._unknown("short_utterance"))

        with self._inference_lock:
            with self._lock:
                self._ensure_open()
            started = self._clock()
            raw = self.engine.embed_pcm16(pcm)
            latency_ms = max(0.0, (self._clock() - started) * 1_000)
        vector = _normalize_embedding(
            raw,
            maximum_dimensions=self.config.maximum_embedding_dimensions,
        )
        with self._lock:
            self._ensure_open()
            self._expire_pending_uncertain_speaker(observed_at)
            self._maximum_latency_ms = max(self._maximum_latency_ms, latency_ms)
            if vector is None:
                self._clear_pending_candidates()
                return self._record(
                    self._unknown("invalid_embedding", latency_ms=round(latency_ms, 3))
                )
            if not self._prototypes:
                self._clear_pending_candidates()
                if duration < self.config.minimum_audio_seconds:
                    return self._record(
                        self._unknown("short_utterance", latency_ms=round(latency_ms, 3))
                    )
                return self._record(
                    self._mint(
                        vector,
                        reason="first_reliable_utterance",
                        confidence=0.5,
                        similarity=None,
                        margin=None,
                        latency_ms=latency_ms,
                    )
                )

            if len(vector) != len(self._prototypes[0].vector):
                self._clear_pending_candidates()
                return self._record(
                    self._unknown("embedding_dimension_changed", latency_ms=latency_ms)
                )
            ranked = sorted(
                (
                    (_cosine(vector, prototype.vector), prototype)
                    for prototype in self._prototypes
                ),
                key=lambda item: (-item[0], item[1].index),
            )
            best_similarity, best = ranked[0]
            second_similarity = ranked[1][0] if len(ranked) > 1 else None
            # With one prototype there is no competing known identity, so the
            # ambiguity test is vacuously satisfied but no fake numeric margin
            # is exposed in audit metadata.
            decision_margin = (
                best_similarity - second_similarity
                if second_similarity is not None
                else 2.0
            )
            reported_margin = (
                None if second_similarity is None else decision_margin
            )
            # Explicitly enrolled profiles may classify a short, clear target
            # turn.  Without this gate, a 0.65–1s interjection from a known
            # speaker always became Unknown and delayed the operator cue.
            if (
                self._explicitly_enrolled
                and self.config.candidate_minimum_audio_seconds
                <= duration
                < self.config.minimum_audio_seconds
                and best_similarity >= self.config.enrolled_match_similarity
                and decision_margin >= self.config.enrolled_ambiguity_margin
            ):
                self._clear_pending_candidates()
                return self._record(
                    LiveSpeakerAssignment(
                        speaker_index=best.index,
                        confidence=round(max(0.0, min(1.0, best_similarity)), 6),
                        reason="matched_enrolled_profile_short_turn",
                        similarity=round(best_similarity, 6),
                        similarity_margin=(
                            None
                            if reported_margin is None
                            else round(reported_margin, 6)
                        ),
                        embedding_latency_ms=round(latency_ms, 3),
                    )
                )
            if duration < self.config.minimum_audio_seconds:
                previous = self._last_known
                if (
                    short_candidate_eligible
                    and previous is not None
                    and previous.speaker_index == best.index
                    and decision_margin >= self.config.ambiguity_margin
                    and len(self._prototypes) < self._new_speaker_cap()
                ):
                    if best_similarity <= self.config.new_speaker_similarity:
                        return self._record(
                            self._candidate_assignment(
                                vector=vector,
                                from_speaker_index=best.index,
                                duration=duration,
                                similarity=best_similarity,
                                latency_ms=latency_ms,
                            )
                        )
                    if (
                        best_similarity
                        <= self.config.uncertain_candidate_max_source_similarity
                    ):
                        return self._record(
                            self._uncertain_candidate_assignment(
                                vector=vector,
                                from_speaker_index=best.index,
                                duration=duration,
                                similarity=best_similarity,
                                latency_ms=latency_ms,
                                observed_at_seconds=observed_at,
                            )
                        )
                # A short match, too-similar dead-zone result, or
                # differently-ranked voice cannot be corroborated safely.
                self._clear_pending_candidates()
                return self._record(
                    self._unknown(
                        "short_utterance",
                        similarity=round(best_similarity, 6),
                        margin=(
                            None
                            if reported_margin is None
                            else round(reported_margin, 6)
                        ),
                        latency_ms=round(latency_ms, 3),
                    )
                )
            effective_match_similarity = (
                self.config.enrolled_match_similarity
                if self._explicitly_enrolled
                else self.config.match_similarity
            )
            effective_ambiguity_margin = (
                self.config.enrolled_ambiguity_margin
                if self._explicitly_enrolled
                else self.config.ambiguity_margin
            )
            if (
                best_similarity >= effective_match_similarity
                and decision_margin >= effective_ambiguity_margin
            ):
                # A normal recognition match is enough to label this turn, but
                # adaptive centroid updates (and therefore a later project
                # snapshot) require substantially stronger, unambiguous local
                # evidence. This is the bounded anti-poisoning gate.
                if (
                    not self._explicitly_enrolled
                    and
                    best_similarity >= self.config.profile_adaptation_similarity
                    and decision_margin >= self.config.profile_adaptation_margin
                ):
                    self._update_prototype(best, vector)
                self._clear_pending_candidates()
                return self._record(
                    LiveSpeakerAssignment(
                        speaker_index=best.index,
                        confidence=round(max(0.0, min(1.0, best_similarity)), 6),
                        reason="matched_stable_prototype",
                        similarity=round(best_similarity, 6),
                        similarity_margin=(
                            None
                            if reported_margin is None
                            else round(reported_margin, 6)
                        ),
                        embedding_latency_ms=round(latency_ms, 3),
                    )
                )
            if (
                best_similarity >= effective_match_similarity
                and decision_margin < effective_ambiguity_margin
            ):
                self._clear_pending_candidates()
                return self._record(
                    self._unknown(
                        "ambiguous_prototypes",
                        similarity=round(best_similarity, 6),
                        margin=round(decision_margin, 6),
                        latency_ms=round(latency_ms, 3),
                    )
                )
            # A named project is a closed roster. Unknown speech, background
            # media, and guests who were not enrolled must never mint or alter
            # an identity; they remain explicitly Unknown for operator review.
            if self._explicitly_enrolled:
                self._clear_pending_candidates()
                return self._record(
                    self._unknown(
                        "enrolled_voice_not_confident",
                        similarity=round(best_similarity, 6),
                        margin=(
                            None
                            if reported_margin is None
                            else round(reported_margin, 6)
                        ),
                        latency_ms=round(latency_ms, 3),
                    )
                )
            confirmed_uncertain = self._confirmed_uncertain_candidate_assignment(
                vector=vector,
                best=best,
                best_similarity=best_similarity,
                decision_margin=decision_margin,
                reported_margin=reported_margin,
                duration=duration,
                latency_ms=latency_ms,
            )
            if confirmed_uncertain is not None:
                return self._record(confirmed_uncertain)
            if best_similarity <= self.config.new_speaker_similarity:
                if len(self._prototypes) >= self._new_speaker_cap():
                    self._clear_pending_candidates()
                    return self._record(
                        self._unknown(
                            "speaker_limit_reached",
                            similarity=round(best_similarity, 6),
                            margin=(
                                None
                                if reported_margin is None
                                else round(reported_margin, 6)
                            ),
                            latency_ms=round(latency_ms, 3),
                        )
                    )
                candidate = self._pending_new_speaker
                candidate_similarity = (
                    None
                    if candidate is None
                    or candidate.from_speaker_index != best.index
                    or len(candidate.vector) != len(vector)
                    else _cosine(candidate.vector, vector)
                )
                if (
                    candidate is not None
                    and candidate_similarity is not None
                    and candidate_similarity
                    >= self.config.candidate_confirmation_similarity
                ):
                    confirmed_vector = self._candidate_confirmation_vector(candidate, vector)
                    candidate_seconds = candidate.evidence_seconds + duration
                    self._clear_pending_new_speaker()
                    return self._record(
                        self._mint(
                            confirmed_vector,
                            reason="confirmed_short_candidate_new_speaker",
                            confidence=candidate_similarity,
                            similarity=best_similarity,
                            margin=reported_margin,
                            latency_ms=latency_ms,
                            observations=2,
                            candidate_state="confirmed",
                            candidate_from_speaker_index=candidate.from_speaker_index,
                            candidate_evidence_seconds=round(candidate_seconds, 6),
                            candidate_similarity=round(candidate_similarity, 6),
                        )
                    )
                self._clear_pending_candidates()
                return self._record(
                    self._mint(
                        vector,
                        reason="new_dissimilar_speaker",
                        confidence=(
                            0.5
                            + 0.5
                            * (self.config.new_speaker_similarity - best_similarity)
                            / (self.config.new_speaker_similarity + 1.0)
                        ),
                        similarity=best_similarity,
                        margin=reported_margin,
                        latency_ms=latency_ms,
                    )
                )
            # A full turn in the bounded dead-zone is not a speaker label.
            # If it follows the last known voice and remains sufficiently far
            # from that voice, retain one ephemeral vector so the *next*
            # completed turn can corroborate it.  This never modifies a saved
            # project snapshot at the suspected stage.
            previous = self._last_known
            if (
                previous is not None
                and previous.speaker_index == best.index
                and len(self._prototypes) < self._new_speaker_cap()
                and best_similarity
                <= self.config.uncertain_candidate_max_source_similarity
                and decision_margin >= self.config.ambiguity_margin
            ):
                return self._record(
                    self._uncertain_candidate_assignment(
                        vector=vector,
                        from_speaker_index=best.index,
                        duration=duration,
                        similarity=best_similarity,
                        latency_ms=latency_ms,
                        observed_at_seconds=observed_at,
                    )
                )
            self._clear_pending_candidates()
            return self._record(
                self._unknown(
                    "insufficient_similarity_evidence",
                    similarity=round(best_similarity, 6),
                    margin=(
                        None
                        if reported_margin is None
                        else round(reported_margin, 6)
                    ),
                    latency_ms=round(latency_ms, 3),
                )
            )

    def end_utterance(self) -> None:
        with self._lock:
            if not self._closed:
                self._active = None

    def stats(self) -> dict[str, object]:
        with self._lock:
            return {
                "speaker_count": len(self._prototypes),
                "assignments": self._assignments,
                "unknown_assignments": self._unknown_assignments,
                "maximum_embedding_latency_ms": round(self._maximum_latency_ms, 3),
                "local_only": True,
                "persistent_voiceprints": self._explicitly_enrolled,
                "enrolled_roster_complete": self.enrolled_roster_complete,
                "closed_roster": self._explicitly_enrolled,
            }

    def cancel(self) -> None:
        with self._lock:
            if self._closed:
                return
            self._cancelled = True
            self._active = None
            self._last_known = None
            self._clear_pending_candidates()
            self._prototypes.clear()

    def close(self) -> None:
        engine: LocalSpeakerEmbeddingEngine | None = None
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._active = None
            self._last_known = None
            self._clear_pending_candidates()
            self._prototypes.clear()
            if self._owns_engine:
                engine = self.engine
        if engine is not None:
            # Never tear down a native ONNX extractor while an embedding call
            # is still inside it.  New calls see ``_closed`` before inference.
            with self._inference_lock:
                engine.close()
