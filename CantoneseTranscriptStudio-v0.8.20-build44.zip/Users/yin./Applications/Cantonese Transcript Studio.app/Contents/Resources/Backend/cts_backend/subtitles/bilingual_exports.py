"""Immutable, cue-aligned exports for locally translated subtitles."""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
import uuid
from dataclasses import replace
from pathlib import Path
from typing import Any, Mapping

from ..exports.safety import subtitle_safe_cue_text
from .ass import generate_ass
from .schemas import SubtitleCue, SubtitleProject


BILINGUAL_EXPORT_FORMATS = ("txt", "srt", "vtt", "ass")
BILINGUAL_EXPORT_LAYOUTS = ("bilingual", "translated")
_FILENAMES = {
    "txt": "subtitles.timestamps.txt",
    "srt": "subtitles.srt",
    "vtt": "subtitles.vtt",
    "ass": "subtitles.ass",
}
_LANGUAGE_TAG = re.compile(r"[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8}){0,3}")


def _sha256(payload: bytes) -> str:
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def _timestamp(milliseconds: int, *, decimal: str) -> str:
    hours, remainder = divmod(max(0, milliseconds), 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}{decimal}{millis:03d}"


def translation_result_sha256(value: Mapping[str, Any]) -> str:
    """Return the canonical identity for one validated translation result.

    The derived-artifact manifest has its own integrity seal.  Render manifests
    additionally pin the immutable ``result`` payload so a later queue worker
    can prove it is burning the exact cue text that the user saw.
    """

    payload = json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return _sha256(payload)


def _validated_text_by_id(
    project: SubtitleProject,
    translation: Mapping[str, Any],
    target_language: str,
) -> dict[str, str]:
    if translation.get("status") != "completed":
        raise ValueError("翻譯未完整完成，暫時唔可以匯出")
    if translation.get("target_language") != target_language:
        raise ValueError("翻譯語言同匯出要求唔一致")
    raw_cues = translation.get("cues")
    if not isinstance(raw_cues, list):
        raise ValueError("翻譯字幕格式無效")
    source_by_id = {cue.id: cue for cue in project.segments if cue.text.strip()}
    translated: dict[str, str] = {}
    for value in raw_cues:
        if not isinstance(value, Mapping):
            raise ValueError("翻譯字幕格式無效")
        cue_id = value.get("id")
        if not isinstance(cue_id, str) or cue_id in translated or cue_id not in source_by_id:
            raise ValueError("翻譯字幕 id 無效或重複")
        source = source_by_id[cue_id]
        source_text = value.get("source_text")
        translated_text = value.get("translated_text")
        # TranslationCue deliberately canonicalises surrounding whitespace
        # before sending text to the model.  Auto-segmented real projects can
        # retain a harmless leading space at a sentence boundary, so compare
        # the same canonical representation here.  Project revision and final
        # transcript hashes still fail closed for every actual source edit.
        if source_text != source.text.strip():
            raise ValueError("翻譯來源文字已過期")
        if not isinstance(translated_text, str) or not translated_text.strip():
            raise ValueError("翻譯字幕有空白內容")
        if round(float(value.get("start", -1)) * 1_000) != source.start_ms:
            raise ValueError("翻譯字幕開始時間已過期")
        if round(float(value.get("end", -1)) * 1_000) != source.end_ms:
            raise ValueError("翻譯字幕結束時間已過期")
        translated[cue_id] = translated_text.strip()
    if set(translated) != set(source_by_id):
        raise ValueError("翻譯字幕未涵蓋全部可見字幕")
    return translated


def _speaker_text(project: SubtitleProject, cue: SubtitleCue, text: str) -> str:
    speaker = next((item for item in project.speakers if item.id == cue.speaker_id), None)
    return f"{speaker.display_name}：{text}" if speaker is not None and speaker.show_name else text


def _visible_text(cue: SubtitleCue, translated: str, layout: str) -> str:
    return translated if layout == "translated" else f"{cue.text}\n{translated}"


def resolve_translated_project(
    project: SubtitleProject,
    translation: Mapping[str, Any],
    *,
    target_language: str,
    layout: str,
) -> SubtitleProject:
    """Resolve a cue-aligned bilingual/translated project without I/O.

    Render and file exports share this resolver.  FFmpeg rendering can then
    generate ASS at the *actual* source resolution rather than reusing the
    fixed 1920x1080 convenience export.
    """

    if _LANGUAGE_TAG.fullmatch(target_language) is None:
        raise ValueError("翻譯語言標籤無效")
    if layout not in BILINGUAL_EXPORT_LAYOUTS:
        raise ValueError("雙語字幕 layout 無效")
    translated_by_id = _validated_text_by_id(project, translation, target_language)
    segments = tuple(
        replace(cue, text=_visible_text(cue, translated_by_id[cue.id], layout))
        if cue.text.strip()
        else cue
        for cue in project.segments
    )
    return replace(project, segments=segments)


def _payloads(
    project: SubtitleProject,
    translated_project: SubtitleProject,
    *,
    layout: str,
) -> dict[str, bytes]:
    cues = tuple(cue for cue in project.segments if cue.text.strip())
    translated_by_id = {cue.id: cue.text for cue in translated_project.segments}
    display = [
        (
            cue,
            _speaker_text(
                project,
                cue,
                translated_by_id[cue.id],
            ),
        )
        for cue in cues
    ]
    txt_lines = [
        f"[{_timestamp(cue.start_ms, decimal='.')} → {_timestamp(cue.end_ms, decimal='.')}] {text}"
        for cue, text in display
    ]
    srt_blocks = [
        (
            f"{index}\n{_timestamp(cue.start_ms, decimal=',')} --> "
            f"{_timestamp(cue.end_ms, decimal=',')}\n{subtitle_safe_cue_text(text)}"
        )
        for index, (cue, text) in enumerate(display, start=1)
    ]
    vtt_blocks = ["WEBVTT"] + [
        (
            f"{_timestamp(cue.start_ms, decimal='.')} --> "
            f"{_timestamp(cue.end_ms, decimal='.')}\n{subtitle_safe_cue_text(text)}"
        )
        for cue, text in display
    ]
    return {
        "txt": ("\n".join(txt_lines) + ("\n" if txt_lines else "")).encode("utf-8"),
        "srt": ("\n\n".join(srt_blocks) + ("\n" if srt_blocks else "")).encode("utf-8"),
        "vtt": ("\n\n".join(vtt_blocks) + "\n").encode("utf-8"),
        "ass": generate_ass(translated_project, width=1_920, height=1_080).encode("utf-8"),
    }


def _write_new(path: Path, payload: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _verify(directory: Path, manifest: Mapping[str, Any]) -> dict[str, str]:
    path = directory / "manifest.json"
    if path.is_symlink() or not path.is_file():
        raise ValueError("雙語字幕匯出 manifest 缺失")
    existing = json.loads(path.read_text(encoding="utf-8"))
    if existing != manifest:
        raise ValueError("雙語字幕匯出 manifest 唔一致")
    paths: dict[str, str] = {}
    for kind, record in manifest["files"].items():
        file_path = directory / record["filename"]
        if file_path.is_symlink() or not file_path.is_file():
            raise ValueError(f"雙語字幕匯出缺少 {kind}")
        payload = file_path.read_bytes()
        if len(payload) != record["bytes"] or _sha256(payload) != record["sha256"]:
            raise ValueError(f"雙語字幕匯出 {kind} integrity 驗證失敗")
        paths[kind] = str(file_path.resolve())
    return paths


def export_bilingual_revision(
    workspace: str | Path,
    project: SubtitleProject,
    translation: Mapping[str, Any],
    *,
    target_language: str,
    layout: str,
) -> dict[str, str]:
    if _LANGUAGE_TAG.fullmatch(target_language) is None:
        raise ValueError("翻譯語言標籤無效")
    if layout not in BILINGUAL_EXPORT_LAYOUTS:
        raise ValueError("雙語字幕 layout 無效")
    root = Path(workspace).expanduser()
    if root.is_symlink() or not root.is_dir():
        raise ValueError("工作 workspace 路徑無效")
    root = root.resolve(strict=True)
    translated_project = resolve_translated_project(
        project,
        translation,
        target_language=target_language,
        layout=layout,
    )
    payloads = _payloads(project, translated_project, layout=layout)
    translation_sha = translation_result_sha256(translation)
    identity = translation_sha.removeprefix("sha256:")[:16]
    exports_root = root / "subtitle" / "translation-exports"
    if exports_root.is_symlink():
        raise ValueError("雙語字幕匯出目錄唔可以係 symlink")
    exports_root.mkdir(mode=0o700, parents=True, exist_ok=True)
    destination = (
        exports_root
        / f"revision-{project.revision}"
        / target_language.lower()
        / identity
        / layout
    )
    manifest = {
        "schema": 1,
        "project_revision": project.revision,
        "source_final_sha256": project.source_final_sha256,
        "translation_sha256": translation_sha,
        "target_language": target_language,
        "layout": layout,
        "files": {
            kind: {
                "filename": _FILENAMES[kind],
                "bytes": len(payload),
                "sha256": _sha256(payload),
            }
            for kind, payload in payloads.items()
        },
    }
    if destination.exists() or destination.is_symlink():
        if destination.is_symlink():
            raise ValueError("雙語字幕匯出路徑唔可以係 symlink")
        return _verify(destination, manifest)
    destination.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".translation-", suffix=".tmp", dir=destination.parent))
    try:
        for kind, payload in payloads.items():
            _write_new(staging / _FILENAMES[kind], payload)
        _write_new(
            staging / "manifest.json",
            (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8"),
        )
        os.replace(staging, destination)
        return _verify(destination, manifest)
    except BaseException:
        if staging.exists():
            failed = exports_root / ".failed-exports"
            failed.mkdir(mode=0o700, exist_ok=True)
            os.replace(staging, failed / uuid.uuid4().hex)
        raise


__all__ = [
    "BILINGUAL_EXPORT_FORMATS",
    "BILINGUAL_EXPORT_LAYOUTS",
    "export_bilingual_revision",
    "resolve_translated_project",
    "translation_result_sha256",
]
