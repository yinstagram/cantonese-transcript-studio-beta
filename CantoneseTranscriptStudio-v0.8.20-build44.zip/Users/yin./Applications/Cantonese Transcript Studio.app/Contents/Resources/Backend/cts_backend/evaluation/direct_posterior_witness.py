"""Fail-closed conversion of a sealed direct-posterior probe into one witness.

The direct Wenet CTC probe is deliberately non-mutating.  This module is the
small bridge between an accepted probe and the existing semantic-pairing gate:
it exposes *only* a fully covered, uniquely located candidate span as a
hash-bound acoustic witness.  It never reads a VTT object or reference cue
timing, and it never changes a CTS subtitle payload.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from ..normalization import HongKongNormalizer
from .metrics import comparison_text
from .semantic_pairing import canonical_sha256, timing_eligibility


DIRECT_POSTERIOR_WITNESS_SCHEMA = "cts.acoustic-witness/v1"
DIRECT_POSTERIOR_WITNESS_POLICY_VERSION = (
    "sealed-direct-posterior-acoustic-witness-v1-2026-09-03"
)
DIRECT_POSTERIOR_CONTEXT_SCHEMA = "cts.direct-posterior-acoustic-witness-context/v1"
_BATCH_MANIFEST_SCHEMA = "cts.wenet-direct-posterior-batch-manifest/v3"
_BATCH_EXECUTION_SCHEMA = "cts.wenet-direct-posterior-batch-execution/v3"
_DIRECT_RECEIPT_SCHEMA = "cts.wenet-direct-posterior-local-alignment/v1"
_HEX = frozenset("0123456789abcdef")
_MAX_DIRECT_EVIDENCE_FILE_BYTES = 64 * 1024 * 1024


class DirectPosteriorWitnessError(ValueError):
    """The evidence cannot safely become an acoustic witness."""


_VERIFIED_CONTEXT_MINT = object()


class VerifiedDirectPosteriorContext:
    """An opaque, revalidating handle to a selected direct-evidence set.

    Bare JSON path/hash maps are intentionally insufficient at the public
    timing gate.  A resolver must first bind the map to a selected evidence
    set and re-run its complete read-back before this handle can exist.  This
    protects the research gate from accidental or caller-supplied synthetic
    receipt chains; it is not a claim of protection against an actor who can
    alter both this source code and every local evidence file.
    """

    __slots__ = ("_payload", "_fresh_resolver")

    def __init__(
        self,
        payload: Mapping[str, object],
        fresh_resolver: Callable[[], Mapping[str, object]],
        *,
        mint: object,
    ) -> None:
        if mint is not _VERIFIED_CONTEXT_MINT:
            raise DirectPosteriorWitnessError(
                "direct posterior context 必須由受信 resolver 建立"
            )
        self._payload = dict(payload)
        self._fresh_resolver = fresh_resolver

    def _read_fresh_payload(self) -> Mapping[str, object]:
        fresh = self._fresh_resolver()
        if not isinstance(fresh, Mapping) or dict(fresh) != self._payload:
            raise DirectPosteriorWitnessError(
                "direct posterior resolver 回讀結果與 sealed context 不一致"
            )
        return fresh


def _mint_verified_direct_posterior_context(
    payload: Mapping[str, object],
    *,
    fresh_resolver: Callable[[], Mapping[str, object]],
) -> VerifiedDirectPosteriorContext:
    """Mint an opaque context only for a resolver that has already read back.

    This intentionally remains module-private.  The supported resolver lives
    beside the hash-pinned multi-video research evidence, rather than letting
    a public caller turn arbitrary self-sealed JSON into timing authority.
    """

    return VerifiedDirectPosteriorContext(
        payload,
        fresh_resolver,
        mint=_VERIFIED_CONTEXT_MINT,
    )


def _is_sha256(value: object) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in _HEX for character in value)
    )


def _require_mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise DirectPosteriorWitnessError(f"{label} 必須係 object")
    return value


def _require_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise DirectPosteriorWitnessError(f"{label} 必須係非空文字")
    return value


def _require_int(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise DirectPosteriorWitnessError(f"{label} 必須係整數")
    return value


def _require_finite_number(value: object, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise DirectPosteriorWitnessError(f"{label} 必須係數值")
    result = float(value)
    if not math.isfinite(result):
        raise DirectPosteriorWitnessError(f"{label} 必須係有限數值")
    return result


def _file_binding(value: object, label: str) -> tuple[str, str]:
    binding = _require_mapping(value, label)
    path = _require_text(binding.get("path"), f"{label} path")
    sha256 = binding.get("sha256")
    if not _is_sha256(sha256):
        raise DirectPosteriorWitnessError(f"{label} sha256 無效")
    return path, sha256


def _load_hash_locked_json(
    path_value: object, expected_sha256: object, label: str
) -> Mapping[str, object]:
    """Load one bounded JSON artifact only when its raw file hash matches."""

    path = Path(_require_text(path_value, f"{label} path"))
    if not path.is_absolute():
        raise DirectPosteriorWitnessError(f"{label} path 必須係 absolute path")
    if not _is_sha256(expected_sha256):
        raise DirectPosteriorWitnessError(f"{label} file hash 無效")
    try:
        stat = path.stat()
        if not path.is_file() or stat.st_size > _MAX_DIRECT_EVIDENCE_FILE_BYTES:
            raise DirectPosteriorWitnessError(f"{label} 唔係可讀 bounded file")
        raw = path.read_bytes()
    except OSError as exc:
        raise DirectPosteriorWitnessError(f"{label} 無法讀取") from exc
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise DirectPosteriorWitnessError(f"{label} raw file hash 不符合")
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DirectPosteriorWitnessError(f"{label} JSON 不可讀") from exc
    return _require_mapping(parsed, label)


def _validate_canonical(
    value: Mapping[str, object], *, schema: str, field: str, label: str
) -> None:
    if value.get("schema") != schema:
        raise DirectPosteriorWitnessError(f"{label} schema 唔符合")
    claimed = value.get(field)
    if not _is_sha256(claimed):
        raise DirectPosteriorWitnessError(f"{label} canonical hash 無效")
    body = dict(value)
    body.pop(field, None)
    if canonical_sha256(body) != claimed:
        raise DirectPosteriorWitnessError(f"{label} canonical hash mismatch")


def _non_mutating_scope(value: object, label: str) -> None:
    scope = _require_mapping(value, f"{label} scope")
    for field in (
        "job_mutated",
        "installed_app_mutated",
        "automatic_timing_mutation",
        "production_release_verdict",
    ):
        if scope.get(field) is not False:
            raise DirectPosteriorWitnessError(f"{label} 不是 non-mutating evidence")


def _normalised_characters(text: str) -> str:
    normalizer = HongKongNormalizer()
    return comparison_text(normalizer.normalize(text))


def _unique_range(haystack: str, needle: str) -> tuple[int, int]:
    if not needle:
        raise DirectPosteriorWitnessError("candidate span normalization 後為空")
    first = haystack.find(needle)
    if first < 0:
        raise DirectPosteriorWitnessError("candidate span 不在 sealed direct target")
    if haystack.find(needle, first + 1) >= 0:
        raise DirectPosteriorWitnessError("candidate span 在 sealed direct target 重複")
    return first, first + len(needle)


def _selected_packet_option(
    *,
    blind_review_packet: Mapping[str, object],
    reference_unit_id: str,
    candidate_span: Mapping[str, object],
) -> Mapping[str, object]:
    span_id = _require_text(candidate_span.get("span_id"), "candidate span ID")
    span_text = _require_text(candidate_span.get("text"), "candidate span text")
    span_text_sha256 = candidate_span.get("text_sha256")
    if span_text_sha256 != hashlib.sha256(span_text.encode("utf-8")).hexdigest():
        raise DirectPosteriorWitnessError("candidate span text hash 無效")
    atoms = candidate_span.get("atom_ids")
    if (
        not isinstance(atoms, Sequence)
        or isinstance(atoms, (str, bytes))
        or not atoms
        or any(not isinstance(item, str) or not item for item in atoms)
    ):
        raise DirectPosteriorWitnessError("candidate span atom IDs 無效")
    units = blind_review_packet.get("units")
    if not isinstance(units, Sequence) or isinstance(units, (str, bytes)):
        raise DirectPosteriorWitnessError("blind review packet units 無效")
    for unit in units:
        if not isinstance(unit, Mapping) or unit.get("reference_unit_id") != reference_unit_id:
            continue
        options = unit.get("candidate_options")
        if not isinstance(options, Sequence) or isinstance(options, (str, bytes)):
            continue
        for option in options:
            if not isinstance(option, Mapping) or option.get("candidate_span_id") != span_id:
                continue
            if (
                option.get("candidate_text") != span_text
                or option.get("candidate_text_sha256") != span_text_sha256
                or option.get("candidate_atom_ids") != list(atoms)
            ):
                raise DirectPosteriorWitnessError("candidate span 與 blind packet 不一致")
            return option
    raise DirectPosteriorWitnessError("candidate span 未綁定到 blind review packet")


def _find_sample(
    manifest: Mapping[str, object], sample_id: str
) -> Mapping[str, object]:
    samples = manifest.get("samples")
    if not isinstance(samples, Sequence) or isinstance(samples, (str, bytes)):
        raise DirectPosteriorWitnessError("direct batch manifest samples 無效")
    found = [
        item
        for item in samples
        if isinstance(item, Mapping) and item.get("sample_id") == sample_id
    ]
    if len(found) != 1:
        raise DirectPosteriorWitnessError("direct batch manifest sample 唔唯一")
    return found[0]


def _find_execution_sample(
    execution: Mapping[str, object], sample_id: str
) -> Mapping[str, object]:
    samples = execution.get("samples")
    if not isinstance(samples, Sequence) or isinstance(samples, (str, bytes)):
        raise DirectPosteriorWitnessError("direct batch execution samples 無效")
    found = [
        item
        for item in samples
        if isinstance(item, Mapping) and item.get("sample_id") == sample_id
    ]
    if len(found) != 1:
        raise DirectPosteriorWitnessError("direct batch execution sample 唔唯一")
    return found[0]


def _validated_direct_context(
    direct_posterior_context: object,
) -> dict[str, object]:
    """Read back every direct-posterior artifact a witness claims to bind.

    The context is deliberately transient input to the public timing gate, not
    embedded in a witness.  Every listed artifact is read afresh from its
    hash-locked local path; bare in-memory receipts never reopen the gate.
    """

    if not isinstance(direct_posterior_context, VerifiedDirectPosteriorContext):
        raise DirectPosteriorWitnessError(
            "direct posterior context 必須由受信 resolver 建立"
        )
    direct_posterior_context = direct_posterior_context._read_fresh_payload()
    expected_context_keys = {
        "schema",
        "batch_manifest_path",
        "batch_manifest_file_sha256",
        "batch_execution_receipt_path",
        "batch_execution_receipt_file_sha256",
        "direct_receipt_path",
        "direct_receipt_file_sha256",
        "sample_id",
    }
    if (
        set(direct_posterior_context) != expected_context_keys
        or direct_posterior_context.get("schema") != DIRECT_POSTERIOR_CONTEXT_SCHEMA
    ):
        raise DirectPosteriorWitnessError("direct posterior context schema keys 不符合")
    batch_manifest = _load_hash_locked_json(
        direct_posterior_context.get("batch_manifest_path"),
        direct_posterior_context.get("batch_manifest_file_sha256"),
        "direct batch manifest",
    )
    batch_execution_receipt = _load_hash_locked_json(
        direct_posterior_context.get("batch_execution_receipt_path"),
        direct_posterior_context.get("batch_execution_receipt_file_sha256"),
        "direct batch execution receipt",
    )
    direct_receipt_file_sha256 = direct_posterior_context.get("direct_receipt_file_sha256")
    direct_receipt = _load_hash_locked_json(
        direct_posterior_context.get("direct_receipt_path"),
        direct_receipt_file_sha256,
        "direct posterior receipt",
    )
    sample_id = _require_text(
        direct_posterior_context.get("sample_id"), "direct posterior context sample ID"
    )
    _validate_canonical(
        batch_manifest,
        schema=_BATCH_MANIFEST_SCHEMA,
        field="manifest_sha256",
        label="direct batch manifest",
    )
    _validate_canonical(
        batch_execution_receipt,
        schema=_BATCH_EXECUTION_SCHEMA,
        field="receipt_sha256",
        label="direct batch execution receipt",
    )
    _validate_canonical(
        direct_receipt,
        schema=_DIRECT_RECEIPT_SCHEMA,
        field="receipt_sha256",
        label="direct posterior receipt",
    )
    _non_mutating_scope(batch_manifest.get("scope"), "direct batch manifest")
    _non_mutating_scope(batch_execution_receipt.get("scope"), "direct batch execution receipt")
    _non_mutating_scope(direct_receipt.get("scope"), "direct posterior receipt")
    manifest_scope = _require_mapping(batch_manifest.get("scope"), "direct batch manifest scope")
    if manifest_scope.get("broader_human_gold_gate_overwritten") is not False:
        raise DirectPosteriorWitnessError("direct batch manifest 不可覆寫 broader human-gold gate")
    direct_scope = _require_mapping(direct_receipt.get("scope"), "direct posterior receipt scope")
    if direct_scope.get("native_ort_runner_used") is not True:
        raise DirectPosteriorWitnessError("direct posterior receipt 未使用 sealed native ORT runner")
    if batch_execution_receipt.get("execution_complete") is not True:
        raise DirectPosteriorWitnessError("direct batch execution 未完成")
    if (
        batch_execution_receipt.get("manifest_sha256")
        != batch_manifest.get("manifest_sha256")
    ):
        raise DirectPosteriorWitnessError("execution receipt 未綁定 batch manifest")
    if not _is_sha256(direct_receipt_file_sha256):
        raise DirectPosteriorWitnessError("direct posterior receipt file hash 無效")
    sample = _find_sample(batch_manifest, sample_id)
    execution_sample = _find_execution_sample(batch_execution_receipt, sample_id)
    receipt_artifact = _require_mapping(
        execution_sample.get("receipt"), "direct execution sample receipt"
    )
    if (
        execution_sample.get("status") != "accepted"
        or execution_sample.get("wrapper_reproduction_gate_passed") is not True
        or receipt_artifact.get("sha256") != direct_receipt_file_sha256
    ):
        raise DirectPosteriorWitnessError("direct execution sample 未通過 wrapper gate")
    result = _require_mapping(direct_receipt.get("result"), "direct posterior result")
    wrapper = _require_mapping(
        direct_receipt.get("wrapper_reproduction"), "direct posterior wrapper"
    )
    if (
        result.get("success") is not True
        or result.get("wrapper_reproduction_gate_passed") is not True
        or result.get("local_alignment_applied_to_job") is not False
        or wrapper.get("pass") is not True
        or wrapper.get("token_sequence_exact") is not True
    ):
        raise DirectPosteriorWitnessError("direct posterior receipt 未通過 exact wrapper gate")

    alignment = _require_mapping(sample.get("alignment"), "direct batch sample alignment")
    wav = _require_mapping(sample.get("wav"), "direct batch sample WAV")
    window = _require_mapping(sample.get("window"), "direct batch sample window")
    segment = _require_mapping(sample.get("segment"), "direct batch sample segment")
    inputs = _require_mapping(direct_receipt.get("inputs"), "direct posterior inputs")
    target = _require_mapping(inputs.get("target"), "direct posterior target")
    receipt_wav = _require_mapping(inputs.get("wav"), "direct posterior WAV")
    authority = _require_mapping(batch_manifest.get("authority"), "direct batch authority")
    expected_model = _file_binding(authority.get("model"), "sealed direct model")
    expected_tokens = _file_binding(authority.get("tokens"), "sealed direct tokens")
    expected_vad = _file_binding(authority.get("silero_vad_model"), "sealed direct VAD")
    expected_runner = _file_binding(
        authority.get("native_ort_runner"), "sealed native ORT runner"
    )
    actual_model = _file_binding(inputs.get("model"), "direct posterior model")
    actual_tokens = _file_binding(inputs.get("tokens"), "direct posterior tokens")
    vad = _require_mapping(direct_receipt.get("silero_vad"), "direct posterior VAD")
    actual_vad = _file_binding(vad.get("model"), "direct posterior VAD model")
    posterior = _require_mapping(direct_receipt.get("posterior"), "direct posterior output")
    inference = _require_mapping(posterior.get("inference"), "direct posterior inference")
    actual_runner = _file_binding(inference.get("runner"), "direct posterior native runner")
    if (
        actual_model != expected_model
        or actual_tokens != expected_tokens
        or actual_vad != expected_vad
        or actual_runner != expected_runner
    ):
        raise DirectPosteriorWitnessError("direct posterior runtime authority 與 sealed manifest 不一致")
    expected_target = (
        alignment.get("path"),
        alignment.get("sha256"),
        segment.get("index"),
        segment.get("start_ms"),
        segment.get("end_ms"),
        segment.get("chosen_text_sha256"),
    )
    actual_target = (
        target.get("path"),
        target.get("sha256"),
        target.get("segment_index"),
        target.get("segment_start_ms"),
        target.get("segment_end_ms"),
        target.get("text_sha256"),
    )
    if actual_target != expected_target:
        raise DirectPosteriorWitnessError("direct posterior target 與 sealed sample 不一致")
    if (
        receipt_wav.get("path") != wav.get("path")
        or receipt_wav.get("sha256") != wav.get("sha256")
        or window.get("path") != str(wav.get("path", "")).rsplit("/", 1)[-1]
        or window.get("sha256") != wav.get("sha256")
    ):
        raise DirectPosteriorWitnessError("direct posterior WAV/window 與 sealed sample 不一致")
    return {
        "batch_manifest": batch_manifest,
        "batch_execution_receipt": batch_execution_receipt,
        "direct_receipt": direct_receipt,
        "direct_receipt_file_sha256": direct_receipt_file_sha256,
        "sample_id": sample_id,
        "sample": sample,
        "window": window,
    }


def _speech_compatible(
    *,
    receipt: Mapping[str, object],
    forced_midpoint_ms: float,
) -> bool:
    vad = _require_mapping(receipt.get("silero_vad"), "direct posterior VAD")
    intervals = vad.get("speech_islands")
    margin = _require_finite_number(vad.get("near_margin_ms"), "VAD near margin")
    if (
        not isinstance(intervals, Sequence)
        or isinstance(intervals, (str, bytes))
        or margin < 0
    ):
        raise DirectPosteriorWitnessError("direct posterior VAD islands 無效")
    for item in intervals:
        if not isinstance(item, Mapping):
            continue
        start = _require_finite_number(item.get("start_ms"), "VAD island start")
        end = _require_finite_number(item.get("end_ms"), "VAD island end")
        if end < start:
            raise DirectPosteriorWitnessError("direct posterior VAD island 反轉")
        if start - margin <= forced_midpoint_ms <= end + margin:
            return True
    return False


def _character_anchors(
    *,
    direct_receipt: Mapping[str, object],
    target_normalized: str,
    candidate_start: int,
    candidate_end: int,
    window: Mapping[str, object],
) -> list[dict[str, object]]:
    window_start = _require_finite_number(window.get("start_ms"), "window start")
    window_end = _require_finite_number(window.get("end_ms"), "window end")
    core_start = _require_finite_number(window.get("core_start_ms"), "window core start")
    core_end = _require_finite_number(window.get("core_end_ms"), "window core end")
    if not window_start <= core_start <= core_end <= window_end:
        raise DirectPosteriorWitnessError("sealed window/core 範圍無效")
    islands = direct_receipt.get("aligned_islands")
    if not isinstance(islands, Sequence) or isinstance(islands, (str, bytes)) or not islands:
        raise DirectPosteriorWitnessError("direct posterior 冇 aligned islands")
    flattened: list[dict[str, object]] = []
    previous_end = -math.inf
    for island_index, island in enumerate(islands):
        if not isinstance(island, Mapping):
            raise DirectPosteriorWitnessError("direct posterior island 無效")
        tokens = island.get("tokens")
        if not isinstance(tokens, Sequence) or isinstance(tokens, (str, bytes)):
            raise DirectPosteriorWitnessError("direct posterior island tokens 無效")
        for token_index, token in enumerate(tokens):
            if not isinstance(token, Mapping):
                raise DirectPosteriorWitnessError("direct posterior token 無效")
            normalized = _require_text(token.get("normalized"), "direct posterior normalized token")
            positions = token.get("source_projected_positions")
            if (
                not isinstance(positions, Sequence)
                or isinstance(positions, (str, bytes))
                or len(positions) != len(normalized)
            ):
                raise DirectPosteriorWitnessError("direct posterior token source projection 無效")
            source_positions = [
                _require_int(position, "direct posterior source projected position")
                for position in positions
            ]
            if (
                any(position < 0 or position >= len(target_normalized) for position in source_positions)
                or source_positions != list(range(source_positions[0], source_positions[0] + len(source_positions)))
                or "".join(target_normalized[position] for position in source_positions) != normalized
            ):
                raise DirectPosteriorWitnessError("direct posterior token source projection 不可驗證")
            start = _require_finite_number(token.get("forced_start_ms"), "forced token start")
            end = _require_finite_number(token.get("forced_end_ms"), "forced token end")
            if not 0 <= start < end <= window_end - window_start or start < previous_end:
                raise DirectPosteriorWitnessError("direct posterior forced token timing 不可用")
            previous_end = end
            if any(candidate_start <= position < candidate_end for position in source_positions):
                if not all(candidate_start <= position < candidate_end for position in source_positions):
                    raise DirectPosteriorWitnessError("direct posterior token 跨出 semantic span")
                for offset, position in enumerate(source_positions):
                    character_start = window_start + start + (end - start) * offset / len(normalized)
                    character_end = window_start + start + (end - start) * (offset + 1) / len(normalized)
                    if not core_start <= character_start < character_end <= core_end:
                        raise DirectPosteriorWitnessError("direct posterior token 落在 window core 外")
                    if not _speech_compatible(
                        receipt=direct_receipt,
                        forced_midpoint_ms=(character_start + character_end) / 2 - window_start,
                    ):
                        raise DirectPosteriorWitnessError("direct posterior token 不相容 VAD")
                    flattened.append(
                        {
                            "source_projected_position": position,
                            "text": target_normalized[position],
                            "start_ms": round(character_start, 6),
                            "end_ms": round(character_end, 6),
                            "island_index": island_index,
                            "token_index": token_index,
                        }
                    )
    expected_positions = list(range(candidate_start, candidate_end))
    if [item["source_projected_position"] for item in flattened] != expected_positions:
        raise DirectPosteriorWitnessError("direct posterior 未完整覆蓋 semantic span")
    return flattened


def validate_direct_posterior_acoustic_witness(
    witness: Mapping[str, object],
    *,
    reference_unit_id: str,
    candidate_span_id: str,
    candidate_span_text: str,
    blind_review_packet_canonical_sha256: str,
    human_confirmation_receipt_canonical_sha256: str,
    monotonic_path_receipt_canonical_sha256: str,
    direct_posterior_context: object,
) -> None:
    """Validate a completed direct-posterior witness beyond a self-sealed hash.

    This deliberately rechecks the semantic binding, non-mutating scope,
    direct-posterior provenance fields and every character anchor against a
    fresh read of the hash-locked local evidence files.  A self-sealed witness
    alone can never reopen the timing gate.
    """

    _validate_canonical(
        witness,
        schema=DIRECT_POSTERIOR_WITNESS_SCHEMA,
        field="witness_canonical_sha256",
        label="direct posterior witness",
    )
    expected_keys = {
        "schema",
        "policy_version",
        "reference_unit_id",
        "candidate_span_id",
        "witness_id",
        "acoustic_source_sha256",
        "vad_compatible",
        "scope",
        "semantic_binding",
        "direct_posterior_binding",
        "candidate_normalized_source_range",
        "character_anchors",
        "witness_canonical_sha256",
    }
    if set(witness) != expected_keys or witness.get("policy_version") != DIRECT_POSTERIOR_WITNESS_POLICY_VERSION:
        raise DirectPosteriorWitnessError("direct posterior witness schema keys 不符合")
    if (
        witness.get("reference_unit_id") != reference_unit_id
        or witness.get("candidate_span_id") != candidate_span_id
        or witness.get("vad_compatible") is not True
        or not _is_sha256(witness.get("acoustic_source_sha256"))
    ):
        raise DirectPosteriorWitnessError("direct posterior witness pair 或 acoustic binding 不符合")
    scope = _require_mapping(witness.get("scope"), "direct posterior witness scope")
    if scope != {
        "automatic_timing_mutation": False,
        "production_release_verdict": False,
        "reference_timing_read": False,
        "local_direct_posterior_only": True,
    }:
        raise DirectPosteriorWitnessError("direct posterior witness scope 不符合")
    semantic_binding = _require_mapping(
        witness.get("semantic_binding"), "direct posterior witness semantic binding"
    )
    expected_semantic_binding = {
        "blind_review_packet_canonical_sha256": blind_review_packet_canonical_sha256,
        "human_confirmation_receipt_canonical_sha256": human_confirmation_receipt_canonical_sha256,
        "monotonic_path_receipt_canonical_sha256": monotonic_path_receipt_canonical_sha256,
        "candidate_span_text_sha256": hashlib.sha256(
            candidate_span_text.encode("utf-8")
        ).hexdigest(),
    }
    if semantic_binding != expected_semantic_binding:
        raise DirectPosteriorWitnessError("direct posterior witness semantic binding 不符合")

    context = _validated_direct_context(direct_posterior_context)
    batch_manifest = _require_mapping(context["batch_manifest"], "validated batch manifest")
    batch_execution = _require_mapping(
        context["batch_execution_receipt"], "validated batch execution receipt"
    )
    direct_receipt = _require_mapping(context["direct_receipt"], "validated direct receipt")
    sample = _require_mapping(context["sample"], "validated direct sample")
    window = _require_mapping(context["window"], "validated direct window")
    sample_id = _require_text(context["sample_id"], "validated direct sample ID")
    receipt_file_sha256 = _require_text(
        context["direct_receipt_file_sha256"], "validated direct receipt file hash"
    )
    segment = _require_mapping(sample.get("segment"), "validated direct sample segment")
    wav = _require_mapping(sample.get("wav"), "validated direct sample WAV")
    target_text = _require_text(segment.get("chosen_text"), "validated direct target text")
    target_normalized = _normalised_characters(target_text)
    candidate_normalized = _normalised_characters(candidate_span_text)
    candidate_start, candidate_end = _unique_range(target_normalized, candidate_normalized)
    expected_anchors = _character_anchors(
        direct_receipt=direct_receipt,
        target_normalized=target_normalized,
        candidate_start=candidate_start,
        candidate_end=candidate_end,
        window=window,
    )
    expected_range = {
        "start": candidate_start,
        "end": candidate_end,
        "character_count": len(expected_anchors),
    }
    expected_direct_binding = {
        "batch_manifest_sha256": batch_manifest.get("manifest_sha256"),
        "batch_execution_receipt_sha256": batch_execution.get("receipt_sha256"),
        "direct_receipt_canonical_sha256": direct_receipt.get("receipt_sha256"),
        "direct_receipt_file_sha256": receipt_file_sha256,
        "sample_id": sample_id,
        "segment_index": segment.get("index"),
        "target_text_sha256": segment.get("chosen_text_sha256"),
        "window_start_ms": window.get("start_ms"),
        "window_core_start_ms": window.get("core_start_ms"),
        "window_core_end_ms": window.get("core_end_ms"),
        "window_sha256": window.get("sha256"),
    }
    if (
        witness.get("witness_id") != f"{sample_id}:{candidate_span_id}"
        or witness.get("acoustic_source_sha256") != wav.get("sha256")
        or witness.get("direct_posterior_binding") != expected_direct_binding
        or witness.get("candidate_normalized_source_range") != expected_range
        or witness.get("character_anchors") != expected_anchors
    ):
        raise DirectPosteriorWitnessError("direct posterior witness 與 hash-locked evidence 不符合")


def build_direct_posterior_acoustic_witness(
    *,
    reference_unit_id: str,
    candidate_span: Mapping[str, object],
    relation: str,
    blind_review_packet: Mapping[str, object],
    human_confirmation_receipt: Mapping[str, object] | None,
    monotonic_path_receipt: Mapping[str, object] | None,
    direct_posterior_context: object,
) -> dict[str, object]:
    """Build one scoped witness or raise without changing any CTS payload.

    ``candidate_span`` must be a canonical row from the pairing-proposals
    artifact.  No reference VTT or reference timestamps are accepted here.
    """

    reference_unit_id = _require_text(reference_unit_id, "reference unit ID")
    candidate_span_id = _require_text(candidate_span.get("span_id"), "candidate span ID")
    if relation != "same_meaning":
        raise DirectPosteriorWitnessError("semantic relation 不是 same_meaning")
    _selected_packet_option(
        blind_review_packet=blind_review_packet,
        reference_unit_id=reference_unit_id,
        candidate_span=candidate_span,
    )
    semantic_ok, semantic_reason = timing_eligibility(
        reference_unit_id=reference_unit_id,
        candidate_span_id=candidate_span_id,
        relation=relation,
        blind_review_packet=blind_review_packet,
        human_confirmation_receipt=human_confirmation_receipt,
        monotonic_path_receipt=monotonic_path_receipt,
        acoustic_witness=None,
    )
    if semantic_ok or semantic_reason != "UNASSESSABLE_NO_ACOUSTIC_WITNESS":
        raise DirectPosteriorWitnessError(semantic_reason)
    context = _validated_direct_context(direct_posterior_context)
    batch_manifest = _require_mapping(context["batch_manifest"], "validated batch manifest")
    batch_execution_receipt = _require_mapping(
        context["batch_execution_receipt"], "validated batch execution receipt"
    )
    direct_receipt = _require_mapping(context["direct_receipt"], "validated direct receipt")
    direct_receipt_file_sha256 = _require_text(
        context["direct_receipt_file_sha256"], "validated direct receipt file hash"
    )
    sample_id = _require_text(context["sample_id"], "validated direct sample ID")
    sample = _require_mapping(context["sample"], "validated direct sample")
    window = _require_mapping(context["window"], "validated direct window")
    segment = _require_mapping(sample.get("segment"), "direct batch sample segment")
    target_text = _require_text(segment.get("chosen_text"), "direct batch target text")
    target_normalized = _normalised_characters(target_text)
    candidate_text = _require_text(candidate_span.get("text"), "candidate span text")
    candidate_normalized = _normalised_characters(candidate_text)
    candidate_start, candidate_end = _unique_range(target_normalized, candidate_normalized)
    anchors = _character_anchors(
        direct_receipt=direct_receipt,
        target_normalized=target_normalized,
        candidate_start=candidate_start,
        candidate_end=candidate_end,
        window=window,
    )
    wav = _require_mapping(sample.get("wav"), "direct batch sample WAV")
    acoustic_source_sha256 = wav.get("sha256")
    if not _is_sha256(acoustic_source_sha256):
        raise DirectPosteriorWitnessError("sealed WAV hash 無效")
    packet_hash = blind_review_packet.get("packet_canonical_sha256")
    human_hash = (
        human_confirmation_receipt.get("receipt_canonical_sha256")
        if isinstance(human_confirmation_receipt, Mapping)
        else None
    )
    path_hash = (
        monotonic_path_receipt.get("path_canonical_sha256")
        if isinstance(monotonic_path_receipt, Mapping)
        else None
    )
    witness: dict[str, object] = {
        "schema": DIRECT_POSTERIOR_WITNESS_SCHEMA,
        "policy_version": DIRECT_POSTERIOR_WITNESS_POLICY_VERSION,
        "reference_unit_id": reference_unit_id,
        "candidate_span_id": candidate_span_id,
        "witness_id": f"{sample_id}:{candidate_span_id}",
        "acoustic_source_sha256": acoustic_source_sha256,
        "vad_compatible": True,
        "scope": {
            "automatic_timing_mutation": False,
            "production_release_verdict": False,
            "reference_timing_read": False,
            "local_direct_posterior_only": True,
        },
        "semantic_binding": {
            "blind_review_packet_canonical_sha256": packet_hash,
            "human_confirmation_receipt_canonical_sha256": human_hash,
            "monotonic_path_receipt_canonical_sha256": path_hash,
            "candidate_span_text_sha256": candidate_span.get("text_sha256"),
        },
        "direct_posterior_binding": {
            "batch_manifest_sha256": batch_manifest.get("manifest_sha256"),
            "batch_execution_receipt_sha256": batch_execution_receipt.get("receipt_sha256"),
            "direct_receipt_canonical_sha256": direct_receipt.get("receipt_sha256"),
            "direct_receipt_file_sha256": direct_receipt_file_sha256,
            "sample_id": sample_id,
            "segment_index": segment.get("index"),
            "target_text_sha256": segment.get("chosen_text_sha256"),
            "window_start_ms": window.get("start_ms"),
            "window_core_start_ms": window.get("core_start_ms"),
            "window_core_end_ms": window.get("core_end_ms"),
            "window_sha256": window.get("sha256"),
        },
        "candidate_normalized_source_range": {
            "start": candidate_start,
            "end": candidate_end,
            "character_count": len(anchors),
        },
        "character_anchors": anchors,
    }
    witness["witness_canonical_sha256"] = canonical_sha256(witness)
    eligible, reason = timing_eligibility(
        reference_unit_id=reference_unit_id,
        candidate_span_id=candidate_span_id,
        relation=relation,
        blind_review_packet=blind_review_packet,
        human_confirmation_receipt=human_confirmation_receipt,
        monotonic_path_receipt=monotonic_path_receipt,
        acoustic_witness=witness,
        direct_posterior_context=direct_posterior_context,
    )
    if not eligible:
        raise DirectPosteriorWitnessError(f"completed witness 未通過 semantic gate: {reason}")
    return witness


__all__ = [
    "DIRECT_POSTERIOR_CONTEXT_SCHEMA",
    "DIRECT_POSTERIOR_WITNESS_POLICY_VERSION",
    "DIRECT_POSTERIOR_WITNESS_SCHEMA",
    "DirectPosteriorWitnessError",
    "VerifiedDirectPosteriorContext",
    "build_direct_posterior_acoustic_witness",
    "validate_direct_posterior_acoustic_witness",
]
