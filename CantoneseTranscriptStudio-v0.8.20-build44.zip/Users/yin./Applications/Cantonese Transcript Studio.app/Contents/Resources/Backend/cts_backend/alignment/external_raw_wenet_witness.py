"""Source-bound raw Wenet starts, separate from immutable display clocks.

The canonical seal detects accidental changes, not forged provenance. Callers
must bind the original verifier, PCM, model, source envelope and this code.
"""

from collections import Counter
from collections.abc import Mapping, Sequence
import hashlib
import json
import math
from typing import Any

from rapidfuzz.distance import Levenshtein

from ..normalization import HongKongNormalizer
from .wenet_timestamps import _Anchor, _augment_unique_native_runs, _project_source, _project_wenet_tokens


SCHEMA = "cts.external-wenet-raw-source-witness/v1"


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def _number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _integer(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _characters(text, rows, duration_ms):
    if not isinstance(text, str) or not text or not _integer(duration_ms) or duration_ms <= 0:
        raise ValueError("invalid source text or duration")
    result = {}
    for row in rows:
        if not isinstance(row, Mapping) or not _integer(row.get("source_index")):
            raise ValueError("invalid character source index")
        index = row["source_index"]
        if (index in result or not 0 <= index < len(text) or row.get("text") != text[index]
                or not _number(row.get("start_ms")) or not _number(row.get("end_ms"))
                or not 0 <= row["start_ms"] < row["end_ms"] <= duration_ms):
            raise ValueError("invalid or ambiguous character coverage")
        result[index] = row
    if len(result) != len(text):
        raise ValueError("incomplete character coverage")
    return result


def _bounds(row, *, final, duration_ms):
    values = []
    for name in ("start", "end"):
        sec, ms = row.get(name), row.get(name + "_ms")
        if final and ms is not None:
            if not _integer(ms):
                raise ValueError("invalid final core milliseconds")
            if sec is not None and (not _number(sec) or abs(sec * 1000 - ms) > 1e-6):
                raise ValueError("inconsistent final core seconds alias")
        else:
            if not _number(sec):
                raise ValueError("missing or invalid core seconds")
            ms = round(sec * 1000)
        values.append(ms)
    if not 0 <= values[0] < values[1] <= duration_ms:
        raise ValueError("core range outside full audio")
    return tuple(values)


def build_external_raw_wenet_witness(
    *, text: str, character_timestamps: Sequence[Mapping[str, Any]],
    final_segments: Sequence[Mapping[str, Any]], verifier_segments: Sequence[Mapping[str, Any]],
    duration_ms: int,
) -> dict[str, Any]:
    """Project exact unique runs without retiming any character or choosing by clock proximity."""
    characters = _characters(text, character_timestamps, duration_ms)
    if not final_segments or len(final_segments) != len(verifier_segments):
        raise ValueError("source/verifier segment count mismatch")
    for rows in (final_segments, verifier_segments):
        ids = []
        for row in rows:
            if not isinstance(row, Mapping):
                raise ValueError("segment must be an object")
            identifier = row.get("id")
            if identifier is not None:
                if not isinstance(identifier, str):
                    raise ValueError("invalid segment id")
                if identifier:
                    ids.append(identifier)
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate segment id")
    raw_parts = [row.get("text", row.get("chosen_text")) for row in final_segments]
    if any(not isinstance(part, str) or not part for part in raw_parts) or "".join(raw_parts) != text:
        raise ValueError("final segments do not exactly reconstruct source")
    witness = {"schema": SCHEMA, "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "character_timestamps_sha256": canonical_hash(character_timestamps), "duration_ms": duration_ms,
        "clock_domain": "absolute_full_audio_seconds_to_ms_once",
        "anchor_selection": "existing_unique_native_runs_only",
        "source_character_clocks_mutated": False, "acoustic_end_available": False,
        "acoustic_accuracy_status": "UNKNOWN", "caller_provenance_required": True,
        "anchors": [], "segments": []}
    normalizer = HongKongNormalizer()
    offset, previous_core_end = 0, 0
    for segment_index, (final, verifier, part) in enumerate(zip(final_segments, verifier_segments, raw_parts)):
        bounds = _bounds(final, final=True, duration_ms=duration_ms)
        if bounds != _bounds(verifier, final=False, duration_ms=duration_ms):
            raise ValueError("same-index exact core bounds mismatch")
        if bounds[0] < previous_core_end:
            raise ValueError("overlapping or out-of-order segment cores")
        previous_core_end = bounds[1]
        if final.get("id") and verifier.get("id") and final["id"] != verifier["id"]:
            raise ValueError("same-index segment identity mismatch")
        source = _project_source(part, normalizer, source_offset=offset)
        source_counts = Counter(row.source_index for row in source)
        tokens = verifier.get("tokens")
        if not isinstance(tokens, Sequence) or isinstance(tokens, (str, bytes)):
            raise ValueError("raw verifier token array missing")
        projected, origins = [], []
        previous_time = -1.0
        for token_index, token in enumerate(tokens):
            if (not isinstance(token, Mapping) or not isinstance(token.get("token"), str)
                    or not _number(token.get("timestamp"))):
                raise ValueError("malformed raw token")
            timestamp = token["timestamp"]
            if not bounds[0] / 1000 <= timestamp <= bounds[1] / 1000 or timestamp < previous_time:
                raise ValueError("raw token absolute timestamp outside core or non-monotonic")
            previous_time = timestamp
            pieces = _project_wenet_tokens([token], normalizer,
                segment_start_ms=bounds[0], segment_end_ms=bounds[1], native_starts_only=True)
            for piece_offset, piece in enumerate(pieces):
                origins.append({"raw_token_index": token_index, "raw_token": token["token"],
                    "raw_token_timestamp_seconds": timestamp, "raw_token_start_ms": round(timestamp * 1000),
                    "token_projected_character_offset": piece_offset})
                projected.append(piece)
        source_text = "".join(row.text for row in source)
        projected_text = "".join(row.text for row in projected)
        segment_audit = {"segment_index": segment_index, "source_start": offset,
            "source_end": offset + len(part), "core_start_ms": bounds[0], "core_end_ms": bounds[1],
            "final_segment_id": final.get("id"), "verifier_segment_id": verifier.get("id"),
            "source_projected_count": len(source), "witness_projected_count": len(projected),
            "raw_token_count": len(tokens), "accepted_anchor_count": 0,
            "segment_binding": "same_index_exact_core_bounds_and_complete_source_reconstruction"}
        witness["segments"].append(segment_audit)
        candidates = []
        # A source code point expanding into several normalized characters can
        # never acquire a unique native start through an opcode/dedup accident.
        segment_audit["quarantined_expanded_source_indices"] = [
            index for index, count in source_counts.items() if count != 1]
        for tag, a, b, c, d in Levenshtein.opcodes(source_text, projected_text):
            if tag != "equal" or b - a < 6:
                continue
            piece = source_text[a:b]
            unique = all(s.find(piece) >= 0 and s.find(piece, s.find(piece) + 1) < 0
                         for s in (source_text, projected_text))
            if not unique:
                continue
            for position in range(b - a):
                src, token = source[a + position], projected[c + position]
                if not token.has_native_start or source_counts[src.source_index] != 1:
                    continue
                current = characters[src.source_index]
                candidates.append(_Anchor(source_index=src.source_index,
                    current_start_ms=current["start_ms"], current_end_ms=current["end_ms"],
                    wenet_start_ms=token.start_ms, wenet_end_ms=token.start_ms,
                    anchor_clock="ctc_onset", witness_index=c + position,
                    exact_match_run=(a, b, c, d), exact_match_unique=True, source_projection_unique=True))
        by_source = Counter(a.source_index for a in candidates)
        by_token = Counter(origins[a.witness_index]["raw_token_index"] for a in candidates)
        ambiguous = [a for a in candidates if by_source[a.source_index] != 1
                     or by_token[origins[a.witness_index]["raw_token_index"]] != 1]
        segment_audit["ambiguous_assignment_count"] = len(ambiguous)
        clean = [a for a in candidates if by_source[a.source_index] == 1
                 and by_token[origins[a.witness_index]["raw_token_index"]] == 1]
        accepted, _, selection = _augment_unique_native_runs(clean, [])
        segment_audit["unique_run_selection"] = selection
        for anchor in accepted:
            witness["anchors"].append({"source_index": anchor.source_index,
                "source_character": text[anchor.source_index], "segment_index": segment_index,
                "projected_witness_index": anchor.witness_index,
                "source_projected_index": next(i for i, s in enumerate(source) if s.source_index == anchor.source_index),
                "exact_match_run": list(anchor.exact_match_run), "exact_match_unique": True,
                **origins[anchor.witness_index]})
        segment_audit["accepted_anchor_count"] = len(accepted)
        if not accepted:
            segment_audit["abstention_reason"] = "no_unambiguous_qualifying_unique_native_run"
        offset += len(part)
    witness["anchor_count"] = len(witness["anchors"])
    witness["report_sha256"] = canonical_hash(witness)
    validated_external_raw_starts(witness, text=text, character_timestamps=character_timestamps,
                                 duration_ms=duration_ms)
    return witness


def validated_external_raw_starts(witness, *, text, character_timestamps, duration_ms):
    """Validate structure/bindings and return source starts, not authenticated evidence."""
    characters = _characters(text, character_timestamps, duration_ms)
    if not isinstance(witness, Mapping):
        raise ValueError("external witness must be an object")
    unsigned = dict(witness)
    seal = unsigned.pop("report_sha256", None)
    if witness.get("schema") != SCHEMA or seal != canonical_hash(unsigned):
        raise ValueError("external witness schema or seal invalid")
    if (witness.get("text_sha256") != hashlib.sha256(text.encode("utf-8")).hexdigest()
            or witness.get("character_timestamps_sha256") != canonical_hash(character_timestamps)
            or witness.get("duration_ms") != duration_ms):
        raise ValueError("external witness source binding mismatch")
    if (witness.get("clock_domain") != "absolute_full_audio_seconds_to_ms_once"
            or witness.get("anchor_selection") != "existing_unique_native_runs_only"
            or witness.get("source_character_clocks_mutated") is not False
            or witness.get("acoustic_end_available") is not False
            or witness.get("caller_provenance_required") is not True
            or witness.get("acoustic_accuracy_status") != "UNKNOWN"):
        raise ValueError("external witness evidence semantics invalid")
    rows, segments = witness.get("anchors"), witness.get("segments")
    if not isinstance(rows, list) or not isinstance(segments, list) or not segments:
        raise ValueError("external witness arrays missing")
    expected, previous_end = 0, 0
    normalizer = HongKongNormalizer()
    projections = []
    final_ids, verifier_ids = set(), set()
    for index, seg in enumerate(segments):
        if (not isinstance(seg, Mapping)
                or any(not _integer(seg.get(k)) for k in ("segment_index", "source_start", "source_end",
                        "core_start_ms", "core_end_ms", "raw_token_count", "witness_projected_count", "source_projected_count", "accepted_anchor_count"))
                or seg["segment_index"] != index or seg["source_start"] != expected
                or not expected < seg["source_end"] <= len(text)
                or not previous_end <= seg["core_start_ms"] < seg["core_end_ms"] <= duration_ms
                or min(seg["raw_token_count"], seg["witness_projected_count"], seg["source_projected_count"], seg["accepted_anchor_count"]) < 0):
            raise ValueError("invalid external witness segment coverage")
        final_id, verifier_id = seg.get("final_segment_id"), seg.get("verifier_segment_id")
        for identifier, used_ids in ((final_id, final_ids), (verifier_id, verifier_ids)):
            if identifier is not None and not isinstance(identifier, str):
                raise ValueError("invalid external witness segment id")
            if identifier:
                if identifier in used_ids:
                    raise ValueError("duplicate external witness segment id")
                used_ids.add(identifier)
        if final_id and verifier_id and final_id != verifier_id:
            raise ValueError("conflicting external witness same-index segment ids")
        expected, previous_end = seg["source_end"], seg["core_end_ms"]
        projection = _project_source(text[seg["source_start"]:seg["source_end"]],
                                     normalizer, source_offset=seg["source_start"])
        if len(projection) != seg["source_projected_count"]:
            raise ValueError("external witness source projection count mismatch")
        projections.append(projection)
    if (expected != len(text) or not _integer(witness.get("anchor_count"))
            or witness["anchor_count"] != len(rows)):
        raise ValueError("external witness count or coverage mismatch")
    result, used_tokens, per_segment = {}, set(), Counter()
    grouped = {i: [] for i in range(len(segments))}
    previous_source = -1
    previous_clock = -1
    previous_positions = {}
    for row in rows:
        if (not isinstance(row, Mapping) or any(not _integer(row.get(k)) for k in
                ("source_index", "segment_index", "raw_token_index", "raw_token_start_ms",
                 "projected_witness_index", "source_projected_index", "token_projected_character_offset"))):
            raise ValueError("invalid external witness anchor indices")
        source, segment = row["source_index"], row["segment_index"]
        if not 0 <= segment < len(segments):
            raise ValueError("external witness segment index outside array")
        seg = segments[segment]
        timestamp, clock = row.get("raw_token_timestamp_seconds"), row["raw_token_start_ms"]
        run = row.get("exact_match_run")
        identity = (segment, row["raw_token_index"])
        previous = previous_positions.get(segment)
        if (source <= previous_source or not seg["source_start"] <= source < seg["source_end"]
                or row.get("source_character") != text[source]
                or not isinstance(row.get("raw_token"), str) or not row["raw_token"]
                or not 0 <= row["raw_token_index"] < seg["raw_token_count"]
                or identity in used_tokens or row["token_projected_character_offset"] != 0
                or not _number(timestamp) or round(timestamp * 1000) != clock
                or not seg["core_start_ms"] / 1000 <= timestamp <= seg["core_end_ms"] / 1000
                or clock <= previous_clock or row.get("exact_match_unique") is not True
                or not isinstance(run, list) or len(run) != 4 or any(not _integer(v) for v in run)
                or not 0 <= run[0] <= row["source_projected_index"] < run[1] <= seg["source_projected_count"]
                or not 0 <= run[2] <= row["projected_witness_index"] < run[3] <= seg["witness_projected_count"]
                or run[1] - run[0] < 6 or run[1] - run[0] != run[3] - run[2]
                or row["source_projected_index"] - run[0] != row["projected_witness_index"] - run[2]):
            raise ValueError("contradictory external witness anchor")
        if previous is not None and (
                row["raw_token_index"] <= previous["raw_token_index"]
                or row["projected_witness_index"] <= previous["projected_witness_index"]
                or row["projected_witness_index"] < previous["token_projection_end"]
                or row["source_projected_index"] <= previous["source_projected_index"]):
            raise ValueError("external witness token order or projection overlap contradiction")
        projection = projections[segment]
        counts = Counter(item.source_index for item in projection)
        projected_source_text = "".join(item.text for item in projection)
        matched_piece = projected_source_text[run[0]:run[1]]
        token_projection = _project_wenet_tokens(
            [{"token": row["raw_token"], "timestamp": timestamp}], normalizer,
            segment_start_ms=seg["core_start_ms"], segment_end_ms=seg["core_end_ms"],
            native_starts_only=True)
        # Only the intersection with this declared exact run claims matching
        # source text. A token's unmatched continuation may extend beyond the
        # run, but still occupies witness positions and cannot overlap a later
        # raw token or exceed the complete projected witness length.
        token_projection_end = row["projected_witness_index"] + len(token_projection)
        matched_length = min(len(token_projection), run[3] - row["projected_witness_index"])
        token_matched_text = "".join(item.text for item in token_projection[:matched_length])
        source_matched_text = projected_source_text[
            row["source_projected_index"]:row["source_projected_index"] + matched_length]
        if (counts[source] != 1
                or projection[row["source_projected_index"]].source_index != source
                or not token_projection
                or token_projection_end > seg["witness_projected_count"]
                or token_matched_text != source_matched_text
                or projected_source_text.find(matched_piece) != run[0]
                or projected_source_text.find(matched_piece, run[0] + 1) >= 0):
            raise ValueError("external witness normalized source/token contradiction")
        previous_positions[segment] = {"raw_token_index": row["raw_token_index"],
            "projected_witness_index": row["projected_witness_index"],
            "source_projected_index": row["source_projected_index"],
            "token_projection_end": token_projection_end}
        grouped[segment].append(_Anchor(source_index=source,
            current_start_ms=characters[source]["start_ms"], current_end_ms=characters[source]["end_ms"],
            wenet_start_ms=clock, wenet_end_ms=clock, anchor_clock="ctc_onset",
            witness_index=row["projected_witness_index"], exact_match_run=tuple(run),
            exact_match_unique=True, source_projection_unique=True))
        result[source] = clock
        used_tokens.add(identity)
        per_segment[segment] += 1
        previous_source, previous_clock = source, clock
    if any(per_segment[i] != seg["accepted_anchor_count"] for i, seg in enumerate(segments)):
        raise ValueError("external witness per-segment count mismatch")
    for group in grouped.values():
        accepted, _, _ = _augment_unique_native_runs(group, [])
        if [row.source_index for row in accepted] != [row.source_index for row in group]:
            raise ValueError("external witness no longer satisfies unique native group constraints")
    return result
