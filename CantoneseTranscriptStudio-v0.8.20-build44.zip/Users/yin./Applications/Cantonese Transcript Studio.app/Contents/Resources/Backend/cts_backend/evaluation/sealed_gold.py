"""Authoritative, transactional sealing for human natural-Cantonese gold.

The semantic manifest validator is necessary but not sufficient.  This module
rebuilds every deterministic stage from a private snapshot, verifies the exact
human-review renderers and source manifest, and makes a seal authoritative only
when a final atomic commit marker points at the complete validated snapshot.
"""

from __future__ import annotations

import ast
import hashlib
import json
import os
import plistlib
import re
import stat
import subprocess
import tempfile
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping, Sequence

from ..build_provenance import (
    BUILD_INPUT_MANIFEST_SCHEMA,
    require_build_input_manifest,
)
from .gold_collection import (
    FINALIZATION_RECEIPT_SCHEMA,
    RENDERER_POLICY_VERSION,
    SEALED_COMMIT_SCHEMA,
    atomic_json,
    build_adjudication_packet,
    build_blind_packet,
    build_gold_manifest,
    canonical_sha256,
    ensure_owner_only_directory,
    file_sha256,
    _project_corrected_collection,
    render_adjudication_html,
    render_timing_annotation_html,
    resolve_human_annotations,
    utc_now,
    validate_adjudication_packet_against_exports,
    validate_annotation_export,
    validate_blind_packet_against_ready,
    validate_collection_draft,
    validate_preparation_evidence,
    validate_ready_collection,
)
from .natural_gold import (
    GoldValidation,
    _evaluate_timestamp_metric_thresholds,
    compute_test_seal,
    validate_natural_cantonese_gold,
)
from .timestamp_evidence import (
    TIMESTAMP_EVALUATION_RESULT_SCHEMA,
    TIMESTAMP_PIPELINE_AUDIT_SCHEMA,
    timestamp_metrics_from_evidence,
)


FINALIZATION_RECEIPT_KEYS = {
    "schema",
    "execution_id",
    "source_manifest_sha256",
    "source_manifest_file_sha256",
    "manifest_sha256",
    "validation_sha256",
    "commit_inventory_sha256",
    "renderer_policy_version",
    "accepted",
    "status",
}
SEALED_MARKER_KEYS = {
    "schema",
    "execution_id",
    "commit_directory",
    "source_manifest_sha256",
    "source_manifest_file_sha256",
    "manifest_sha256",
    "validation_sha256",
    "finalization_receipt_sha256",
    "commit_inventory_sha256",
    "commit_inventory_file_sha256",
    "committed_at",
    "status",
}
COMMIT_INVENTORY_SCHEMA = "cts.natural-gold-commit-inventory/v1"
COMMIT_INVENTORY_KEYS = {"schema", "directories", "files", "sha256"}
COMMIT_INVENTORY_NAME = "commit-inventory.json"
FINALIZATION_RECEIPT_NAME = "natural-cantonese-timing-gold-finalization.json"
TIMESTAMP_EVALUATION_RECEIPT_SCHEMA = "cts.timestamp-evaluation-receipt/v3"
TIMESTAMP_EVALUATION_RECEIPT_KEYS = {
    "schema",
    "execution_id",
    "created_at",
    "candidate",
    "candidate_source_manifest",
    "source_bound_build_receipt",
    "timestamp_policy",
    "model_manifests",
    "model_tree_checkpoints",
    "gold",
    "evaluator",
    "execution",
    "candidate_input_artifact",
    "result_artifact",
    "pipeline_audit_artifact",
    "baseline",
    "blinded_review",
    "metrics",
}
TIMESTAMP_POLICY_SOURCE_PATH = "backend/cts_backend/alignment/forced_timestamps.py"
TIMESTAMP_POLICY_PACKAGED_PATH = (
    "Contents/Resources/Backend/cts_backend/alignment/forced_timestamps.py"
)
TIMESTAMP_EVALUATOR_PATH = "scripts/run_natural_gold_timestamp_evaluation.py"
BLINDED_REVIEW_RENDERER_PATH = "scripts/run_blinded_cue_review_ui.py"
REQUIRED_TIMESTAMP_MODEL_NAMES = {"qwen3-forced-aligner-0.6b"}
TIMESTAMP_MODEL_MANIFEST_SCHEMA = "cts.timestamp-model-tree-manifest/v1"
TIMESTAMP_MODEL_CHECKPOINT_SCHEMA = "cts.timestamp-model-checkpoints/v1"
BASELINE_BUILD = "39"
BUILD39_BASELINE_AUTHORITY_SCHEMA = "cts.timestamp-build39-baseline-authority/v1"
BUILD39_BASELINE_AUTHORITY_PATH = "resources/timestamp-build39-baseline-authority.json"
V4_BUILD_RECEIPT_KEYS = {
    "schema",
    "execution_id",
    "receipt_path",
    "build",
    "created_at",
    "source_manifest",
    "installed_before",
    "commands",
    "artifacts",
    "validation_complete",
    "validation_completed_at",
    "build_complete",
    "build_completed_at",
    "candidate",
    "candidate_codesign",
    "installed_after",
}
V4_BUILD_COMMAND_NAMES = (
    "backend_full",
    "swift_full",
    "synthetic_gold_primary",
    "synthetic_gold_heldout",
    "real_10min_structure",
    "real_10min_timing_attention",
    "candidate_build_only",
    "candidate_codesign_strict",
)
V4_BUILD_ARTIFACT_KEYS = {
    "backend_junit",
    "swift_run",
    "swift_discovery",
    "gold_primary",
    "gold_heldout",
    "real_10min",
    "timing_attention_real_10min",
    "build_log",
}
V4_BUILD_COMMAND_KEYS = {
    "name",
    "command",
    "started_at",
    "completed_at",
    "exit_status",
    "log",
    "source_manifest_after",
}
CORE_CHAIN_FILES = (
    "collection-draft.json",
    "draft-validation.json",
    "preparation-receipt.json",
    "transcript-freeze.json",
    "collection-ready.json",
    "primary-timing-packet.json",
    "primary-timing-annotation.html",
    "primary-timing-export.json",
    "secondary-timing-packet.json",
    "secondary-timing-annotation.html",
    "secondary-timing-export.json",
    "adjudication-packet.json",
    "timing-adjudication.html",
    "timing-adjudication-export.json",
)
_SAFE_EXECUTION_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
PROJECT_ROOT = Path(__file__).resolve().parents[3]


def _exact(value: object, keys: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != keys:
        raise ValueError(f"{label} schema is invalid")
    return value


def _json(path: Path, label: str) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{label} is not a regular file")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{label} JSON root is invalid")
    return value


def _json_bytes(value: object) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")


def _bytes_sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _atomic_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, raw = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(raw)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb", closefd=True) as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        if temporary.exists():
            aborted = temporary.with_name(temporary.name + ".aborted")
            os.replace(temporary, aborted)
        raise


def _stable_regular_bytes(path: Path) -> bytes:
    if path.is_symlink():
        raise ValueError("chain artifact must not be a symlink")
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("chain artifact is not a regular file")
        chunks: list[bytes] = []
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            chunks.append(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise RuntimeError("chain artifact changed while being snapshotted")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def _source_manifest_validator(
    source_manifest: Mapping[str, Any], project_root: Path
) -> Any:
    return require_build_input_manifest(dict(source_manifest), project_root)


def _assert_owner_only_tree(root: Path) -> None:
    for path in (root, *sorted(root.rglob("*"))):
        if path.is_symlink():
            raise ValueError("sealed commit contains a symlink")
        mode = stat.S_IMODE(path.stat().st_mode)
        if path.is_dir() and mode != 0o700:
            raise ValueError("sealed commit directory is not owner-only")
        if path.is_file() and mode != 0o600:
            raise ValueError("sealed commit file is not owner-only")
        if not path.is_dir() and not path.is_file():
            raise ValueError("sealed commit contains a non-regular entry")


def _validate_source_manifest_shape(
    source_manifest: Mapping[str, Any], *, allow_test_schema: bool = False
) -> None:
    if (
        set(source_manifest) != {"schema", "sha256", "files"}
        or (
            source_manifest.get("schema") != BUILD_INPUT_MANIFEST_SCHEMA
            and not allow_test_schema
        )
        or not isinstance(source_manifest.get("schema"), str)
        or not isinstance(source_manifest.get("sha256"), str)
        or not re.fullmatch(r"[0-9a-f]{64}", str(source_manifest.get("sha256")))
        or not isinstance(source_manifest.get("files"), list)
    ):
        raise ValueError("tool source manifest schema is invalid")

    seen: set[str] = set()
    for raw in source_manifest["files"]:
        if not isinstance(raw, Mapping):
            raise ValueError("tool source manifest file record is invalid")
        relative = raw.get("path")
        if not isinstance(relative, str):
            raise ValueError("tool source manifest path is invalid")
        pure = PurePosixPath(relative)
        if (
            not relative
            or pure.is_absolute()
            or ".." in pure.parts
            or pure.as_posix() != relative
            or relative in seen
        ):
            raise ValueError("tool source manifest path is unsafe or duplicate")
        seen.add(relative)
        state = raw.get("state")
        if state == "absent":
            if set(raw) != {"path", "state"}:
                raise ValueError("absent source record schema is invalid")
        elif state == "file":
            if (
                set(raw) != {"path", "state", "bytes", "sha256"}
                or type(raw.get("bytes")) is not int
                or int(raw["bytes"]) < 0
                or not isinstance(raw.get("sha256"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", str(raw["sha256"]))
            ):
                raise ValueError("source file record schema is invalid")
        else:
            raise ValueError("tool source manifest state is invalid")


def _snapshot_tool_source(
    project_root: Path,
    destination: Path,
    source_manifest: Mapping[str, Any],
) -> None:
    if destination.exists():
        raise FileExistsError("source snapshot destination already exists")
    ensure_owner_only_directory(destination)
    project_root = project_root.resolve(strict=True)
    for record in source_manifest["files"]:
        relative = str(record["path"])
        target_parent = destination
        for part in PurePosixPath(relative).parts[:-1]:
            target_parent = ensure_owner_only_directory(target_parent / part)
        target = target_parent / PurePosixPath(relative).name
        source = project_root.joinpath(*PurePosixPath(relative).parts)
        if record["state"] == "absent":
            if source.exists() or source.is_symlink():
                raise RuntimeError("source changed while snapshotting absent input")
            continue
        payload = _stable_regular_bytes(source)
        if (
            len(payload) != record["bytes"]
            or _bytes_sha256(payload) != record["sha256"]
        ):
            raise RuntimeError("source changed while creating immutable snapshot")
        _atomic_bytes(target, payload)


def _validate_archived_source_snapshot(
    snapshot_root: Path, source_manifest: Mapping[str, Any]
) -> None:
    if snapshot_root.is_symlink() or not snapshot_root.is_dir():
        raise ValueError("archived source snapshot is missing")
    _assert_owner_only_tree(snapshot_root)
    expected_files: set[str] = set()
    for record in source_manifest["files"]:
        relative = str(record["path"])
        path = snapshot_root.joinpath(*PurePosixPath(relative).parts)
        if record["state"] == "absent":
            if path.exists() or path.is_symlink():
                raise ValueError("archived absent source unexpectedly exists")
            continue
        expected_files.add(relative)
        payload = _stable_regular_bytes(path)
        if (
            len(payload) != record["bytes"]
            or _bytes_sha256(payload) != record["sha256"]
        ):
            raise ValueError("archived source snapshot hash mismatch")
    actual_files = {
        path.relative_to(snapshot_root).as_posix()
        for path in snapshot_root.rglob("*")
        if path.is_file()
    }
    if actual_files != expected_files:
        raise ValueError("archived source snapshot inventory mismatch")


def _receipt_logical_sha256(receipt: Mapping[str, Any]) -> str:
    logical = dict(receipt)
    logical.pop("commit_inventory_sha256", None)
    return canonical_sha256(logical)


def _relative_directories(root: Path) -> list[str]:
    return sorted(
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_dir()
    )


def _build_commit_inventory(
    commit_root: Path, receipt_without_inventory: Mapping[str, Any]
) -> dict[str, Any]:
    files: list[dict[str, Any]] = []
    for path in sorted(commit_root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(commit_root).as_posix()
        if relative in {COMMIT_INVENTORY_NAME, FINALIZATION_RECEIPT_NAME}:
            continue
        payload = _stable_regular_bytes(path)
        files.append(
            {
                "path": relative,
                "hash_mode": "raw",
                "bytes": len(payload),
                "sha256": _bytes_sha256(payload),
            }
        )
    files.append(
        {
            "path": FINALIZATION_RECEIPT_NAME,
            "hash_mode": "canonical_json_without_commit_inventory_sha256",
            "sha256": _receipt_logical_sha256(receipt_without_inventory),
        }
    )
    files.sort(key=lambda row: str(row["path"]))
    directories = _relative_directories(commit_root)
    payload = {"directories": directories, "files": files}
    return {
        "schema": COMMIT_INVENTORY_SCHEMA,
        **payload,
        "sha256": canonical_sha256(payload),
    }


def _validate_commit_inventory(
    commit_root: Path,
    inventory: Mapping[str, Any],
    receipt: Mapping[str, Any],
) -> None:
    _exact(inventory, COMMIT_INVENTORY_KEYS, "commit inventory")
    if inventory.get("schema") != COMMIT_INVENTORY_SCHEMA:
        raise ValueError("commit inventory schema is invalid")
    directories = inventory.get("directories")
    files = inventory.get("files")
    if (
        not isinstance(directories, list)
        or any(not isinstance(item, str) for item in directories)
        or directories != sorted(set(directories))
        or not isinstance(files, list)
    ):
        raise ValueError("commit inventory structure is invalid")
    payload = {"directories": directories, "files": files}
    if inventory.get("sha256") != canonical_sha256(payload):
        raise ValueError("commit inventory canonical hash mismatch")
    if receipt.get("commit_inventory_sha256") != inventory["sha256"]:
        raise ValueError("finalization receipt inventory binding mismatch")
    if directories != _relative_directories(commit_root):
        raise ValueError("commit directory inventory mismatch")

    actual = {
        path.relative_to(commit_root).as_posix(): path
        for path in commit_root.rglob("*")
        if path.is_file()
    }
    expected_paths = {COMMIT_INVENTORY_NAME}
    seen: set[str] = set()
    for raw in files:
        if not isinstance(raw, Mapping) or not isinstance(raw.get("path"), str):
            raise ValueError("commit inventory file record is invalid")
        relative = str(raw["path"])
        pure = PurePosixPath(relative)
        if (
            pure.is_absolute()
            or ".." in pure.parts
            or pure.as_posix() != relative
            or relative in seen
        ):
            raise ValueError("commit inventory file path is unsafe or duplicate")
        seen.add(relative)
        expected_paths.add(relative)
        if relative not in actual:
            raise ValueError("commit inventory required file is missing")
        if raw.get("hash_mode") == "raw":
            if set(raw) != {"path", "hash_mode", "bytes", "sha256"}:
                raise ValueError("raw commit inventory record is invalid")
            payload_bytes = _stable_regular_bytes(actual[relative])
            if (
                len(payload_bytes) != raw.get("bytes")
                or _bytes_sha256(payload_bytes) != raw.get("sha256")
            ):
                raise ValueError("commit inventory file hash mismatch")
        elif raw.get("hash_mode") == "canonical_json_without_commit_inventory_sha256":
            if (
                set(raw) != {"path", "hash_mode", "sha256"}
                or relative != FINALIZATION_RECEIPT_NAME
                or raw.get("sha256") != _receipt_logical_sha256(receipt)
            ):
                raise ValueError("logical finalization receipt hash mismatch")
        else:
            raise ValueError("commit inventory hash mode is invalid")
    if set(actual) != expected_paths:
        raise ValueError("sealed commit contains missing or unexpected files")


def _read_chain(
    media_root: Path,
    evidence_root: Path,
) -> dict[str, Any]:
    draft = _json(evidence_root / "collection-draft.json", "collection draft")
    draft_validation = validate_collection_draft(draft, root=media_root)
    if draft_validation.get("accepted") is not True:
        raise ValueError("collection draft is not accepted")
    preparation = validate_preparation_evidence(
        media_root, draft, evidence_root=evidence_root
    )
    correction_path = evidence_root / "transcript-freeze.json"
    correction = _json(correction_path, "transcript freeze")
    ready = _json(evidence_root / "collection-ready.json", "ready collection")
    validate_ready_collection(ready)
    rebuilt_ready = _project_corrected_collection(
        draft,
        correction,
        root=media_root,
        primary_annotator=str(
            ready["role_identities"]["primary_timing_annotator"]
        ),
        secondary_annotator=str(
            ready["role_identities"]["secondary_timing_annotator"]
        ),
        adjudicator=str(ready["role_identities"]["adjudicator"]),
        materialize=False,
    )
    if rebuilt_ready != ready:
        raise ValueError("ready collection is not the deterministic draft projection")
    _validate_projected_derivatives(media_root, evidence_root, rebuilt_ready)

    primary_packet = _json(
        evidence_root / "primary-timing-packet.json", "primary timing packet"
    )
    secondary_packet = _json(
        evidence_root / "secondary-timing-packet.json", "secondary timing packet"
    )
    for packet, secondary in (
        (primary_packet, False),
        (secondary_packet, True),
    ):
        validate_blind_packet_against_ready(ready, packet)
        rebuilt_packet = build_blind_packet(
            ready,
            annotator_pseudonym=str(packet["annotator_pseudonym"]),
            secondary=secondary,
        )
        if rebuilt_packet != packet:
            raise ValueError("stored timing packet is not the deterministic projection")

    primary_ui_path = evidence_root / "primary-timing-annotation.html"
    secondary_ui_path = evidence_root / "secondary-timing-annotation.html"
    if primary_ui_path.read_text(encoding="utf-8") != render_timing_annotation_html(
        primary_packet
    ):
        raise ValueError("primary annotation UI is not the deterministic renderer output")
    if secondary_ui_path.read_text(
        encoding="utf-8"
    ) != render_timing_annotation_html(secondary_packet):
        raise ValueError("secondary annotation UI is not the deterministic renderer output")

    primary_export_path = evidence_root / "primary-timing-export.json"
    secondary_export_path = evidence_root / "secondary-timing-export.json"
    primary_export = _json(primary_export_path, "primary timing export")
    secondary_export = _json(secondary_export_path, "secondary timing export")
    validate_annotation_export(primary_packet, primary_export)
    validate_annotation_export(secondary_packet, secondary_export)

    adjudication_packet = _json(
        evidence_root / "adjudication-packet.json", "adjudication packet"
    )
    rebuilt_adjudication_packet = build_adjudication_packet(
        ready,
        primary_packet,
        primary_export,
        secondary_packet,
        secondary_export,
    )
    validate_adjudication_packet_against_exports(
        ready,
        primary_packet,
        primary_export,
        secondary_packet,
        secondary_export,
        adjudication_packet,
    )
    if rebuilt_adjudication_packet != adjudication_packet:
        raise ValueError("adjudication packet is not the deterministic projection")
    adjudication_ui_path = evidence_root / "timing-adjudication.html"
    if adjudication_ui_path.read_text(
        encoding="utf-8"
    ) != render_adjudication_html(
        adjudication_packet,
        adjudicator_pseudonym=str(adjudication_packet["adjudicator_pseudonym"]),
    ):
        raise ValueError("adjudication UI is not the deterministic renderer output")
    adjudication_export_path = evidence_root / "timing-adjudication-export.json"
    adjudication_export = _json(
        adjudication_export_path, "adjudication export"
    )
    resolved = resolve_human_annotations(
        ready,
        primary_packet,
        primary_export,
        secondary_packet,
        secondary_export,
        adjudication_packet,
        adjudication_export,
    )
    return {
        "draft": draft,
        "correction": correction,
        "ready": ready,
        "primary_packet": primary_packet,
        "secondary_packet": secondary_packet,
        "primary_export": primary_export,
        "secondary_export": secondary_export,
        "adjudication_packet": adjudication_packet,
        "adjudication_export": adjudication_export,
        "resolved": resolved,
        "preparation": preparation,
        "transcript_freeze_file_sha256": file_sha256(correction_path),
        "primary_export_file_sha256": file_sha256(primary_export_path),
        "secondary_export_file_sha256": file_sha256(secondary_export_path),
        "adjudication_export_file_sha256": file_sha256(adjudication_export_path),
        "primary_annotation_ui_sha256": file_sha256(primary_ui_path),
        "secondary_annotation_ui_sha256": file_sha256(secondary_ui_path),
        "adjudication_ui_sha256": file_sha256(adjudication_ui_path),
    }


def _validate_projected_derivatives(
    media_root: Path,
    evidence_root: Path,
    ready: Mapping[str, Any],
) -> None:
    """Exact-compare materialised derivatives without repairing either tree."""

    roots = (media_root,) if media_root == evidence_root else (media_root, evidence_root)
    for clip in ready.get("clips", []):
        if not isinstance(clip, Mapping):
            raise ValueError("ready derivative clip is invalid")
        for path_key, sha_key in (
            ("transcript_path", "transcript_sha256"),
            ("baseline_segments_path", "baseline_segments_sha256"),
        ):
            relative = clip.get(path_key)
            expected = clip.get(sha_key)
            if not isinstance(relative, str) or not isinstance(expected, str):
                raise ValueError("ready derivative identity is invalid")
            pure = PurePosixPath(relative)
            if pure.is_absolute() or ".." in pure.parts or pure.as_posix() != relative:
                raise ValueError("ready derivative path is unsafe")
            for root in roots:
                candidate = root / relative
                candidate.resolve(strict=True).relative_to(root.resolve(strict=True))
                if _bytes_sha256(_stable_regular_bytes(candidate)) != expected:
                    raise ValueError("ready derivative bytes do not match projection")


def _build_collection_lineage_from_root(
    root: Path,
    source_manifest: Mapping[str, Any],
    *,
    execution_id: str,
    project_root: Path,
    source_manifest_validator: Callable[[Mapping[str, Any], Path], Any]
    | None = None,
    allow_test_source_manifest: bool = False,
) -> dict[str, Any]:
    if not _SAFE_EXECUTION_ID.fullmatch(execution_id):
        raise ValueError("finalization execution identity is invalid")
    _validate_source_manifest_shape(
        source_manifest, allow_test_schema=allow_test_source_manifest
    )
    validator = source_manifest_validator or _source_manifest_validator
    validator(source_manifest, project_root)
    chain = _read_chain(root.resolve(strict=True), root.resolve(strict=True))
    ready = chain["ready"]
    return {
        "draft_sha256": str(chain["draft"]["draft_sha256"]),
        "transcript_freeze_sha256": str(ready["transcript_freeze_sha256"]),
        "transcript_freeze_file_sha256": chain[
            "transcript_freeze_file_sha256"
        ],
        "ready_sha256": str(ready["ready_sha256"]),
        "primary_packet_sha256": str(chain["primary_packet"]["packet_sha256"]),
        "primary_export_file_sha256": chain["primary_export_file_sha256"],
        "secondary_packet_sha256": str(
            chain["secondary_packet"]["packet_sha256"]
        ),
        "secondary_export_file_sha256": chain["secondary_export_file_sha256"],
        "adjudication_packet_sha256": str(
            chain["adjudication_packet"]["packet_sha256"]
        ),
        "adjudication_export_file_sha256": chain[
            "adjudication_export_file_sha256"
        ],
        "tool_source_manifest_sha256": str(source_manifest["sha256"]),
        "tool_source_manifest_file_sha256": _bytes_sha256(
            _json_bytes(source_manifest)
        ),
        "transcript_review_ui_sha256": chain["preparation"][
            "review_ui_sha256"
        ],
        "primary_annotation_ui_sha256": chain[
            "primary_annotation_ui_sha256"
        ],
        "secondary_annotation_ui_sha256": chain[
            "secondary_annotation_ui_sha256"
        ],
        "adjudication_ui_sha256": chain["adjudication_ui_sha256"],
        "renderer_policy_version": RENDERER_POLICY_VERSION,
        "finalization_execution_id": execution_id,
    }


def build_collection_lineage_from_root(
    root: Path,
    source_manifest: Mapping[str, Any],
    *,
    execution_id: str,
) -> dict[str, Any]:
    """Build lineage using only the real project source validator."""

    return _build_collection_lineage_from_root(
        root,
        source_manifest,
        execution_id=execution_id,
        project_root=PROJECT_ROOT,
    )


def _receipt_without_inventory(
    *,
    execution_id: str,
    source_manifest: Mapping[str, Any],
    manifest_path: Path,
    validation_path: Path,
) -> dict[str, Any]:
    return {
        "schema": FINALIZATION_RECEIPT_SCHEMA,
        "execution_id": execution_id,
        "source_manifest_sha256": source_manifest["sha256"],
        "source_manifest_file_sha256": _bytes_sha256(
            _json_bytes(source_manifest)
        ),
        "manifest_sha256": file_sha256(manifest_path),
        "validation_sha256": file_sha256(validation_path),
        "renderer_policy_version": RENDERER_POLICY_VERSION,
        "accepted": True,
        "status": "SEALED_HUMAN_GOLD",
    }


def _expected_receipt(
    *,
    execution_id: str,
    source_manifest: Mapping[str, Any],
    manifest_path: Path,
    validation_path: Path,
    commit_inventory_sha256: str,
) -> dict[str, Any]:
    receipt = _receipt_without_inventory(
        execution_id=execution_id,
        source_manifest=source_manifest,
        manifest_path=manifest_path,
        validation_path=validation_path,
    )
    receipt["commit_inventory_sha256"] = commit_inventory_sha256
    return receipt


def _validate_sealed_gold_chain(
    root: Path,
    manifest: Mapping[str, Any],
    finalization_receipt: Mapping[str, Any],
    *,
    commit_root: Path,
    project_root: Path,
    duration_probe: Any | None = None,
    source_manifest_validator: Callable[[Mapping[str, Any], Path], Any]
    | None = None,
    require_current_source: bool = False,
    allow_test_source_manifest: bool = False,
) -> dict[str, Any]:
    """Recompute the complete authoritative chain and exact-compare every stage."""

    media_root = root.resolve(strict=True)
    commit_root = commit_root.resolve(strict=True)
    commit_root.relative_to((media_root / "sealed-gold-commits").resolve(strict=True))
    _assert_owner_only_tree(commit_root)
    chain_root = (commit_root / "chain").resolve(strict=True)
    chain_root.relative_to(commit_root)
    source_manifest_path = commit_root / "tool-source-manifest.json"
    manifest_path = commit_root / "natural-cantonese-timing-gold.json"
    validation_path = commit_root / "natural-cantonese-timing-gold-validation.json"
    receipt_path = commit_root / FINALIZATION_RECEIPT_NAME
    inventory_path = commit_root / COMMIT_INVENTORY_NAME
    source_snapshot_root = commit_root / "source-snapshot"
    stored_source_manifest = _json(source_manifest_path, "tool source manifest")
    stored_manifest = _json(manifest_path, "sealed gold manifest")
    stored_validation = _json(validation_path, "sealed gold validation")
    stored_receipt = _json(receipt_path, "finalization receipt")
    stored_inventory = _json(inventory_path, "commit inventory")
    if stored_manifest != dict(manifest) or stored_receipt != dict(finalization_receipt):
        raise ValueError("supplied seal objects do not match committed bytes")
    _validate_source_manifest_shape(
        stored_source_manifest, allow_test_schema=allow_test_source_manifest
    )
    _validate_archived_source_snapshot(source_snapshot_root, stored_source_manifest)
    if require_current_source:
        validator = source_manifest_validator or _source_manifest_validator
        validator(stored_source_manifest, project_root)
    _validate_commit_inventory(commit_root, stored_inventory, stored_receipt)

    chain = _read_chain(media_root, chain_root)
    execution_id = finalization_receipt.get("execution_id")
    if not isinstance(execution_id, str) or not _SAFE_EXECUTION_ID.fullmatch(
        execution_id
    ):
        raise ValueError("finalization execution identity is invalid")
    ready = chain["ready"]
    snapshot_lineage = {
        "draft_sha256": str(chain["draft"]["draft_sha256"]),
        "transcript_freeze_sha256": str(ready["transcript_freeze_sha256"]),
        "transcript_freeze_file_sha256": chain[
            "transcript_freeze_file_sha256"
        ],
        "ready_sha256": str(ready["ready_sha256"]),
        "primary_packet_sha256": str(chain["primary_packet"]["packet_sha256"]),
        "primary_export_file_sha256": chain["primary_export_file_sha256"],
        "secondary_packet_sha256": str(
            chain["secondary_packet"]["packet_sha256"]
        ),
        "secondary_export_file_sha256": chain["secondary_export_file_sha256"],
        "adjudication_packet_sha256": str(
            chain["adjudication_packet"]["packet_sha256"]
        ),
        "adjudication_export_file_sha256": chain[
            "adjudication_export_file_sha256"
        ],
        "tool_source_manifest_sha256": str(stored_source_manifest["sha256"]),
        "tool_source_manifest_file_sha256": file_sha256(source_manifest_path),
        "transcript_review_ui_sha256": chain["preparation"][
            "review_ui_sha256"
        ],
        "primary_annotation_ui_sha256": chain[
            "primary_annotation_ui_sha256"
        ],
        "secondary_annotation_ui_sha256": chain[
            "secondary_annotation_ui_sha256"
        ],
        "adjudication_ui_sha256": chain["adjudication_ui_sha256"],
        "renderer_policy_version": RENDERER_POLICY_VERSION,
        "finalization_execution_id": execution_id,
    }
    expected_manifest = build_gold_manifest(
        chain["ready"],
        chain["resolved"],
        annotator_pseudonyms=[
            str(chain["primary_packet"]["annotator_pseudonym"]),
            str(chain["secondary_packet"]["annotator_pseudonym"]),
        ],
        adjudicator_pseudonym=str(
            chain["adjudication_export"]["adjudicator_pseudonym"]
        ),
        sealed_at=str(manifest.get("split_contract", {}).get("sealed_at")),
        collection_lineage=snapshot_lineage,
    )
    if expected_manifest != stored_manifest:
        raise ValueError("sealed manifest is not the deterministic chain projection")
    semantic = (
        validate_natural_cantonese_gold(stored_manifest, root=media_root)
        if duration_probe is None
        else validate_natural_cantonese_gold(
            stored_manifest, root=media_root, duration_probe=duration_probe
        )
    )
    if not semantic.accepted or stored_validation != semantic.to_dict():
        raise ValueError("sealed semantic validation is rejected or stale")
    expected_receipt = _expected_receipt(
        execution_id=execution_id,
        source_manifest=stored_source_manifest,
        manifest_path=manifest_path,
        validation_path=validation_path,
        commit_inventory_sha256=str(stored_inventory["sha256"]),
    )
    _exact(finalization_receipt, FINALIZATION_RECEIPT_KEYS, "finalization receipt")
    if expected_receipt != stored_receipt:
        raise ValueError("finalization receipt is not bound to this execution")
    return {
        "accepted": True,
        "status": "AUTHORITATIVE_SEALED_HUMAN_GOLD",
        "execution_id": execution_id,
        "manifest_sha256": file_sha256(manifest_path),
        "validation_sha256": file_sha256(validation_path),
        "source_manifest_sha256": stored_source_manifest["sha256"],
        "source_manifest_file_sha256": file_sha256(source_manifest_path),
        "renderer_policy_version": RENDERER_POLICY_VERSION,
        "commit_inventory_sha256": stored_inventory["sha256"],
        "commit_inventory_file_sha256": file_sha256(inventory_path),
        "semantic_stats": semantic.stats,
    }


def _snapshot_names(root: Path) -> tuple[str, ...]:
    receipt = _json(root / "preparation-receipt.json", "preparation receipt")
    review = receipt.get("review_html")
    if not isinstance(review, Mapping) or not isinstance(review.get("path"), str):
        raise ValueError("preparation review path is missing")
    review_name = str(review["path"])
    if Path(review_name).name != review_name:
        raise ValueError("preparation review path is not a local filename")
    names = set(CORE_CHAIN_FILES) | {review_name}
    if "draft_validation" not in receipt:
        names.update(
            {
                "draft-validation-receipt.json",
                "review-ui-v3-receipt.json",
                "transcript-and-speaker-review-v3.html",
            }
        )
    ready = _json(root / "collection-ready.json", "ready collection")
    for clip in ready.get("clips", []):
        if not isinstance(clip, Mapping):
            raise ValueError("ready clip is invalid while snapshotting")
        for key in ("transcript_path", "baseline_segments_path"):
            relative = clip.get(key)
            if not isinstance(relative, str):
                raise ValueError("ready derivative path is missing")
            pure = PurePosixPath(relative)
            if pure.is_absolute() or ".." in pure.parts or pure.as_posix() != relative:
                raise ValueError("ready derivative path is unsafe")
            names.add(relative)
    return tuple(sorted(names))


def _snapshot_chain(root: Path, destination: Path) -> None:
    ensure_owner_only_directory(destination)
    for name in _snapshot_names(root):
        source = root / name
        try:
            source.resolve(strict=True).relative_to(root.resolve(strict=True))
        except ValueError:
            raise ValueError("chain snapshot source escapes the private root")
        target = destination / name
        ensure_owner_only_directory(target.parent)
        _atomic_bytes(target, _stable_regular_bytes(source))


def _publish_authoritative_gold(
    root: Path,
    manifest: Mapping[str, Any],
    source_manifest: Mapping[str, Any],
    *,
    project_root: Path,
    duration_probe: Any | None = None,
    source_manifest_validator: Callable[[Mapping[str, Any], Path], Any]
    | None = None,
    fault_at: str | None = None,
    allow_test_source_manifest: bool = False,
) -> tuple[Path, dict[str, Any]]:
    """Stage, validate, commit, then atomically publish one authoritative marker."""

    root = root.resolve(strict=True)
    execution_id = manifest.get("collection_lineage", {}).get(
        "finalization_execution_id"
    )
    if not isinstance(execution_id, str) or not _SAFE_EXECUTION_ID.fullmatch(
        execution_id
    ):
        raise ValueError("manifest finalization execution identity is invalid")
    _validate_source_manifest_shape(
        source_manifest, allow_test_schema=allow_test_source_manifest
    )
    commits = ensure_owner_only_directory(root / "sealed-gold-commits")
    staging_path = commits / f".{execution_id}.staging"
    if staging_path.exists() or staging_path.is_symlink():
        raise FileExistsError("finalization staging directory already exists")
    staging = ensure_owner_only_directory(staging_path)
    final = commits / execution_id
    if final.exists():
        raise FileExistsError("finalization execution already exists")
    committed = False
    try:
        chain_root = ensure_owner_only_directory(staging / "chain")
        _snapshot_chain(root, chain_root)
        atomic_json(staging / "tool-source-manifest.json", source_manifest)
        _snapshot_tool_source(
            project_root,
            staging / "source-snapshot",
            source_manifest,
        )
        atomic_json(staging / "natural-cantonese-timing-gold.json", manifest)
        semantic = (
            validate_natural_cantonese_gold(manifest, root=root)
            if duration_probe is None
            else validate_natural_cantonese_gold(
                manifest, root=root, duration_probe=duration_probe
            )
        )
        if not semantic.accepted:
            raise RuntimeError("sealed human gold failed the semantic contract")
        atomic_json(
            staging / "natural-cantonese-timing-gold-validation.json",
            semantic.to_dict(),
        )
        if fault_at == "after_snapshot":
            raise RuntimeError("injected seal fault after snapshot")
        receipt_without_inventory = _receipt_without_inventory(
            execution_id=execution_id,
            source_manifest=source_manifest,
            manifest_path=staging / "natural-cantonese-timing-gold.json",
            validation_path=staging
            / "natural-cantonese-timing-gold-validation.json",
        )
        inventory = _build_commit_inventory(staging, receipt_without_inventory)
        receipt = {
            **receipt_without_inventory,
            "commit_inventory_sha256": inventory["sha256"],
        }
        atomic_json(
            staging / FINALIZATION_RECEIPT_NAME, receipt
        )
        atomic_json(staging / COMMIT_INVENTORY_NAME, inventory)
        chain_validation = _validate_sealed_gold_chain(
            root,
            manifest,
            receipt,
            commit_root=staging,
            project_root=project_root,
            duration_probe=duration_probe,
            source_manifest_validator=source_manifest_validator,
            require_current_source=True,
            allow_test_source_manifest=allow_test_source_manifest,
        )
        if fault_at == "after_validation":
            raise RuntimeError("injected seal fault after validation")
        os.replace(staging, final)
        committed = True
        if fault_at in {"after_commit_directory", "before_marker"}:
            raise RuntimeError("injected seal fault before authoritative marker")
        marker = {
            "schema": SEALED_COMMIT_SCHEMA,
            "execution_id": execution_id,
            "commit_directory": f"sealed-gold-commits/{execution_id}",
            "source_manifest_sha256": source_manifest["sha256"],
            "source_manifest_file_sha256": file_sha256(
                final / "tool-source-manifest.json"
            ),
            "manifest_sha256": file_sha256(
                final / "natural-cantonese-timing-gold.json"
            ),
            "validation_sha256": file_sha256(
                final / "natural-cantonese-timing-gold-validation.json"
            ),
            "finalization_receipt_sha256": file_sha256(
                final / FINALIZATION_RECEIPT_NAME
            ),
            "commit_inventory_sha256": inventory["sha256"],
            "commit_inventory_file_sha256": file_sha256(
                final / COMMIT_INVENTORY_NAME
            ),
            "committed_at": utc_now(),
            "status": "AUTHORITATIVE_SEALED_HUMAN_GOLD",
        }
        marker_path = root / "SEALED.json"
        atomic_json(marker_path, marker)
        return marker_path, {**chain_validation, "marker": marker}
    except BaseException:
        if not committed and staging.exists():
            aborted_root = ensure_owner_only_directory(commits / "aborted-seals")
            aborted = aborted_root / f"{execution_id}-{utc_now().replace(':', '')}"
            os.replace(staging, aborted)
        raise


def publish_authoritative_gold(
    root: Path,
    manifest: Mapping[str, Any],
    source_manifest: Mapping[str, Any],
) -> tuple[Path, dict[str, Any]]:
    """Publish through the strict real-media, real-project authority path."""

    return _publish_authoritative_gold(
        root,
        manifest,
        source_manifest,
        project_root=PROJECT_ROOT,
    )


def _load_authoritative_sealed_gold(
    root: Path,
    *,
    project_root: Path | None = None,
    duration_probe: Any | None = None,
    allow_test_source_manifest: bool = False,
) -> tuple[dict[str, Any], dict[str, Any]]:
    root = root.resolve(strict=True)
    marker = _json(root / "SEALED.json", "authoritative seal marker")
    _exact(marker, SEALED_MARKER_KEYS, "authoritative seal marker")
    execution_id = marker.get("execution_id")
    expected_directory = f"sealed-gold-commits/{execution_id}"
    if (
        marker.get("schema") != SEALED_COMMIT_SCHEMA
        or not isinstance(execution_id, str)
        or not _SAFE_EXECUTION_ID.fullmatch(execution_id)
        or marker.get("commit_directory") != expected_directory
        or marker.get("status") != "AUTHORITATIVE_SEALED_HUMAN_GOLD"
    ):
        raise ValueError("authoritative seal marker identity is invalid")
    commit_root = (root / expected_directory).resolve(strict=True)
    commit_root.relative_to((root / "sealed-gold-commits").resolve(strict=True))
    source_path = commit_root / "tool-source-manifest.json"
    manifest_path = commit_root / "natural-cantonese-timing-gold.json"
    validation_path = commit_root / "natural-cantonese-timing-gold-validation.json"
    receipt_path = commit_root / FINALIZATION_RECEIPT_NAME
    inventory_path = commit_root / COMMIT_INVENTORY_NAME
    for key, path in (
        ("source_manifest_file_sha256", source_path),
        ("manifest_sha256", manifest_path),
        ("validation_sha256", validation_path),
        ("finalization_receipt_sha256", receipt_path),
        ("commit_inventory_file_sha256", inventory_path),
    ):
        if marker.get(key) != file_sha256(path):
            raise ValueError(f"authoritative marker hash mismatch: {key}")
    source_manifest = _json(source_path, "tool source manifest")
    if marker.get("source_manifest_sha256") != source_manifest.get("sha256"):
        raise ValueError("authoritative source manifest identity mismatch")
    manifest = _json(manifest_path, "sealed gold manifest")
    receipt = _json(receipt_path, "finalization receipt")
    inventory = _json(inventory_path, "commit inventory")
    if marker.get("commit_inventory_sha256") != inventory.get("sha256"):
        raise ValueError("authoritative commit inventory identity mismatch")
    validation = _validate_sealed_gold_chain(
        root,
        manifest,
        receipt,
        commit_root=commit_root,
        project_root=project_root or root,
        duration_probe=duration_probe,
        require_current_source=False,
        allow_test_source_manifest=allow_test_source_manifest,
    )
    return manifest, {**validation, "marker": marker}


def load_authoritative_sealed_gold(
    root: Path,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Read and reconstruct authoritative gold without injectable overrides."""

    return _load_authoritative_sealed_gold(root, project_root=PROJECT_ROOT)


def _candidate_bundle_identity(bundle: Path) -> dict[str, Any]:
    if bundle.is_symlink():
        raise ValueError("candidate bundle must not be a symlink")
    bundle = bundle.resolve(strict=True)
    if not bundle.is_dir():
        raise ValueError("candidate bundle is invalid")
    info_path = bundle / "Contents" / "Info.plist"
    binary_path = bundle / "Contents" / "MacOS" / "CantoneseTranscriptStudio"
    info = plistlib.loads(_stable_regular_bytes(info_path))
    if not isinstance(info, Mapping):
        raise ValueError("candidate Info.plist is invalid")
    files: list[Path] = []
    for path in sorted(bundle.rglob("*")):
        if path.is_symlink():
            raise ValueError("candidate bundle contains a symlink")
        if path.is_file():
            files.append(path)
        elif not path.is_dir():
            raise ValueError("candidate bundle contains an unsupported entry")
    inventory = hashlib.sha256()
    for path in files:
        inventory.update(path.relative_to(bundle).as_posix().encode("utf-8"))
        inventory.update(b"\0")
        inventory.update(_bytes_sha256(_stable_regular_bytes(path)).encode("ascii"))
        inventory.update(b"\n")
    return {
        "version": str(info.get("CFBundleShortVersionString")),
        "build": str(info.get("CFBundleVersion")),
        "file_count": len(files),
        "canonical_inventory_sha256": inventory.hexdigest(),
        "info_plist_sha256": _bytes_sha256(_stable_regular_bytes(info_path)),
        "binary_sha256": _bytes_sha256(_stable_regular_bytes(binary_path)),
    }


def _candidate_identity_sha256(candidate: Mapping[str, Any]) -> str:
    return canonical_sha256(dict(candidate))


def _relative_artifact(
    record: object, *, base: Path, label: str
) -> tuple[Path, bytes]:
    record = _exact(record, {"path", "bytes", "sha256"}, label)
    relative = record.get("path")
    if not isinstance(relative, str):
        raise ValueError(f"{label} path is invalid")
    pure = PurePosixPath(relative)
    if pure.is_absolute() or ".." in pure.parts or pure.as_posix() != relative:
        raise ValueError(f"{label} path is unsafe")
    root = base.resolve(strict=True)
    path = (root / relative).resolve(strict=True)
    path.relative_to(root)
    payload = _stable_regular_bytes(path)
    if (
        isinstance(record.get("bytes"), bool)
        or record.get("bytes") != len(payload)
        or record.get("sha256") != _bytes_sha256(payload)
    ):
        raise ValueError(f"{label} identity mismatch")
    return path, payload


def _relative_json_artifact(
    record: object, *, base: Path, label: str
) -> tuple[Path, bytes, Mapping[str, Any]]:
    path, payload = _relative_artifact(record, base=base, label=label)
    value = json.loads(payload)
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} JSON root is invalid")
    return path, payload, value


def _source_record(
    source_manifest: Mapping[str, Any], relative: str
) -> Mapping[str, Any]:
    records = {
        str(row.get("path")): row
        for row in source_manifest.get("files", [])
        if isinstance(row, Mapping)
    }
    record = records.get(relative)
    if not isinstance(record, Mapping) or record.get("state") != "file":
        raise ValueError("evaluation source file is absent from candidate source manifest")
    return record


def _validate_bound_source_file(
    record: Mapping[str, Any],
    *,
    project_root: Path,
    source_manifest: Mapping[str, Any],
) -> None:
    if set(record) != {"path", "sha256"}:
        raise ValueError("evaluation source binding schema is invalid")
    relative = record.get("path")
    if not isinstance(relative, str):
        raise ValueError("evaluation source binding path is invalid")
    path = project_root / relative
    path.resolve(strict=True).relative_to(project_root.resolve(strict=True))
    payload = _stable_regular_bytes(path)
    manifest_record = _source_record(source_manifest, relative)
    if (
        record.get("sha256") != _bytes_sha256(payload)
        or manifest_record.get("sha256") != record.get("sha256")
        or manifest_record.get("bytes") != len(payload)
    ):
        raise ValueError("evaluation source binding hash is invalid")


def _literal_string_constant(source: bytes, name: str) -> str:
    tree = ast.parse(source.decode("utf-8"))
    values: list[str] = []
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if any(isinstance(target, ast.Name) and target.id == name for target in targets):
            value = node.value
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                values.append(value.value)
    if len(values) != 1 or not values[0]:
        raise ValueError(f"timestamp policy constant is not a unique literal: {name}")
    return values[0]


def _timestamp_policy_identity(
    *,
    candidate_bundle: Path,
    project_root: Path,
    source_manifest: Mapping[str, Any],
) -> dict[str, Any]:
    source_path = project_root / TIMESTAMP_POLICY_SOURCE_PATH
    packaged_path = candidate_bundle / TIMESTAMP_POLICY_PACKAGED_PATH
    source = _stable_regular_bytes(source_path)
    packaged = _stable_regular_bytes(packaged_path)
    source_record = _source_record(source_manifest, TIMESTAMP_POLICY_SOURCE_PATH)
    if (
        source_record.get("sha256") != _bytes_sha256(source)
        or source_record.get("bytes") != len(source)
        or source != packaged
    ):
        raise ValueError("packaged timestamp policy is not byte-identical to source")
    source_version = _literal_string_constant(source, "FORCED_TIMESTAMP_POLICY_VERSION")
    packaged_version = _literal_string_constant(
        packaged, "FORCED_TIMESTAMP_POLICY_VERSION"
    )
    if source_version != packaged_version:
        raise ValueError("packaged timestamp policy version differs from source")
    return {
        "version": source_version,
        "source_path": TIMESTAMP_POLICY_SOURCE_PATH,
        "packaged_path": TIMESTAMP_POLICY_PACKAGED_PATH,
        "source_sha256": _bytes_sha256(source),
        "packaged_sha256": _bytes_sha256(packaged),
    }


def _directory_manifest(root: Path) -> dict[str, Any]:
    if root.is_symlink():
        raise ValueError("timestamp model root must not be a symlink")
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError("timestamp model root is not a directory")
    rows: list[dict[str, Any]] = []
    total = 0
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError("timestamp model tree contains a symlink")
        if path.is_dir():
            continue
        payload = _stable_regular_bytes(path)
        total += len(payload)
        rows.append(
            {
                "path": path.relative_to(root).as_posix(),
                "bytes": len(payload),
                "sha256": _bytes_sha256(payload),
            }
        )
    if not rows:
        raise ValueError("timestamp model tree is empty")
    return {
        "schema": TIMESTAMP_MODEL_MANIFEST_SCHEMA,
        "root": str(root),
        "file_count": len(rows),
        "total_bytes": total,
        "canonical_inventory_sha256": canonical_sha256(rows),
    }


def _codesign_identity(candidate_bundle: Path) -> dict[str, Any]:
    completed = subprocess.run(
        ("/usr/bin/codesign", "-dvvv", str(candidate_bundle)),
        stdin=subprocess.DEVNULL,
        capture_output=True,
        check=False,
    )
    details = completed.stdout + completed.stderr
    verified = subprocess.run(
        ("/usr/bin/codesign", "--verify", "--deep", "--strict", str(candidate_bundle)),
        stdin=subprocess.DEVNULL,
        capture_output=True,
        check=False,
    )
    if completed.returncode != 0 or verified.returncode != 0:
        raise ValueError("candidate codesign verification failed")
    text = details.decode("utf-8", errors="strict")
    values: dict[str, str] = {}
    for line in text.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    identity = {
        "identifier": values.get("Identifier", ""),
        "format": values.get("Format", ""),
        "signature": values.get("Signature", ""),
        "team_identifier": values.get("TeamIdentifier", ""),
        "cdhash": values.get("CDHash", ""),
    }
    return {**identity, "details_sha256": canonical_sha256(identity)}


def _project_artifact(
    record: object, *, project_root: Path, label: str
) -> tuple[Path, bytes]:
    return _relative_artifact(record, base=project_root, label=label)


def _validate_installed_snapshot(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} is invalid")
    exists = value.get("exists")
    if exists is False:
        return _exact(value, {"path", "exists"}, label)
    snapshot = _exact(
        value,
        {
            "path",
            "exists",
            "version",
            "build",
            "info_plist_sha256",
            "binary_sha256",
            "entry_count",
            "canonical_inventory_sha256",
            "exact_running_pids",
        },
        label,
    )
    if snapshot.get("exists") is not True:
        raise ValueError(f"{label} existence flag is invalid")
    if any(
        not isinstance(snapshot.get(key), str) or not snapshot.get(key)
        for key in (
            "path",
            "version",
            "build",
            "info_plist_sha256",
            "binary_sha256",
            "canonical_inventory_sha256",
        )
    ):
        raise ValueError(f"{label} identity is invalid")
    if (
        isinstance(snapshot.get("entry_count"), bool)
        or not isinstance(snapshot.get("entry_count"), int)
        or snapshot["entry_count"] <= 0
        or not isinstance(snapshot.get("exact_running_pids"), list)
        or any(
            isinstance(pid, bool) or not isinstance(pid, int) or pid <= 0
            for pid in snapshot["exact_running_pids"]
        )
    ):
        raise ValueError(f"{label} process or inventory identity is invalid")
    return snapshot


def _command_targets_script(
    command: Sequence[str], relative: str, *, project_root: Path
) -> bool:
    if not command:
        return False
    expected = Path(relative).as_posix()
    for part in command:
        if part == expected:
            return True
        try:
            if Path(part).expanduser().resolve() == (project_root / relative).resolve():
                return True
        except (OSError, RuntimeError):
            continue
    return False


def _flag_value(command: Sequence[str], flag: str) -> str | None:
    if command.count(flag) != 1:
        return None
    index = command.index(flag)
    if index + 1 >= len(command):
        return None
    return command[index + 1]


def _validate_v4_command(
    name: str,
    command: Sequence[str],
    *,
    candidate_bundle: Path,
    project_root: Path,
) -> None:
    script_requirements = {
        "swift_full": "scripts/run_swift_tests.sh",
        "synthetic_gold_primary": "scripts/run_timestamp_gold_smoke.py",
        "synthetic_gold_heldout": "scripts/run_timestamp_gold_smoke.py",
        "real_10min_structure": "scripts/run_real_timestamp_structure_smoke.py",
        "real_10min_timing_attention": "scripts/run_timing_attention_smoke.py",
        "candidate_build_only": "scripts/build_app.sh",
    }
    if name == "backend_full":
        valid = (
            len(command) >= 6
            and command[1:5] == ["-m", "pytest", "-q", "backend/tests"]
            and sum(part.startswith("--junitxml=") for part in command) == 1
        )
    elif name in script_requirements:
        valid = _command_targets_script(
            command, script_requirements[name], project_root=project_root
        )
        if name == "swift_full" or name == "candidate_build_only":
            valid = valid and len(command) == 1
        elif name == "synthetic_gold_primary":
            valid = valid and _flag_value(command, "--fixture") == "primary"
        elif name == "synthetic_gold_heldout":
            valid = valid and _flag_value(command, "--fixture") == "heldout"
        elif name == "real_10min_structure":
            valid = valid and _flag_value(command, "--limit-seconds") == "600"
        elif name == "real_10min_timing_attention":
            valid = valid and _flag_value(command, "--job-id") is not None
        if name not in {"swift_full", "candidate_build_only"}:
            output = _flag_value(command, "--output")
            valid = valid and output is not None
            if output is not None:
                try:
                    Path(output).expanduser().resolve().relative_to(
                        project_root.resolve(strict=True)
                    )
                except (OSError, RuntimeError, ValueError):
                    valid = False
    elif name == "candidate_codesign_strict":
        valid = list(command) == [
            "codesign",
            "--verify",
            "--deep",
            "--strict",
            "--verbose=2",
            str(candidate_bundle),
        ] or list(command) == [
            "/usr/bin/codesign",
            "--verify",
            "--deep",
            "--strict",
            "--verbose=2",
            str(candidate_bundle),
        ]
    else:
        valid = False
    if not valid:
        raise ValueError(f"source-bound build command {name} is not authoritative")


def _validate_source_bound_build_receipt(
    receipt: Mapping[str, Any],
    *,
    candidate: Mapping[str, Any],
    candidate_bundle: Path,
    source_manifest: Mapping[str, Any],
    project_root: Path = PROJECT_ROOT,
) -> None:
    receipt = _exact(receipt, V4_BUILD_RECEIPT_KEYS, "source-bound build receipt")
    if (
        receipt.get("schema") != "cts.timestamp-validation-execution/v4"
        or receipt.get("validation_complete") is not True
        or receipt.get("build_complete") is not True
        or receipt.get("build") != candidate.get("build")
        or receipt.get("candidate") != candidate
        or receipt.get("source_manifest") != source_manifest
        or not isinstance(receipt.get("execution_id"), str)
        or not _SAFE_EXECUTION_ID.fullmatch(receipt["execution_id"])
    ):
        raise ValueError("source-bound build receipt identity is invalid")
    measured_codesign = _codesign_identity(candidate_bundle)
    if receipt.get("candidate_codesign") != measured_codesign:
        raise ValueError("source-bound build codesign identity is invalid")

    for key in (
        "created_at",
        "validation_completed_at",
        "build_completed_at",
    ):
        if not isinstance(receipt.get(key), str) or not receipt.get(key):
            raise ValueError("source-bound build timestamps are invalid")
    if not (
        receipt["created_at"]
        <= receipt["validation_completed_at"]
        <= receipt["build_completed_at"]
    ):
        raise ValueError("source-bound build timestamp order is invalid")

    before = _validate_installed_snapshot(
        receipt.get("installed_before"), "installed-before snapshot"
    )
    after = _validate_installed_snapshot(
        receipt.get("installed_after"), "installed-after snapshot"
    )
    protected = {
        "path",
        "exists",
        "version",
        "build",
        "info_plist_sha256",
        "binary_sha256",
        "entry_count",
        "canonical_inventory_sha256",
    }
    for key in protected:
        if before.get(key) != after.get(key):
            raise ValueError("installed application changed during build-only run")

    commands = receipt.get("commands")
    if not isinstance(commands, list) or len(commands) != len(V4_BUILD_COMMAND_NAMES):
        raise ValueError("source-bound build command log is invalid")
    for index, name in enumerate(V4_BUILD_COMMAND_NAMES):
        row = _exact(
            commands[index], V4_BUILD_COMMAND_KEYS, f"source-bound build command {name}"
        )
        command = row.get("command")
        if (
            row.get("name") != name
            or row.get("exit_status") != 0
            or row.get("source_manifest_after") != source_manifest.get("sha256")
            or not isinstance(command, list)
            or not command
            or any(not isinstance(part, str) or not part for part in command)
            or not isinstance(row.get("started_at"), str)
            or not isinstance(row.get("completed_at"), str)
            or not row["started_at"] <= row["completed_at"]
        ):
            raise ValueError("source-bound candidate build command did not pass")
        _validate_v4_command(
            name,
            command,
            candidate_bundle=candidate_bundle,
            project_root=project_root,
        )
        _project_artifact(
            row.get("log"), project_root=project_root, label=f"{name} command log"
        )

    artifacts = _exact(
        receipt.get("artifacts"), V4_BUILD_ARTIFACT_KEYS, "source-bound build artifacts"
    )
    for name in sorted(V4_BUILD_ARTIFACT_KEYS):
        _project_artifact(
            artifacts[name], project_root=project_root, label=f"{name} artifact"
        )

    raw_receipt_path = receipt.get("receipt_path")
    if not isinstance(raw_receipt_path, str) or not raw_receipt_path:
        raise ValueError("source-bound build receipt path is invalid")
    original = Path(raw_receipt_path).expanduser().resolve(strict=True)
    original.relative_to(project_root.resolve(strict=True))
    original_value = json.loads(_stable_regular_bytes(original))
    if original_value != dict(receipt):
        raise ValueError("source-bound build receipt copy differs from authority")


def _authority_artifact_record(
    value: Mapping[str, Any], *, project_root: Path, label: str
) -> tuple[Path, bytes]:
    return _project_artifact(
        {key: value.get(key) for key in ("path", "bytes", "sha256")},
        project_root=project_root,
        label=label,
    )


def _validate_build39_baseline_authority(
    authority: Mapping[str, Any],
    *,
    authority_bytes: bytes,
    baseline_bundle: Path,
    baseline_receipt: Mapping[str, Any],
    baseline_receipt_bytes: bytes,
    project_root: Path,
    source_manifest: Mapping[str, Any],
) -> None:
    authority = _exact(
        authority,
        {
            "schema",
            "authority_id",
            "recorded_at",
            "bundle",
            "source",
            "timestamp_policy",
            "execution_receipt",
            "rc_evidence",
            "packaged_review",
            "final_review",
            "codesign_migration",
        },
        "Build 39 baseline authority",
    )
    if (
        authority.get("schema") != BUILD39_BASELINE_AUTHORITY_SCHEMA
        or not isinstance(authority.get("authority_id"), str)
        or not authority.get("authority_id")
        or not isinstance(authority.get("recorded_at"), str)
        or not authority.get("recorded_at")
    ):
        raise ValueError("Build 39 baseline authority identity is invalid")
    source_record = _source_record(source_manifest, BUILD39_BASELINE_AUTHORITY_PATH)
    if (
        source_record.get("sha256") != _bytes_sha256(authority_bytes)
        or source_record.get("bytes") != len(authority_bytes)
    ):
        raise ValueError("Build 39 baseline authority is not source-bound")

    bundle = _exact(
        authority.get("bundle"), {"path", "candidate", "codesign"}, "Build 39 bundle authority"
    )
    raw_bundle_path = bundle.get("path")
    if not isinstance(raw_bundle_path, str):
        raise ValueError("Build 39 authority bundle path is invalid")
    expected_bundle = (project_root / raw_bundle_path).resolve(strict=True)
    expected_bundle.relative_to(project_root.resolve(strict=True))
    if baseline_bundle.resolve(strict=True) != expected_bundle:
        raise ValueError("timestamp baseline is not the reviewed Build 39 archive")
    candidate = _exact(
        bundle.get("candidate"),
        {
            "version",
            "build",
            "file_count",
            "canonical_inventory_sha256",
            "info_plist_sha256",
            "binary_sha256",
        },
        "Build 39 candidate authority",
    )
    if (
        candidate.get("build") != BASELINE_BUILD
        or dict(candidate) != _candidate_bundle_identity(expected_bundle)
        or bundle.get("codesign") != _codesign_identity(expected_bundle)
    ):
        raise ValueError("reviewed Build 39 archive identity changed")

    source = _exact(
        authority.get("source"),
        {"manifest_sha256", "timestamp_policy_path", "timestamp_policy_sha256"},
        "Build 39 source authority",
    )
    policy = _exact(
        authority.get("timestamp_policy"),
        {"version", "packaged_path", "bytes", "sha256"},
        "Build 39 timestamp policy authority",
    )
    packaged_policy_path = expected_bundle / str(policy.get("packaged_path"))
    packaged_policy = _stable_regular_bytes(packaged_policy_path)
    if (
        source.get("manifest_sha256")
        != "8633b06fb9206b5b5410424484faa1abaf1c94c3ab5dc055c750dfe0f938c37e"
        or source.get("timestamp_policy_path") != TIMESTAMP_POLICY_SOURCE_PATH
        or source.get("timestamp_policy_sha256") != _bytes_sha256(packaged_policy)
        or policy.get("bytes") != len(packaged_policy)
        or policy.get("sha256") != _bytes_sha256(packaged_policy)
        or policy.get("version")
        != _literal_string_constant(packaged_policy, "FORCED_TIMESTAMP_POLICY_VERSION")
    ):
        raise ValueError("reviewed Build 39 timestamp policy identity changed")

    execution_record = _exact(
        authority.get("execution_receipt"),
        {"path", "bytes", "sha256", "schema", "validation_complete", "build_complete"},
        "Build 39 execution authority",
    )
    _, authoritative_receipt_bytes = _authority_artifact_record(
        execution_record, project_root=project_root, label="Build 39 execution receipt"
    )
    if (
        baseline_receipt_bytes != authoritative_receipt_bytes
        or baseline_receipt != json.loads(authoritative_receipt_bytes)
        or execution_record.get("schema") != "cts.timestamp-validation-execution/v2"
        or execution_record.get("validation_complete") is not True
        or execution_record.get("build_complete") is not True
        or baseline_receipt.get("schema") != execution_record.get("schema")
        or baseline_receipt.get("validation_complete") is not True
        or baseline_receipt.get("build_complete") is not True
        or baseline_receipt.get("source_manifest", {}).get("sha256")
        != source.get("manifest_sha256")
        or baseline_receipt.get("candidate")
        != {
            "version": candidate["version"],
            "build": candidate["build"],
            "file_count": candidate["file_count"],
            "canonical_inventory_sha256": candidate["canonical_inventory_sha256"],
        }
    ):
        raise ValueError("Build 39 execution receipt is not the reviewed v2 authority")
    legacy_commands = baseline_receipt.get("commands")
    expected_legacy_names = (
        "backend_full",
        "swift_full",
        "synthetic_gold_primary",
        "synthetic_gold_heldout",
        "real_10min_structure",
        "candidate_build_only",
    )
    if (
        not isinstance(legacy_commands, list)
        or tuple(row.get("name") for row in legacy_commands if isinstance(row, Mapping))
        != expected_legacy_names
        or any(
            row.get("exit_status") != 0
            or row.get("source_manifest_after") != source.get("manifest_sha256")
            for row in legacy_commands
            if isinstance(row, Mapping)
        )
    ):
        raise ValueError("reviewed Build 39 command chain is invalid")

    rc_record = _exact(
        authority.get("rc_evidence"),
        {"path", "bytes", "sha256", "execution_identity_sha256"},
        "Build 39 RC authority",
    )
    _, rc_bytes = _authority_artifact_record(
        rc_record, project_root=project_root, label="Build 39 RC evidence"
    )
    rc = json.loads(rc_bytes)
    if (
        rc.get("candidate", {}).get("canonical_inventory_sha256")
        != candidate["canonical_inventory_sha256"]
        or rc.get("execution_receipt", {}).get("sha256")
        != execution_record["sha256"]
        or rc.get("source", {}).get("manifest", {}).get("sha256")
        != source["manifest_sha256"]
        or rc.get("execution_identity_sha256")
        != rc_record.get("execution_identity_sha256")
        or rc.get("release_decision", {}).get("internal_rc_candidate") is not True
        or rc.get("release_decision", {}).get("production_release_approved") is not False
    ):
        raise ValueError("Build 39 RC authority does not bind the reviewed candidate")

    packaged_record = _exact(
        authority.get("packaged_review"),
        {
            "path",
            "bytes",
            "sha256",
            "internal_rc_package_verdict",
            "production_verdict",
            "installation_approved",
        },
        "Build 39 packaged review authority",
    )
    _, packaged_bytes = _authority_artifact_record(
        packaged_record, project_root=project_root, label="Build 39 packaged review"
    )
    packaged = json.loads(packaged_bytes)
    if (
        packaged_record.get("internal_rc_package_verdict") != "PASS"
        or packaged_record.get("production_verdict") != "BLOCKED"
        or packaged_record.get("installation_approved") is not False
        or packaged.get("verdicts", {}).get("internal_rc_package") != "PASS"
        or packaged.get("verdicts", {}).get("production") != "BLOCKED"
        or packaged.get("candidate", {}).get("inventory_sha256")
        != candidate["canonical_inventory_sha256"]
    ):
        raise ValueError("Build 39 packaged review authority is invalid")

    final_record = _exact(
        authority.get("final_review"),
        {
            "path",
            "bytes",
            "sha256",
            "internal_rc_candidate_complete",
            "production_complete",
        },
        "Build 39 final review authority",
    )
    _, final_bytes = _authority_artifact_record(
        final_record, project_root=project_root, label="Build 39 final review"
    )
    final_review = json.loads(final_bytes)
    if (
        final_record.get("internal_rc_candidate_complete") is not True
        or final_record.get("production_complete") is not False
        or final_review.get("scope", {}).get("internal_rc_candidate_complete") is not True
        or final_review.get("scope", {}).get("production_complete") is not False
        or final_review.get("validated_chain", {}).get("execution_receipt_sha256")
        != execution_record["sha256"]
    ):
        raise ValueError("Build 39 final review authority is invalid")

    migration = _exact(
        authority.get("codesign_migration"),
        {
            "measured_at",
            "original_v2_receipt_has_codesign_identity",
            "reviewed_signature_verdict",
        },
        "Build 39 codesign migration",
    )
    if (
        not isinstance(migration.get("measured_at"), str)
        or not migration.get("measured_at")
        or migration.get("original_v2_receipt_has_codesign_identity") is not False
        or migration.get("reviewed_signature_verdict") != "PASS_INTERNAL_ADHOC"
    ):
        raise ValueError("Build 39 codesign migration is invalid")


def _validate_model_manifests(models: object) -> list[dict[str, Any]]:
    if not isinstance(models, list):
        raise ValueError("timestamp model manifests are missing")
    validated: list[dict[str, Any]] = []
    names: set[str] = set()
    for raw in models:
        model = _exact(
            raw,
            {
                "name",
                "schema",
                "root",
                "file_count",
                "total_bytes",
                "canonical_inventory_sha256",
            },
            "timestamp model manifest",
        )
        name = model.get("name")
        root = model.get("root")
        if (
            not isinstance(name, str)
            or name in names
            or not isinstance(root, str)
        ):
            raise ValueError("timestamp model manifest identity is invalid")
        measured = {"name": name, **_directory_manifest(Path(root).expanduser())}
        if dict(model) != measured:
            raise ValueError("timestamp model recursive inventory is invalid")
        names.add(name)
        validated.append(measured)
    if names != REQUIRED_TIMESTAMP_MODEL_NAMES:
        raise ValueError("timestamp evaluation used an unexpected model set")
    return validated


def _evaluate_timestamp_production_receipt(
    root: Path,
    receipt_path: Path,
    *,
    candidate_bundle: Path,
    project_root: Path,
    duration_probe: Any | None = None,
    allow_test_source_manifest: bool = False,
    source_manifest_validator: Callable[[Mapping[str, Any], Path], Any]
    | None = None,
    build_receipt_validator: Callable[..., Any] | None = None,
    baseline_authority_validator: Callable[..., Any] | None = None,
    minimum_blinded_review_cues: int = 100,
) -> GoldValidation:
    try:
        manifest, evidence = _load_authoritative_sealed_gold(
            root,
            project_root=project_root,
            duration_probe=duration_probe,
            allow_test_source_manifest=allow_test_source_manifest,
        )
        if receipt_path.is_symlink():
            raise ValueError("timestamp evaluation receipt must not be a symlink")
        receipt_path = receipt_path.resolve(strict=True)
        receipt = json.loads(_stable_regular_bytes(receipt_path))
        receipt = _exact(
            receipt, TIMESTAMP_EVALUATION_RECEIPT_KEYS, "timestamp evaluation receipt"
        )
        if receipt.get("schema") != TIMESTAMP_EVALUATION_RECEIPT_SCHEMA:
            raise ValueError("timestamp evaluation receipt schema is invalid")
        execution_id = receipt.get("execution_id")
        if (
            not isinstance(execution_id, str)
            or not _SAFE_EXECUTION_ID.fullmatch(execution_id)
            or not isinstance(receipt.get("created_at"), str)
            or not receipt.get("created_at")
        ):
            raise ValueError("timestamp evaluation execution identity is invalid")

        source_manifest = receipt.get("candidate_source_manifest")
        if not isinstance(source_manifest, Mapping):
            raise ValueError("candidate source manifest is missing")
        _validate_source_manifest_shape(
            source_manifest, allow_test_schema=allow_test_source_manifest
        )
        validator = source_manifest_validator or _source_manifest_validator
        validator(source_manifest, project_root)

        candidate = _exact(
            receipt.get("candidate"),
            {
                "version",
                "build",
                "file_count",
                "canonical_inventory_sha256",
                "info_plist_sha256",
                "binary_sha256",
            },
            "candidate identity",
        )
        if dict(candidate) != _candidate_bundle_identity(candidate_bundle):
            raise ValueError("candidate bundle identity does not match evaluation receipt")

        _, _, build_receipt = _relative_json_artifact(
            receipt.get("source_bound_build_receipt"),
            base=receipt_path.parent,
            label="source-bound candidate build receipt",
        )
        build_validator = build_receipt_validator or _validate_source_bound_build_receipt
        build_validator(
            build_receipt,
            candidate=candidate,
            candidate_bundle=candidate_bundle,
            source_manifest=source_manifest,
            project_root=project_root,
        )

        timestamp_policy = _exact(
            receipt.get("timestamp_policy"),
            {
                "version",
                "source_path",
                "packaged_path",
                "source_sha256",
                "packaged_sha256",
            },
            "timestamp policy",
        )
        if dict(timestamp_policy) != _timestamp_policy_identity(
            candidate_bundle=candidate_bundle,
            project_root=project_root,
            source_manifest=source_manifest,
        ):
            raise ValueError("timestamp policy receipt is not packaged-source parity")

        evaluator = _exact(
            receipt.get("evaluator"),
            {"path", "sha256", "source_manifest_sha256"},
            "timestamp evaluator",
        )
        if evaluator.get("source_manifest_sha256") != source_manifest.get("sha256"):
            raise ValueError("timestamp evaluator source identity mismatch")
        if evaluator.get("path") != TIMESTAMP_EVALUATOR_PATH:
            raise ValueError("timestamp evaluator is not the production runner")
        _validate_bound_source_file(
            {"path": evaluator.get("path"), "sha256": evaluator.get("sha256")},
            project_root=project_root,
            source_manifest=source_manifest,
        )

        execution = _exact(
            receipt.get("execution"),
            {"command", "started_at", "completed_at", "exit_status", "log"},
            "timestamp evaluation execution",
        )
        command = execution.get("command")
        if (
            not isinstance(command, list)
            or not command
            or any(not isinstance(item, str) or not item for item in command)
            or evaluator.get("path") not in command
            or execution.get("exit_status") != 0
            or not isinstance(execution.get("started_at"), str)
            or not isinstance(execution.get("completed_at"), str)
            or not execution["started_at"] <= execution["completed_at"]
        ):
            raise ValueError("timestamp evaluation execution is invalid")
        required_command_pairs = (
            ("--candidate", str(candidate_bundle.resolve(strict=True))),
            ("--gold-root", str(root.resolve(strict=True))),
            ("--output-dir", str(receipt_path.parent.resolve(strict=True))),
        )
        for flag, expected in required_command_pairs:
            if flag not in command or command.index(flag) + 1 >= len(command):
                raise ValueError("timestamp evaluation command is incomplete")
            if command[command.index(flag) + 1] != expected:
                raise ValueError("timestamp evaluation command target is invalid")
        _relative_artifact(
            execution.get("log"),
            base=receipt_path.parent,
            label="timestamp evaluation execution log",
        )

        models = _validate_model_manifests(receipt.get("model_manifests"))
        model_checkpoint_hash = canonical_sha256(models[0])
        model_checkpoints = _exact(
            receipt.get("model_tree_checkpoints"),
            {
                "schema",
                "before_candidate",
                "after_candidate",
                "after_baseline",
                "before_finalization",
            },
            "timestamp model checkpoints",
        )
        if (
            model_checkpoints.get("schema") != TIMESTAMP_MODEL_CHECKPOINT_SCHEMA
            or any(
                model_checkpoints.get(key) != model_checkpoint_hash
                for key in (
                    "before_candidate",
                    "after_candidate",
                    "after_baseline",
                    "before_finalization",
                )
            )
        ):
            raise ValueError("timestamp model tree changed during evaluation")
        for model in models:
            if "--model-root" not in command:
                raise ValueError("timestamp evaluation command model target is missing")
            model_index = command.index("--model-root")
            if model_index + 1 >= len(command) or command[model_index + 1] != model["root"]:
                raise ValueError("timestamp evaluation command model target is invalid")

        gold = _exact(
            receipt.get("gold"),
            {
                "execution_id",
                "manifest_sha256",
                "source_manifest_sha256",
                "commit_inventory_sha256",
                "test_seal_sha256",
            },
            "evaluation gold identity",
        )
        test_seal = compute_test_seal(manifest)
        lineage = manifest.get("collection_lineage", {})
        if (
            gold.get("execution_id") != evidence.get("execution_id")
            or gold.get("manifest_sha256") != evidence.get("manifest_sha256")
            or gold.get("source_manifest_sha256") != evidence.get("source_manifest_sha256")
            or gold.get("source_manifest_sha256") != lineage.get("tool_source_manifest_sha256")
            or gold.get("commit_inventory_sha256") != evidence.get("commit_inventory_sha256")
            or gold.get("test_seal_sha256") != test_seal
            or manifest.get("split_contract", {}).get("test_seal_sha256") != test_seal
        ):
            raise ValueError("timestamp evaluation gold identity is invalid")

        _, candidate_input_bytes, _ = _relative_json_artifact(
            receipt.get("candidate_input_artifact"),
            base=receipt_path.parent,
            label="timestamp candidate input artifact",
        )
        _, result_bytes, result = _relative_json_artifact(
            receipt.get("result_artifact"),
            base=receipt_path.parent,
            label="timestamp result artifact",
        )
        if (
            result.get("execution_id") != execution_id
            or result.get("gold_test_seal_sha256") != test_seal
            or result.get("candidate_identity_sha256")
            != _candidate_identity_sha256(candidate)
        ):
            raise ValueError("timestamp result execution identity mismatch")

        _, _, pipeline_audit = _relative_json_artifact(
            receipt.get("pipeline_audit_artifact"),
            base=receipt_path.parent,
            label="timestamp pipeline audit artifact",
        )
        if (
            pipeline_audit.get("schema") != TIMESTAMP_PIPELINE_AUDIT_SCHEMA
            or pipeline_audit.get("policy_version") != timestamp_policy["version"]
        ):
            raise ValueError("timestamp pipeline audit policy is invalid")

        baseline = _exact(
            receipt.get("baseline"),
            {
                "execution_id",
                "bundle_path",
                "candidate",
                "authority",
                "source_bound_build_receipt",
                "execution",
                "result_artifact",
            },
            "timestamp baseline",
        )
        baseline_execution_id = baseline.get("execution_id")
        baseline_bundle_raw = baseline.get("bundle_path")
        if (
            not isinstance(baseline_execution_id, str)
            or not _SAFE_EXECUTION_ID.fullmatch(baseline_execution_id)
            or not isinstance(baseline_bundle_raw, str)
        ):
            raise ValueError("timestamp baseline identity is invalid")
        baseline_bundle = Path(baseline_bundle_raw).expanduser().resolve(strict=True)
        baseline_candidate = _exact(
            baseline.get("candidate"),
            {
                "version",
                "build",
                "file_count",
                "canonical_inventory_sha256",
                "info_plist_sha256",
                "binary_sha256",
            },
            "timestamp baseline candidate",
        )
        if (
            baseline_candidate.get("build") != BASELINE_BUILD
            or dict(baseline_candidate) != _candidate_bundle_identity(baseline_bundle)
        ):
            raise ValueError("timestamp baseline is not the bound Build 39 candidate")
        _, baseline_authority_bytes, baseline_authority = _relative_json_artifact(
            baseline.get("authority"),
            base=receipt_path.parent,
            label="Build 39 baseline authority",
        )
        authoritative_path = project_root / BUILD39_BASELINE_AUTHORITY_PATH
        authoritative_bytes = _stable_regular_bytes(authoritative_path)
        if baseline_authority_bytes != authoritative_bytes:
            raise ValueError("copied Build 39 authority differs from source authority")
        _, baseline_build_receipt_bytes, baseline_build_receipt = _relative_json_artifact(
            baseline.get("source_bound_build_receipt"),
            base=receipt_path.parent,
            label="source-bound baseline build receipt",
        )
        authority_validator = (
            baseline_authority_validator or _validate_build39_baseline_authority
        )
        authority_validator(
            baseline_authority,
            authority_bytes=baseline_authority_bytes,
            baseline_bundle=baseline_bundle,
            baseline_receipt=baseline_build_receipt,
            baseline_receipt_bytes=baseline_build_receipt_bytes,
            project_root=project_root,
            source_manifest=source_manifest,
        )
        baseline_execution = _exact(
            baseline.get("execution"),
            {"command", "started_at", "completed_at", "exit_status", "log"},
            "timestamp baseline execution",
        )
        baseline_command = baseline_execution.get("command")
        if (
            not isinstance(baseline_command, list)
            or TIMESTAMP_EVALUATOR_PATH not in baseline_command
            or baseline_execution.get("exit_status") != 0
            or "--candidate" not in baseline_command
            or baseline_command.index("--candidate") + 1 >= len(baseline_command)
            or baseline_command[baseline_command.index("--candidate") + 1]
            != str(baseline_bundle)
            or "--gold-root" not in baseline_command
            or baseline_command.index("--gold-root") + 1 >= len(baseline_command)
            or baseline_command[baseline_command.index("--gold-root") + 1]
            != str(root.resolve(strict=True))
            or "--model-root" not in baseline_command
            or baseline_command.index("--model-root") + 1 >= len(baseline_command)
            or baseline_command[baseline_command.index("--model-root") + 1]
            != models[0]["root"]
        ):
            raise ValueError("timestamp baseline runner execution is invalid")
        _relative_artifact(
            baseline_execution.get("log"),
            base=receipt_path.parent,
            label="timestamp baseline execution log",
        )
        _, baseline_result_bytes, baseline_result = _relative_json_artifact(
            baseline.get("result_artifact"),
            base=receipt_path.parent,
            label="timestamp baseline result artifact",
        )

        blinded_records = _exact(
            receipt.get("blinded_review"),
            {"transaction", "plan", "packet", "html", "response", "receipt"},
            "blinded review artifact records",
        )
        blinded_review: dict[str, Mapping[str, Any]] = {}
        blinded_paths: dict[str, Path] = {}
        for name in ("transaction", "plan", "packet", "response", "receipt"):
            artifact_path, _, value = _relative_json_artifact(
                blinded_records[name],
                base=receipt_path.parent,
                label=f"blinded review {name} artifact",
            )
            blinded_paths[name] = artifact_path
            blinded_review[name] = value
        blinded_html_path, blinded_html = _relative_artifact(
            blinded_records["html"],
            base=receipt_path.parent,
            label="blinded review HTML",
        )
        blinded_paths["html"] = blinded_html_path
        transaction = blinded_review["transaction"]
        if (
            transaction.get("renderer_path") != BLINDED_REVIEW_RENDERER_PATH
            or transaction.get("review_html_sha256") != _bytes_sha256(blinded_html)
            or stat.S_IMODE(blinded_paths["transaction"].stat().st_mode) != 0o400
            or blinded_paths["response"].stat().st_mtime_ns
            < blinded_paths["transaction"].stat().st_mtime_ns
        ):
            raise ValueError("blinded review renderer transaction is invalid")
        _validate_bound_source_file(
            {
                "path": transaction.get("renderer_path"),
                "sha256": transaction.get("renderer_sha256"),
            },
            project_root=project_root,
            source_manifest=source_manifest,
        )
        packet_rows = blinded_review["packet"].get("presentations")
        if not isinstance(packet_rows, list):
            raise ValueError("blinded review packet has no presentations")
        verified_audio: dict[str, str] = {}
        for row in packet_rows:
            if not isinstance(row, Mapping):
                raise ValueError("blinded review packet presentation is invalid")
            relative = row.get("audio_path")
            digest = row.get("audio_sha256")
            if not isinstance(relative, str) or not isinstance(digest, str):
                raise ValueError("blinded review audio identity is invalid")
            prior = verified_audio.get(relative)
            if prior is not None and prior != digest:
                raise ValueError("blinded review audio path has conflicting hashes")
            pure = PurePosixPath(relative)
            if pure.is_absolute() or ".." in pure.parts or pure.as_posix() != relative:
                raise ValueError("blinded review audio path is unsafe")
            audio_path = (receipt_path.parent / relative).resolve(strict=True)
            audio_path.relative_to(receipt_path.parent.resolve(strict=True))
            if _bytes_sha256(_stable_regular_bytes(audio_path)) != digest:
                raise ValueError("blinded review audio bytes changed")
            verified_audio[relative] = digest

        prepared_artifacts = {
            "candidate_result": dict(receipt["result_artifact"]),
            "candidate_input": dict(receipt["candidate_input_artifact"]),
            "candidate_audit": dict(receipt["pipeline_audit_artifact"]),
            "baseline_result": dict(baseline["result_artifact"]),
            "candidate_build_receipt": dict(receipt["source_bound_build_receipt"]),
            "baseline_build_receipt": dict(baseline["source_bound_build_receipt"]),
            "baseline_authority": dict(baseline["authority"]),
            "blinded_review_plan_private": dict(blinded_records["plan"]),
            "blinded_review_packet": dict(blinded_records["packet"]),
            "blinded_review_html": dict(blinded_records["html"]),
        }
        review_audio_records = []
        for relative, digest in sorted(verified_audio.items()):
            audio_path = (receipt_path.parent / relative).resolve(strict=True)
            payload = _stable_regular_bytes(audio_path)
            review_audio_records.append(
                {"path": relative, "bytes": len(payload), "sha256": digest}
            )
        expected_prepared_inventory_sha256 = canonical_sha256(
            {
                "artifacts": prepared_artifacts,
                "review_audio": review_audio_records,
                "renderer": {
                    "path": BLINDED_REVIEW_RENDERER_PATH,
                    "sha256": transaction.get("renderer_sha256"),
                },
            }
        )
        if (
            transaction.get("prepared_inventory_sha256")
            != expected_prepared_inventory_sha256
        ):
            raise ValueError("blinded review pre-review inventory binding is invalid")

        metrics = timestamp_metrics_from_evidence(
            manifest=manifest,
            candidate_result=result,
            candidate_result_sha256=_bytes_sha256(result_bytes),
            baseline_result=baseline_result,
            baseline_result_sha256=_bytes_sha256(baseline_result_bytes),
            pipeline_audit=pipeline_audit,
            candidate_input_sha256=_bytes_sha256(candidate_input_bytes),
            model_manifest_sha256=model_checkpoint_hash,
            blinded_review=blinded_review,
            execution_id=execution_id,
            candidate_identity_sha256=_candidate_identity_sha256(candidate),
            baseline_execution_id=baseline_execution_id,
            baseline_identity_sha256=_candidate_identity_sha256(baseline_candidate),
            test_seal_sha256=test_seal,
            minimum_blinded_review_cues=minimum_blinded_review_cues,
        )
        if receipt.get("metrics") != metrics:
            raise ValueError("timestamp metrics are not the deterministic result projection")
        measured = _evaluate_timestamp_metric_thresholds(metrics)
        checks = {
            "authoritative_sealed_gold_verified": True,
            "candidate_evaluation_receipt_verified": True,
            **dict(measured.stats.get("checks", {})),
        }
        failures = tuple(name for name, passed in checks.items() if passed is not True)
        return GoldValidation(
            not failures,
            failures,
            {
                "checks": checks,
                "execution_id": execution_id,
                "candidate": dict(candidate),
                "candidate_source_manifest_sha256": source_manifest["sha256"],
                "result_artifact_sha256": _bytes_sha256(result_bytes),
                "metrics": metrics,
            },
        )
    except (OSError, RuntimeError, TypeError, ValueError, json.JSONDecodeError):
        return GoldValidation(
            False,
            ("candidate_evaluation_receipt_verified",),
            {"checks": {"candidate_evaluation_receipt_verified": False}},
        )


def _evaluate_timestamp_production_gate_from_metrics_for_tests(
    root: Path,
    metrics: Mapping[str, Any],
    *,
    project_root: Path | None = None,
    duration_probe: Any | None = None,
) -> GoldValidation:
    """Require an authoritative reconstructed seal before metric acceptance."""

    try:
        manifest, evidence = _load_authoritative_sealed_gold(
            root,
            project_root=project_root,
            duration_probe=duration_probe,
            allow_test_source_manifest=True,
        )
        test_seal = compute_test_seal(manifest)
    except (OSError, RuntimeError, TypeError, ValueError):
        return GoldValidation(
            False,
            ("authoritative_sealed_gold_verified",),
            {"checks": {"authoritative_sealed_gold_verified": False}},
        )

    lineage = manifest.get("collection_lineage", {})
    split_contract = manifest.get("split_contract", {})
    authoritative_checks = {
        "authoritative_sealed_gold_verified": (
            evidence.get("accepted") is True
            and evidence.get("status") == "AUTHORITATIVE_SEALED_HUMAN_GOLD"
        ),
        "gold_execution_id_bound": (
            metrics.get("gold_execution_id") == evidence.get("execution_id")
            == lineage.get("finalization_execution_id")
        ),
        "gold_manifest_sha256_bound": (
            metrics.get("gold_manifest_sha256") == evidence.get("manifest_sha256")
        ),
        "gold_source_manifest_sha256_bound": (
            metrics.get("gold_source_manifest_sha256")
            == evidence.get("source_manifest_sha256")
            == lineage.get("tool_source_manifest_sha256")
        ),
        "gold_commit_inventory_sha256_bound": (
            metrics.get("gold_commit_inventory_sha256")
            == evidence.get("commit_inventory_sha256")
        ),
        "locked_test_seal_verified": (
            metrics.get("gold_test_seal_sha256")
            == split_contract.get("test_seal_sha256")
            == test_seal
        ),
    }
    measured = _evaluate_timestamp_metric_thresholds(metrics)
    metric_checks = dict(measured.stats.get("checks", {}))
    checks = {**authoritative_checks, **metric_checks}
    failures = tuple(name for name, passed in checks.items() if passed is not True)
    return GoldValidation(
        not failures,
        failures,
        {
            "checks": checks,
            "authoritative_gold": {
                "execution_id": evidence["execution_id"],
                "manifest_sha256": evidence["manifest_sha256"],
                "source_manifest_sha256": evidence["source_manifest_sha256"],
                "commit_inventory_sha256": evidence[
                    "commit_inventory_sha256"
                ],
                "test_seal_sha256": test_seal,
            },
        },
    )


def evaluate_timestamp_production_gate(
    root: Path,
    receipt_path: Path,
    *,
    candidate_bundle: Path,
) -> GoldValidation:
    """Validate a source-bound, candidate-bound evaluation receipt."""

    return _evaluate_timestamp_production_receipt(
        root,
        receipt_path,
        candidate_bundle=candidate_bundle,
        project_root=PROJECT_ROOT,
    )


__all__ = [
    "FINALIZATION_RECEIPT_KEYS",
    "SEALED_MARKER_KEYS",
    "build_collection_lineage_from_root",
    "evaluate_timestamp_production_gate",
    "load_authoritative_sealed_gold",
    "publish_authoritative_gold",
]
