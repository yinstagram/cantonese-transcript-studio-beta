"""Revision-safe persistence for editable subtitle projects."""

from __future__ import annotations

import fcntl
import hashlib
import hmac
import json
import math
import os
import tempfile
import threading
from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

from .schemas import (
    MAX_PROJECT_BYTES,
    PROJECT_SCHEMA,
    SubtitleCue,
    SubtitleProject,
    SubtitleSegmentationPreferences,
    SubtitleSpeakerProfile,
    SubtitleSpeakerStyle,
    SubtitleStyle,
    SPEAKER_COLOUR_PALETTE,
)
from .segmentation import (
    SubtitleSegmentationPolicy,
    legal_subtitle_boundary_ids,
    segment_subtitles,
)


FINAL_ARTIFACT_LIMIT = 64 * 1024 * 1024
PROJECT_FILENAME = "subtitle-project.json"
# Sixteen bounded windows keep a normal two-hour transcript densely covered
# while retaining a hard upper bound on local-model work and memory.
MAX_SEMANTIC_SELECTOR_CALLS = 16
MAX_SEMANTIC_CANDIDATES_PER_CALL = 100


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, Mapping):
        return dict(value)
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        result = to_dict()
        return dict(result) if isinstance(result, Mapping) else {}
    raw = getattr(value, "__dict__", None)
    return dict(raw) if isinstance(raw, Mapping) else {}


def _state(value: Any) -> str:
    if isinstance(value, Enum):
        return str(value.value)
    return str(value or "")


def _safe_source_speaker_text(value: Any) -> str | None:
    """Bound untrusted diarizer metadata before storing it as project audit text."""
    if not isinstance(value, str):
        return None
    result = value.strip()
    if (
        not result
        or result == "Unknown"
        or len(result.encode("utf-8")) > 256
        or any(character in result for character in ("\x00", "\r", "\n"))
    ):
        return None
    return result


def _sha256(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def _read_bytes(path: Path, *, maximum: int) -> bytes:
    if path.is_symlink() or not path.is_file():
        raise FileNotFoundError(f"搵唔到安全 artifact：{path.name}")
    stat = path.stat()
    if stat.st_size > maximum:
        raise ValueError(f"{path.name} 超出大小限制")
    return path.read_bytes()


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_descriptor = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)
    except BaseException:
        try:
            failed = path.parent / ".failed-writes"
            failed.mkdir(exist_ok=True)
            if temporary.exists():
                os.replace(temporary, failed / f"{path.name}-{os.getpid()}-{threading.get_ident()}")
        except OSError:
            pass
        raise


def _strict_sequence(value: Any, name: str) -> Sequence[Any]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise ValueError(f"{name} 必須係 array")
    return value


def _source_text(document: Mapping[str, Any]) -> str:
    text = document.get("text", document.get("final_transcript"))
    if not isinstance(text, str):
        raise ValueError("final transcript 缺少完整文字")
    return text


@dataclass(frozen=True)
class SubtitleAutoSegmentationContext:
    """In-memory-only snapshot used before optional local semantic selection."""

    revision: int
    source_final_sha256: str
    text: str
    vocabulary: tuple[str, ...]
    candidate_boundary_ids: tuple[int, ...]


class SubtitleProjectStore:
    """Read and atomically update fixed-path subtitle projects."""

    def __init__(self, jobs_root: str | Path) -> None:
        self.jobs_root = Path(jobs_root).expanduser().resolve()
        self.jobs_root.mkdir(parents=True, exist_ok=True)
        self._thread_lock = threading.RLock()

    def workspace_for_job(self, job_id: str, job: Any) -> Path:
        if not job_id or Path(job_id).name != job_id or job_id in {".", ".."}:
            raise ValueError("job id 無效")
        value = _mapping(job)
        stored_id = str(value.get("job_id") or value.get("id") or "")
        if stored_id and stored_id != job_id:
            raise ValueError("job id 同 workspace 唔一致")
        raw_workspace = value.get("workspace") or value.get("workspace_path")
        candidate = Path(str(raw_workspace)).expanduser() if raw_workspace else self.jobs_root / job_id
        if candidate.is_symlink() or not candidate.is_dir():
            raise FileNotFoundError(f"搵唔到工作 workspace：{job_id}")
        root = self.jobs_root.resolve(strict=True)
        resolved = candidate.resolve(strict=True)
        try:
            resolved.relative_to(root)
        except ValueError as exc:
            raise ValueError("工作 workspace 超出 Jobs 目錄") from exc
        if resolved.name != job_id:
            raise ValueError("工作 workspace 路徑無效")
        return resolved

    @contextmanager
    def _locked(self, workspace: Path) -> Iterator[None]:
        with self._thread_lock:
            lock_path = workspace / ".subtitle-project.lock"
            with lock_path.open("a+b") as handle:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    @staticmethod
    def _require_completed(job: Any) -> dict[str, Any]:
        value = _mapping(job)
        state = _state(value.get("state", value.get("status")))
        if state != "completed":
            raise ValueError("只可以編輯已完成工作嘅字幕")
        return value

    @staticmethod
    def _load_final(workspace: Path) -> tuple[dict[str, Any], str]:
        path = workspace / "final.json"
        raw = _read_bytes(path, maximum=FINAL_ARTIFACT_LIMIT)
        try:
            envelope = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("final.json 已損壞") from exc
        if not isinstance(envelope, Mapping) or envelope.get("complete") is not True:
            raise ValueError("工作未有完整 final transcript")
        document = envelope.get("value")
        if not isinstance(document, Mapping):
            raise ValueError("final.json value 無效")
        sealed = {
            "fingerprint": envelope.get("fingerprint"),
            "value": document,
        }
        encoded = json.dumps(
            sealed,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        expected = envelope.get("payload_sha256")
        actual = hashlib.sha256(encoded).hexdigest()
        if not isinstance(expected, str) or not hmac.compare_digest(expected, actual):
            raise ValueError("final.json integrity seal 無效")
        return dict(document), _sha256(raw)

    def load_final_document(
        self,
        job_id: str,
        job: Any,
    ) -> tuple[dict[str, Any], str, Path]:
        """Return one integrity-checked immutable final artifact for derived work."""

        self._require_completed(job)
        workspace = self.workspace_for_job(job_id, job)
        document, final_sha = self._load_final(workspace)
        return document, final_sha, workspace

    @staticmethod
    def _duration_ms(document: Mapping[str, Any], job_value: Mapping[str, Any]) -> int:
        raw_duration = document.get("duration")
        if isinstance(raw_duration, (int, float)) and not isinstance(raw_duration, bool):
            duration = round(float(raw_duration) * 1000)
        else:
            duration = 0
        fine_segments = document.get("subtitle_segments")
        raw_segments = (
            fine_segments
            if isinstance(fine_segments, list) and fine_segments
            else document.get("segments")
        )
        if isinstance(raw_segments, list):
            for item in raw_segments:
                if isinstance(item, Mapping):
                    raw_end = item.get("end_ms")
                    if isinstance(raw_end, int) and not isinstance(raw_end, bool):
                        duration = max(duration, raw_end)
        checkpoints = job_value.get("checkpoints")
        probed = checkpoints.get("probed") if isinstance(checkpoints, Mapping) else None
        data = probed.get("data") if isinstance(probed, Mapping) else None
        media = data.get("media") if isinstance(data, Mapping) else None
        checkpoint_duration = media.get("duration_ms") if isinstance(media, Mapping) else None
        if isinstance(checkpoint_duration, (int, float)) and not isinstance(checkpoint_duration, bool):
            duration = max(duration, round(float(checkpoint_duration)))
        if duration <= 0:
            raise ValueError("final transcript 缺少有效音訊長度")
        return duration

    @classmethod
    def _create_from_final(
        cls,
        *,
        job_id: str,
        job_value: Mapping[str, Any],
        document: Mapping[str, Any],
        final_sha: str,
    ) -> SubtitleProject:
        duration = cls._duration_ms(document, job_value)
        fine_segments = document.get("subtitle_segments")
        raw_segments = (
            fine_segments
            if isinstance(fine_segments, list) and fine_segments
            else document.get("segments")
        )
        segments: list[SubtitleCue] = []
        speakers: list[SubtitleSpeakerProfile] = []
        speaker_by_source: dict[str, str] = {}
        if isinstance(raw_segments, list):
            for index, item in enumerate(raw_segments):
                if not isinstance(item, Mapping):
                    raise ValueError(f"final segment {index} 無效")
                audit = item.get("audit") if isinstance(item.get("audit"), Mapping) else {}
                text = item.get("chosen_text", item.get("text", ""))
                speaker_label = item.get("speaker_label")
                source_speaker_id = item.get("speaker_id")
                usable_label = _safe_source_speaker_text(speaker_label)
                usable_source_id = _safe_source_speaker_text(source_speaker_id)
                project_speaker_id: str | None = None
                if usable_source_id is not None or usable_label is not None:
                    source_key = usable_source_id or str(usable_label)
                    project_speaker_id = speaker_by_source.get(source_key)
                    if project_speaker_id is None:
                        ordinal = len(speakers) + 1
                        # External diarizer IDs are audit metadata, never trusted
                        # as project identifiers or claims about a real person.
                        project_speaker_id = f"speaker-{ordinal}"
                        profile = SubtitleSpeakerProfile.from_dict(
                            {
                                "id": project_speaker_id,
                                "display_name": usable_label or f"講者 {ordinal}",
                                "source_label": usable_label or usable_source_id,
                                "style": SubtitleSpeakerStyle(
                                    text_color_rgba=SPEAKER_COLOUR_PALETTE[
                                        len(speakers) % len(SPEAKER_COLOUR_PALETTE)
                                    ]
                                ).to_dict(),
                            }
                        )
                        speakers.append(profile)
                        speaker_by_source[source_key] = project_speaker_id
                cue = SubtitleCue.from_dict(
                    {
                        "id": f"cue-{index + 1:06d}",
                        "source_segment_index": (
                            item.get("source_segment_index")
                            if isinstance(item.get("source_segment_index"), int)
                            and not isinstance(item.get("source_segment_index"), bool)
                            else index
                        ),
                        "start_ms": item.get("start_ms"),
                        "end_ms": item.get("end_ms"),
                        "text": str(text or ""),
                        "source_confidence": item.get("confidence"),
                        "source_low_confidence": bool(
                            item.get(
                                "low_confidence",
                                audit.get("low_confidence", False),
                            )
                        ),
                        "source_start": item.get("source_start"),
                        "source_end": item.get("source_end"),
                        "boundary_reason": item.get("boundary_reason"),
                        "speaker_id": project_speaker_id,
                        "speaker_label": usable_label,
                    },
                    duration_ms=duration,
                )
                segments.append(cue)
        if not segments:
            transcript = document.get("text", document.get("final_transcript", ""))
            if isinstance(transcript, str) and transcript:
                segments.append(
                    SubtitleCue(
                        id="cue-000001",
                        source_segment_index=0,
                        start_ms=0,
                        end_ms=duration,
                        text=transcript,
                    )
                )
        source_path = document.get("source_path") or document.get("media_path") or job_value.get("source_path")
        if not isinstance(source_path, str) or not source_path:
            raise ValueError("工作缺少 source path")
        now = _utc_now()
        project = SubtitleProject(
            schema=PROJECT_SCHEMA,
            revision=1,
            job_id=job_id,
            source_path=source_path,
            source_fingerprint=str(job_value.get("fingerprint") or ""),
            source_final_sha256=final_sha,
            duration_ms=duration,
            created_at=now,
            updated_at=now,
            style=SubtitleStyle(),
            segments=tuple(segments),
            speakers=tuple(speakers),
        )
        return SubtitleProject.from_dict(project.to_dict(), expected_job_id=job_id)

    @staticmethod
    def _read_project(path: Path, *, job_id: str) -> SubtitleProject:
        raw = _read_bytes(path, maximum=MAX_PROJECT_BYTES)
        try:
            value = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("subtitle-project.json 已損壞") from exc
        return SubtitleProject.from_dict(value, expected_job_id=job_id)

    @staticmethod
    def _verify_final_source(project: SubtitleProject, workspace: Path) -> None:
        raw = _read_bytes(workspace / "final.json", maximum=FINAL_ARTIFACT_LIMIT)
        if _sha256(raw) != project.source_final_sha256:
            raise ValueError("來源逐字稿已更改；字幕 project 未有自動覆蓋")

    def get_or_create(self, job_id: str, job: Any) -> SubtitleProject:
        job_value = self._require_completed(job)
        workspace = self.workspace_for_job(job_id, job)
        path = workspace / PROJECT_FILENAME
        with self._locked(workspace):
            if path.exists():
                if path.is_symlink():
                    raise ValueError("subtitle-project.json 唔可以係 symlink")
                project = self._read_project(path, job_id=job_id)
                self._verify_final_source(project, workspace)
                return project
            document, final_sha = self._load_final(workspace)
            project = self._create_from_final(
                job_id=job_id,
                job_value=job_value,
                document=document,
                final_sha=final_sha,
            )
            _atomic_json(path, project.to_dict())
            return project

    def update(
        self,
        job_id: str,
        job: Any,
        submitted: Mapping[str, Any],
        *,
        expected_revision: int,
    ) -> SubtitleProject:
        if isinstance(expected_revision, bool) or not isinstance(expected_revision, int):
            raise ValueError("expected_revision 必須係整數")
        if not isinstance(submitted, Mapping):
            raise ValueError("project 必須係 object")
        try:
            submitted_size = len(
                json.dumps(
                    submitted,
                    ensure_ascii=False,
                    allow_nan=False,
                    separators=(",", ":"),
                ).encode("utf-8")
            )
        except (TypeError, ValueError) as exc:
            raise ValueError(f"project JSON 無效：{exc}") from exc
        if submitted_size > MAX_PROJECT_BYTES:
            raise ValueError("project 超過 16 MiB")
        self._require_completed(job)
        workspace = self.workspace_for_job(job_id, job)
        path = workspace / PROJECT_FILENAME
        with self._locked(workspace):
            if not path.is_file():
                document, final_sha = self._load_final(workspace)
                current = self._create_from_final(
                    job_id=job_id,
                    job_value=_mapping(job),
                    document=document,
                    final_sha=final_sha,
                )
                _atomic_json(path, current.to_dict())
            else:
                current = self._read_project(path, job_id=job_id)
            self._verify_final_source(current, workspace)
            if current.revision != expected_revision:
                raise ValueError(
                    f"stale_revision：目前 revision 係 {current.revision}，唔係 {expected_revision}"
                )
            submitted_revision = submitted.get("revision")
            if submitted_revision != expected_revision:
                raise ValueError("project revision 同 expected_revision 唔一致")
            for key in (
                "schema",
                "job_id",
                "source_path",
                "source_fingerprint",
                "source_final_sha256",
                "duration_ms",
                "created_at",
            ):
                if key in submitted and submitted[key] != current.to_dict()[key]:
                    raise ValueError(f"project 唔可以修改 {key}")
            candidate = replace(
                current,
                revision=current.revision + 1,
                updated_at=_utc_now(),
                style=SubtitleStyle.from_dict(submitted.get("style", {})),
                segments=tuple(
                    SubtitleCue.from_dict(item, duration_ms=current.duration_ms)
                    for item in submitted.get("segments", ())
                ),
                speakers=tuple(
                    SubtitleSpeakerProfile.from_dict(item)
                    for item in submitted.get(
                        "speakers", [speaker.to_dict() for speaker in current.speakers]
                    )
                ),
            )
            validated = SubtitleProject.from_dict(candidate.to_dict(), expected_job_id=job_id)
            _atomic_json(path, validated.to_dict())
            return validated

    def _auto_source_locked(
        self,
        *,
        job_id: str,
        job_value: Mapping[str, Any],
        workspace: Path,
        expected_revision: int,
    ) -> tuple[
        SubtitleProject,
        dict[str, Any],
        str,
        Sequence[Any],
        Sequence[Any],
        tuple[str, ...],
    ]:
        path = workspace / PROJECT_FILENAME
        if not path.is_file():
            document, final_sha = self._load_final(workspace)
            current = self._create_from_final(
                job_id=job_id,
                job_value=job_value,
                document=document,
                final_sha=final_sha,
            )
            _atomic_json(path, current.to_dict())
        else:
            current = self._read_project(path, job_id=job_id)
        self._verify_final_source(current, workspace)
        if current.revision != expected_revision:
            raise ValueError(
                f"stale_revision：目前 revision 係 {current.revision}，唔係 {expected_revision}"
            )

        document, final_sha = self._load_final(workspace)
        if final_sha != current.source_final_sha256:
            raise ValueError("來源逐字稿已更改；字幕 project 未有自動覆蓋")
        text = _source_text(document)
        current_text = "".join(cue.text for cue in current.segments)
        if current_text != text:
            raise ValueError(
                "字幕內容已經有人手修改；為免覆蓋你嘅文字，請先另存或還原原稿再自動分段"
            )
        words = _strict_sequence(document.get("word_timestamps", ()), "word_timestamps")
        characters = _strict_sequence(
            document.get("character_timestamps", ()), "character_timestamps"
        )
        if not words and not characters:
            raise ValueError("呢份工作未有精細時間碼，請重新轉錄後再使用自動分段")
        raw_vocabulary = _strict_sequence(document.get("vocabulary", ()), "vocabulary")
        if not all(isinstance(item, str) and item for item in raw_vocabulary):
            raise ValueError("vocabulary 必須係非空文字 array")
        return (
            current,
            document,
            text,
            words,
            characters,
            tuple(raw_vocabulary),
        )

    def auto_segment_context(
        self,
        job_id: str,
        job: Any,
        *,
        expected_revision: int,
    ) -> SubtitleAutoSegmentationContext:
        """Take a revision-checked snapshot without holding a lock during LLM work."""

        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 1 <= expected_revision <= 2_147_483_647
        ):
            raise ValueError("expected_revision 必須係正整數")
        job_value = self._require_completed(job)
        workspace = self.workspace_for_job(job_id, job)
        with self._locked(workspace):
            current, _, text, _, _, vocabulary = self._auto_source_locked(
                job_id=job_id,
                job_value=job_value,
                workspace=workspace,
                expected_revision=expected_revision,
            )
            return SubtitleAutoSegmentationContext(
                revision=current.revision,
                source_final_sha256=current.source_final_sha256,
                text=text,
                vocabulary=vocabulary,
                candidate_boundary_ids=legal_subtitle_boundary_ids(
                    text,
                    vocabulary=vocabulary,
                ),
            )

    @staticmethod
    def _source_metadata(
        document: Mapping[str, Any],
        *,
        source_start: int,
        source_end: int,
        start_ms: int,
        end_ms: int,
    ) -> dict[str, Any]:
        raw_fine = document.get("subtitle_segments")
        raw_segments = raw_fine if isinstance(raw_fine, list) and raw_fine else document.get("segments")
        matches: list[tuple[int, Mapping[str, Any]]] = []
        if isinstance(raw_segments, list):
            for position, raw in enumerate(raw_segments):
                if not isinstance(raw, Mapping):
                    continue
                raw_source_start = raw.get("source_start")
                raw_source_end = raw.get("source_end")
                source_overlap = (
                    isinstance(raw_source_start, int)
                    and not isinstance(raw_source_start, bool)
                    and isinstance(raw_source_end, int)
                    and not isinstance(raw_source_end, bool)
                    and raw_source_start < source_end
                    and raw_source_end > source_start
                )
                raw_start = raw.get("start_ms")
                raw_end = raw.get("end_ms")
                time_overlap = (
                    isinstance(raw_start, int)
                    and not isinstance(raw_start, bool)
                    and isinstance(raw_end, int)
                    and not isinstance(raw_end, bool)
                    and raw_start < end_ms
                    and raw_end > start_ms
                )
                if source_overlap or time_overlap:
                    matches.append((position, raw))
        indices: list[int] = []
        confidences: list[float] = []
        labels: set[str] = set()
        speaker_ids: set[str] = set()
        low_confidence = False
        for position, item in matches:
            raw_index = item.get("source_segment_index", position)
            if (
                isinstance(raw_index, int)
                and not isinstance(raw_index, bool)
                and 0 <= raw_index < 50_000
            ):
                indices.append(raw_index)
            confidence = item.get("confidence")
            if (
                isinstance(confidence, (int, float))
                and not isinstance(confidence, bool)
                and math.isfinite(float(confidence))
                and 0 <= float(confidence) <= 1
            ):
                confidences.append(float(confidence))
            audit = item.get("audit") if isinstance(item.get("audit"), Mapping) else {}
            low_confidence = low_confidence or bool(
                item.get("low_confidence", audit.get("low_confidence", False))
            )
            label = item.get("speaker_label")
            if isinstance(label, str) and label and label != "Unknown":
                labels.add(label)
            speaker_id = item.get("speaker_id")
            if isinstance(speaker_id, str) and speaker_id:
                speaker_ids.add(speaker_id)
        return {
            "source_segment_index": min(indices) if indices else 0,
            "source_confidence": min(confidences) if confidences else None,
            "source_low_confidence": low_confidence,
            # A mixed-speaker auto segment deliberately has no single label.
            "speaker_id": next(iter(speaker_ids)) if len(speaker_ids) == 1 else None,
            "speaker_label": next(iter(labels)) if len(labels) == 1 else None,
        }

    @staticmethod
    def select_semantic_boundaries(
        text: str,
        candidate_boundary_ids: Sequence[int],
        selector: Any | None,
    ) -> tuple[tuple[int, ...], dict[str, Any]]:
        if not isinstance(text, str):
            raise ValueError("text 必須係文字")
        if not isinstance(candidate_boundary_ids, Sequence) or isinstance(
            candidate_boundary_ids, (str, bytes, bytearray)
        ):
            raise ValueError("candidate_boundary_ids 必須係整數 array")
        candidate_ids = tuple(candidate_boundary_ids)
        if (
            any(
                isinstance(value, bool)
                or not isinstance(value, int)
                or not 0 < value < len(text)
                for value in candidate_ids
            )
            or len(set(candidate_ids)) != len(candidate_ids)
            or candidate_ids != tuple(sorted(candidate_ids))
        ):
            raise ValueError("candidate_boundary_ids 必須係有序、唯一、範圍內嘅整數")
        audit: dict[str, Any] = {
            "attempted": selector is not None,
            "candidate_count": len(candidate_ids),
            "selected_count": 0,
            "calls": [],
            "status": "fallback",
            "reason": "selector_not_configured",
        }
        if selector is None:
            return (), audit
        if not candidate_ids:
            audit.update({"reason": "no_candidate_boundaries"})
            return (), audit

        # Short recordings should not pay the cost of sixteen separate local
        # model round trips. Scale calls by the provider's bounded candidate
        # capacity; long transcripts retain the sixteen-window density cap.
        call_count = min(
            MAX_SEMANTIC_SELECTOR_CALLS,
            math.ceil(len(candidate_ids) / MAX_SEMANTIC_CANDIDATES_PER_CALL),
        )
        group_size = math.ceil(len(candidate_ids) / call_count)
        selected: set[int] = set()
        for call_index, first in enumerate(range(0, len(candidate_ids), group_size)):
            last = min(len(candidate_ids), first + group_size)
            complete_group = candidate_ids[first:last]
            if len(complete_group) <= MAX_SEMANTIC_CANDIDATES_PER_CALL:
                candidates = complete_group
            else:
                indexes = {
                    round(
                        position
                        * (len(complete_group) - 1)
                        / (MAX_SEMANTIC_CANDIDATES_PER_CALL - 1)
                    )
                    for position in range(MAX_SEMANTIC_CANDIDATES_PER_CALL)
                }
                candidates = tuple(complete_group[index] for index in sorted(indexes))
            chunk_start = 0 if first == 0 else candidate_ids[first - 1]
            chunk_end = len(text) if last == len(candidate_ids) else candidate_ids[last]
            try:
                selection = selector.select(
                    text[chunk_start:chunk_end],
                    candidates,
                    source_offset=chunk_start,
                    context_characters=6,
                )
                raw_audit = selection.audit.to_dict()
                boundary_ids = tuple(selection.boundary_ids)
            except Exception as exc:
                audit["calls"].append(
                    {
                        "index": call_index,
                        "status": "abstained",
                        "reason": f"selector_exception:{type(exc).__name__}",
                    }
                )
                audit.update({"reason": "selector_exception"})
                return (), audit
            safe_call_audit = {
                key: raw_audit[key]
                for key in (
                    "status",
                    "model",
                    "candidate_count",
                    "selected_count",
                    "reason",
                )
                if key in raw_audit
            }
            audit["calls"].append({"index": call_index, **safe_call_audit})
            if safe_call_audit.get("status") != "selected":
                audit.update(
                    {
                        "reason": str(
                            safe_call_audit.get("reason") or "selector_abstained"
                        ),
                    }
                )
                return (), audit
            allowed = set(candidates)
            if any(
                isinstance(value, bool)
                or not isinstance(value, int)
                or value not in allowed
                for value in boundary_ids
            ):
                audit.update({"reason": "selector_returned_unknown_boundary"})
                return (), audit
            selected.update(boundary_ids)

        ordered = tuple(sorted(selected))
        if not ordered:
            audit.update({"reason": "model_abstained_all_chunks"})
            return (), audit
        audit.update(
            {
                "status": "selected",
                "reason": "semantic_boundaries_selected",
                "selected_count": len(ordered),
            }
        )
        return ordered, audit

    def auto_segment(
        self,
        job_id: str,
        job: Any,
        *,
        expected_revision: int,
        max_characters: int,
        mode: str,
        semantic_boundary_ids: Sequence[int] = (),
        semantic_selector_audit: Mapping[str, Any] | None = None,
    ) -> SubtitleProject:
        """Atomically replace cue boundaries without ever rewriting transcript text."""

        if (
            isinstance(expected_revision, bool)
            or not isinstance(expected_revision, int)
            or not 1 <= expected_revision <= 2_147_483_647
        ):
            raise ValueError("expected_revision 必須係正整數")
        policy = SubtitleSegmentationPolicy(
            max_characters=max_characters,
            mode=mode,  # type: ignore[arg-type]
        )
        job_value = self._require_completed(job)
        workspace = self.workspace_for_job(job_id, job)
        path = workspace / PROJECT_FILENAME
        with self._locked(workspace):
            current, document, text, words, characters, vocabulary = (
                self._auto_source_locked(
                    job_id=job_id,
                    job_value=job_value,
                    workspace=workspace,
                    expected_revision=expected_revision,
                )
            )

            precise_result = segment_subtitles(
                text,
                word_timestamps=words,
                character_timestamps=characters,
                policy=SubtitleSegmentationPolicy(
                    max_characters=max_characters,
                    mode="precise",
                ),
                vocabulary=vocabulary,
                semantic_boundary_ids=(),
            )
            if not isinstance(semantic_boundary_ids, Sequence) or isinstance(
                semantic_boundary_ids, (str, bytes, bytearray)
            ):
                raise ValueError("semantic_boundary_ids 必須係整數 array")
            semantic_ids = tuple(semantic_boundary_ids)
            legal_semantic_ids = frozenset(
                legal_subtitle_boundary_ids(text, vocabulary=vocabulary)
            )
            if (
                any(
                    isinstance(value, bool)
                    or not isinstance(value, int)
                    or value not in legal_semantic_ids
                    for value in semantic_ids
                )
                or len(set(semantic_ids)) != len(semantic_ids)
                or semantic_ids != tuple(sorted(semantic_ids))
            ):
                raise ValueError(
                    "semantic_boundary_ids 只可以包含有序選擇器提供嘅安全斷點"
                )
            if mode == "precise" and semantic_ids:
                raise ValueError("precise mode 唔可以提交 semantic boundary IDs")
            if semantic_selector_audit is not None and not isinstance(
                semantic_selector_audit, Mapping
            ):
                raise ValueError("semantic_selector_audit 必須係 object")
            semantic_audit = dict(semantic_selector_audit or {})
            if mode == "precise":
                semantic_audit = {
                    "attempted": False,
                    "status": "not_requested",
                    "reason": "precise_mode",
                    "calls": [],
                    "candidate_count": 0,
                    "selected_count": 0,
                }
            elif not semantic_audit:
                semantic_audit = {
                    "attempted": False,
                    "status": "fallback",
                    "reason": "selector_not_configured",
                    "calls": [],
                    "candidate_count": 0,
                    "selected_count": 0,
                }
            result = (
                segment_subtitles(
                    text,
                    word_timestamps=words,
                    character_timestamps=characters,
                    policy=policy,
                    vocabulary=vocabulary,
                    semantic_boundary_ids=semantic_ids,
                )
                if semantic_ids
                else precise_result
            )
            if "".join(cue.text for cue in result.cues) != text:
                raise AssertionError("自動分段改變咗逐字稿")
            segments: list[SubtitleCue] = []
            previous_end = 0
            for cue in result.cues:
                if cue.start_ms < previous_end or cue.end_ms > current.duration_ms:
                    raise ValueError("精細時間碼超出音訊範圍，請重新轉錄後再試")
                metadata = self._source_metadata(
                    document,
                    source_start=cue.source_start,
                    source_end=cue.source_end,
                    start_ms=cue.start_ms,
                    end_ms=cue.end_ms,
                )
                current_overlaps = [
                    existing
                    for existing in current.segments
                    if existing.start_ms < cue.end_ms and existing.end_ms > cue.start_ms
                ]
                current_speaker_ids = {
                    existing.speaker_id
                    for existing in current_overlaps
                    if existing.speaker_id is not None
                }
                if len(current_speaker_ids) == 1:
                    retained_id = next(iter(current_speaker_ids))
                    retained_profile = next(
                        (
                            profile
                            for profile in current.speakers
                            if profile.id == retained_id
                        ),
                        None,
                    )
                    metadata["speaker_id"] = retained_id
                    metadata["speaker_label"] = (
                        retained_profile.source_label
                        if retained_profile is not None
                        else metadata.get("speaker_label")
                    )
                elif len(current_speaker_ids) > 1:
                    # A re-segmented cue that crosses a speaker boundary stays
                    # explicitly unassigned rather than inventing a dominant
                    # identity. The user can split or reassign it in the editor.
                    metadata["speaker_id"] = None
                    metadata["speaker_label"] = None
                segments.append(
                    SubtitleCue.from_dict(
                        {
                            "id": f"cue-{cue.index:06d}",
                            **metadata,
                            "start_ms": cue.start_ms,
                            "end_ms": cue.end_ms,
                            "text": cue.text,
                            "source_start": cue.source_start,
                            "source_end": cue.source_end,
                            "boundary_reason": cue.boundary_reason,
                        },
                        duration_ms=current.duration_ms,
                    )
                )
                previous_end = cue.end_ms

            audit = result.audit.to_dict()
            audit.update(
                {
                    "applied_at": _utc_now(),
                    "exact_text_preserved": True,
                    "source_text_sha256": _sha256(text.encode("utf-8")),
                    "source_final_sha256": current.source_final_sha256,
                    "previous_revision": current.revision,
                    "result_revision": current.revision + 1,
                    "cue_count": len(segments),
                    "requested_mode": mode,
                    "effective_mode": result.audit.mode,
                    "semantic_selector": semantic_audit,
                }
            )
            candidate = replace(
                current,
                revision=current.revision + 1,
                updated_at=_utc_now(),
                segments=tuple(segments),
                segmentation_preferences=SubtitleSegmentationPreferences(
                    max_characters=max_characters,
                    mode=mode,
                ),
                segmentation_audit=audit,
            )
            validated = SubtitleProject.from_dict(candidate.to_dict(), expected_job_id=job_id)
            _atomic_json(path, validated.to_dict())
            return validated


__all__ = [
    "PROJECT_FILENAME",
    "SubtitleAutoSegmentationContext",
    "SubtitleProjectStore",
]
