"""Fail-closed local judge for text-only semantic pairing proposals.

The local model receives a formal reference caption unit plus two to four
preselected raw-Cantonese candidate spans.  It may only return immutable IDs
and an allowed relation.  It never receives timestamp, VAD, or acoustic
alignment fields; a model proposal never makes a timing row eligible.
"""

from __future__ import annotations

import json
from contextlib import contextmanager
import signal
import threading
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import asdict, dataclass
from typing import Any, Mapping, Sequence

from .semantic_pairing import (
    CandidateSpan,
    ReferenceUnit,
    assert_no_timestamp_fields,
)


SEMANTIC_PAIR_JUDGE_POLICY_VERSION = "local-semantic-pair-judge-m0-2026-09-03"
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "::1"})
_CHAT_COMPLETIONS_PATH = "/v1/chat/completions"
_RELATIONS = frozenset({"same_meaning", "partial", "different", "uncertain"})


@contextmanager
def _hard_request_deadline(seconds: float | None):
    """Bound one local-model request even after the HTTP headers arrived.

    A socket timeout is insufficient when a local OpenAI-compatible server
    accepts the request then leaves the response body open while generating.
    On the main POSIX thread, SIGALRM safely interrupts that blocking read;
    other threads retain the normal socket timeout rather than modifying a
    process-global signal handler.  Callers catch the resulting TimeoutError
    and record an abstention instead of a semantic match.
    """

    if (
        seconds is None
        or threading.current_thread() is not threading.main_thread()
        or not hasattr(signal, "SIGALRM")
        or not hasattr(signal, "setitimer")
    ):
        yield
        return
    previous_handler = signal.getsignal(signal.SIGALRM)
    previous_delay, previous_interval = signal.setitimer(signal.ITIMER_REAL, 0)
    if previous_delay > 0 or previous_interval > 0:
        signal.setitimer(signal.ITIMER_REAL, previous_delay, previous_interval)
        yield
        return

    def _expired(_signum: int, _frame: object) -> None:
        raise TimeoutError("local semantic model hard deadline exceeded")

    signal.signal(signal.SIGALRM, _expired)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """A transcript-bearing local request must never leave loopback."""

    def redirect_request(self, *_: object, **__: object) -> None:
        return None


@dataclass(frozen=True)
class SemanticPairJudgeAudit:
    """Privacy-safe audit: contains counts/status only, never caption text."""

    status: str
    model: str
    candidate_count: int
    reason: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class SemanticPairJudgment:
    reference_unit_id: str
    candidate_span_id: str | None
    relation: str | None
    evidence_atom_ids: tuple[str, ...]
    audit: SemanticPairJudgeAudit

    def to_dict(self) -> dict[str, object]:
        return {
            "reference_unit_id": self.reference_unit_id,
            "candidate_span_id": self.candidate_span_id,
            "relation": self.relation,
            "evidence_atom_ids": list(self.evidence_atom_ids),
            "audit": self.audit.to_dict(),
            "timing_eligibility": "UNASSESSABLE_NO_HUMAN_SEMANTIC_CONFIRMATION",
        }


def _validated_endpoint(endpoint: str) -> str:
    if not isinstance(endpoint, str) or not endpoint:
        raise ValueError("semantic pair judge endpoint 唔可以空白")
    try:
        parsed = urllib.parse.urlsplit(endpoint)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("semantic pair judge endpoint 無效") from exc
    if (
        parsed.scheme != "http"
        or parsed.hostname not in _LOOPBACK_HOSTS
        or port is None
        or not 1024 <= port <= 65_535
        or parsed.path.rstrip("/") != _CHAT_COMPLETIONS_PATH
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or not parsed.netloc
    ):
        raise ValueError(
            "semantic pair judge endpoint 必須係本機 loopback chat completions"
        )
    return endpoint


def _parse_response(
    content: str,
    *,
    reference_unit_id: str,
    spans: Mapping[str, CandidateSpan],
) -> tuple[bool, str | None, str | None, tuple[str, ...], str]:
    try:
        value = json.loads(content)
    except (TypeError, json.JSONDecodeError):
        return False, None, None, (), "invalid_json"
    if not isinstance(value, dict) or set(value) != {
        "reference_unit_id",
        "candidate_span_id",
        "relation",
        "evidence_atom_ids",
    }:
        return False, None, None, (), "invalid_schema"
    if value.get("reference_unit_id") != reference_unit_id:
        return False, None, None, (), "wrong_reference_unit"
    span_id = value.get("candidate_span_id")
    relation = value.get("relation")
    evidence = value.get("evidence_atom_ids")
    if span_id == "abstain":
        # ``different`` is a meaningful, still-safe abstention: the model saw
        # the offered options and found no same-meaning span.  It has no
        # candidate ID/evidence and can never make a timing row eligible.
        if relation not in {"uncertain", "different"} or evidence != []:
            return False, None, None, (), "invalid_abstention"
        return True, None, str(relation), (), "model_abstained"
    if not isinstance(span_id, str) or span_id not in spans:
        return False, None, None, (), "unknown_candidate_span"
    if relation not in _RELATIONS:
        return False, None, None, (), "invalid_relation"
    if not isinstance(evidence, list) or not evidence:
        return False, None, None, (), "invalid_evidence_atoms"
    if any(isinstance(item, bool) or not isinstance(item, str) for item in evidence):
        return False, None, None, (), "invalid_evidence_atoms"
    if len(evidence) != len(set(evidence)):
        return False, None, None, (), "duplicate_evidence_atoms"
    if not set(evidence).issubset(spans[span_id].atom_ids):
        return False, None, None, (), "unknown_evidence_atom"
    return True, span_id, str(relation), tuple(evidence), "model_proposed"


class LocalSemanticPairJudge:
    """Bounded, loopback-only semantic-ID proposer with fail-closed abstention."""

    policy_version = SEMANTIC_PAIR_JUDGE_POLICY_VERSION

    def __init__(
        self,
        *,
        endpoint: str,
        model: str,
        timeout_seconds: float = 45.0,
        hard_deadline_seconds: float | None = None,
        max_response_bytes: int = 16_384,
    ) -> None:
        self.endpoint = _validated_endpoint(endpoint)
        if not isinstance(model, str) or not model.strip():
            raise ValueError("semantic pair judge model 唔可以空白")
        self.model = model.strip()
        if (
            isinstance(timeout_seconds, bool)
            or not isinstance(timeout_seconds, (int, float))
            or not 1.0 <= float(timeout_seconds) <= 120.0
        ):
            raise ValueError("semantic pair judge timeout 必須係 1 至 120 秒")
        self.timeout_seconds = float(timeout_seconds)
        if hard_deadline_seconds is not None and (
            isinstance(hard_deadline_seconds, bool)
            or not isinstance(hard_deadline_seconds, (int, float))
            or not 1.0 <= float(hard_deadline_seconds) <= 120.0
        ):
            raise ValueError("semantic pair judge hard deadline 必須係 1 至 120 秒或 null")
        self.hard_deadline_seconds = (
            None if hard_deadline_seconds is None else float(hard_deadline_seconds)
        )
        if (
            isinstance(max_response_bytes, bool)
            or not isinstance(max_response_bytes, int)
            or not 256 <= max_response_bytes <= 65_536
        ):
            raise ValueError("semantic pair judge response cap 必須係 256 至 65536 bytes")
        self.max_response_bytes = max_response_bytes
        self._opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), _NoRedirectHandler()
        )
        self._disabled_reason: str | None = None

    def _abstain(
        self,
        reference_unit_id: str,
        *,
        candidate_count: int,
        reason: str,
    ) -> SemanticPairJudgment:
        return SemanticPairJudgment(
            reference_unit_id=reference_unit_id,
            candidate_span_id=None,
            relation=None,
            evidence_atom_ids=(),
            audit=SemanticPairJudgeAudit(
                status="abstained",
                model=self.model,
                candidate_count=candidate_count,
                reason=reason,
            ),
        )

    def judge(
        self,
        reference: ReferenceUnit,
        candidates: Sequence[CandidateSpan],
    ) -> SemanticPairJudgment:
        candidate_count = len(candidates) if isinstance(candidates, Sequence) else 0
        if self._disabled_reason is not None:
            return self._abstain(
                reference.unit_id,
                candidate_count=candidate_count,
                reason="circuit_open",
            )
        if (
            not isinstance(reference, ReferenceUnit)
            or not isinstance(candidates, Sequence)
            or isinstance(candidates, (str, bytes, bytearray))
            or not 2 <= candidate_count <= 4
            or len(reference.text) > 2_000
        ):
            return self._abstain(
                reference.unit_id if isinstance(reference, ReferenceUnit) else "",
                candidate_count=candidate_count,
                reason="invalid_request",
            )
        spans = {candidate.span_id: candidate for candidate in candidates}
        if (
            len(spans) != candidate_count
            or any(
                not candidate.text.strip()
                or len(candidate.text) > 4_000
                or not candidate.atom_ids
                or len(set(candidate.atom_ids)) != len(candidate.atom_ids)
                for candidate in candidates
            )
        ):
            return self._abstain(
                reference.unit_id, candidate_count=candidate_count, reason="invalid_candidates"
            )
        allowed_span_ids = [*spans, "abstain"]
        allowed_atom_ids = [atom for candidate in candidates for atom in candidate.atom_ids]
        user_payload = {
            "task": (
                "Compare the approximate meaning of one formal Chinese reference caption and "
                "the supplied raw Cantonese candidate spans. Choose only one supplied immutable "
                "candidate span ID, or abstain when none is reliable. Do not infer timing."
            ),
            "reference": {"id": reference.unit_id, "text": reference.text},
            "candidate_options": [
                {
                    "id": candidate.span_id,
                    "text": candidate.text,
                    "evidence_atom_ids": list(candidate.atom_ids),
                }
                for candidate in candidates
            ],
            "allowed_candidate_span_ids": allowed_span_ids,
            "allowed_relations": sorted(_RELATIONS),
        }
        assert_no_timestamp_fields(user_payload)
        request_payload = {
            "model": self.model,
            "temperature": 0,
            "max_tokens": 160,
            "reasoning_effort": "none",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你係香港廣東話字幕語意配對器。reference 可能係正式書面中文，"
                        "candidate 係口語 ASR。只判斷大概意思，唔要求逐字一樣；"
                        "但數字、否定、專有名詞或核心事件有衝突時，要揀 partial、different 或 uncertain。"
                        "你唔可以新增、刪除、改寫、翻譯、重排任何字幕，亦唔可以推斷時間。"
                        "只輸出一個 JSON object，並且只可使用提供嘅 immutable IDs。"
                        "如冇任何可靠候選，必須精確輸出 candidate_span_id='abstain'、"
                        "relation='uncertain' 或 'different'，以及空嘅 evidence_atom_ids=[]。"
                        "如揀咗 candidate span，evidence_atom_ids 必須只包含該 span 提供嘅 IDs，"
                        "而且唔可以係空陣列。"
                    ),
                },
                {"role": "user", "content": json.dumps(user_payload, ensure_ascii=False, separators=(",", ":"))},
            ],
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "semantic_pair_proposal",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {
                            "reference_unit_id": {"type": "string", "const": reference.unit_id},
                            "candidate_span_id": {"type": "string", "enum": allowed_span_ids},
                            "relation": {"type": "string", "enum": sorted(_RELATIONS)},
                            "evidence_atom_ids": {
                                "type": "array",
                                "items": {"type": "string", "enum": allowed_atom_ids},
                                "uniqueItems": True,
                                "maxItems": max(len(allowed_atom_ids), 1),
                            },
                        },
                        "required": [
                            "reference_unit_id",
                            "candidate_span_id",
                            "relation",
                            "evidence_atom_ids",
                        ],
                        "additionalProperties": False,
                    },
                },
            },
        }
        request = urllib.request.Request(
            self.endpoint,
            data=json.dumps(request_payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                status = getattr(response, "status", None)
                if status is None:
                    status = response.getcode()
                if status != 200:
                    self._disabled_reason = "http_error"
                    return self._abstain(
                        reference.unit_id, candidate_count=candidate_count, reason="http_error"
                    )
                raw = response.read(self.max_response_bytes + 1)
            if len(raw) > self.max_response_bytes:
                self._disabled_reason = "response_too_large"
                return self._abstain(
                    reference.unit_id,
                    candidate_count=candidate_count,
                    reason="response_too_large",
                )
            payload = json.loads(raw.decode("utf-8"))
            content = payload["choices"][0]["message"]["content"]
            if not isinstance(content, str):
                return self._abstain(
                    reference.unit_id,
                    candidate_count=candidate_count,
                    reason="invalid_response",
                )
            valid, span_id, relation, evidence, reason = _parse_response(
                content, reference_unit_id=reference.unit_id, spans=spans
            )
            if not valid:
                return self._abstain(
                    reference.unit_id, candidate_count=candidate_count, reason=reason
                )
            status = "model_proposed" if span_id is not None else "abstained"
            return SemanticPairJudgment(
                reference_unit_id=reference.unit_id,
                candidate_span_id=span_id,
                relation=relation,
                evidence_atom_ids=evidence,
                audit=SemanticPairJudgeAudit(
                    status=status,
                    model=self.model,
                    candidate_count=candidate_count,
                    reason=reason,
                ),
            )
        except (TimeoutError, urllib.error.URLError) as exc:
            reason = (
                "timeout"
                if isinstance(exc, TimeoutError)
                or (
                    isinstance(exc, urllib.error.URLError)
                    and isinstance(exc.reason, TimeoutError)
                )
                else "unavailable"
            )
            self._disabled_reason = reason
            return self._abstain(
                reference.unit_id, candidate_count=candidate_count, reason=reason
            )
        except (
            OSError,
            KeyError,
            IndexError,
            TypeError,
            ValueError,
            json.JSONDecodeError,
        ):
            return self._abstain(
                reference.unit_id, candidate_count=candidate_count, reason="invalid_response"
            )


__all__ = [
    "SEMANTIC_PAIR_JUDGE_POLICY_VERSION",
    "LocalSemanticPairJudge",
    "SemanticPairJudgeAudit",
    "SemanticPairJudgment",
]
