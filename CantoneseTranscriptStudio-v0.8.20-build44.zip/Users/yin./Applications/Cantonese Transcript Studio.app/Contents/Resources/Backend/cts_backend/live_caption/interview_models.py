"""Validated, session-only configuration for the live Interview Coach.

The interview plan crosses the Swift -> Python live-start boundary but is never
persisted by the backend.  These models deliberately reject unknown fields and
keep every text input bounded because questions, expected answers and concept
labels are user-authored, untrusted model data.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


_QUESTION_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_QUESTION_KEYS = frozenset(
    {"id", "prompt", "expected_answer", "required_concepts"}
)
_INTERVIEW_KEYS = frozenset({"enabled", "questions"})
# The live E2B runtime has a fixed 2,048-token context.  Individual field caps
# protect UI/storage boundaries; this aggregate UTF-8 cap protects inference.
# Swift can mirror the exact byte-sum rule before sending live.start.
INTERVIEW_QUESTION_UTF8_BUDGET = 600


def _normalized_text(value: object, *, field: str, minimum: int, maximum: int) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} 必須係文字")
    clean = " ".join(value.split())
    if not minimum <= len(clean) <= maximum:
        raise ValueError(f"{field} 必須係 {minimum} 至 {maximum} 字")
    return clean


@dataclass(frozen=True)
class InterviewQuestion:
    """One stable, ordered interview target supplied by the user."""

    id: str
    prompt: str
    expected_answer: str = ""
    required_concepts: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.id, str) or _QUESTION_ID.fullmatch(self.id) is None:
            raise ValueError(
                "interview question id 必須係 1 至 64 個 A-Z、a-z、0-9、.、_ 或 -"
            )
        object.__setattr__(
            self,
            "prompt",
            _normalized_text(self.prompt, field="question prompt", minimum=2, maximum=500),
        )
        object.__setattr__(
            self,
            "expected_answer",
            _normalized_text(
                self.expected_answer,
                field="expected_answer",
                minimum=0,
                maximum=1_000,
            ),
        )
        concepts = tuple(self.required_concepts)
        if len(concepts) > 20:
            raise ValueError("required_concepts 最多 20 項")
        normalized: list[str] = []
        seen: set[str] = set()
        for value in concepts:
            clean = _normalized_text(
                value,
                field="required concept",
                minimum=2,
                maximum=80,
            )
            key = clean.casefold()
            if key in seen:
                raise ValueError("required_concepts 唔可以重複")
            seen.add(key)
            normalized.append(clean)
        object.__setattr__(self, "required_concepts", tuple(normalized))
        semantic_bytes = sum(
            len(value.encode("utf-8"))
            for value in (self.id, self.prompt, self.expected_answer, *normalized)
        )
        if semantic_bytes > INTERVIEW_QUESTION_UTF8_BUDGET:
            raise ValueError(
                "question id + prompt + expected_answer + required_concepts "
                f"UTF-8 bytes 最多 {INTERVIEW_QUESTION_UTF8_BUDGET}"
            )

    @classmethod
    def from_dict(cls, value: object) -> "InterviewQuestion":
        if not isinstance(value, dict):
            raise ValueError("interview question 必須係 object")
        unknown = set(value) - _QUESTION_KEYS
        if unknown:
            raise ValueError(
                f"interview question 有未知參數：{', '.join(sorted(unknown))}"
            )
        missing = {"id", "prompt"} - set(value)
        if missing:
            raise ValueError(
                f"interview question 缺少參數：{', '.join(sorted(missing))}"
            )
        concepts = value.get("required_concepts", ())
        if not isinstance(concepts, (list, tuple)):
            raise ValueError("required_concepts 必須係 list")
        return cls(
            id=value["id"],
            prompt=value["prompt"],
            expected_answer=value.get("expected_answer", ""),
            required_concepts=tuple(concepts),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "prompt": self.prompt,
            "expected_answer": self.expected_answer,
            "required_concepts": list(self.required_concepts),
        }


@dataclass(frozen=True)
class InterviewConfig:
    """Strict optional interview plan; disabled by default."""

    enabled: bool = False
    questions: tuple[InterviewQuestion, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.enabled, bool):
            raise ValueError("interview enabled 必須係 boolean")
        questions = tuple(self.questions)
        if len(questions) > 20 or (self.enabled and not questions):
            raise ValueError("enabled interview questions 必須係 1 至 20 題")
        normalized: list[InterviewQuestion] = []
        seen: set[str] = set()
        for value in questions:
            question = (
                value if isinstance(value, InterviewQuestion) else InterviewQuestion.from_dict(value)
            )
            if question.id in seen:
                raise ValueError("interview question id 唔可以重複")
            seen.add(question.id)
            normalized.append(question)
        object.__setattr__(self, "questions", tuple(normalized))

    @classmethod
    def from_dict(cls, value: object | None) -> "InterviewConfig":
        if value is None:
            return cls()
        if not isinstance(value, dict):
            raise ValueError("interview 設定必須係 object")
        unknown = set(value) - _INTERVIEW_KEYS
        if unknown:
            raise ValueError(f"interview 有未知參數：{', '.join(sorted(unknown))}")
        questions = value.get("questions", ())
        if not isinstance(questions, (list, tuple)):
            raise ValueError("interview questions 必須係 list")
        return cls(
            enabled=value.get("enabled", False),
            questions=tuple(InterviewQuestion.from_dict(item) for item in questions),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "questions": [item.to_dict() for item in self.questions],
        }


__all__ = [
    "INTERVIEW_QUESTION_UTF8_BUDGET",
    "InterviewConfig",
    "InterviewQuestion",
]
