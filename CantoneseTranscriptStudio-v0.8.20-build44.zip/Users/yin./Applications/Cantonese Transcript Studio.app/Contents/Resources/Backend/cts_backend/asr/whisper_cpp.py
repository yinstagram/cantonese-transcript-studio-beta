"""whisper.cpp adapter with Metal and crash-safe chunk batches."""

from __future__ import annotations

import json
import hashlib
import os
import signal
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from .types import ASRCancelled, AudioChunk, TranscriptSegment


WHISPER_CPP_POLICY_VERSION = "2026-08-06.1"
WHISPER_LARGE_V3_FILENAME = "ggml-large-v3.bin"
WHISPER_LARGE_V2_FILENAME = "ggml-large-v2.bin"
# Backward-compatible public name retained for legacy callers/tests.
WHISPER_MODEL_FILENAME = WHISPER_LARGE_V2_FILENAME
Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]
DEFAULT_BATCH_TIMEOUT_SECONDS = 2 * 60 * 60.0
DEFAULT_NO_PROGRESS_TIMEOUT_SECONDS = 20 * 60.0
DEFAULT_MAXIMUM_LOG_BYTES = 32 * 1024 * 1024


class WhisperCPPError(RuntimeError):
    pass


class _BoundedProcessLog:
    def __init__(self, stream: Any, path: Path, maximum_bytes: int) -> None:
        self.stream = stream
        self.path = path
        self.maximum_bytes = max(0, int(maximum_bytes))
        self.limit_exceeded = threading.Event()
        self.last_output_at = time.monotonic()
        self._thread = threading.Thread(
            target=self._consume,
            name="cts-whisper-log",
            daemon=True,
        )

    def start(self) -> None:
        self._thread.start()

    def join(self, timeout: float = 3.0) -> None:
        self._thread.join(timeout=max(0.0, timeout))

    def _consume(self) -> None:
        written = 0
        try:
            with self.path.open("ab") as handle:
                while True:
                    block = self.stream.read(64 * 1024)
                    if not block:
                        break
                    self.last_output_at = time.monotonic()
                    remaining = self.maximum_bytes - written
                    if remaining <= 0:
                        self.limit_exceeded.set()
                        break
                    accepted = block[:remaining]
                    handle.write(accepted)
                    written += len(accepted)
                    if len(accepted) != len(block):
                        self.limit_exceeded.set()
                        break
                handle.flush()
                os.fsync(handle.fileno())
        finally:
            try:
                self.stream.close()
            except OSError:
                pass


def _trim_technical_log(path: Path, *, keep_bytes: int) -> None:
    """Atomically retain only the newest bounded technical log tail."""

    if not path.is_file() or path.stat().st_size <= keep_bytes:
        return
    with path.open("rb") as source:
        source.seek(-keep_bytes, os.SEEK_END)
        tail = source.read(keep_bytes)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(b"[older whisper log truncated]\n")
            handle.write(tail)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


def _group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def terminate_whisper_process_group(
    process: subprocess.Popen[Any], *, grace_seconds: float = 2.0
) -> None:
    """Bounded TERM -> KILL for the wrapper and every whisper helper."""

    group_id = process.pid
    started = time.monotonic()
    final_deadline = started + 2.9
    try:
        os.killpg(group_id, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        pass
    term_deadline = started + min(2.5, max(0.0, grace_seconds))
    while time.monotonic() < term_deadline:
        if process.poll() is not None and not _group_exists(group_id):
            break
        time.sleep(0.01)
    if _group_exists(group_id):
        try:
            os.killpg(group_id, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
    try:
        process.wait(timeout=max(0.01, final_deadline - time.monotonic()))
    except subprocess.TimeoutExpired:
        try:
            os.killpg(group_id, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass


def resolve_whisper_cli(explicit: str | Path | None = None) -> Path:
    candidates = [
        Path(explicit).expanduser() if explicit else None,
        Path(os.environ["CTS_WHISPER_CLI"]).expanduser()
        if os.environ.get("CTS_WHISPER_CLI")
        else None,
        Path(shutil.which("whisper-cli")) if shutil.which("whisper-cli") else None,
        Path("/opt/homebrew/bin/whisper-cli"),
        Path("/usr/local/bin/whisper-cli"),
    ]
    for candidate in candidates:
        if candidate and candidate.is_file() and os.access(candidate, os.X_OK):
            return candidate.resolve()
    raise WhisperCPPError("搵唔到 whisper-cli；請先安裝 whisper-cpp")


def build_whisper_command(
    *,
    cli_path: Path,
    model_file: Path,
    inputs: Sequence[Path],
    prompt: str = "",
    threads: int = 4,
    language: str = "zh",
) -> list[str]:
    if not inputs:
        raise ValueError("Whisper command 至少要一個輸入")
    command = [
        str(cli_path),
        "-m",
        str(model_file),
        "-l",
        language,
        "-t",
        str(max(1, int(threads))),
        "-ojf",
        "-np",
    ]
    cleaned_prompt = " ".join(prompt.split())[:1_000]
    if cleaned_prompt:
        command.extend(["--prompt", cleaned_prompt, "--carry-initial-prompt"])
    command.extend(str(path) for path in inputs)
    return command


def _offsets(segment: dict[str, Any]) -> tuple[int, int] | None:
    offsets = segment.get("offsets")
    if not isinstance(offsets, dict):
        return None
    start = offsets.get("from")
    end = offsets.get("to")
    if isinstance(start, bool) or isinstance(end, bool):
        return None
    if not isinstance(start, (int, float)) or not isinstance(end, (int, float)):
        return None
    start_ms = max(0, round(float(start)))
    end_ms = max(start_ms, round(float(end)))
    return start_ms, end_ms


def parse_whisper_json(path: Path, chunk: AudioChunk) -> TranscriptSegment:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise WhisperCPPError(f"Whisper JSON 無效：{path.name}") from exc
    transcription = value.get("transcription")
    if not isinstance(transcription, list):
        raise WhisperCPPError(f"Whisper JSON 缺少 transcription：{path.name}")

    core_start_ms = round(chunk.transcript_start * 1000)
    core_end_ms = round(chunk.transcript_end * 1000)
    chunk_start_ms = round(chunk.start * 1000)
    selected: list[dict[str, Any]] = []
    for raw in transcription:
        if not isinstance(raw, dict) or not isinstance(raw.get("text"), str):
            continue
        offset = _offsets(raw)
        if offset is None:
            continue
        local_start, local_end = offset
        absolute_start = chunk_start_ms + local_start
        absolute_end = chunk_start_ms + local_end
        midpoint = (absolute_start + absolute_end) / 2.0
        if core_start_ms <= midpoint < core_end_ms:
            selected.append(raw)
    text = "".join(str(raw.get("text", "")) for raw in selected).strip()
    result = value.get("result") if isinstance(value.get("result"), dict) else {}
    return TranscriptSegment(
        id=chunk.id,
        start=chunk.transcript_start,
        end=chunk.transcript_end,
        text=text,
        language="Cantonese",
        source="whisper",
        metadata={
            "chunk_index": chunk.index,
            "engine": "whisper.cpp",
            "language": result.get("language"),
            "raw_json": str(path),
            "raw_segment_count": len(transcription),
            "selected_segment_count": len(selected),
            "word_timestamps_reliable": False,
            "policy_version": WHISPER_CPP_POLICY_VERSION,
        },
    )


class WhisperCPPASR:
    policy_version = WHISPER_CPP_POLICY_VERSION

    def __init__(
        self,
        model_path: str | Path,
        *,
        context: str = "",
        output_dir: str | Path,
        cli_path: str | Path | None = None,
        batch_size: int = 8,
        threads: int | None = None,
        language: str | None = None,
        batch_timeout_seconds: float = DEFAULT_BATCH_TIMEOUT_SECONDS,
        no_progress_timeout_seconds: float = DEFAULT_NO_PROGRESS_TIMEOUT_SECONDS,
        maximum_log_bytes: int = DEFAULT_MAXIMUM_LOG_BYTES,
    ) -> None:
        root = Path(model_path)
        if root.is_dir():
            candidates = (
                root / WHISPER_LARGE_V3_FILENAME,
                root / WHISPER_LARGE_V2_FILENAME,
            )
            self.model_file = next(
                (candidate for candidate in candidates if candidate.is_file()),
                candidates[0],
            )
        else:
            self.model_file = root
        if not self.model_file.is_file():
            raise WhisperCPPError(f"Whisper 模型不存在：{self.model_file}")
        self.cli_path = resolve_whisper_cli(cli_path)
        self.context = context
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.input_dir = self.output_dir / "inputs"
        self.input_dir.mkdir(parents=True, exist_ok=True)
        if not 1 <= int(batch_size) <= 32:
            raise ValueError("Whisper batch_size 必須係 1 至 32")
        self.batch_size = int(batch_size)
        self.threads = int(threads or min(max(os.cpu_count() or 4, 2), 6))
        default_language = (
            "yue" if self.model_file.name == WHISPER_LARGE_V3_FILENAME else "zh"
        )
        self.language = language or default_language
        if self.language not in {"yue", "zh"}:
            raise ValueError("Whisper language 必須係 yue 或 zh")
        if not 0.05 <= float(batch_timeout_seconds) <= 24 * 60 * 60:
            raise ValueError("Whisper batch timeout 必須係 0.05 秒至 24 小時")
        if not 0.05 <= float(no_progress_timeout_seconds) <= 24 * 60 * 60:
            raise ValueError("Whisper no-progress timeout 必須係 0.05 秒至 24 小時")
        if not 4 * 1024 <= int(maximum_log_bytes) <= 256 * 1024 * 1024:
            raise ValueError("Whisper log limit 必須係 4 KiB 至 256 MiB")
        self.batch_timeout_seconds = float(batch_timeout_seconds)
        self.no_progress_timeout_seconds = float(no_progress_timeout_seconds)
        self.maximum_log_bytes = int(maximum_log_bytes)

    @staticmethod
    def _sidecar(staged: Path) -> Path:
        return Path(str(staged) + ".json")

    def _stage(self, chunk: AudioChunk) -> Path:
        digest = hashlib.sha256(chunk.id.encode("utf-8")).hexdigest()[:12]
        staged = self.input_dir / f"{chunk.index:05d}-{digest}.wav"
        if staged.is_file():
            return staged
        try:
            os.link(chunk.path, staged)
        except OSError:
            shutil.copy2(chunk.path, staged)
        return staged

    def _valid_existing(self, staged: Path, chunk: AudioChunk) -> TranscriptSegment | None:
        sidecar = self._sidecar(staged)
        if not sidecar.is_file():
            return None
        try:
            return parse_whisper_json(sidecar, chunk)
        except WhisperCPPError:
            # Do not destructively remove evidence.  The CLI overwrites the
            # sidecar on the next batch and the invalid file remains until then.
            return None

    def transcribe_chunks(
        self,
        chunks: Iterable[AudioChunk | dict[str, Any] | Any],
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> list[TranscriptSegment]:
        chunk_list = [AudioChunk.coerce(chunk) for chunk in chunks]
        if not chunk_list:
            return []
        staged = {chunk.id: self._stage(chunk) for chunk in chunk_list}
        completed: dict[str, TranscriptSegment] = {}
        missing: list[AudioChunk] = []
        for chunk in chunk_list:
            existing = self._valid_existing(staged[chunk.id], chunk)
            if existing is None:
                missing.append(chunk)
            else:
                completed[chunk.id] = existing
        total = len(chunk_list)
        if progress:
            progress(
                {
                    "progress": len(completed) / total,
                    "chunks_completed": len(completed),
                    "chunks_total": total,
                    "resumed": bool(completed),
                }
            )

        log_path = self.output_dir / "whisper-cli.log"
        for offset in range(0, len(missing), self.batch_size):
            if cancelled and cancelled():
                raise ASRCancelled("已取消 Whisper；已完成批次保留供續跑")
            batch = missing[offset : offset + self.batch_size]
            inputs = [staged[chunk.id] for chunk in batch]
            command = build_whisper_command(
                cli_path=self.cli_path,
                model_file=self.model_file,
                inputs=inputs,
                prompt=self.context,
                threads=self.threads,
                language=self.language,
            )
            _trim_technical_log(log_path, keep_bytes=self.maximum_log_bytes // 2)
            with log_path.open("ab") as technical_log:
                technical_log.write(
                    f"\n[batch {offset // self.batch_size + 1}] inputs={len(batch)}\n".encode("utf-8")
                )
                technical_log.flush()
            started = time.monotonic()
            wrapped_command = [
                sys.executable,
                str(Path(__file__).with_name("whisper_child.py")),
                "--parent-pid",
                str(os.getpid()),
                "--",
                *command,
            ]
            process = subprocess.Popen(
                wrapped_command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                close_fds=True,
                start_new_session=True,
                shell=False,
            )
            assert process.stdout is not None
            existing_log_bytes = log_path.stat().st_size if log_path.is_file() else 0
            capture = _BoundedProcessLog(
                process.stdout,
                log_path,
                max(0, self.maximum_log_bytes - existing_log_bytes),
            )
            capture.start()
            try:
                while process.poll() is None:
                    now = time.monotonic()
                    if cancelled and cancelled():
                        raise ASRCancelled("已取消 Whisper；已完成批次保留供續跑")
                    if capture.limit_exceeded.is_set():
                        raise WhisperCPPError("whisper-cli log limit exceeded")
                    if now - started >= self.batch_timeout_seconds:
                        raise WhisperCPPError("whisper-cli batch deadline exceeded")
                    if now - capture.last_output_at >= self.no_progress_timeout_seconds:
                        raise WhisperCPPError("whisper-cli no-progress deadline exceeded")
                    time.sleep(0.05)
            except BaseException:
                terminate_whisper_process_group(process)
                capture.join()
                raise
            capture.join()
            if capture.limit_exceeded.is_set():
                terminate_whisper_process_group(process)
                raise WhisperCPPError("whisper-cli log limit exceeded")
            if process.returncode != 0:
                raise WhisperCPPError(
                    f"whisper-cli batch 失敗（exit {process.returncode}）；詳情見 {log_path}"
                )

            for chunk in batch:
                sidecar = self._sidecar(staged[chunk.id])
                segment = parse_whisper_json(sidecar, chunk)
                segment.metadata["batch_elapsed_seconds"] = round(time.monotonic() - started, 3)
                completed[chunk.id] = segment
            if progress:
                progress(
                    {
                        "progress": len(completed) / total,
                        "chunks_completed": len(completed),
                        "chunks_total": total,
                    }
                )
        return [completed[chunk.id] for chunk in chunk_list]


__all__ = [
    "WHISPER_CPP_POLICY_VERSION",
    "WHISPER_LARGE_V2_FILENAME",
    "WHISPER_LARGE_V3_FILENAME",
    "WHISPER_MODEL_FILENAME",
    "WhisperCPPASR",
    "WhisperCPPError",
    "build_whisper_command",
    "parse_whisper_json",
    "resolve_whisper_cli",
    "terminate_whisper_process_group",
]
