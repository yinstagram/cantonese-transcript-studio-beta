from __future__ import annotations

import re
import unicodedata
from collections import Counter
from typing import Any, Iterable

from rapidfuzz.distance import Levenshtein

from ..normalization import HongKongNormalizer
from .models import TimedSegment, TimedTranscript


_ENGLISH_TOKEN_RE = re.compile(
    r"(?<![A-Za-z0-9])[A-Za-z][A-Za-z0-9]*(?:[-'’][A-Za-z0-9]+)*(?![A-Za-z0-9])"
)
CANTONESE_COLLOQUIAL_FORMS = (
    "係",
    "喺",
    "嘅",
    "咗",
    "冇",
    "佢",
    "哋",
    "啲",
    "嚟",
    "嗰",
    "咁",
    "唔",
    "畀",
    "睇",
    "而家",
)


def _round_rate(value: float) -> float:
    return round(value, 6)


def comparison_text(text: str) -> str:
    output: list[str] = []
    for character in unicodedata.normalize("NFKC", text).casefold():
        category = unicodedata.category(character)
        if character.isspace() or category.startswith(("P", "S", "Z", "C")):
            continue
        output.append(character)
    return "".join(output)


def normalized_text(text: str, normalizer: HongKongNormalizer) -> str:
    return comparison_text(normalizer.normalize(text))


def edit_metrics(reference: str, hypothesis: str, *, rate_name: str = "cer") -> dict[str, Any]:
    operations = Levenshtein.editops(reference, hypothesis)
    substitutions = sum(operation.tag == "replace" for operation in operations)
    insertions = sum(operation.tag == "insert" for operation in operations)
    deletions = sum(operation.tag == "delete" for operation in operations)
    distance = len(operations)
    denominator = len(reference) if rate_name == "cer" else max(len(reference), len(hypothesis))
    if denominator:
        rate = distance / denominator
    else:
        rate = 0.0 if not hypothesis else float(distance)
    similarity_denominator = max(len(reference), len(hypothesis), 1)
    return {
        rate_name: _round_rate(rate),
        "similarity": _round_rate(1.0 - distance / similarity_denominator),
        "distance": distance,
        "substitutions": substitutions,
        "insertions": insertions,
        "deletions": deletions,
        "reference_characters": len(reference),
        "hypothesis_characters": len(hypothesis),
    }


def system_hei_counts(text: str) -> dict[str, int]:
    normalized = unicodedata.normalize("NFKC", text)
    return {"系": normalized.count("系"), "係": normalized.count("係")}


def system_hei_confusion(reference: str, hypothesis: str) -> dict[str, int]:
    left = comparison_text(reference)
    right = comparison_text(hypothesis)
    missed_cantonese_copula = 0
    overcorrected_system_character = 0
    for operation in Levenshtein.editops(left, right):
        if operation.tag != "replace":
            continue
        reference_character = left[operation.src_pos]
        hypothesis_character = right[operation.dest_pos]
        if reference_character == "係" and hypothesis_character == "系":
            missed_cantonese_copula += 1
        elif reference_character == "系" and hypothesis_character == "係":
            overcorrected_system_character += 1
    return {
        "reference_係_hypothesis_系": missed_cantonese_copula,
        "reference_系_hypothesis_係": overcorrected_system_character,
    }


def english_token_metrics(reference: str, hypothesis: str) -> dict[str, Any]:
    expected = [token.casefold() for token in _ENGLISH_TOKEN_RE.findall(reference)]
    observed = [token.casefold() for token in _ENGLISH_TOKEN_RE.findall(hypothesis)]
    expected_counts = Counter(expected)
    observed_counts = Counter(observed)
    matched = sum((expected_counts & observed_counts).values())
    precision = matched / len(observed) if observed else (1.0 if not expected else 0.0)
    recall = matched / len(expected) if expected else (1.0 if not observed else 0.0)
    f1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "reference_tokens": len(expected),
        "hypothesis_tokens": len(observed),
        "matched_tokens": matched,
        "precision": _round_rate(precision),
        "recall": _round_rate(recall),
        "f1": _round_rate(f1),
        "sequence_exact": expected == observed,
    }


def _entity_pattern(entity: str) -> re.Pattern[str]:
    normalized = " ".join(unicodedata.normalize("NFKC", entity).casefold().split())
    escaped = re.escape(normalized).replace(r"\ ", r"\s+")
    prefix = r"(?<![a-z0-9])" if normalized and normalized[0].isascii() else ""
    suffix = r"(?![a-z0-9])" if normalized and normalized[-1].isascii() else ""
    return re.compile(prefix + escaped + suffix)


def entity_occurrences(text: str, entities: Iterable[str]) -> dict[str, int]:
    normalized = " ".join(unicodedata.normalize("NFKC", text).casefold().split())
    return {entity: len(_entity_pattern(entity).findall(normalized)) for entity in entities}


def entity_accuracy(reference: str, hypothesis: str, entities: Iterable[str]) -> dict[str, Any]:
    reference_counts = entity_occurrences(reference, entities)
    hypothesis_counts = entity_occurrences(hypothesis, entities)
    expected = {entity: count for entity, count in reference_counts.items() if count}
    matched = {
        entity: min(count, hypothesis_counts[entity])
        for entity, count in expected.items()
    }
    expected_count = sum(expected.values())
    matched_count = sum(matched.values())
    return {
        "expected_occurrences": expected_count,
        "matched_occurrences": matched_count,
        "recall": _round_rate(matched_count / expected_count) if expected_count else None,
        "all_expected_matched": matched_count == expected_count if expected_count else None,
        "per_entity": {
            entity: {
                "expected": count,
                "matched": matched[entity],
                "exact": matched[entity] == count,
            }
            for entity, count in expected.items()
        },
    }


def observed_cantonese_forms(
    text: str,
    forms: Iterable[str] = CANTONESE_COLLOQUIAL_FORMS,
) -> dict[str, Any]:
    """Count observed colloquial forms without implying they are correct.

    With no human reference, these counts measure preservation signals only;
    they are deliberately not named recall, accuracy, CER, or WER.
    """

    normalized = unicodedata.normalize("NFKC", text)
    counts = {form: normalized.count(form) for form in forms}
    return {
        "observed_occurrences": sum(counts.values()),
        "unique_forms_observed": sum(count > 0 for count in counts.values()),
        "per_form": counts,
        "accuracy_claim": False,
    }


def coverage_repetition_metrics(
    transcript: TimedTranscript,
    *,
    audio_duration_ms: int,
    normalizer: HongKongNormalizer,
) -> dict[str, Any]:
    """Measure timestamp coverage and repeated segment evidence.

    Intervals are clipped to the declared source duration.  Repetition is
    measured after HK normalization and punctuation-insensitive projection,
    but no transcript text is returned in the metrics.
    """

    if audio_duration_ms <= 0:
        raise ValueError("audio_duration_ms must be positive")
    intervals: list[tuple[int, int]] = []
    empty_segments = 0
    zero_duration_segments = 0
    keys: list[str] = []
    for segment in transcript.segments:
        start = min(max(segment.start_ms, 0), audio_duration_ms)
        end = min(max(segment.end_ms, start), audio_duration_ms)
        if end == start:
            zero_duration_segments += 1
        else:
            intervals.append((start, end))
        key = normalized_text(segment.text, normalizer)
        if not key:
            empty_segments += 1
        keys.append(key)

    merged: list[list[int]] = []
    overlap_ms = 0
    for start, end in sorted(intervals):
        if not merged or start > merged[-1][1]:
            merged.append([start, end])
            continue
        overlap_ms += max(0, min(end, merged[-1][1]) - start)
        merged[-1][1] = max(merged[-1][1], end)
    covered_ms = sum(end - start for start, end in merged)
    leading_uncovered_ms = merged[0][0] if merged else audio_duration_ms
    trailing_uncovered_ms = audio_duration_ms - merged[-1][1] if merged else 0
    internal_gap_ms = sum(
        max(0, current[0] - previous[1])
        for previous, current in zip(merged, merged[1:])
    )

    nonempty_keys = [key for key in keys if key]
    counts = Counter(nonempty_keys)
    repeated_instances = sum(max(0, count - 1) for count in counts.values())
    adjacent_duplicates = sum(
        bool(left) and left == right for left, right in zip(keys, keys[1:])
    )
    denominator = max(len(nonempty_keys), 1)
    return {
        "segment_count": len(transcript.segments),
        "nonempty_segment_count": len(nonempty_keys),
        "empty_segment_count": empty_segments,
        "zero_duration_segment_count": zero_duration_segments,
        "timestamp_covered_ms": covered_ms,
        "timestamp_coverage_rate": _round_rate(covered_ms / audio_duration_ms),
        "leading_uncovered_ms": leading_uncovered_ms,
        "internal_gap_ms": internal_gap_ms,
        "trailing_uncovered_ms": trailing_uncovered_ms,
        "overlap_ms": overlap_ms,
        "repeated_segment_instances": repeated_instances,
        "repeated_segment_rate": _round_rate(repeated_instances / denominator),
        "adjacent_duplicate_segments": adjacent_duplicates,
        "adjacent_duplicate_rate": _round_rate(
            adjacent_duplicates / max(len(keys) - 1, 1)
        ),
    }


def metric_pair(
    reference: str,
    hypothesis: str,
    normalizer: HongKongNormalizer,
    *,
    rate_name: str,
) -> dict[str, Any]:
    return {
        "raw": edit_metrics(
            comparison_text(reference),
            comparison_text(hypothesis),
            rate_name=rate_name,
        ),
        "hk_normalized": edit_metrics(
            normalized_text(reference, normalizer),
            normalized_text(hypothesis, normalizer),
            rate_name=rate_name,
        ),
    }


def _overlaps(left: TimedSegment, right: TimedSegment) -> bool:
    return left.end_ms > right.start_ms and right.end_ms > left.start_ms


def comparison_windows(
    left: TimedTranscript,
    right: TimedTranscript,
    normalizer: HongKongNormalizer,
    *,
    rate_name: str,
) -> list[dict[str, Any]]:
    left_count = len(left.segments)
    total = left_count + len(right.segments)
    parents = list(range(total))

    def find(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def union(first: int, second: int) -> None:
        root_first = find(first)
        root_second = find(second)
        if root_first != root_second:
            parents[root_second] = root_first

    for left_index, left_segment in enumerate(left.segments):
        for right_index, right_segment in enumerate(right.segments):
            if _overlaps(left_segment, right_segment):
                union(left_index, left_count + right_index)

    groups: dict[int, list[tuple[str, TimedSegment]]] = {}
    for index, segment in enumerate(left.segments):
        groups.setdefault(find(index), []).append(("left", segment))
    for index, segment in enumerate(right.segments):
        groups.setdefault(find(left_count + index), []).append(("right", segment))

    output: list[dict[str, Any]] = []
    ordered_groups = sorted(
        groups.values(),
        key=lambda group: min((segment.start_ms, segment.end_ms) for _, segment in group),
    )
    for index, group in enumerate(ordered_groups, start=1):
        left_segments = sorted(
            (segment for side, segment in group if side == "left"),
            key=lambda segment: (segment.start_ms, segment.end_ms),
        )
        right_segments = sorted(
            (segment for side, segment in group if side == "right"),
            key=lambda segment: (segment.start_ms, segment.end_ms),
        )
        left_text = " ".join(segment.text for segment in left_segments)
        right_text = " ".join(segment.text for segment in right_segments)
        metrics = metric_pair(
            left_text,
            right_text,
            normalizer,
            rate_name=rate_name,
        )
        raw_distance = metrics["raw"]["distance"]
        hk_distance = metrics["hk_normalized"]["distance"]
        if hk_distance == 0:
            classification = "agreement" if raw_distance == 0 else "orthography_only"
        else:
            classification = "disagreement"
        output.append(
            {
                "index": index,
                "start_ms": min(segment.start_ms for _, segment in group),
                "end_ms": max(segment.end_ms for _, segment in group),
                "left_segment_count": len(left_segments),
                "right_segment_count": len(right_segments),
                "classification": classification,
                **metrics,
            }
        )
    return output


__all__ = [
    "CANTONESE_COLLOQUIAL_FORMS",
    "comparison_text",
    "comparison_windows",
    "coverage_repetition_metrics",
    "edit_metrics",
    "english_token_metrics",
    "entity_accuracy",
    "entity_occurrences",
    "metric_pair",
    "normalized_text",
    "observed_cantonese_forms",
    "system_hei_confusion",
    "system_hei_counts",
]
