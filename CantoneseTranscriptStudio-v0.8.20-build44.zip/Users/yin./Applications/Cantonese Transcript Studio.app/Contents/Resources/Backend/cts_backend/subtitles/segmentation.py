"""Deterministic, timestamp-aware subtitle segmentation.

The segmenter is deliberately a *boundary selector*, not a text generator.  It
can only choose offsets in the supplied transcript, so local semantic models
may suggest boundary IDs but can never rewrite, insert, delete, or reorder
content.

The public function accepts the project's ``WordTimestamp`` and
``CharacterTimestamp`` dataclasses as well as structurally equivalent
mappings.  This keeps the core independent from a particular aligner while
retaining strict validation at the trust boundary.
"""

from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import asdict, dataclass
from typing import Any, Iterable, Literal, Mapping, Sequence


SEGMENTATION_POLICY_VERSION = "timestamp-semantic-dp-v4"
MIN_MAX_CHARACTERS = 6
MAX_MAX_CHARACTERS = 60
DEFAULT_MAX_CHARACTERS = 18
DEFAULT_MINIMUM_READABLE_DURATION_MS = 500
SegmentationMode = Literal["precise", "semantic"]

_STRONG_PUNCTUATION = frozenset("。！？!?；;…\n\r")
_SOFT_PUNCTUATION = frozenset("，,、：:")
_OPENING_PUNCTUATION = frozenset("([{（［｛「『《〈【〔〖〘〚‘“")
_CLOSING_PUNCTUATION = frozenset(
    ")]},.!?;:%）］｝，。！？；：、」』》〉】〕〗〙〛’”"
)
_CANTONESE_BOUNDARY_PARTICLES = frozenset(
    "呀啊吖喇啦囉咯啫咩嘛噃喎㗎嘞添先呢㖭"
)
# Short, high-confidence lexical units that must not be broken merely because
# a forced aligner reports a pause between their characters.  This is a safety
# gate, not a language rewrite: the source text remains byte-for-byte intact,
# and the list is intentionally limited to common connective/function phrases.
_LEXICAL_GLUE_PHRASES = (
    "之後",
    "之前",
    "然後",
    "因為",
    "所以",
    "如果",
    "但係",
    "即係",
    "其實",
    "同埋",
    "仲有",
    "或者",
    "不過",
    "而且",
    "另外",
    "例如",
    "嗰個",
    "呢個",
    "邊個",
    "乜嘢",
    "點樣",
    "而家",
    "嗰度",
    "呢度",
    "唔係",
    "唔會",
)
_URL_PATTERN = re.compile(r"(?i)(?:https?://|www\.)[^\s<>{}\[\]]+")
_EMAIL_PATTERN = re.compile(
    r"(?i)(?<![\w.+-])[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@"
    r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?:\.[a-z]{2,})+"
)
_SOCIAL_PATTERN = re.compile(r"(?<!\w)[#@][\w.\-]+", re.UNICODE)
_TRAILING_URL_PUNCTUATION = frozenset(".,!?;:，。！？；：、」』》〉】〕〗〙〛’”")
_ABSOLUTE_FLASH_DURATION_MS = 200


@dataclass(frozen=True)
class SubtitleSegmentationPolicy:
    """User-facing segmentation policy.

    ``minimum_readable_duration_ms`` is a readability threshold, not a hard
    timestamp clamp.  A genuinely short, punctuated utterance can remain on
    its own, while fragments are penalised and then merged with an adjacent
    cue whenever that can be done without exceeding ``max_characters``.
    """

    max_characters: int = DEFAULT_MAX_CHARACTERS
    mode: SegmentationMode = "precise"
    target_duration_ms: int = 3_200
    pause_boundary_ms: int = 320
    minimum_readable_duration_ms: int = DEFAULT_MINIMUM_READABLE_DURATION_MS

    def __post_init__(self) -> None:
        if (
            isinstance(self.max_characters, bool)
            or not isinstance(self.max_characters, int)
            or not MIN_MAX_CHARACTERS
            <= self.max_characters
            <= MAX_MAX_CHARACTERS
        ):
            raise ValueError("max_characters 必須係 6 至 60 嘅整數")
        if self.mode not in {"precise", "semantic"}:
            raise ValueError("mode 必須係 precise 或 semantic")
        if (
            isinstance(self.target_duration_ms, bool)
            or not isinstance(self.target_duration_ms, int)
            or not 500 <= self.target_duration_ms <= 20_000
        ):
            raise ValueError("target_duration_ms 必須係 500 至 20000")
        if (
            isinstance(self.pause_boundary_ms, bool)
            or not isinstance(self.pause_boundary_ms, int)
            or not 80 <= self.pause_boundary_ms <= 5_000
        ):
            raise ValueError("pause_boundary_ms 必須係 80 至 5000")
        if (
            isinstance(self.minimum_readable_duration_ms, bool)
            or not isinstance(self.minimum_readable_duration_ms, int)
            or not 250 <= self.minimum_readable_duration_ms <= 2_000
        ):
            raise ValueError("minimum_readable_duration_ms 必須係 250 至 2000")


@dataclass(frozen=True)
class SegmentedSubtitleCue:
    """One exact, contiguous source-text slice."""

    index: int
    start_ms: int
    end_ms: int
    text: str
    source_start: int
    source_end: int
    character_count: int
    boundary_reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class OverLimitCueAudit:
    """Why one cue was necessarily longer than the user limit."""

    cue_index: int
    source_start: int
    source_end: int
    character_count: int
    reason: str


@dataclass(frozen=True)
class SubtitleSegmentationAudit:
    """Non-generative segmentation provenance and safety exceptions."""

    policy_version: str
    mode: str
    max_characters: int
    target_duration_ms: int
    pause_boundary_ms: int
    minimum_readable_duration_ms: int
    protected_span_count: int
    requested_semantic_boundary_ids: tuple[int, ...]
    applied_semantic_boundary_ids: tuple[int, ...]
    ignored_semantic_boundary_ids: tuple[int, ...]
    timing_fallback_character_count: int
    readability_merge_count: int
    remaining_short_cue_count: int
    over_limit_cues: tuple[OverLimitCueAudit, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SubtitleSegmentationResult:
    """Cue output plus the immutable source transcript and audit."""

    text: str
    cues: tuple[SegmentedSubtitleCue, ...]
    audit: SubtitleSegmentationAudit

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class _TimestampSpan:
    text: str
    start_ms: int
    end_ms: int
    source_start: int
    source_end: int


@dataclass(frozen=True)
class _CharacterTime:
    text: str
    start_ms: int
    end_ms: int
    source_index: int


@dataclass(frozen=True)
class _Grapheme:
    text: str
    source_start: int
    source_end: int


@dataclass(frozen=True)
class _TimedGrapheme:
    text: str
    source_start: int
    source_end: int
    start_ms: int
    end_ms: int


@dataclass(frozen=True)
class _ProtectedSpan:
    start: int
    end: int
    kind: str


def _member(value: Any, name: str) -> Any:
    if isinstance(value, Mapping):
        if name not in value:
            raise ValueError(f"timestamp 缺少 {name}")
        return value[name]
    try:
        return getattr(value, name)
    except AttributeError as exc:
        raise ValueError(f"timestamp 缺少 {name}") from exc


def _integer(value: Any, name: str, *, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"timestamp {name} 無效")
    return value


def _coerce_words(values: Sequence[Any]) -> tuple[_TimestampSpan, ...]:
    output: list[_TimestampSpan] = []
    for value in values:
        text = _member(value, "text")
        if not isinstance(text, str) or not text:
            raise ValueError("word timestamp text 無效")
        start_ms = _integer(_member(value, "start_ms"), "start_ms")
        end_ms = _integer(_member(value, "end_ms"), "end_ms")
        source_start = _integer(_member(value, "source_start"), "source_start")
        source_end = _integer(_member(value, "source_end"), "source_end")
        if end_ms < start_ms or source_end <= source_start:
            raise ValueError("word timestamp range 無效")
        output.append(
            _TimestampSpan(text, start_ms, end_ms, source_start, source_end)
        )
    output.sort(key=lambda item: (item.source_start, item.source_end, item.start_ms))
    previous_end = -1
    for item in output:
        if item.source_start < previous_end:
            raise ValueError("word timestamp source ranges 重疊")
        previous_end = item.source_end
    return tuple(output)


def _coerce_characters(values: Sequence[Any]) -> tuple[_CharacterTime, ...]:
    output: list[_CharacterTime] = []
    for value in values:
        text = _member(value, "text")
        if not isinstance(text, str) or len(text) != 1:
            raise ValueError("character timestamp 必須對應一個 Unicode code point")
        start_ms = _integer(_member(value, "start_ms"), "start_ms")
        end_ms = _integer(_member(value, "end_ms"), "end_ms")
        source_index = _integer(_member(value, "source_index"), "source_index")
        if end_ms < start_ms:
            raise ValueError("character timestamp range 無效")
        output.append(_CharacterTime(text, start_ms, end_ms, source_index))
    output.sort(key=lambda item: item.source_index)
    if len({item.source_index for item in output}) != len(output):
        raise ValueError("character timestamp source_index 重複")
    return tuple(output)


def _is_variation_selector(character: str) -> bool:
    value = ord(character)
    return 0xFE00 <= value <= 0xFE0F or 0xE0100 <= value <= 0xE01EF


def _is_emoji_modifier(character: str) -> bool:
    return 0x1F3FB <= ord(character) <= 0x1F3FF


def _is_regional_indicator(character: str) -> bool:
    return 0x1F1E6 <= ord(character) <= 0x1F1FF


def _is_extend(character: str) -> bool:
    value = ord(character)
    return (
        bool(unicodedata.combining(character))
        or unicodedata.category(character) in {"Mn", "Mc", "Me"}
        or _is_variation_selector(character)
        or _is_emoji_modifier(character)
        or value == 0x20E3
        or 0xE0020 <= value <= 0xE007F
    )


def _is_virama(character: str) -> bool:
    try:
        return "VIRAMA" in unicodedata.name(character)
    except ValueError:
        return False


def _graphemes(text: str, *, source_offset: int) -> tuple[_Grapheme, ...]:
    """Return conservative extended grapheme clusters without a dependency.

    It covers combining sequences, emoji modifiers, flags, keycaps, ZWJ emoji,
    CRLF, and virama conjuncts.  Conservatively keeping a sequence together is
    preferable to ever cutting a visible user-perceived character.
    """

    output: list[_Grapheme] = []
    index = 0
    while index < len(text):
        start = index
        index += 1
        if text[start] == "\r" and index < len(text) and text[index] == "\n":
            index += 1
        if _is_regional_indicator(text[start]) and index < len(text):
            if _is_regional_indicator(text[index]):
                index += 1
        while index < len(text):
            current = text[index]
            previous = text[index - 1]
            if _is_extend(current):
                index += 1
                continue
            if previous == "\u200d":
                index += 1
                continue
            if current == "\u200d":
                index += 1
                continue
            if _is_virama(previous):
                index += 1
                continue
            break
        output.append(
            _Grapheme(
                text=text[start:index],
                source_start=source_offset + start,
                source_end=source_offset + index,
            )
        )
    return tuple(output)


def _is_latin_or_number(character: str) -> bool:
    if character.isdigit():
        return True
    try:
        return "LATIN" in unicodedata.name(character) and character.isalpha()
    except ValueError:
        return False


def _latin_number_spans(text: str, *, source_offset: int) -> Iterable[_ProtectedSpan]:
    connectors = frozenset("._+:/#@-'’")
    index = 0
    while index < len(text):
        if not _is_latin_or_number(text[index]):
            index += 1
            continue
        start = index
        saw_digit = text[index].isdigit()
        index += 1
        while index < len(text):
            character = text[index]
            if _is_latin_or_number(character) or _is_extend(character):
                saw_digit = saw_digit or character.isdigit()
                index += 1
                continue
            if (
                character in connectors
                and index + 1 < len(text)
                and _is_latin_or_number(text[index + 1])
            ):
                index += 1
                continue
            if saw_digit and character in "%％℃°":
                index += 1
            break
        yield _ProtectedSpan(
            source_offset + start, source_offset + index, "latin_or_number_token"
        )


def _regex_spans(text: str, *, source_offset: int) -> Iterable[_ProtectedSpan]:
    for pattern, kind in (
        (_URL_PATTERN, "url"),
        (_EMAIL_PATTERN, "email"),
        (_SOCIAL_PATTERN, "hashtag_or_mention"),
    ):
        for match in pattern.finditer(text):
            end = match.end()
            if kind == "url":
                while end > match.start() and text[end - 1] in _TRAILING_URL_PUNCTUATION:
                    end -= 1
            if end > match.start():
                yield _ProtectedSpan(
                    source_offset + match.start(), source_offset + end, kind
                )


def _vocabulary_spans(
    text: str, vocabulary: Sequence[str], *, source_offset: int
) -> Iterable[_ProtectedSpan]:
    phrases: set[str] = set()
    for phrase in vocabulary:
        if not isinstance(phrase, str) or not phrase:
            raise ValueError("vocabulary phrase 必須係非空文字")
        if len(phrase) > 10_000:
            raise ValueError("vocabulary phrase 過長")
        phrases.add(phrase)
    for phrase in sorted(phrases, key=lambda item: (-len(item), item)):
        cursor = 0
        while True:
            start = text.find(phrase, cursor)
            if start < 0:
                break
            yield _ProtectedSpan(
                source_offset + start,
                source_offset + start + len(phrase),
                "vocabulary",
            )
            cursor = start + 1


def _protected_spans(
    text: str, vocabulary: Sequence[str], *, source_offset: int
) -> tuple[_ProtectedSpan, ...]:
    spans = [
        *_regex_spans(text, source_offset=source_offset),
        *_latin_number_spans(text, source_offset=source_offset),
        *_vocabulary_spans(
            text, _LEXICAL_GLUE_PHRASES, source_offset=source_offset
        ),
        *_vocabulary_spans(text, vocabulary, source_offset=source_offset),
    ]
    unique = {(span.start, span.end, span.kind): span for span in spans}
    return tuple(
        sorted(unique.values(), key=lambda item: (item.start, item.end, item.kind))
    )


def _validate_timestamp_content(
    text: str,
    words: Sequence[_TimestampSpan],
    characters: Sequence[_CharacterTime],
    *,
    source_offset: int,
) -> None:
    source_end = source_offset + len(text)
    for word in words:
        if word.source_end <= source_offset or word.source_start >= source_end:
            continue
        if word.source_start < source_offset or word.source_end > source_end:
            raise ValueError("word timestamp 只可完整包含或完全位於 transcript 範圍外")
        local_start = word.source_start - source_offset
        local_end = word.source_end - source_offset
        if text[local_start:local_end] != word.text:
            raise ValueError("word timestamp 改變咗 transcript content")
    for character in characters:
        if not source_offset <= character.source_index < source_end:
            continue
        if text[character.source_index - source_offset] != character.text:
            raise ValueError("character timestamp 改變咗 transcript content")


def _timed_graphemes(
    graphemes: Sequence[_Grapheme],
    words: Sequence[_TimestampSpan],
    characters: Sequence[_CharacterTime],
) -> tuple[tuple[_TimedGrapheme, ...], int]:
    if not graphemes:
        return (), 0
    char_by_index = {item.source_index: item for item in characters}
    starts: list[int | None] = [None] * len(graphemes)
    ends: list[int | None] = [None] * len(graphemes)

    # Word timing provides a proportional baseline, including for a protected
    # Latin token.  Character timing, when available, overrides this baseline.
    for word in words:
        width = word.source_end - word.source_start
        if width <= 0:
            continue
        for index, grapheme in enumerate(graphemes):
            overlap_start = max(grapheme.source_start, word.source_start)
            overlap_end = min(grapheme.source_end, word.source_end)
            if overlap_end <= overlap_start:
                continue
            duration = word.end_ms - word.start_ms
            starts[index] = word.start_ms + round(
                duration * (overlap_start - word.source_start) / width
            )
            ends[index] = word.start_ms + round(
                duration * (overlap_end - word.source_start) / width
            )

    for index, grapheme in enumerate(graphemes):
        matched = [
            char_by_index[source_index]
            for source_index in range(grapheme.source_start, grapheme.source_end)
            if source_index in char_by_index
        ]
        if matched:
            starts[index] = min(item.start_ms for item in matched)
            ends[index] = max(item.end_ms for item in matched)

    known_starts = [value for value in starts if value is not None]
    known_ends = [value for value in ends if value is not None]
    if not known_starts or not known_ends:
        # Untimed text remains deterministic and monotonic.  The audit makes
        # this synthetic fallback explicit to downstream callers.
        return (
            tuple(
                _TimedGrapheme(
                    item.text,
                    item.source_start,
                    item.source_end,
                    index * 100,
                    (index + 1) * 100,
                )
                for index, item in enumerate(graphemes)
            ),
            len(graphemes),
        )

    unresolved = sum(value is None for value in starts)
    index = 0
    while index < len(graphemes):
        if starts[index] is not None and ends[index] is not None:
            index += 1
            continue
        run_start = index
        while index < len(graphemes) and (
            starts[index] is None or ends[index] is None
        ):
            index += 1
        run_end = index
        left = (
            int(ends[run_start - 1])
            if run_start > 0 and ends[run_start - 1] is not None
            else min(known_starts)
        )
        right = (
            int(starts[run_end])
            if run_end < len(graphemes) and starts[run_end] is not None
            else max(known_ends)
        )
        right = max(left, right)
        count = run_end - run_start
        for offset, item_index in enumerate(range(run_start, run_end)):
            starts[item_index] = left + round((right - left) * offset / count)
            ends[item_index] = left + round((right - left) * (offset + 1) / count)

    output: list[_TimedGrapheme] = []
    cursor = min(known_starts)
    for grapheme, raw_start, raw_end in zip(graphemes, starts, ends):
        assert raw_start is not None and raw_end is not None
        start_ms = max(cursor, raw_start)
        end_ms = max(start_ms, raw_end)
        output.append(
            _TimedGrapheme(
                grapheme.text,
                grapheme.source_start,
                grapheme.source_end,
                start_ms,
                end_ms,
            )
        )
        cursor = end_ms
    return tuple(output), unresolved


def _visible_count(grapheme: _Grapheme | _TimedGrapheme) -> int:
    return 0 if grapheme.text.isspace() else 1


def _is_non_acoustic_boundary_grapheme(grapheme: _TimedGrapheme) -> bool:
    """Keep punctuation in text without treating its gap fill as speech."""

    return bool(grapheme.text) and all(
        character.isspace() or unicodedata.category(character).startswith("P")
        for character in grapheme.text
    )


def _acoustic_time_bounds(
    graphemes: Sequence[_TimedGrapheme],
    start: int,
    end: int,
    *,
    maximum_non_acoustic_edge_ms: int,
) -> tuple[int, int]:
    """Trim only long gap-fill tails around otherwise acoustic cue text."""

    acoustic = [
        grapheme
        for grapheme in graphemes[start:end]
        if not _is_non_acoustic_boundary_grapheme(grapheme)
    ]
    if acoustic:
        raw_start_ms = graphemes[start].start_ms
        raw_end_ms = graphemes[end - 1].end_ms
        acoustic_start_ms = acoustic[0].start_ms
        acoustic_end_ms = acoustic[-1].end_ms
        start_ms = (
            acoustic_start_ms
            if acoustic_start_ms - raw_start_ms > maximum_non_acoustic_edge_ms
            else raw_start_ms
        )
        end_ms = (
            acoustic_end_ms
            if raw_end_ms - acoustic_end_ms > maximum_non_acoustic_edge_ms
            else raw_end_ms
        )
        return start_ms, end_ms
    return graphemes[start].start_ms, graphemes[end - 1].end_ms


def _next_acoustic_start_ms(
    graphemes: Sequence[_TimedGrapheme], start: int
) -> int | None:
    for grapheme in graphemes[start:]:
        if not _is_non_acoustic_boundary_grapheme(grapheme):
            return grapheme.start_ms
    return None


def _previous_visible(graphemes: Sequence[_TimedGrapheme], boundary: int) -> str:
    index = boundary - 1
    while index >= 0 and graphemes[index].text.isspace():
        index -= 1
    return graphemes[index].text[-1] if index >= 0 else ""


def _next_visible(graphemes: Sequence[_TimedGrapheme], boundary: int) -> str:
    index = boundary
    while index < len(graphemes) and graphemes[index].text.isspace():
        index += 1
    return graphemes[index].text[0] if index < len(graphemes) else ""


def _pause_at(graphemes: Sequence[_TimedGrapheme], boundary: int) -> int:
    left = boundary - 1
    while left >= 0 and _is_non_acoustic_boundary_grapheme(graphemes[left]):
        left -= 1
    right = boundary
    while right < len(graphemes) and _is_non_acoustic_boundary_grapheme(
        graphemes[right]
    ):
        right += 1
    if left < 0 or right >= len(graphemes):
        return 0
    return max(0, graphemes[right].start_ms - graphemes[left].end_ms)


def _boundary_features(
    graphemes: Sequence[_TimedGrapheme],
    boundary: int,
    *,
    source_boundary: int,
    word_boundaries: frozenset[int],
    semantic_boundaries: frozenset[int],
    policy: SubtitleSegmentationPolicy,
) -> tuple[float, str]:
    if boundary == len(graphemes):
        return 0.0, "end_of_transcript"
    previous = _previous_visible(graphemes, boundary)
    following = _next_visible(graphemes, boundary)
    pause = _pause_at(graphemes, boundary)

    score = 4.0
    reason = "length_balance"
    if previous in _STRONG_PUNCTUATION:
        score -= 18.0
        reason = "strong_punctuation"
    elif pause >= policy.pause_boundary_ms:
        ratio = min(3.0, pause / policy.pause_boundary_ms)
        score -= 8.0 + 2.0 * ratio
        reason = "speech_pause"
    elif previous in _SOFT_PUNCTUATION:
        score -= 7.0
        reason = "soft_punctuation"
    elif source_boundary in word_boundaries:
        score -= 2.0
        reason = "word_boundary"
    elif previous in _CANTONESE_BOUNDARY_PARTICLES:
        score -= 1.5
        reason = "cantonese_particle"

    if source_boundary in semantic_boundaries:
        # Semantic IDs are optional hints.  Keeping this reward smaller than a
        # real punctuation/pause signal prevents a dense local-model response
        # from turning every suggested offset into a one-frame subtitle.
        score -= 7.0 if policy.mode == "semantic" else 1.0
        # Keep the strongest evidence in the audit label.  The readability
        # merge pass uses this reason to protect real sentence endings and
        # speech pauses, so a coincident semantic hint must never downgrade
        # their merge penalty.
        if policy.mode == "semantic" and reason in {
            "length_balance",
            "word_boundary",
            "cantonese_particle",
        }:
            reason = "semantic_boundary"
    if previous in _OPENING_PUNCTUATION or following in _CLOSING_PUNCTUATION:
        score += 30.0
    return score, reason


def _edge_cost(
    graphemes: Sequence[_TimedGrapheme],
    start: int,
    end: int,
    *,
    character_count: int,
    source_boundary: int,
    word_boundaries: frozenset[int],
    semantic_boundaries: frozenset[int],
    policy: SubtitleSegmentationPolicy,
) -> tuple[float, str]:
    target_characters = max(1.0, policy.max_characters * 0.72)
    length_delta = (character_count - target_characters) / policy.max_characters
    length_cost = 5.0 * length_delta * length_delta
    acoustic_start_ms, acoustic_end_ms = _acoustic_time_bounds(
        graphemes,
        start,
        end,
        maximum_non_acoustic_edge_ms=policy.pause_boundary_ms,
    )
    start_ms = acoustic_start_ms
    end_ms = max(start_ms + 1, acoustic_end_ms)
    # A short utterance before a pause has real readable display time available
    # without claiming that the silence belongs to punctuation.  Use that
    # bounded availability for boundary selection only; emitted cue edges below
    # remain tied to the acoustic range (apart from the existing short-cue pass).
    next_acoustic_start_ms = _next_acoustic_start_ms(graphemes, end)
    if next_acoustic_start_ms is not None:
        end_ms = max(
            end_ms,
            min(next_acoustic_start_ms, start_ms + policy.target_duration_ms),
        )
    duration = end_ms - start_ms
    duration_delta = (duration - policy.target_duration_ms) / policy.target_duration_ms
    duration_weight = 3.0 if policy.mode == "precise" else 1.25
    duration_cost = duration_weight * min(9.0, duration_delta * duration_delta)
    readability_cost = 0.0
    complete_utterance = (
        end == len(graphemes)
        or _previous_visible(graphemes, end) in _STRONG_PUNCTUATION
    )
    if duration < policy.minimum_readable_duration_ms and not complete_utterance:
        shortfall = (
            policy.minimum_readable_duration_ms - duration
        ) / policy.minimum_readable_duration_ms
        readability_cost = 28.0 * shortfall * shortfall
        if character_count <= 2:
            readability_cost += 8.0 * shortfall
    boundary_cost, reason = _boundary_features(
        graphemes,
        end,
        source_boundary=source_boundary,
        word_boundaries=word_boundaries,
        semantic_boundaries=semantic_boundaries,
        policy=policy,
    )
    return length_cost + duration_cost + readability_cost + boundary_cost, reason


def _legal_boundaries(
    graphemes: Sequence[_Grapheme | _TimedGrapheme],
    protected: Sequence[_ProtectedSpan],
) -> tuple[int, ...]:
    legal = [0]
    for index in range(1, len(graphemes)):
        source_boundary = graphemes[index].source_start
        if any(span.start < source_boundary < span.end for span in protected):
            continue
        # Whitespace is retained at the end of the previous cue.  Not exposing
        # boundaries before/inside a whitespace run prevents whitespace-only
        # cues while preserving the transcript byte-for-byte.
        if graphemes[index].text.isspace():
            continue
        legal.append(index)
    legal.append(len(graphemes))
    return tuple(legal)


def legal_subtitle_boundary_ids(
    text: str,
    *,
    vocabulary: Sequence[str] = (),
    source_offset: int = 0,
) -> tuple[int, ...]:
    """Return every structurally safe internal source offset in stable order.

    These are candidate identifiers, not segmentation decisions.  The helper
    excludes offsets inside Unicode grapheme clusters, URLs, email addresses,
    hashtags, Latin/number tokens, and caller-protected vocabulary phrases.
    A semantic selector may therefore choose a different natural boundary
    from the deterministic precise result without gaining any ability to
    rewrite text or cut an explicitly protected span.
    """

    if not isinstance(text, str):
        raise ValueError("text 必須係文字")
    if (
        isinstance(source_offset, bool)
        or not isinstance(source_offset, int)
        or source_offset < 0
    ):
        raise ValueError("source_offset 必須係非負整數")
    if not isinstance(vocabulary, Sequence) or isinstance(
        vocabulary, (str, bytes, bytearray)
    ):
        raise ValueError("vocabulary 必須係文字 array")

    graphemes = _graphemes(text, source_offset=source_offset)
    if not graphemes:
        return ()
    protected = _protected_spans(text, vocabulary, source_offset=source_offset)
    legal_indexes = _legal_boundaries(graphemes, protected)
    return tuple(
        graphemes[index].source_start
        for index in legal_indexes
        if 0 < index < len(graphemes)
    )


def _over_limit_reason(
    source_start: int,
    source_end: int,
    protected: Sequence[_ProtectedSpan],
) -> str:
    kinds = {
        span.kind
        for span in protected
        if span.start < source_end and span.end > source_start
    }
    if "vocabulary" in kinds:
        return "protected_vocabulary_phrase"
    if "url" in kinds:
        return "unbreakable_url"
    if "email" in kinds:
        return "unbreakable_email"
    if "hashtag_or_mention" in kinds:
        return "unbreakable_hashtag_or_mention"
    if "latin_or_number_token" in kinds:
        return "unbreakable_latin_or_number_token"
    return "no_safe_grapheme_boundary"


def _cue_ends_complete_utterance(cue: SegmentedSubtitleCue) -> bool:
    stripped = cue.text.rstrip()
    return bool(stripped and stripped[-1] in _STRONG_PUNCTUATION)


def _stretch_cues_into_silence(
    cues: Sequence[SegmentedSubtitleCue], *, minimum_duration_ms: int
) -> list[SegmentedSubtitleCue]:
    """Keep a short cue visible into a following silent gap when available."""

    output: list[SegmentedSubtitleCue] = []
    for index, cue in enumerate(cues):
        end_ms = cue.end_ms
        if index + 1 < len(cues) and end_ms - cue.start_ms < minimum_duration_ms:
            end_ms = min(
                cues[index + 1].start_ms,
                max(end_ms, cue.start_ms + minimum_duration_ms),
            )
        output.append(
            SegmentedSubtitleCue(
                index=cue.index,
                start_ms=cue.start_ms,
                end_ms=end_ms,
                text=cue.text,
                source_start=cue.source_start,
                source_end=cue.source_end,
                character_count=cue.character_count,
                boundary_reason=cue.boundary_reason,
            )
        )
    return output


def _removed_boundary_penalty(reason: str) -> float:
    return {
        "strong_punctuation": 50.0,
        "speech_pause": 20.0,
        "soft_punctuation": 10.0,
        "semantic_boundary": 3.0,
        "word_boundary": 2.0,
    }.get(reason, 0.0)


def _merge_unreadable_cues(
    cues: Sequence[SegmentedSubtitleCue],
    *,
    policy: SubtitleSegmentationPolicy,
) -> tuple[tuple[SegmentedSubtitleCue, ...], int, int]:
    """Merge only flashes that can be joined without violating the hard limit.

    Real punctuation and pauses remain preferred boundaries.  They can still
    be removed when a cue is shorter than an absolute 200 ms flash and there
    is no readable alternative.  Every merge is lossless and contiguous.
    """

    work = _stretch_cues_into_silence(
        cues, minimum_duration_ms=policy.minimum_readable_duration_ms
    )
    merge_count = 0
    while len(work) > 1:
        merged = False
        for index, cue in enumerate(work):
            duration = cue.end_ms - cue.start_ms
            if duration >= policy.minimum_readable_duration_ms:
                continue
            if (
                (_cue_ends_complete_utterance(cue) or index == len(work) - 1)
                and duration >= _ABSOLUTE_FLASH_DURATION_MS
            ):
                continue

            options: list[tuple[float, str]] = []
            if index > 0:
                previous = work[index - 1]
                combined_count = previous.character_count + cue.character_count
                if combined_count <= policy.max_characters:
                    score = _removed_boundary_penalty(previous.boundary_reason)
                    score += abs(
                        combined_count - policy.max_characters * 0.72
                    ) / policy.max_characters
                    options.append((score, "left"))
            if index + 1 < len(work):
                following = work[index + 1]
                combined_count = cue.character_count + following.character_count
                if combined_count <= policy.max_characters:
                    score = _removed_boundary_penalty(cue.boundary_reason)
                    score += abs(
                        combined_count - policy.max_characters * 0.72
                    ) / policy.max_characters
                    options.append((score, "right"))
            if not options:
                continue

            direction = min(options, key=lambda item: (item[0], item[1]))[1]
            if direction == "left":
                previous = work[index - 1]
                combined = SegmentedSubtitleCue(
                    index=previous.index,
                    start_ms=previous.start_ms,
                    end_ms=cue.end_ms,
                    text=previous.text + cue.text,
                    source_start=previous.source_start,
                    source_end=cue.source_end,
                    character_count=(
                        previous.character_count + cue.character_count
                    ),
                    boundary_reason=cue.boundary_reason,
                )
                work[index - 1 : index + 1] = [combined]
            else:
                following = work[index + 1]
                combined = SegmentedSubtitleCue(
                    index=cue.index,
                    start_ms=cue.start_ms,
                    end_ms=following.end_ms,
                    text=cue.text + following.text,
                    source_start=cue.source_start,
                    source_end=following.source_end,
                    character_count=(
                        cue.character_count + following.character_count
                    ),
                    boundary_reason=following.boundary_reason,
                )
                work[index : index + 2] = [combined]
            merge_count += 1
            work = _stretch_cues_into_silence(
                work, minimum_duration_ms=policy.minimum_readable_duration_ms
            )
            merged = True
            break
        if not merged:
            break

    reindexed = tuple(
        SegmentedSubtitleCue(
            index=cue_index,
            start_ms=cue.start_ms,
            end_ms=cue.end_ms,
            text=cue.text,
            source_start=cue.source_start,
            source_end=cue.source_end,
            character_count=cue.character_count,
            boundary_reason=cue.boundary_reason,
        )
        for cue_index, cue in enumerate(work, start=cues[0].index if cues else 1)
    )
    remaining_short = sum(
        cue.end_ms - cue.start_ms < policy.minimum_readable_duration_ms
        for cue in reindexed
    )
    return reindexed, merge_count, remaining_short


def segment_subtitles(
    text: str,
    word_timestamps: Sequence[Any] = (),
    character_timestamps: Sequence[Any] = (),
    *,
    policy: SubtitleSegmentationPolicy | None = None,
    vocabulary: Sequence[str] = (),
    semantic_boundary_ids: Iterable[int] = (),
    starting_index: int = 1,
    source_offset: int = 0,
) -> SubtitleSegmentationResult:
    """Split ``text`` without changing it, using deterministic dynamic programming.

    Semantic boundary IDs are absolute source offsets *between* Unicode code
    points.  Unsafe suggestions (inside a grapheme, URL, token, or vocabulary
    phrase) are ignored and reported; they never override the safety rules.
    """

    if not isinstance(text, str):
        raise ValueError("text 必須係文字")
    if isinstance(starting_index, bool) or not isinstance(starting_index, int) or starting_index < 1:
        raise ValueError("starting_index 必須係正整數")
    if isinstance(source_offset, bool) or not isinstance(source_offset, int) or source_offset < 0:
        raise ValueError("source_offset 必須係非負整數")
    selected_policy = policy or SubtitleSegmentationPolicy()
    words = _coerce_words(word_timestamps)
    characters = _coerce_characters(character_timestamps)
    _validate_timestamp_content(
        text, words, characters, source_offset=source_offset
    )
    grapheme_values = _graphemes(text, source_offset=source_offset)
    timed, fallback_count = _timed_graphemes(grapheme_values, words, characters)
    protected = _protected_spans(text, vocabulary, source_offset=source_offset)

    requested: list[int] = []
    for value in semantic_boundary_ids:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("semantic boundary ID 必須係整數 source offset")
        if not source_offset < value < source_offset + len(text):
            raise ValueError("semantic boundary ID 超出 transcript 範圍")
        requested.append(value)
    requested_ids = tuple(sorted(set(requested)))

    if not text:
        return SubtitleSegmentationResult(
            text="",
            cues=(),
            audit=SubtitleSegmentationAudit(
                policy_version=SEGMENTATION_POLICY_VERSION,
                mode=selected_policy.mode,
                max_characters=selected_policy.max_characters,
                target_duration_ms=selected_policy.target_duration_ms,
                pause_boundary_ms=selected_policy.pause_boundary_ms,
                minimum_readable_duration_ms=(
                    selected_policy.minimum_readable_duration_ms
                ),
                protected_span_count=0,
                requested_semantic_boundary_ids=(),
                applied_semantic_boundary_ids=(),
                ignored_semantic_boundary_ids=(),
                timing_fallback_character_count=0,
                readability_merge_count=0,
                remaining_short_cue_count=0,
                over_limit_cues=(),
            ),
        )

    legal = _legal_boundaries(timed, protected)
    legal_source_offsets = {
        timed[index].source_start if index < len(timed) else source_offset + len(text)
        for index in legal
    }
    applied_semantic = tuple(
        value for value in requested_ids if value in legal_source_offsets
    )
    semantic_set = frozenset(applied_semantic)
    word_boundaries = frozenset(
        word.source_end
        for word in words
        if source_offset < word.source_end < source_offset + len(text)
    )
    prefix_visible = [0]
    for grapheme in timed:
        prefix_visible.append(prefix_visible[-1] + _visible_count(grapheme))

    costs = [math.inf] * len(legal)
    choices: list[tuple[int, str] | None] = [None] * len(legal)
    costs[0] = 0.0
    for end_position in range(1, len(legal)):
        end = legal[end_position]
        for start_position in range(end_position - 1, -1, -1):
            start = legal[start_position]
            character_count = prefix_visible[end] - prefix_visible[start]
            over_limit = character_count > selected_policy.max_characters
            if over_limit and start_position != end_position - 1:
                # Moving farther left can only add characters.
                break
            if character_count == 0 and not (start == 0 and end == len(timed)):
                continue
            if not math.isfinite(costs[start_position]):
                continue
            source_boundary = (
                timed[end].source_start
                if end < len(timed)
                else source_offset + len(text)
            )
            edge_cost, reason = _edge_cost(
                timed,
                start,
                end,
                character_count=character_count,
                source_boundary=source_boundary,
                word_boundaries=word_boundaries,
                semantic_boundaries=semantic_set,
                policy=selected_policy,
            )
            if over_limit:
                edge_cost += 100.0
            candidate = costs[start_position] + edge_cost
            current = costs[end_position]
            # Stable tie-break: prefer the later source boundary, producing the
            # fewest/longest equal-cost cues without input-order dependence.
            if candidate < current - 1e-9 or (
                abs(candidate - current) <= 1e-9
                and choices[end_position] is not None
                and start_position > choices[end_position][0]
            ):
                costs[end_position] = candidate
                choices[end_position] = (start_position, reason)

    if choices[-1] is None:
        raise AssertionError("subtitle DP failed to find a safe segmentation")
    selected: list[tuple[int, int, str]] = []
    cursor = len(legal) - 1
    while cursor > 0:
        choice = choices[cursor]
        if choice is None:
            raise AssertionError("subtitle DP path is incomplete")
        previous, reason = choice
        selected.append((legal[previous], legal[cursor], reason))
        cursor = previous
    selected.reverse()

    cues: list[SegmentedSubtitleCue] = []
    previous_end_ms = timed[0].start_ms
    for local_index, (start, end, reason) in enumerate(selected):
        source_start = timed[start].source_start
        source_end = timed[end - 1].source_end
        local_start = source_start - source_offset
        local_end = source_end - source_offset
        acoustic_start_ms, acoustic_end_ms = _acoustic_time_bounds(
            timed,
            start,
            end,
            maximum_non_acoustic_edge_ms=selected_policy.pause_boundary_ms,
        )
        start_ms = max(previous_end_ms, acoustic_start_ms)
        end_ms = max(start_ms + 1, acoustic_end_ms)
        character_count = prefix_visible[end] - prefix_visible[start]
        cue = SegmentedSubtitleCue(
            index=starting_index + local_index,
            start_ms=start_ms,
            end_ms=end_ms,
            text=text[local_start:local_end],
            source_start=source_start,
            source_end=source_end,
            character_count=character_count,
            boundary_reason=reason,
        )
        cues.append(cue)
        previous_end_ms = end_ms

    final_cues, readability_merge_count, remaining_short_cue_count = (
        _merge_unreadable_cues(cues, policy=selected_policy)
    )
    chosen_source_boundaries = frozenset(
        cue.source_end for cue in final_cues[:-1]
    )
    actually_applied_semantic = tuple(
        value for value in applied_semantic if value in chosen_source_boundaries
    )
    actually_ignored_semantic = tuple(
        value for value in requested_ids if value not in chosen_source_boundaries
    )
    over_limit_audit = tuple(
        OverLimitCueAudit(
            cue_index=cue.index,
            source_start=cue.source_start,
            source_end=cue.source_end,
            character_count=cue.character_count,
            reason=_over_limit_reason(cue.source_start, cue.source_end, protected),
        )
        for cue in final_cues
        if cue.character_count > selected_policy.max_characters
    )

    if "".join(cue.text for cue in final_cues) != text:
        raise AssertionError("subtitle segmentation changed transcript content")
    for previous, current in zip(final_cues, final_cues[1:]):
        if previous.source_end != current.source_start:
            raise AssertionError("subtitle source ranges are not contiguous")
        if previous.end_ms > current.start_ms:
            raise AssertionError("subtitle cue timestamps overlap")

    return SubtitleSegmentationResult(
        text=text,
        cues=final_cues,
        audit=SubtitleSegmentationAudit(
            policy_version=SEGMENTATION_POLICY_VERSION,
            mode=selected_policy.mode,
            max_characters=selected_policy.max_characters,
            target_duration_ms=selected_policy.target_duration_ms,
            pause_boundary_ms=selected_policy.pause_boundary_ms,
            minimum_readable_duration_ms=(
                selected_policy.minimum_readable_duration_ms
            ),
            protected_span_count=len(protected),
            requested_semantic_boundary_ids=requested_ids,
            applied_semantic_boundary_ids=actually_applied_semantic,
            ignored_semantic_boundary_ids=actually_ignored_semantic,
            timing_fallback_character_count=fallback_count,
            readability_merge_count=readability_merge_count,
            remaining_short_cue_count=remaining_short_cue_count,
            over_limit_cues=over_limit_audit,
        ),
    )


__all__ = [
    "DEFAULT_MAX_CHARACTERS",
    "DEFAULT_MINIMUM_READABLE_DURATION_MS",
    "MAX_MAX_CHARACTERS",
    "MIN_MAX_CHARACTERS",
    "OverLimitCueAudit",
    "SEGMENTATION_POLICY_VERSION",
    "SegmentedSubtitleCue",
    "SubtitleSegmentationAudit",
    "SubtitleSegmentationPolicy",
    "SubtitleSegmentationResult",
    "legal_subtitle_boundary_ids",
    "segment_subtitles",
]
