"""Offline four-engine evidence report without accuracy overclaims."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from .benchmark import build_benchmark_report, write_benchmark_outputs


CONSENSUS_EVALUATION_VERSION = "2026-08-06.1"
SYSTEM_ALIASES = {
    "qwen": ("qwen", "primary"),
    "wenet": ("wenet", "verifier"),
    "whisper.cpp": ("whisper.cpp", "whisper"),
    "sensevoice": ("sensevoice", "sensevoice-yue"),
}
_RUNTIME_METADATA_FIELDS = {
    "app_version",
    "device",
    "engine_version",
    "language",
    "model",
    "precision",
    "quantization",
    "runtime",
}


def _json_object(path: str | Path, *, label: str) -> tuple[Path, Mapping[str, Any]]:
    source = Path(path).expanduser().resolve(strict=True)
    try:
        value = json.loads(source.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"invalid {label} JSON at line {exc.lineno}, column {exc.colno}"
        ) from exc
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be a JSON object")
    return source, value


def _system_runtime(
    runtime_metadata: Mapping[str, Any],
    identifier: str,
) -> dict[str, Any]:
    systems = runtime_metadata.get("systems", {})
    if not isinstance(systems, Mapping):
        raise ValueError("runtime metadata systems must be an object")
    raw: Mapping[str, Any] = {}
    for alias in SYSTEM_ALIASES[identifier]:
        candidate = systems.get(alias)
        if candidate is not None:
            if not isinstance(candidate, Mapping):
                raise ValueError(f"runtime metadata system {alias} must be an object")
            raw = candidate
            break
    entry: dict[str, Any] = {}
    if "processing_seconds" in raw:
        entry["processing_seconds"] = raw["processing_seconds"]
    nested = raw.get("metadata", {})
    if nested is not None and not isinstance(nested, Mapping):
        raise ValueError(f"runtime metadata for {identifier} must be an object")
    metadata = {
        key: raw[key]
        for key in _RUNTIME_METADATA_FIELDS
        if key in raw
    }
    if isinstance(nested, Mapping):
        metadata.update(
            {
                key: nested[key]
                for key in _RUNTIME_METADATA_FIELDS
                if key in nested
            }
        )
    if metadata:
        entry["metadata"] = metadata
    return entry


def build_consensus_manifest(
    *,
    qwen_path: str | Path,
    wenet_path: str | Path,
    whisper_paths: Sequence[str | Path],
    sensevoice_path: str | Path,
    runtime_metadata: Mapping[str, Any],
    extra_terms: Sequence[str] = (),
) -> dict[str, Any]:
    if not whisper_paths:
        raise ValueError("at least one whisper.cpp JSON is required")
    duration = runtime_metadata.get("audio_duration_seconds")
    if duration is None:
        raise ValueError("runtime metadata requires audio_duration_seconds")
    raw_offsets = runtime_metadata.get("whisper_offsets_ms")
    if len(whisper_paths) > 1 and raw_offsets is None:
        raise ValueError(
            "multiple whisper.cpp JSON files require runtime whisper_offsets_ms"
        )
    if raw_offsets is not None and not isinstance(raw_offsets, list):
        raise ValueError("runtime whisper_offsets_ms must be an array")

    qwen = Path(qwen_path).expanduser().resolve(strict=True)
    wenet = Path(wenet_path).expanduser().resolve(strict=True)
    whisper = [Path(path).expanduser().resolve(strict=True) for path in whisper_paths]
    sensevoice = Path(sensevoice_path).expanduser().resolve(strict=True)
    systems = [
        {"id": "qwen", "path": str(qwen), **_system_runtime(runtime_metadata, "qwen")},
        {"id": "wenet", "path": str(wenet), **_system_runtime(runtime_metadata, "wenet")},
        {
            "id": "whisper.cpp",
            "paths": [str(path) for path in whisper],
            **({"offsets_ms": raw_offsets} if raw_offsets is not None else {}),
            **_system_runtime(runtime_metadata, "whisper.cpp"),
        },
        {
            "id": "sensevoice",
            "path": str(sensevoice),
            **_system_runtime(runtime_metadata, "sensevoice"),
        },
    ]
    return {
        "schema_version": 1,
        "systems": systems,
        "audio_duration_seconds": duration,
        "entities": list(extra_terms),
    }


def run_consensus_evaluation(
    *,
    qwen_path: str | Path,
    wenet_path: str | Path,
    whisper_paths: Sequence[str | Path],
    sensevoice_path: str | Path,
    runtime_metadata_path: str | Path,
    output_json_path: str | Path,
    output_markdown_path: str | Path,
    extra_terms: Sequence[str] = (),
) -> dict[str, Any]:
    runtime_source, runtime_metadata = _json_object(
        runtime_metadata_path,
        label="runtime metadata",
    )
    manifest = build_consensus_manifest(
        qwen_path=qwen_path,
        wenet_path=wenet_path,
        whisper_paths=whisper_paths,
        sensevoice_path=sensevoice_path,
        runtime_metadata=runtime_metadata,
        extra_terms=extra_terms,
    )
    report = build_benchmark_report(manifest, base_dir=runtime_source.parent)
    report["evaluation_profile"] = {
        "name": "four_engine_no_gold_consensus",
        "version": CONSENSUS_EVALUATION_VERSION,
        "system_roles": {
            "qwen": "primary",
            "wenet": "verifier",
            "whisper.cpp": "independent_candidate",
            "sensevoice": "cantonese_specialist_candidate",
        },
        "whisper_artifact_count": len(whisper_paths),
        "runtime_metadata_sha256": hashlib.sha256(runtime_source.read_bytes()).hexdigest(),
        "human_gold_supplied": False,
        "winner_by_WER": None,
        "winner_by_CER": None,
    }
    write_benchmark_outputs(
        report,
        json_path=output_json_path,
        markdown_path=output_markdown_path,
    )
    return report


__all__ = [
    "CONSENSUS_EVALUATION_VERSION",
    "build_consensus_manifest",
    "run_consensus_evaluation",
]
