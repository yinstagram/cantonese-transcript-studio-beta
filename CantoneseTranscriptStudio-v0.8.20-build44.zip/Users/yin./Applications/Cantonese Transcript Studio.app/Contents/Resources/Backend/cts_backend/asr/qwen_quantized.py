"""Offline, bounded-memory conversion of Qwen3-ASR checkpoints to MLX Q8.

The Hugging Face checkpoint is treated as immutable input.  Conversion is
performed one tensor at a time and saved in small safetensor shards inside a
staging directory.  The staging directory is only renamed into place after a
full SHA-256 verification succeeds.
"""

from __future__ import annotations

import gc
import hashlib
import json
import os
import re
import shutil
import struct
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


# The normal worker binds resumable checkpoints to ``manifest.json``.  Runtime
# derivatives therefore use that canonical name instead of a converter-only
# filename, while retaining the converter schema inside the document.
RUNTIME_MANIFEST = "manifest.json"
QUANTIZATION_CONFIG = "quantization_config.json"
CONVERTER_SCHEMA = "cts.qwen3-asr-mlx-runtime/v1"
CONVERTER_VERSION = "2"
SOURCE_IDENTITY_SCHEMA = "cts.qwen3-asr-source-identity/v1"
DEFAULT_BITS = 8
DEFAULT_GROUP_SIZE = 64
DEFAULT_SHARD_BYTES = 256 * 1024 * 1024
DEFAULT_MODE = "affine"
DEFAULT_SCOPE = "text_decoder_only"
MAX_SAFETENSORS_HEADER_BYTES = 64 * 1024 * 1024
SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]


class QwenRuntimeConversionError(RuntimeError):
    """Raised when a source checkpoint cannot be converted safely."""


class QwenRuntimeConversionCancelled(QwenRuntimeConversionError):
    """Raised when a caller cancels conversion between tensors."""


class _DuplicateJSONKey(ValueError):
    """Internal signal used to reject ambiguous JSON objects fail-closed."""


def _reject_duplicate_json_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    value: dict[str, Any] = {}
    for key, item in pairs:
        if key in value:
            raise _DuplicateJSONKey(f"duplicate_key:{key}")
        value[key] = item
    return value


def _reject_json_constant(value: str) -> Any:
    raise ValueError(f"invalid_constant:{value}")


def _strict_json_object(path: Path) -> dict[str, Any]:
    """Read one JSON object while rejecting duplicate keys at every depth."""

    raw = json.loads(
        path.read_text(encoding="utf-8"),
        object_pairs_hook=_reject_duplicate_json_keys,
        parse_constant=_reject_json_constant,
    )
    if not isinstance(raw, dict):
        raise ValueError("root_not_object")
    return raw


@dataclass(frozen=True)
class RuntimeVerification:
    valid: bool
    errors: tuple[str, ...]
    manifest: dict[str, Any] | None = None


@dataclass(frozen=True)
class RuntimeConversionResult:
    output_dir: Path
    manifest: dict[str, Any]
    reused: bool
    moved_invalid_to: Path | None = None


def runtime_output_path(source_dir: str | Path, *, bits: int = DEFAULT_BITS) -> Path:
    """Return the sole app-derived runtime path eligible for safe replacement."""
    source = Path(source_dir).expanduser().resolve(strict=False)
    return source.with_name(f"{source.name}-MLX-{bits}bit")


def _sha256_file(path: Path, block_size: int = 4 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(block_size), b""):
            digest.update(block)
    return digest.hexdigest()


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _source_files(source_dir: Path) -> list[Path]:
    files = sorted(source_dir.glob("*.safetensors"))
    if not files:
        raise QwenRuntimeConversionError(f"Qwen source 缺少 safetensors：{source_dir}")
    for path in files:
        if path.is_symlink() or not path.is_file():
            raise QwenRuntimeConversionError(f"Qwen source weight 唔可以係 symlink：{path}")
    return files


def _canonical_manifest_path(raw: Any, *, label: str) -> str:
    if (
        not isinstance(raw, str)
        or not raw
        or "\\" in raw
        or "\0" in raw
    ):
        raise QwenRuntimeConversionError(f"{label} path 無效")
    relative = Path(raw)
    if (
        relative.is_absolute()
        or not relative.parts
        or ".." in relative.parts
        or "." in relative.parts
        or len(relative.parts) != 1
        or relative.as_posix() != raw
        or raw in {RUNTIME_MANIFEST, ".verification.json"}
    ):
        raise QwenRuntimeConversionError(f"{label} path 不安全：{raw}")
    return raw


def _safe_file_entry(source_dir: Path, raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict) or set(raw) != {"path", "size", "sha256"}:
        raise QwenRuntimeConversionError("Qwen source manifest file entry 無效")
    name = _canonical_manifest_path(
        raw.get("path"), label="Qwen source manifest file"
    )
    size = raw.get("size")
    sha256 = raw.get("sha256")
    path = source_dir / name
    if path.is_symlink() or not path.is_file():
        raise QwenRuntimeConversionError(f"Qwen source manifest file 缺失：{name}")
    if (
        isinstance(size, bool)
        or not isinstance(size, int)
        or size < 0
        or path.stat().st_size != size
    ):
        raise QwenRuntimeConversionError(f"Qwen source manifest size 不符：{name}")
    if (
        not isinstance(sha256, str)
        or not SHA256_PATTERN.fullmatch(sha256)
        or _sha256_file(path) != sha256
    ):
        raise QwenRuntimeConversionError(f"Qwen source manifest SHA-256 不符：{name}")
    return {"path": name, "size": size, "sha256": sha256}


def _source_regular_files(source_dir: Path) -> dict[str, Path]:
    """Return every top-level source asset covered by its immutable identity."""

    files: dict[str, Path] = {}
    for path in sorted(source_dir.iterdir()):
        if path.name in {RUNTIME_MANIFEST, ".verification.json"}:
            continue
        if path.name == ".cache" and path.is_dir() and not path.is_symlink():
            continue
        if path.is_symlink() or not path.is_file():
            raise QwenRuntimeConversionError(f"Qwen source asset 無效：{path.name}")
        files[path.name] = path
    if not files:
        raise QwenRuntimeConversionError("Qwen source 沒有可驗證檔案")
    return files


def _source_identity(source_dir: Path, weight_files: list[Path]) -> dict[str, Any]:
    """Bind a runtime to the complete verified checkpoint, not weights alone."""

    manifest_path = source_dir / RUNTIME_MANIFEST
    if manifest_path.is_file() and not manifest_path.is_symlink():
        try:
            raw = _strict_json_object(manifest_path)
        except (
            OSError,
            UnicodeError,
            json.JSONDecodeError,
            ValueError,
        ) as exc:
            raise QwenRuntimeConversionError("Qwen source manifest 無法讀取") from exc
        if raw.get("schema") != 1 or not isinstance(raw.get("files"), list):
            raise QwenRuntimeConversionError("Qwen source manifest root 無效")
        entries = [_safe_file_entry(source_dir, item) for item in raw["files"]]
        declared = {entry["path"] for entry in entries}
        if len(declared) != len(entries):
            raise QwenRuntimeConversionError("Qwen source manifest path 重複")
        if not {path.name for path in weight_files} <= declared:
            raise QwenRuntimeConversionError("Qwen source manifest 未包含全部 weights")
        actual = set(_source_regular_files(source_dir))
        if declared != actual:
            raise QwenRuntimeConversionError("Qwen source manifest 未涵蓋完整檔案集合")
        return {
            "identity_schema": SOURCE_IDENTITY_SCHEMA,
            "identity_kind": "app_manifest",
            "path": str(source_dir),
            "manifest_sha256": _sha256_file(manifest_path),
            "model": raw.get("model"),
            "source": raw.get("source"),
            "revision": raw.get("revision"),
            "files": entries,
        }

    # Unit fixtures and explicit local checkpoints may not have an app manifest.
    # Bind every regular file that can affect loading instead of silently falling
    # back to a weights-only identity.
    entries: list[dict[str, Any]] = []
    for path in _source_regular_files(source_dir).values():
        entries.append(
            {
                "path": path.name,
                "size": path.stat().st_size,
                "sha256": _sha256_file(path),
            }
        )
    return {
        "identity_schema": SOURCE_IDENTITY_SCHEMA,
        "identity_kind": "directory_snapshot",
        "path": str(source_dir),
        "manifest_sha256": None,
        "model": None,
        "source": None,
        "revision": None,
        "files": entries,
    }


def _same_source_identity(expected: dict[str, Any], source_dir: Path) -> bool:
    if expected.get("path") != str(source_dir):
        return False
    try:
        actual = _source_identity(source_dir, _source_files(source_dir))
    except QwenRuntimeConversionError:
        return False
    return expected == actual


def _read_safetensors_header(path: Path) -> dict[str, dict[str, Any]]:
    try:
        with path.open("rb") as stream:
            raw_length = stream.read(8)
            if len(raw_length) != 8:
                raise ValueError("short header length")
            header_length = struct.unpack("<Q", raw_length)[0]
            if not 2 <= header_length <= MAX_SAFETENSORS_HEADER_BYTES:
                raise ValueError("unsafe header length")
            raw_header = stream.read(header_length)
            if len(raw_header) != header_length:
                raise ValueError("short header")
        value = json.loads(raw_header)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError, struct.error) as exc:
        raise QwenRuntimeConversionError(
            f"quantized safetensors header 無效：{path.name}"
        ) from exc
    if not isinstance(value, dict):
        raise QwenRuntimeConversionError(f"quantized safetensors header 無效：{path.name}")
    output: dict[str, dict[str, Any]] = {}
    for name, metadata in value.items():
        if name == "__metadata__":
            continue
        if not isinstance(name, str) or not isinstance(metadata, dict):
            raise QwenRuntimeConversionError(f"quantized tensor metadata 無效：{path.name}")
        if name in output:
            raise QwenRuntimeConversionError(f"quantized tensor 名稱重複：{name}")
        output[name] = metadata
    return output


def _validate_packed_quantization(
    output: Path, *, bits: int, group_size: int
) -> tuple[str, ...]:
    errors: list[str] = []
    tensors: dict[str, dict[str, Any]] = {}
    for path in sorted(output.glob("*.safetensors")):
        try:
            header = _read_safetensors_header(path)
        except QwenRuntimeConversionError as exc:
            errors.append(str(exc))
            continue
        overlap = set(tensors) & set(header)
        if overlap:
            errors.append("tensor_name_duplicate:" + sorted(overlap)[0])
        tensors.update(header)

    quantized_count = 0
    for name, scales in tensors.items():
        if not name.endswith(".scales"):
            continue
        prefix = name.removesuffix(".scales")
        weight_name = prefix + ".weight"
        biases_name = prefix + ".biases"
        weight = tensors.get(weight_name)
        biases = tensors.get(biases_name)
        if weight is None or biases is None:
            errors.append(f"quantized_triplet_missing:{prefix}")
            continue
        if not (weight_name.startswith("model.") or weight_name.startswith("lm_head.")):
            errors.append(f"quantized_scope_invalid:{weight_name}")
        weight_shape = weight.get("shape")
        scale_shape = scales.get("shape")
        bias_shape = biases.get("shape")
        if not (
            isinstance(weight_shape, list)
            and isinstance(scale_shape, list)
            and isinstance(bias_shape, list)
            and len(weight_shape) == len(scale_shape) == len(bias_shape) == 2
            and all(isinstance(item, int) and item > 0 for item in weight_shape)
            and all(isinstance(item, int) and item > 0 for item in scale_shape)
            and all(isinstance(item, int) and item > 0 for item in bias_shape)
        ):
            errors.append(f"quantized_shape_invalid:{prefix}")
            continue
        packed_columns = int(weight_shape[-1])
        numerator = packed_columns * 32
        if numerator % bits:
            errors.append(f"quantized_bits_shape_mismatch:{prefix}")
            continue
        input_dimension = numerator // bits
        if input_dimension % group_size:
            errors.append(f"quantized_group_shape_mismatch:{prefix}")
            continue
        expected_scales = [int(weight_shape[0]), input_dimension // group_size]
        if scale_shape != expected_scales or bias_shape != expected_scales:
            errors.append(f"quantized_group_shape_mismatch:{prefix}")
        if weight.get("dtype") != "U32":
            errors.append(f"quantized_weight_dtype_invalid:{prefix}")
        if scales.get("dtype") not in {"F16", "BF16", "F32"}:
            errors.append(f"quantized_scale_dtype_invalid:{prefix}")
        if biases.get("dtype") != scales.get("dtype"):
            errors.append(f"quantized_bias_dtype_invalid:{prefix}")
        quantized_count += 1
    if quantized_count == 0:
        errors.append("quantized_tensors_missing")
    return tuple(errors)


def _is_tied_lm_head(config: dict[str, Any]) -> bool:
    thinker = config.get("thinker_config", config)
    text = thinker.get("text_config", {}) if isinstance(thinker, dict) else {}
    return bool(text.get("tie_word_embeddings", False))


def _asset_files(source_dir: Path) -> list[Path]:
    excluded = {
        RUNTIME_MANIFEST,
        QUANTIZATION_CONFIG,
        ".verification.json",
        "model.safetensors.index.json",
    }
    assets: list[Path] = []
    for path in sorted(source_dir.iterdir()):
        if path.name in excluded or path.suffix == ".safetensors":
            continue
        if path.is_symlink():
            raise QwenRuntimeConversionError(
                f"Qwen source asset 唔可以係 symlink：{path.name}"
            )
        if path.is_file():
            assets.append(path)
    return assets


def _array_bytes(array: Any) -> int:
    return int(getattr(array, "nbytes", 0))


def _remap_name_and_value(name: str, value: Any) -> tuple[str, Any]:
    had_thinker_prefix = name.startswith("thinker.")
    new_name = name[len("thinker.") :] if had_thinker_prefix else name
    if (
        had_thinker_prefix
        and "conv2d" in new_name
        and new_name.endswith(".weight")
        and value.ndim == 4
    ):
        value = value.transpose(0, 2, 3, 1)
    return new_name, value


def _is_decoder_quantized_weight(name: str, value: Any) -> bool:
    """Match the established MLX Qwen3-ASR Q8 layout: decoder only.

    Keeping ``audio_tower.*`` in FP16 is intentional.  Quantizing its Linear
    layers saves relatively little memory and introduces avoidable error before
    the language decoder receives the acoustic features.
    """
    return (
        value.ndim == 2
        and name.endswith(".weight")
        and (name.startswith("model.") or name.startswith("lm_head."))
    )


def _move_to_trash(path: Path, trash_root: Path | None = None) -> Path:
    trash = trash_root or (Path.home() / ".Trash")
    trash.mkdir(parents=True, exist_ok=True)
    destination = trash / (
        f"{path.name}-{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"
    )
    shutil.move(str(path), str(destination))
    return destination


def _is_exact_derived_output(source_dir: Path, output_dir: Path, bits: int) -> bool:
    return output_dir.resolve(strict=False) == runtime_output_path(source_dir, bits=bits)


def _manifest_file_fields(raw: Any) -> tuple[str | None, int | None, str | None]:
    if not isinstance(raw, dict) or set(raw) != {"path", "size", "sha256"}:
        return None, None, None
    name = raw.get("path")
    size = raw.get("size")
    sha256 = raw.get("sha256")
    if (
        not isinstance(name, str)
        or not name
        or "\\" in name
        or "\0" in name
    ):
        return None, None, None
    relative = Path(name)
    if (
        relative.is_absolute()
        or not relative.parts
        or ".." in relative.parts
        or "." in relative.parts
        or len(relative.parts) != 1
        or relative.as_posix() != name
        or name in {RUNTIME_MANIFEST, ".verification.json"}
    ):
        return None, None, None
    clean_size = (
        size
        if not isinstance(size, bool) and isinstance(size, int) and size >= 0
        else None
    )
    clean_sha256 = (
        sha256
        if isinstance(sha256, str) and SHA256_PATTERN.fullmatch(sha256)
        else None
    )
    return name, clean_size, clean_sha256


def _source_identity_errors(value: Any) -> tuple[str, ...]:
    errors: list[str] = []
    required = {
        "identity_schema",
        "identity_kind",
        "path",
        "manifest_sha256",
        "model",
        "source",
        "revision",
        "files",
    }
    if not isinstance(value, dict) or set(value) != required:
        return ("source_identity_invalid",)
    if value.get("identity_schema") != SOURCE_IDENTITY_SCHEMA:
        errors.append("source_identity_schema_mismatch")
    kind = value.get("identity_kind")
    if kind not in {"app_manifest", "directory_snapshot"}:
        errors.append("source_identity_kind_invalid")
    path = value.get("path")
    if (
        not isinstance(path, str)
        or not path
        or "\0" in path
        or not Path(path).is_absolute()
    ):
        errors.append("source_identity_path_invalid")
    manifest_sha256 = value.get("manifest_sha256")
    if kind == "app_manifest":
        if (
            not isinstance(manifest_sha256, str)
            or not SHA256_PATTERN.fullmatch(manifest_sha256)
        ):
            errors.append("source_manifest_sha256_invalid")
        if not isinstance(value.get("model"), str) or not value.get("model"):
            errors.append("source_model_identity_invalid")
        if not isinstance(value.get("source"), str) or not value.get("source"):
            errors.append("source_repository_identity_invalid")
        revision = value.get("revision")
        if revision is not None and (not isinstance(revision, str) or not revision):
            errors.append("source_revision_identity_invalid")
    elif kind == "directory_snapshot":
        if manifest_sha256 is not None:
            errors.append("source_snapshot_manifest_invalid")
        if any(value.get(key) is not None for key in ("model", "source", "revision")):
            errors.append("source_snapshot_metadata_invalid")

    raw_files = value.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        errors.append("source_file_manifest_missing")
        return tuple(errors)
    declared: set[str] = set()
    for item in raw_files:
        name, size, sha256 = _manifest_file_fields(item)
        if name is None:
            errors.append("source_file_entry_invalid")
            continue
        if name in declared:
            errors.append(f"source_file_path_duplicate:{name}")
            continue
        declared.add(name)
        if size is None:
            errors.append(f"source_size_invalid:{name}")
        if sha256 is None:
            errors.append(f"source_sha256_invalid:{name}")
    if not {"config.json", "tokenizer_config.json"} <= declared:
        errors.append("source_required_metadata_missing")
    if not any(name.endswith(".safetensors") for name in declared):
        errors.append("source_weight_files_missing")
    return tuple(errors)


def verify_quantized_runtime(
    output_dir: str | Path,
    *,
    source_dir: str | Path | None = None,
    verify_hashes: bool = True,
    expected_bits: int | None = None,
    expected_group_size: int | None = None,
    expected_mode: str | None = None,
    expected_scope: str | None = None,
) -> RuntimeVerification:
    """Verify the custom manifest, every output hash, and optional source identity."""
    supplied = Path(output_dir).expanduser()
    if supplied.is_symlink():
        return RuntimeVerification(False, ("output_symlink",), None)
    output = supplied.resolve(strict=False)
    errors: list[str] = []

    def add_error(value: str) -> None:
        if value not in errors:
            errors.append(value)

    manifest: dict[str, Any] | None = None
    manifest_path = output / RUNTIME_MANIFEST
    try:
        manifest = _strict_json_object(manifest_path)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        return RuntimeVerification(False, (f"manifest_invalid:{exc}",), None)

    if set(manifest) != {
        "schema",
        "converter_version",
        "created_at",
        "source",
        "quantization",
        "tensors",
        "files",
    }:
        add_error("manifest_fields_invalid")
    if manifest.get("schema") != CONVERTER_SCHEMA:
        add_error("schema_mismatch")
    if manifest.get("converter_version") != CONVERTER_VERSION:
        add_error("converter_version_mismatch")
    if not isinstance(manifest.get("created_at"), str) or not manifest.get(
        "created_at"
    ):
        add_error("created_at_invalid")
    for identity_error in _source_identity_errors(manifest.get("source")):
        add_error(identity_error)
    quant = manifest.get("quantization")
    if not isinstance(quant, dict) or set(quant) != {
        "bits",
        "group_size",
        "mode",
        "scope",
    }:
        add_error("quantization_invalid")
        quant = {}
    bits = quant.get("bits")
    group_size = quant.get("group_size")
    mode = quant.get("mode")
    scope = quant.get("scope")
    if isinstance(bits, bool) or bits != DEFAULT_BITS:
        add_error("quantization_bits_mismatch")
    if isinstance(group_size, bool) or group_size != DEFAULT_GROUP_SIZE:
        add_error("quantization_group_size_mismatch")
    if mode != DEFAULT_MODE:
        add_error("quantization_mode_mismatch")
    if scope != DEFAULT_SCOPE:
        add_error("quantization_scope_mismatch")
    if expected_bits is not None and bits != expected_bits:
        add_error("quantization_bits_mismatch")
    if expected_group_size is not None and group_size != expected_group_size:
        add_error("quantization_group_size_mismatch")
    if expected_mode is not None and mode != expected_mode:
        add_error("quantization_mode_mismatch")
    if expected_scope is not None and scope != expected_scope:
        add_error("quantization_scope_mismatch")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        add_error("file_manifest_missing")
        files = []

    declared: set[str] = set()
    for item in files:
        name, size, sha256 = _manifest_file_fields(item)
        if name is None:
            add_error("file_entry_invalid")
            continue
        if name in declared:
            add_error(f"file_path_duplicate:{name}")
            continue
        declared.add(name)
        path = output / name
        if path.is_symlink() or not path.is_file():
            add_error(f"file_missing:{name}")
            continue
        if size is None:
            add_error(f"size_invalid:{name}")
        elif path.stat().st_size != size:
            add_error(f"size_mismatch:{name}")
        if sha256 is None:
            add_error(f"sha256_invalid:{name}")
        elif verify_hashes and _sha256_file(path) != sha256:
            add_error(f"hash_mismatch:{name}")

    actual_files: set[str] = set()
    try:
        output_items = list(output.iterdir())
    except OSError:
        output_items = []
        errors.append("output_unreadable")
    for path in output_items:
        if path.name == RUNTIME_MANIFEST:
            continue
        if path.is_symlink() or not path.is_file():
            add_error(f"output_entry_invalid:{path.name}")
            continue
        actual_files.add(path.name)
    if actual_files != declared:
        add_error("runtime_file_set_mismatch")
    actual_weights = {name for name in actual_files if name.endswith(".safetensors")}
    declared_weights = {name for name in declared if name.endswith(".safetensors")}
    if actual_weights != declared_weights:
        add_error("weight_file_set_mismatch")
    if QUANTIZATION_CONFIG not in declared or "config.json" not in declared:
        add_error("required_metadata_missing")
    if not declared_weights:
        add_error("weight_files_missing")

    quant_config_path = output / QUANTIZATION_CONFIG
    try:
        quant_config = _strict_json_object(quant_config_path)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError):
        quant_config = {}
        add_error("quantization_config_invalid")
    expected_config = {
        "schema": CONVERTER_SCHEMA,
        "bits": DEFAULT_BITS,
        "group_size": DEFAULT_GROUP_SIZE,
        "mode": DEFAULT_MODE,
        "scope": DEFAULT_SCOPE,
        "source_dtype": "BF16",
        "non_quantized_float_dtype": "float16",
    }
    if quant_config != expected_config:
        add_error("quantization_config_mismatch")
    if bits == DEFAULT_BITS and group_size == DEFAULT_GROUP_SIZE:
        errors.extend(
            _validate_packed_quantization(
                output, bits=bits, group_size=group_size
            )
        )

    if source_dir is not None:
        source_supplied = Path(source_dir).expanduser()
        if source_supplied.is_symlink():
            add_error("source_symlink")
            return RuntimeVerification(False, tuple(errors), manifest)
        try:
            source = source_supplied.resolve(strict=True)
        except OSError:
            add_error("source_unavailable")
            return RuntimeVerification(False, tuple(errors), manifest)
        identity = manifest.get("source")
        if not isinstance(identity, dict) or not _same_source_identity(identity, source):
            add_error("source_identity_mismatch")
    return RuntimeVerification(not errors, tuple(errors), manifest)


def convert_qwen_runtime(
    source_dir: str | Path,
    output_dir: str | Path | None = None,
    *,
    bits: int = DEFAULT_BITS,
    group_size: int = DEFAULT_GROUP_SIZE,
    shard_size_bytes: int = DEFAULT_SHARD_BYTES,
    progress: Progress | None = None,
    cancelled: Cancelled | None = None,
    trash_root: str | Path | None = None,
) -> RuntimeConversionResult:
    """Create or reuse an offline MLX quantized runtime without changing source."""
    if bits != DEFAULT_BITS:
        raise ValueError("CTS Qwen runtime 只接受經驗證嘅 8-bit affine 量化")
    if group_size != DEFAULT_GROUP_SIZE:
        raise ValueError("CTS Qwen runtime 只接受 group_size=64")
    if shard_size_bytes <= 0:
        raise ValueError("shard_size_bytes 必須大過 0")

    source_supplied = Path(source_dir).expanduser()
    if source_supplied.is_symlink():
        raise QwenRuntimeConversionError("Qwen source model 唔可以係 symlink")
    source = source_supplied.resolve(strict=True)
    if not source.is_dir() or not (source / "config.json").is_file():
        raise QwenRuntimeConversionError(f"Qwen source 無有效 config.json：{source}")
    output = (
        runtime_output_path(source, bits=bits)
        if output_dir is None
        else (
            Path(output_dir).expanduser().parent.resolve(strict=False)
            / Path(output_dir).expanduser().name
        )
    )
    if output == source or source in output.parents:
        raise QwenRuntimeConversionError("runtime output 唔可以覆蓋或放入 source model")
    derived = _is_exact_derived_output(source, output, bits)
    trash = Path(trash_root).expanduser() if trash_root is not None else None

    moved_invalid_to: Path | None = None
    if output.exists() or output.is_symlink():
        verified = verify_quantized_runtime(
            output,
            source_dir=source,
            expected_bits=bits,
            expected_group_size=group_size,
            expected_mode=DEFAULT_MODE,
            expected_scope=DEFAULT_SCOPE,
        )
        if verified.valid and verified.manifest is not None:
            return RuntimeConversionResult(output, verified.manifest, True)
        if not derived:
            raise QwenRuntimeConversionError(
                f"拒絕取代非 App 衍生 output：{output}（{','.join(verified.errors)}）"
            )
        moved_invalid_to = _move_to_trash(output, trash)

    # Interrupted app-owned staging folders are recoverable, never unlinked.
    if derived:
        for stale in sorted(output.parent.glob(f".{output.name}.staging-*")):
            if stale.is_dir() or stale.is_symlink():
                _move_to_trash(stale, trash)

    output.parent.mkdir(parents=True, exist_ok=True)
    staging = output.parent / f".{output.name}.staging-{uuid.uuid4().hex}"
    staging.mkdir(parents=True, exist_ok=False)
    try:
        import mlx.core as mx

        weight_files = _source_files(source)
        source_identity = _source_identity(source, weight_files)
        try:
            config = _strict_json_object(source / "config.json")
        except (
            OSError,
            UnicodeError,
            json.JSONDecodeError,
            ValueError,
        ) as exc:
            raise QwenRuntimeConversionError("Qwen config root 必須係有效 object") from exc
        tied_lm_head = _is_tied_lm_head(config)

        for asset in _asset_files(source):
            shutil.copy2(asset, staging / asset.name)
        _atomic_json(
            staging / QUANTIZATION_CONFIG,
            {
                "schema": CONVERTER_SCHEMA,
                "bits": bits,
                "group_size": group_size,
                "mode": DEFAULT_MODE,
                "scope": DEFAULT_SCOPE,
                "source_dtype": "BF16",
                "non_quantized_float_dtype": "float16",
            },
        )

        pending: dict[str, Any] = {}
        pending_bytes = 0
        shard_number = 0
        tensor_to_shard: dict[str, str] = {}
        quantized_modules = 0
        copied_tensors = 0
        omitted_tensors: list[str] = []
        seen_names: set[str] = set()

        def flush() -> None:
            nonlocal pending, pending_bytes, shard_number
            if not pending:
                return
            shard_number += 1
            shard_name = f"model-q{bits}-{shard_number:05d}.safetensors"
            mx.save_safetensors(
                staging / shard_name,
                pending,
                metadata={"format": "mlx", "converter": CONVERTER_SCHEMA},
            )
            for tensor_name in pending:
                tensor_to_shard[tensor_name] = shard_name
            pending = {}
            pending_bytes = 0
            gc.collect()
            mx.clear_cache()

        total_source_bytes = sum(path.stat().st_size for path in weight_files)
        completed_source_bytes = 0
        for weight_file in weight_files:
            if cancelled and cancelled():
                raise QwenRuntimeConversionCancelled("Qwen runtime conversion 已取消")
            arrays = mx.load(weight_file)
            if not isinstance(arrays, dict):
                raise QwenRuntimeConversionError(f"無法讀取 safetensors map：{weight_file}")
            for source_name in list(arrays):
                if cancelled and cancelled():
                    raise QwenRuntimeConversionCancelled("Qwen runtime conversion 已取消")
                value = arrays.pop(source_name)
                name, value = _remap_name_and_value(source_name, value)
                if tied_lm_head and name == "lm_head.weight":
                    omitted_tensors.append(name)
                    del value
                    continue
                if name in seen_names:
                    raise QwenRuntimeConversionError(f"remap 後 tensor 名稱重複：{name}")
                seen_names.add(name)

                produced: dict[str, Any]
                if _is_decoder_quantized_weight(name, value):
                    if int(value.shape[-1]) % group_size:
                        raise QwenRuntimeConversionError(
                            f"2D tensor 最後維度唔可用 group_size={group_size}："
                            f"{name} {tuple(value.shape)}"
                        )
                    fp16 = value.astype(mx.float16)
                    packed, scales, biases = mx.quantize(
                        fp16, group_size=group_size, bits=bits, mode="affine"
                    )
                    mx.eval(packed, scales, biases)
                    produced = {
                        name: packed,
                        name.removesuffix(".weight") + ".scales": scales,
                        name.removesuffix(".weight") + ".biases": biases,
                    }
                    quantized_modules += 1
                    del fp16
                else:
                    if mx.issubdtype(value.dtype, mx.floating):
                        value = value.astype(mx.float16)
                    mx.eval(value)
                    produced = {name: value}
                    copied_tensors += 1

                produced_bytes = sum(_array_bytes(item) for item in produced.values())
                if pending and pending_bytes + produced_bytes > shard_size_bytes:
                    flush()
                pending.update(produced)
                pending_bytes += produced_bytes
                del value, produced
            del arrays
            completed_source_bytes += weight_file.stat().st_size
            if progress is not None:
                progress(
                    {
                        "phase": "quantizing",
                        "source_file": weight_file.name,
                        "progress": completed_source_bytes / total_source_bytes,
                    }
                )
        flush()

        if "model.embed_tokens.weight" not in tensor_to_shard:
            raise QwenRuntimeConversionError("quantized runtime 缺少 model.embed_tokens.weight")
        if quantized_modules == 0:
            raise QwenRuntimeConversionError("source 沒有可量化 2D tensor")

        _atomic_json(
            staging / "model.safetensors.index.json",
            {
                "metadata": {
                    "total_size": sum(
                        path.stat().st_size for path in staging.glob("*.safetensors")
                    )
                },
                "weight_map": dict(sorted(tensor_to_shard.items())),
            },
        )

        output_files = []
        for path in sorted(staging.iterdir()):
            if not path.is_file() or path.name == RUNTIME_MANIFEST:
                continue
            output_files.append(
                {"path": path.name, "size": path.stat().st_size, "sha256": _sha256_file(path)}
            )
        manifest = {
            "schema": CONVERTER_SCHEMA,
            "converter_version": CONVERTER_VERSION,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "source": source_identity,
            "quantization": {
                "bits": bits,
                "group_size": group_size,
                "mode": DEFAULT_MODE,
                "scope": DEFAULT_SCOPE,
            },
            "tensors": {
                "quantized_modules": quantized_modules,
                "copied": copied_tensors,
                "omitted_tied": sorted(omitted_tensors),
            },
            "files": output_files,
        }
        _atomic_json(staging / RUNTIME_MANIFEST, manifest)
        verified = verify_quantized_runtime(
            staging,
            source_dir=source,
            expected_bits=bits,
            expected_group_size=group_size,
            expected_mode=DEFAULT_MODE,
            expected_scope=DEFAULT_SCOPE,
        )
        if not verified.valid:
            raise QwenRuntimeConversionError(
                "staging runtime 驗證失敗：" + ",".join(verified.errors)
            )
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists() or output.is_symlink():
            raise QwenRuntimeConversionError(f"finalize 前 output 已經出現：{output}")
        os.replace(staging, output)
        return RuntimeConversionResult(output, manifest, False, moved_invalid_to)
    except Exception:
        if staging.exists() or staging.is_symlink():
            _move_to_trash(staging, trash)
        raise


__all__ = [
    "CONVERTER_SCHEMA",
    "DEFAULT_BITS",
    "DEFAULT_GROUP_SIZE",
    "QwenRuntimeConversionCancelled",
    "QwenRuntimeConversionError",
    "RUNTIME_MANIFEST",
    "RuntimeConversionResult",
    "RuntimeVerification",
    "convert_qwen_runtime",
    "runtime_output_path",
    "verify_quantized_runtime",
]
