"""Small, public-only Threads media adapter.

Threads has no upstream yt-dlp extractor at the moment. This adapter is
intentionally conservative: it tries the public GraphQL response, then parses
the exact post from the bounded page JSON Meta serves to link-preview crawlers.
It never sends cookies or credentials and only returns HTTPS media URLs from
Meta-owned CDN hosts. If Meta changes the public page contract, callers receive
a clear unsupported error instead of guessing or selecting a recommended post.
"""

from __future__ import annotations

import html
import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from html.parser import HTMLParser
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen


THREADS_GRAPHQL_ENDPOINT = "https://www.threads.com/api/graphql"
MAX_RESPONSE_BYTES = 8 * 1024 * 1024
_SHORTCODE_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
_CDN_HOST_SUFFIXES = (".fbcdn.net", ".cdninstagram.com", ".threads.net", ".threads.com")
_GOOGLEBOT_USER_AGENT = (
    "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
)
_POST_MEDIA_KEYS = frozenset(
    {"video_versions", "video_dash_manifest", "carousel_media"}
)
MAX_JSON_NODES = 200_000


class ThreadsPublicError(RuntimeError):
    """The public Threads page did not expose downloadable media."""


@dataclass(frozen=True)
class ThreadsMedia:
    url: str
    title: str | None = None


def _post_id(canonical_url: str) -> str:
    token = _target_shortcode(canonical_url)
    if token is None:
        raise ThreadsPublicError("threads_extractor_unavailable")
    value = 0
    for char in token:
        value = value * 64 + _SHORTCODE_ALPHABET.index(char)
    return str(value)


def _valid_shortcode(token: object) -> str | None:
    if (
        not isinstance(token, str)
        or not token
        or len(token) > 256
        or any(char not in _SHORTCODE_ALPHABET for char in token)
    ):
        return None
    return token


def _target_shortcode(value: str) -> str | None:
    parts = [part for part in urlsplit(value).path.rstrip("/").split("/") if part]
    for index, part in enumerate(parts[:-1]):
        if part == "post":
            return _valid_shortcode(parts[index + 1])
    if len(parts) == 2 and parts[0] == "t":
        return _valid_shortcode(parts[1])
    return None


class _ThreadsPageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.json_blocks: list[str] = []
        self.canonical_url: str | None = None
        self.video_url: str | None = None
        self.title: str | None = None
        self._script_parts: list[str] | None = None

    def handle_starttag(
        self, tag: str, attrs: list[tuple[str, str | None]]
    ) -> None:
        values = {key.lower(): value for key, value in attrs if value is not None}
        if tag.lower() == "script" and values.get("type", "").lower() == "application/json":
            self._script_parts = []
            return
        if tag.lower() != "meta":
            return
        property_name = (values.get("property") or values.get("name") or "").lower()
        content = values.get("content")
        if not content:
            return
        if property_name == "og:url":
            self.canonical_url = content
        elif property_name in {"og:video", "og:video:url", "og:video:secure_url"}:
            self.video_url = content
        elif property_name in {"og:title", "twitter:title"}:
            self.title = " ".join(content.split())[:180] or None

    def handle_data(self, data: str) -> None:
        if self._script_parts is not None:
            self._script_parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() != "script" or self._script_parts is None:
            return
        block = "".join(self._script_parts)
        self._script_parts = None
        if block and len(block) <= MAX_RESPONSE_BYTES and len(self.json_blocks) < 128:
            self.json_blocks.append(block)


def _read_limited(response: object) -> bytes:
    chunks: list[bytes] = []
    total = 0
    while True:
        block = response.read(min(64 * 1024, MAX_RESPONSE_BYTES - total + 1))  # type: ignore[attr-defined]
        if not block:
            break
        total += len(block)
        if total > MAX_RESPONSE_BYTES:
            raise ThreadsPublicError("threads_response_too_large")
        chunks.append(block)
    return b"".join(chunks)


def _safe_cdn_url(value: object) -> str | None:
    if not isinstance(value, str) or len(value) > 8192:
        return None
    candidate = html.unescape(value).replace("\\/", "/")
    try:
        split = urlsplit(candidate)
    except ValueError:
        return None
    host = (split.hostname or "").lower()
    if split.scheme != "https" or not host.endswith(_CDN_HOST_SUFFIXES):
        return None
    return candidate


def _find_video(value: object) -> tuple[str, str | None] | None:
    stack: list[tuple[object, str | None]] = [(value, None)]
    visited = 0
    while stack:
        current, inherited_title = stack.pop()
        visited += 1
        if visited > MAX_JSON_NODES:
            return None
        if isinstance(current, Mapping):
            title = inherited_title
            caption = current.get("caption")
            if isinstance(caption, Mapping) and isinstance(caption.get("text"), str):
                title = " ".join(caption["text"].split())[:180] or title
            versions = current.get("video_versions")
            if isinstance(versions, list):
                for item in versions:
                    if isinstance(item, Mapping):
                        url = _safe_cdn_url(item.get("url"))
                        if url:
                            return url, title
            for key in ("video_url", "videoUrl"):
                url = _safe_cdn_url(current.get(key))
                if url:
                    return url, title
            stack.extend((child, title) for child in reversed(tuple(current.values())))
        elif isinstance(current, list):
            stack.extend((child, inherited_title) for child in reversed(current))
    return None


def _find_post_video(value: object, target_code: str) -> tuple[str, str | None] | None:
    stack: list[object] = [value]
    visited = 0
    while stack:
        current = stack.pop()
        visited += 1
        if visited > MAX_JSON_NODES:
            return None
        if isinstance(current, Mapping):
            if current.get("code") == target_code and current.keys() & _POST_MEDIA_KEYS:
                return _find_video(current)
            stack.extend(reversed(tuple(current.values())))
        elif isinstance(current, list):
            stack.extend(reversed(current))
    return None


def _find_crawler_video(body: bytes, target_code: str | None) -> ThreadsMedia | None:
    parser = _ThreadsPageParser()
    try:
        parser.feed(body.decode("utf-8", errors="replace"))
        parser.close()
    except (ValueError, TypeError):
        return None
    canonical_code = _target_shortcode(parser.canonical_url or "")
    selected_code = target_code or canonical_code
    if selected_code is None or (canonical_code is not None and canonical_code != selected_code):
        return None
    for block in parser.json_blocks:
        try:
            payload = json.loads(html.unescape(block))
        except (json.JSONDecodeError, RecursionError, TypeError, ValueError):
            continue
        found = _find_post_video(payload, selected_code)
        if found:
            return ThreadsMedia(found[0], found[1] or parser.title)
    meta_video = _safe_cdn_url(parser.video_url)
    if meta_video:
        return ThreadsMedia(meta_video, parser.title)
    return None


def fetch_public_thread(
    canonical_url: str,
    *,
    opener: Callable[..., object] = urlopen,
    timeout: float = 20.0,
) -> ThreadsMedia:
    """Fetch one public video URL without cookies or browser state."""

    target_code = _target_shortcode(canonical_url)
    if target_code is not None:
        variables = json.dumps({"postID": _post_id(canonical_url)}, separators=(",", ":"))
        form = urlencode(
            {
                "av": "0",
                "__user": "0",
                "__a": "1",
                "__req": "1",
                "fb_api_caller_class": "RelayModern",
                "fb_api_req_friendly_name": "BarcelonaPostPageQuery",
                "variables": variables,
                "server_timestamps": "true",
                # Retain the old public query as a fast path. It rotates, so
                # the crawler-rendered page below is the durable fallback.
                "doc_id": "5587632691339264",
            }
        ).encode("ascii")
        request = Request(
            THREADS_GRAPHQL_ENDPOINT,
            data=form,
            headers={
                "content-type": "application/x-www-form-urlencoded",
                "accept": "application/json",
                "user-agent": "CantoneseTranscriptStudio/0.8",
            },
            method="POST",
        )
        try:
            with opener(request, timeout=timeout) as response:  # type: ignore[misc]
                payload = json.loads(_read_limited(response).decode("utf-8"))
        except (
            HTTPError,
            URLError,
            OSError,
            json.JSONDecodeError,
            RecursionError,
            ValueError,
            TypeError,
            ThreadsPublicError,
        ):
            payload = None
        found = _find_post_video(payload, target_code)
        if found:
            return ThreadsMedia(found[0], found[1])

    # Logged-out browser HTML is only a login shell. Threads still server-renders
    # the exact post for link-preview crawlers; parse the bounded JSON and match
    # the requested shortcode so a recommended video can never be substituted.
    page_request = Request(
        canonical_url,
        headers={"accept": "text/html", "user-agent": _GOOGLEBOT_USER_AGENT},
    )
    try:
        with opener(page_request, timeout=timeout) as response:  # type: ignore[misc]
            page = _read_limited(response)
    except (HTTPError, URLError, OSError, ValueError, TypeError, ThreadsPublicError) as exc:
        raise ThreadsPublicError("threads_extractor_unavailable") from exc
    media = _find_crawler_video(page, target_code)
    if media:
        return media
    raise ThreadsPublicError("threads_extractor_unavailable")
