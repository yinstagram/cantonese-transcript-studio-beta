"""Deterministic six-format exports for downloaded canonical captions."""

from __future__ import annotations

import csv
import io
import json
import os
import tempfile
from pathlib import Path

from .captions import CaptionCue, serialize_srt, serialize_vtt


def _atomic_text(path: Path, value: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise
    return path


def _timestamp(milliseconds: int, decimal: str = ".") -> str:
    hours, remainder = divmod(max(0, int(milliseconds)), 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}{decimal}{millis:03d}"


def export_caption_bundle(
    cues: tuple[CaptionCue, ...] | list[CaptionCue],
    output_directory: str | Path,
    *,
    video_id: str,
    language: str,
    source: str,
) -> dict[str, str]:
    destination = Path(output_directory).expanduser().resolve(strict=False)
    destination.mkdir(parents=True, exist_ok=True)
    values = tuple(cues)
    plain = "\n".join(cue.text for cue in values)
    timestamped = "\n".join(
        f"[{_timestamp(cue.start_ms)} → {_timestamp(cue.end_ms)}] {cue.text}"
        for cue in values
    )
    json_value = {
        "schema": 1,
        "source": "youtube_caption",
        "video_id": video_id,
        "language": language,
        "caption_source": source,
        "text": plain,
        "segments": [
            {
                "index": index,
                "start_ms": cue.start_ms,
                "end_ms": cue.end_ms,
                "start": round(cue.start_ms / 1000.0, 3),
                "end": round(cue.end_ms / 1000.0, 3),
                "text": cue.text,
            }
            for index, cue in enumerate(values, start=1)
        ],
    }
    csv_buffer = io.StringIO(newline="")
    writer = csv.DictWriter(
        csv_buffer,
        fieldnames=(
            "index",
            "video_id",
            "language",
            "caption_source",
            "start",
            "end",
            "start_ms",
            "end_ms",
            "text",
        ),
        lineterminator="\n",
    )
    writer.writeheader()
    for index, cue in enumerate(values, start=1):
        writer.writerow(
            {
                "index": index,
                "video_id": video_id,
                "language": language,
                "caption_source": source,
                "start": f"{cue.start_ms / 1000.0:.3f}",
                "end": f"{cue.end_ms / 1000.0:.3f}",
                "start_ms": cue.start_ms,
                "end_ms": cue.end_ms,
                "text": cue.text,
            }
        )
    paths = {
        "txt": _atomic_text(destination / "transcript.txt", plain + ("\n" if plain else "")),
        "timestamp_txt": _atomic_text(
            destination / "transcript-with-timestamps.txt",
            timestamped + ("\n" if timestamped else ""),
        ),
        "srt": _atomic_text(destination / "subtitles.srt", serialize_srt(values)),
        "vtt": _atomic_text(destination / "subtitles.vtt", serialize_vtt(values)),
        "json": _atomic_text(
            destination / "transcript.json",
            json.dumps(json_value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        ),
        "csv": _atomic_text(destination / "segments.csv", csv_buffer.getvalue()),
    }
    return {name: str(path) for name, path in paths.items()}
