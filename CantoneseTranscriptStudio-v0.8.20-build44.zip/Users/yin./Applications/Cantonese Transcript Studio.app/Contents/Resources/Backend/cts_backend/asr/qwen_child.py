"""Private child entry point used by :mod:`cts_backend.asr.qwen_process`."""

from __future__ import annotations

import argparse
import math
import os
import signal
import threading
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from .qwen import QwenASR
from .qwen_process import (
    PROTOCOL_VERSION,
    atomic_write_json,
    completed_batch_manifest,
    failed_batch_manifest,
    load_request,
    segment_protocol_payload,
    verify_request_inputs,
)


def local_chunk_progress(event: Mapping[str, Any]) -> float | None:
    """Extract only Qwen's explicit per-chunk fraction.

    Events without ``model_event`` are stage-global completion updates emitted
    by ``QwenASR``.  Forwarding them as local progress would apply the chunk
    prefix twice in the parent and can make the visible progress go backwards.
    """

    model_event = event.get("model_event")
    if not isinstance(model_event, Mapping):
        return None
    fraction = model_event.get("progress")
    if fraction is None or isinstance(fraction, bool):
        return None
    try:
        numeric = float(fraction)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(numeric):
        return None
    return min(1.0, max(0.0, numeric))
from .types import AudioChunk


class _JSONLineWriter:
    def __init__(self, descriptor: int) -> None:
        self._handle = os.fdopen(descriptor, "w", encoding="utf-8", buffering=1, closefd=True)
        self._lock = threading.Lock()

    def emit(self, event: str, **values: Any) -> None:
        import json

        # Callers only pass numeric/control metadata.  Context, model text and
        # exception messages never enter this channel.
        payload = {"protocol_version": PROTOCOL_VERSION, "event": event, **values}
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        with self._lock:
            self._handle.write(encoded + "\n")
            self._handle.flush()

    def close(self) -> None:
        with self._lock:
            self._handle.close()


def _watch_parent(expected_parent_pid: int, stop: threading.Event) -> None:
    while not stop.wait(0.25):
        if os.getppid() != expected_parent_pid:
            # The supervisor disappeared without executing its finally block.
            # Kill our complete session, including any native/helper child, so
            # an abruptly killed supervisor cannot orphan inference work.
            os.killpg(os.getpgrp(), signal.SIGKILL)
            os._exit(73)


def _heartbeat(writer: _JSONLineWriter, interval: float, stop: threading.Event) -> None:
    while not stop.wait(interval):
        writer.emit("heartbeat")


def _failure_category(exc: BaseException) -> str:
    if isinstance(exc, (ValueError, KeyError, TypeError)):
        return "protocol_error"
    if isinstance(exc, FileNotFoundError):
        return "input_error"
    if isinstance(exc, RuntimeError):
        return "runtime_error"
    return "child_crash"


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--event-fd", type=int, required=True)
    parser.add_argument("--segment-fd", type=int, required=True)
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--attempt", type=int, required=True)
    parser.add_argument("--heartbeat-seconds", type=float, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    if arguments.attempt < 1:
        return 64
    if not math.isfinite(arguments.heartbeat_seconds) or arguments.heartbeat_seconds <= 0:
        return 64
    if os.getsid(0) != os.getpid() or os.getpgrp() != os.getpid():
        # The parent promises an isolated session/process group so its bounded
        # TERM -> KILL path cannot affect an unrelated process tree.
        return 64
    writer = _JSONLineWriter(arguments.event_fd)
    segment_writer = _JSONLineWriter(arguments.segment_fd)
    stop = threading.Event()
    parent_thread = threading.Thread(
        target=_watch_parent,
        args=(arguments.parent_pid, stop),
        name="qwen-parent-watch",
        daemon=True,
    )
    heartbeat_thread = threading.Thread(
        target=_heartbeat,
        args=(writer, arguments.heartbeat_seconds, stop),
        name="qwen-heartbeat",
        daemon=True,
    )
    parent_thread.start()
    heartbeat_thread.start()
    request: Mapping[str, Any] | None = None
    try:
        request = load_request(arguments.request)
        verify_request_inputs(request)
        writer.emit("ready")
        raw_chunks = request.get("chunks")
        if not isinstance(raw_chunks, list) or not raw_chunks:
            raise ValueError("Qwen child requires a non-empty batch")
        chunks = [AudioChunk.coerce(item) for item in raw_chunks]
        completed_ids: list[str] = []

        def progress(event: dict[str, Any]) -> None:
            # QwenASR's outer progress is already stage-global.  The supervisor
            # and pipeline need the model's per-chunk fraction, otherwise the
            # pipeline applies the chunk prefix/duration a second time.
            numeric = local_chunk_progress(event)
            if numeric is not None:
                writer.emit(
                    "progress",
                    chunk_id=str(event.get("chunk_id", "")),
                    fraction=numeric,
                )
                return
            phase = str(event.get("phase", ""))
            if phase in {
                "primary_model_loading",
                "primary_model_ready",
                "primary_decoding",
            }:
                writer.emit(
                    "phase",
                    phase=phase,
                    chunk_id=str(event.get("chunk_id") or chunks[0].id),
                )

        def segment_completed(segment: Any) -> None:
            ordinal = len(completed_ids)
            segment_writer.emit(
                "segment",
                request_id=str(request["request_id"]),
                chunk_id=str(segment.id),
                ordinal=ordinal,
                segment=segment_protocol_payload(segment),
            )
            completed_ids.append(str(segment.id))

        adapter = QwenASR(
            Path(str(request["model_path"])),
            context=str(request.get("context", "")),
            language=str(request.get("language", "Cantonese")),
        )
        segments = adapter.transcribe_chunks(
            chunks,
            progress=progress,
            initial_previous_text=str(request.get("initial_previous_text", "")),
            processed_duration=float(request.get("processed_duration", 0.0)),
            total_duration=float(request["total_duration"])
            if request.get("total_duration") is not None
            else None,
            segment_completed=segment_completed,
        )
        expected_ids = [chunk.id for chunk in chunks]
        if len(segments) != len(chunks) or completed_ids != expected_ids:
            raise RuntimeError("Qwen child did not produce the requested ordered batch")
        atomic_write_json(
            arguments.result,
            completed_batch_manifest(
                request,
                attempt=arguments.attempt,
                completed_chunk_ids=completed_ids,
            ),
        )
        writer.emit("stage_complete")
        return 0
    except Exception as exc:
        category = _failure_category(exc)
        atomic_write_json(
            arguments.result,
            failed_batch_manifest(
                request,
                attempt=arguments.attempt,
                category=category,
                error_type=type(exc).__name__,
            ),
        )
        writer.emit("error", category=category, error_type=type(exc).__name__)
        return 70
    finally:
        stop.set()
        parent_thread.join(timeout=0.5)
        heartbeat_thread.join(timeout=0.5)
        writer.close()
        segment_writer.close()


if __name__ == "__main__":
    raise SystemExit(main())
