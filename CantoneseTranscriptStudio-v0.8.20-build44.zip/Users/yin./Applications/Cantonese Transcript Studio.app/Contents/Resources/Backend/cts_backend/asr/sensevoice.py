"""Offline SenseVoice Small Yue candidate used for controlled ASR benchmarks."""

from __future__ import annotations

import gc
import wave
from pathlib import Path
from typing import Any, Callable, Iterable

from .sherpa import _read_pcm16_mono
from .types import ASRCancelled, AudioChunk, TranscriptSegment, VerifierToken

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]


def _wav_duration(path: Path) -> float:
    with wave.open(str(path), "rb") as source:
        if source.getframerate() <= 0:
            raise ValueError(f"WAV sample rate 無效：{path}")
        return source.getnframes() / source.getframerate()


def _token_text(tokens: list[VerifierToken]) -> str:
    return "".join(item.token.replace("▁", " ") for item in tokens).strip()


class SenseVoiceYueCandidate:
    """Run the ASLP-lab WSYue fine-tuned SenseVoice Small INT8 model locally.

    This adapter is intentionally separate from the production verifier. It lets
    benchmark code compare raw model output without silently changing the current
    reconciliation pipeline.
    """

    def __init__(
        self,
        model_dir: Path,
        *,
        num_threads: int = 2,
        recognizer_factory: Callable[..., Any] | None = None,
    ) -> None:
        self.model_dir = Path(model_dir)
        if not 1 <= num_threads <= 8:
            raise ValueError("SenseVoice num_threads 必須係 1 至 8")
        self.num_threads = num_threads
        self._recognizer_factory = recognizer_factory

    def _validate_local(self) -> tuple[Path, Path]:
        model = self.model_dir / "model.int8.onnx"
        tokens = self.model_dir / "tokens.txt"
        if not model.is_file() or not tokens.is_file():
            raise FileNotFoundError(f"SenseVoice Yue local model 不完整：{self.model_dir}")
        return model, tokens

    def transcribe_wav(
        self,
        wav_path: Path,
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> list[TranscriptSegment]:
        path = Path(wav_path).expanduser().resolve()
        duration = _wav_duration(path)
        return self.transcribe_chunks(
            [AudioChunk(id=path.stem, path=path, start=0.0, end=duration)],
            progress=progress,
            cancelled=cancelled,
        )

    def transcribe_chunks(
        self,
        chunks: Iterable[AudioChunk | dict[str, Any] | Any],
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> list[TranscriptSegment]:
        model, tokens_path = self._validate_local()
        items = [AudioChunk.coerce(item) for item in chunks]
        if self._recognizer_factory is None:
            try:
                import sherpa_onnx
            except ImportError as exc:
                raise RuntimeError("runtime 未安裝 sherpa-onnx==1.13.4") from exc
            factory = sherpa_onnx.OfflineRecognizer.from_sense_voice
        else:
            factory = self._recognizer_factory

        recognizer = factory(
            model=str(model),
            tokens=str(tokens_path),
            num_threads=self.num_threads,
            sample_rate=16000,
            feature_dim=80,
            decoding_method="greedy_search",
            provider="cpu",
            language="yue",
            use_itn=False,
        )
        output: list[TranscriptSegment] = []
        total_duration = sum(chunk.duration for chunk in items)
        processed = 0.0
        try:
            for index, chunk in enumerate(items, start=1):
                if cancelled and cancelled():
                    raise ASRCancelled("已取消 SenseVoice Yue transcription")
                samples, sample_rate = _read_pcm16_mono(chunk.path)
                stream = recognizer.create_stream()
                stream.accept_waveform(sample_rate, samples)
                recognizer.decode_stream(stream)
                result = stream.result
                raw_tokens = list(getattr(result, "tokens", []) or [])
                raw_times = list(getattr(result, "timestamps", []) or [])
                raw_probs = list(getattr(result, "ys_log_probs", []) or [])
                token_items: list[VerifierToken] = []
                for token_index, (token, relative) in enumerate(zip(raw_tokens, raw_times)):
                    probability = raw_probs[token_index] if token_index < len(raw_probs) else None
                    absolute = chunk.start + float(relative)
                    within_end = (
                        absolute <= chunk.transcript_end
                        if index == len(items)
                        else absolute < chunk.transcript_end
                    )
                    if chunk.transcript_start <= absolute and within_end:
                        token_items.append(
                            VerifierToken(
                                token=str(token),
                                timestamp=absolute,
                                log_probability=(
                                    float(probability) if probability is not None else None
                                ),
                            )
                        )
                if len(token_items) == len(raw_tokens):
                    text = str(getattr(result, "text", ""))
                elif token_items:
                    text = _token_text(token_items)
                else:
                    text = str(getattr(result, "text", ""))
                output.append(
                    TranscriptSegment(
                        id=chunk.id,
                        start=chunk.transcript_start,
                        end=chunk.transcript_end,
                        text=text,
                        source="candidate_sensevoice_yue",
                        tokens=token_items,
                        metadata={
                            "model_path": str(self.model_dir),
                            "language": str(getattr(result, "lang", "") or "yue"),
                            "emotion": str(getattr(result, "emotion", "") or ""),
                            "event": str(getattr(result, "event", "") or ""),
                            "confidence_available": bool(raw_probs),
                            "token_timestamps_available": bool(raw_times),
                        },
                    )
                )
                processed += chunk.duration
                if progress:
                    progress(
                        {
                            "phase": "candidate_sensevoice_yue",
                            "chunk_id": chunk.id,
                            "chunk_index": index,
                            "chunk_total": len(items),
                            "progress": processed / total_duration if total_duration else 1.0,
                        }
                    )
                del samples, stream, result
            return output
        finally:
            del recognizer
            gc.collect()


def format_timestamp(seconds: float) -> str:
    milliseconds = max(0, round(seconds * 1000))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"


def timestamp_txt(segments: Iterable[TranscriptSegment], *, include_tokens: bool = False) -> str:
    lines: list[str] = []
    for segment in segments:
        lines.append(
            f"[{format_timestamp(segment.start)} --> {format_timestamp(segment.end)}] "
            f"{segment.text.strip()}"
        )
        if include_tokens and segment.tokens:
            token_line = " ".join(
                f"[{format_timestamp(token.timestamp)}] {token.token}" for token in segment.tokens
            )
            lines.append(f"tokens: {token_line}")
    return "\n".join(lines).rstrip() + ("\n" if lines else "")
