"""Crash-safe persistence for transcript-derived local AI artifacts."""

from __future__ import annotations

import fcntl
import hashlib
import hmac
import json
import os
import re
import tempfile
import threading
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, Mapping


DERIVED_SCHEMA = 1
DERIVED_DIRECTORY = "derived"
INSIGHTS_FILENAME = "insights.json"
MAX_DERIVED_BYTES = 32 * 1024 * 1024
MAX_TRANSLATED_TEXT_CHARACTERS = 4_000
MAX_TRANSLATED_TEXT_BYTES = 16_000
_LANGUAGE_TAG = re.compile(r"[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8}){0,3}")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _payload_sha256(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sealed(value: Mapping[str, Any]) -> dict[str, Any]:
    payload = dict(value)
    payload.pop("payload_sha256", None)
    payload["payload_sha256"] = _payload_sha256(payload)
    return payload


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
        directory_descriptor = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)
    except BaseException:
        try:
            failed = path.parent / ".failed-writes"
            failed.mkdir(exist_ok=True)
            if temporary.exists():
                os.replace(temporary, failed / f"{path.name}-{os.getpid()}-{threading.get_ident()}")
        except OSError:
            pass
        raise


class DerivedArtifactStore:
    """Own fixed, integrity-checked files under one canonical job workspace."""

    def __init__(self, jobs_root: str | Path) -> None:
        self.jobs_root = Path(jobs_root).expanduser().resolve()
        self.jobs_root.mkdir(parents=True, exist_ok=True)
        self._thread_lock = threading.RLock()

    def _workspace(self, workspace: str | Path, job_id: str) -> Path:
        if not job_id or Path(job_id).name != job_id or job_id in {".", ".."}:
            raise ValueError("derived job id 無效")
        candidate = Path(workspace).expanduser()
        if candidate.is_symlink() or not candidate.is_dir():
            raise FileNotFoundError("derived job workspace 唔存在")
        root = self.jobs_root.resolve(strict=True)
        resolved = candidate.resolve(strict=True)
        try:
            resolved.relative_to(root)
        except ValueError as exc:
            raise ValueError("derived workspace 超出 Jobs 目錄") from exc
        if resolved.name != job_id:
            raise ValueError("derived workspace 同 job id 唔一致")
        return resolved

    @staticmethod
    def _translation_filename(target_language: str) -> str:
        if not isinstance(target_language, str) or _LANGUAGE_TAG.fullmatch(target_language) is None:
            raise ValueError("translation target language 無效")
        return f"translation-{target_language.lower()}.json"

    def path_for(
        self,
        workspace: str | Path,
        job_id: str,
        *,
        kind: str,
        target_language: str | None = None,
    ) -> Path:
        root = self._workspace(workspace, job_id) / DERIVED_DIRECTORY
        if kind == "insights" and target_language is None:
            return root / INSIGHTS_FILENAME
        if kind == "translation" and target_language is not None:
            return root / self._translation_filename(target_language)
        raise ValueError("derived artifact kind 無效")

    @contextmanager
    def _locked(self, path: Path) -> Iterator[None]:
        with self._thread_lock:
            path.parent.mkdir(parents=True, exist_ok=True)
            lock_path = path.with_suffix(path.suffix + ".lock")
            with lock_path.open("a+b") as handle:
                os.chmod(lock_path, 0o600)
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    @staticmethod
    def _read_path(path: Path) -> dict[str, Any]:
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(path.name)
        if path.stat().st_size > MAX_DERIVED_BYTES:
            raise ValueError("derived artifact 太大")
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("derived artifact 已損壞") from exc
        if not isinstance(value, dict):
            raise ValueError("derived artifact schema 無效")
        expected = value.get("payload_sha256")
        payload = dict(value)
        payload.pop("payload_sha256", None)
        actual = _payload_sha256(payload)
        if not isinstance(expected, str) or not hmac.compare_digest(expected, actual):
            raise ValueError("derived artifact integrity seal 無效")
        if value.get("schema") != DERIVED_SCHEMA:
            raise ValueError("derived artifact schema version 無效")
        return value

    def read(
        self,
        workspace: str | Path,
        job_id: str,
        *,
        kind: str,
        target_language: str | None = None,
        source_final_sha256: str | None = None,
        project_revision: int | None = None,
    ) -> dict[str, Any]:
        path = self.path_for(
            workspace,
            job_id,
            kind=kind,
            target_language=target_language,
        )
        try:
            value = self._read_path(path)
        except FileNotFoundError:
            return {
                "schema": DERIVED_SCHEMA,
                "kind": kind,
                "job_id": job_id,
                "target_language": target_language,
                "state": "missing",
                "progress": 0.0,
            }
        except ValueError as exc:
            return {
                "schema": DERIVED_SCHEMA,
                "kind": kind,
                "job_id": job_id,
                "target_language": target_language,
                "state": "corrupt",
                "progress": 0.0,
                "error": str(exc),
            }
        if value.get("kind") != kind or value.get("job_id") != job_id:
            return {**value, "state": "corrupt", "error": "derived artifact identity 無效"}
        if kind == "translation" and value.get("target_language") != target_language:
            return {**value, "state": "corrupt", "error": "translation language identity 無效"}
        stale = False
        if source_final_sha256 is not None and value.get("source_final_sha256") != source_final_sha256:
            stale = True
        if project_revision is not None and value.get("project_revision") != project_revision:
            stale = True
        if stale:
            return {**value, "state": "stale", "stale": True}
        return {**value, "stale": False}

    def prepare(
        self,
        workspace: str | Path,
        job_id: str,
        *,
        kind: str,
        source_final_sha256: str,
        target_language: str | None = None,
        project_revision: int | None = None,
        resume_result: Mapping[str, Any] | None = None,
        resume_model: str | None = None,
        expected_payload_sha256: str | None = None,
        expected_state: str | None = None,
    ) -> dict[str, Any]:
        if not isinstance(source_final_sha256, str) or not source_final_sha256.startswith("sha256:"):
            raise ValueError("source final SHA 無效")
        if kind == "translation" and (
            isinstance(project_revision, bool) or not isinstance(project_revision, int) or project_revision < 1
        ):
            raise ValueError("translation project revision 無效")
        if resume_result is not None and kind != "translation":
            raise ValueError("只有 translation 可以保留 partial result")
        if resume_result is not None and (
            not isinstance(resume_model, str) or not resume_model.strip()
        ):
            raise ValueError("translation resume model 無效")
        if expected_payload_sha256 is not None and (
            not isinstance(expected_payload_sha256, str)
            or len(expected_payload_sha256) != 64
            or any(character not in "0123456789abcdef" for character in expected_payload_sha256.lower())
        ):
            raise ValueError("derived expected payload SHA 無效")
        if expected_state not in {None, "missing", "corrupt"}:
            raise ValueError("derived expected state 無效")
        if expected_payload_sha256 is not None and expected_state is not None:
            raise ValueError("derived CAS 只可以指定 payload SHA 或 state")
        path = self.path_for(
            workspace,
            job_id,
            kind=kind,
            target_language=target_language,
        )
        now = _utc_now()
        value = {
            "schema": DERIVED_SCHEMA,
            "kind": kind,
            "job_id": job_id,
            "target_language": target_language,
            "source_final_sha256": source_final_sha256,
            "project_revision": project_revision,
            "token": str(uuid.uuid4()),
            "state": "queued",
            "progress": 0.0,
            "cancel_requested": False,
            "created_at": now,
            "started_at": None,
            "completed_at": None,
            "result": None,
            "resume_result": dict(resume_result) if resume_result is not None else None,
            "resume_model": resume_model,
            "resume_payload_sha256": expected_payload_sha256,
            "error": None,
            "lifecycle": [],
        }
        sealed = _sealed(value)
        with self._locked(path):
            if expected_payload_sha256 is not None:
                current = self._read_path(path)
                current_sha = current.get("payload_sha256")
                if not isinstance(current_sha, str) or not hmac.compare_digest(
                    current_sha,
                    expected_payload_sha256,
                ):
                    raise ValueError("derived artifact 已被另一個操作更新")
            elif expected_state == "missing":
                if path.exists() or path.is_symlink():
                    raise ValueError("derived artifact 已被另一個操作建立")
            elif expected_state == "corrupt":
                try:
                    self._read_path(path)
                except ValueError:
                    pass
                except FileNotFoundError as exc:
                    raise ValueError("derived artifact 已被另一個操作更新") from exc
                else:
                    raise ValueError("derived artifact 已被另一個操作更新")
            _atomic_json(path, sealed)
        return sealed

    def update(
        self,
        workspace: str | Path,
        job_id: str,
        *,
        kind: str,
        token: str,
        target_language: str | None = None,
        **changes: Any,
    ) -> dict[str, Any]:
        path = self.path_for(
            workspace,
            job_id,
            kind=kind,
            target_language=target_language,
        )
        with self._locked(path):
            value = self._read_path(path)
            if value.get("token") != token:
                raise ValueError("stale derived task token")
            value.pop("payload_sha256", None)
            value.update(changes)
            sealed = _sealed(value)
            _atomic_json(path, sealed)
        return sealed

    def update_completed_translation_cue(
        self,
        workspace: str | Path,
        job_id: str,
        *,
        target_language: str,
        source_final_sha256: str,
        project_revision: int,
        cue_id: str,
        translated_text: str,
        expected_payload_sha256: str,
    ) -> dict[str, Any]:
        """CAS-update only one translated cue while preserving source evidence."""

        if not isinstance(cue_id, str) or not cue_id or Path(cue_id).name != cue_id:
            raise ValueError("translation cue id 無效")
        if not isinstance(translated_text, str) or not translated_text.strip():
            raise ValueError("翻譯字幕唔可以留空")
        if (
            len(translated_text) > MAX_TRANSLATED_TEXT_CHARACTERS
            or len(translated_text.encode("utf-8")) > MAX_TRANSLATED_TEXT_BYTES
        ):
            raise ValueError("翻譯字幕太長")
        if any(ord(character) < 32 and character not in {"\n", "\t"} for character in translated_text):
            raise ValueError("翻譯字幕包含無效控制字元")
        if (
            not isinstance(expected_payload_sha256, str)
            or len(expected_payload_sha256) != 64
            or any(character not in "0123456789abcdef" for character in expected_payload_sha256)
        ):
            raise ValueError("translation expected payload SHA 無效")

        path = self.path_for(
            workspace,
            job_id,
            kind="translation",
            target_language=target_language,
        )
        with self._locked(path):
            value = self._read_path(path)
            current_sha = value.get("payload_sha256")
            if not isinstance(current_sha, str) or not hmac.compare_digest(
                current_sha,
                expected_payload_sha256,
            ):
                raise ValueError("翻譯字幕已被另一個操作更新，請重新載入")
            if (
                value.get("kind") != "translation"
                or value.get("job_id") != job_id
                or value.get("target_language") != target_language
                or value.get("source_final_sha256") != source_final_sha256
                or value.get("project_revision") != project_revision
            ):
                raise ValueError("翻譯字幕同目前逐字稿版本唔一致")
            result = value.get("result")
            if (
                value.get("state") != "completed"
                or not isinstance(result, Mapping)
                or result.get("status") != "completed"
            ):
                raise ValueError("翻譯未完整完成，暫時唔可以編輯")
            raw_cues = result.get("cues")
            if not isinstance(raw_cues, list):
                raise ValueError("翻譯字幕資料已損壞")
            matching_indexes = [
                index
                for index, cue in enumerate(raw_cues)
                if isinstance(cue, Mapping) and cue.get("id") == cue_id
            ]
            if len(matching_indexes) != 1:
                raise ValueError("搵唔到唯一嘅翻譯字幕段落")

            index = matching_indexes[0]
            existing_cue = dict(raw_cues[index])
            previous_text = existing_cue.get("translated_text")
            if not isinstance(previous_text, str):
                raise ValueError("翻譯字幕資料已損壞")
            existing_cue["translated_text"] = translated_text
            updated_cues = list(raw_cues)
            updated_cues[index] = existing_cue
            updated_result = dict(result)
            updated_result["cues"] = updated_cues

            audit = value.get("human_edits")
            edit_history = list(audit) if isinstance(audit, list) else []
            edit_history.append(
                {
                    "cue_id": cue_id,
                    "edited_at": _utc_now(),
                    "before_sha256": hashlib.sha256(previous_text.encode("utf-8")).hexdigest(),
                    "after_sha256": hashlib.sha256(translated_text.encode("utf-8")).hexdigest(),
                }
            )
            value.pop("payload_sha256", None)
            value["result"] = updated_result
            value["human_edits"] = edit_history[-256:]
            value["human_edit_count"] = int(value.get("human_edit_count") or 0) + 1
            value["updated_at"] = _utc_now()
            sealed = _sealed(value)
            _atomic_json(path, sealed)
        return sealed

    def list_translations(
        self,
        workspace: str | Path,
        job_id: str,
        *,
        source_final_sha256: str,
        project_revision: int,
    ) -> list[dict[str, Any]]:
        root = self._workspace(workspace, job_id) / DERIVED_DIRECTORY
        if root.is_symlink() or not root.is_dir():
            return []
        output: list[dict[str, Any]] = []
        for path in sorted(root.glob("translation-*.json")):
            try:
                raw = self._read_path(path)
                target = raw.get("target_language")
                if not isinstance(target, str):
                    continue
                output.append(
                    self.read(
                        workspace,
                        job_id,
                        kind="translation",
                        target_language=target,
                        source_final_sha256=source_final_sha256,
                        project_revision=project_revision,
                    )
                )
            except (OSError, ValueError):
                continue
        return output

    def recover(self) -> list[tuple[str, str, str | None, str]]:
        """Requeue durable queued tasks and fail interrupted in-flight tasks."""

        queued: list[tuple[str, str, str | None, str]] = []
        for workspace in sorted(self.jobs_root.iterdir()):
            if workspace.is_symlink() or not workspace.is_dir():
                continue
            derived = workspace / DERIVED_DIRECTORY
            if derived.is_symlink() or not derived.is_dir():
                continue
            for path in sorted(derived.glob("*.json")):
                try:
                    value = self._read_path(path)
                    kind = value.get("kind")
                    job_id = value.get("job_id")
                    target = value.get("target_language")
                    token = value.get("token")
                    if (
                        kind not in {"insights", "translation"}
                        or not isinstance(job_id, str)
                        or job_id != workspace.name
                        or not isinstance(token, str)
                    ):
                        continue
                    if value.get("state") == "queued":
                        queued.append((kind, job_id, target if isinstance(target, str) else None, token))
                    elif value.get("state") == "generating":
                        preserved_result = (
                            value.get("resume_result")
                            if kind == "translation"
                            and isinstance(value.get("resume_result"), Mapping)
                            else None
                        )
                        self.update(
                            workspace,
                            job_id,
                            kind=kind,
                            target_language=target if isinstance(target, str) else None,
                            token=token,
                            state="partial" if preserved_result is not None else "interrupted",
                            progress=1.0 if preserved_result is not None else 0.0,
                            cancel_requested=False,
                            completed_at=_utc_now(),
                            result=preserved_result,
                            resume_result=None,
                            resume_model=None,
                            error=(
                                "App 上次關閉前已保留完成部分；請重試未完成字幕。"
                                if preserved_result is not None
                                else "App 上次喺本機模型分析期間關閉，請重試。"
                            ),
                        )
                except (OSError, ValueError):
                    continue
        return queued


__all__ = ["DERIVED_SCHEMA", "DerivedArtifactStore"]
