"""Convert flat yt-dlp playlist metadata into independent per-video plans."""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Mapping, Sequence
from typing import Any
from urllib.parse import urlencode, urlunsplit

from .schemas import PlaylistEntryFailure, PlaylistEntryPlan, PlaylistPlan


MAX_PLAYLIST_ENTRIES = 2_000
_VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
_PLAYLIST_ID_RE = re.compile(r"^[A-Za-z0-9_-]{10,128}$")


def _display_title(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = unicodedata.normalize("NFC", value)
    cleaned = " ".join(
        "".join(char for char in normalized if unicodedata.category(char) != "Cc").split()
    )
    return cleaned[:180] or None


def _position(value: Any, fallback: int, total: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return fallback
    return number if 1 <= number <= total else fallback


def plan_flat_playlist(payload: Mapping[str, Any]) -> PlaylistPlan:
    if not isinstance(payload, Mapping):
        raise ValueError("playlist metadata 必須係 object")
    playlist_id = str(payload.get("id", ""))
    if _PLAYLIST_ID_RE.fullmatch(playlist_id) is None:
        raise ValueError("playlist metadata 缺少有效 id")
    raw_entries = payload.get("entries")
    if not isinstance(raw_entries, Sequence) or isinstance(raw_entries, (str, bytes)):
        raise ValueError("playlist entries 必須係 list")
    if len(raw_entries) > MAX_PLAYLIST_ENTRIES:
        raise ValueError("playlist entries 超出安全上限")

    total = len(raw_entries)
    plans: list[PlaylistEntryPlan] = []
    failures: list[PlaylistEntryFailure] = []
    seen: set[str] = set()
    for fallback, raw_entry in enumerate(raw_entries, start=1):
        if not isinstance(raw_entry, Mapping):
            failures.append(PlaylistEntryFailure(fallback, "unavailable_entry"))
            continue
        position = _position(raw_entry.get("playlist_index"), fallback, total)
        video_id = str(raw_entry.get("id", ""))
        if _VIDEO_ID_RE.fullmatch(video_id) is None:
            failures.append(PlaylistEntryFailure(position, "invalid_video_id"))
            continue
        if video_id in seen:
            failures.append(PlaylistEntryFailure(position, "duplicate_video_id"))
            continue
        seen.add(video_id)
        canonical = urlunsplit(
            ("https", "www.youtube.com", "/watch", urlencode({"v": video_id}), "")
        )
        plans.append(
            PlaylistEntryPlan(
                position=position,
                total=total,
                video_id=video_id,
                canonical_url=canonical,
                display_title=_display_title(raw_entry.get("title")),
            )
        )
    return PlaylistPlan(playlist_id, tuple(plans), tuple(failures), total)
