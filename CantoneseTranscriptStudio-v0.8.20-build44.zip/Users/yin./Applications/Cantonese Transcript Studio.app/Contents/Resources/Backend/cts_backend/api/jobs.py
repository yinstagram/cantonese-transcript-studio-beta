"""Canonical, UI-safe presentation of persistent job records."""

from __future__ import annotations

import json
import hashlib
import hmac
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping


UI_STATUS_BY_INTERNAL = {
    "created": "queued",
    "ready": "queued",
    "queued": "queued",
    "probing": "extracting_audio",
    "extracting": "extracting_audio",
    "chunking": "extracting_audio",
    "primary_asr": "primary_asr",
    "running": "primary_asr",
    "processing": "primary_asr",
    "transcribing": "primary_asr",
    "verifying": "verification_asr",
    "reconciling": "reconciling",
    "normalizing": "converting_hk",
    "exporting": "exporting",
    "completed": "completed",
    "failed": "failed",
    "canceled": "cancelled",
    "cancelled": "cancelled",
    "extracting_audio": "extracting_audio",
    "verification_asr": "verification_asr",
    "converting_hk": "converting_hk",
}

DISPLAY_STATUS = {
    "queued": "等待處理",
    "extracting_audio": "提取音訊",
    "primary_asr": "廣東話轉錄",
    "verification_asr": "雙模型驗證",
    "reconciling": "對照逐字稿",
    "converting_hk": "轉換香港繁體",
    "exporting": "匯出檔案",
    "completed": "已完成",
    "failed": "處理失敗",
    "cancelled": "已取消",
}

# Keep persistence/debug detail out of the ordinary queue UI.  Older releases
# stored DuplicateJobError's English exception text directly in job.json, so
# presentation must also translate historical records without rewriting them.
DUPLICATE_MEDIA_UI_MESSAGE = "呢個檔案已經喺工作列表，唔需要重複加入。"

_MAX_ARTIFACT_BYTES = 128 * 1024 * 1024


def _mapping(value: Any) -> dict[str, Any]:
    if hasattr(value, "to_dict") and callable(value.to_dict):
        value = value.to_dict()
    return dict(value) if isinstance(value, Mapping) else {}


def _state_value(value: Any) -> str:
    raw = getattr(value, "value", value)
    return str(raw or "queued").lower()


def _safe_json(workspace: Path, filename: str) -> dict[str, Any] | None:
    """Read one fixed artifact without following links outside the workspace."""
    try:
        root = workspace.resolve(strict=True)
        candidate = root / filename
        if candidate.is_symlink() or not candidate.is_file():
            return None
        resolved = candidate.resolve(strict=True)
        if resolved.parent != root or resolved.stat().st_size > _MAX_ARTIFACT_BYTES:
            return None
        value = json.loads(resolved.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError):
        return None
    return dict(value) if isinstance(value, Mapping) else None


def _completed_value(payload: dict[str, Any] | None) -> dict[str, Any]:
    if not payload or payload.get("schema") != 1 or payload.get("complete") is not True:
        return {}
    value = payload.get("value")
    if not isinstance(value, Mapping):
        return {}
    sealed: dict[str, Any] = {
        "fingerprint": payload.get("fingerprint"),
        "value": value,
    }
    if "artifacts" in payload:
        sealed["artifacts"] = payload.get("artifacts")
    encoded = json.dumps(
        sealed,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    expected = payload.get("payload_sha256")
    actual = hashlib.sha256(encoded).hexdigest()
    if not isinstance(expected, str) or not hmac.compare_digest(expected, actual):
        return {}
    return dict(value)


def _checkpoint_data(value: dict[str, Any], name: str) -> dict[str, Any]:
    checkpoints = value.get("checkpoints")
    checkpoint = checkpoints.get(name) if isinstance(checkpoints, Mapping) else None
    data = checkpoint.get("data") if isinstance(checkpoint, Mapping) else None
    return dict(data) if isinstance(data, Mapping) else {}


def _duration_seconds(value: dict[str, Any], metadata: dict[str, Any]) -> float | None:
    duration = value.get("duration")
    if isinstance(duration, (int, float)) and not isinstance(duration, bool):
        return max(0.0, float(duration))
    media = metadata.get("media")
    if not isinstance(media, Mapping):
        media = _checkpoint_data(value, "probed").get("media")
    if isinstance(media, Mapping):
        duration_ms = media.get("duration_ms")
        if isinstance(duration_ms, (int, float)) and not isinstance(duration_ms, bool):
            return max(0.0, float(duration_ms) / 1000.0)
    return None


def _error_message(value: Any) -> str | None:
    code: str | None = None
    if isinstance(value, Mapping):
        raw_code = value.get("code")
        code = str(raw_code).strip().lower() if raw_code else None
        message = value.get("message")
        message = str(message) if message else None
    else:
        message = str(value) if value else None
    if not message:
        return None
    lowered = message.casefold()
    if code in {"duplicate_job", "duplicate_source"} or any(
        marker in lowered
        for marker in (
            "media already exists in job",
            "duplicatejoberror",
        )
    ):
        return DUPLICATE_MEDIA_UI_MESSAGE
    return message


def _checkpoint_time(value: dict[str, Any], *, first: bool) -> str | None:
    checkpoints = value.get("checkpoints")
    if not isinstance(checkpoints, Mapping):
        return None
    times = [
        item.get("completed_at")
        for item in checkpoints.values()
        if isinstance(item, Mapping) and isinstance(item.get("completed_at"), str)
    ]
    if not times:
        return None
    return min(times) if first else max(times)


def _named_checkpoint_time(value: dict[str, Any], name: str) -> str | None:
    checkpoints = value.get("checkpoints")
    checkpoint = checkpoints.get(name) if isinstance(checkpoints, Mapping) else None
    completed_at = checkpoint.get("completed_at") if isinstance(checkpoint, Mapping) else None
    return completed_at if isinstance(completed_at, str) else None


def _elapsed_seconds(start: str | None, end: str | None) -> float | None:
    if not start or not end:
        return None
    try:
        start_time = datetime.fromisoformat(start.replace("Z", "+00:00"))
        end_time = datetime.fromisoformat(end.replace("Z", "+00:00"))
    except ValueError:
        return None
    return max(0.0, (end_time - start_time).total_seconds())


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def _safe_exports(
    workspace: Path,
    value: Mapping[str, Any],
    manifest: Any,
) -> dict[str, str]:
    output: dict[str, str] = {}
    try:
        workspace_root = workspace.resolve(strict=True)
        root = (workspace_root / "exports").resolve(strict=True)
        root.relative_to(workspace_root)
    except OSError:
        return output
    except ValueError:
        return output
    if not isinstance(manifest, list) or len(manifest) != len(value):
        return output
    records: dict[str, Mapping[str, Any]] = {}
    for raw_record in manifest:
        if not isinstance(raw_record, Mapping):
            return {}
        key = raw_record.get("key")
        if not isinstance(key, str) or key in records:
            return {}
        records[key] = raw_record
    if set(records) != set(value):
        return output
    for key, raw_path in value.items():
        if not isinstance(key, str) or not isinstance(raw_path, str):
            return {}
        record = records[key]
        relative_path = record.get("relative_path")
        expected_size = record.get("size")
        expected_sha256 = record.get("sha256")
        if (
            not isinstance(relative_path, str)
            or not relative_path
            or isinstance(expected_size, bool)
            or not isinstance(expected_size, int)
            or expected_size < 0
            or not isinstance(expected_sha256, str)
            or len(expected_sha256) != 64
        ):
            return {}
        candidate = Path(raw_path).expanduser()
        if not candidate.is_absolute():
            candidate = workspace_root / candidate
        try:
            if candidate.is_symlink() or not candidate.is_file():
                return {}
            resolved = candidate.resolve(strict=True)
            relative = resolved.relative_to(root)
            if str(relative) != relative_path:
                return {}
            stat = resolved.stat()
            if stat.st_size != expected_size or _file_sha256(resolved) != expected_sha256:
                return {}
        except (OSError, ValueError):
            return {}
        output[key] = str(resolved)
    return output


def present_job(record: Any) -> dict[str, Any]:
    """Return the stable worker/UI contract without mutating persistent state."""
    value = _mapping(record)
    metadata = _mapping(value.get("metadata"))
    internal = _state_value(value.get("state", value.get("status")))
    status = UI_STATUS_BY_INTERNAL.get(internal, "queued")
    job_id = str(value.get("job_id") or value.get("id") or "")
    source_path = str(value.get("source_path") or metadata.get("source_path") or "")
    workspace_raw = value.get("workspace") or value.get("workspace_path") or ""
    workspace = Path(str(workspace_raw)).expanduser() if workspace_raw else None

    document: dict[str, Any] = {}
    exports: dict[str, str] = {}
    if status == "completed" and workspace is not None:
        document = _completed_value(_safe_json(workspace, "final.json"))
        exports_payload = _safe_json(workspace, "exports.json")
        exports_value = _completed_value(exports_payload)
        exports = _safe_exports(
            workspace,
            exports_value,
            exports_payload.get("artifacts") if exports_payload else None,
        )

    raw_segments = document.get("segments")
    segments = [dict(item) for item in raw_segments if isinstance(item, Mapping)] if isinstance(raw_segments, list) else []
    low_confidence_count = sum(
        1
        for segment in segments
        if bool(_mapping(segment.get("audit")).get("low_confidence") or segment.get("low_confidence"))
    )

    vocabulary = document.get("vocabulary", metadata.get("vocabulary", ()))
    if not isinstance(vocabulary, (list, tuple)):
        vocabulary = ()
    vocabulary = [str(item) for item in vocabulary if isinstance(item, str) and item.strip()]

    started_at = document.get("processing_started_at", metadata.get("processing_started_at"))
    if not isinstance(started_at, str):
        started_at = _checkpoint_time(value, first=True)
    completed_at = document.get("processing_completed_at", metadata.get("processing_completed_at"))
    if not isinstance(completed_at, str):
        completed_at = _named_checkpoint_time(value, "exported") if status == "completed" else None
    if status == "completed" and completed_at is None:
        completed_at = value.get("updated_at") if isinstance(value.get("updated_at"), str) else None

    primary_model = document.get("model_primary") or metadata.get("primary_model")
    verifier_model = document.get("model_verifier") or metadata.get("verifier_model")
    progress = value.get("progress", 0.0)
    try:
        progress = max(0.0, min(1.0, float(progress)))
    except (TypeError, ValueError):
        progress = 0.0

    duration = _duration_seconds(value, metadata)
    if duration is None and isinstance(document.get("duration"), (int, float)):
        duration = max(0.0, float(document["duration"]))

    return {
        "id": job_id,
        "source_filename": Path(source_path).name if source_path else str(metadata.get("source_filename") or ""),
        "source_path": source_path,
        "media_type": str(metadata.get("media_type") or Path(source_path).suffix.lstrip(".").lower()),
        "duration": duration,
        "status": status,
        "display_status": DISPLAY_STATUS[status],
        "progress": 1.0 if status == "completed" else progress,
        "error_message": _error_message(value.get("error", value.get("error_message"))),
        "created_at": value.get("created_at"),
        "updated_at": value.get("updated_at"),
        "processing_started_at": started_at,
        "processing_completed_at": completed_at,
        "processing_duration_seconds": _elapsed_seconds(started_at, completed_at),
        "vocabulary": vocabulary,
        "primary_model": str(primary_model) if primary_model else None,
        "verifier_model": str(verifier_model) if verifier_model else None,
        "workspace_path": str(workspace) if workspace is not None else None,
        "final_transcript": str(document.get("text") or ""),
        "segments": segments,
        "exports": exports,
        "low_confidence_count": low_confidence_count,
    }


__all__ = [
    "DISPLAY_STATUS",
    "DUPLICATE_MEDIA_UI_MESSAGE",
    "UI_STATUS_BY_INTERNAL",
    "present_job",
]
