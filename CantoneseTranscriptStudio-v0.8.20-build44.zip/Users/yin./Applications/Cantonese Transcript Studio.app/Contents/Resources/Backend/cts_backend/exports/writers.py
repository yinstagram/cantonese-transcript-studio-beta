from __future__ import annotations

import csv
import io
import json
import os
import tempfile
from dataclasses import asdict
from pathlib import Path
from typing import Callable

from ..schemas import ReconciledSegment, TimedSubtitleSegment, TranscriptDocument
from .safety import csv_safe_row, subtitle_safe_cue_text


def _atomic_text_write(path: str | Path, content: str) -> Path:
    destination = Path(path).expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{destination.name}.", dir=destination.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
    except BaseException:
        try:
            Path(temporary_name).unlink(missing_ok=True)
        except OSError:
            pass
        raise
    return destination


def _clean_cue_text(text: str) -> str:
    return "\n".join(line.rstrip() for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")).strip()


def _timestamp(milliseconds: int, *, decimal: str) -> str:
    milliseconds = max(0, int(milliseconds))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}{decimal}{millis:03d}"


def _subtitle_segments(
    document: TranscriptDocument,
) -> tuple[ReconciledSegment | TimedSubtitleSegment, ...]:
    candidates = document.subtitle_segments or document.segments
    return tuple(segment for segment in candidates if _clean_cue_text(segment.text))


def _speaker_text(segment: ReconciledSegment | TimedSubtitleSegment) -> str:
    label = segment.speaker_label
    if label and label != "Unknown":
        return f"{label}: {_clean_cue_text(segment.text)}"
    return _clean_cue_text(segment.text)


def export_txt(document: TranscriptDocument, path: str | Path) -> Path:
    has_speakers = any(segment.speaker_label and segment.speaker_label != "Unknown" for segment in document.segments)
    text = (
        "\n".join(_speaker_text(segment) for segment in _subtitle_segments(document))
        if has_speakers
        else document.text
    )
    if not text and document.segments:
        text = "\n".join(segment.text for segment in document.segments)
    text = text.rstrip()
    return _atomic_text_write(path, text + ("\n" if text else ""))


def export_timestamp_txt(document: TranscriptDocument, path: str | Path) -> Path:
    """Write a human-readable transcript with one time range per segment."""
    blocks: list[str] = []
    for segment in _subtitle_segments(document):
        start = _timestamp(segment.start_ms, decimal=".")
        end = _timestamp(max(segment.start_ms + 1, segment.end_ms), decimal=".")
        blocks.append(f"[{start} → {end}] {_speaker_text(segment)}")
    content = "\n".join(blocks)
    return _atomic_text_write(path, content + ("\n" if content else ""))


def export_srt(document: TranscriptDocument, path: str | Path) -> Path:
    blocks: list[str] = []
    for index, segment in enumerate(_subtitle_segments(document), start=1):
        end_ms = max(segment.start_ms + 1, segment.end_ms)
        blocks.append(
            f"{index}\n"
            f"{_timestamp(segment.start_ms, decimal=',')} --> {_timestamp(end_ms, decimal=',')}\n"
            f"{subtitle_safe_cue_text(_speaker_text(segment))}"
        )
    content = "\n\n".join(blocks)
    return _atomic_text_write(path, content + ("\n" if content else ""))


def export_vtt(document: TranscriptDocument, path: str | Path) -> Path:
    blocks = ["WEBVTT"]
    for segment in _subtitle_segments(document):
        end_ms = max(segment.start_ms + 1, segment.end_ms)
        blocks.append(
            f"{_timestamp(segment.start_ms, decimal='.')} --> {_timestamp(end_ms, decimal='.')}\n"
            f"{subtitle_safe_cue_text(_speaker_text(segment))}"
        )
    return _atomic_text_write(path, "\n\n".join(blocks) + "\n")


def export_json(document: TranscriptDocument, path: str | Path) -> Path:
    content = json.dumps(document.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    return _atomic_text_write(path, content)


def export_csv(document: TranscriptDocument, path: str | Path) -> Path:
    buffer = io.StringIO(newline="")
    fieldnames = [
        "index",
        "source_filename",
        "source_path",
        "duration",
        "language",
        "primary_model",
        "verifier_model",
        "processing_started_at",
        "processing_completed_at",
        "final_transcript",
        "start",
        "end",
        "start_ms",
        "end_ms",
        "speaker_label",
        "speaker_id",
        "speaker_overlap",
        "confidence",
        "disagreement_flag",
        "primary_text",
        "verifier_text",
        "chosen_text",
        "reconciliation_reason",
        "disagreement_ratio",
        "missing",
        "conflict_candidate",
        "candidate_audit",
        "text",
        "similarity",
        "edit_distance",
        "disagreement_count",
        "missing_in_verifier",
        "conflict",
        "low_confidence",
        "audit_reasons",
        "corrections",
    ]
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    for index, segment in enumerate(document.segments, start=1):
        audit = segment.audit
        contract = segment.to_dict()
        writer.writerow(
            csv_safe_row(
                {
                    "index": index,
                    "source_filename": Path(document.media_path).name,
                    "source_path": document.media_path,
                    "duration": "" if document.duration is None else f"{document.duration:.3f}",
                    "language": document.language,
                    "primary_model": document.model_primary or "",
                    "verifier_model": document.model_verifier or "",
                    "processing_started_at": document.processing_started_at or "",
                    "processing_completed_at": document.processing_completed_at or "",
                    "final_transcript": document.text,
                    "start": f"{contract['start']:.3f}",
                    "end": f"{contract['end']:.3f}",
                    "start_ms": segment.start_ms,
                    "end_ms": segment.end_ms,
                    "speaker_label": segment.speaker_label or "",
                    "speaker_id": segment.speaker_id or "",
                    "speaker_overlap": str(segment.speaker_overlap).lower(),
                    "confidence": (
                        "" if segment.confidence is None else f"{segment.confidence:.6f}"
                    ),
                    "disagreement_flag": str(contract["disagreement_flag"]).lower(),
                    "primary_text": segment.primary_text,
                    "verifier_text": segment.verifier_text,
                    "chosen_text": segment.text,
                    "reconciliation_reason": contract["reconciliation_reason"],
                    "disagreement_ratio": f"{audit.disagreement_ratio:.6f}",
                    "missing": str(audit.missing).lower(),
                    "conflict_candidate": str(audit.conflict_candidate).lower(),
                    "candidate_audit": json.dumps(
                        {
                            "disagreement_ratio": audit.disagreement_ratio,
                            "missing": audit.missing,
                            "conflict": audit.conflict,
                            "conflict_candidate": audit.conflict_candidate,
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    "text": segment.text,
                    "similarity": f"{audit.similarity:.6f}",
                    "edit_distance": audit.edit_distance,
                    "disagreement_count": audit.disagreement_count,
                    "missing_in_verifier": str(audit.missing_in_verifier).lower(),
                    "conflict": str(audit.conflict).lower(),
                    "low_confidence": str(audit.low_confidence).lower(),
                    "audit_reasons": json.dumps(audit.reasons, ensure_ascii=False),
                    "corrections": json.dumps(
                        [asdict(correction) for correction in audit.corrections],
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                }
            )
        )
    return _atomic_text_write(path, buffer.getvalue())


def export_all(
    document: TranscriptDocument,
    output_dir: str | Path,
    *,
    stem: str,
) -> dict[str, str]:
    if not stem or Path(stem).name != stem:
        raise ValueError("stem must be a non-empty filename stem without path separators")
    destination = Path(output_dir).expanduser().resolve()
    exporters: dict[str, Callable[[TranscriptDocument, str | Path], Path]] = {
        "txt": export_txt,
        "timestamp_txt": export_timestamp_txt,
        "srt": export_srt,
        "vtt": export_vtt,
        "json": export_json,
        "csv": export_csv,
    }
    results: dict[str, str] = {}
    for extension, exporter in exporters.items():
        filename = f"{stem}.timestamps.txt" if extension == "timestamp_txt" else f"{stem}.{extension}"
        results[extension] = str(exporter(document, destination / filename))
    return results
