"""Dependency-light CTC Viterbi alignment over an observed posterior matrix.

The caller owns acoustic feature extraction and model execution.  This module
only aligns an explicit token-id sequence to finite frame log-probabilities;
it never invents tokens or extrapolates beyond the supplied frame window.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class CTCAlignedToken:
    token_index: int
    token_id: int
    start_frame: int
    end_frame: int
    peak_frame: int
    mean_log_probability: float
    peak_probability: float


@dataclass(frozen=True)
class CTCForcedAlignment:
    tokens: tuple[CTCAlignedToken, ...]
    frame_start: int
    frame_end: int
    path_log_probability: float
    path_log_probability_per_frame: float


def greedy_ctc_tokens(
    log_probabilities: np.ndarray,
    *,
    blank_id: int,
) -> tuple[tuple[int, ...], tuple[int, ...]]:
    """Collapse an argmax CTC path into token ids and their peak frames."""

    matrix = _validated_matrix(log_probabilities, blank_id=blank_id)
    best = np.argmax(matrix, axis=1)
    token_ids: list[int] = []
    frames: list[int] = []
    previous: int | None = None
    for frame, raw_token_id in enumerate(best):
        token_id = int(raw_token_id)
        if token_id != blank_id and token_id != previous:
            token_ids.append(token_id)
            frames.append(frame)
        previous = token_id
    return tuple(token_ids), tuple(frames)


def force_align_ctc(
    log_probabilities: np.ndarray,
    token_ids: Sequence[int],
    *,
    blank_id: int,
    frame_offset: int = 0,
) -> CTCForcedAlignment:
    """Viterbi-align ``token_ids`` to a bounded CTC posterior window.

    ``end_frame`` values are exclusive.  Repeated adjacent token ids require a
    blank transition, as in the standard CTC topology.  A non-finite or
    impossible path raises ``ValueError`` instead of returning guessed timing.
    """

    matrix = _validated_matrix(log_probabilities, blank_id=blank_id)
    if isinstance(frame_offset, bool) or not isinstance(frame_offset, int):
        raise ValueError("frame_offset must be an integer")
    if frame_offset < 0:
        raise ValueError("frame_offset must be non-negative")
    targets = tuple(int(value) for value in token_ids)
    if not targets:
        raise ValueError("CTC target must contain at least one token")
    vocabulary_size = matrix.shape[1]
    if any(value == blank_id or not 0 <= value < vocabulary_size for value in targets):
        raise ValueError("CTC target contains blank or out-of-range token id")

    labels = np.empty(len(targets) * 2 + 1, dtype=np.int64)
    labels[0::2] = blank_id
    labels[1::2] = targets
    frame_count = matrix.shape[0]
    state_count = len(labels)
    scores = np.full(state_count, -np.inf, dtype=np.float64)
    scores[0] = float(matrix[0, blank_id])
    if state_count > 1:
        scores[1] = float(matrix[0, labels[1]])
    backpointers = np.full((frame_count, state_count), -1, dtype=np.int8)

    for frame in range(1, frame_count):
        previous = scores
        scores = np.full(state_count, -np.inf, dtype=np.float64)
        for state, label in enumerate(labels):
            best_score = previous[state]
            transition = 0
            if state > 0 and previous[state - 1] > best_score:
                best_score = previous[state - 1]
                transition = 1
            if (
                state > 1
                and label != blank_id
                and label != labels[state - 2]
                and previous[state - 2] > best_score
            ):
                best_score = previous[state - 2]
                transition = 2
            if np.isfinite(best_score):
                scores[state] = best_score + float(matrix[frame, label])
                backpointers[frame, state] = transition

    terminal_states = (state_count - 1, state_count - 2)
    terminal = max(terminal_states, key=lambda state: scores[state])
    path_score = float(scores[terminal])
    if not np.isfinite(path_score):
        raise ValueError("no finite CTC path covers the requested token sequence")

    states = np.empty(frame_count, dtype=np.int64)
    state = terminal
    for frame in range(frame_count - 1, -1, -1):
        states[frame] = state
        if frame == 0:
            break
        transition = int(backpointers[frame, state])
        if transition < 0:
            raise ValueError("CTC backtrace reached an impossible transition")
        state -= transition
    if states[0] not in {0, 1}:
        raise ValueError("CTC backtrace did not reach a valid initial state")

    aligned: list[CTCAlignedToken] = []
    for token_index, token_id in enumerate(targets):
        token_state = token_index * 2 + 1
        local_frames = np.flatnonzero(states == token_state)
        if not len(local_frames):
            raise ValueError("CTC path omitted a requested token")
        emissions = matrix[local_frames, token_id]
        peak_local_index = int(np.argmax(emissions))
        aligned.append(
            CTCAlignedToken(
                token_index=token_index,
                token_id=token_id,
                start_frame=frame_offset + int(local_frames[0]),
                end_frame=frame_offset + int(local_frames[-1]) + 1,
                peak_frame=frame_offset + int(local_frames[peak_local_index]),
                mean_log_probability=float(np.mean(emissions)),
                peak_probability=float(np.exp(float(emissions[peak_local_index]))),
            )
        )

    return CTCForcedAlignment(
        tokens=tuple(aligned),
        frame_start=frame_offset,
        frame_end=frame_offset + frame_count,
        path_log_probability=path_score,
        path_log_probability_per_frame=path_score / frame_count,
    )


def _validated_matrix(
    log_probabilities: np.ndarray,
    *,
    blank_id: int,
) -> np.ndarray:
    matrix = np.asarray(log_probabilities)
    if matrix.ndim != 2 or not matrix.shape[0] or not matrix.shape[1]:
        raise ValueError("CTC log probabilities must be a non-empty frame×vocabulary matrix")
    if isinstance(blank_id, bool) or not isinstance(blank_id, int):
        raise ValueError("blank_id must be an integer")
    if not 0 <= blank_id < matrix.shape[1]:
        raise ValueError("blank_id is outside the posterior vocabulary")
    if not np.all(np.isfinite(matrix)):
        raise ValueError("CTC log probabilities must be finite")
    return matrix
