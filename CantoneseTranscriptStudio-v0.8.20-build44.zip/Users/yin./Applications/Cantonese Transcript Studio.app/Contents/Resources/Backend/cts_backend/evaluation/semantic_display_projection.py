"""Project reviewed source occurrences onto actual display cues, without timing gold."""

from __future__ import annotations

import html
import math
import re
import unicodedata
from collections.abc import Mapping, Sequence


class SemanticDisplayProjectionError(ValueError):
    """A source identity, complete cue sequence, or reviewed packet is invalid."""


def _semantic_projection_text(value: str) -> str:
    # Exact text-only policy from strict_semantic_display_timing; keep this module pure.
    return " ".join(html.unescape(re.sub(r"<[^>]+>", "", value)).split())


def _sequence(value: object, label: str) -> Sequence:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        raise SemanticDisplayProjectionError(f"{label} must be a sequence")
    return value


def _integer(value: object, label: str) -> int:
    if type(value) is not int or value < 0:
        raise SemanticDisplayProjectionError(f"{label} must be a nonnegative integer")
    return value


def _validate_cues(text: str, cues: Sequence[Mapping], label: str) -> list[Mapping]:
    result = list(_sequence(cues, label))
    seen: set[str] = set()
    cursor, previous_start = 0, -1
    for cue in result:
        if not isinstance(cue, Mapping):
            raise SemanticDisplayProjectionError(f"{label} cue must be a mapping")
        cue_id = cue.get("id")
        if not isinstance(cue_id, str) or not cue_id or cue_id in seen:
            raise SemanticDisplayProjectionError(f"{label} cue ID missing or duplicated")
        seen.add(cue_id)
        start = _integer(cue.get("source_start"), f"{label} source_start")
        end = _integer(cue.get("source_end"), f"{label} source_end")
        if start != cursor or end <= start or end > len(text):
            raise SemanticDisplayProjectionError(f"{label} source range incomplete or overlapping")
        if cue.get("text") != text[start:end]:
            raise SemanticDisplayProjectionError(f"{label} cue text/source mismatch")
        cursor = end
        start_ms = _integer(cue.get("start_ms"), f"{label} start_ms")
        end_ms = _integer(cue.get("end_ms"), f"{label} end_ms")
        if end_ms <= start_ms or start_ms < previous_start:
            raise SemanticDisplayProjectionError(f"{label} cue clocks invalid or unordered")
        previous_start = start_ms
        for alias, milliseconds in (("start", start_ms), ("end", end_ms)):
            if alias not in cue:
                continue
            value = cue[alias]
            try:
                valid = (
                    type(value) in (int, float)
                    and math.isfinite(value)
                    and math.isclose(value * 1000, milliseconds, rel_tol=0, abs_tol=1e-6)
                )
            except OverflowError:
                valid = False
            if not valid:
                raise SemanticDisplayProjectionError(f"{label} {alias} seconds alias mismatch")
    if cursor != len(text):
        raise SemanticDisplayProjectionError(f"{label} does not cover the complete source")
    return result


def _spoken(text: str) -> str:
    return "".join(
        char for char in text
        if not char.isspace() and not unicodedata.category(char).startswith("P")
    )


def _diagnostic_flag(owners: Sequence[Mapping], name: str) -> bool | None:
    if any(cue.get(name) is True for cue in owners):
        return True
    return False if all(cue.get(name) is False for cue in owners) else None


def project_semantic_span(
    *,
    source_text: str,
    source_cues: Sequence[Mapping],
    candidate_text: str,
    candidate_cues: Sequence[Mapping],
    reviewed_atom_ids: Sequence[str],
    reviewed_text: str,
) -> dict:
    """Return whole new display edges only when their source extent is unchanged.

    IDs identify the OLD reviewed occurrence only. New owners are found exclusively
    through exact character offsets. Punctuation/whitespace extras may be included;
    extra spoken characters invalidate measurement rather than being cropped away.
    This is source-identity evidence, never human semantic gold or timing acceptance.
    """
    if not isinstance(source_text, str) or not isinstance(candidate_text, str):
        raise SemanticDisplayProjectionError("full source texts must be strings")
    if source_text != candidate_text:
        raise SemanticDisplayProjectionError("full source text identity changed")
    old = _validate_cues(source_text, source_cues, "source")
    new = _validate_cues(candidate_text, candidate_cues, "candidate")
    ids = list(_sequence(reviewed_atom_ids, "reviewed_atom_ids"))
    if not ids or any(not isinstance(value, str) or not value for value in ids):
        raise SemanticDisplayProjectionError("reviewed IDs must be nonempty strings")
    if len(set(ids)) != len(ids):
        raise SemanticDisplayProjectionError("reviewed IDs duplicated")
    positions = {cue["id"]: index for index, cue in enumerate(old)}
    if any(value not in positions for value in ids):
        raise SemanticDisplayProjectionError("reviewed ID absent from old source")
    indices = [positions[value] for value in ids]
    if indices != list(range(indices[0], indices[0] + len(indices))):
        raise SemanticDisplayProjectionError("reviewed IDs must be contiguous in source order")
    selected = old[indices[0]:indices[-1] + 1]
    expected = _semantic_projection_text(" ".join(cue["text"] for cue in selected))
    if not isinstance(reviewed_text, str) or reviewed_text != expected:
        raise SemanticDisplayProjectionError("reviewed text does not match selected old cues")
    start, end = selected[0]["source_start"], selected[-1]["source_end"]
    owners = [cue for cue in new if cue["source_start"] < end and cue["source_end"] > start]
    # Complete sequence validation proves every character in the reviewed interval
    # has one owner; this explicit check documents the resulting ownership bound.
    if not owners or owners[0]["source_start"] > start or owners[-1]["source_end"] < end:
        raise SemanticDisplayProjectionError("candidate ownership does not cover reviewed span")
    owner_start, owner_end = owners[0]["source_start"], owners[-1]["source_end"]
    prefix, suffix = candidate_text[owner_start:start], candidate_text[end:owner_end]
    prefix_spoken, suffix_spoken = _spoken(prefix), _spoken(suffix)
    exact = not prefix_spoken and not suffix_spoken
    return {
        "source_start": start,
        "source_end": end,
        "source_text": source_text[start:end],
        "reviewed_atom_ids": ids,
        "reviewed_text": reviewed_text,
        "owner_ids": [cue["id"] for cue in owners],
        "owner_source_start": owner_start,
        "owner_source_end": owner_end,
        "owner_text": candidate_text[owner_start:owner_end],
        "owner_start_ms": owners[0]["start_ms"],
        "owner_end_ms": owners[-1]["end_ms"],
        "extra_prefix": prefix,
        "extra_suffix": suffix,
        "extra_spoken_prefix": prefix_spoken,
        "extra_spoken_suffix": suffix_spoken,
        "same_source_extent_ignoring_punctuation": exact,
        "candidate_start_ms": owners[0]["start_ms"] if exact else None,
        "candidate_end_ms": owners[-1]["end_ms"] if exact else None,
        "timing_review_required": any(cue.get("timing_review_required") is not False for cue in owners),
        "low_confidence": _diagnostic_flag(owners, "low_confidence"),
        "speaker_overlap": _diagnostic_flag(owners, "speaker_overlap"),
        "owner_flags": [
            {"id": cue["id"], **{
                name: cue.get(name) if type(cue.get(name)) is bool else None
                for name in ("timing_review_required", "low_confidence", "speaker_overlap")
            }} for cue in owners
        ],
        "accuracy_status": "UNKNOWN",
        "acceptance": False,
    }
