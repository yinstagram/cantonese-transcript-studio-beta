"""Persistent settings and canonical Application Support paths."""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
import urllib.parse
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any


APP_NAME = "Cantonese Transcript Studio"
APPLICATION_SUPPORT_ROOT = Path.home() / "Library" / "Application Support" / APP_NAME
SUPPORT_ROOT_ENVIRONMENT_VARIABLE = "CTS_APPLICATION_SUPPORT_ROOT"


@dataclass(frozen=True)
class AppPaths:
    root: Path
    models: Path
    jobs: Path
    runtime: Path
    logs: Path
    settings: Path

    @classmethod
    def default(cls, root: Path | None = None) -> "AppPaths":
        configured_root = root or os.environ.get(SUPPORT_ROOT_ENVIRONMENT_VARIABLE)
        base = Path(configured_root or APPLICATION_SUPPORT_ROOT).expanduser()
        return cls(
            root=base,
            models=base / "Models",
            jobs=base / "Jobs",
            runtime=base / "Runtime",
            logs=base / "Logs",
            settings=base / "settings.json",
        )

    def ensure(self) -> "AppPaths":
        for directory in (self.root, self.models, self.jobs, self.runtime, self.logs):
            directory.mkdir(parents=True, exist_ok=True)
        return self


@dataclass
class Settings:
    primary_model: str = "Qwen/Qwen3-ASR-1.7B"
    fallback_model: str = "Qwen/Qwen3-ASR-0.6B"
    verifier_model: str = (
        "sherpa-onnx-wenetspeech-yue-u2pp-conformer-ctc-zh-en-cantonese-"
        "int8-2025-09-10"
    )
    forced_aligner_model: str = "Qwen/Qwen3-ForcedAligner-0.6B"
    forced_alignment_enabled: bool = True
    use_fallback: bool = False
    context: str = ""
    language: str = "Cantonese"
    sherpa_num_threads: int = 2
    max_retries: int = 2
    # High-accuracy mode runs three independent ASR engines sequentially.
    # It is opt-in so the existing two-engine workflow remains the fast path.
    accuracy_mode: bool = False
    whisper_model: str = "whisper.cpp/large-v3"
    local_arbiter_enabled: bool = False
    local_arbiter_model: str = "google/gemma-4-12b-qat"
    local_arbiter_endpoint: str = "http://127.0.0.1:1234/v1/chat/completions"
    # Anonymous local speaker clustering.  Labels are Speaker 1/2/... and
    # never claim a real person's identity.
    speaker_diarization_enabled: bool = True
    speaker_num_speakers: int | None = None
    # User-visible, local-only learning from subtitle edits. This setting only
    # controls new inferred mappings; manual dictionary entries remain usable.
    correction_memory_learning_enabled: bool = True
    # The API is deliberately opt-in and only ever binds to loopback.
    local_api_enabled: bool = False
    local_api_port: int = 8765
    local_api_token: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp_name, path)
    except BaseException:
        try:
            failed = path.parent / ".failed-writes"
            failed.mkdir(parents=True, exist_ok=True)
            shutil.move(tmp_name, failed / f"{path.name}-{time.time_ns()}")
        except OSError:
            pass
        raise


class SettingsStore:
    def __init__(self, paths: AppPaths | None = None) -> None:
        self.paths = (paths or AppPaths.default()).ensure()

    def get(self) -> Settings:
        if not self.paths.settings.exists():
            value = Settings()
            self.save(value)
            return value
        raw = json.loads(self.paths.settings.read_text(encoding="utf-8"))
        allowed = {item.name for item in fields(Settings)}
        return Settings(**{key: value for key, value in raw.items() if key in allowed})

    def save(self, value: Settings) -> Settings:
        _atomic_json(self.paths.settings, value.to_dict())
        return value

    def update(self, changes: dict[str, Any]) -> Settings:
        current = self.get().to_dict()
        allowed = set(current)
        unknown = sorted(set(changes) - allowed)
        if unknown:
            raise ValueError(f"未知設定：{', '.join(unknown)}")
        current.update(changes)
        value = Settings(**current)
        if value.sherpa_num_threads != 2:
            raise ValueError("呢部 M1 專案固定 sherpa_num_threads=2")
        if (
            isinstance(value.max_retries, bool)
            or not isinstance(value.max_retries, int)
            or not 0 <= value.max_retries <= 2
        ):
            raise ValueError("max_retries 必須係 0 至 2")
        if value.language != "Cantonese":
            raise ValueError("目前只支援 Cantonese 語言模式")
        if not isinstance(value.local_api_enabled, bool):
            raise ValueError("local_api_enabled 必須係布林值")
        if not isinstance(value.local_api_port, int) or isinstance(value.local_api_port, bool) or not 1024 <= value.local_api_port <= 65535:
            raise ValueError("local_api_port 必須係 1024 至 65535")
        if not isinstance(value.local_api_token, str):
            raise ValueError("local_api_token 必須係文字")
        if not isinstance(value.accuracy_mode, bool):
            raise ValueError("accuracy_mode 必須係布林值")
        if value.whisper_model not in {"whisper.cpp/large-v3", "whisper.cpp/large-v2"}:
            raise ValueError("whisper_model 只支援 Whisper Large v3 或 Large v2")
        if not isinstance(value.local_arbiter_enabled, bool):
            raise ValueError("local_arbiter_enabled 必須係布林值")
        if not isinstance(value.local_arbiter_model, str) or not value.local_arbiter_model.strip():
            raise ValueError("local_arbiter_model 必須係非空白文字")
        if not isinstance(value.local_arbiter_endpoint, str):
            raise ValueError("local_arbiter_endpoint 必須係文字")
        if not isinstance(value.speaker_diarization_enabled, bool):
            raise ValueError("speaker_diarization_enabled 必須係布林值")
        if not isinstance(value.forced_alignment_enabled, bool):
            raise ValueError("forced_alignment_enabled 必須係布林值")
        if not isinstance(value.correction_memory_learning_enabled, bool):
            raise ValueError("correction_memory_learning_enabled 必須係布林值")
        if value.forced_aligner_model != "Qwen/Qwen3-ForcedAligner-0.6B":
            raise ValueError("forced_aligner_model 目前只支援 Qwen3 ForcedAligner 0.6B")
        if value.speaker_num_speakers is not None and (
            isinstance(value.speaker_num_speakers, bool)
            or not isinstance(value.speaker_num_speakers, int)
            or not 1 <= value.speaker_num_speakers <= 20
        ):
            raise ValueError("speaker_num_speakers 必須係 1 至 20 或留空自動辨認")
        endpoint = urllib.parse.urlparse(value.local_arbiter_endpoint)
        try:
            endpoint_port = endpoint.port
        except ValueError as exc:
            raise ValueError("local_arbiter_endpoint port 無效") from exc
        if (
            endpoint.scheme != "http"
            or endpoint.hostname not in {"127.0.0.1", "::1"}
            or endpoint_port is None
            or not 1024 <= endpoint_port <= 65535
            or endpoint.path.rstrip("/") != "/v1/chat/completions"
            or endpoint.username is not None
            or endpoint.password is not None
            or endpoint.params
            or endpoint.query
            or endpoint.fragment
        ):
            raise ValueError("local_arbiter_endpoint 只可以係本機 loopback chat completions")
        return self.save(value)


__all__ = [
    "APP_NAME",
    "APPLICATION_SUPPORT_ROOT",
    "AppPaths",
    "Settings",
    "SettingsStore",
    "_atomic_json",
]
