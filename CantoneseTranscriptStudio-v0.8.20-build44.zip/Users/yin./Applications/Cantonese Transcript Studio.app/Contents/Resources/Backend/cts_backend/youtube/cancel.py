"""Bounded cancellation for child processes launched in a new process group."""

from __future__ import annotations

import os
import signal
import subprocess
from collections.abc import Mapping
from typing import Any, Protocol


class GroupProcess(Protocol):
    pid: int

    def poll(self) -> int | None: ...

    def wait(self, timeout: float | None = None) -> int: ...


def process_group_popen_kwargs() -> Mapping[str, Any]:
    """Keyword contract required when the worker eventually launches yt-dlp."""

    return {"start_new_session": True, "shell": False}


def cancel_process_group(
    process: GroupProcess,
    *,
    interrupt_grace: float = 3.0,
    terminate_grace: float = 2.0,
    kill_grace: float = 1.0,
) -> int | None:
    """Cancel yt-dlp plus descendant Deno／FFmpeg without orphaning them."""

    if min(interrupt_grace, terminate_grace, kill_grace) < 0:
        raise ValueError("cancel grace period 唔可以係負數")
    if process.poll() is not None:
        return process.poll()
    pid = int(process.pid)
    if pid <= 1 or pid in {os.getpid(), os.getpgrp()}:
        raise ValueError("拒絕取消不安全 process group")

    sequence = (
        (signal.SIGINT, interrupt_grace),
        (signal.SIGTERM, terminate_grace),
        (signal.SIGKILL, kill_grace),
    )
    for selected_signal, timeout in sequence:
        if process.poll() is not None:
            return process.poll()
        try:
            os.killpg(pid, selected_signal)
        except ProcessLookupError:
            return process.poll()
        try:
            return process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            continue
    return process.poll()
