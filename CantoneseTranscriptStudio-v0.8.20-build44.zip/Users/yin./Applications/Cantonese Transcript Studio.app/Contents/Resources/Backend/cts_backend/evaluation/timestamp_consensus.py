"""Gold-free timestamp context-ablation consensus with fail-closed abstention.

This module never estimates, averages, or rewrites timestamps.  It either
returns the complete triple-context acoustic candidate or retains the complete
target-only baseline.  Human-labelled timing is deliberately not accepted as
an input, so offline gold cannot leak into runtime selection.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


TIMESTAMP_CONTEXT_CONSENSUS_POLICY = "timestamp-context-ablation-consensus-v1"


@dataclass(frozen=True)
class TimestampConsensusConfig:
    max_intrinsic_shift_ms: int = 80
    pairwise_p95_ms: int = 160
    pairwise_max_ms: int = 320
    interior_anchor_p95_ms: int = 160
    interior_anchor_max_ms: int = 320
    recognition_envelope_ms: int = 750
    max_baseline_displacement_ms: int = 750
    max_stitch_shift_ms: int = 80

    def to_dict(self) -> dict[str, Any]:
        return {
            "policy": TIMESTAMP_CONTEXT_CONSENSUS_POLICY,
            "max_intrinsic_shift_ms": self.max_intrinsic_shift_ms,
            "pairwise_p95_ms": self.pairwise_p95_ms,
            "pairwise_max_ms": self.pairwise_max_ms,
            "interior_anchor_p95_ms": self.interior_anchor_p95_ms,
            "interior_anchor_max_ms": self.interior_anchor_max_ms,
            "recognition_envelope_ms": self.recognition_envelope_ms,
            "max_baseline_displacement_ms": self.max_baseline_displacement_ms,
            "max_stitch_shift_ms": self.max_stitch_shift_ms,
            "selection": "complete_triple_or_complete_baseline",
            "averaging": False,
            "reference_timing_input": False,
        }

    def sha256(self) -> str:
        encoded = json.dumps(
            self.to_dict(), sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True)
class _Word:
    source_start: int
    source_end: int
    start_ms: int
    end_ms: int


@dataclass(frozen=True)
class _Candidate:
    mode: str
    words: tuple[_Word, ...]
    character_source_indexes: tuple[int, ...]
    target_text_sha256: str
    expected_target_text_sha256: str
    context_text_sha256: str
    expected_context_text_sha256: str
    fallback_count: int
    window_clamped_target_words: int
    zero_duration_target_words: int
    max_intrinsic_shift_ms: int
    context_audio_start_ms: int
    context_audio_end_ms: int


def _strict_int(value: Any, *, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{label} must be an integer")
    return value


def _strict_sha(value: Any, *, label: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError(f"{label} must be a SHA-256 hex digest")
    try:
        bytes.fromhex(value)
    except ValueError as exc:
        raise ValueError(f"{label} must be a SHA-256 hex digest") from exc
    return value.lower()


def _coerce_candidate(value: Mapping[str, Any], *, expected_mode: str) -> _Candidate:
    if not isinstance(value, Mapping) or value.get("mode") != expected_mode:
        raise ValueError(f"candidate mode must be {expected_mode}")
    raw_words = value.get("words")
    if not isinstance(raw_words, Sequence) or isinstance(raw_words, (str, bytes)):
        raise ValueError(f"{expected_mode}.words must be an array")
    words: list[_Word] = []
    previous_source_end = 0
    previous_time_end = 0
    for index, raw in enumerate(raw_words):
        if not isinstance(raw, Mapping):
            raise ValueError(f"{expected_mode}.words[{index}] must be an object")
        word = _Word(
            source_start=_strict_int(
                raw.get("source_start"), label=f"{expected_mode}.source_start"
            ),
            source_end=_strict_int(
                raw.get("source_end"), label=f"{expected_mode}.source_end"
            ),
            start_ms=_strict_int(
                raw.get("start_ms"), label=f"{expected_mode}.start_ms"
            ),
            end_ms=_strict_int(raw.get("end_ms"), label=f"{expected_mode}.end_ms"),
        )
        if not (
            0 <= word.source_start < word.source_end
            and word.source_start >= previous_source_end
            and 0 <= word.start_ms < word.end_ms
            and word.start_ms >= previous_time_end
        ):
            raise ValueError(f"{expected_mode}.words[{index}] has an invalid range")
        words.append(word)
        previous_source_end = word.source_end
        previous_time_end = word.end_ms
    if not words:
        raise ValueError(f"{expected_mode}.words must not be empty")
    raw_indexes = value.get("character_source_indexes")
    if not isinstance(raw_indexes, Sequence) or isinstance(raw_indexes, (str, bytes)):
        raise ValueError(f"{expected_mode}.character_source_indexes must be an array")
    indexes = tuple(
        _strict_int(item, label=f"{expected_mode}.character_source_indexes")
        for item in raw_indexes
    )
    if not indexes or any(right <= left for left, right in zip(indexes, indexes[1:])):
        raise ValueError(f"{expected_mode}.character_source_indexes must be strictly increasing")
    candidate = _Candidate(
        mode=expected_mode,
        words=tuple(words),
        character_source_indexes=indexes,
        target_text_sha256=_strict_sha(
            value.get("target_text_sha256"), label=f"{expected_mode}.target_text_sha256"
        ),
        expected_target_text_sha256=_strict_sha(
            value.get("expected_target_text_sha256"),
            label=f"{expected_mode}.expected_target_text_sha256",
        ),
        context_text_sha256=_strict_sha(
            value.get("context_text_sha256"), label=f"{expected_mode}.context_text_sha256"
        ),
        expected_context_text_sha256=_strict_sha(
            value.get("expected_context_text_sha256"),
            label=f"{expected_mode}.expected_context_text_sha256",
        ),
        fallback_count=_strict_int(
            value.get("fallback_count"), label=f"{expected_mode}.fallback_count"
        ),
        window_clamped_target_words=_strict_int(
            value.get("window_clamped_target_words"),
            label=f"{expected_mode}.window_clamped_target_words",
        ),
        zero_duration_target_words=_strict_int(
            value.get("zero_duration_target_words"),
            label=f"{expected_mode}.zero_duration_target_words",
        ),
        max_intrinsic_shift_ms=_strict_int(
            value.get("max_intrinsic_shift_ms"),
            label=f"{expected_mode}.max_intrinsic_shift_ms",
        ),
        context_audio_start_ms=_strict_int(
            value.get("context_audio_start_ms"),
            label=f"{expected_mode}.context_audio_start_ms",
        ),
        context_audio_end_ms=_strict_int(
            value.get("context_audio_end_ms"),
            label=f"{expected_mode}.context_audio_end_ms",
        ),
    )
    if (
        candidate.fallback_count < 0
        or candidate.window_clamped_target_words < 0
        or candidate.zero_duration_target_words < 0
        or candidate.max_intrinsic_shift_ms < 0
        or candidate.context_audio_start_ms < 0
        or candidate.context_audio_end_ms <= candidate.context_audio_start_ms
    ):
        raise ValueError(f"{expected_mode} has invalid audit values")
    return candidate


def _boundaries(candidate: _Candidate) -> tuple[int, ...]:
    return tuple(value for word in candidate.words for value in (word.start_ms, word.end_ms))


def _source_spans(candidate: _Candidate) -> tuple[tuple[int, int], ...]:
    return tuple((word.source_start, word.source_end) for word in candidate.words)


def _percentile(values: Sequence[int], percentile: float) -> int:
    if not values:
        return 0
    ordered = sorted(values)
    return ordered[max(1, math.ceil(percentile * len(ordered))) - 1]


def _delta_summary(left: _Candidate, right: _Candidate) -> dict[str, int]:
    values = [
        abs(a - b) for a, b in zip(_boundaries(left), _boundaries(right))
    ]
    return {
        "p50_ms": _percentile(values, 0.50),
        "p95_ms": _percentile(values, 0.95),
        "max_ms": max(values, default=0),
    }


def _canonical_words_sha(candidate: _Candidate) -> str:
    encoded = json.dumps(
        [
            [word.source_start, word.source_end, word.start_ms, word.end_ms]
            for word in candidate.words
        ],
        separators=(",", ":"),
    ).encode("ascii")
    return hashlib.sha256(encoded).hexdigest()


def _structural_reasons(
    candidate: _Candidate,
    baseline: _Candidate,
    config: TimestampConsensusConfig,
) -> list[str]:
    reasons: list[str] = []
    if _source_spans(candidate) != _source_spans(baseline):
        reasons.append("target_source_span_mismatch")
    if candidate.character_source_indexes != baseline.character_source_indexes:
        reasons.append("target_character_index_mismatch")
    if candidate.target_text_sha256 != candidate.expected_target_text_sha256:
        reasons.append("target_text_hash_mismatch")
    if candidate.context_text_sha256 != candidate.expected_context_text_sha256:
        reasons.append("context_text_hash_mismatch")
    if candidate.fallback_count:
        reasons.append("fallback_present")
    if candidate.window_clamped_target_words:
        reasons.append("window_clamp_present")
    if candidate.zero_duration_target_words:
        reasons.append("zero_duration_present")
    if candidate.max_intrinsic_shift_ms > config.max_intrinsic_shift_ms:
        reasons.append("intrinsic_shift_exceeds_limit")
    if any(
        word.start_ms < candidate.context_audio_start_ms
        or word.end_ms > candidate.context_audio_end_ms
        for word in candidate.words
    ):
        reasons.append("target_word_outside_context_audio")
    return reasons


def select_timestamp_context_consensus(
    baseline_value: Mapping[str, Any],
    left_value: Mapping[str, Any],
    right_value: Mapping[str, Any],
    triple_value: Mapping[str, Any],
    *,
    target_core_start_ms: int,
    target_core_end_ms: int,
    is_first_segment: bool,
    is_final_segment: bool,
    previous_output_end_ms: int | None = None,
    next_output_start_ms: int | None = None,
    config: TimestampConsensusConfig = TimestampConsensusConfig(),
) -> dict[str, Any]:
    """Select one complete acoustic candidate or retain baseline.

    The result intentionally contains no transcript text or reference timing.
    """

    core_start = _strict_int(target_core_start_ms, label="target_core_start_ms")
    core_end = _strict_int(target_core_end_ms, label="target_core_end_ms")
    if core_start < 0 or core_end <= core_start:
        raise ValueError("target core range is invalid")
    baseline = _coerce_candidate(baseline_value, expected_mode="baseline")
    left = _coerce_candidate(left_value, expected_mode="left")
    right = _coerce_candidate(right_value, expected_mode="right")
    triple = _coerce_candidate(triple_value, expected_mode="triple")
    reasons: list[str] = []
    if is_first_segment:
        reasons.append("first_segment_abstention")
    if is_final_segment:
        reasons.append("final_segment_abstention")

    baseline_structural = _structural_reasons(baseline, baseline, config)
    reasons.extend(f"baseline:{value}" for value in baseline_structural)
    structural = {
        item.mode: _structural_reasons(item, baseline, config)
        for item in (left, right, triple)
    }
    for mode, values in structural.items():
        reasons.extend(f"{mode}:{value}" for value in values)

    pairwise = {
        "left_right": _delta_summary(left, right),
        "left_triple": _delta_summary(left, triple),
        "right_triple": _delta_summary(right, triple),
    }
    if any(value["p95_ms"] > config.pairwise_p95_ms for value in pairwise.values()):
        reasons.append("context_pairwise_p95_exceeds_limit")
    if any(value["max_ms"] > config.pairwise_max_ms for value in pairwise.values()):
        reasons.append("context_pairwise_max_exceeds_limit")

    baseline_boundaries = _boundaries(baseline)
    triple_boundaries = _boundaries(triple)
    interior_deltas = [
        abs(left_boundary - right_boundary)
        for index, (left_boundary, right_boundary) in enumerate(
            zip(triple_boundaries, baseline_boundaries)
        )
        if index not in {0, len(baseline_boundaries) - 1}
    ]
    interior = {
        "p95_ms": _percentile(interior_deltas, 0.95),
        "max_ms": max(interior_deltas, default=0),
    }
    if interior["p95_ms"] > config.interior_anchor_p95_ms:
        reasons.append("interior_anchor_p95_exceeds_limit")
    if interior["max_ms"] > config.interior_anchor_max_ms:
        reasons.append("interior_anchor_max_exceeds_limit")

    baseline_deltas = [
        abs(left_boundary - right_boundary)
        for left_boundary, right_boundary in zip(
            triple_boundaries, baseline_boundaries
        )
    ]
    if max(baseline_deltas, default=0) > config.max_baseline_displacement_ms:
        reasons.append("baseline_displacement_exceeds_limit")
    if triple.words[0].start_ms < core_start - config.recognition_envelope_ms:
        reasons.append("leading_edge_outside_recognition_envelope")
    if triple.words[-1].end_ms > core_end + config.recognition_envelope_ms:
        reasons.append("trailing_edge_outside_recognition_envelope")

    if previous_output_end_ms is not None:
        previous_end = _strict_int(previous_output_end_ms, label="previous_output_end_ms")
        overlap = previous_end - triple.words[0].start_ms
        if overlap > 0:
            reasons.append("previous_segment_overlap")
        if overlap > config.max_stitch_shift_ms:
            reasons.append("previous_stitch_shift_exceeds_limit")
    if next_output_start_ms is not None:
        next_start = _strict_int(next_output_start_ms, label="next_output_start_ms")
        overlap = triple.words[-1].end_ms - next_start
        if overlap > 0:
            reasons.append("next_segment_overlap")
        if overlap > config.max_stitch_shift_ms:
            reasons.append("next_stitch_shift_exceeds_limit")

    selected = baseline if reasons else triple
    return {
        "schema": "cts.timestamp-context-consensus/v1",
        "policy": TIMESTAMP_CONTEXT_CONSENSUS_POLICY,
        "policy_sha256": config.sha256(),
        "selected_mode": selected.mode,
        "abstained": selected is baseline,
        "reasons": sorted(set(reasons)),
        "candidate_eligibility": {
            "baseline": {
                "eligible": not baseline_structural,
                "reasons": baseline_structural,
            },
            **{
                mode: {"eligible": not values, "reasons": values}
                for mode, values in structural.items()
            },
        },
        "pairwise_context_delta": pairwise,
        "interior_anchor_delta": interior,
        "selected_words_sha256": _canonical_words_sha(selected),
        "baseline_words_sha256": _canonical_words_sha(baseline),
        "triple_words_sha256": _canonical_words_sha(triple),
        "selected_is_direct_candidate": True,
        "timing_averaged_or_synthesized": False,
        "contains_reference_timing": False,
        "contains_transcript_text": False,
    }


__all__ = [
    "TIMESTAMP_CONTEXT_CONSENSUS_POLICY",
    "TimestampConsensusConfig",
    "select_timestamp_context_consensus",
]
