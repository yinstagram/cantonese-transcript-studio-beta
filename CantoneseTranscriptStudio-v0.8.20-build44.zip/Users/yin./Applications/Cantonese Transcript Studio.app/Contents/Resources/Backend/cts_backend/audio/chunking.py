from __future__ import annotations

import array
import json
import math
import os
import sys
import tempfile
import unicodedata
import wave
from pathlib import Path
from typing import Callable, Iterable, Sequence

from ..constants import (
    CHUNK_PLAN_FILENAME,
    DEFAULT_CHUNK_BOUNDARY_SEARCH_SECONDS,
    DEFAULT_CHUNK_OVERLAP_SECONDS,
    DEFAULT_CHUNK_SECONDS,
    DEFAULT_ENERGY_WINDOW_MS,
    MIN_CHUNK_SECONDS,
    TARGET_CHANNELS,
    TARGET_SAMPLE_RATE,
    TARGET_SAMPLE_WIDTH_BYTES,
)
from ..schemas import ChunkPlan, ChunkSpec, TranscriptSegment


class InvalidChunkSourceError(ValueError):
    pass


def _pcm16_rms(sample: bytes) -> int:
    values = array.array("h")
    values.frombytes(sample)
    if sys.byteorder != "little":
        values.byteswap()
    if not values:
        return 0
    return math.isqrt(sum(value * value for value in values) // len(values))


def _atomic_json_write(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, path)
    except BaseException:
        try:
            Path(temporary_name).unlink(missing_ok=True)
        except OSError:
            pass
        raise


def _validate_pcm_wav(reader: wave.Wave_read) -> None:
    actual = (reader.getnchannels(), reader.getframerate(), reader.getsampwidth(), reader.getcomptype())
    expected = (TARGET_CHANNELS, TARGET_SAMPLE_RATE, TARGET_SAMPLE_WIDTH_BYTES, "NONE")
    if actual != expected:
        raise InvalidChunkSourceError(
            "Chunk source must be mono 16 kHz PCM16 WAV; "
            f"received channels={actual[0]}, rate={actual[1]}, width={actual[2]}, type={actual[3]}"
        )


def _find_low_energy_boundary(
    reader: wave.Wave_read,
    *,
    ideal_frame: int,
    search_frames: int,
    window_frames: int,
    lower_bound: int,
    upper_bound: int,
    cancel_requested: Callable[[], bool] | None = None,
) -> int:
    search_start = max(lower_bound, ideal_frame - search_frames)
    search_end = min(upper_bound, ideal_frame + search_frames)
    if search_end <= search_start:
        return max(lower_bound, min(ideal_frame, upper_bound))

    step_frames = max(1, window_frames // 2)
    best_frame = max(search_start, min(ideal_frame, search_end))
    best_rms: int | None = None
    position = search_start
    while position <= search_end:
        if cancel_requested is not None and cancel_requested():
            raise InterruptedError("Audio chunking cancelled")
        reader.setpos(position)
        sample = reader.readframes(min(window_frames, reader.getnframes() - position))
        if not sample:
            break
        rms = _pcm16_rms(sample)
        candidate = position + min(window_frames, len(sample) // TARGET_SAMPLE_WIDTH_BYTES) // 2
        distance = abs(candidate - ideal_frame)
        best_distance = abs(best_frame - ideal_frame)
        if best_rms is None or rms < best_rms or (rms == best_rms and distance < best_distance):
            best_rms = rms
            best_frame = candidate
        position += step_frames
    return max(lower_bound, min(best_frame, upper_bound))


def _copy_wave_range(
    source_path: Path,
    destination_path: Path,
    *,
    start_frame: int,
    end_frame: int,
    cancel_requested: Callable[[], bool] | None = None,
) -> None:
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(source_path), "rb") as reader, wave.open(str(destination_path), "wb") as writer:
        _validate_pcm_wav(reader)
        writer.setnchannels(reader.getnchannels())
        writer.setsampwidth(reader.getsampwidth())
        writer.setframerate(reader.getframerate())
        reader.setpos(start_frame)
        remaining = end_frame - start_frame
        block_frames = reader.getframerate()
        while remaining > 0:
            if cancel_requested is not None and cancel_requested():
                raise InterruptedError("Audio chunking cancelled")
            frames = reader.readframes(min(block_frames, remaining))
            if not frames:
                break
            writer.writeframesraw(frames)
            remaining -= len(frames) // (reader.getsampwidth() * reader.getnchannels())
        writer.writeframes(b"")
    if remaining != 0:
        raise InvalidChunkSourceError("Unexpected end of WAV while writing disk-backed chunk")


def build_chunk_plan(
    source_path: str | Path,
    output_dir: str | Path,
    *,
    target_seconds: float = DEFAULT_CHUNK_SECONDS,
    overlap_seconds: float = DEFAULT_CHUNK_OVERLAP_SECONDS,
    boundary_search_seconds: float = DEFAULT_CHUNK_BOUNDARY_SEARCH_SECONDS,
    energy_window_ms: int = DEFAULT_ENERGY_WINDOW_MS,
    boundary_hints_ms: Sequence[int] = (),
    cancel_requested: Callable[[], bool] | None = None,
) -> ChunkPlan:
    source = Path(source_path).expanduser().resolve()
    destination = Path(output_dir).expanduser().resolve()
    if target_seconds <= MIN_CHUNK_SECONDS:
        raise ValueError(f"target_seconds must be greater than {MIN_CHUNK_SECONDS}")
    if overlap_seconds < 0 or overlap_seconds * 2 >= target_seconds:
        raise ValueError("overlap_seconds must be non-negative and less than half the target")
    if boundary_search_seconds < 0:
        raise ValueError("boundary_search_seconds must be non-negative")
    if energy_window_ms <= 0:
        raise ValueError("energy_window_ms must be positive")
    if any(
        isinstance(value, bool) or not isinstance(value, int) or value < 0
        for value in boundary_hints_ms
    ):
        raise ValueError("boundary_hints_ms must contain non-negative integers")

    destination.mkdir(parents=True, exist_ok=True)
    with wave.open(str(source), "rb") as reader:
        _validate_pcm_wav(reader)
        sample_rate = reader.getframerate()
        total_frames = reader.getnframes()
        if total_frames == 0:
            raise InvalidChunkSourceError("Chunk source WAV is empty")
        target_frames = round(target_seconds * sample_rate)
        overlap_frames = round(overlap_seconds * sample_rate)
        search_frames = round(boundary_search_seconds * sample_rate)
        window_frames = max(1, round(energy_window_ms / 1000 * sample_rate))
        minimum_frames = round(MIN_CHUNK_SECONDS * sample_rate)
        hint_frames = tuple(
            sorted(
                {
                    round(value / 1000 * sample_rate)
                    for value in boundary_hints_ms
                    if 0 < value < round(total_frames / sample_rate * 1000)
                }
            )
        )

        boundaries = [0]
        current = 0
        while total_frames - current > target_frames:
            if cancel_requested is not None and cancel_requested():
                raise InterruptedError("Audio chunking cancelled")
            ideal = current + target_frames
            lower = current + minimum_frames
            upper = total_frames - minimum_frames
            nearby_hints = [
                value
                for value in hint_frames
                if lower <= value <= upper and abs(value - ideal) <= search_frames
            ]
            if nearby_hints:
                # Coarse ASR segment ends are safer ownership boundaries than
                # an arbitrary local energy minimum inside the same sentence.
                boundary = min(nearby_hints, key=lambda value: (abs(value - ideal), value))
            else:
                boundary = _find_low_energy_boundary(
                    reader,
                    ideal_frame=ideal,
                    search_frames=search_frames,
                    window_frames=window_frames,
                    lower_bound=lower,
                    upper_bound=upper,
                    cancel_requested=cancel_requested,
                )
            if boundary <= current:
                boundary = min(total_frames, current + target_frames)
            boundaries.append(boundary)
            current = boundary
        boundaries.append(total_frames)

    chunks: list[ChunkSpec] = []
    for index, (core_start, core_end) in enumerate(zip(boundaries, boundaries[1:])):
        if cancel_requested is not None and cancel_requested():
            raise InterruptedError("Audio chunking cancelled")
        actual_start = core_start if index == 0 else max(0, core_start - overlap_frames)
        actual_end = (
            core_end if index == len(boundaries) - 2 else min(total_frames, core_end + overlap_frames)
        )
        chunk_path = destination / f"chunk-{index:05d}.wav"
        _copy_wave_range(
            source,
            chunk_path,
            start_frame=actual_start,
            end_frame=actual_end,
            cancel_requested=cancel_requested,
        )
        chunks.append(
            ChunkSpec(
                index=index,
                path=str(chunk_path),
                start_ms=round(actual_start / sample_rate * 1000),
                end_ms=round(actual_end / sample_rate * 1000),
                core_start_ms=round(core_start / sample_rate * 1000),
                core_end_ms=round(core_end / sample_rate * 1000),
            )
        )

    plan = ChunkPlan(
        source_path=str(source),
        sample_rate=sample_rate,
        total_duration_ms=round(total_frames / sample_rate * 1000),
        overlap_ms=round(overlap_seconds * 1000),
        chunks=tuple(chunks),
    )
    _atomic_json_write(destination / CHUNK_PLAN_FILENAME, plan.to_dict())
    return plan


def _overlap_projection(text: str) -> tuple[str, list[int]]:
    characters: list[str] = []
    raw_ends: list[int] = []
    for raw_index, character in enumerate(text):
        category = unicodedata.category(character)
        if character.isspace() or category.startswith(("P", "S", "Z", "C")):
            continue
        for folded in character.casefold():
            characters.append(folded)
            raw_ends.append(raw_index + 1)
    return "".join(characters), raw_ends


def remove_text_overlap(previous: str, current: str, *, maximum_characters: int = 120) -> str:
    """Remove punctuation/spacing-normalized overlap, never fuzzy semantic text."""
    if not previous or not current:
        return current
    previous_key, _ = _overlap_projection(previous)
    current_key, current_raw_ends = _overlap_projection(current)
    cap = min(len(previous_key), len(current_key), maximum_characters)
    for length in range(cap, 1, -1):
        if previous_key[-length:] == current_key[:length]:
            return current[current_raw_ends[length - 1]:].lstrip()
    return current


def merge_chunk_segments(
    plan: ChunkPlan,
    segments_by_chunk: Sequence[Sequence[TranscriptSegment]],
) -> tuple[TranscriptSegment, ...]:
    if len(segments_by_chunk) != len(plan.chunks):
        raise ValueError("segments_by_chunk length must match the chunk plan")

    merged: list[TranscriptSegment] = []
    for chunk, relative_segments in zip(plan.chunks, segments_by_chunk):
        for segment in relative_segments:
            absolute_start = chunk.start_ms + segment.start_ms
            absolute_end = chunk.start_ms + segment.end_ms
            midpoint = (absolute_start + absolute_end) // 2
            if midpoint < chunk.core_start_ms or midpoint > chunk.core_end_ms:
                continue
            text = segment.text.strip()
            if not text:
                continue
            if merged:
                text = remove_text_overlap(merged[-1].text, text)
                if not text:
                    continue
            merged.append(
                TranscriptSegment(
                    start_ms=max(chunk.core_start_ms, absolute_start),
                    end_ms=min(chunk.core_end_ms, absolute_end),
                    text=text,
                    confidence=segment.confidence,
                    source=segment.source,
                    chunk_index=chunk.index,
                )
            )
    merged.sort(key=lambda item: (item.start_ms, item.end_ms, item.chunk_index or 0))
    return tuple(merged)
