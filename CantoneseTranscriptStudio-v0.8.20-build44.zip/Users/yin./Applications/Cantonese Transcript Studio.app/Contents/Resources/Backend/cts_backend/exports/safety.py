"""Format-specific neutralization for untrusted transcript text."""

from __future__ import annotations

import re
from typing import Mapping


_CSV_FORMULA_PREFIXES = frozenset("=+-@")
_SUBTITLE_TIMESTAMP_LINE = re.compile(
    r"(?:\d{1,}:[0-5]\d:[0-5]\d|[0-5]?\d:[0-5]\d)[,.]\d{3}"
    r"[ \t]*-->[ \t]*"
    r"(?:\d{1,}:[0-5]\d:[0-5]\d|[0-5]?\d:[0-5]\d)[,.]\d{3}"
    r"(?:[ \t]+[^\r\n]*)?"
)


def csv_safe_cell(value: object) -> object:
    """Neutralize spreadsheet formulas without changing non-string cells."""

    if not isinstance(value, str):
        return value
    candidate = value.lstrip(" \t")
    if candidate and candidate[0] in _CSV_FORMULA_PREFIXES:
        return f"'{value}"
    return value


def csv_safe_row(row: Mapping[str, object]) -> dict[str, object]:
    """Apply :func:`csv_safe_cell` to every string value in a CSV row."""

    return {key: csv_safe_cell(value) for key, value in row.items()}


def subtitle_safe_cue_text(text: str) -> str:
    """Keep normal cue line breaks while neutralizing structural cue content."""

    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    safe_lines: list[str] = []
    for line in normalized.split("\n"):
        candidate = line.strip()
        if not candidate:
            continue
        if _SUBTITLE_TIMESTAMP_LINE.fullmatch(candidate):
            line = f"'{line}"
        safe_lines.append(line)
    return "\n".join(safe_lines)


__all__ = ["csv_safe_cell", "csv_safe_row", "subtitle_safe_cue_text"]
