"""Persistent, injectable background orchestration for user-initiated YouTube imports."""

from __future__ import annotations

import hashlib
import fcntl
import importlib.util
import json
import logging
import os
import queue
import re
import shutil
import sys
import tempfile
import threading
import time
import uuid
from collections.abc import Callable, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

from ..audio.media import (
    OwnedProcessCancelled,
    OwnedProcessDeadlineExceeded,
    OwnedProcessOutputLimitExceeded,
    run_owned_process,
)
from .captions import parse_caption, preserve_and_normalize_caption
from .commands import (
    YtDlpRuntimePaths,
    build_artifact_argv,
    build_direct_artifact_argv,
    build_metadata_argv,
)
from .exports import export_caption_bundle
from .manifest import ArtifactManifestStore, ManifestError
from .playlist import plan_flat_playlist
from .progress import parse_artifact_line, parse_progress_line
from .ranking import rank_subtitle_tracks
from .schemas import (
    ArtifactKind,
    ArtifactManifest,
    ArtifactState,
    SubtitleSource,
    SubtitleTrack,
    YouTubeImportRequest,
)
from .threads import ThreadsPublicError, fetch_public_thread
from .urls import SocialPlatform, SocialURL, YouTubeResourceKind, YouTubeURL, validate_remote_url


IMPORT_SCHEMA = 1
MAX_MACHINE_STDOUT_BYTES = 32 * 1024 * 1024
MAX_MACHINE_LINE_BYTES = 1024 * 1024
MAX_IMPORT_MANIFEST_BYTES = 4 * 1024 * 1024
MAX_IMPORT_ENTRIES = 200
MAX_MEDIA_ARTIFACT_BYTES = 20 * 1024 * 1024 * 1024
MAX_SUBTITLE_ARTIFACT_BYTES = 64 * 1024 * 1024
MIN_FREE_SPACE_RESERVE_BYTES = 2 * 1024 * 1024 * 1024
UNKNOWN_DOWNLOAD_HEADROOM_BYTES = 512 * 1024 * 1024
YOUTUBE_PROCESS_TIMEOUT_SECONDS = 6 * 60 * 60.0
YOUTUBE_TERMINATION_GRACE_SECONDS = 2.0
_SAFE_IMPORT_ID = re.compile(r"^[0-9a-f-]{36}$")
_TERMINAL_STATES = frozenset({"completed", "completed_with_errors", "failed", "canceled"})
_URL_PATTERN = re.compile(r"https?://\S+", re.IGNORECASE)
_SECRET_PATTERN = re.compile(
    r"(?i)(cookie|authorization|token|signature|visitor_data)(\s*[:=]\s*)([^\s,;]+)"
)
_ERROR_PRIORITY = {
    "yt_dlp_failed": 0,
    "server_error": 10,
    "connection_interrupted": 20,
    "network_timeout": 25,
    "http_forbidden": 30,
    "rate_limited": 40,
    "youtube_po_token_required": 45,
    "youtube_login_required": 50,
    "youtube_bot_check": 60,
    "js_runtime_missing": 70,
    "ejs_missing_or_old": 70,
    "challenge_failed": 70,
    "ffmpeg_failed": 70,
    "disk_full": 80,
    "permission_denied": 80,
}

logger = logging.getLogger(__name__)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class YouTubeImportError(RuntimeError):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class YouTubeImportCancelled(YouTubeImportError):
    def __init__(self) -> None:
        super().__init__("canceled")


@dataclass(frozen=True)
class CommandResult:
    returncode: int
    stdout_lines: tuple[str, ...] = ()
    error_code: str | None = None


class CommandExecutor(Protocol):
    def execute(
        self,
        argv: tuple[str, ...],
        *,
        cancel_event: threading.Event,
        line_callback: Callable[[str], None] | None = None,
    ) -> CommandResult: ...


def _prefer_error(current: str | None, candidate: str) -> str:
    if current is None:
        return candidate
    if _ERROR_PRIORITY.get(candidate, 50) >= _ERROR_PRIORITY.get(current, 50):
        return candidate
    return current


def _classify_stderr(line: str, current: str | None) -> str | None:
    lowered = line.lower()
    for needle, code in (
        ("subtitles are only available when logged in", "bilibili_subtitle_login_required"),
        ("sign in to confirm you’re not a bot", "youtube_bot_check"),
        ("sign in to confirm you're not a bot", "youtube_bot_check"),
        ("confirm you are not a bot", "youtube_bot_check"),
        ("captcha", "youtube_bot_check"),
        ("http error 429", "rate_limited"),
        ("too many requests", "rate_limited"),
        ("request rate limit", "rate_limited"),
        ("gvs po token", "youtube_po_token_required"),
        ("po token", "youtube_po_token_required"),
        ("login required", "youtube_login_required"),
        ("sign in to confirm your age", "youtube_login_required"),
        ("members-only", "youtube_login_required"),
        ("private video", "private_video"),
        ("no video could be found", "video_unavailable"),
        ("is unavailable", "video_unavailable"),
        ("video unavailable", "video_unavailable"),
        ("copyright", "copyright_restricted"),
        ("drm", "drm_not_supported"),
        ("unsupported url", "unsupported_url"),
        ("requested format is not available", "format_unavailable"),
        ("timed out", "network_timeout"),
        ("timeout", "network_timeout"),
        ("incompleteread", "connection_interrupted"),
        ("connection reset", "connection_interrupted"),
        ("remote end closed", "connection_interrupted"),
        ("broken pipe", "connection_interrupted"),
        ("no supported javascript runtime", "js_runtime_missing"),
        ("challenge solver skipped", "ejs_missing_or_old"),
        ("outdated ejs", "ejs_missing_or_old"),
        ("nsig extraction failed", "challenge_failed"),
        ("signature extraction failed", "challenge_failed"),
        ("http error 403", "http_forbidden"),
        ("forbidden", "http_forbidden"),
        ("http error 500", "server_error"),
        ("http error 502", "server_error"),
        ("http error 503", "server_error"),
        ("http error 504", "server_error"),
        ("no space left on device", "disk_full"),
        ("permission denied", "permission_denied"),
        ("ffmpeg exited with code", "ffmpeg_failed"),
        ("postprocessing: error", "ffmpeg_failed"),
    ):
        if needle in lowered:
            return _prefer_error(current, code)
    return current


def _sanitize_stderr(line: str) -> str:
    """Return a bounded diagnostic with signed URLs and credentials removed."""

    clean = _URL_PATTERN.sub("[URL REDACTED]", line.replace("\x00", ""))
    clean = _SECRET_PATTERN.sub(r"\1\2[REDACTED]", clean)
    return " ".join(clean.split())[:2_000]


class SubprocessYtDlpExecutor:
    """Default executor.  Raw stderr and remote JSON are never logged."""

    def execute(
        self,
        argv: tuple[str, ...],
        *,
        cancel_event: threading.Event,
        line_callback: Callable[[str], None] | None = None,
    ) -> CommandResult:
        if not argv or not Path(argv[0]).is_absolute():
            raise YouTubeImportError("runtime_path_invalid")
        stdout_lines: list[str] = []
        error_code: str | None = None
        diagnostic_lines: list[str] = []
        pending_stdout = bytearray()
        pending_stderr = bytearray()

        def accept_stdout_line(raw_line: bytes) -> None:
            line = raw_line.rstrip(b"\r").decode("utf-8", errors="replace")
            stdout_lines.append(line)
            if line_callback is not None:
                line_callback(line + "\n")

        def accept_stdout(data: bytes) -> None:
            pending_stdout.extend(data)
            if len(pending_stdout) > MAX_MACHINE_LINE_BYTES and b"\n" not in pending_stdout:
                raise OwnedProcessOutputLimitExceeded
            while True:
                newline = pending_stdout.find(b"\n")
                if newline < 0:
                    return
                raw_line = bytes(pending_stdout[:newline])
                del pending_stdout[: newline + 1]
                accept_stdout_line(raw_line)

        def accept_stderr(data: bytes) -> None:
            nonlocal error_code
            pending_stderr.extend(data)
            while True:
                newline = pending_stderr.find(b"\n")
                if newline < 0:
                    break
                raw_line = bytes(pending_stderr[:newline])
                del pending_stderr[: newline + 1]
                decoded = raw_line.decode("utf-8", errors="replace")
                error_code = _classify_stderr(decoded, error_code)
                sanitized = _sanitize_stderr(decoded)
                if sanitized:
                    diagnostic_lines.append(sanitized)
                    del diagnostic_lines[:-12]
            if len(pending_stderr) > MAX_MACHINE_LINE_BYTES:
                error_code = _classify_stderr(
                    pending_stderr.decode("utf-8", errors="replace"), error_code
                )
                pending_stderr.clear()

        try:
            returncode, _, _ = run_owned_process(
                argv,
                timeout_seconds=YOUTUBE_PROCESS_TIMEOUT_SECONDS,
                termination_grace_seconds=YOUTUBE_TERMINATION_GRACE_SECONDS,
                cancel_requested=cancel_event.is_set,
                stdout_consumer=accept_stdout,
                stderr_consumer=accept_stderr,
                stdout_limit_bytes=MAX_MACHINE_STDOUT_BYTES,
            )
        except OwnedProcessCancelled as exc:
            raise YouTubeImportCancelled() from exc
        except OwnedProcessDeadlineExceeded as exc:
            raise YouTubeImportError("runtime_timeout") from exc
        except OwnedProcessOutputLimitExceeded as exc:
            raise YouTubeImportError("machine_output_too_large") from exc
        except (OSError, ValueError) as exc:
            raise YouTubeImportError("runtime_launch_failed") from exc
        if pending_stdout:
            accept_stdout_line(bytes(pending_stdout))
        if pending_stderr:
            error_code = _classify_stderr(
                pending_stderr.decode("utf-8", errors="replace"), error_code
            )
            sanitized = _sanitize_stderr(
                pending_stderr.decode("utf-8", errors="replace")
            )
            if sanitized:
                diagnostic_lines.append(sanitized)
                del diagnostic_lines[:-12]
        if returncode:
            logger.warning(
                "yt-dlp failed returncode=%s error_code=%s diagnostic=%s",
                returncode,
                error_code or "yt_dlp_failed",
                " | ".join(diagnostic_lines),
            )
        return CommandResult(
            returncode=returncode,
            stdout_lines=tuple(stdout_lines),
            error_code=error_code or ("yt_dlp_failed" if returncode else None),
        )


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        temporary.unlink(missing_ok=True)
        raise


class YouTubeImportStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).expanduser().resolve(strict=False)
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    @contextmanager
    def _locked(self):
        with self._lock:
            lock_path = self.root / ".import-store.lock"
            with lock_path.open("a+b") as handle:
                os.chmod(lock_path, 0o600)
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def workspace(self, import_id: str) -> Path:
        if _SAFE_IMPORT_ID.fullmatch(import_id) is None:
            raise ValueError("YouTube import id 無效")
        candidate = self.root / import_id
        # A UUID-looking child can be pre-created as a symlink.  Never let
        # subsequent mkdir/atomic writes reinterpret an external directory as
        # an import workspace.
        if candidate.is_symlink() or candidate.resolve(strict=False).parent != self.root:
            raise ValueError("YouTube import workspace 無效")
        return candidate

    def path(self, import_id: str) -> Path:
        return self.workspace(import_id) / "import.json"

    def create(self, value: Mapping[str, Any]) -> dict[str, Any]:
        import_id = str(value.get("id", ""))
        with self._locked():
            path = self.path(import_id)
            if path.exists():
                raise ValueError("YouTube import 已存在")
            payload = dict(value)
            self._validate_manifest_size(payload)
            _atomic_json(path, payload)
            return payload

    def get(self, import_id: str) -> dict[str, Any]:
        with self._locked():
            return self._get_unlocked(import_id)

    def _get_unlocked(self, import_id: str) -> dict[str, Any]:
        path = self.path(import_id)
        if (
            path.is_symlink()
            or not path.is_file()
            or path.stat().st_size > MAX_IMPORT_MANIFEST_BYTES
        ):
            raise KeyError(import_id)
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise YouTubeImportError("import_manifest_corrupt") from exc
        if not isinstance(value, dict) or value.get("id") != import_id:
            raise YouTubeImportError("import_manifest_corrupt")
        return value

    def save(
        self,
        import_id: str,
        value: Mapping[str, Any],
        *,
        expected_revision: int | None = None,
    ) -> dict[str, Any]:
        with self._locked():
            current = self._get_unlocked(import_id)
            payload = dict(value)
            if payload.get("id") != import_id:
                raise ValueError("YouTube import id 唔一致")
            current_revision = int(current.get("revision", 0))
            if expected_revision is None:
                candidate_revision = payload.get("revision")
                if isinstance(candidate_revision, bool) or not isinstance(candidate_revision, int):
                    raise YouTubeImportError("import_revision_missing")
                expected_revision = candidate_revision
            if expected_revision != current_revision:
                raise YouTubeImportError("import_revision_conflict")
            payload["revision"] = current_revision + 1
            payload["updated_at"] = _utc_now()
            self._validate_manifest_size(payload)
            _atomic_json(self.path(import_id), payload)
            return payload

    @staticmethod
    def _validate_manifest_size(value: Mapping[str, Any]) -> None:
        try:
            encoded = json.dumps(
                value,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                allow_nan=False,
            ).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise YouTubeImportError("import_manifest_corrupt") from exc
        # Include the newline written by _atomic_json so every accepted
        # manifest is guaranteed readable by get().
        if len(encoded) + 1 > MAX_IMPORT_MANIFEST_BYTES:
            raise YouTubeImportError("import_manifest_too_large")

    def list(self) -> tuple[dict[str, Any], ...]:
        output: list[dict[str, Any]] = []
        with self._locked():
            for path in sorted(self.root.glob("*/import.json")):
                try:
                    output.append(self._get_unlocked(path.parent.name))
                except (KeyError, YouTubeImportError):
                    continue
        return tuple(output)

    def recover(self) -> tuple[str, ...]:
        queued: list[str] = []
        for value in self.list():
            state = value.get("state")
            if state == "queued":
                queued.append(str(value["id"]))
                continue
            if state not in {"running", "interrupted"}:
                continue
            recovered = dict(value)
            recovered["state"] = "queued"
            recovered["error_code"] = None
            recovered["cancel_requested"] = False
            entries = []
            for entry in recovered.get("entries", []):
                item = dict(entry)
                if item.get("state") in {"running", "interrupted"}:
                    item["state"] = "planned"
                entries.append(item)
            recovered["entries"] = entries
            self.save(str(value["id"]), recovered)
            queued.append(str(value["id"]))
        return tuple(queued)


def _default_runtime(runtime_root: Path) -> YtDlpRuntimePaths:
    youtube_runtime = runtime_root / "youtube"
    ffmpeg = youtube_runtime / "ffmpeg"
    if not ffmpeg.is_file():
        ffmpeg = Path("/opt/homebrew/bin/ffmpeg")
    return YtDlpRuntimePaths(
        python_executable=sys.executable,
        deno_executable=youtube_runtime / "deno",
        ffmpeg_executable=ffmpeg,
    )


class YouTubeImportService:
    def __init__(
        self,
        *,
        root: str | Path,
        runtime_root: str | Path,
        executor: CommandExecutor | None = None,
        runtime: YtDlpRuntimePaths | None = None,
        event_callback: Callable[[str, dict[str, Any]], None] | None = None,
        enqueue_asr: Callable[[str, Mapping[str, Any]], Mapping[str, Any]] | None = None,
        recover: bool = True,
        runner_enabled: bool = True,
    ) -> None:
        self.store = YouTubeImportStore(root)
        self.runtime = runtime or _default_runtime(Path(runtime_root))
        self.executor = executor or SubprocessYtDlpExecutor()
        self._executor_injected = executor is not None
        self._event_callback = event_callback
        self._enqueue_asr = enqueue_asr
        self._runner_enabled = runner_enabled
        self._queue: queue.Queue[str | None] = queue.Queue()
        self._cancel: dict[str, threading.Event] = {}
        self._shutdown = threading.Event()
        self._runner_lock = threading.Lock()
        self._runner: threading.Thread | None = None
        queued = self.store.recover() if recover else ()
        for import_id in queued:
            self._queue.put(import_id)
        if queued:
            self._ensure_runner()

    def capabilities(self) -> dict[str, Any]:
        try:
            yt_dlp_available = importlib.util.find_spec("yt_dlp") is not None
        except (ImportError, ValueError):
            yt_dlp_available = False
        deno = Path(self.runtime.deno_executable)
        ffmpeg = Path(self.runtime.ffmpeg_executable)
        ready = self._executor_injected or (
            yt_dlp_available
            and deno.is_file()
            and os.access(deno, os.X_OK)
            and ffmpeg.is_file()
            and os.access(ffmpeg, os.X_OK)
        )
        return {
            "available": ready,
            "user_initiated_network_only": True,
            "normal_transcription_network": False,
            "platforms": [
                "youtube",
                "instagram",
                "threads",
                "x",
                "tiktok",
                "facebook",
                "reddit",
                "bilibili",
            ],
            # Threads is handled by the bounded public-page adapter below,
            # rather than by an upstream yt-dlp extractor.  Keep the capability
            # truthful so the native UI/diagnostics do not report a feature as
            # unavailable after the adapter has shipped.
            "threads_support": "public_page_adapter",
            "modes": ["video", "audio", "subtitles", "all"],
            "playlist_policies": ["expand", "reject"],
            "safety_limits": {
                "maximum_items_per_import": MAX_IMPORT_ENTRIES,
                "maximum_media_bytes_per_artifact": MAX_MEDIA_ARTIFACT_BYTES,
                "minimum_free_space_reserve_bytes": MIN_FREE_SPACE_RESERVE_BYTES,
            },
            "caption_preferences": [
                "manual_then_auto",
                "manual_only",
                "auto_only",
                "auto_then_manual",
            ],
            "runtime": {
                "yt_dlp": yt_dlp_available or self._executor_injected,
                "deno": self._executor_injected or deno.is_file(),
                "ffmpeg": self._executor_injected or ffmpeg.is_file(),
                "python_path": self.runtime.python_executable,
                "deno_path": self.runtime.deno_executable,
                "ffmpeg_path": self.runtime.ffmpeg_executable,
            },
        }

    def _emit(self, event: str, **payload: Any) -> None:
        if self._event_callback is not None:
            self._event_callback(event, payload)

    def _ensure_runner(self) -> None:
        if not self._runner_enabled or self._shutdown.is_set():
            return
        with self._runner_lock:
            if self._runner is not None and self._runner.is_alive():
                return
            self._runner = threading.Thread(
                target=self._run,
                name="cts-youtube-import-runner",
                daemon=True,
            )
            self._runner.start()

    def start(self, params: Mapping[str, Any]) -> dict[str, Any]:
        if self._shutdown.is_set():
            raise ValueError("Worker 正在關閉，唔可以開始 YouTube import")
        if not self.capabilities()["available"]:
            raise ValueError("YouTube runtime 尚未安裝完整")
        mode = params.get("mode", "all")
        if mode not in {"video", "audio", "subtitles", "all"}:
            raise ValueError("mode 只支援 video／audio／subtitles／all")
        playlist_policy = params.get("playlist_policy", "expand")
        if playlist_policy not in {"expand", "reject"}:
            raise ValueError("playlist_policy 只支援 expand／reject")
        caption_preference = params.get("caption_preference", "manual_then_auto")
        if caption_preference not in {
            "manual_then_auto",
            "manual_only",
            "auto_only",
            "auto_then_manual",
        }:
            raise ValueError("caption_preference 無效")
        asr_fallback = params.get("asr_fallback", True)
        transcribe = params.get("transcribe", False)
        if not isinstance(asr_fallback, bool) or not isinstance(transcribe, bool):
            raise ValueError("asr_fallback 同 transcribe 必須係 boolean")
        raw_urls = params.get("urls")
        if isinstance(raw_urls, str):
            urls = (raw_urls,)
        elif isinstance(raw_urls, Sequence) and not isinstance(raw_urls, (bytes, str)):
            urls = tuple(str(item) for item in raw_urls)
        else:
            raise ValueError("urls 必須係一條 URL 或 URL array")
        request = YouTubeImportRequest(
            urls=urls,
            rights_confirmed=params.get("rights_confirmed") is True,
            download_video=mode in {"video", "all"},
            download_audio=mode in {"audio", "all"},
            download_subtitles=mode in {"subtitles", "all"},
            allow_playlists=playlist_policy == "expand",
        )
        now = _utc_now()
        import_id = str(uuid.uuid4())
        payload = {
            "schema": IMPORT_SCHEMA,
            "id": import_id,
            "state": "queued",
            "created_at": now,
            "updated_at": now,
            "revision": 0,
            "cancel_requested": False,
            "error_code": None,
            "request": {
                **request.to_dict(),
                "mode": mode,
                "playlist_policy": playlist_policy,
                "caption_preference": caption_preference,
                "asr_fallback": asr_fallback,
                "transcribe": transcribe,
            },
            "current_item": 0,
            "total_items": None,
            "entries": [],
            "planning_failures": [],
        }
        self.store.create(payload)
        self._cancel[import_id] = threading.Event()
        self._queue.put(import_id)
        self._ensure_runner()
        self._emit("youtube.import.updated", import_id=import_id, import_job=payload)
        return payload

    def status(self, import_id: str) -> dict[str, Any]:
        return self.store.get(import_id)

    def list_imports(self) -> dict[str, Any]:
        return {"imports": list(self.store.list())}

    def cancel(self, import_id: str) -> dict[str, Any]:
        value = self.store.get(import_id)
        if value.get("state") in _TERMINAL_STATES:
            return value
        updated = dict(value)
        updated["cancel_requested"] = True
        if updated.get("state") in {"queued", "interrupted"}:
            updated["state"] = "canceled"
            updated["completed_at"] = _utc_now()
            updated["cancel_requested"] = False
        updated = self.store.save(import_id, updated)
        self._cancel.setdefault(import_id, threading.Event()).set()
        self._emit("youtube.import.updated", import_id=import_id, import_job=updated)
        return updated

    def retry(self, import_id: str) -> dict[str, Any]:
        value = self.store.get(import_id)
        if value.get("state") not in {"failed", "interrupted", "canceled", "completed_with_errors"}:
            raise ValueError("呢個 YouTube import 狀態唔可以 retry")
        updated = dict(value)
        updated.update(
            {
                "state": "queued",
                "cancel_requested": False,
                "error_code": None,
                "completed_at": None,
            }
        )
        updated = self.store.save(import_id, updated)
        self._cancel[import_id] = threading.Event()
        self._queue.put(import_id)
        self._ensure_runner()
        self._emit("youtube.import.updated", import_id=import_id, import_job=updated)
        return updated

    def shutdown(self, *, wait_timeout: float = 8.0) -> None:
        self._shutdown.set()
        for event in list(self._cancel.values()):
            event.set()
        self._queue.put(None)
        runner = self._runner
        if runner is not None and runner is not threading.current_thread() and runner.is_alive():
            runner.join(timeout=max(0.0, wait_timeout))

    def _save(self, import_id: str, value: dict[str, Any]) -> dict[str, Any]:
        for _ in range(3):
            current = self.store.get(import_id)
            payload = dict(value)
            if current.get("cancel_requested") and payload.get("state") not in _TERMINAL_STATES:
                payload["cancel_requested"] = True
            if current.get("state") == "canceled" and payload.get("state") == "running":
                value.clear()
                value.update(current)
                return current
            expected_revision = int(current.get("revision", 0))
            payload["revision"] = expected_revision
            try:
                saved = self.store.save(
                    import_id,
                    payload,
                    expected_revision=expected_revision,
                )
            except YouTubeImportError as exc:
                if exc.code == "import_revision_conflict":
                    continue
                raise
            value.clear()
            value.update(saved)
            self._emit("youtube.import.updated", import_id=import_id, import_job=saved)
            return saved
        raise YouTubeImportError("import_revision_conflict")

    def _run(self) -> None:
        while True:
            import_id = self._queue.get()
            if import_id is None:
                return
            cancel_event = self._cancel.setdefault(import_id, threading.Event())
            try:
                value = self.store.get(import_id)
                if value.get("state") != "queued" or cancel_event.is_set():
                    continue
                value["state"] = "running"
                value["started_at"] = value.get("started_at") or _utc_now()
                value["cancel_requested"] = False
                value = self._save(import_id, value)
                if value.get("state") != "running":
                    continue
                value = self._process_import(value, cancel_event)
                if cancel_event.is_set():
                    raise YouTubeImportCancelled()
                entries = value.get("entries", [])
                successful = sum(
                    item.get("state") in {"completed", "completed_with_errors"} for item in entries
                )
                errors = len(value.get("planning_failures", [])) + sum(
                    bool(item.get("error_codes")) for item in entries
                )
                value["state"] = (
                    "failed"
                    if successful == 0
                    else "completed_with_errors"
                    if errors
                    else "completed"
                )
                value["error_code"] = "partial_failure" if successful and errors else (
                    "all_items_failed" if not successful else None
                )
                value["completed_at"] = _utc_now()
                value = self._save(import_id, value)
            except YouTubeImportCancelled:
                value = self.store.get(import_id)
                shutting_down = self._shutdown.is_set() and not value.get("cancel_requested")
                value.update(
                    {
                        "state": "interrupted" if shutting_down else "canceled",
                        "cancel_requested": False,
                        "error_code": "interrupted" if shutting_down else None,
                        "completed_at": None if shutting_down else _utc_now(),
                    }
                )
                if shutting_down:
                    entries = []
                    for raw_entry in value.get("entries", []):
                        entry = dict(raw_entry)
                        if entry.get("state") == "running":
                            entry["state"] = "interrupted"
                            entry["error_codes"] = [
                                *entry.get("error_codes", []),
                                "interrupted",
                            ]
                        entries.append(entry)
                    value["entries"] = entries
                self._save(import_id, value)
            except YouTubeImportError as exc:
                value = self.store.get(import_id)
                value.update(
                    {"state": "failed", "error_code": exc.code, "completed_at": _utc_now()}
                )
                self._save(import_id, value)
            except Exception:
                value = self.store.get(import_id)
                value.update(
                    {"state": "failed", "error_code": "internal_error", "completed_at": _utc_now()}
                )
                self._save(import_id, value)
            finally:
                self._queue.task_done()

    def _execute(
        self,
        argv: tuple[str, ...],
        *,
        cancel_event: threading.Event,
        progress_callback: Callable[[str], None] | None = None,
    ) -> CommandResult:
        if cancel_event.is_set() or self._shutdown.is_set():
            raise YouTubeImportCancelled()
        result = self.executor.execute(
            argv,
            cancel_event=cancel_event,
            line_callback=progress_callback,
        )
        if cancel_event.is_set() or self._shutdown.is_set():
            raise YouTubeImportCancelled()
        if result.returncode != 0:
            raise YouTubeImportError(result.error_code or "yt_dlp_failed")
        return result

    @staticmethod
    def _metadata(result: CommandResult) -> dict[str, Any]:
        for line in reversed(result.stdout_lines):
            if len(line) > MAX_MACHINE_STDOUT_BYTES:
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
        raise YouTubeImportError("metadata_invalid")

    def _process_import(
        self,
        value: dict[str, Any],
        cancel_event: threading.Event,
    ) -> dict[str, Any]:
        import_id = str(value["id"])
        if not value.get("entries"):
            entries: list[dict[str, Any]] = []
            failures = list(value.get("planning_failures", []))
            seen: set[str] = set()
            for raw_url in value["request"]["urls"]:
                if cancel_event.is_set():
                    raise YouTubeImportCancelled()
                target = validate_remote_url(raw_url)
                if isinstance(target, SocialURL):
                    resource_id = target.resource_id
                    if resource_id not in seen:
                        seen.add(resource_id)
                        entries.append(
                            self._new_entry(
                                resource_id,
                                target.canonical_url,
                                len(entries) + 1,
                                None,
                                platform=target.platform.value,
                            )
                        )
                    continue
                if target.kind is YouTubeResourceKind.VIDEO:
                    assert target.video_id is not None
                    if target.video_id not in seen:
                        seen.add(target.video_id)
                        entries.append(
                            self._new_entry(
                                target.video_id,
                                target.canonical_url,
                                len(entries) + 1,
                                None,
                            )
                        )
                    continue
                try:
                    result = self._execute(
                        build_metadata_argv(self.runtime, target),
                        cancel_event=cancel_event,
                    )
                    plan = plan_flat_playlist(self._metadata(result))
                    if len(entries) + len(plan.entries) > MAX_IMPORT_ENTRIES:
                        raise YouTubeImportError("batch_too_large")
                    failures.extend(
                        {
                            "target": "playlist",
                            "position": failure.position,
                            "error_code": failure.reason,
                        }
                        for failure in plan.failures
                    )
                    for item in plan.entries:
                        if item.video_id in seen:
                            failures.append(
                                {
                                    "target": "playlist",
                                    "position": item.position,
                                    "error_code": "duplicate_video_id",
                                }
                            )
                            continue
                        seen.add(item.video_id)
                        entries.append(
                            self._new_entry(
                                item.video_id,
                                item.canonical_url,
                                len(entries) + 1,
                                item.display_title,
                            )
                        )
                except YouTubeImportCancelled:
                    raise
                except YouTubeImportError as exc:
                    failures.append(
                        {"target": "playlist", "position": None, "error_code": exc.code}
                    )
            total = len(entries)
            for index, entry in enumerate(entries, start=1):
                entry["position"] = index
                entry["total"] = total
            value["entries"] = entries
            value["planning_failures"] = failures
            value["total_items"] = total
            value = self._save(import_id, value)

        for index, raw_entry in enumerate(value.get("entries", []), start=1):
            if cancel_event.is_set():
                raise YouTubeImportCancelled()
            entry = dict(raw_entry)
            if entry.get("state") == "completed":
                continue
            value["current_item"] = index
            value = self._save(import_id, value)
            try:
                entry = self._process_entry(value, entry, cancel_event)
            except YouTubeImportCancelled:
                entry["state"] = "interrupted" if self._shutdown.is_set() else "canceled"
                if self._shutdown.is_set():
                    entry["error_codes"] = [*entry.get("error_codes", []), "interrupted"]
                self._replace_entry(value, entry)
                self._save(import_id, value)
                raise
            except YouTubeImportError as exc:
                entry["state"] = "failed"
                entry["error_codes"] = [*entry.get("error_codes", []), exc.code]
            except Exception:
                entry["state"] = "failed"
                entry["error_codes"] = [*entry.get("error_codes", []), "internal_error"]
            self._replace_entry(value, entry)
            value = self._save(import_id, value)
        return value

    @staticmethod
    def _metadata_size_hint(metadata: Mapping[str, Any]) -> int | None:
        candidates = []
        for key in ("filesize", "filesize_approx"):
            raw = metadata.get(key)
            if isinstance(raw, bool) or not isinstance(raw, (int, float)):
                continue
            if not float(raw).is_integer() or raw <= 0:
                continue
            candidates.append(int(raw))
        return max(candidates) if candidates else None

    @staticmethod
    def _artifact_limit(kind: ArtifactKind) -> int:
        return (
            MAX_SUBTITLE_ARTIFACT_BYTES
            if kind is ArtifactKind.SUBTITLE_RAW
            else MAX_MEDIA_ARTIFACT_BYTES
        )

    @classmethod
    def _ensure_download_capacity(
        cls,
        workspace: Path,
        kind: ArtifactKind,
        expected_bytes: int | None,
    ) -> None:
        limit = cls._artifact_limit(kind)
        if expected_bytes is not None and expected_bytes > limit:
            raise YouTubeImportError("artifact_too_large")
        required = expected_bytes or UNKNOWN_DOWNLOAD_HEADROOM_BYTES
        try:
            free = shutil.disk_usage(workspace).free
        except OSError as exc:
            raise YouTubeImportError("disk_space_unknown") from exc
        if free < MIN_FREE_SPACE_RESERVE_BYTES + required:
            raise YouTubeImportError("disk_space_low")

    @staticmethod
    def _cleanup_incomplete_downloads(workspace: Path) -> None:
        allowed_suffixes = {".part", ".ytdl", ".tmp", ".temp"}
        root = workspace.resolve(strict=True)
        for path in workspace.rglob("*"):
            try:
                if path.is_symlink() or not path.is_file() or path.suffix.lower() not in allowed_suffixes:
                    continue
                resolved = path.resolve(strict=True)
                resolved.relative_to(root)
                resolved.unlink(missing_ok=True)
            except (FileNotFoundError, OSError, ValueError):
                continue

    @staticmethod
    def _new_entry(
        video_id: str,
        canonical_url: str,
        position: int,
        display_title: str | None,
        platform: str = "youtube",
    ) -> dict[str, Any]:
        return {
            "video_id": video_id,
            "platform": platform,
            "canonical_url": canonical_url,
            "position": position,
            "total": None,
            "display_title": display_title,
            "state": "planned",
            "error_codes": [],
            "artifacts": {},
            "exports": {},
            "caption": None,
            "asr_job_id": None,
        }

    @staticmethod
    def _replace_entry(value: dict[str, Any], entry: dict[str, Any]) -> None:
        video_id = entry["video_id"]
        value["entries"] = [
            dict(entry) if item.get("video_id") == video_id else item
            for item in value.get("entries", [])
        ]

    @staticmethod
    def _rank_for_preference(
        metadata: Mapping[str, Any], preference: str
    ) -> tuple[SubtitleTrack, ...]:
        ranked = rank_subtitle_tracks(
            metadata.get("subtitles") if isinstance(metadata.get("subtitles"), Mapping) else None,
            metadata.get("automatic_captions")
            if isinstance(metadata.get("automatic_captions"), Mapping)
            else None,
        )
        manual = tuple(item for item in ranked if item.source is SubtitleSource.MANUAL)
        automatic = tuple(item for item in ranked if item.source is SubtitleSource.AUTOMATIC)
        if preference == "manual_only":
            return manual
        if preference == "auto_only":
            return automatic
        if preference == "auto_then_manual":
            return (*automatic, *manual)
        return ranked

    def _process_entry(
        self,
        batch: dict[str, Any],
        entry: dict[str, Any],
        cancel_event: threading.Event,
    ) -> dict[str, Any]:
        import_id = str(batch["id"])
        video_id = str(entry["video_id"])
        entry["state"] = "running"
        self._replace_entry(batch, entry)
        self._save(import_id, batch)
        video_workspace = self.store.workspace(import_id) / "videos" / video_id
        video_workspace.mkdir(parents=True, exist_ok=True)
        target = validate_remote_url(str(entry["canonical_url"]))
        direct_media_url: str | None = None
        if isinstance(target, SocialURL) and target.platform is SocialPlatform.THREADS:
            try:
                media = fetch_public_thread(target.canonical_url)
            except ThreadsPublicError as exc:
                raise YouTubeImportError(str(exc)) from exc
            direct_media_url = media.url
            metadata = {
                "id": video_id,
                "title": media.title or "Threads 影片",
                "subtitles": {},
                "automatic_captions": {},
            }
        else:
            metadata = self._metadata(
                self._execute(
                    build_metadata_argv(self.runtime, target),
                    cancel_event=cancel_event,
                )
            )
        if isinstance(target, YouTubeURL) and metadata.get("id") != video_id:
            raise YouTubeImportError("metadata_video_id_mismatch")
        if metadata.get("has_drm") is True or metadata.get("_has_drm") is True:
            raise YouTubeImportError("drm_not_supported")
        if isinstance(metadata.get("title"), str) and not entry.get("display_title"):
            title = " ".join(metadata["title"].split())[:180]
            entry["display_title"] = title or None

        request = batch["request"]
        mode = request["mode"]
        preference = request["caption_preference"]
        output_prefix = str(entry.get("platform") or "youtube")
        errors: list[str] = []
        artifacts = dict(entry.get("artifacts", {}))
        media_paths: dict[str, Path] = {}
        media_size_hint = self._metadata_size_hint(metadata)

        for kind in (
            ArtifactKind.VIDEO if mode in {"video", "all"} else None,
            ArtifactKind.AUDIO if mode in {"audio", "all"} else None,
        ):
            if kind is None:
                continue
            try:
                media_paths[kind.value] = self._download_artifact(
                    import_id=import_id,
                    video_id=video_id,
                    target_url=target.canonical_url,
                    workspace=video_workspace,
                    kind=kind,
                    track=None,
                    cancel_event=cancel_event,
                    item_position=int(entry["position"]),
                    item_total=int(entry["total"]),
                    output_prefix=output_prefix,
                    direct_url=direct_media_url,
                    expected_bytes=media_size_hint,
                )
                artifacts[kind.value] = str(media_paths[kind.value])
            except YouTubeImportCancelled:
                raise
            except YouTubeImportError as exc:
                errors.append(exc.code)

        caption_succeeded = False
        tracks = self._rank_for_preference(metadata, preference)
        if mode in {"subtitles", "all"} and tracks:
            last_caption_error = "caption_failed"
            attempts: list[dict[str, Any]] = []
            for attempt, track in enumerate(tracks, start=1):
                raw_manifest_id = f"subtitle-raw-{attempt}"
                normalized_manifest_id = f"subtitle-normalized-{attempt}"
                try:
                    raw_path = self._download_artifact(
                        import_id=import_id,
                        video_id=video_id,
                        target_url=target.canonical_url,
                        workspace=video_workspace,
                        kind=ArtifactKind.SUBTITLE_RAW,
                        track=track,
                        cancel_event=cancel_event,
                        item_position=int(entry["position"]),
                        item_total=int(entry["total"]),
                        artifact_id=raw_manifest_id,
                        output_prefix=output_prefix,
                        expected_bytes=None,
                    )
                    artifacts[ArtifactKind.SUBTITLE_RAW.value] = str(raw_path)
                    normalized_path, exports = self._normalize_and_export(
                        video_workspace,
                        video_id,
                        raw_path,
                        track,
                        raw_manifest_id=raw_manifest_id,
                        normalized_manifest_id=normalized_manifest_id,
                    )
                    artifacts[ArtifactKind.SUBTITLE_NORMALIZED.value] = str(normalized_path)
                    entry["exports"] = exports
                    entry["caption"] = track.to_dict()
                    attempts.append({**track.to_dict(), "result": "completed"})
                    caption_succeeded = True
                    break
                except YouTubeImportCancelled:
                    raise
                except (YouTubeImportError, ValueError, OSError, ManifestError) as exc:
                    last_caption_error = (
                        exc.code if isinstance(exc, YouTubeImportError) else "caption_failed"
                    )
                    attempts.append({**track.to_dict(), "result": "failed"})
            entry["caption_attempts"] = attempts
            if not caption_succeeded:
                errors.append(last_caption_error)
        elif mode in {"subtitles", "all"}:
            errors.append("no_suitable_caption")

        needs_asr = bool(request["transcribe"]) or (
            bool(request["asr_fallback"])
            and mode in {"subtitles", "all"}
            and not caption_succeeded
        )
        if needs_asr:
            if "audio" not in media_paths:
                try:
                    media_paths["audio"] = self._download_artifact(
                        import_id=import_id,
                        video_id=video_id,
                        target_url=target.canonical_url,
                        workspace=video_workspace,
                        kind=ArtifactKind.AUDIO,
                        track=None,
                        cancel_event=cancel_event,
                        item_position=int(entry["position"]),
                        item_total=int(entry["total"]),
                        output_prefix=output_prefix,
                        direct_url=direct_media_url,
                        expected_bytes=media_size_hint,
                    )
                    artifacts["audio"] = str(media_paths["audio"])
                except YouTubeImportCancelled:
                    raise
                except YouTubeImportError as exc:
                    errors.append(exc.code)
            source = media_paths.get("audio") or media_paths.get("video")
            if source is not None and self._enqueue_asr is not None and not entry.get("asr_job_id"):
                try:
                    asr = self._enqueue_asr(
                        str(source),
                        {
                            "youtube_import_id": import_id,
                            "youtube_video_id": video_id,
                            "youtube_caption_fallback": not caption_succeeded,
                        },
                    )
                    entry["asr_job_id"] = str(asr.get("id") or asr.get("job_id") or "") or None
                except Exception:
                    errors.append("asr_enqueue_failed")
            elif source is None:
                errors.append("asr_media_unavailable")

        entry["artifacts"] = artifacts
        entry["error_codes"] = list(dict.fromkeys(errors))
        succeeded = bool(artifacts or entry.get("asr_job_id"))
        entry["state"] = (
            "failed" if not succeeded else "completed_with_errors" if errors else "completed"
        )
        return entry

    def _download_artifact(
        self,
        *,
        import_id: str,
        video_id: str,
        target_url: str,
        workspace: Path,
        kind: ArtifactKind,
        track: SubtitleTrack | None,
        cancel_event: threading.Event,
        item_position: int,
        item_total: int,
        artifact_id: str | None = None,
        output_prefix: str = "youtube",
        direct_url: str | None = None,
        expected_bytes: int | None = None,
    ) -> Path:
        self._ensure_download_capacity(workspace, kind, expected_bytes)
        store = ArtifactManifestStore(workspace)
        artifact_id = artifact_id or kind.value
        try:
            manifest = store.get(artifact_id)
        except ManifestError:
            manifest = ArtifactManifest(
                artifact_id=artifact_id,
                video_id=video_id,
                kind=kind,
                state=ArtifactState.PLANNED,
                created_at=_utc_now(),
                updated_at=_utc_now(),
                subtitle_language=track.language if track else None,
                subtitle_source=track.source if track else None,
            )
            store.create(manifest)
        if manifest.state is ArtifactState.COMPLETED:
            try:
                return store.verify_completed(artifact_id)
            except ManifestError as exc:
                raise YouTubeImportError("artifact_integrity_failed") from exc
        if manifest.state is ArtifactState.DOWNLOADING:
            manifest = store.transition(
                artifact_id,
                ArtifactState.FAILED,
                updated_at=_utc_now(),
                error_code="interrupted",
            )
        try:
            manifest = store.transition(
                artifact_id,
                ArtifactState.DOWNLOADING,
                updated_at=_utc_now(),
            )
            if direct_url is not None:
                argv = build_direct_artifact_argv(
                    self.runtime,
                    direct_url,
                    kind=kind,
                    workspace=workspace,
                    video_id=video_id,
                    output_prefix=output_prefix,
                )
            else:
                argv = build_artifact_argv(
                    self.runtime,
                    target_url,
                    kind=kind,
                    workspace=workspace,
                    video_id=video_id,
                    subtitle_track=track,
                    output_prefix=output_prefix,
                )

            last_space_check = 0.0

            def on_line(line: str) -> None:
                nonlocal last_space_check
                progress = parse_progress_line(line)
                if progress is None:
                    return
                limit = self._artifact_limit(kind)
                if (
                    progress.downloaded_bytes is not None
                    and progress.downloaded_bytes > limit
                ) or (
                    progress.total_bytes is not None
                    and progress.total_bytes > limit
                ):
                    raise YouTubeImportError("artifact_too_large")
                now = time.monotonic()
                if now - last_space_check >= 0.5:
                    last_space_check = now
                    try:
                        free = shutil.disk_usage(workspace).free
                    except OSError as exc:
                        raise YouTubeImportError("disk_space_unknown") from exc
                    if free < MIN_FREE_SPACE_RESERVE_BYTES:
                        raise YouTubeImportError("disk_space_low")
                self._emit(
                    "youtube.import.progress",
                    import_id=import_id,
                    video_id=video_id,
                    artifact=kind.value,
                    item_position=item_position,
                    item_total=item_total,
                    status=progress.status,
                    downloaded_bytes=progress.downloaded_bytes,
                    total_bytes=progress.total_bytes,
                    fragment_index=progress.fragment_index,
                    fragment_count=progress.fragment_count,
                    progress=progress.ratio,
                )

            result = self._execute(argv, cancel_event=cancel_event, progress_callback=on_line)
            if kind is ArtifactKind.SUBTITLE_RAW:
                assert track is not None
                path = (
                    workspace
                    / "raw"
                    / kind.value
                    / f"{output_prefix}-{video_id}.{track.language}.{track.extension}"
                )
                if path.is_symlink() or not path.is_file():
                    raise YouTubeImportError("artifact_missing")
                path = path.resolve()
            else:
                path = next(
                    (
                        parsed
                        for line in reversed(result.stdout_lines)
                        if (
                            parsed := parse_artifact_line(
                                line,
                                workspace=workspace,
                                expected_video_id=video_id,
                            )
                        )
                        is not None
                    ),
                    None,
                )
                if path is None:
                    raise YouTubeImportError("artifact_missing")
            if path.stat().st_size > self._artifact_limit(kind):
                raise YouTubeImportError("artifact_too_large")
            relative = path.relative_to(workspace.resolve()).as_posix()
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                while block := handle.read(1024 * 1024):
                    digest.update(block)
            store.transition(
                artifact_id,
                ArtifactState.COMPLETED,
                updated_at=_utc_now(),
                relative_path=relative,
                size_bytes=path.stat().st_size,
                sha256=f"sha256:{digest.hexdigest()}",
            )
            return path
        except YouTubeImportCancelled:
            current = store.get(artifact_id)
            if current.state is ArtifactState.DOWNLOADING:
                store.transition(
                    artifact_id,
                    ArtifactState.CANCELED,
                    updated_at=_utc_now(),
                )
            if not self._shutdown.is_set():
                self._cleanup_incomplete_downloads(workspace)
            raise
        except YouTubeImportError as exc:
            current = store.get(artifact_id)
            if current.state is ArtifactState.DOWNLOADING:
                store.transition(
                    artifact_id,
                    ArtifactState.FAILED,
                    updated_at=_utc_now(),
                    error_code=exc.code,
                )
            self._cleanup_incomplete_downloads(workspace)
            raise

    def _normalize_and_export(
        self,
        workspace: Path,
        video_id: str,
        raw_path: Path,
        track: SubtitleTrack,
        *,
        raw_manifest_id: str,
        normalized_manifest_id: str,
    ) -> tuple[Path, dict[str, str]]:
        store = ArtifactManifestStore(workspace)
        artifact_id = normalized_manifest_id
        normalized = workspace / "normalized" / "subtitles" / f"{track.language}.vtt"
        try:
            manifest = store.get(artifact_id)
        except ManifestError:
            manifest = ArtifactManifest(
                artifact_id=artifact_id,
                video_id=video_id,
                kind=ArtifactKind.SUBTITLE_NORMALIZED,
                state=ArtifactState.PLANNED,
                created_at=_utc_now(),
                updated_at=_utc_now(),
                subtitle_language=track.language,
                subtitle_source=track.source,
                raw_artifact_id=raw_manifest_id,
            )
            store.create(manifest)
        if manifest.state is ArtifactState.COMPLETED:
            try:
                normalized = store.verify_completed(artifact_id)
            except ManifestError as exc:
                raise YouTubeImportError("artifact_integrity_failed") from exc
        else:
            if manifest.state is ArtifactState.DOWNLOADING:
                store.transition(
                    artifact_id,
                    ArtifactState.FAILED,
                    updated_at=_utc_now(),
                    error_code="interrupted",
                )
            store.transition(
                artifact_id,
                ArtifactState.DOWNLOADING,
                updated_at=_utc_now(),
            )
            result = preserve_and_normalize_caption(
                raw_path,
                raw_path,
                normalized,
                source_format=track.extension,
                output_format="vtt",
            )
            store.transition(
                artifact_id,
                ArtifactState.COMPLETED,
                updated_at=_utc_now(),
                relative_path=normalized.relative_to(workspace).as_posix(),
                size_bytes=result.normalized_size_bytes,
                sha256=result.normalized_sha256,
            )
        cues = parse_caption(normalized.read_text(encoding="utf-8"), "vtt")
        exports = export_caption_bundle(
            cues,
            workspace / "exports",
            video_id=video_id,
            language=track.language,
            source=track.source.value,
        )
        return normalized, exports
