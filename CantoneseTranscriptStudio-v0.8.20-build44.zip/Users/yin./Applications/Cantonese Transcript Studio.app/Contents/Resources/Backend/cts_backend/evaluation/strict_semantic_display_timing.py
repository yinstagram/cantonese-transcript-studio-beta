"""Scoped timing metrics after strict semantic extent and a global text path."""

from __future__ import annotations

from collections import Counter
import html
import re
from typing import Mapping, Sequence
from urllib.parse import parse_qs, urlsplit

from .scoped_ai_semantic_timing import (
    SCOPED_REGISTRY_IDS,
    SCOPED_VIDEO_ID,
    ScopedAISemanticTimingError,
    _require_int,
    _require_list,
    _require_mapping,
    _require_text,
    _stats,
    _timing_grade,
    _validate_canonical,
    _validate_yin_feedback,
)
from .semantic_extent_judge import SEMANTIC_EXTENT_JUDGE_POLICY_VERSION
from .semantic_pairing import (
    SemanticPairingError,
    assert_no_timestamp_fields,
    canonical_sha256,
    validate_blind_review_packet_shape,
    validate_bundle,
)


STRICT_SEMANTIC_DISPLAY_TIMING_POLICY_VERSION = (
    "o8-strict-semantic-display-timing-m2-2026-09-08"
)
_REQUIRED_FILE_HASHES = frozenset(
    {
        "proposals",
        "blind_packet",
        "bundle",
        "model_run",
        "yin_feedback",
        "candidate_final",
        "reference_vtt",
    }
)
_SEMANTIC_TAG_RE = re.compile(r"<[^>]+>")


def _semantic_projection_text(value: object) -> str:
    """Mirror the sealed bundle's text-only projection without changing timing."""

    if not isinstance(value, str):
        raise ScopedAISemanticTimingError("candidate final cue text is invalid")
    return " ".join(html.unescape(_SEMANTIC_TAG_RE.sub("", value)).split())


def _validate_video_scope(value: object, label: str) -> Mapping[str, object]:
    scope = _require_mapping(value, f"{label} scope")
    if scope.get("video_id") != SCOPED_VIDEO_ID:
        raise ScopedAISemanticTimingError(f"{label} video identity mismatch")
    url = _require_text(scope.get("youtube_url"), f"{label} YouTube URL")
    parsed = urlsplit(url)
    if parsed.scheme != "https":
        raise ScopedAISemanticTimingError(f"{label} YouTube URL scheme mismatch")
    valid_short = (
        parsed.hostname == "youtu.be"
        and parsed.path.strip("/") == SCOPED_VIDEO_ID
    )
    valid_watch = (
        parsed.hostname in {"www.youtube.com", "youtube.com"}
        and parsed.path == "/watch"
        and parse_qs(parsed.query).get("v") == [SCOPED_VIDEO_ID]
    )
    if not (valid_short or valid_watch):
        raise ScopedAISemanticTimingError(f"{label} YouTube URL identity mismatch")
    if scope.get("production_wide_human_gold_claim") is not False:
        raise ScopedAISemanticTimingError(f"{label} broader human-gold boundary unsafe")
    return scope


def _validate_final(
    envelope: Mapping[str, object], expected_hash: str
) -> tuple[Mapping[str, object], Mapping[str, Mapping[str, object]]]:
    value = _require_mapping(envelope.get("value"), "candidate final value")
    fingerprint = _require_text(envelope.get("fingerprint"), "candidate fingerprint")
    if envelope.get("complete") is not True or envelope.get(
        "payload_sha256"
    ) != canonical_sha256({"fingerprint": fingerprint, "value": value}):
        raise ScopedAISemanticTimingError("candidate final integrity seal mismatch")
    segments = _require_list(value.get("subtitle_segments"), "candidate final cues")
    by_id: dict[str, Mapping[str, object]] = {}
    for raw in segments:
        cue = _require_mapping(raw, "candidate final cue")
        cue_id = _require_text(cue.get("id"), "candidate final cue ID")
        if cue_id in by_id:
            raise ScopedAISemanticTimingError("candidate final cue ID duplicated")
        by_id[cue_id] = cue
    if not expected_hash or len(expected_hash) != 64:
        raise ScopedAISemanticTimingError("candidate final file hash missing")
    return value, by_id


def _path_better(
    left: tuple[int, ...],
    right: tuple[int, ...],
    nodes: Sequence[Mapping[str, object]],
    *,
    reference_count: int,
    candidate_count: int,
) -> tuple[int, ...]:
    if len(left) != len(right):
        return left if len(left) > len(right) else right

    def deviation(path: tuple[int, ...]) -> int:
        total = 0
        for index in path:
            node = nodes[index]
            first = int(node["first_ordinal"])
            last = int(node["last_ordinal"])
            reference = int(node["reference_ordinal"])
            candidate_twice = first + last
            reference_twice = reference * 2
            total += abs(
                candidate_twice * reference_count
                - reference_twice * candidate_count
            )
        return total

    left_deviation = deviation(left)
    right_deviation = deviation(right)
    if left_deviation != right_deviation:
        return left if left_deviation < right_deviation else right
    left_ids = tuple(str(nodes[index]["candidate_span_id"]) for index in left)
    right_ids = tuple(str(nodes[index]["candidate_span_id"]) for index in right)
    return left if left_ids <= right_ids else right


def maximum_cardinality_monotonic_path(
    nodes: Sequence[Mapping[str, object]],
    *,
    reference_count: int,
    candidate_count: int,
) -> tuple[int, ...]:
    """Return a deterministic time-blind, non-overlapping candidate path."""

    if not nodes:
        return ()
    best_ending: list[tuple[int, ...]] = []
    for index, node in enumerate(nodes):
        best_prefix: tuple[int, ...] = ()
        first = int(node["first_ordinal"])
        for previous_index, previous in enumerate(nodes[:index]):
            if int(previous["last_ordinal"]) >= first:
                continue
            best_prefix = _path_better(
                best_prefix,
                best_ending[previous_index],
                nodes,
                reference_count=reference_count,
                candidate_count=candidate_count,
            )
        best_ending.append((*best_prefix, index))
    best: tuple[int, ...] = ()
    for path in best_ending:
        best = _path_better(
            best,
            path,
            nodes,
            reference_count=reference_count,
            candidate_count=candidate_count,
        )
    return best


def _candidate_requires_timing_review(
    cues: Sequence[Mapping[str, object]],
) -> bool:
    return any(cue.get("timing_review_required") is True for cue in cues)


def evaluate_strict_semantic_display_timing(
    *,
    proposals: Mapping[str, object],
    blind_packet: Mapping[str, object],
    bundle: Mapping[str, object],
    model_run: Mapping[str, object],
    yin_feedback: Mapping[str, object],
    candidate_final: Mapping[str, object],
    file_hashes: Mapping[str, str],
) -> dict[str, object]:
    if set(file_hashes) != _REQUIRED_FILE_HASHES or any(
        not isinstance(value, str) or len(value) != 64
        for value in file_hashes.values()
    ):
        raise ScopedAISemanticTimingError("actual file-hash binding is incomplete")
    _validate_canonical(
        proposals,
        schema="cts.semantic-pairing-proposals/v1",
        hash_field="proposals_canonical_sha256",
        label="pairing proposals",
    )
    _validate_canonical(
        blind_packet,
        schema="cts.semantic-pairing-blind-review-packet/v1",
        hash_field="packet_canonical_sha256",
        label="blind packet",
    )
    _validate_canonical(
        model_run,
        schema="cts.local-semantic-extent-judge-run/v1",
        hash_field="run_canonical_sha256",
        label="strict extent model run",
    )
    try:
        validate_bundle(bundle)
        validate_blind_review_packet_shape(blind_packet)
        assert_no_timestamp_fields(blind_packet)
    except SemanticPairingError as exc:
        raise ScopedAISemanticTimingError(str(exc)) from exc
    scopes = [
        _validate_video_scope(proposals.get("scope"), "proposals"),
        _validate_video_scope(blind_packet.get("scope"), "blind packet"),
        _validate_video_scope(bundle.get("scope"), "bundle"),
    ]
    if len({str(scope["youtube_url"]) for scope in scopes}) != 1:
        raise ScopedAISemanticTimingError("semantic artifact URL scope mismatch")
    _validate_yin_feedback(yin_feedback)

    authority = _require_mapping(proposals.get("authority"), "proposal authority")
    packet_authority = _require_mapping(
        blind_packet.get("authority"), "blind packet authority"
    )
    for field in (
        "bundle_file_sha256",
        "bundle_canonical_sha256",
        "candidate_text_projection_sha256",
    ):
        if authority.get(field) != packet_authority.get(field):
            raise ScopedAISemanticTimingError(f"proposal/packet authority mismatch: {field}")
    if (
        authority.get("bundle_file_sha256") != file_hashes["bundle"]
        or authority.get("bundle_canonical_sha256")
        != bundle.get("bundle_canonical_sha256")
    ):
        raise ScopedAISemanticTimingError("proposal bundle binding mismatch")
    feedback = _require_mapping(
        authority.get("yin_feedback_authority"), "Yin feedback authority"
    )
    if feedback.get("sha256") != file_hashes["yin_feedback"]:
        raise ScopedAISemanticTimingError("Yin feedback hash mismatch")
    run_authority = _require_mapping(
        model_run.get("input_authority"), "model run authority"
    )
    if (
        run_authority.get("proposals_sha256") != file_hashes["proposals"]
        or run_authority.get("blind_packet_sha256") != file_hashes["blind_packet"]
        or run_authority.get("proposals_canonical_sha256")
        != proposals.get("proposals_canonical_sha256")
        or run_authority.get("blind_packet_canonical_sha256")
        != blind_packet.get("packet_canonical_sha256")
    ):
        raise ScopedAISemanticTimingError("strict model run input binding mismatch")
    run_scope = _require_mapping(model_run.get("scope"), "model run scope")
    if (
        model_run.get("policy_version") != SEMANTIC_EXTENT_JUDGE_POLICY_VERSION
        or run_scope.get("strict_same_extent_required_for_same_meaning") is not True
        or model_run.get("semantic_selection_used_candidate_timing") is not False
        or model_run.get("blind_packet_contains_numeric_timing_values") is not False
        or model_run.get("timing_metric_rows") != 0
        or model_run.get("automatic_timing_mutation") is not False
        or model_run.get("installed_app_mutated") is not False
        or model_run.get("production_release_verdict") is not False
    ):
        raise ScopedAISemanticTimingError("strict model run safety boundary mismatch")

    artifacts = _require_mapping(bundle.get("source_artifacts"), "bundle sources")
    reference_source = _require_mapping(
        artifacts.get("reference_vtt"), "reference VTT source"
    )
    candidate_source = _require_mapping(
        artifacts.get("candidate_final"), "candidate final source"
    )
    if (
        reference_source.get("sha256") != file_hashes["reference_vtt"]
        or candidate_source.get("sha256") != file_hashes["candidate_final"]
        or candidate_source.get("integrity_seal_valid") is not True
    ):
        raise ScopedAISemanticTimingError("bundle source-file binding mismatch")
    _, final_cues = _validate_final(candidate_final, file_hashes["candidate_final"])

    references = {
        _require_text(row.get("unit_id"), "reference ID"): row
        for raw in _require_list(proposals.get("reference_units"), "reference units")
        for row in [_require_mapping(raw, "reference unit")]
    }
    atoms = {
        _require_text(row.get("atom_id"), "atom ID"): row
        for raw in _require_list(proposals.get("candidate_atoms"), "candidate atoms")
        for row in [_require_mapping(raw, "candidate atom")]
    }
    spans = {
        _require_text(row.get("span_id"), "span ID"): row
        for raw in _require_list(proposals.get("candidate_spans"), "candidate spans")
        for row in [_require_mapping(raw, "candidate span")]
    }
    packet_units = {
        _require_text(row.get("reference_unit_id"), "packet unit ID"): row
        for raw in _require_list(blind_packet.get("units"), "packet units")
        for row in [_require_mapping(raw, "packet unit")]
    }
    bundle_units = {
        _require_text(row.get("unit_id"), "bundle unit ID"): row
        for raw in _require_list(bundle.get("units"), "bundle units")
        for row in [_require_mapping(raw, "bundle unit")]
    }
    bundle_cues = {
        _require_text(row.get("cue_id"), "bundle cue ID"): row
        for raw in _require_list(bundle.get("candidate_cues"), "bundle cues")
        for row in [_require_mapping(raw, "bundle cue")]
    }
    if len(references) != len(proposals.get("reference_units", [])) or len(
        bundle_cues
    ) != len(bundle.get("candidate_cues", [])):
        raise ScopedAISemanticTimingError("duplicate source identity")
    for cue_id, cue in bundle_cues.items():
        final = final_cues.get(cue_id)
        if (
            final is None
            or cue.get("text") != _semantic_projection_text(final.get("text"))
            or any(
                cue.get(field) != final.get(field)
                for field in ("start_ms", "end_ms")
            )
        ):
            raise ScopedAISemanticTimingError("bundle/final cue mismatch")

    start_ordinal = _require_int(
        run_scope.get("sample_reference_ordinal_start"), "sample start", minimum=1
    )
    end_ordinal = _require_int(
        run_scope.get("sample_reference_ordinal_end"),
        "sample end",
        minimum=start_ordinal,
    )
    sample_count = _require_int(
        run_scope.get("sample_reference_units"), "sample count", minimum=1
    )
    judgments = _require_list(model_run.get("judgments"), "model judgments")
    if len(judgments) != sample_count or end_ordinal - start_ordinal + 1 != sample_count:
        raise ScopedAISemanticTimingError("strict model sample window mismatch")

    nodes: list[dict[str, object]] = []
    base_rows: list[dict[str, object]] = []
    for offset, raw in enumerate(judgments):
        wrapper = _require_mapping(raw, "judgment wrapper")
        unit_id = _require_text(wrapper.get("reference_unit_id"), "judgment unit ID")
        ordinal = _require_int(wrapper.get("reference_ordinal"), "judgment ordinal")
        if ordinal != start_ordinal + offset:
            raise ScopedAISemanticTimingError("judgments are not a contiguous ordered window")
        reference = references.get(unit_id)
        unit = bundle_units.get(unit_id)
        packet_unit = packet_units.get(unit_id)
        if (
            reference is None
            or unit is None
            or packet_unit is None
            or reference.get("ordinal") != ordinal
            or unit.get("reference_text") != reference.get("text")
        ):
            raise ScopedAISemanticTimingError("judgment source identity mismatch")
        judgment = _require_mapping(wrapper.get("judgment"), "judgment")
        audit = _require_mapping(judgment.get("audit"), "judgment audit")
        row: dict[str, object] = {
            "reference_unit_id": unit_id,
            "reference_ordinal": ordinal,
            "reference_text": reference.get("text"),
            "reference_start_ms": unit.get("reference_start_ms"),
            "reference_end_ms": unit.get("reference_end_ms"),
            "model_status": audit.get("status"),
            "model_relation": judgment.get("relation"),
            "candidate_span_id": judgment.get("candidate_span_id"),
            "candidate_atom_ids": judgment.get("evidence_atom_ids", []),
            "semantic_timing_status": "UNASSESSABLE",
            "timing_grade": "UNASSESSABLE",
            "reason": "model_did_not_propose_strict_same_extent",
        }
        base_rows.append(row)
        if audit.get("status") != "model_proposed" or judgment.get(
            "relation"
        ) != "same_meaning":
            continue
        span_id = _require_text(judgment.get("candidate_span_id"), "selected span ID")
        span = spans.get(span_id)
        if span is None:
            raise ScopedAISemanticTimingError("model selected unknown span")
        atom_ids = _require_list(span.get("atom_ids"), "selected span atoms")
        if judgment.get("evidence_atom_ids") != atom_ids or any(
            not isinstance(atom_id, str) or atom_id not in atoms for atom_id in atom_ids
        ):
            raise ScopedAISemanticTimingError("selected span evidence mismatch")
        options = packet_unit.get("candidate_options")
        if not isinstance(options, list) or not any(
            isinstance(option, Mapping)
            and option.get("candidate_span_id") == span_id
            and option.get("candidate_atom_ids") == atom_ids
            for option in options
        ):
            raise ScopedAISemanticTimingError("selected span was not a blind option")
        first = _require_int(span.get("first_ordinal"), "span first", minimum=1)
        last = _require_int(span.get("last_ordinal"), "span last", minimum=first)
        if [atoms[str(atom)]["ordinal"] for atom in atom_ids] != list(
            range(first, last + 1)
        ):
            raise ScopedAISemanticTimingError("selected span is not contiguous")
        nodes.append(
            {
                "row_index": len(base_rows) - 1,
                "reference_unit_id": unit_id,
                "reference_ordinal": ordinal,
                "candidate_span_id": span_id,
                "candidate_atom_ids": list(atom_ids),
                "candidate_text": span.get("text"),
                "first_ordinal": first,
                "last_ordinal": last,
            }
        )

    path = maximum_cardinality_monotonic_path(
        nodes,
        reference_count=len(references),
        candidate_count=len(atoms),
    )
    selected_node_indexes = set(path)
    starts: list[int] = []
    ends: list[int] = []
    maximums: list[int] = []
    rejection_counts = Counter()
    for node_index, node in enumerate(nodes):
        row = base_rows[int(node["row_index"])]
        row["candidate_text"] = node["candidate_text"]
        if node_index not in selected_node_indexes:
            row["reason"] = "not_on_maximum_cardinality_monotonic_path"
            rejection_counts[str(row["reason"])] += 1
            continue
        selected_cues = [bundle_cues[str(value)] for value in node["candidate_atom_ids"]]
        final_selected = [final_cues[str(value)] for value in node["candidate_atom_ids"]]
        review_required = _candidate_requires_timing_review(final_selected)
        row["candidate_timing_review_required"] = review_required
        if review_required:
            row["reason"] = "candidate_timing_review_required"
            rejection_counts[str(row["reason"])] += 1
            continue
        candidate_start = int(selected_cues[0]["start_ms"])
        candidate_end = int(selected_cues[-1]["end_ms"])
        reference_start = int(row["reference_start_ms"])
        reference_end = int(row["reference_end_ms"])
        start_error = candidate_start - reference_start
        end_error = candidate_end - reference_end
        start_abs = abs(start_error)
        end_abs = abs(end_error)
        maximum = max(start_abs, end_abs)
        row.update(
            {
                "candidate_start_ms": candidate_start,
                "candidate_end_ms": candidate_end,
                "start_error_ms": start_error,
                "end_error_ms": end_error,
                "start_absolute_error_ms": start_abs,
                "end_absolute_error_ms": end_abs,
                "max_edge_absolute_error_ms": maximum,
                "candidate_timing_review_required": False,
                "semantic_timing_status": "ELIGIBLE_AI_SCOPED_REFERENCE_ONLY",
                "timing_grade": _timing_grade(start_abs, end_abs),
                "reason": "strict_same_extent_on_global_monotonic_path",
            }
        )
        starts.append(start_abs)
        ends.append(end_abs)
        maximums.append(maximum)

    grades = Counter(str(row["timing_grade"]) for row in base_rows)
    relation_counts = Counter(str(row["model_relation"]) for row in base_rows)
    status_counts = Counter(str(row["model_status"]) for row in base_rows)
    eligible_rows = [
        row
        for row in base_rows
        if row["semantic_timing_status"] == "ELIGIBLE_AI_SCOPED_REFERENCE_ONLY"
    ]
    failures = sorted(
        eligible_rows,
        key=lambda row: int(row["max_edge_absolute_error_ms"]),
        reverse=True,
    )[:10]
    report: dict[str, object] = {
        "schema": "cts.o8-strict-semantic-display-timing-report/v1",
        "policy_version": STRICT_SEMANTIC_DISPLAY_TIMING_POLICY_VERSION,
        "scope": {
            "video_id": SCOPED_VIDEO_ID,
            "youtube_url": scopes[0]["youtube_url"],
            "scoped_reference_role": "gold for this O8 comparison only",
            "ai_semantic_validation": True,
            "human_confirmation": False,
            "production_wide_human_gold_claim": False,
            "broader_human_gold_gate_overwritten": False,
            "automatic_timing_mutation": False,
            "installed_app_mutated": False,
            "production_release_verdict": False,
        },
        "registry_authority": sorted(SCOPED_REGISTRY_IDS),
        "input_bindings": {
            "file_sha256": dict(file_hashes),
            "proposals_canonical_sha256": proposals["proposals_canonical_sha256"],
            "blind_packet_canonical_sha256": blind_packet["packet_canonical_sha256"],
            "bundle_canonical_sha256": bundle["bundle_canonical_sha256"],
            "model_run_canonical_sha256": model_run["run_canonical_sha256"],
        },
        "sample": {
            "reference_ordinal_start": start_ordinal,
            "reference_ordinal_end": end_ordinal,
            "reference_units": sample_count,
            "full_reference_units": len(references),
            "strict_same_extent_model_proposals": len(nodes),
            "text_path_selected_rows": len(path),
            "candidate_timing_review_rejections": rejection_counts.get(
                "candidate_timing_review_required", 0
            ),
            "eligible_timing_rows": len(eligible_rows),
            "eligible_coverage": len(eligible_rows) / sample_count,
        },
        "semantic_path": {
            "algorithm": "maximum_cardinality_forward_nonoverlap",
            "candidate_timing_used": False,
            "tie_break": "minimum_normalized_text_ordinal_deviation_then_span_id",
            "selected_reference_unit_ids": [
                str(nodes[index]["reference_unit_id"]) for index in path
            ],
            "rejected_reference_unit_ids": [
                str(node["reference_unit_id"])
                for index, node in enumerate(nodes)
                if index not in selected_node_indexes
            ],
        },
        "semantic_model_counts": {
            "status": dict(sorted(status_counts.items())),
            "relation": dict(sorted(relation_counts.items())),
            "structural_rejections": dict(sorted(rejection_counts.items())),
        },
        "timing": {
            "grade_counts": {
                grade: grades.get(grade, 0)
                for grade in ("ON_TIME", "SLIGHT_OFFSET", "OFF_TIME", "UNASSESSABLE")
            },
            "start_absolute_error_ms": _stats(starts),
            "end_absolute_error_ms": _stats(ends),
            "max_edge_absolute_error_ms": _stats(maximums),
            "bands": {
                "ON_TIME": "both display edges <= 500 ms",
                "SLIGHT_OFFSET": "both display edges <= 2000 ms but not ON_TIME",
                "OFF_TIME": "at least one display edge > 2000 ms",
                "UNASSESSABLE": "no strict semantic extent on the global monotonic path",
            },
            "measurement_target": (
                "sealed readable-display cue edges versus grouped O8 reference cue edges"
            ),
            "acoustic_onset_or_offset_proof": False,
        },
        "rows": base_rows,
        "failure_samples": failures,
        "claims": [
            {
                "label": "FACT",
                "confidence": 100,
                "claim": "Semantic selection and global occurrence resolution used no candidate or reference timestamps.",
            },
            {
                "label": "FACT",
                "confidence": 100,
                "claim": "Only strict same-extent model proposals on the maximum-cardinality forward non-overlapping text path, with no candidate timing-review flag, contribute timing rows.",
            },
            {
                "label": "INFERENCE",
                "confidence": 65,
                "claim": "Accepted rows estimate display-edit burden for this scoped O8 pilot; Gemma proposals are not human confirmations and may contain semantic mistakes.",
            },
            {
                "label": "UNKNOWN",
                "confidence": 100,
                "claim": "Acoustic truth, full-video accuracy, multi-video generalization, and production release readiness remain unproven.",
            },
        ],
    }
    report["report_canonical_sha256"] = canonical_sha256(report)
    return report


__all__ = [
    "STRICT_SEMANTIC_DISPLAY_TIMING_POLICY_VERSION",
    "_candidate_requires_timing_review",
    "evaluate_strict_semantic_display_timing",
    "maximum_cardinality_monotonic_path",
]
