from __future__ import annotations

import unicodedata
from difflib import SequenceMatcher
from typing import Iterable, Sequence

from rapidfuzz import fuzz
from rapidfuzz.distance import Levenshtein

from .confidence import disagreement_ratio, reconciliation_confidence
from ..schemas import (
    AlignmentAudit,
    Correction,
    ReconciledSegment,
    TranscriptSegment,
)


# Persisted alignment checkpoints are invalidated when deterministic
# reconciliation behaviour changes.
RECONCILIATION_POLICY_VERSION = "2026-08-05.1"


def _is_comparison_character(character: str) -> bool:
    category = unicodedata.category(character)
    return not character.isspace() and not category.startswith(("P", "S", "Z", "C"))


def _comparison_projection(text: str) -> tuple[list[str], list[int]]:
    characters: list[str] = []
    raw_indices: list[int] = []
    for raw_index, character in enumerate(text):
        if not _is_comparison_character(character):
            continue
        folded = character.casefold()
        for folded_character in folded:
            characters.append(folded_character)
            raw_indices.append(raw_index)
    return characters, raw_indices


def _raw_slice(text: str, raw_indices: Sequence[int], start: int, end: int) -> tuple[int, int, str]:
    if start == end:
        insertion = raw_indices[start] if start < len(raw_indices) else len(text)
        return insertion, insertion, ""
    raw_start = raw_indices[start]
    raw_end = raw_indices[end - 1] + 1
    return raw_start, raw_end, text[raw_start:raw_end]


def _normalized_vocabulary(vocabulary: Iterable[str]) -> tuple[str, ...]:
    output: list[str] = []
    for term in vocabulary:
        chars, _ = _comparison_projection(term)
        normalized = "".join(chars)
        if normalized and normalized not in output:
            output.append(normalized)
    return tuple(sorted(output, key=lambda value: (-len(value), value)))


def _vocabulary_supports_edit(
    primary: str,
    verifier: str,
    *,
    primary_start: int,
    primary_end: int,
    verifier_start: int,
    verifier_end: int,
    vocabulary: Sequence[str],
) -> bool:
    for term in vocabulary:
        search_from = 0
        while True:
            occurrence = verifier.find(term, search_from)
            if occurrence < 0:
                break
            occurrence_end = occurrence + len(term)
            if occurrence <= verifier_start and verifier_end <= occurrence_end:
                relative = verifier_start - occurrence
                candidate_start = primary_start - relative
                candidate_end = candidate_start + len(term)
                if 0 <= candidate_start and candidate_end <= len(primary):
                    candidate = primary[candidate_start:candidate_end]
                    allowed_distance = max(1, len(term) // 5)
                    if Levenshtein.distance(candidate, term) <= allowed_distance:
                        return True
            search_from = occurrence + 1
    return False


def reconcile_text(
    primary_text: str,
    verifier_text: str,
    *,
    primary_confidence: float | None = None,
    vocabulary: Iterable[str] = (),
    anchor_characters: int = 2,
    maximum_edit_span: int = 4,
    low_similarity_threshold: float = 0.85,
    low_primary_confidence_threshold: float = 0.60,
) -> tuple[str, AlignmentAudit]:
    """Conservatively reconcile verifier differences while retaining the primary skeleton."""
    if anchor_characters < 1 or maximum_edit_span < 1:
        raise ValueError("anchor_characters and maximum_edit_span must be positive")

    primary_chars, primary_indices = _comparison_projection(primary_text)
    verifier_chars, verifier_indices = _comparison_projection(verifier_text)
    primary = "".join(primary_chars)
    verifier = "".join(verifier_chars)
    vocabulary_terms = _normalized_vocabulary(vocabulary)

    if not primary and not verifier:
        audit = AlignmentAudit(
            similarity=1.0,
            edit_distance=0,
            disagreement_count=0,
            missing_in_verifier=False,
            conflict=False,
            low_confidence=primary_confidence is not None
            and primary_confidence < low_primary_confidence_threshold,
            reasons=("primary_low_confidence",)
            if primary_confidence is not None
            and primary_confidence < low_primary_confidence_threshold
            else ("verifier_agreement",),
            disagreement_ratio=0.0,
            missing=False,
            conflict_candidate=False,
        )
        return primary_text, audit

    similarity = round(fuzz.ratio(primary, verifier) / 100.0, 6)
    edit_distance = int(Levenshtein.distance(primary, verifier))
    ratio = disagreement_ratio(edit_distance, len(primary), len(verifier))
    missing_in_verifier = bool(primary and not verifier)
    reasons: list[str] = []
    corrections: list[Correction] = []

    if not primary and verifier:
        reasons.extend(("primary_missing", "unresolved_disagreement"))
        audit = AlignmentAudit(
            similarity=similarity,
            edit_distance=edit_distance,
            disagreement_count=edit_distance,
            missing_in_verifier=False,
            conflict=True,
            low_confidence=True,
            reasons=tuple(reasons),
            disagreement_ratio=ratio,
            missing=True,
            conflict_candidate=True,
        )
        return primary_text, audit
    if missing_in_verifier:
        reasons.extend(("verifier_missing", "unresolved_disagreement"))
        if primary_confidence is not None and primary_confidence < low_primary_confidence_threshold:
            reasons.append("primary_low_confidence")
        audit = AlignmentAudit(
            similarity=similarity,
            edit_distance=edit_distance,
            disagreement_count=edit_distance,
            missing_in_verifier=True,
            conflict=True,
            low_confidence=True,
            reasons=tuple(reasons),
            disagreement_ratio=ratio,
            missing=True,
            conflict_candidate=True,
        )
        return primary_text, audit

    matcher = SequenceMatcher(a=primary_chars, b=verifier_chars, autojunk=False)
    opcodes = matcher.get_opcodes()
    pending: list[tuple[int, int, str, Correction]] = []
    for opcode_index, (tag, i1, i2, j1, j2) in enumerate(opcodes):
        if tag == "equal":
            continue
        primary_length = i2 - i1
        verifier_length = j2 - j1
        if tag != "replace" or primary_length != verifier_length:
            continue
        if primary_length == 0 or primary_length > maximum_edit_span:
            continue

        left_anchor = 0
        right_anchor = 0
        if opcode_index > 0 and opcodes[opcode_index - 1][0] == "equal":
            left_anchor = opcodes[opcode_index - 1][2] - opcodes[opcode_index - 1][1]
        if opcode_index + 1 < len(opcodes) and opcodes[opcode_index + 1][0] == "equal":
            right_anchor = opcodes[opcode_index + 1][2] - opcodes[opcode_index + 1][1]

        strongly_anchored = (
            primary_length == 1
            and similarity >= 0.90
            and left_anchor >= max(3, anchor_characters)
            and right_anchor >= max(3, anchor_characters)
        )
        strongly_edge_anchored = (
            primary_length == 1
            and similarity >= 0.94
            and (
                (i1 == 0 and right_anchor >= max(6, anchor_characters * 2))
                or (i2 == len(primary_chars) and left_anchor >= max(6, anchor_characters * 2))
            )
        )
        vocabulary_supported = _vocabulary_supports_edit(
            primary,
            verifier,
            primary_start=i1,
            primary_end=i2,
            verifier_start=j1,
            verifier_end=j2,
            vocabulary=vocabulary_terms,
        )
        if not (strongly_anchored or strongly_edge_anchored or vocabulary_supported):
            continue

        raw_start, raw_end, before = _raw_slice(primary_text, primary_indices, i1, i2)
        _, _, after = _raw_slice(verifier_text, verifier_indices, j1, j2)
        reason = "vocabulary_correction" if vocabulary_supported else "anchored_correction"
        correction = Correction(
            primary_start=raw_start,
            primary_end=raw_end,
            before=before,
            after=after,
            reason=reason,
        )
        pending.append((raw_start, raw_end, after, correction))

    final_text = primary_text
    for raw_start, raw_end, replacement, correction in reversed(pending):
        final_text = final_text[:raw_start] + replacement + final_text[raw_end:]
        corrections.append(correction)
    corrections.reverse()

    final_chars, _ = _comparison_projection(final_text)
    unresolved = "".join(final_chars) != verifier
    if edit_distance == 0:
        reasons.append("verifier_agreement")
    else:
        reasons.extend(correction.reason for correction in corrections if correction.reason not in reasons)
        if unresolved:
            reasons.append("unresolved_disagreement")
    if similarity < low_similarity_threshold:
        reasons.append("low_similarity")
    if primary_confidence is not None and primary_confidence < low_primary_confidence_threshold:
        reasons.append("primary_low_confidence")

    conflict = unresolved and edit_distance > 0
    low_confidence = (
        conflict
        or similarity < low_similarity_threshold
        or (
            primary_confidence is not None
            and primary_confidence < low_primary_confidence_threshold
        )
    )
    audit = AlignmentAudit(
        similarity=similarity,
        edit_distance=edit_distance,
        disagreement_count=edit_distance,
        missing_in_verifier=False,
        conflict=conflict,
        low_confidence=low_confidence,
        reasons=tuple(reasons),
        corrections=tuple(corrections),
        disagreement_ratio=ratio,
        missing=False,
        conflict_candidate=edit_distance > 0,
    )
    return final_text, audit


def _join_fragments(fragments: Sequence[str]) -> str:
    output = ""
    for fragment in fragments:
        fragment = fragment.strip()
        if not fragment:
            continue
        if output and output[-1].isascii() and output[-1].isalnum() and fragment[0].isascii() and fragment[0].isalnum():
            output += " "
        output += fragment
    return output


def reconcile_segments(
    primary_segments: Sequence[TranscriptSegment],
    verifier_segments: Sequence[TranscriptSegment],
    *,
    vocabulary: Iterable[str] = (),
) -> tuple[ReconciledSegment, ...]:
    reconciled: list[ReconciledSegment] = []
    for primary in primary_segments:
        overlaps = [
            verifier
            for verifier in verifier_segments
            if verifier.end_ms > primary.start_ms and verifier.start_ms < primary.end_ms
        ]
        verifier_text = _join_fragments([segment.text for segment in overlaps])
        final_text, audit = reconcile_text(
            primary.text,
            verifier_text,
            primary_confidence=primary.confidence,
            vocabulary=vocabulary,
        )
        confidence = reconciliation_confidence(
            similarity=audit.similarity,
            ratio=audit.disagreement_ratio,
            missing=audit.missing,
            conflict=audit.conflict,
            corrected=bool(audit.corrections),
            primary_confidence=primary.confidence,
        )
        reconciled.append(
            ReconciledSegment(
                start_ms=primary.start_ms,
                end_ms=primary.end_ms,
                primary_text=primary.text,
                verifier_text=verifier_text,
                text=final_text,
                confidence=confidence,
                audit=audit,
            )
        )
    return tuple(reconciled)
