"""Transcript-free metrics for a fixed timestamp gold reference."""

from __future__ import annotations

import math
import statistics
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any


_ERROR_THRESHOLDS_MS = (100, 250, 500, 1_000)


@dataclass(frozen=True)
class _WindowMetadata:
    source_start: int
    source_end: int
    core_start_ms: int
    core_end_ms: int
    actual_start_ms: int
    actual_end_ms: int


def _strict_int(value: Any, *, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{label} must be an integer")
    return value


def _coerce_items(values: Sequence[Mapping[str, Any]], *, label: str) -> dict[tuple[int, int], tuple[int, int]]:
    output: dict[tuple[int, int], tuple[int, int]] = {}
    for index, raw in enumerate(values):
        if not isinstance(raw, Mapping):
            raise ValueError(f"{label}[{index}] must be an object")
        source_start = _strict_int(raw.get("source_start"), label=f"{label}.source_start")
        source_end = _strict_int(raw.get("source_end"), label=f"{label}.source_end")
        start_ms = _strict_int(raw.get("start_ms"), label=f"{label}.start_ms")
        end_ms = _strict_int(raw.get("end_ms"), label=f"{label}.end_ms")
        if not (0 <= source_start < source_end and 0 <= start_ms <= end_ms):
            raise ValueError(f"{label}[{index}] has an invalid range")
        key = (source_start, source_end)
        if key in output:
            raise ValueError(f"{label} has a duplicate source span")
        output[key] = (start_ms, end_ms)
    return output


def _percentile(values: Sequence[int], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    rank = max(1, math.ceil(percentile * len(ordered)))
    return float(ordered[rank - 1])


def _error_summary(start_errors: Sequence[int], end_errors: Sequence[int]) -> dict[str, Any]:
    boundaries = [*start_errors, *end_errors]
    return {
        "items": len(start_errors),
        "start_median_ms": round(statistics.median(start_errors), 3) if start_errors else None,
        "start_p95_ms": _percentile(start_errors, 0.95),
        "end_median_ms": round(statistics.median(end_errors), 3) if end_errors else None,
        "end_p95_ms": _percentile(end_errors, 0.95),
        "boundary_median_ms": round(statistics.median(boundaries), 3) if boundaries else None,
        "boundary_p95_ms": _percentile(boundaries, 0.95),
        "boundary_max_ms": float(max(boundaries)) if boundaries else None,
    }


def _boundary_error_summary(signed_errors: Sequence[int]) -> dict[str, Any]:
    absolute = [abs(value) for value in signed_errors]
    return {
        "boundaries": len(signed_errors),
        "signed_median_ms": (
            round(statistics.median(signed_errors), 3) if signed_errors else None
        ),
        "absolute_median_ms": (
            round(statistics.median(absolute), 3) if absolute else None
        ),
        "absolute_p95_ms": _percentile(absolute, 0.95),
        "absolute_max_ms": float(max(absolute)) if absolute else None,
        "early_count": sum(value < 0 for value in signed_errors),
        "exact_count": sum(value == 0 for value in signed_errors),
        "late_count": sum(value > 0 for value in signed_errors),
        "absolute_error_over_ms": {
            str(threshold): sum(value > threshold for value in absolute)
            for threshold in _ERROR_THRESHOLDS_MS
        },
    }


def _paired_boundary_summary(
    start_signed: Sequence[int], end_signed: Sequence[int]
) -> dict[str, Any]:
    return {
        "items": len(start_signed),
        "start": _boundary_error_summary(start_signed),
        "end": _boundary_error_summary(end_signed),
        "combined": _boundary_error_summary([*start_signed, *end_signed]),
    }


def _coerce_windows(values: Sequence[Mapping[str, Any]]) -> tuple[_WindowMetadata, ...]:
    output: list[_WindowMetadata] = []
    previous_source_end = 0
    for index, raw in enumerate(values):
        if not isinstance(raw, Mapping):
            raise ValueError(f"window_metadata[{index}] must be an object")
        item = _WindowMetadata(
            source_start=_strict_int(
                raw.get("source_start"), label="window_metadata.source_start"
            ),
            source_end=_strict_int(
                raw.get("source_end"), label="window_metadata.source_end"
            ),
            core_start_ms=_strict_int(
                raw.get("core_start_ms"), label="window_metadata.core_start_ms"
            ),
            core_end_ms=_strict_int(
                raw.get("core_end_ms"), label="window_metadata.core_end_ms"
            ),
            actual_start_ms=_strict_int(
                raw.get("actual_start_ms"), label="window_metadata.actual_start_ms"
            ),
            actual_end_ms=_strict_int(
                raw.get("actual_end_ms"), label="window_metadata.actual_end_ms"
            ),
        )
        if not (
            0 <= item.source_start < item.source_end
            and item.source_start >= previous_source_end
            and 0
            <= item.actual_start_ms
            <= item.core_start_ms
            < item.core_end_ms
            <= item.actual_end_ms
        ):
            raise ValueError(f"window_metadata[{index}] has an invalid range")
        output.append(item)
        previous_source_end = item.source_end
    return tuple(output)


def _window_for_span(
    key: tuple[int, int], windows: Sequence[_WindowMetadata]
) -> tuple[int, _WindowMetadata] | None:
    matches = [
        (index, item)
        for index, item in enumerate(windows)
        if item.source_start <= key[0] and key[1] <= item.source_end
    ]
    if len(matches) > 1:
        raise ValueError("window metadata assigns one source span more than once")
    return matches[0] if matches else None


def _append_pair(
    groups: dict[str, tuple[list[int], list[int]]],
    name: str,
    start_signed: int,
    end_signed: int,
) -> None:
    starts, ends = groups.setdefault(name, ([], []))
    starts.append(start_signed)
    ends.append(end_signed)


def _append_boundary(
    groups: dict[str, list[int]], name: str, signed_error: int
) -> None:
    groups.setdefault(name, []).append(signed_error)


def timing_accuracy_report(
    reference: Sequence[Mapping[str, Any]],
    hypothesis: Sequence[Mapping[str, Any]],
    *,
    seam_times_ms: Sequence[int] = (),
    seam_margin_ms: int = 1_500,
) -> dict[str, Any]:
    """Compare exact source spans without returning transcript text."""

    if isinstance(seam_margin_ms, bool) or not isinstance(seam_margin_ms, int) or seam_margin_ms < 0:
        raise ValueError("seam_margin_ms must be a non-negative integer")
    seams = tuple(sorted({_strict_int(value, label="seam_time") for value in seam_times_ms}))
    if seams and seams[0] < 0:
        raise ValueError("seam times must be non-negative")
    gold = _coerce_items(reference, label="reference")
    candidate = _coerce_items(hypothesis, label="hypothesis")
    matched_keys = sorted(set(gold) & set(candidate))

    all_start: list[int] = []
    all_end: list[int] = []
    seam_start: list[int] = []
    seam_end: list[int] = []
    interior_start: list[int] = []
    interior_end: list[int] = []
    for key in matched_keys:
        gold_start, gold_end = gold[key]
        candidate_start, candidate_end = candidate[key]
        start_error = abs(candidate_start - gold_start)
        end_error = abs(candidate_end - gold_end)
        all_start.append(start_error)
        all_end.append(end_error)
        is_seam = any(
            min(abs(gold_start - seam), abs(gold_end - seam)) <= seam_margin_ms
            for seam in seams
        )
        if is_seam:
            seam_start.append(start_error)
            seam_end.append(end_error)
        else:
            interior_start.append(start_error)
            interior_end.append(end_error)

    denominator = len(gold)
    return {
        "schema_version": 1,
        "privacy": {
            "contains_audio": False,
            "contains_transcript_text": False,
            "contains_source_paths": False,
        },
        "reference_items": denominator,
        "hypothesis_items": len(candidate),
        "matched_items": len(matched_keys),
        "unmatched_reference_items": denominator - len(matched_keys),
        "unexpected_hypothesis_items": len(set(candidate) - set(gold)),
        "coverage_rate": round(len(matched_keys) / denominator, 6) if denominator else 1.0,
        "seam_margin_ms": seam_margin_ms,
        "seam_count": len(seams),
        "all": _error_summary(all_start, all_end),
        "seam_adjacent": _error_summary(seam_start, seam_end),
        "interior": _error_summary(interior_start, interior_end),
    }


def timing_accuracy_report_v2(
    reference: Sequence[Mapping[str, Any]],
    hypothesis: Sequence[Mapping[str, Any]],
    *,
    window_metadata: Sequence[Mapping[str, Any]] = (),
    seam_times_ms: Sequence[int] = (),
    seam_margin_ms: int = 1_500,
    reference_cues: Sequence[Mapping[str, Any]] = (),
    hypothesis_cues: Sequence[Mapping[str, Any]] = (),
) -> dict[str, Any]:
    """Return signed, edge-aware timing diagnostics without transcript data.

    Exact source spans are used only as an in-memory join key.  The returned
    report contains aggregate counts and ordinal window buckets, never source
    spans, transcript text, audio, or filesystem paths.
    """

    legacy = timing_accuracy_report(
        reference,
        hypothesis,
        seam_times_ms=seam_times_ms,
        seam_margin_ms=seam_margin_ms,
    )
    gold = _coerce_items(reference, label="reference")
    candidate = _coerce_items(hypothesis, label="hypothesis")
    windows = _coerce_windows(window_metadata)
    matched_keys = sorted(set(gold) & set(candidate))
    pair_groups: dict[str, tuple[list[int], list[int]]] = {}
    boundary_groups: dict[str, list[int]] = {}
    per_window: dict[int, tuple[list[int], list[int]]] = {}
    worst_boundaries: list[dict[str, Any]] = []

    first_key = matched_keys[0] if matched_keys else None
    last_key = matched_keys[-1] if matched_keys else None
    for key in matched_keys:
        gold_start, gold_end = gold[key]
        candidate_start, candidate_end = candidate[key]
        start_signed = candidate_start - gold_start
        end_signed = candidate_end - gold_end
        _append_pair(pair_groups, "all", start_signed, end_signed)
        assigned = _window_for_span(key, windows)
        if assigned is not None:
            window_index, window = assigned
            starts, ends = per_window.setdefault(window_index, ([], []))
            starts.append(start_signed)
            ends.append(end_signed)
            # Token position is defined by the immutable reference, not by the
            # surviving hypothesis.  A missing first token must not make the
            # second token look like a valid segment-leading edge.
            words_in_window = [
                reference_key
                for reference_key in sorted(gold)
                if window.source_start <= reference_key[0]
                and reference_key[1] <= window.source_end
            ]
            word_index = words_in_window.index(key)
            if word_index == 0:
                _append_pair(
                    pair_groups, "segment_first_word", start_signed, end_signed
                )
                _append_boundary(
                    boundary_groups, "segment_leading_edge", start_signed
                )
            if word_index == 1:
                _append_pair(
                    pair_groups, "segment_second_word", start_signed, end_signed
                )
            if word_index == len(words_in_window) - 2:
                _append_pair(
                    pair_groups,
                    "segment_penultimate_word",
                    start_signed,
                    end_signed,
                )
            if word_index == len(words_in_window) - 1:
                _append_pair(
                    pair_groups, "segment_last_word", start_signed, end_signed
                )
                _append_boundary(
                    boundary_groups, "segment_trailing_edge", end_signed
                )
            if 0 < word_index < len(words_in_window) - 1:
                _append_pair(pair_groups, "interior_words", start_signed, end_signed)

            for boundary_kind, boundary_ms, signed_error in (
                ("start", gold_start, start_signed),
                ("end", gold_end, end_signed),
            ):
                start_distance = abs(boundary_ms - window.core_start_ms)
                end_distance = abs(boundary_ms - window.core_end_ms)
                edge_class = "interior"
                if word_index == 0 and boundary_kind == "start":
                    edge_class = "segment_leading_edge"
                elif word_index == len(words_in_window) - 1 and boundary_kind == "end":
                    edge_class = "segment_trailing_edge"
                elif min(start_distance, end_distance) <= 250:
                    edge_class = "core_edge_0_250ms"
                elif min(start_distance, end_distance) <= 750:
                    edge_class = "core_edge_250_750ms"
                worst_boundaries.append(
                    {
                        "window_ordinal": window_index,
                        "word_ordinal_within_target": word_index,
                        "boundary_kind": boundary_kind,
                        "edge_class": edge_class,
                        "signed_error_ms": signed_error,
                        "absolute_error_ms": abs(signed_error),
                        "core_edge_distance_ms": min(start_distance, end_distance),
                        "actual_window_edge_distance_ms": min(
                            abs(boundary_ms - window.actual_start_ms),
                            abs(boundary_ms - window.actual_end_ms),
                        ),
                    }
                )
                if start_distance <= 250:
                    _append_boundary(
                        boundary_groups, "core_start_0_250ms", signed_error
                    )
                elif start_distance <= 750:
                    _append_boundary(
                        boundary_groups, "core_start_250_750ms", signed_error
                    )
                if end_distance <= 250:
                    _append_boundary(
                        boundary_groups, "core_end_0_250ms", signed_error
                    )
                elif end_distance <= 750:
                    _append_boundary(
                        boundary_groups, "core_end_250_750ms", signed_error
                    )
                if abs(boundary_ms - window.actual_start_ms) <= 250:
                    _append_boundary(
                        boundary_groups, "actual_window_start_0_250ms", signed_error
                    )
                if abs(boundary_ms - window.actual_end_ms) <= 250:
                    _append_boundary(
                        boundary_groups, "actual_window_end_0_250ms", signed_error
                    )

        if key == first_key:
            _append_boundary(boundary_groups, "first_global_edge", start_signed)
        if key == last_key:
            _append_boundary(boundary_groups, "last_global_edge", end_signed)

    cue_report: dict[str, Any] | None = None
    if reference_cues or hypothesis_cues:
        cue_gold = _coerce_items(reference_cues, label="reference_cues")
        cue_candidate = _coerce_items(hypothesis_cues, label="hypothesis_cues")
        cue_keys = sorted(set(cue_gold) & set(cue_candidate))
        cue_start = [
            cue_candidate[key][0] - cue_gold[key][0] for key in cue_keys
        ]
        cue_end = [cue_candidate[key][1] - cue_gold[key][1] for key in cue_keys]
        cue_report = {
            "reference_items": len(cue_gold),
            "hypothesis_items": len(cue_candidate),
            "matched_items": len(cue_keys),
            "coverage_rate": (
                round(len(cue_keys) / len(cue_gold), 6) if cue_gold else 1.0
            ),
            "errors": _paired_boundary_summary(cue_start, cue_end),
        }

    return {
        "schema_version": 2,
        "privacy": dict(legacy["privacy"]),
        "reference_items": legacy["reference_items"],
        "hypothesis_items": legacy["hypothesis_items"],
        "matched_items": legacy["matched_items"],
        "unmatched_reference_items": legacy["unmatched_reference_items"],
        "unexpected_hypothesis_items": legacy["unexpected_hypothesis_items"],
        "coverage_rate": legacy["coverage_rate"],
        "signed_word_errors": {
            name: _paired_boundary_summary(starts, ends)
            for name, (starts, ends) in sorted(pair_groups.items())
        },
        "boundary_groups": {
            name: _boundary_error_summary(values)
            for name, values in sorted(boundary_groups.items())
        },
        "per_window": [
            {
                "window_ordinal": index,
                "errors": _paired_boundary_summary(starts, ends),
            }
            for index, (starts, ends) in sorted(per_window.items())
        ],
        "worst_boundaries": sorted(
            worst_boundaries,
            key=lambda item: (
                -item["absolute_error_ms"],
                item["window_ordinal"],
                item["word_ordinal_within_target"],
                item["boundary_kind"],
            ),
        )[:20],
        "cue_errors": cue_report,
        "legacy_core_end_adjacent_1500ms": legacy["seam_adjacent"],
    }


__all__ = ["timing_accuracy_report", "timing_accuracy_report_v2"]
