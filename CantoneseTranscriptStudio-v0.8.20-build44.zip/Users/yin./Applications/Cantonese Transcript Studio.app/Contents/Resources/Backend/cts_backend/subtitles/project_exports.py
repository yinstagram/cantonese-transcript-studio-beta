"""Atomic, revision-addressed exports for editable subtitle projects."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import tempfile
import uuid
from pathlib import Path
from typing import Any, Mapping

from ..exports.safety import csv_safe_row, subtitle_safe_cue_text
from .schemas import SubtitleCue, SubtitleProject


EXPORT_SCHEMA = 1
EXPORT_FORMATS = ("txt", "timestamp_txt", "srt", "vtt", "json", "csv")
EXPORT_FILENAMES = {
    "txt": "transcript.txt",
    "timestamp_txt": "transcript.timestamps.txt",
    "srt": "subtitles.srt",
    "vtt": "subtitles.vtt",
    "json": "subtitle-project.json",
    "csv": "subtitles.csv",
}
MANIFEST_FILENAME = "manifest.json"


def _sha256(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def _project_digest(project: SubtitleProject) -> str:
    encoded = json.dumps(
        project.to_dict(),
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return _sha256(encoded)


def _timestamp(milliseconds: int, *, decimal: str) -> str:
    milliseconds = max(0, int(milliseconds))
    hours, remainder = divmod(milliseconds, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    seconds, millis = divmod(remainder, 1_000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}{decimal}{millis:03d}"


def _display_cues(project: SubtitleProject) -> tuple[SubtitleCue, ...]:
    return tuple(cue for cue in project.segments if cue.text.strip())


def _caption_text(project: SubtitleProject, cue: SubtitleCue) -> str:
    speaker = next(
        (speaker for speaker in project.speakers if speaker.id == cue.speaker_id),
        None,
    )
    if speaker is not None and speaker.show_name:
        return f"{speaker.display_name}：{cue.text}"
    return cue.text


def _txt(project: SubtitleProject) -> str:
    text = "".join(cue.text for cue in project.segments)
    return text + ("\n" if text and not text.endswith("\n") else "")


def _timestamp_txt(project: SubtitleProject) -> str:
    lines = [
        (
            f"[{_timestamp(cue.start_ms, decimal='.')} → "
            f"{_timestamp(cue.end_ms, decimal='.')}] {_caption_text(project, cue)}"
        )
        for cue in _display_cues(project)
    ]
    return "\n".join(lines) + ("\n" if lines else "")


def _srt(project: SubtitleProject) -> str:
    blocks = [
        (
            f"{index}\n"
            f"{_timestamp(cue.start_ms, decimal=',')} --> "
            f"{_timestamp(cue.end_ms, decimal=',')}\n"
            f"{subtitle_safe_cue_text(_caption_text(project, cue))}"
        )
        for index, cue in enumerate(_display_cues(project), start=1)
    ]
    return "\n\n".join(blocks) + ("\n" if blocks else "")


def _vtt(project: SubtitleProject) -> str:
    blocks = ["WEBVTT"]
    blocks.extend(
        (
            f"{_timestamp(cue.start_ms, decimal='.')} --> "
            f"{_timestamp(cue.end_ms, decimal='.')}\n"
            f"{subtitle_safe_cue_text(_caption_text(project, cue))}"
        )
        for cue in _display_cues(project)
    )
    return "\n\n".join(blocks) + "\n"


def _json_export(project: SubtitleProject) -> str:
    value = project.to_dict()
    value.update(
        {
            "export_schema": EXPORT_SCHEMA,
            "project_revision": project.revision,
            "source_filename": Path(project.source_path).name,
            "final_transcript": "".join(cue.text for cue in project.segments),
        }
    )
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False) + "\n"


def _csv_export(project: SubtitleProject) -> str:
    buffer = io.StringIO(newline="")
    fields = (
        "index",
        "id",
        "project_revision",
        "source_filename",
        "source_path",
        "start",
        "end",
        "start_ms",
        "end_ms",
        "text",
        "source_segment_index",
        "source_confidence",
        "source_low_confidence",
        "speaker_id",
        "speaker_name",
        "speaker_show_name",
        "speaker_label",
        "speaker_text_color_rgba",
        "speaker_italic",
        "speaker_background_enabled",
        "speaker_background_color_rgba",
        "source_start",
        "source_end",
        "boundary_reason",
    )
    writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    speaker_profiles = {speaker.id: speaker for speaker in project.speakers}
    for index, cue in enumerate(_display_cues(project), start=1):
        speaker = speaker_profiles.get(cue.speaker_id or "")
        speaker_style = speaker.style.resolve(project.style) if speaker is not None else None
        writer.writerow(
            csv_safe_row(
                {
                    "index": index,
                    "id": cue.id,
                    "project_revision": project.revision,
                    "source_filename": Path(project.source_path).name,
                    "source_path": project.source_path,
                    "start": _timestamp(cue.start_ms, decimal="."),
                    "end": _timestamp(cue.end_ms, decimal="."),
                    "start_ms": cue.start_ms,
                    "end_ms": cue.end_ms,
                    "text": cue.text,
                    "source_segment_index": cue.source_segment_index,
                    "source_confidence": (
                        "" if cue.source_confidence is None else f"{cue.source_confidence:.6f}"
                    ),
                    "source_low_confidence": str(cue.source_low_confidence).lower(),
                    "speaker_id": cue.speaker_id or "",
                    "speaker_name": speaker.display_name if speaker is not None else "",
                    "speaker_show_name": (
                        str(speaker.show_name).lower() if speaker is not None else ""
                    ),
                    "speaker_label": cue.speaker_label or "",
                    "speaker_text_color_rgba": (
                        speaker_style.text_color_rgba if speaker_style is not None else ""
                    ),
                    "speaker_italic": (
                        str(speaker_style.italic).lower() if speaker_style is not None else ""
                    ),
                    "speaker_background_enabled": (
                        str(speaker_style.background_enabled).lower()
                        if speaker_style is not None
                        else ""
                    ),
                    "speaker_background_color_rgba": (
                        speaker_style.background_color_rgba if speaker_style is not None else ""
                    ),
                    "source_start": "" if cue.source_start is None else cue.source_start,
                    "source_end": "" if cue.source_end is None else cue.source_end,
                    "boundary_reason": cue.boundary_reason or "",
                }
            )
        )
    return buffer.getvalue()


def _payloads(project: SubtitleProject) -> dict[str, bytes]:
    renderers = {
        "txt": _txt,
        "timestamp_txt": _timestamp_txt,
        "srt": _srt,
        "vtt": _vtt,
        "json": _json_export,
        "csv": _csv_export,
    }
    return {
        kind: renderers[kind](project).encode("utf-8")
        for kind in EXPORT_FORMATS
    }


def _write_new_file(path: Path, payload: bytes) -> None:
    if path.exists() or path.is_symlink():
        raise ValueError(f"匯出 staging file 已存在：{path.name}")
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _manifest(
    project: SubtitleProject,
    payloads: Mapping[str, bytes],
) -> dict[str, Any]:
    return {
        "schema": EXPORT_SCHEMA,
        "project_revision": project.revision,
        "project_sha256": _project_digest(project),
        "files": {
            kind: {
                "filename": EXPORT_FILENAMES[kind],
                "sha256": _sha256(payloads[kind]),
                "bytes": len(payloads[kind]),
            }
            for kind in EXPORT_FORMATS
        },
    }


def _paths(directory: Path) -> dict[str, str]:
    return {
        kind: str((directory / EXPORT_FILENAMES[kind]).resolve())
        for kind in EXPORT_FORMATS
    }


def _verify_existing(directory: Path, project: SubtitleProject) -> dict[str, str]:
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError("字幕匯出 revision 路徑無效")
    manifest_path = directory / MANIFEST_FILENAME
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("字幕匯出 revision 缺少完整 manifest")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("字幕匯出 manifest 已損壞") from exc
    if (
        not isinstance(manifest, Mapping)
        or manifest.get("schema") != EXPORT_SCHEMA
        or manifest.get("project_revision") != project.revision
        or manifest.get("project_sha256") != _project_digest(project)
    ):
        raise ValueError("現有字幕匯出同目前 revision 不一致")
    files = manifest.get("files")
    if not isinstance(files, Mapping) or set(files) != set(EXPORT_FORMATS):
        raise ValueError("字幕匯出 manifest 檔案清單無效")
    for kind in EXPORT_FORMATS:
        record = files.get(kind)
        if not isinstance(record, Mapping) or record.get("filename") != EXPORT_FILENAMES[kind]:
            raise ValueError("字幕匯出 manifest 檔案記錄無效")
        path = directory / EXPORT_FILENAMES[kind]
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"字幕匯出缺少 {kind}")
        payload = path.read_bytes()
        if record.get("bytes") != len(payload) or record.get("sha256") != _sha256(payload):
            raise ValueError(f"字幕匯出 {kind} integrity 驗證失敗")
    return _paths(directory)


def export_project_revision(workspace: str | Path, project: SubtitleProject) -> dict[str, str]:
    """Create all six formats as one immutable revision bundle."""

    root = Path(workspace).expanduser()
    if root.is_symlink() or not root.is_dir():
        raise ValueError("工作 workspace 路徑無效")
    root = root.resolve(strict=True)
    subtitle_root = root / "subtitle"
    if subtitle_root.is_symlink():
        raise ValueError("subtitle 目錄唔可以係 symlink")
    subtitle_root.mkdir(mode=0o700, exist_ok=True)
    exports_root = subtitle_root / "exports"
    if exports_root.is_symlink():
        raise ValueError("subtitle exports 目錄唔可以係 symlink")
    exports_root.mkdir(mode=0o700, exist_ok=True)
    destination = exports_root / f"revision-{project.revision}"
    if destination.exists() or destination.is_symlink():
        return _verify_existing(destination, project)

    staging = Path(
        tempfile.mkdtemp(
            prefix=f".revision-{project.revision}-",
            suffix=".tmp",
            dir=exports_root,
        )
    )
    try:
        payloads = _payloads(project)
        for kind, payload in payloads.items():
            _write_new_file(staging / EXPORT_FILENAMES[kind], payload)
        manifest = _manifest(project, payloads)
        _write_new_file(
            staging / MANIFEST_FILENAME,
            (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode(
                "utf-8"
            ),
        )
        staging_descriptor = os.open(staging, os.O_RDONLY)
        try:
            os.fsync(staging_descriptor)
        finally:
            os.close(staging_descriptor)
        try:
            os.replace(staging, destination)
        except OSError:
            if destination.exists() and not destination.is_symlink():
                existing = _verify_existing(destination, project)
                failed_root = exports_root / ".failed-exports"
                if failed_root.is_symlink():
                    raise ValueError("failed export 目錄唔可以係 symlink")
                failed_root.mkdir(mode=0o700, exist_ok=True)
                os.replace(staging, failed_root / f"superseded-{uuid.uuid4().hex}")
                return existing
            raise
        exports_descriptor = os.open(exports_root, os.O_RDONLY)
        try:
            os.fsync(exports_descriptor)
        finally:
            os.close(exports_descriptor)
        return _verify_existing(destination, project)
    except BaseException:
        if staging.exists():
            failed_root = exports_root / ".failed-exports"
            if failed_root.is_symlink():
                raise ValueError("failed export 目錄唔可以係 symlink")
            failed_root.mkdir(mode=0o700, exist_ok=True)
            os.replace(staging, failed_root / f"revision-{project.revision}-{uuid.uuid4().hex}")
        raise


__all__ = [
    "EXPORT_FILENAMES",
    "EXPORT_FORMATS",
    "EXPORT_SCHEMA",
    "export_project_revision",
]
