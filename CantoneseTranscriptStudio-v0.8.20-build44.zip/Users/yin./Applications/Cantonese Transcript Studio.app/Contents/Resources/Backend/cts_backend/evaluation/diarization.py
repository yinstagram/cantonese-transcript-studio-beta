"""Offline-only speaker diarization fixture and metric helpers.

This module never downloads or uploads audio.  A fixture manifest references an
existing local WAV by path and SHA-256.  Exact DER/JER-style metrics are emitted
only when a human-supplied turn annotation is present; otherwise the report is
limited to speaker-count bounds and fragmentation evidence.
"""

from __future__ import annotations

import hashlib
import json
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from ..diarization import SpeakerTurn


@dataclass(frozen=True)
class LabelledTurn:
    start_ms: int
    end_ms: int
    speaker: str

    def __post_init__(self) -> None:
        if self.start_ms < 0 or self.end_ms <= self.start_ms:
            raise ValueError("labelled turn timestamps must be positive and ordered")
        if not self.speaker.strip():
            raise ValueError("labelled turn speaker must not be empty")


@dataclass(frozen=True)
class DiarizationFixture:
    fixture_id: str
    audio_path: Path
    audio_sha256: str
    duration_ms: int
    annotation_status: str
    minimum_speakers: int | None
    maximum_speakers: int | None
    reference_turns: tuple[LabelledTurn, ...]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _wav_duration_ms(path: Path) -> int:
    with wave.open(str(path), "rb") as stream:
        if stream.getframerate() <= 0:
            raise ValueError("fixture WAV has an invalid sample rate")
        return round(stream.getnframes() / stream.getframerate() * 1000)


def load_fixture_manifest(path: Path) -> tuple[DiarizationFixture, ...]:
    """Load and integrity-check a local fixture manifest.

    ``annotation_status`` must be ``human_labelled`` for turn metrics.  A
    ``count_bounds_only`` fixture may state conservative bounds but cannot
    masquerade as human ground truth.  ``pending_human_label`` carries neither.
    """

    manifest_path = Path(path).expanduser().resolve()
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or payload.get("schema") != 1:
        raise ValueError("diarization fixture manifest schema is invalid")
    rows = payload.get("fixtures")
    if not isinstance(rows, list):
        raise ValueError("diarization fixture manifest fixtures must be a list")
    fixtures: list[DiarizationFixture] = []
    seen: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("diarization fixture entry must be an object")
        fixture_id = str(row.get("id", "")).strip()
        if not fixture_id or fixture_id in seen:
            raise ValueError("diarization fixture ids must be unique and non-empty")
        seen.add(fixture_id)
        raw_audio_path = Path(str(row.get("audio_path", ""))).expanduser()
        audio_path = (
            raw_audio_path
            if raw_audio_path.is_absolute()
            else (manifest_path.parent / raw_audio_path)
        ).resolve()
        if not audio_path.is_file():
            raise FileNotFoundError(f"diarization fixture audio missing: {audio_path}")
        expected_hash = str(row.get("audio_sha256", "")).lower()
        actual_hash = _sha256(audio_path)
        if expected_hash != actual_hash:
            raise ValueError(f"diarization fixture audio hash mismatch: {fixture_id}")
        duration_ms = int(row.get("duration_ms", -1))
        actual_duration_ms = _wav_duration_ms(audio_path)
        if duration_ms != actual_duration_ms:
            raise ValueError(f"diarization fixture duration mismatch: {fixture_id}")
        status = str(row.get("annotation_status", ""))
        if status not in {"human_labelled", "count_bounds_only", "pending_human_label"}:
            raise ValueError(f"diarization fixture annotation status is invalid: {fixture_id}")
        minimum = row.get("minimum_speakers")
        maximum = row.get("maximum_speakers")
        minimum = int(minimum) if minimum is not None else None
        maximum = int(maximum) if maximum is not None else None
        if minimum is not None and minimum < 1:
            raise ValueError("minimum_speakers must be positive")
        if maximum is not None and maximum < 1:
            raise ValueError("maximum_speakers must be positive")
        if minimum is not None and maximum is not None and minimum > maximum:
            raise ValueError("speaker count bounds are reversed")
        values = row.get("reference_turns", [])
        if not isinstance(values, list):
            raise ValueError("reference_turns must be a list")
        reference = tuple(
            LabelledTurn(
                int(value["start_ms"]),
                int(value["end_ms"]),
                str(value["speaker"]),
            )
            for value in values
            if isinstance(value, dict)
        )
        if len(reference) != len(values):
            raise ValueError("reference_turns entries must be objects")
        if status == "human_labelled" and not reference:
            raise ValueError("human-labelled fixture requires reference turns")
        if status != "human_labelled" and reference:
            raise ValueError("non-human fixture cannot contain reference turns")
        if any(turn.end_ms > duration_ms for turn in reference):
            raise ValueError("reference turn exceeds fixture duration")
        if status == "count_bounds_only" and minimum is None and maximum is None:
            raise ValueError("count-bounds fixture requires at least one bound")
        if status == "pending_human_label" and (minimum is not None or maximum is not None):
            raise ValueError("pending fixture cannot claim speaker-count ground truth")
        fixtures.append(
            DiarizationFixture(
                fixture_id=fixture_id,
                audio_path=audio_path,
                audio_sha256=actual_hash,
                duration_ms=duration_ms,
                annotation_status=status,
                minimum_speakers=minimum,
                maximum_speakers=maximum,
                reference_turns=reference,
            )
        )
    return tuple(fixtures)


def _frame_sets(
    turns: Iterable[LabelledTurn],
    *,
    duration_ms: int,
    frame_ms: int,
) -> list[set[str]]:
    frames = [set() for _ in range((duration_ms + frame_ms - 1) // frame_ms)]
    for turn in turns:
        start = max(0, turn.start_ms // frame_ms)
        end = min(len(frames), (turn.end_ms + frame_ms - 1) // frame_ms)
        for index in range(start, end):
            frames[index].add(turn.speaker)
    return frames


def _maximum_weight_pairs(weights: list[list[int]]) -> tuple[tuple[int, int], ...]:
    """Return deterministic maximum-weight one-to-one row/column pairs."""

    if not weights or not weights[0]:
        return ()
    original_rows = len(weights)
    original_columns = len(weights[0])
    transposed = original_rows > original_columns
    matrix = (
        [[weights[row][column] for row in range(original_rows)] for column in range(original_columns)]
        if transposed
        else [list(row) for row in weights]
    )
    rows = len(matrix)
    columns = len(matrix[0])
    maximum = max(max(row) for row in matrix)
    costs = [[maximum - value for value in row] for row in matrix]

    # Hungarian algorithm for rows <= columns.  Tie-breaking follows ascending
    # indices, making repeated evaluations byte-for-byte deterministic.
    u = [0] * (rows + 1)
    v = [0] * (columns + 1)
    p = [0] * (columns + 1)
    way = [0] * (columns + 1)
    for row_index in range(1, rows + 1):
        p[0] = row_index
        column0 = 0
        minimums = [10**18] * (columns + 1)
        used = [False] * (columns + 1)
        while True:
            used[column0] = True
            current_row = p[column0]
            delta = 10**18
            column1 = 0
            for column in range(1, columns + 1):
                if used[column]:
                    continue
                current = costs[current_row - 1][column - 1] - u[current_row] - v[column]
                if current < minimums[column]:
                    minimums[column] = current
                    way[column] = column0
                if minimums[column] < delta:
                    delta = minimums[column]
                    column1 = column
            for column in range(columns + 1):
                if used[column]:
                    u[p[column]] += delta
                    v[column] -= delta
                else:
                    minimums[column] -= delta
            column0 = column1
            if p[column0] == 0:
                break
        while True:
            column1 = way[column0]
            p[column0] = p[column1]
            column0 = column1
            if column0 == 0:
                break

    pairs = [(p[column] - 1, column - 1) for column in range(1, columns + 1) if p[column]]
    if transposed:
        pairs = [(column, row) for row, column in pairs]
    return tuple(sorted(pairs))


def evaluate_labelled_turns(
    reference: Iterable[LabelledTurn],
    hypothesis: Iterable[SpeakerTurn],
    *,
    duration_ms: int,
    frame_ms: int = 10,
) -> dict[str, Any]:
    """Return frame-based DER/JER-style metrics with optimal label mapping."""

    if duration_ms <= 0 or frame_ms <= 0:
        raise ValueError("duration_ms and frame_ms must be positive")
    reference_values = tuple(reference)
    if not reference_values:
        raise ValueError("labelled diarization evaluation requires reference turns")
    hypothesis_values = tuple(
        LabelledTurn(turn.start_ms, turn.end_ms, str(turn.speaker_index))
        for turn in hypothesis
    )
    reference_frames = _frame_sets(reference_values, duration_ms=duration_ms, frame_ms=frame_ms)
    hypothesis_frames = _frame_sets(
        hypothesis_values, duration_ms=duration_ms, frame_ms=frame_ms
    )
    reference_labels = sorted({turn.speaker for turn in reference_values})
    hypothesis_labels = sorted({turn.speaker for turn in hypothesis_values})
    overlap = [
        [
            sum(
                reference_label in ref and hypothesis_label in hyp
                for ref, hyp in zip(reference_frames, hypothesis_frames)
            )
            for hypothesis_label in hypothesis_labels
        ]
        for reference_label in reference_labels
    ]
    pairs = _maximum_weight_pairs(overlap)
    hypothesis_to_reference = {
        hypothesis_labels[column]: reference_labels[row] for row, column in pairs
    }
    miss = false_alarm = confusion = denominator = 0
    for ref, hyp in zip(reference_frames, hypothesis_frames):
        mapped = {hypothesis_to_reference[label] for label in hyp if label in hypothesis_to_reference}
        correct = len(ref & mapped)
        denominator += len(ref)
        miss += max(0, len(ref) - len(hyp))
        false_alarm += max(0, len(hyp) - len(ref))
        confusion += max(0, min(len(ref), len(hyp)) - correct)

    per_speaker_jer: dict[str, float] = {}
    for reference_label in reference_labels:
        matched = next(
            (
                hypothesis_labels[column]
                for row, column in pairs
                if reference_labels[row] == reference_label
            ),
            None,
        )
        intersection = union = 0
        for ref, hyp in zip(reference_frames, hypothesis_frames):
            ref_active = reference_label in ref
            hyp_active = matched in hyp if matched is not None else False
            intersection += int(ref_active and hyp_active)
            union += int(ref_active or hyp_active)
        per_speaker_jer[reference_label] = 1.0 - intersection / max(1, union)

    return {
        "metric": "frame_der_jer_v1",
        "frame_ms": frame_ms,
        "reference_num_speakers": len(reference_labels),
        "hypothesis_num_speakers": len(hypothesis_labels),
        "mapping": hypothesis_to_reference,
        "miss_frames": miss,
        "false_alarm_frames": false_alarm,
        "confusion_frames": confusion,
        "reference_speaker_frames": denominator,
        "der": round((miss + false_alarm + confusion) / max(1, denominator), 6),
        "jer": round(
            sum(per_speaker_jer.values()) / max(1, len(per_speaker_jer)), 6
        ),
        "per_speaker_jer": {
            label: round(value, 6) for label, value in per_speaker_jer.items()
        },
    }


def evaluate_count_bounds(
    turns: Iterable[SpeakerTurn],
    *,
    minimum_speakers: int | None,
    maximum_speakers: int | None,
) -> dict[str, Any]:
    count = len({turn.speaker_index for turn in turns})
    lower_pass = minimum_speakers is None or count >= minimum_speakers
    upper_pass = maximum_speakers is None or count <= maximum_speakers
    return {
        "metric": "speaker_count_bounds_v1",
        "speaker_count": count,
        "minimum_speakers": minimum_speakers,
        "maximum_speakers": maximum_speakers,
        "within_bounds": lower_pass and upper_pass,
    }


__all__ = [
    "DiarizationFixture",
    "LabelledTurn",
    "evaluate_count_bounds",
    "evaluate_labelled_turns",
    "load_fixture_manifest",
]
