"""Offline collection and human-annotation tooling for natural timing gold.

This module deliberately keeps model timestamps out of timing packets.  Draft
ASR text is only a starting point for a separate human transcript-freeze stage;
timing labels are accepted only from explicit human exports bound to the pack
hash.  Job-local diarization labels must also be mapped to global human
pseudonyms before a speaker-disjoint split can be frozen.
"""

from __future__ import annotations

import hashlib
import html
import json
import math
import os
import re
import tempfile
import unicodedata
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Mapping, Sequence

from .natural_gold import (
    ANNOTATION_POLICY_VERSION,
    BASELINE_SEGMENT_POLICY_VERSION,
    BASELINE_SEGMENT_SCHEMA,
    DETERMINISTIC_RESOLVER,
    GOLD_COLLECTION_CONTRACT_VERSION,
    GOLD_SCHEMA,
    RENDERER_POLICY_VERSION,
    REQUIRED_CONDITIONS,
    compute_baseline_projection_sha256,
    compute_test_seal,
    validate_natural_cantonese_gold,
)


DRAFT_COLLECTION_SCHEMA = "CTS_NATURAL_GOLD_COLLECTION_DRAFT_V1"
CORRECTION_EXPORT_SCHEMA = "CTS_NATURAL_GOLD_TRANSCRIPT_FREEZE_V1"
READY_COLLECTION_SCHEMA = "CTS_NATURAL_GOLD_COLLECTION_READY_V1"
BLIND_PACKET_SCHEMA = "CTS_BLIND_TIMING_PACKET_V1"
ANNOTATION_EXPORT_SCHEMA = "CTS_BLIND_TIMING_ANNOTATION_V1"
ADJUDICATION_PACKET_SCHEMA = "CTS_TIMING_ADJUDICATION_PACKET_V1"
ADJUDICATION_EXPORT_SCHEMA = "CTS_TIMING_ADJUDICATION_V1"
SEALED_COMMIT_SCHEMA = "cts.natural-gold-seal-commit/v2"
FINALIZATION_RECEIPT_SCHEMA = "cts.natural-gold-finalization/v3"

SPLIT_WORD_QUOTAS = {
    "train": {"leading": 100, "trailing": 100, "interior": 400},
    "validation": {"leading": 40, "trailing": 40, "interior": 160},
    "test": {"leading": 60, "trailing": 60, "interior": 240},
}
SPLIT_CUE_QUOTAS = {"train": 170, "validation": 70, "test": 100}
DOUBLE_FRACTION = 0.25

DRAFT_KEYS = {
    "schema",
    "status",
    "pack_id",
    "source_build",
    "created_at",
    "privacy",
    "natural_human_speech_claim",
    "draft_asr_text_is_gold",
    "job_local_speaker_ids_are_global_identity",
    "model_timing_fields_are_transcript_review_only",
    "timing_annotation_packet_created",
    "clips",
    "draft_sha256",
}
DRAFT_CLIP_KEYS = {
    "id",
    "split",
    "audio_path",
    "audio_sha256",
    "duration_seconds",
    "source_authority",
    "source_reference",
    "suggested_conditions",
    "preliminary_speaker_ids",
    "draft_segments",
    "private_lineage",
}
DRAFT_SEGMENT_KEYS = {
    "id",
    "text",
    "preliminary_speaker_id",
    "review_start_ms",
    "review_end_ms",
}
CORRECTION_KEYS = {
    "schema",
    "draft_sha256",
    "corrector_pseudonym",
    "corrected_at",
    "confirmed_natural_human_speech",
    "timing_annotators_blind_to_model_timestamps",
    "no_same_human_has_multiple_global_ids",
    "global_identity_attested_by",
    "global_identity_attested_at",
    "audio_set_sha256",
    "ui_contract_sha256",
    "global_speaker_registry",
    "clips",
}
CORRECTION_CLIP_KEYS = {
    "id",
    "speaker_map",
    "confirmed_conditions",
    "segments",
}
CORRECTION_SEGMENT_KEYS = {
    "id",
    "text",
    "reviewed_by",
    "reviewed_at",
    "human_review_complete",
    "review_outcome",
}
REGISTRY_KEYS = {
    "global_speaker_id",
    "human_identity_confirmation",
    "member_clusters",
    "assigned_split",
    "confirmed_by",
    "confirmed_at",
}
REGISTRY_MEMBER_KEYS = {"clip_id", "preliminary_speaker_id"}
ROLE_KEYS = {
    "transcript_corrector",
    "primary_timing_annotator",
    "secondary_timing_annotator",
    "adjudicator",
}
READY_KEYS = {
    "schema",
    "status",
    "pack_id",
    "source_build",
    "frozen_at",
    "corrector_pseudonym",
    "draft_sha256",
    "transcript_freeze_sha256",
    "natural_human_speech",
    "synthetic_or_tts",
    "timing_annotators_blind_to_model_timestamps",
    "no_same_human_has_multiple_global_ids",
    "global_speaker_registry",
    "role_identities",
    "clips",
    "word_tasks",
    "cue_tasks",
    "double_annotation_word_ids",
    "double_annotation_cue_ids",
    "ready_sha256",
}
READY_CLIP_KEYS = {
    "id",
    "split",
    "audio_path",
    "audio_sha256",
    "transcript_path",
    "transcript_sha256",
    "baseline_segments_path",
    "baseline_segments_sha256",
    "duration_seconds",
    "speaker_ids",
    "source_authority",
    "source_reference",
    "conditions",
}
WORD_TASK_KEYS = {
    "id",
    "clip_id",
    "baseline_word_id",
    "segment_id",
    "text",
    "source_start",
    "source_end",
    "role",
    "split",
}
CUE_TASK_KEYS = {"id", "clip_id", "source_start", "source_end", "text", "split"}
PACKET_KEYS = {
    "schema",
    "pack_id",
    "ready_sha256",
    "annotator_pseudonym",
    "secondary_subset",
    "model_timestamps_exposed",
    "audio_set_sha256",
    "clips",
    "word_tasks",
    "cue_tasks",
    "packet_sha256",
}
PACKET_CLIP_KEYS = {"id", "audio_path", "audio_sha256", "duration_seconds"}
ANNOTATION_EXPORT_KEYS = {
    "schema",
    "packet_sha256",
    "annotator_pseudonym",
    "model_timestamps_seen",
    "audio_set_sha256",
    "ui_contract_sha256",
    "generated_at",
    "items",
}
ADJUDICATION_PACKET_KEYS = {
    "schema",
    "pack_id",
    "ready_sha256",
    "adjudicator_pseudonym",
    "audio_set_sha256",
    "clips",
    "tasks",
    "packet_sha256",
}
ADJUDICATION_WORD_TASK_KEYS = WORD_TASK_KEYS | {"kind", "raw_annotations"}
ADJUDICATION_CUE_TASK_KEYS = CUE_TASK_KEYS | {"kind", "raw_annotations"}
ADJUDICATION_EXPORT_KEYS = {
    "schema",
    "packet_sha256",
    "adjudicator_pseudonym",
    "audio_set_sha256",
    "ui_contract_sha256",
    "items",
}
COLLECTION_LINEAGE_KEYS = {
    "draft_sha256",
    "transcript_freeze_sha256",
    "transcript_freeze_file_sha256",
    "ready_sha256",
    "primary_packet_sha256",
    "primary_export_file_sha256",
    "secondary_packet_sha256",
    "secondary_export_file_sha256",
    "adjudication_packet_sha256",
    "adjudication_export_file_sha256",
    "tool_source_manifest_sha256",
    "tool_source_manifest_file_sha256",
    "transcript_review_ui_sha256",
    "primary_annotation_ui_sha256",
    "secondary_annotation_ui_sha256",
    "adjudication_ui_sha256",
    "renderer_policy_version",
    "finalization_execution_id",
}
PREPARATION_RECEIPT_SCHEMA = "cts.natural-gold-collection-preparation/v1"
PREPARATION_CURRENT_KEYS = {
    "schema",
    "created_at",
    "config_sha256",
    "draft",
    "draft_validation",
    "review_html",
    "clip_count",
    "duration_seconds",
    "status",
}
PREPARATION_LEGACY_KEYS = PREPARATION_CURRENT_KEYS - {"draft_validation"}
PREPARATION_DRAFT_KEYS = {"path", "sha256", "bound_draft_sha256"}
PREPARATION_VALIDATION_KEYS = {"path", "sha256", "status"}
PREPARATION_REVIEW_KEYS = {"path", "sha256"}
TIMING_LIKE_FIELD = re.compile(
    r"(?:^|_)(?:start|end|time|timestamp|alignment|forced|seam)(?:_|$)", re.IGNORECASE
)

_LATIN_TOKEN = re.compile(r"[A-Za-z0-9]+(?:['\u2019.-][A-Za-z0-9]+)*")
_SAFE_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")


def utc_now() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


def canonical_sha256(value: object) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, raw = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(raw)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temporary.unlink(missing_ok=True)
        raise


def _json_file_bytes(value: object) -> bytes:
    """Return the exact UTF-8 bytes written by :func:`atomic_json`."""

    return (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")


def atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    descriptor, raw = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(raw)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            handle.write(value)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        os.chmod(path, 0o600)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temporary.unlink(missing_ok=True)
        raise


def validate_private_collection_location(
    path: Path, *, project_root: Path
) -> Path:
    """Resolve a proposed private corpus root and reject repository storage.

    The check runs before directory creation so a failed policy decision cannot
    leave private data or even an empty private-corpus directory in the source
    tree. A symlink supplied as the corpus root is rejected rather than
    followed implicitly.
    """

    expanded = path.expanduser()
    if expanded.is_symlink():
        raise ValueError("private collection root must not be a symlink")
    resolved = expanded.resolve(strict=False)
    source_root = project_root.expanduser().resolve(strict=True)
    try:
        resolved.relative_to(source_root)
    except ValueError:
        return resolved
    raise ValueError("private gold collection must remain outside the project repository")


def ensure_owner_only_directory(path: Path) -> Path:
    """Create or tighten one known private corpus directory to mode 0700."""

    if path.is_symlink():
        raise ValueError("private collection directory must not be a symlink")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.is_symlink() or not path.is_dir():
        raise ValueError("private collection directory is invalid")
    path.chmod(0o700)
    return path.resolve(strict=True)


def _with_hash(value: Mapping[str, Any], key: str) -> dict[str, Any]:
    output = dict(value)
    output.pop(key, None)
    output[key] = canonical_sha256(output)
    return output


def _require_hash(value: Mapping[str, Any], key: str, label: str) -> None:
    expected = value.get(key)
    payload = dict(value)
    payload.pop(key, None)
    if not isinstance(expected, str) or expected != canonical_sha256(payload):
        raise ValueError(f"{label} hash mismatch")


def _exact_keys(value: object, expected: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != expected:
        raise ValueError(f"{label} schema is invalid")
    return value


def _json_object(path: Path, label: str) -> dict[str, Any]:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{label} is not a regular file")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{label} JSON root is invalid")
    return value


def _audio_set_sha256(clips: Sequence[Mapping[str, Any]]) -> str:
    return canonical_sha256(
        [
            {
                "id": row.get("id"),
                "audio_sha256": row.get("audio_sha256"),
                "duration_seconds": row.get("duration_seconds"),
            }
            for row in sorted(clips, key=lambda item: str(item.get("id")))
        ]
    )


def audio_set_sha256(clips: Sequence[Mapping[str, Any]]) -> str:
    return _audio_set_sha256(clips)


def ui_contract_sha256(stage: str, binding_sha256: str) -> str:
    if stage not in {
        "transcript_review",
        "primary_timing_annotation",
        "secondary_timing_annotation",
        "timing_adjudication",
    }:
        raise ValueError("human UI stage is invalid")
    if not isinstance(binding_sha256, str) or not re.fullmatch(
        r"[0-9a-f]{64}", binding_sha256
    ):
        raise ValueError("human UI binding hash is invalid")
    return canonical_sha256(
        {
            "renderer_policy_version": RENDERER_POLICY_VERSION,
            "stage": stage,
            "binding_sha256": binding_sha256,
        }
    )


def _contains_timing_like_extra(
    value: Mapping[str, Any], allowed: set[str]
) -> bool:
    return any(key not in allowed and TIMING_LIKE_FIELD.search(str(key)) for key in value)


def tokenize_frozen_segment(text: str) -> list[dict[str, Any]]:
    """Return Cantonese character / Latin word tokens with exact source spans."""

    output: list[dict[str, Any]] = []
    cursor = 0
    while cursor < len(text):
        latin = _LATIN_TOKEN.match(text, cursor)
        if latin is not None:
            output.append(
                {
                    "text": latin.group(0),
                    "source_start": latin.start(),
                    "source_end": latin.end(),
                }
            )
            cursor = latin.end()
            continue
        character = text[cursor]
        category = unicodedata.category(character)
        if not (
            character.isspace()
            or category.startswith("P")
            or category.startswith("S")
            or category.startswith("C")
        ):
            output.append(
                {
                    "text": character,
                    "source_start": cursor,
                    "source_end": cursor + 1,
                }
            )
        cursor += 1
    return output


def _stable_select(rows: Sequence[Mapping[str, Any]], count: int, seed: str) -> list[dict[str, Any]]:
    if len(rows) < count:
        raise ValueError(f"insufficient candidates: need {count}, found {len(rows)}")
    ordered = sorted(
        rows,
        key=lambda row: (
            hashlib.sha256(f"{seed}\0{row['id']}".encode()).hexdigest(),
            str(row["id"]),
        ),
    )[:count]
    return [dict(row) for row in ordered]


def _task_order(row: Mapping[str, Any]) -> tuple[str, int, str]:
    return str(row["clip_id"]), int(row["source_start"]), str(row["id"])


def _validated_root_file(root: Path, relative: object, digest: object) -> Path:
    if not isinstance(relative, str) or not relative:
        raise ValueError("relative path missing")
    resolved_root = root.resolve(strict=True)
    unresolved = resolved_root / relative
    if unresolved.is_symlink():
        raise ValueError("evidence path must not be a symlink")
    path = unresolved.resolve(strict=True)
    path.relative_to(resolved_root)
    if path.is_symlink() or not path.is_file():
        raise ValueError("evidence path is not a regular file")
    if not isinstance(digest, str) or file_sha256(path) != digest:
        raise ValueError("evidence file hash mismatch")
    return path


def validate_collection_draft(
    draft: Mapping[str, Any], *, root: Path
) -> dict[str, Any]:
    errors: list[str] = []
    try:
        _exact_keys(draft, DRAFT_KEYS, "draft collection")
        if draft.get("schema") != DRAFT_COLLECTION_SCHEMA:
            errors.append("draft schema is invalid")
        _require_hash(draft, "draft_sha256", "draft collection")
    except ValueError as exc:
        errors.append(str(exc))
    if draft.get("status") != "transcript_and_identity_review_required":
        errors.append("draft status is invalid")
    expected_flags = {
        "privacy": "offline_private_do_not_commit_or_upload",
        "natural_human_speech_claim": "pending_human_confirmation",
        "draft_asr_text_is_gold": False,
        "job_local_speaker_ids_are_global_identity": False,
        "model_timing_fields_are_transcript_review_only": True,
        "timing_annotation_packet_created": False,
    }
    for key, expected in expected_flags.items():
        if draft.get(key) != expected:
            errors.append(f"draft safety flag is invalid: {key}")
    clips = draft.get("clips")
    if not isinstance(clips, list) or not clips:
        clips = []
        errors.append("draft clips are missing")
    seen_ids: set[str] = set()
    audio_hashes: set[str] = set()
    duration_by_split = {split: 0.0 for split in SPLIT_WORD_QUOTAS}
    preliminary_clusters: set[tuple[str, str]] = set()
    segment_count = 0
    total_duration = 0.0
    for index, clip in enumerate(clips):
        if not isinstance(clip, Mapping) or set(clip) != DRAFT_CLIP_KEYS:
            errors.append(f"draft clip {index} is invalid")
            continue
        clip_id = clip.get("id")
        split = clip.get("split")
        if (
            not isinstance(clip_id, str)
            or not _SAFE_ID.fullmatch(clip_id)
            or clip_id in seen_ids
        ):
            errors.append(f"draft clip {index} identity is invalid or duplicate")
            continue
        seen_ids.add(clip_id)
        if split not in duration_by_split:
            errors.append(f"draft clip {clip_id} split is invalid")
        duration = clip.get("duration_seconds")
        if (
            isinstance(duration, bool)
            or not isinstance(duration, (int, float))
            or not math.isfinite(float(duration))
            or float(duration) <= 0
        ):
            errors.append(f"draft clip {clip_id} duration is invalid")
            duration_ms = 0
        else:
            duration_ms = round(float(duration) * 1000)
            total_duration += float(duration)
            if split in duration_by_split:
                duration_by_split[str(split)] += float(duration)
        try:
            _validated_root_file(root, clip.get("audio_path"), clip.get("audio_sha256"))
        except (OSError, ValueError) as exc:
            errors.append(f"draft clip {clip_id} audio evidence is invalid: {exc}")
        audio_hash = clip.get("audio_sha256")
        if not isinstance(audio_hash, str) or audio_hash in audio_hashes:
            errors.append(f"draft clip {clip_id} audio hash is invalid or duplicate")
        else:
            audio_hashes.add(audio_hash)
        speakers = clip.get("preliminary_speaker_ids")
        if not isinstance(speakers, list) or not speakers:
            errors.append(f"draft clip {clip_id} preliminary speakers are missing")
            speakers = []
        elif any(not isinstance(item, str) or not item for item in speakers):
            errors.append(f"draft clip {clip_id} preliminary speakers are invalid")
        for speaker in speakers:
            preliminary_clusters.add((clip_id, str(speaker)))
        segments = clip.get("draft_segments")
        if not isinstance(segments, list) or not segments:
            errors.append(f"draft clip {clip_id} segments are missing")
            continue
        local_ids: set[str] = set()
        previous_start = -1
        for segment in segments:
            if not isinstance(segment, Mapping) or set(segment) != DRAFT_SEGMENT_KEYS:
                errors.append(f"draft clip {clip_id} segment is invalid")
                continue
            segment_id = segment.get("id")
            start_ms = segment.get("review_start_ms")
            end_ms = segment.get("review_end_ms")
            if (
                not isinstance(segment_id, str)
                or not _SAFE_ID.fullmatch(segment_id)
                or segment_id in local_ids
                or not isinstance(segment.get("text"), str)
                or not segment.get("text")
                or segment.get("preliminary_speaker_id") not in speakers
                or isinstance(start_ms, bool)
                or isinstance(end_ms, bool)
                or not isinstance(start_ms, int)
                or not isinstance(end_ms, int)
                or not 0 <= start_ms < end_ms <= duration_ms
                or start_ms < previous_start
            ):
                errors.append(f"draft clip {clip_id} segment evidence is invalid")
                continue
            local_ids.add(segment_id)
            previous_start = start_ms
            segment_count += 1
    if total_duration < 1_800:
        errors.append("draft contains less than 30 minutes")
    if total_duration:
        expected_ratios = {"train": 0.50, "validation": 0.20, "test": 0.30}
        for split, ratio in expected_ratios.items():
            if abs(duration_by_split[split] / total_duration - ratio) > 0.02:
                errors.append(f"draft {split} duration ratio is outside tolerance")
    return {
        "schema": "cts.natural-gold-collection-draft-validation/v1",
        "accepted": not errors,
        "status": "DRAFT_ACCEPTED_NOT_HUMAN_GOLD" if not errors else "DRAFT_REJECTED",
        "errors": errors,
        "stats": {
            "clip_count": len(clips),
            "duration_seconds": round(total_duration, 3),
            "duration_by_split": {
                key: round(value, 3) for key, value in duration_by_split.items()
            },
            "preliminary_job_local_cluster_count": len(preliminary_clusters),
            "global_human_speaker_count": None,
            "draft_segment_count": segment_count,
            "human_transcript_frozen": False,
            "human_identity_confirmed": False,
            "timing_labels_present": False,
        },
    }


def build_redacted_draft_audit(
    draft: Mapping[str, Any],
    validation: Mapping[str, Any],
    *,
    tool_source_manifest_sha256: str,
    sealed_gold_manifest_present: bool,
) -> dict[str, Any]:
    if validation.get("status") != "DRAFT_ACCEPTED_NOT_HUMAN_GOLD":
        raise ValueError("redacted audit requires an accepted non-gold draft")
    stats = validation.get("stats")
    if not isinstance(stats, Mapping):
        raise ValueError("redacted audit draft stats are missing")
    if not isinstance(tool_source_manifest_sha256, str) or not re.fullmatch(
        r"[0-9a-f]{64}", tool_source_manifest_sha256
    ):
        raise ValueError("redacted audit source manifest hash is invalid")
    audit = {
        "schema": "cts.natural-gold-redacted-draft-audit/v1",
        "draft_sha256": draft.get("draft_sha256"),
        "tool_source_manifest_sha256": tool_source_manifest_sha256,
        "clip_count": stats.get("clip_count"),
        "aggregate_duration_seconds": stats.get("duration_seconds"),
        "draft_validation_status": validation.get("status"),
        "human_transcript_frozen": False,
        "human_identity_confirmed": False,
        "timing_labels_present": False,
        "timing_packet_created": False,
        "sealed_gold_manifest_present": bool(sealed_gold_manifest_present),
        "private_content_lint": "PASS",
    }
    validate_redacted_draft_audit(audit)
    return audit


def validate_redacted_draft_audit(audit: Mapping[str, Any]) -> None:
    expected = {
        "schema",
        "draft_sha256",
        "tool_source_manifest_sha256",
        "clip_count",
        "aggregate_duration_seconds",
        "draft_validation_status",
        "human_transcript_frozen",
        "human_identity_confirmed",
        "timing_labels_present",
        "timing_packet_created",
        "sealed_gold_manifest_present",
        "private_content_lint",
    }
    _exact_keys(audit, expected, "redacted draft audit")
    if (
        audit.get("schema") != "cts.natural-gold-redacted-draft-audit/v1"
        or audit.get("draft_validation_status")
        != "DRAFT_ACCEPTED_NOT_HUMAN_GOLD"
        or audit.get("human_transcript_frozen") is not False
        or audit.get("human_identity_confirmed") is not False
        or audit.get("timing_labels_present") is not False
        or audit.get("timing_packet_created") is not False
        or audit.get("sealed_gold_manifest_present") is not False
        or audit.get("private_content_lint") != "PASS"
        or not isinstance(audit.get("clip_count"), int)
        or audit.get("clip_count", 0) < 1
        or not isinstance(audit.get("aggregate_duration_seconds"), (int, float))
        or audit.get("aggregate_duration_seconds", 0) < 1_800
    ):
        raise ValueError("redacted draft audit state is invalid")
    for key in ("draft_sha256", "tool_source_manifest_sha256"):
        if not isinstance(audit.get(key), str) or not re.fullmatch(
            r"[0-9a-f]{64}", str(audit.get(key))
        ):
            raise ValueError("redacted draft audit hash is invalid")
    serialized = json.dumps(audit, ensure_ascii=False, sort_keys=True).lower()
    forbidden = (
        "job_id",
        "source_path",
        "source_reference",
        "audio_path",
        ".wav",
        ".m4a",
        "/users/",
        "/volumes/",
    )
    if any(value in serialized for value in forbidden):
        raise ValueError("redacted draft audit contains private content")


def _project_corrected_collection(
    draft: Mapping[str, Any],
    correction: Mapping[str, Any],
    *,
    root: Path,
    primary_annotator: str,
    secondary_annotator: str,
    adjudicator: str,
    materialize: bool,
) -> dict[str, Any]:
    """Freeze human-corrected text and create blind timing tasks.

    This is intentionally a hard boundary: preliminary diarization clusters do
    not count as identities, suggested conditions do not count as confirmed,
    and draft ASR text is never silently accepted as human-corrected text.
    """

    draft_validation = validate_collection_draft(draft, root=root)
    if not draft_validation["accepted"]:
        raise ValueError("draft collection has not passed accepted draft validation")
    if draft.get("status") != "transcript_and_identity_review_required":
        raise ValueError("draft collection is not awaiting human freeze")
    _exact_keys(correction, CORRECTION_KEYS, "transcript-freeze")
    if correction.get("schema") != CORRECTION_EXPORT_SCHEMA:
        raise ValueError("transcript-freeze schema is invalid")
    if correction.get("draft_sha256") != draft.get("draft_sha256"):
        raise ValueError("transcript-freeze is bound to another draft")
    expected_audio_set = _audio_set_sha256(draft.get("clips", []))
    if correction.get("audio_set_sha256") != expected_audio_set:
        raise ValueError("transcript-freeze audio identity mismatch")
    if correction.get("ui_contract_sha256") != ui_contract_sha256(
        "transcript_review", str(draft.get("draft_sha256"))
    ):
        raise ValueError("transcript-freeze UI contract mismatch")
    if correction.get("confirmed_natural_human_speech") is not True:
        raise ValueError("natural human speech was not explicitly confirmed")
    if correction.get("timing_annotators_blind_to_model_timestamps") is not True:
        raise ValueError("timing-annotator blindness was not confirmed")
    corrector = correction.get("corrector_pseudonym")
    corrected_at = correction.get("corrected_at")
    if not isinstance(corrector, str) or not corrector:
        raise ValueError("corrector pseudonym is missing")
    if not isinstance(corrected_at, str) or not corrected_at:
        raise ValueError("correction timestamp is missing")
    if correction.get("no_same_human_has_multiple_global_ids") is not True:
        raise ValueError("global human identity attestation is missing")
    if (
        correction.get("global_identity_attested_by") != corrector
        or not isinstance(correction.get("global_identity_attested_at"), str)
        or not correction.get("global_identity_attested_at")
    ):
        raise ValueError("global human identity attestation is invalid")
    role_identities = {
        "transcript_corrector": corrector,
        "primary_timing_annotator": primary_annotator,
        "secondary_timing_annotator": secondary_annotator,
        "adjudicator": adjudicator,
    }
    if (
        any(not isinstance(value, str) or not value.strip() or value.strip() != value for value in role_identities.values())
        or len(set(role_identities.values())) != 4
    ):
        raise ValueError("all four human roles must use distinct pseudonyms")

    draft_clips = draft.get("clips")
    corrected_clips = correction.get("clips")
    if not isinstance(draft_clips, list) or not isinstance(corrected_clips, list):
        raise ValueError("clip arrays are missing")
    if any(not isinstance(item, Mapping) or set(item) != CORRECTION_CLIP_KEYS for item in corrected_clips):
        raise ValueError("transcript-freeze clip schema is invalid")
    correction_ids = [item.get("id") for item in corrected_clips]
    if len(correction_ids) != len(set(correction_ids)):
        raise ValueError("transcript-freeze clip IDs are duplicate")
    correction_by_id = {item.get("id"): item for item in corrected_clips}
    if set(correction_by_id) != {
        item.get("id") for item in draft_clips if isinstance(item, Mapping)
    }:
        raise ValueError("transcript-freeze clip set does not match draft")

    split_by_clip = {str(item["id"]): str(item["split"]) for item in draft_clips}
    expected_clusters = {
        (str(clip["id"]), str(local))
        for clip in draft_clips
        for local in clip["preliminary_speaker_ids"]
    }
    registry = correction.get("global_speaker_registry")
    if not isinstance(registry, list) or not registry:
        raise ValueError("global speaker registry is missing")
    registry_map: dict[tuple[str, str], str] = {}
    registry_ids: set[str] = set()
    normalized_registry: list[dict[str, Any]] = []
    for index, identity in enumerate(registry):
        _exact_keys(identity, REGISTRY_KEYS, f"global speaker registry item {index}")
        global_id = identity.get("global_speaker_id")
        assigned_split = identity.get("assigned_split")
        members = identity.get("member_clusters")
        if (
            not isinstance(global_id, str)
            or not global_id.strip()
            or global_id.strip() != global_id
            or global_id in registry_ids
            or identity.get("human_identity_confirmation") is not True
            or assigned_split not in SPLIT_WORD_QUOTAS
            or identity.get("confirmed_by") != corrector
            or not isinstance(identity.get("confirmed_at"), str)
            or not identity.get("confirmed_at")
            or not isinstance(members, list)
            or not members
        ):
            raise ValueError("global speaker registry identity is invalid")
        registry_ids.add(global_id)
        normalized_members: list[dict[str, str]] = []
        for member in members:
            _exact_keys(member, REGISTRY_MEMBER_KEYS, "global speaker registry member")
            cluster = (str(member.get("clip_id")), str(member.get("preliminary_speaker_id")))
            if (
                cluster not in expected_clusters
                or cluster in registry_map
                or split_by_clip.get(cluster[0]) != assigned_split
            ):
                raise ValueError("global speaker registry member is invalid or duplicate")
            registry_map[cluster] = global_id
            normalized_members.append(
                {"clip_id": cluster[0], "preliminary_speaker_id": cluster[1]}
            )
        normalized_registry.append(
            {
                "global_speaker_id": global_id,
                "human_identity_confirmation": True,
                "member_clusters": sorted(
                    normalized_members,
                    key=lambda row: (row["clip_id"], row["preliminary_speaker_id"]),
                ),
                "assigned_split": assigned_split,
                "confirmed_by": corrector,
                "confirmed_at": identity["confirmed_at"],
            }
        )
    if set(registry_map) != expected_clusters:
        raise ValueError("global speaker registry does not cover every local cluster exactly once")

    ready_clips: list[dict[str, Any]] = []
    baseline_words: list[dict[str, Any]] = []
    cue_candidates: list[dict[str, Any]] = []
    speakers_by_split = {split: set() for split in SPLIT_WORD_QUOTAS}
    confirmed_conditions: set[str] = set()
    for draft_clip in draft_clips:
        if not isinstance(draft_clip, Mapping):
            raise ValueError("draft clip is invalid")
        clip_id = str(draft_clip.get("id", ""))
        split = str(draft_clip.get("split", ""))
        if not _SAFE_ID.fullmatch(clip_id) or split not in SPLIT_WORD_QUOTAS:
            raise ValueError("draft clip identity or split is invalid")
        corrected = correction_by_id[clip_id]
        local_speakers = draft_clip.get("preliminary_speaker_ids")
        speaker_map = corrected.get("speaker_map")
        if not isinstance(local_speakers, list) or not isinstance(speaker_map, Mapping):
            raise ValueError(f"clip {clip_id} speaker confirmation is missing")
        if set(speaker_map) != set(local_speakers):
            raise ValueError(f"clip {clip_id} speaker map is incomplete")
        if any(
            not isinstance(value, str) or not value or value.strip() != value
            for value in speaker_map.values()
        ):
            raise ValueError(f"clip {clip_id} global speaker identities are invalid")
        expected_speaker_map = {
            str(local): registry_map[(clip_id, str(local))] for local in local_speakers
        }
        if dict(speaker_map) != expected_speaker_map:
            raise ValueError(f"clip {clip_id} speaker map does not match global registry")
        global_speakers = set(speaker_map.values())
        if len(global_speakers) == 0:
            raise ValueError(f"clip {clip_id} global speaker identities are invalid")
        speakers_by_split[split].update(global_speakers)

        conditions = corrected.get("confirmed_conditions")
        if not isinstance(conditions, list) or any(
            not isinstance(item, str) or item not in REQUIRED_CONDITIONS
            for item in conditions
        ):
            raise ValueError(f"clip {clip_id} confirmed conditions are invalid")
        confirmed_conditions.update(conditions)
        _validated_root_file(root, draft_clip.get("audio_path"), draft_clip.get("audio_sha256"))

        draft_segments = draft_clip.get("draft_segments")
        corrected_segments = corrected.get("segments")
        if not isinstance(draft_segments, list) or not isinstance(corrected_segments, list):
            raise ValueError(f"clip {clip_id} segment correction is missing")
        if any(
            not isinstance(item, Mapping) or set(item) != CORRECTION_SEGMENT_KEYS
            for item in corrected_segments
        ):
            raise ValueError(f"clip {clip_id} corrected segment schema is invalid")
        corrected_ids = [item.get("id") for item in corrected_segments]
        if len(corrected_ids) != len(set(corrected_ids)):
            raise ValueError(f"clip {clip_id} corrected segment IDs are duplicate")
        corrected_by_id = {item.get("id"): item for item in corrected_segments}
        expected_segment_ids = {
            item.get("id") for item in draft_segments if isinstance(item, Mapping)
        }
        if set(corrected_by_id) != expected_segment_ids:
            raise ValueError(f"clip {clip_id} corrected segment set is incomplete")

        transcript_parts: list[str] = []
        baseline_segments: list[dict[str, Any]] = []
        clip_words: list[dict[str, Any]] = []
        source_cursor = 0
        for segment_index, draft_segment in enumerate(draft_segments):
            segment_id = str(draft_segment.get("id", ""))
            corrected_segment = corrected_by_id[segment_id]
            text = corrected_segment.get("text")
            if not isinstance(text, str) or not text.strip():
                raise ValueError(f"clip {clip_id} segment {segment_id} text is empty")
            expected_outcome = (
                "reviewed_and_unchanged"
                if text == draft_segment.get("text")
                else "reviewed_and_modified"
            )
            if (
                corrected_segment.get("human_review_complete") is not True
                or corrected_segment.get("reviewed_by") != corrector
                or not isinstance(corrected_segment.get("reviewed_at"), str)
                or not corrected_segment.get("reviewed_at")
                or corrected_segment.get("review_outcome") != expected_outcome
            ):
                raise ValueError(
                    f"clip {clip_id} segment {segment_id} lacks explicit human review"
                )
            segment_start = source_cursor
            transcript_parts.append(text)
            source_cursor += len(text)
            segment_end = source_cursor
            baseline_segments.append(
                {
                    "id": segment_id,
                    "source_start": segment_start,
                    "source_end": segment_end,
                    "text": text,
                }
            )
            tokens = tokenize_frozen_segment(text)
            for token_index, token in enumerate(tokens):
                role = (
                    "leading"
                    if token_index == 0
                    else "trailing"
                    if token_index == len(tokens) - 1
                    else "interior"
                )
                word_id = f"{clip_id}-word-{segment_index:04d}-{token_index:04d}"
                row = {
                    "id": word_id,
                    "clip_id": clip_id,
                    "baseline_word_id": word_id,
                    "segment_id": segment_id,
                    "text": token["text"],
                    "source_start": segment_start + int(token["source_start"]),
                    "source_end": segment_start + int(token["source_end"]),
                    "role": role,
                    "split": split,
                }
                clip_words.append(row)
                baseline_words.append(row)
            cue_candidates.append(
                {
                    "id": f"{clip_id}-cue-{segment_index:04d}",
                    "clip_id": clip_id,
                    "source_start": segment_start,
                    "source_end": segment_end,
                    "text": text,
                    "split": split,
                }
            )

        transcript = "".join(transcript_parts)
        transcript_relative = Path("transcripts") / f"{clip_id}.txt"
        transcript_path = root / transcript_relative
        transcript_sha = hashlib.sha256(transcript.encode("utf-8")).hexdigest()
        baseline_value: dict[str, Any] = {
            "schema": BASELINE_SEGMENT_SCHEMA,
            "segmentation_policy_version": BASELINE_SEGMENT_POLICY_VERSION,
            "source_build": int(draft.get("source_build")),
            "transcript_sha256": transcript_sha,
            "segments": baseline_segments,
            "words": [
                {
                    key: word[key]
                    for key in ("id", "segment_id", "text", "source_start", "source_end")
                }
                for word in clip_words
            ],
        }
        baseline_value["segment_projection_sha256"] = compute_baseline_projection_sha256(
            baseline_value
        )
        baseline_relative = Path("baseline") / f"{clip_id}.json"
        baseline_path = root / baseline_relative
        baseline_sha = hashlib.sha256(_json_file_bytes(baseline_value)).hexdigest()
        if materialize:
            ensure_owner_only_directory(transcript_path.parent)
            atomic_text(transcript_path, transcript)
            ensure_owner_only_directory(baseline_path.parent)
            atomic_json(baseline_path, baseline_value)
            if (
                file_sha256(transcript_path) != transcript_sha
                or file_sha256(baseline_path) != baseline_sha
            ):
                raise RuntimeError("frozen derivative bytes changed while materialising")
        ready_clips.append(
            {
                "id": clip_id,
                "split": split,
                "audio_path": str(draft_clip["audio_path"]),
                "audio_sha256": str(draft_clip["audio_sha256"]),
                "transcript_path": transcript_relative.as_posix(),
                "transcript_sha256": transcript_sha,
                "baseline_segments_path": baseline_relative.as_posix(),
                "baseline_segments_sha256": baseline_sha,
                "duration_seconds": float(draft_clip["duration_seconds"]),
                "speaker_ids": sorted(global_speakers),
                "source_authority": str(draft_clip["source_authority"]),
                "source_reference": str(draft_clip["source_reference"]),
                "conditions": sorted(set(conditions)),
            }
        )

    splits = tuple(SPLIT_WORD_QUOTAS)
    for left_index, left in enumerate(splits):
        for right in splits[left_index + 1 :]:
            overlap = speakers_by_split[left].intersection(speakers_by_split[right])
            if overlap:
                raise ValueError(
                    f"global speaker identities cross {left}/{right}: "
                    + ", ".join(sorted(overlap))
                )
    missing_conditions = REQUIRED_CONDITIONS - confirmed_conditions
    if missing_conditions:
        raise ValueError("human-confirmed acoustic conditions are incomplete")

    selected_words: list[dict[str, Any]] = []
    selected_cues: list[dict[str, Any]] = []
    pack_id = str(draft.get("pack_id"))
    for split, role_quotas in SPLIT_WORD_QUOTAS.items():
        for role, quota in role_quotas.items():
            candidates = [
                row for row in baseline_words if row["split"] == split and row["role"] == role
            ]
            selected_words.extend(
                _stable_select(candidates, quota, f"{pack_id}:word:{split}:{role}")
            )
        cue_rows = [row for row in cue_candidates if row["split"] == split]
        selected_cues.extend(
            _stable_select(cue_rows, SPLIT_CUE_QUOTAS[split], f"{pack_id}:cue:{split}")
        )
    selected_words.sort(key=_task_order)
    selected_cues.sort(key=_task_order)

    double_word_ids: list[str] = []
    double_cue_ids: list[str] = []
    for split in SPLIT_WORD_QUOTAS:
        split_words = [row for row in selected_words if row["split"] == split]
        split_cues = [row for row in selected_cues if row["split"] == split]
        double_word_ids.extend(
            row["id"]
            for row in _stable_select(
                split_words,
                math.ceil(len(split_words) * DOUBLE_FRACTION),
                f"{pack_id}:double-word:{split}",
            )
        )
        double_cue_ids.extend(
            row["id"]
            for row in _stable_select(
                split_cues,
                math.ceil(len(split_cues) * DOUBLE_FRACTION),
                f"{pack_id}:double-cue:{split}",
            )
        )

    ready = {
        "schema": READY_COLLECTION_SCHEMA,
        "status": "ready_for_blind_human_timing",
        "pack_id": pack_id,
        "source_build": int(draft.get("source_build")),
        "frozen_at": corrected_at,
        "corrector_pseudonym": corrector,
        "draft_sha256": draft["draft_sha256"],
        "transcript_freeze_sha256": canonical_sha256(correction),
        "natural_human_speech": True,
        "synthetic_or_tts": False,
        "timing_annotators_blind_to_model_timestamps": True,
        "no_same_human_has_multiple_global_ids": True,
        "global_speaker_registry": sorted(
            normalized_registry, key=lambda row: row["global_speaker_id"]
        ),
        "role_identities": role_identities,
        "clips": ready_clips,
        "word_tasks": selected_words,
        "cue_tasks": selected_cues,
        "double_annotation_word_ids": sorted(double_word_ids),
        "double_annotation_cue_ids": sorted(double_cue_ids),
    }
    return _with_hash(ready, "ready_sha256")


def freeze_corrected_collection(
    draft: Mapping[str, Any],
    correction: Mapping[str, Any],
    *,
    root: Path,
    primary_annotator: str,
    secondary_annotator: str,
    adjudicator: str,
) -> dict[str, Any]:
    """Validate and materialise the immutable transcript/baseline derivatives."""

    return _project_corrected_collection(
        draft,
        correction,
        root=root,
        primary_annotator=primary_annotator,
        secondary_annotator=secondary_annotator,
        adjudicator=adjudicator,
        materialize=True,
    )


def validate_ready_collection(ready: Mapping[str, Any]) -> None:
    _exact_keys(ready, READY_KEYS, "ready collection")
    if ready.get("schema") != READY_COLLECTION_SCHEMA:
        raise ValueError("ready collection schema is invalid")
    _require_hash(ready, "ready_sha256", "ready collection")
    if (
        ready.get("status") != "ready_for_blind_human_timing"
        or ready.get("natural_human_speech") is not True
        or ready.get("synthetic_or_tts") is not False
        or ready.get("timing_annotators_blind_to_model_timestamps") is not True
        or ready.get("no_same_human_has_multiple_global_ids") is not True
    ):
        raise ValueError("ready collection state is invalid")
    roles = _exact_keys(ready.get("role_identities"), ROLE_KEYS, "human roles")
    if (
        any(not isinstance(value, str) or not value for value in roles.values())
        or len(set(roles.values())) != 4
        or ready.get("corrector_pseudonym") != roles.get("transcript_corrector")
    ):
        raise ValueError("all four human roles must use distinct pseudonyms")
    registry = ready.get("global_speaker_registry")
    if not isinstance(registry, list) or not registry:
        raise ValueError("ready global speaker registry is invalid")
    registry_ids: set[str] = set()
    registry_members: set[tuple[str, str]] = set()
    registry_splits: dict[str, str] = {}
    for index, identity in enumerate(registry):
        _exact_keys(identity, REGISTRY_KEYS, f"ready speaker registry item {index}")
        global_id = identity.get("global_speaker_id")
        split = identity.get("assigned_split")
        members = identity.get("member_clusters")
        if (
            not isinstance(global_id, str)
            or not global_id
            or global_id in registry_ids
            or split not in SPLIT_WORD_QUOTAS
            or identity.get("human_identity_confirmation") is not True
            or identity.get("confirmed_by") != roles.get("transcript_corrector")
            or not isinstance(identity.get("confirmed_at"), str)
            or not identity.get("confirmed_at")
            or not isinstance(members, list)
            or not members
        ):
            raise ValueError("ready global speaker registry identity is invalid")
        registry_ids.add(global_id)
        registry_splits[global_id] = str(split)
        for member in members:
            _exact_keys(member, REGISTRY_MEMBER_KEYS, "ready speaker registry member")
            cluster = (str(member.get("clip_id")), str(member.get("preliminary_speaker_id")))
            if cluster in registry_members:
                raise ValueError("ready speaker registry member is duplicate")
            registry_members.add(cluster)

    clips = ready.get("clips")
    if not isinstance(clips, list) or not clips:
        raise ValueError("ready clips are missing")
    clip_by_id: dict[str, Mapping[str, Any]] = {}
    speakers_by_split = {split: set() for split in SPLIT_WORD_QUOTAS}
    for index, clip in enumerate(clips):
        _exact_keys(clip, READY_CLIP_KEYS, f"ready clip {index}")
        clip_id = clip.get("id")
        split = clip.get("split")
        speakers = clip.get("speaker_ids")
        if (
            not isinstance(clip_id, str)
            or not clip_id
            or clip_id in clip_by_id
            or split not in SPLIT_WORD_QUOTAS
            or not isinstance(speakers, list)
            or not speakers
            or any(not isinstance(value, str) or value not in registry_ids for value in speakers)
            or len(speakers) != len(set(speakers))
            or any(registry_splits.get(value) != split for value in speakers)
        ):
            raise ValueError("ready clip identity, split, or speakers are invalid")
        clip_by_id[clip_id] = clip
        speakers_by_split[str(split)].update(speakers)
    split_names = tuple(SPLIT_WORD_QUOTAS)
    for left_index, left in enumerate(split_names):
        for right in split_names[left_index + 1 :]:
            if speakers_by_split[left].intersection(speakers_by_split[right]):
                raise ValueError("ready speakers cross splits")

    def validate_tasks(
        raw: object, *, keys: set[str], kind: str
    ) -> list[Mapping[str, Any]]:
        if not isinstance(raw, list):
            raise ValueError(f"ready {kind} tasks are invalid")
        seen: set[str] = set()
        output: list[Mapping[str, Any]] = []
        for index, row in enumerate(raw):
            _exact_keys(row, keys, f"ready {kind} task {index}")
            identity = row.get("id")
            clip = clip_by_id.get(str(row.get("clip_id")))
            if (
                not isinstance(identity, str)
                or not identity
                or identity in seen
                or clip is None
                or row.get("split") != clip.get("split")
                or not isinstance(row.get("text"), str)
                or not row.get("text")
                or isinstance(row.get("source_start"), bool)
                or isinstance(row.get("source_end"), bool)
                or not isinstance(row.get("source_start"), int)
                or not isinstance(row.get("source_end"), int)
                or not 0 <= row["source_start"] < row["source_end"]
            ):
                raise ValueError(f"ready {kind} task identity is invalid")
            if kind == "word" and (
                row.get("role") not in {"leading", "trailing", "interior"}
                or not isinstance(row.get("baseline_word_id"), str)
                or not isinstance(row.get("segment_id"), str)
            ):
                raise ValueError("ready word task projection is invalid")
            seen.add(identity)
            output.append(row)
        return output

    words = validate_tasks(ready.get("word_tasks"), keys=WORD_TASK_KEYS, kind="word")
    cues = validate_tasks(ready.get("cue_tasks"), keys=CUE_TASK_KEYS, kind="cue")
    for split, quotas in SPLIT_WORD_QUOTAS.items():
        for role, quota in quotas.items():
            if sum(row["split"] == split and row["role"] == role for row in words) != quota:
                raise ValueError("ready word quotas are invalid")
        if sum(row["split"] == split for row in cues) != SPLIT_CUE_QUOTAS[split]:
            raise ValueError("ready cue quotas are invalid")

    pack_id = ready.get("pack_id")
    expected_word_ids: list[str] = []
    expected_cue_ids: list[str] = []
    for split in SPLIT_WORD_QUOTAS:
        split_words = [row for row in words if row["split"] == split]
        split_cues = [row for row in cues if row["split"] == split]
        expected_word_ids.extend(
            row["id"]
            for row in _stable_select(
                split_words,
                math.ceil(len(split_words) * DOUBLE_FRACTION),
                f"{pack_id}:double-word:{split}",
            )
        )
        expected_cue_ids.extend(
            row["id"]
            for row in _stable_select(
                split_cues,
                math.ceil(len(split_cues) * DOUBLE_FRACTION),
                f"{pack_id}:double-cue:{split}",
            )
        )
    if ready.get("double_annotation_word_ids") != sorted(expected_word_ids):
        raise ValueError("ready double-annotation word subset is invalid")
    if ready.get("double_annotation_cue_ids") != sorted(expected_cue_ids):
        raise ValueError("ready double-annotation cue subset is invalid")


def _build_blind_packet_unchecked(
    ready: Mapping[str, Any], *, annotator_pseudonym: str, secondary: bool
) -> dict[str, Any]:
    word_ids = set(ready["double_annotation_word_ids"])
    cue_ids = set(ready["double_annotation_cue_ids"])
    words = [
        dict(row)
        for row in ready["word_tasks"]
        if not secondary or row["id"] in word_ids
    ]
    cues = [
        dict(row)
        for row in ready["cue_tasks"]
        if not secondary or row["id"] in cue_ids
    ]
    clips = [
        {key: clip[key] for key in PACKET_CLIP_KEYS}
        for clip in ready["clips"]
    ]
    packet = {
        "schema": BLIND_PACKET_SCHEMA,
        "pack_id": ready["pack_id"],
        "ready_sha256": ready["ready_sha256"],
        "annotator_pseudonym": annotator_pseudonym,
        "secondary_subset": secondary,
        "model_timestamps_exposed": False,
        "audio_set_sha256": _audio_set_sha256(clips),
        "clips": clips,
        "word_tasks": words,
        "cue_tasks": cues,
    }
    return _with_hash(packet, "packet_sha256")


def build_blind_packet(
    ready: Mapping[str, Any], *, annotator_pseudonym: str, secondary: bool
) -> dict[str, Any]:
    validate_ready_collection(ready)
    if not annotator_pseudonym:
        raise ValueError("annotator pseudonym is required")
    expected_role = (
        "secondary_timing_annotator" if secondary else "primary_timing_annotator"
    )
    if ready["role_identities"][expected_role] != annotator_pseudonym:
        raise ValueError("annotator pseudonym does not match assigned human role")
    return _build_blind_packet_unchecked(
        ready, annotator_pseudonym=annotator_pseudonym, secondary=secondary
    )


def validate_blind_packet_against_ready(
    ready: Mapping[str, Any], packet: Mapping[str, Any]
) -> None:
    validate_ready_collection(ready)
    _exact_keys(packet, PACKET_KEYS, "blind packet")
    if packet.get("schema") != BLIND_PACKET_SCHEMA:
        raise ValueError("blind packet schema is invalid")
    _require_hash(packet, "packet_sha256", "blind packet")
    for row in packet.get("clips", []):
        _exact_keys(row, PACKET_CLIP_KEYS, "blind packet clip")
    for row in packet.get("word_tasks", []):
        _exact_keys(row, WORD_TASK_KEYS, "blind packet word task")
    for row in packet.get("cue_tasks", []):
        _exact_keys(row, CUE_TASK_KEYS, "blind packet cue task")
    if packet.get("model_timestamps_exposed") is not False:
        raise ValueError("blind packet exposes model timestamps")
    secondary = packet.get("secondary_subset")
    if not isinstance(secondary, bool):
        raise ValueError("blind packet subset flag is invalid")
    expected_role = (
        "secondary_timing_annotator" if secondary else "primary_timing_annotator"
    )
    if packet.get("annotator_pseudonym") != ready["role_identities"][expected_role]:
        raise ValueError("blind packet human role is invalid")
    expected = _build_blind_packet_unchecked(
        ready,
        annotator_pseudonym=str(packet["annotator_pseudonym"]),
        secondary=secondary,
    )
    if dict(packet) != expected:
        raise ValueError("blind packet is not the deterministic ready projection")


def _packet_task_map(packet: Mapping[str, Any]) -> dict[tuple[str, str], Mapping[str, Any]]:
    tasks: dict[tuple[str, str], Mapping[str, Any]] = {}
    for kind, key in (("word", "word_tasks"), ("cue", "cue_tasks")):
        rows = packet.get(key)
        if not isinstance(rows, list):
            raise ValueError(f"packet {key} is invalid")
        for row in rows:
            if not isinstance(row, Mapping) or not isinstance(row.get("id"), str):
                raise ValueError(f"packet {kind} task is invalid")
            identity = (kind, str(row["id"]))
            if identity in tasks:
                raise ValueError("packet task identity is duplicate")
            tasks[identity] = row
    return tasks


def validate_annotation_export(
    packet: Mapping[str, Any], export: Mapping[str, Any]
) -> dict[tuple[str, str], dict[str, Any]]:
    _exact_keys(packet, PACKET_KEYS, "blind packet")
    if packet.get("schema") != BLIND_PACKET_SCHEMA:
        raise ValueError("blind packet schema is invalid")
    _require_hash(packet, "packet_sha256", "blind packet")
    if packet.get("model_timestamps_exposed") is not False:
        raise ValueError("blind packet exposes model timestamps")
    for row in packet.get("clips", []):
        _exact_keys(row, PACKET_CLIP_KEYS, "blind packet clip")
    for row in packet.get("word_tasks", []):
        _exact_keys(row, WORD_TASK_KEYS, "blind packet word task")
    for row in packet.get("cue_tasks", []):
        _exact_keys(row, CUE_TASK_KEYS, "blind packet cue task")
    _exact_keys(export, ANNOTATION_EXPORT_KEYS, "annotation export")
    if export.get("schema") != ANNOTATION_EXPORT_SCHEMA:
        raise ValueError("annotation export schema is invalid")
    if export.get("packet_sha256") != packet.get("packet_sha256"):
        raise ValueError("annotation export is bound to another packet")
    if export.get("annotator_pseudonym") != packet.get("annotator_pseudonym"):
        raise ValueError("annotation export pseudonym mismatch")
    if export.get("model_timestamps_seen") is not False:
        raise ValueError("annotator blindness declaration is missing")
    if export.get("audio_set_sha256") != packet.get("audio_set_sha256"):
        raise ValueError("annotation audio identity mismatch")
    stage = (
        "secondary_timing_annotation"
        if packet.get("secondary_subset") is True
        else "primary_timing_annotation"
    )
    if export.get("ui_contract_sha256") != ui_contract_sha256(
        stage, str(packet.get("packet_sha256"))
    ):
        raise ValueError("annotation UI contract mismatch")
    if not isinstance(export.get("generated_at"), str) or not export.get("generated_at"):
        raise ValueError("annotation generation timestamp is missing")
    expected = _packet_task_map(packet)
    clips = {
        str(row["id"]): round(float(row["duration_seconds"]) * 1000)
        for row in packet.get("clips", [])
    }
    rows = export.get("items")
    if not isinstance(rows, list):
        raise ValueError("annotation items are missing")
    output: dict[tuple[str, str], dict[str, Any]] = {}
    exact_keys = {"id", "kind", "start_ms", "end_ms", "ambiguous"}
    for row in rows:
        if not isinstance(row, Mapping) or set(row) != exact_keys:
            raise ValueError("annotation item schema is invalid")
        identity = (str(row.get("kind")), str(row.get("id")))
        task = expected.get(identity)
        if task is None or identity in output:
            raise ValueError("annotation item identity is unknown or duplicate")
        start_ms = row.get("start_ms")
        end_ms = row.get("end_ms")
        duration_ms = clips.get(str(task.get("clip_id")))
        if (
            isinstance(start_ms, bool)
            or isinstance(end_ms, bool)
            or not isinstance(start_ms, int)
            or not isinstance(end_ms, int)
            or duration_ms is None
            or not 0 <= start_ms < end_ms <= duration_ms
            or not isinstance(row.get("ambiguous"), bool)
        ):
            raise ValueError("annotation timing is invalid")
        output[identity] = dict(row)
    if set(output) != set(expected):
        raise ValueError("annotation export is incomplete")
    return output


def _build_adjudication_packet_unchecked(
    ready: Mapping[str, Any],
    primary_packet: Mapping[str, Any],
    primary_export: Mapping[str, Any],
    secondary_packet: Mapping[str, Any],
    secondary_export: Mapping[str, Any],
) -> dict[str, Any]:
    primary = validate_annotation_export(primary_packet, primary_export)
    secondary = validate_annotation_export(secondary_packet, secondary_export)
    ready_tasks = {
        (kind, str(row["id"])): row
        for kind, key in (("word", "word_tasks"), ("cue", "cue_tasks"))
        for row in ready.get(key, [])
    }
    tasks: list[dict[str, Any]] = []
    for identity, second in secondary.items():
        first = primary.get(identity)
        task = ready_tasks.get(identity)
        if first is None or task is None:
            raise ValueError("double annotation is not a subset of the primary packet")
        delta = max(
            abs(first["start_ms"] - second["start_ms"]),
            abs(first["end_ms"] - second["end_ms"]),
        )
        if delta > 80:
            tasks.append(
                {
                    **dict(task),
                    "kind": identity[0],
                    "raw_annotations": [
                        {
                            "annotator": primary_packet["annotator_pseudonym"],
                            "start_ms": first["start_ms"],
                            "end_ms": first["end_ms"],
                        },
                        {
                            "annotator": secondary_packet["annotator_pseudonym"],
                            "start_ms": second["start_ms"],
                            "end_ms": second["end_ms"],
                        },
                    ],
                }
            )
    packet = {
        "schema": ADJUDICATION_PACKET_SCHEMA,
        "pack_id": ready.get("pack_id"),
        "ready_sha256": ready.get("ready_sha256"),
        "adjudicator_pseudonym": ready["role_identities"]["adjudicator"],
        "audio_set_sha256": primary_packet["audio_set_sha256"],
        "clips": [
            {
                key: clip[key]
                for key in PACKET_CLIP_KEYS
            }
            for clip in ready.get("clips", [])
        ],
        "tasks": sorted(tasks, key=lambda row: (row["clip_id"], row["source_start"], row["id"])),
    }
    return _with_hash(packet, "packet_sha256")


def build_adjudication_packet(
    ready: Mapping[str, Any],
    primary_packet: Mapping[str, Any],
    primary_export: Mapping[str, Any],
    secondary_packet: Mapping[str, Any],
    secondary_export: Mapping[str, Any],
) -> dict[str, Any]:
    validate_ready_collection(ready)
    validate_blind_packet_against_ready(ready, primary_packet)
    validate_blind_packet_against_ready(ready, secondary_packet)
    if primary_packet.get("secondary_subset") is not False:
        raise ValueError("primary annotation packet is invalid")
    if secondary_packet.get("secondary_subset") is not True:
        raise ValueError("secondary annotation packet is invalid")
    return _build_adjudication_packet_unchecked(
        ready,
        primary_packet,
        primary_export,
        secondary_packet,
        secondary_export,
    )


def validate_adjudication_packet_against_exports(
    ready: Mapping[str, Any],
    primary_packet: Mapping[str, Any],
    primary_export: Mapping[str, Any],
    secondary_packet: Mapping[str, Any],
    secondary_export: Mapping[str, Any],
    adjudication_packet: Mapping[str, Any],
) -> None:
    validate_ready_collection(ready)
    validate_blind_packet_against_ready(ready, primary_packet)
    validate_blind_packet_against_ready(ready, secondary_packet)
    _exact_keys(adjudication_packet, ADJUDICATION_PACKET_KEYS, "adjudication packet")
    if adjudication_packet.get("schema") != ADJUDICATION_PACKET_SCHEMA:
        raise ValueError("adjudication packet schema is invalid")
    _require_hash(adjudication_packet, "packet_sha256", "adjudication packet")
    for row in adjudication_packet.get("clips", []):
        _exact_keys(row, PACKET_CLIP_KEYS, "adjudication packet clip")
    for row in adjudication_packet.get("tasks", []):
        expected = (
            ADJUDICATION_WORD_TASK_KEYS
            if row.get("kind") == "word"
            else ADJUDICATION_CUE_TASK_KEYS
            if row.get("kind") == "cue"
            else set()
        )
        _exact_keys(row, expected, "adjudication packet task")
    expected_packet = _build_adjudication_packet_unchecked(
        ready,
        primary_packet,
        primary_export,
        secondary_packet,
        secondary_export,
    )
    if dict(adjudication_packet) != expected_packet:
        raise ValueError("adjudication packet is not the deterministic export projection")


def _validate_adjudication_export(
    packet: Mapping[str, Any], export: Mapping[str, Any]
) -> dict[tuple[str, str], dict[str, Any]]:
    _exact_keys(packet, ADJUDICATION_PACKET_KEYS, "adjudication packet")
    _require_hash(packet, "packet_sha256", "adjudication packet")
    _exact_keys(export, ADJUDICATION_EXPORT_KEYS, "adjudication export")
    if export.get("schema") != ADJUDICATION_EXPORT_SCHEMA:
        raise ValueError("adjudication export schema is invalid")
    if export.get("packet_sha256") != packet.get("packet_sha256"):
        raise ValueError("adjudication export is bound to another packet")
    pseudonym = export.get("adjudicator_pseudonym")
    if (
        not isinstance(pseudonym, str)
        or not pseudonym
        or pseudonym != packet.get("adjudicator_pseudonym")
    ):
        raise ValueError("adjudicator pseudonym is missing")
    if export.get("audio_set_sha256") != packet.get("audio_set_sha256"):
        raise ValueError("adjudication audio identity mismatch")
    if export.get("ui_contract_sha256") != ui_contract_sha256(
        "timing_adjudication", str(packet.get("packet_sha256"))
    ):
        raise ValueError("adjudication UI contract mismatch")
    expected = {(str(row["kind"]), str(row["id"])): row for row in packet.get("tasks", [])}
    clip_durations = {
        str(row["id"]): round(float(row["duration_seconds"]) * 1000)
        for row in packet.get("clips", [])
    }
    rows = export.get("items")
    if not isinstance(rows, list):
        raise ValueError("adjudication items are missing")
    output: dict[tuple[str, str], dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, Mapping) or set(row) != {
            "id", "kind", "start_ms", "end_ms", "ambiguous", "decided_at"
        }:
            raise ValueError("adjudication item schema is invalid")
        identity = (str(row.get("kind")), str(row.get("id")))
        if identity not in expected or identity in output:
            raise ValueError("adjudication item identity is unknown or duplicate")
        duration_ms = clip_durations.get(str(expected[identity].get("clip_id")))
        if (
            isinstance(row.get("start_ms"), bool)
            or isinstance(row.get("end_ms"), bool)
            or not isinstance(row.get("start_ms"), int)
            or not isinstance(row.get("end_ms"), int)
            or duration_ms is None
            or not 0 <= row["start_ms"] < row["end_ms"] <= duration_ms
            or not isinstance(row.get("ambiguous"), bool)
            or not isinstance(row.get("decided_at"), str)
        ):
            raise ValueError("adjudication item is invalid")
        output[identity] = dict(row)
    if set(output) != set(expected):
        raise ValueError("adjudication export is incomplete")
    return output


def resolve_human_annotations(
    ready: Mapping[str, Any],
    primary_packet: Mapping[str, Any],
    primary_export: Mapping[str, Any],
    secondary_packet: Mapping[str, Any],
    secondary_export: Mapping[str, Any],
    adjudication_packet: Mapping[str, Any],
    adjudication_export: Mapping[str, Any],
) -> dict[tuple[str, str], dict[str, Any]]:
    validate_adjudication_packet_against_exports(
        ready,
        primary_packet,
        primary_export,
        secondary_packet,
        secondary_export,
        adjudication_packet,
    )
    primary = validate_annotation_export(primary_packet, primary_export)
    secondary = validate_annotation_export(secondary_packet, secondary_export)
    adjudicated = _validate_adjudication_export(adjudication_packet, adjudication_export)
    primary_name = str(primary_packet["annotator_pseudonym"])
    secondary_name = str(secondary_packet["annotator_pseudonym"])
    adjudicator_name = str(adjudication_export["adjudicator_pseudonym"])
    output: dict[tuple[str, str], dict[str, Any]] = {}
    for identity, first in primary.items():
        raw = [
            {"annotator": primary_name, "start_ms": first["start_ms"], "end_ms": first["end_ms"]}
        ]
        second = secondary.get(identity)
        if second is None:
            output[identity] = {
                "start_ms": first["start_ms"],
                "end_ms": first["end_ms"],
                "ambiguous": first["ambiguous"],
                "resolution": "single_annotation",
                "raw_annotations": raw,
            }
            continue
        raw.append(
            {"annotator": secondary_name, "start_ms": second["start_ms"], "end_ms": second["end_ms"]}
        )
        delta = max(
            abs(first["start_ms"] - second["start_ms"]),
            abs(first["end_ms"] - second["end_ms"]),
        )
        if delta <= 80:
            output[identity] = {
                "start_ms": min(first["start_ms"], second["start_ms"]),
                "end_ms": min(first["end_ms"], second["end_ms"]),
                "ambiguous": bool(first["ambiguous"] or second["ambiguous"]),
                "resolution": "deterministic_consensus",
                "raw_annotations": raw,
            }
            continue
        decision = adjudicated.get(identity)
        if decision is None:
            raise ValueError("over-80ms disagreement lacks adjudication")
        output[identity] = {
            "start_ms": decision["start_ms"],
            "end_ms": decision["end_ms"],
            "ambiguous": decision["ambiguous"],
            "resolution": "adjudicated",
            "raw_annotations": raw,
            "adjudication": {
                "adjudicator": adjudicator_name,
                "decided_at": decision["decided_at"],
                "policy_version": ANNOTATION_POLICY_VERSION,
                "start_ms": decision["start_ms"],
                "end_ms": decision["end_ms"],
            },
        }
    return output


def build_gold_manifest(
    ready: Mapping[str, Any],
    resolved: Mapping[tuple[str, str], Mapping[str, Any]],
    *,
    annotator_pseudonyms: Sequence[str],
    adjudicator_pseudonym: str,
    sealed_at: str,
    collection_lineage: Mapping[str, Any],
) -> dict[str, Any]:
    validate_ready_collection(ready)
    lineage = _exact_keys(
        collection_lineage, COLLECTION_LINEAGE_KEYS, "collection lineage"
    )
    for key in COLLECTION_LINEAGE_KEYS - {
        "finalization_execution_id",
        "renderer_policy_version",
    }:
        value = lineage.get(key)
        if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
            raise ValueError(f"collection lineage hash is invalid: {key}")
    if lineage.get("renderer_policy_version") != RENDERER_POLICY_VERSION:
        raise ValueError("collection renderer policy version is invalid")
    if not isinstance(lineage.get("finalization_execution_id"), str) or not lineage.get(
        "finalization_execution_id"
    ):
        raise ValueError("collection finalization execution identity is invalid")
    roles = ready["role_identities"]
    if (
        len(annotator_pseudonyms) != 2
        or len(set(annotator_pseudonyms)) != len(annotator_pseudonyms)
        or not adjudicator_pseudonym
        or adjudicator_pseudonym in set(annotator_pseudonyms)
        or list(annotator_pseudonyms)
        != [roles["primary_timing_annotator"], roles["secondary_timing_annotator"]]
        or adjudicator_pseudonym != roles["adjudicator"]
    ):
        raise ValueError("human annotation roles must use distinct pseudonyms")
    words: list[dict[str, Any]] = []
    cues: list[dict[str, Any]] = []
    deltas: list[int] = []
    for kind, source, target in (
        ("word", ready.get("word_tasks", []), words),
        ("cue", ready.get("cue_tasks", []), cues),
    ):
        for task in source:
            identity = (kind, str(task["id"]))
            resolution = resolved.get(identity)
            if resolution is None:
                raise ValueError("resolved annotation set is incomplete")
            raw = resolution["raw_annotations"]
            if len(raw) >= 2:
                deltas.extend(
                    (
                        max(row["start_ms"] for row in raw) - min(row["start_ms"] for row in raw),
                        max(row["end_ms"] for row in raw) - min(row["end_ms"] for row in raw),
                    )
                )
            common = {
                "id": task["id"],
                "clip_id": task["clip_id"],
                "source_start": task["source_start"],
                "source_end": task["source_end"],
                "text": task["text"],
                "ambiguous": resolution["ambiguous"],
                "resolution": resolution["resolution"],
                "raw_annotations": raw,
            }
            if "adjudication" in resolution:
                common["adjudication"] = resolution["adjudication"]
            if kind == "word":
                common.update(
                    {
                        "baseline_word_id": task["baseline_word_id"],
                        "segment_id": task["segment_id"],
                        "start_ms": resolution["start_ms"],
                        "end_ms": resolution["end_ms"],
                        "role": task["role"],
                    }
                )
            else:
                common.update(
                    {
                        "appearance_ms": resolution["start_ms"],
                        "disappearance_ms": resolution["end_ms"],
                    }
                )
            target.append(common)
    ordered = sorted(deltas)
    median = 0.0
    p95 = 0.0
    if ordered:
        middle = len(ordered) // 2
        median = (
            float(ordered[middle])
            if len(ordered) % 2
            else (ordered[middle - 1] + ordered[middle]) / 2
        )
        p95 = float(ordered[max(0, math.ceil(0.95 * len(ordered)) - 1)])
    manifest: dict[str, Any] = {
        "schema": GOLD_SCHEMA,
        "status": "sealed",
        "natural_human_speech": True,
        "synthetic_or_tts": False,
        "annotation_policy_version": ANNOTATION_POLICY_VERSION,
        "role_identities": dict(roles),
        "collection_lineage": dict(lineage),
        "clips": ready.get("clips", []),
        "annotations": {
            "transcripts_frozen_before_timing": True,
            "annotators_blind_to_model_timestamps": True,
            "annotator_pseudonyms": list(annotator_pseudonyms),
            "adjudicator_pseudonyms": [adjudicator_pseudonym],
            "deterministic_resolver": DETERMINISTIC_RESOLVER,
            "punctuation_interval_policy": "no_invented_interval",
            "raw_boundary_format": "per_annotator_start_end_ms",
            "pre_adjudication_median_ms": median,
            "pre_adjudication_p95_ms": p95,
            "words": words,
            "cues": cues,
        },
        "split_contract": {
            "collection_contract_version": GOLD_COLLECTION_CONTRACT_VERSION,
            "unit": "clip",
            "speaker_disjoint": True,
            "test_locked_before_development": True,
            "sealed_at": sealed_at,
        },
    }
    manifest["split_contract"]["test_seal_sha256"] = compute_test_seal(manifest)
    return manifest


def validate_preparation_evidence(
    root: Path,
    draft: Mapping[str, Any],
    *,
    evidence_root: Path | None = None,
    allow_legacy_adapter: bool = True,
) -> dict[str, Any]:
    """Validate the exact transcript-review UI bound to an accepted draft.

    Current collections derive the UI path from ``preparation-receipt.json``.
    The one legacy shape is explicit and requires both its validation receipt
    and v3 UI receipt; it never guesses between similarly named HTML files.
    """

    root = root.resolve(strict=True)
    evidence_root = (
        evidence_root.resolve(strict=True)
        if evidence_root is not None
        else root
    )
    validation = validate_collection_draft(draft, root=root)
    if validation.get("accepted") is not True:
        raise ValueError("preparation evidence requires an accepted draft")
    draft_path = evidence_root / "collection-draft.json"
    stored_draft = _json_object(draft_path, "collection draft")
    if stored_draft != dict(draft):
        raise ValueError("preparation draft bytes do not match supplied draft")
    validation_path = evidence_root / "draft-validation.json"
    stored_validation = _json_object(validation_path, "draft validation")
    if stored_validation != validation:
        raise ValueError("stored draft validation is stale")

    receipt = _json_object(
        evidence_root / "preparation-receipt.json", "preparation receipt"
    )
    if receipt.get("schema") != PREPARATION_RECEIPT_SCHEMA:
        raise ValueError("preparation receipt schema is invalid")
    common = {
        "draft_file_sha256": file_sha256(draft_path),
        "draft_sha256": str(draft.get("draft_sha256")),
        "validation_file_sha256": file_sha256(validation_path),
    }
    draft_binding = _exact_keys(
        receipt.get("draft"), PREPARATION_DRAFT_KEYS, "preparation draft binding"
    )
    if (
        draft_binding.get("path") != draft_path.name
        or draft_binding.get("sha256") != common["draft_file_sha256"]
        or draft_binding.get("bound_draft_sha256") != common["draft_sha256"]
        or receipt.get("status")
        != "HUMAN_TRANSCRIPT_AND_SPEAKER_IDENTITY_REQUIRED"
        or receipt.get("clip_count") != validation["stats"]["clip_count"]
        or receipt.get("duration_seconds") != validation["stats"]["duration_seconds"]
        or not isinstance(receipt.get("config_sha256"), str)
        or not re.fullmatch(r"[0-9a-f]{64}", str(receipt.get("config_sha256")))
    ):
        raise ValueError("preparation receipt does not bind the accepted draft")

    mode: str
    if set(receipt) == PREPARATION_CURRENT_KEYS:
        validation_binding = _exact_keys(
            receipt.get("draft_validation"),
            PREPARATION_VALIDATION_KEYS,
            "preparation validation binding",
        )
        if (
            validation_binding.get("path") != validation_path.name
            or validation_binding.get("sha256")
            != common["validation_file_sha256"]
            or validation_binding.get("status")
            != "DRAFT_ACCEPTED_NOT_HUMAN_GOLD"
        ):
            raise ValueError("preparation validation binding is stale")
        review_binding = _exact_keys(
            receipt.get("review_html"),
            PREPARATION_REVIEW_KEYS,
            "preparation review binding",
        )
        review_path = _validated_root_file(
            evidence_root, review_binding.get("path"), review_binding.get("sha256")
        )
        mode = "current"
    elif set(receipt) == PREPARATION_LEGACY_KEYS and allow_legacy_adapter:
        original_review = _exact_keys(
            receipt.get("review_html"),
            PREPARATION_REVIEW_KEYS,
            "legacy preparation review binding",
        )
        _validated_root_file(
            evidence_root,
            original_review.get("path"),
            original_review.get("sha256"),
        )
        legacy = _json_object(
            evidence_root / "draft-validation-receipt.json",
            "legacy validation receipt",
        )
        _exact_keys(
            legacy,
            {
                "schema",
                "created_at",
                "draft_sha256",
                "validation_sha256",
                "accepted",
                "status",
                "stats",
            },
            "legacy validation receipt",
        )
        review = _json_object(
            evidence_root / "review-ui-v3-receipt.json", "legacy UI receipt"
        )
        _exact_keys(
            review,
            {"schema", "draft_sha256", "review_html_sha256", "status"},
            "legacy UI receipt",
        )
        review_path = evidence_root / "transcript-and-speaker-review-v3.html"
        if (
            legacy.get("schema")
            != "cts.natural-gold-draft-validation-receipt/v1"
            or legacy.get("draft_sha256") != common["draft_file_sha256"]
            or legacy.get("validation_sha256")
            != common["validation_file_sha256"]
            or legacy.get("accepted") is not True
            or legacy.get("status") != "DRAFT_ACCEPTED_NOT_HUMAN_GOLD"
            or legacy.get("stats") != validation.get("stats")
            or review.get("schema") != "cts.natural-gold-review-ui/v3"
            or review.get("draft_sha256") != common["draft_sha256"]
            or review.get("review_html_sha256") != file_sha256(review_path)
            or review.get("status") != "HUMAN_REVIEW_REQUIRED"
        ):
            raise ValueError("legacy preparation adapter evidence is stale")
        mode = "legacy-v3-adapter"
    else:
        raise ValueError("preparation receipt keys are not a supported exact schema")

    expected_html = render_transcript_freeze_html(draft).encode("utf-8")
    if review_path.read_bytes() != expected_html:
        raise ValueError("transcript review UI is not the deterministic renderer output")
    return {
        "mode": mode,
        "review_path": review_path,
        "review_ui_sha256": file_sha256(review_path),
        **common,
    }


def render_timing_annotation_html(packet: Mapping[str, Any]) -> str:
    """Render a standalone offline annotator with no model-time fields."""

    if packet.get("schema") != BLIND_PACKET_SCHEMA:
        raise ValueError("blind packet schema is invalid")
    _require_hash(packet, "packet_sha256", "blind packet")
    payload = json.dumps(
        packet, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).replace(
        "<", "\\u003c"
    )
    title = html.escape(str(packet.get("annotator_pseudonym")))
    stage = (
        "secondary_timing_annotation"
        if packet.get("secondary_subset") is True
        else "primary_timing_annotation"
    )
    ui_contract = ui_contract_sha256(stage, str(packet.get("packet_sha256")))
    return f"""<!doctype html>
<html lang=\"zh-HK\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\">
<title>CTS 盲測時間標註 — {title}</title><style>
:root{{--bg:#101114;--card:#191b20;--text:#f4f4f5;--muted:#a1a1aa;--accent:#5eead4;--danger:#fb7185}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:17px -apple-system,BlinkMacSystemFont,sans-serif}}
main{{max-width:900px;margin:auto;padding:28px}}.card{{background:var(--card);border:1px solid #2b2e35;border-radius:18px;padding:22px;margin:16px 0}}
.row{{display:flex;gap:10px;flex-wrap:wrap;align-items:center}}button{{font:inherit;padding:12px 18px;border:0;border-radius:12px;background:#30343d;color:white}}
button.primary{{background:var(--accent);color:#052e2b;font-weight:700}}button:disabled{{opacity:.35}}.muted{{color:var(--muted)}}
#target{{font-size:30px;font-weight:750;margin:18px 0}}#context{{font-size:22px;line-height:1.6}}mark{{background:#0f766e;color:white;border-radius:5px;padding:2px 5px}}
.time{{font-variant-numeric:tabular-nums;font-size:24px}}progress{{width:100%;height:14px}}label{{display:flex;gap:8px;align-items:center}}
</style></head><body><main><h1>盲測時間標註</h1><p class=\"muted\">只憑聲音標記開始／結束；頁面冇提供任何模型時間。</p>
	<div class=\"card\"><progress id=\"progress\" max=\"1\" value=\"0\"></progress><p id=\"counter\"></p><p id=\"audioStatus\" class=\"muted\">正在驗證音訊…</p><audio id=\"audio\" controls preload=\"metadata\" style=\"width:100%\"></audio></div>
<div class=\"card\"><div id=\"kind\" class=\"muted\"></div><div id=\"target\"></div><div id=\"context\"></div></div>
<div class=\"card\"><div class=\"row\"><button id=\"back\">← 上一項</button><button id=\"start\" class=\"primary\">S · 設開始</button><button id=\"end\" class=\"primary\">E · 設結束</button><button id=\"next\">下一項 →</button></div>
<p class=\"time\">開始 <span id=\"startValue\">—</span>　結束 <span id=\"endValue\">—</span></p><label><input id=\"ambiguous\" type=\"checkbox\"> 聲音邊界含糊</label></div>
<div class=\"card row\"><button id=\"rewind\">−2 秒</button><button id=\"forward\">+2 秒</button><button id=\"export\" class=\"primary\">匯出完整標註 JSON</button></div>
</main><script id=\"packet\" type=\"application/json\">{payload}</script><script>
const packet=JSON.parse(document.getElementById('packet').textContent);const items=[...packet.word_tasks.map(x=>({{...x,kind:'word'}})),...packet.cue_tasks.map(x=>({{...x,kind:'cue'}}))].sort((a,b)=>a.clip_id.localeCompare(b.clip_id)||a.source_start-b.source_start||a.kind.localeCompare(b.kind));
	const clips=new Map(packet.clips.map(x=>[x.id,x]));const key='cts-gold-'+packet.packet_sha256;let saved=Object.assign(Object.create(null),JSON.parse(localStorage.getItem(key)||'{{}}'));let index=Math.min(saved.index||0,Math.max(0,items.length-1));const audio=document.getElementById('audio'),verified=new Map();let audioReady=false,verificationGeneration=0;
	const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');async function verifyAudio(clip){{const generation=++verificationGeneration;audioReady=false;audio.dataset.clip='';document.getElementById('audioStatus').textContent='正在驗證音訊 SHA-256…';for(const id of ['start','end','export'])document.getElementById(id).disabled=true;try{{if(!verified.has(clip.id)){{const response=await fetch(clip.audio_path,{{cache:'no-store'}});if(!response.ok)throw new Error('讀取音訊失敗');const bytes=await response.arrayBuffer(),digest=hex(await crypto.subtle.digest('SHA-256',bytes));if(digest!==clip.audio_sha256)throw new Error('音訊 SHA-256 不符');verified.set(clip.id,{{url:URL.createObjectURL(new Blob([bytes],{{type:'audio/wav'}})),sha256:digest}})}}if(generation!==verificationGeneration||row().clip_id!==clip.id)return;audio.src=verified.get(clip.id).url;audio.dataset.clip=clip.id;audioReady=true;document.getElementById('audioStatus').textContent='✓ 正在播放已驗證音訊 bytes';for(const id of ['start','end','export'])document.getElementById(id).disabled=false}}catch(error){{if(generation!==verificationGeneration)return;audio.removeAttribute('src');audio.dataset.clip='';document.getElementById('audioStatus').textContent='音訊驗證失敗：'+error.message}}}}
function row(){{return items[index]}}function stamp(v){{return Number.isInteger(v)?(v/1000).toFixed(3)+'s':'—'}}
	function render(){{const x=row(),clip=clips.get(x.clip_id);if(audio.dataset.clip!==x.clip_id)verifyAudio(clip);document.getElementById('counter').textContent=`${{index+1}} / ${{items.length}} · ${{x.clip_id}}`;document.getElementById('progress').max=items.length;document.getElementById('progress').value=index+1;document.getElementById('kind').textContent=x.kind==='word'?'字詞邊界':'字幕 cue 邊界';document.getElementById('target').textContent=x.text;document.getElementById('context').replaceChildren(document.createTextNode('文字位置：'),Object.assign(document.createElement('mark'),{{textContent:x.text}}));const value=saved[x.kind+':'+x.id]||{{}};document.getElementById('startValue').textContent=stamp(value.start_ms);document.getElementById('endValue').textContent=stamp(value.end_ms);document.getElementById('ambiguous').checked=!!value.ambiguous;document.getElementById('back').disabled=index===0;document.getElementById('next').disabled=index===items.length-1;saved.index=index;localStorage.setItem(key,JSON.stringify(saved))}}
	function setBoundary(which){{const x=row();if(!audioReady||audio.dataset.clip!==x.clip_id)throw new Error('目前項目音訊未驗證');const id=x.kind+':'+x.id,value=saved[id]||{{}};value[which]=Math.round(audio.currentTime*1000);value.ambiguous=document.getElementById('ambiguous').checked;saved[id]=value;localStorage.setItem(key,JSON.stringify(saved));render()}}
document.getElementById('start').onclick=()=>setBoundary('start_ms');document.getElementById('end').onclick=()=>setBoundary('end_ms');document.getElementById('back').onclick=()=>{{index--;render()}};document.getElementById('next').onclick=()=>{{index++;render()}};document.getElementById('rewind').onclick=()=>audio.currentTime=Math.max(0,audio.currentTime-2);document.getElementById('forward').onclick=()=>audio.currentTime=Math.min(audio.duration||1e9,audio.currentTime+2);document.getElementById('ambiguous').onchange=()=>{{const x=row(),id=x.kind+':'+x.id,value=saved[id]||{{}};value.ambiguous=document.getElementById('ambiguous').checked;saved[id]=value;localStorage.setItem(key,JSON.stringify(saved))}};
	document.getElementById('export').onclick=()=>{{if(verified.size!==packet.clips.length)throw new Error('必須逐段完成音訊身份驗證');const rows=items.map(x=>{{const v=saved[x.kind+':'+x.id];if(!v||!Number.isInteger(v.start_ms)||!Number.isInteger(v.end_ms)||v.start_ms>=v.end_ms)throw new Error('仍有未完成或無效標註');return {{id:x.id,kind:x.kind,start_ms:v.start_ms,end_ms:v.end_ms,ambiguous:!!v.ambiguous}}}});const out={{schema:'{ANNOTATION_EXPORT_SCHEMA}',packet_sha256:packet.packet_sha256,annotator_pseudonym:packet.annotator_pseudonym,model_timestamps_seen:false,audio_set_sha256:packet.audio_set_sha256,ui_contract_sha256:'{ui_contract}',generated_at:new Date().toISOString(),items:rows}};const blob=new Blob([JSON.stringify(out,null,2)+'\\n'],{{type:'application/json'}});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=packet.annotator_pseudonym+'-timing-annotation.json';a.click();URL.revokeObjectURL(a.href)}};window.addEventListener('beforeunload',()=>verified.forEach(x=>URL.revokeObjectURL(x.url)));
document.addEventListener('keydown',e=>{{if(e.target.tagName==='INPUT')return;if(e.key.toLowerCase()==='s')setBoundary('start_ms');if(e.key.toLowerCase()==='e')setBoundary('end_ms')}});render();
</script></body></html>"""


def render_transcript_freeze_html(draft: Mapping[str, Any]) -> str:
    """Render the separate human transcript/identity confirmation stage."""

    if draft.get("schema") != DRAFT_COLLECTION_SCHEMA:
        raise ValueError("draft collection schema is invalid")
    _require_hash(draft, "draft_sha256", "draft collection")
    payload = json.dumps(
        draft, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).replace(
        "<", "\\u003c"
    )
    conditions = json.dumps(sorted(REQUIRED_CONDITIONS), ensure_ascii=False)
    condition_labels = json.dumps(
        {
            "background_noise": "有背景聲",
            "cantonese_english_code_switching": "廣東話／英文夾雜",
            "clean_audio": "清晰錄音",
            "continuous_speech": "連續講話",
            "fast_speech": "語速較快",
            "particles_fillers": "語氣詞／口頭禪",
            "repeated_words": "重複字詞",
            "room_audio": "室內環境聲",
            "slow_speech": "語速較慢",
            "varied_distances": "收音距離有變",
            "varied_microphones": "不同收音設備",
        },
        ensure_ascii=False,
    )
    expected_audio_set = _audio_set_sha256(draft.get("clips", []))
    ui_contract = ui_contract_sha256(
        "transcript_review", str(draft.get("draft_sha256"))
    )
    return f"""<!doctype html><html lang=\"zh-HK\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\">
<title>CTS Gold 文字及講者確認</title><style>
:root{{--bg:#101114;--card:#191b20;--text:#f4f4f5;--muted:#a1a1aa;--accent:#5eead4}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:16px -apple-system,BlinkMacSystemFont,sans-serif}}main{{max-width:1100px;margin:auto;padding:28px}}.card{{background:var(--card);border:1px solid #2b2e35;border-radius:18px;padding:20px;margin:15px 0}}textarea,input{{font:inherit;background:#0f1013;color:white;border:1px solid #3f424a;border-radius:9px;padding:9px}}textarea{{width:100%;min-height:72px;line-height:1.5}}button{{font:inherit;padding:10px 15px;border:0;border-radius:12px;background:var(--accent);color:#052e2b;font-weight:700}}.muted{{color:var(--muted)}}.speaker{{display:grid;grid-template-columns:150px 1fr auto;gap:10px;margin:8px 0;align-items:center}}label{{display:flex;gap:8px;align-items:center;margin:8px 0}}audio{{width:100%}}.autosave{{color:#5eead4;font-weight:650}}
</style></head><body><main><h1>文字、講者身份及錄音條件確認</h1><p class=\"muted\">呢一步只係修正文字同確認真人身份；之後另一批 timing annotator 先會做盲測時間標註。</p><p class=\"autosave\">✓ 所有修改會自動儲存喺呢部 Mac</p><div id=\"clips\"></div>
	<div class=\"card\"><h2>確認人</h2><input id=\"corrector\" placeholder=\"匿名代號，例如 corrector-a\"><label><input id=\"natural\" type=\"checkbox\"> 我確認全部係自然真人語音</label><label><input id=\"blind\" type=\"checkbox\"> timing annotators 未見過任何模型時間</label><label><input id=\"identity\" type=\"checkbox\"> 我已跨全部錄音核對，同一真人冇被登記成兩個 global ID</label><button id=\"export\">匯出 transcript-freeze JSON</button></div>
</main><script id=\"draft\" type=\"application/json\">{payload}</script><script>
	const draft=JSON.parse(document.getElementById('draft').textContent),allConditions={conditions},conditionLabels={condition_labels},root=document.getElementById('clips'),storageKey='cts-freeze-'+draft.draft_sha256,expectedAudioSet='{expected_audio_set}',verifiedAudio=new Map();let saved=Object.assign(Object.create(null),JSON.parse(localStorage.getItem(storageKey)||'{{}}'));saved.speakers=Object.assign(Object.create(null),saved.speakers||{{}});saved.conditions=Object.assign(Object.create(null),saved.conditions||{{}});saved.segments=Object.assign(Object.create(null),saved.segments||{{}});saved.reviews=Object.assign(Object.create(null),saved.reviews||{{}});const persist=()=>localStorage.setItem(storageKey,JSON.stringify(saved)),hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');async function verifyClipAudio(clip,card){{const generation=Number(card.dataset.verifyGeneration||0)+1;card.dataset.verifyGeneration=String(generation);const status=card.querySelector('[data-audio-status]'),audio=card.querySelector('audio');status.textContent='正在驗證音訊 SHA-256…';card.dataset.verifiedSha='';try{{const response=await fetch(clip.audio_path,{{cache:'no-store'}});if(!response.ok)throw new Error('讀取音訊失敗');const bytes=await response.arrayBuffer(),digest=hex(await crypto.subtle.digest('SHA-256',bytes));if(digest!==clip.audio_sha256)throw new Error('音訊 SHA-256 不符');if(Number(card.dataset.verifyGeneration)!==generation)return;const record={{url:URL.createObjectURL(new Blob([bytes],{{type:'audio/wav'}})),sha256:digest}};verifiedAudio.set(clip.id,record);audio.src=record.url;audio.dataset.clip=clip.id;card.dataset.verifiedSha=digest;status.textContent='✓ 正在播放已驗證音訊 bytes'}}catch(error){{if(Number(card.dataset.verifyGeneration)!==generation)return;audio.removeAttribute('src');audio.dataset.clip='';status.textContent='音訊驗證失敗：'+error.message}}}}
	for(const clip of draft.clips){{const card=document.createElement('section');card.className='card';card.innerHTML=`<h2>${{clip.id}} · ${{clip.split}} · ${{clip.draft_segments.length}} 段</h2><p data-audio-status class="muted">正在驗證音訊…</p><audio controls preload="metadata"></audio><h3>將 job-local 講者對應至全域真人代號</h3>`;saved.speakers[clip.id]=Object.assign(Object.create(null),saved.speakers[clip.id]||{{}});saved.conditions[clip.id]=Array.isArray(saved.conditions[clip.id])?saved.conditions[clip.id]:[];saved.segments[clip.id]=Object.assign(Object.create(null),saved.segments[clip.id]||{{}});saved.reviews[clip.id]=Object.assign(Object.create(null),saved.reviews[clip.id]||{{}});for(const speaker of clip.preliminary_speaker_ids){{const row=document.createElement('div');row.className='speaker';const label=document.createElement('span');label.textContent=speaker;const input=document.createElement('input');input.dataset.clip=clip.id;input.dataset.speaker=speaker;input.placeholder='例如 person-yin（同一人跨錄音必須用同一代號）';input.value=saved.speakers[clip.id][speaker]||'';input.oninput=()=>{{saved.speakers[clip.id][speaker]=input.value;persist()}};const sample=document.createElement('button');sample.type='button';sample.textContent='試聽樣本';const sampleSegment=clip.draft_segments.find(seg=>seg.preliminary_speaker_id===speaker);sample.onclick=()=>{{if(card.dataset.verifiedSha!==clip.audio_sha256)throw new Error('音訊未驗證');const a=card.querySelector('audio');a.currentTime=Math.max(0,(sampleSegment?.review_start_ms||0)/1000-1);a.play()}};row.append(label,input,sample);card.append(row)}}const cond=document.createElement('div');cond.innerHTML='<h3>實際錄音條件（只剔你確認過嘅）</h3>';for(const name of allConditions){{const label=document.createElement('label');const box=document.createElement('input');box.type='checkbox';box.dataset.condition=name;box.dataset.clip=clip.id;box.checked=saved.conditions[clip.id].includes(name);box.onchange=()=>{{saved.conditions[clip.id]=[...cond.querySelectorAll('input:checked')].map(x=>x.dataset.condition);persist()}};label.append(box,document.createTextNode(conditionLabels[name]||name));cond.append(label)}}card.append(cond);const heading=document.createElement('h3');heading.textContent='逐段修正文字（每段都要明確確認）';card.append(heading);for(const seg of clip.draft_segments){{const wrap=document.createElement('div');wrap.style.margin='16px 0';const go=document.createElement('button');go.type='button';go.textContent='▶ 播呢段附近';go.onclick=()=>{{if(card.dataset.verifiedSha!==clip.audio_sha256)throw new Error('音訊未驗證');const a=card.querySelector('audio');a.currentTime=Math.max(0,seg.review_start_ms/1000-1);a.play()}};const area=document.createElement('textarea');area.value=saved.segments[clip.id][seg.id]??seg.text;area.dataset.clip=clip.id;area.dataset.segment=seg.id;area.oninput=()=>{{saved.segments[clip.id][seg.id]=area.value;saved.reviews[clip.id][seg.id]=null;review.checked=false;persist()}};const reviewLabel=document.createElement('label'),review=document.createElement('input'),savedReview=saved.reviews[clip.id][seg.id];review.type='checkbox';review.dataset.reviewClip=clip.id;review.dataset.reviewSegment=seg.id;review.checked=!!savedReview&&savedReview.audio_sha256===clip.audio_sha256&&typeof savedReview.reviewed_at==='string';review.onchange=()=>{{if(review.checked&&card.dataset.verifiedSha!==clip.audio_sha256){{review.checked=false;throw new Error('必須先驗證同播放呢段音訊')}}saved.reviews[clip.id][seg.id]=review.checked?{{reviewed_at:new Date().toISOString(),audio_sha256:clip.audio_sha256}}:null;persist()}};reviewLabel.append(review,document.createTextNode('我已聽過並逐字確認呢一段'));wrap.append(go,area,reviewLabel);card.append(wrap)}}root.append(card);verifyClipAudio(clip,card)}}
	const correctorField=document.getElementById('corrector'),naturalField=document.getElementById('natural'),blindField=document.getElementById('blind'),identityField=document.getElementById('identity');correctorField.value=saved.corrector||'';naturalField.checked=!!saved.natural;blindField.checked=!!saved.blind;identityField.checked=!!saved.identity;correctorField.oninput=()=>{{saved.corrector=correctorField.value;persist()}};naturalField.onchange=()=>{{saved.natural=naturalField.checked;persist()}};blindField.onchange=()=>{{saved.blind=blindField.checked;persist()}};identityField.onchange=()=>{{saved.identity=identityField.checked;persist()}};
	document.getElementById('export').onclick=()=>{{const corrector=document.getElementById('corrector').value.trim(),now=new Date().toISOString();if(verifiedAudio.size!==draft.clips.length)throw new Error('全部音訊必須先完成 bytes 驗證');if(!corrector||!document.getElementById('natural').checked||!document.getElementById('blind').checked||!document.getElementById('identity').checked)throw new Error('請完成四項真人確認');const registry=new Map();const clips=draft.clips.map(clip=>{{const speaker_map=Object.create(null);for(const input of document.querySelectorAll(`input[data-clip="${{clip.id}}"][data-speaker]`)){{const globalId=input.value.trim();if(!globalId)throw new Error('講者身份未完成');speaker_map[input.dataset.speaker]=globalId;if(!registry.has(globalId))registry.set(globalId,{{global_speaker_id:globalId,human_identity_confirmation:true,member_clusters:[],assigned_split:clip.split,confirmed_by:corrector,confirmed_at:now}});const identity=registry.get(globalId);if(identity.assigned_split!==clip.split)throw new Error('同一真人唔可以跨 train／validation／test');identity.member_clusters.push({{clip_id:clip.id,preliminary_speaker_id:input.dataset.speaker}})}}const confirmed_conditions=[...document.querySelectorAll(`input[data-clip="${{clip.id}}"][data-condition]:checked`)].map(x=>x.dataset.condition);const segments=clip.draft_segments.map(seg=>{{const area=document.querySelector(`textarea[data-clip="${{clip.id}}"][data-segment="${{seg.id}}"]`),review=saved.reviews[clip.id][seg.id];if(!area.value.trim())throw new Error('文字段落唔可以留空');if(!review||review.audio_sha256!==clip.audio_sha256||typeof review.reviewed_at!=='string')throw new Error('每一段都要用已驗證音訊明確確認');return {{id:seg.id,text:area.value,reviewed_by:corrector,reviewed_at:review.reviewed_at,human_review_complete:true,review_outcome:area.value===seg.text?'reviewed_and_unchanged':'reviewed_and_modified'}}}});return {{id:clip.id,speaker_map,confirmed_conditions,segments}}}});const out={{schema:'{CORRECTION_EXPORT_SCHEMA}',draft_sha256:draft.draft_sha256,corrector_pseudonym:corrector,corrected_at:now,confirmed_natural_human_speech:true,timing_annotators_blind_to_model_timestamps:true,no_same_human_has_multiple_global_ids:true,global_identity_attested_by:corrector,global_identity_attested_at:now,audio_set_sha256:expectedAudioSet,ui_contract_sha256:'{ui_contract}',global_speaker_registry:[...registry.values()],clips}};const blob=new Blob([JSON.stringify(out,null,2)+'\\n'],{{type:'application/json'}}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='transcript-freeze.json';a.click();URL.revokeObjectURL(a.href)}};window.addEventListener('beforeunload',()=>verifiedAudio.forEach(x=>URL.revokeObjectURL(x.url)));
</script></body></html>"""


def render_adjudication_html(
    packet: Mapping[str, Any], *, adjudicator_pseudonym: str
) -> str:
    _exact_keys(packet, ADJUDICATION_PACKET_KEYS, "adjudication packet")
    if packet.get("schema") != ADJUDICATION_PACKET_SCHEMA:
        raise ValueError("adjudication packet schema is invalid")
    _require_hash(packet, "packet_sha256", "adjudication packet")
    if not adjudicator_pseudonym or adjudicator_pseudonym != packet.get(
        "adjudicator_pseudonym"
    ):
        raise ValueError("adjudicator pseudonym is required")
    payload = json.dumps(
        packet, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).replace(
        "<", "\\u003c"
    )
    ui_contract = ui_contract_sha256(
        "timing_adjudication", str(packet.get("packet_sha256"))
    )
    return f"""<!doctype html><html lang=\"zh-HK\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\"><title>CTS Gold 分歧裁決</title><style>
body{{margin:0;background:#101114;color:#f4f4f5;font:17px -apple-system,sans-serif}}main{{max-width:900px;margin:auto;padding:28px}}.card{{background:#191b20;border:1px solid #30333a;border-radius:18px;padding:20px;margin:16px 0}}audio{{width:100%}}button{{font:inherit;padding:12px 18px;border:0;border-radius:12px;margin:4px;background:#30343d;color:white}}button.primary{{background:#5eead4;color:#052e2b;font-weight:700}}#target{{font-size:30px;font-weight:750}}.raw{{color:#fbbf24}}label{{display:flex;gap:8px;align-items:center}}
	</style></head><body><main><h1>雙人標註分歧裁決</h1><p>只會列出相差超過 80 ms 嘅項目；請重新聽聲音後獨立定案。</p><div class=\"card\"><div id=\"counter\"></div><p id=\"audioStatus\">正在驗證音訊…</p><audio id=\"audio\" controls></audio></div><div class=\"card\"><div id=\"target\"></div><div id=\"raw\" class=\"raw\"></div></div><div class=\"card\"><button id=\"start\" class=\"primary\">設開始</button><button id=\"end\" class=\"primary\">設結束</button><button id=\"previous\">上一項</button><button id=\"next\">下一項</button><p>開始 <span id=\"sv\">—</span>　結束 <span id=\"ev\">—</span></p><label><input id=\"ambiguous\" type=\"checkbox\"> 邊界含糊</label></div><div class=\"card\"><button id=\"export\" class=\"primary\">匯出裁決 JSON</button></div></main>
<script id=\"packet\" type=\"application/json\">{payload}</script><script>
	const packet=JSON.parse(document.getElementById('packet').textContent),clips=new Map(packet.clips.map(x=>[x.id,x])),items=packet.tasks,key='cts-adjudicate-'+packet.packet_sha256;let saved=Object.assign(Object.create(null),JSON.parse(localStorage.getItem(key)||'{{}}')),index=Math.min(saved.index||0,Math.max(0,items.length-1)),audio=document.getElementById('audio'),verified=new Map(),audioReady=false,verificationGeneration=0;const requiredClipIds=new Set(items.map(x=>x.clip_id));const hex=b=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');async function verifyAudio(clip){{const generation=++verificationGeneration;audioReady=false;audio.dataset.clip='';for(const id of ['start','end','export'])document.getElementById(id).disabled=true;try{{if(!verified.has(clip.id)){{const response=await fetch(clip.audio_path,{{cache:'no-store'}});if(!response.ok)throw new Error('讀取音訊失敗');const bytes=await response.arrayBuffer(),digest=hex(await crypto.subtle.digest('SHA-256',bytes));if(digest!==clip.audio_sha256)throw new Error('音訊 SHA-256 不符');verified.set(clip.id,{{url:URL.createObjectURL(new Blob([bytes],{{type:'audio/wav'}})),sha256:digest}})}}if(generation!==verificationGeneration||x().clip_id!==clip.id)return;audio.src=verified.get(clip.id).url;audio.dataset.clip=clip.id;audioReady=true;document.getElementById('audioStatus').textContent='✓ 正在播放已驗證音訊 bytes';for(const id of ['start','end','export'])document.getElementById(id).disabled=false}}catch(error){{if(generation!==verificationGeneration)return;audio.removeAttribute('src');audio.dataset.clip='';document.getElementById('audioStatus').textContent='音訊驗證失敗：'+error.message}}}}
	function x(){{return items[index]}}function fmt(v){{return Number.isInteger(v)?(v/1000).toFixed(3)+'s':'—'}}function render(){{if(!items.length){{document.getElementById('counter').textContent='冇超過 80 ms 嘅分歧，可以直接匯出空裁決。';document.getElementById('audioStatus').textContent='毋須播放音訊';document.getElementById('export').disabled=false;return}}const t=x();if(audio.dataset.clip!==t.clip_id)verifyAudio(clips.get(t.clip_id));document.getElementById('counter').textContent=`${{index+1}} / ${{items.length}} · ${{t.clip_id}}`;document.getElementById('target').textContent=t.text;document.getElementById('raw').textContent=t.raw_annotations.map(v=>`${{v.annotator}}: ${{fmt(v.start_ms)}}–${{fmt(v.end_ms)}}`).join('　');const v=saved[t.kind+':'+t.id]||{{}};document.getElementById('sv').textContent=fmt(v.start_ms);document.getElementById('ev').textContent=fmt(v.end_ms);document.getElementById('ambiguous').checked=!!v.ambiguous;document.getElementById('previous').disabled=index===0;document.getElementById('next').disabled=index===items.length-1;saved.index=index;localStorage.setItem(key,JSON.stringify(saved))}}
	function set(which){{const t=x();if(!audioReady||audio.dataset.clip!==t.clip_id)throw new Error('目前項目音訊未驗證');const id=t.kind+':'+t.id,v=saved[id]||{{}};v[which]=Math.round(audio.currentTime*1000);v.ambiguous=document.getElementById('ambiguous').checked;saved[id]=v;localStorage.setItem(key,JSON.stringify(saved));render()}}document.getElementById('start').onclick=()=>set('start_ms');document.getElementById('end').onclick=()=>set('end_ms');document.getElementById('previous').onclick=()=>{{index--;render()}};document.getElementById('next').onclick=()=>{{index++;render()}};
	document.getElementById('export').onclick=()=>{{if([...requiredClipIds].some(id=>!verified.has(id)))throw new Error('必須完成全部相關音訊身份驗證');const rows=items.map(t=>{{const v=saved[t.kind+':'+t.id];if(!v||!Number.isInteger(v.start_ms)||!Number.isInteger(v.end_ms)||v.start_ms>=v.end_ms)throw new Error('仍有未完成裁決');return {{id:t.id,kind:t.kind,start_ms:v.start_ms,end_ms:v.end_ms,ambiguous:!!v.ambiguous,decided_at:new Date().toISOString()}}}}),out={{schema:'{ADJUDICATION_EXPORT_SCHEMA}',packet_sha256:packet.packet_sha256,adjudicator_pseudonym:{json.dumps(adjudicator_pseudonym)},audio_set_sha256:packet.audio_set_sha256,ui_contract_sha256:'{ui_contract}',items:rows}};const b=new Blob([JSON.stringify(out,null,2)+'\\n'],{{type:'application/json'}}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='timing-adjudication.json';a.click();URL.revokeObjectURL(a.href)}};window.addEventListener('beforeunload',()=>verified.forEach(x=>URL.revokeObjectURL(x.url)));render();
</script></body></html>"""


__all__ = [
    "ADJUDICATION_EXPORT_SCHEMA",
    "ADJUDICATION_PACKET_SCHEMA",
    "ANNOTATION_EXPORT_SCHEMA",
    "BLIND_PACKET_SCHEMA",
    "CORRECTION_EXPORT_SCHEMA",
    "DRAFT_COLLECTION_SCHEMA",
    "GOLD_COLLECTION_CONTRACT_VERSION",
    "READY_COLLECTION_SCHEMA",
    "RENDERER_POLICY_VERSION",
    "SPLIT_CUE_QUOTAS",
    "SPLIT_WORD_QUOTAS",
    "atomic_json",
    "atomic_text",
    "audio_set_sha256",
    "build_adjudication_packet",
    "build_blind_packet",
    "build_gold_manifest",
    "build_redacted_draft_audit",
    "canonical_sha256",
    "ensure_owner_only_directory",
    "file_sha256",
    "freeze_corrected_collection",
    "render_timing_annotation_html",
    "render_transcript_freeze_html",
    "render_adjudication_html",
    "resolve_human_annotations",
    "tokenize_frozen_segment",
    "ui_contract_sha256",
    "utc_now",
    "validate_annotation_export",
    "validate_adjudication_packet_against_exports",
    "validate_blind_packet_against_ready",
    "validate_collection_draft",
    "validate_ready_collection",
    "validate_redacted_draft_audit",
    "validate_private_collection_location",
    "validate_preparation_evidence",
]
