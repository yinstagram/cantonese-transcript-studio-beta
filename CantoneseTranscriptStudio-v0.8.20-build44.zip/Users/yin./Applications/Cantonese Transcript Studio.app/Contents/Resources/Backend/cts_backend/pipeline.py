"""Crash-safe sequential transcription pipeline with atomic checkpoints."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import math
import os
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from .alignment import (
    ARBITER_POLICY_VERSION,
    ENSEMBLE_POLICY_VERSION,
    LMStudioLifecycle,
    LocalCandidateArbiter,
    RECONCILIATION_POLICY_VERSION,
    ForcedProcessSupervisor,
    FORCED_TIMESTAMP_POLICY_VERSION,
    QwenForcedTimestampAligner,
    WENET_TIMING_MODEL,
    WENET_TIMING_POLICY_VERSION,
    retime_with_wenet_anchors,
)
from .alignment.windows import (
    ALIGNMENT_WINDOW_CONTEXT_SECONDS,
    ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS,
    ALIGNMENT_WINDOW_POLICY_VERSION,
    ALIGNMENT_WINDOW_STRATEGY,
    prepare_alignment_windows,
)
from .alignment.forced_timestamps import (
    FORCED_ALIGNER_METHOD,
    _is_safe_fallback_reason,
    _projection,
)
from .asr import (
    ASRCancelled,
    WHISPER_CPP_POLICY_VERSION,
    AudioChunk,
    QwenASR,
    SherpaYueVerifier,
    WhisperCPPASR,
)
from .asr.types import TranscriptSegment, segments_to_dict
from .asr.decode_health import PRIMARY_DECODE_HEALTH_POLICY, primary_decode_health
from .asr.primary_recovery import (
    PRIMARY_RECOVERY_POLICY, PrimaryRecoveryError,
    build_primary_recovery_decisions, recovery_segment,
)
from .asr.qwen_process import QwenProcessSupervisor
from .asr.qwen_quantized import (
    QwenRuntimeConversionCancelled,
    QwenRuntimeConversionError,
    convert_qwen_runtime,
    runtime_output_path,
    verify_quantized_runtime,
)
from .correction_memory import (
    CorrectionEntry,
    CorrectionMemoryError,
    apply_approved_corrections,
    correction_entries_from_snapshot,
)
from .models import (
    ModelManager,
    ModelError,
    QWEN_FALLBACK_ID,
    QWEN_ALIGNER_ID,
    QWEN_PRIMARY_ID,
    SHERPA_MODEL_NAME,
    WHISPER_LARGE_V3_ID,
    WHISPER_MODEL_FILENAMES,
    WHISPER_MODEL_IDS,
    SPEAKER_SEGMENTATION_ID,
    SPEAKER_EMBEDDING_ID,
    SORTFORMER_COREML_ID,
    SORTFORMER_COREML_BUNDLE,
    SORTFORMER_COREML_FILES,
    move_to_trash,
)
from .normalization import HK_NORMALIZATION_POLICY_VERSION
from .resource_guard import MacASRResourceGuard, ResourceGuardError
from .diarization import (
    DiarizationCancelled,
    DiarizationError,
    SherpaOfflineDiarizer,
    SortformerCoreMLDiarizer,
    assign_speakers,
    read_turns,
    write_turns,
)
from .settings import Settings, _atomic_json
from .schemas import (
    AlignmentAudit,
    Correction,
    ReconciledSegment,
    TimedSubtitleSegment,
    TranscriptDocument,
    TranscriptSegment as CoreTranscriptSegment,
)


class PipelineError(RuntimeError):
    pass


class PipelineCancelled(PipelineError):
    pass


class PipelineInterrupted(PipelineCancelled):
    """The owning worker stopped; durable job state must remain recoverable."""


Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]

logger = logging.getLogger(__name__)

PRIMARY_PROMPT_POLICY_VERSION = "2026-08-05.1"
VERIFIER_POLICY_VERSION = "2026-08-06.1"
DIARIZATION_POLICY_VERSION = "2026-08-27.1"
EXPORT_POLICY_VERSION = "2026-08-05.1"
CORRECTION_MEMORY_POLICY_VERSION = "2026-08-07.1"
WENET_DISPLAY_CUE_SHIFT_POLICY_VERSION = "wenet-display-end-trim-v1"
WENET_DISPLAY_CUE_START_SHIFT_MS = 0
WENET_DISPLAY_CUE_END_SHIFT_MS = -100
WENET_DISPLAY_CUE_MIN_RETAINED_DURATION_MS = 200

STAGES = ("primary", "verifier", "whisper", "alignment", "final", "timestamps", "exports")
STAGE_PROGRESS = {
    "primary": (0.10, 0.58),
    "verifier": (0.58, 0.78),
    "alignment": (0.78, 0.88),
    "final": (0.88, 0.92),
    "timestamps": (0.92, 0.96),
    "exports": (0.96, 1.00),
}
ACCURACY_STAGE_PROGRESS = {
    "primary": (0.10, 0.50),
    "whisper": (0.50, 0.70),
    "verifier": (0.70, 0.82),
    "alignment": (0.82, 0.90),
    "final": (0.90, 0.93),
    "timestamps": (0.93, 0.97),
    "exports": (0.97, 1.00),
}
JOB_STAGE_STATES = {
    "primary": "primary_asr",
    "verifier": "verifying",
    "whisper": "verifying",
    "alignment": "reconciling",
    "final": "normalizing",
    "timestamps": "normalizing",
    "exports": "exporting",
}
JOB_STATE_ORDER = (
    "probing",
    "extracting",
    "chunking",
    "primary_asr",
    "verifying",
    "reconciling",
    "normalizing",
    "exporting",
    "completed",
)


def _wenet_display_cue_adjustment(method: str) -> dict[str, Any]:
    """Describe the preregistered subtitle-only Wenet display adjustment."""

    applied = method.endswith("+wenet_ctc_anchor_retime")
    return {
        "policy_version": WENET_DISPLAY_CUE_SHIFT_POLICY_VERSION,
        "applied": applied,
        "start_shift_ms": WENET_DISPLAY_CUE_START_SHIFT_MS if applied else 0,
        "end_shift_ms": WENET_DISPLAY_CUE_END_SHIFT_MS if applied else 0,
        "scope": "subtitle_segments_only",
        "word_timestamps_changed": False,
        "character_timestamps_changed": False,
        "cue_start_changed": False,
        "cue_duration_preserved": False,
        "minimum_retained_duration_ms": WENET_DISPLAY_CUE_MIN_RETAINED_DURATION_MS,
        "shorter_cues_preserved": True,
        "media_end_overflow_possible": False,
    }


def _adjust_wenet_display_cue(
    start_ms: int,
    end_ms: int,
    *,
    method: str,
) -> tuple[int, int]:
    """Trim late cue ends without changing the Wenet timing backbone or starts."""

    adjustment = _wenet_display_cue_adjustment(method)
    if not adjustment["applied"]:
        return start_ms, end_ms
    shifted_start = max(0, start_ms + int(adjustment["start_shift_ms"]))
    original_duration_ms = max(1, end_ms - shifted_start)
    retained_duration_ms = min(
        original_duration_ms,
        int(adjustment["minimum_retained_duration_ms"]),
    )
    shifted_end = max(
        shifted_start + retained_duration_ms,
        end_ms + int(adjustment["end_shift_ms"]),
    )
    return shifted_start, shifted_end


def _load_checkpoint(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if value.get("schema") != 1 or not value.get("complete"):
        return None
    return value


def _verified_verifier_timing_checkpoint(path: Path) -> dict[str, Any] | None:
    """Return a sealed Wenet checkpoint or abstain without trusting it."""

    checkpoint = _load_checkpoint(path)
    if checkpoint is None or checkpoint.get("model") != WENET_TIMING_MODEL:
        return None
    segments = checkpoint.get("segments")
    if not isinstance(segments, list) or not all(
        isinstance(item, dict) for item in segments
    ):
        return None
    sealed = {
        "model": checkpoint.get("model"),
        "input_fingerprint": checkpoint.get("input_fingerprint"),
        "model_manifest_sha256": checkpoint.get("model_manifest_sha256"),
        "policy": checkpoint.get("policy"),
        "segments": segments,
    }
    payload_sha256 = checkpoint.get("payload_sha256")
    if not isinstance(payload_sha256, str) or not hmac.compare_digest(
        payload_sha256, _json_fingerprint(sealed)
    ):
        return None
    return checkpoint


def _json_fingerprint(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _validate_word_source_coverage(
    words: Sequence[Mapping[str, Any]],
    final_text: str,
) -> None:
    """Validate alignable source coverage without imposing block word splits.

    The upstream aligner removes punctuation before space-language
    tokenization.  A token such as ``comment。Come`` can therefore be one word
    inside a single alignment window but two words when a safe window boundary
    falls at the punctuation.  Source-character projection is invariant to
    that implementation detail; exact word-count equality is not.
    """

    expected_projection, expected_source_indices = _projection(final_text)
    actual_projection: list[str] = []
    actual_source_indices: list[int] = []
    previous_source_end = 0
    for index, word in enumerate(words):
        source_start = word.get("source_start")
        source_end = word.get("source_end")
        if (
            isinstance(source_start, bool)
            or not isinstance(source_start, int)
            or isinstance(source_end, bool)
            or not isinstance(source_end, int)
            or not 0 <= source_start < source_end <= len(final_text)
            or source_start < previous_source_end
        ):
            raise ValueError(f"word timestamp {index} source range 無效")
        word_text = word.get("text")
        if not isinstance(word_text, str) or word_text != final_text[source_start:source_end]:
            raise ValueError(f"word timestamp {index} text 無效")
        projected, raw_indices = _projection(word_text)
        if not projected or not raw_indices:
            raise ValueError(f"word timestamp {index} 冇 alignable text")
        actual_projection.extend(projected)
        actual_source_indices.extend(source_start + item for item in raw_indices)
        previous_source_end = source_end
    if (
        "".join(actual_projection) != expected_projection
        or actual_source_indices != expected_source_indices
    ):
        raise ValueError("word_timestamps 未精確覆蓋 alignable transcript text")


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _segment_fingerprint_values(segments: list[TranscriptSegment]) -> list[dict[str, Any]]:
    """Keep stage hashes stable by excluding timing/memory diagnostic metadata."""
    return [
        {
            "id": segment.id,
            "start": segment.start,
            "end": segment.end,
            "text": segment.text,
            "language": segment.language,
            "source": segment.source,
            "truncated": segment.truncated,
        }
        for segment in segments
    ]


def _component_policy(component: Any | None, default: str) -> dict[str, str]:
    if component is None:
        return {"component": "builtin", "version": default}
    component_type = type(component)
    version = getattr(component, "policy_version", None)
    if version is None:
        version = getattr(component_type, "policy_version", "unversioned")
    return {
        "component": f"{component_type.__module__}.{component_type.__qualname__}",
        "version": str(version),
    }


def _coerce_segments(value: dict[str, Any]) -> list[TranscriptSegment]:
    output = []
    for raw in value.get("segments", []):
        raw = dict(raw)
        tokens = raw.pop("tokens", [])
        # ``dict(raw)`` is shallow; copy nested metadata so resume coercion can
        # annotate the runtime object without mutating the sealed JSON payload.
        raw["metadata"] = dict(raw.get("metadata") or {})
        segment = TranscriptSegment(**raw)
        # Alignment/normalization integrations consume plain dictionaries, so
        # resumed token objects do not need reconstruction for primary output.
        segment.metadata.setdefault("resumed_tokens", tokens)
        output.append(segment)
    return output


def _checkpoint_segments_match_chunks(
    value: Mapping[str, Any],
    chunks: Sequence[AudioChunk],
    *,
    source: str,
    allow_prefix: bool = False,
) -> list[TranscriptSegment] | None:
    """Validate a checkpoint's complete chunk mapping before trusting its text.

    The seal protects the serialized payload, while this validation proves that
    the payload is actually a result for the expected chunks.  In particular,
    a correctly sealed but injected segment list cannot skip, duplicate, reorder
    or extend audio ranges.
    """

    raw_segments = value.get("segments")
    if not isinstance(raw_segments, list):
        return None
    if allow_prefix:
        if len(raw_segments) > len(chunks):
            return None
        expected_chunks = chunks[: len(raw_segments)]
    else:
        if len(raw_segments) != len(chunks):
            return None
        expected_chunks = chunks
    for raw, chunk in zip(raw_segments, expected_chunks):
        if not isinstance(raw, dict):
            return None
        start = raw.get("start")
        end = raw.get("end")
        try:
            expected_start = float(chunk.transcript_start)
            expected_end = float(chunk.transcript_end)
        except (TypeError, ValueError):
            return None
        if (
            raw.get("id") != chunk.id
            or raw.get("source") != source
            or raw.get("truncated") is not False
            or not isinstance(raw.get("text"), str)
            or not isinstance(start, (int, float))
            or isinstance(start, bool)
            or not isinstance(end, (int, float))
            or isinstance(end, bool)
            or not math.isfinite(float(start))
            or not math.isfinite(float(end))
            or not math.isfinite(expected_start)
            or not math.isfinite(expected_end)
            or expected_end < expected_start
            or abs(float(start) - expected_start) > 0.001
            or abs(float(end) - expected_end) > 0.001
        ):
            return None
    try:
        return _coerce_segments(dict(value))
    except (KeyError, TypeError, ValueError):
        return None


def _load_primary_partial(
    path: Path,
    *,
    model: str,
    chunks: list[AudioChunk],
    run_fingerprint: str,
) -> list[TranscriptSegment]:
    """Load only a valid, contiguous per-chunk primary journal prefix."""
    if not path.is_file():
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    if (
        value.get("schema") != 1
        or value.get("model") != model
        or value.get("run_fingerprint") != run_fingerprint
        or value.get("complete")
    ):
        return []
    sealed = {
        "model": value.get("model"),
        "run_fingerprint": value.get("run_fingerprint"),
        "segments": value.get("segments"),
    }
    seal = value.get("payload_sha256")
    if not (
        isinstance(seal, str)
        and hmac.compare_digest(seal, _json_fingerprint(sealed))
    ):
        return []
    segments = _checkpoint_segments_match_chunks(
        value,
        chunks,
        source="primary",
        allow_prefix=True,
    )
    if segments is None:
        return []
    return segments


def _load_completed_primary_checkpoint(
    path: Path,
    *,
    model: str,
    input_fingerprint: str,
    chunks: list[AudioChunk],
    model_path_for: Callable[[str], Path] | None,
) -> list[TranscriptSegment] | None:
    """Load a sealed complete primary checkpoint for one exact model/input."""

    checkpoint = _load_checkpoint(path)
    if (
        checkpoint is None
        or checkpoint.get("model") != model
        or checkpoint.get("input_fingerprint") != input_fingerprint
    ):
        return None
    stored_manifest = str(checkpoint.get("model_manifest_sha256", ""))
    sealed = {
        "model": checkpoint.get("model"),
        "input_fingerprint": checkpoint.get("input_fingerprint"),
        "model_manifest_sha256": stored_manifest,
        "run_fingerprint": checkpoint.get("run_fingerprint"),
        "prompt_policy_version": checkpoint.get("prompt_policy_version"),
        "segments": checkpoint.get("segments"),
    }
    expected_run_fingerprint = _json_fingerprint(
        {
            "input_fingerprint": input_fingerprint,
            "model_manifest_sha256": stored_manifest,
        }
    )
    manifests_match = True
    if callable(model_path_for):
        installed_model_path = Path(model_path_for(model))
        manifests_match = _installed_manifest_matches(
            stored_sha256=stored_manifest,
            model_path=installed_model_path,
            required_files=_qwen_required_files(installed_model_path),
        )
    segments = _checkpoint_segments_match_chunks(
        checkpoint,
        chunks,
        source="primary",
    )
    seal = checkpoint.get("payload_sha256")
    if not (
        checkpoint.get("prompt_policy_version") == PRIMARY_PROMPT_POLICY_VERSION
        and checkpoint.get("run_fingerprint") == expected_run_fingerprint
        and isinstance(seal, str)
        and hmac.compare_digest(seal, _json_fingerprint(sealed))
        and segments is not None
        and manifests_match
    ):
        return None
    return segments


def _primary_run_fingerprint(
    *,
    model: str,
    model_path: Path,
    context: str,
    vocabulary: tuple[str, ...],
    chunks: list[AudioChunk],
) -> str:
    """Bind a partial journal to the exact model, prompt, and disk chunks."""
    manifest_sha256 = _model_manifest_sha256(model_path)
    input_fingerprint = _primary_input_fingerprint(
        model=model,
        context=context,
        vocabulary=vocabulary,
        chunks=chunks,
    )
    return _json_fingerprint(
        {
            "input_fingerprint": input_fingerprint,
            "model_manifest_sha256": manifest_sha256,
        }
    )


def _model_manifest_sha256(model_path: Path) -> str:
    try:
        return hashlib.sha256((model_path / "manifest.json").read_bytes()).hexdigest()
    except OSError:
        return ""


def _runtime_source_matches_verified_model(
    runtime_manifest: Mapping[str, Any], source_model_path: Path
) -> bool:
    """Compare a derived runtime with the already verified source manifest.

    ``ModelManager.require_local`` authenticates the source checkpoint before
    this helper runs.  Comparing the two signed-by-hash file tables avoids
    re-reading another 4.7 GB merely to decide whether an existing Q8 runtime
    belongs to that exact source revision.
    """

    manifest_path = source_model_path / "manifest.json"
    try:
        manifest_bytes = manifest_path.read_bytes()
        source_manifest = json.loads(manifest_bytes)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return False
    runtime_source = runtime_manifest.get("source")
    if not isinstance(runtime_source, Mapping):
        return False
    if runtime_source.get("path") != str(source_model_path.resolve(strict=True)):
        return False
    if runtime_source.get("manifest_sha256") != hashlib.sha256(manifest_bytes).hexdigest():
        return False
    for key in ("model", "source", "revision"):
        if runtime_source.get(key) != source_manifest.get(key):
            return False
    runtime_files = runtime_source.get("files")
    source_files = source_manifest.get("files") if isinstance(source_manifest, Mapping) else None
    if not isinstance(runtime_files, list) or not isinstance(source_files, list):
        return False

    def file_table(values: Sequence[Any]) -> dict[str, tuple[int, str]] | None:
        result: dict[str, tuple[int, str]] = {}
        for raw in values:
            if not isinstance(raw, Mapping):
                return None
            name = raw.get("path")
            size = raw.get("size")
            sha256 = raw.get("sha256")
            if (
                not isinstance(name, str)
                or Path(name).name != name
                or name in result
                or isinstance(size, bool)
                or not isinstance(size, int)
                or size < 0
                or not isinstance(sha256, str)
                or len(sha256) != 64
                or any(character not in "0123456789abcdef" for character in sha256)
            ):
                return None
            result[name] = (size, sha256)
        return result or None

    return file_table(runtime_files) == file_table(source_files)


def _primary_runtime_from_segments(
    segments: Sequence[TranscriptSegment], *, model: str
) -> dict[str, Any] | None:
    """Restore a sealed runtime audit when a completed primary resumes."""

    restored: dict[str, Any] | None = None
    for segment in segments:
        metadata = segment.metadata if isinstance(segment.metadata, Mapping) else {}
        raw_runtime = metadata.get("runtime")
        model_path = metadata.get("model_path")
        if not isinstance(raw_runtime, Mapping) or not isinstance(model_path, str):
            return None
        quantized = raw_runtime.get("quantized")
        precision = raw_runtime.get("precision")
        if not isinstance(quantized, bool) or not isinstance(precision, str):
            return None
        candidate: dict[str, Any] = {
            "model": model,
            "quantized": quantized,
            "precision": precision,
            "path": model_path,
            "resumed_from_checkpoint": True,
        }
        if quantized:
            bits = raw_runtime.get("bits")
            group_size = raw_runtime.get("group_size")
            mode = raw_runtime.get("mode")
            scope = raw_runtime.get("scope")
            if (
                bits != 8
                or group_size != 64
                or mode != "affine"
                or scope != "text_decoder_only"
                or raw_runtime.get("metadata_valid") is not True
            ):
                return None
            candidate.update(
                {
                    "bits": 8,
                    "group_size": 64,
                    "mode": "affine",
                    "scope": "text_decoder_only",
                    "audio_encoder_precision": "float16",
                }
            )
        elif precision != "float16":
            return None
        if restored is None:
            restored = candidate
        elif restored != candidate:
            return None
    return restored


def _callable_policy(component: Any, default: str) -> dict[str, str]:
    """Return a stable adapter identity without depending on object reprs."""
    module = str(getattr(component, "__module__", type(component).__module__))
    qualname = str(getattr(component, "__qualname__", type(component).__qualname__))
    return {
        "component": f"{module}.{qualname}",
        "version": str(getattr(component, "policy_version", default)),
    }


def _audio_chunk_fingerprint_values(chunks: Sequence[AudioChunk]) -> list[dict[str, Any]]:
    """Bind a checkpoint to exact on-disk chunk bytes and timeline geometry."""
    values: list[dict[str, Any]] = []
    for chunk in chunks:
        try:
            stat = chunk.path.stat()
            size = stat.st_size
            mtime_ns = stat.st_mtime_ns
            sha256 = _file_sha256(chunk.path)
        except OSError:
            size = -1
            mtime_ns = -1
            sha256 = ""
        values.append(
            {
                "id": chunk.id,
                "index": chunk.index,
                "path": str(chunk.path),
                "size": size,
                "mtime_ns": mtime_ns,
                "sha256": sha256,
                "start": chunk.start,
                "end": chunk.end,
                "core_start": chunk.transcript_start,
                "core_end": chunk.transcript_end,
            }
        )
    return values


def _verifier_policy(factory: Any) -> dict[str, str]:
    return {
        **_callable_policy(factory, VERIFIER_POLICY_VERSION),
        "language": "Cantonese",
        "num_threads": "2",
        "decoding_method": "greedy_search",
    }


def _whisper_language(model: str) -> str:
    if model not in WHISPER_MODEL_IDS:
        raise PipelineError("Whisper model 必須係 Large v3 或 Large v2")
    return "yue" if model == WHISPER_LARGE_V3_ID else "zh"


def _whisper_policy(factory: Any, *, model: str) -> dict[str, str]:
    return {
        **_callable_policy(factory, WHISPER_CPP_POLICY_VERSION),
        "language": _whisper_language(model),
        "timestamp_mapping": "chunk_core_midpoint",
    }


def _verifier_input_fingerprint(
    *,
    model: str,
    policy: Mapping[str, str],
    chunks: Sequence[AudioChunk],
    primary: list[TranscriptSegment],
    primary_checkpoint: Mapping[str, Any],
) -> str:
    return _json_fingerprint(
        {
            "schema": 1,
            "model": model,
            "policy": dict(policy),
            "chunks": _audio_chunk_fingerprint_values(chunks),
            # A verifier result is downstream of this exact primary run.  Bind
            # both semantic output and run identity so a new prompt, primary
            # model or manifest cannot inherit a stale verifier checkpoint even
            # when its visible text happens to be unchanged.
            "primary": _segment_fingerprint_values(primary),
            "primary_checkpoint": {
                key: primary_checkpoint.get(key)
                for key in (
                    "model",
                    "input_fingerprint",
                    "model_manifest_sha256",
                    "run_fingerprint",
                )
            },
        }
    )


def _file_fingerprint_value(path: Path) -> dict[str, Any]:
    """Describe one file strongly enough to detect same-path byte replacement."""
    try:
        stat = path.stat()
        return {
            "path": str(path),
            "size": stat.st_size,
            "mtime_ns": stat.st_mtime_ns,
            "sha256": _file_sha256(path),
        }
    except OSError:
        return {"path": str(path), "size": -1, "mtime_ns": -1, "sha256": ""}


def _installed_manifest_matches(
    *,
    stored_sha256: str,
    model_path: Path,
    required_files: Sequence[Path],
) -> bool:
    """Match installed weights, while allowing resume after all weights are removed.

    A directory with any required weight still present but no manifest is an
    unverifiable/corrupt install, not a missing install, and cannot authorize a
    checkpoint resume.
    """
    installed_files = any(path.is_file() for path in required_files)
    installed_manifest = _model_manifest_sha256(model_path)
    if not installed_files and not installed_manifest:
        return True
    if not installed_manifest:
        return False
    return hmac.compare_digest(installed_manifest, stored_sha256)


def _strict_installed_manifest_matches(
    *,
    stored_sha256: str,
    model_path: Path,
    required_files: Sequence[Path],
) -> bool:
    """Require the exact installed model for a diarization checkpoint.

    Unlike ASR transcript checkpoints, speaker turns are not useful without
    the matching diarization runtime/model because users may retry or edit the
    speaker track.  Missing weights therefore fail closed instead of silently
    authorizing an old result.
    """

    current = _model_manifest_sha256(model_path)
    return bool(
        stored_sha256
        and current
        and all(path.is_file() and not path.is_symlink() for path in required_files)
        and hmac.compare_digest(current, stored_sha256)
    )


def _qwen_required_files(model_path: Path) -> tuple[Path, ...]:
    """Return enough local artifacts to distinguish removed from partial weights."""

    return (
        model_path / "config.json",
        *tuple(sorted(model_path.glob("*.safetensors"))),
    )


def _primary_input_fingerprint(
    *,
    model: str,
    context: str,
    vocabulary: tuple[str, ...],
    chunks: list[AudioChunk],
) -> str:
    """Fingerprint ASR inputs without requiring installed model weights.

    A completed primary checkpoint remains useful if its model is later removed;
    partial checkpoints still require and fingerprint the local model before they
    can continue inference.
    """
    return _json_fingerprint(
        {
            "schema": 1,
            "model": model,
            "context": context,
            "vocabulary": list(vocabulary),
            "language": "Cantonese",
            "prompt_policy_version": PRIMARY_PROMPT_POLICY_VERSION,
            "chunks": _audio_chunk_fingerprint_values(chunks),
        }
    )


def _whisper_input_fingerprint(
    *,
    model: str,
    context: str,
    vocabulary: tuple[str, ...],
    chunks: list[AudioChunk],
    policy: Mapping[str, str] | None = None,
) -> str:
    policy_value = dict(
        policy
        or {
            "component": "cts_backend.asr.whisper_cpp.WhisperCPPASR",
            "version": WHISPER_CPP_POLICY_VERSION,
            "language": _whisper_language(model),
            "timestamp_mapping": "chunk_core_midpoint",
        }
    )
    language = _whisper_language(model)
    if policy_value.get("language") != language:
        raise PipelineError("Whisper policy language 同 model 唔一致")
    return _json_fingerprint(
        {
            "schema": 1,
            "model": model,
            "context": context,
            "vocabulary": list(vocabulary),
            "language": language,
            "policy": policy_value,
            "chunks": _audio_chunk_fingerprint_values(chunks),
        }
    )


def _core_segments(values: list[TranscriptSegment]) -> tuple[CoreTranscriptSegment, ...]:
    return tuple(
        CoreTranscriptSegment(
            start_ms=round(item.start * 1000),
            end_ms=round(item.end * 1000),
            text=item.text,
            confidence=None,
            source=item.source,
            chunk_index=int(item.metadata.get("chunk_index", 0)) if item.metadata else None,
        )
        for item in values
        if item.text.strip()
    )


def _document_from_dict(value: dict[str, Any]) -> TranscriptDocument:
    segments = []
    for raw in value.get("segments", []):
        audit_raw = dict(raw["audit"])
        audit = AlignmentAudit(
            similarity=float(audit_raw["similarity"]),
            edit_distance=int(audit_raw["edit_distance"]),
            disagreement_count=int(audit_raw["disagreement_count"]),
            missing_in_verifier=bool(audit_raw["missing_in_verifier"]),
            conflict=bool(audit_raw["conflict"]),
            low_confidence=bool(audit_raw["low_confidence"]),
            reasons=tuple(audit_raw.get("reasons", ())),
            corrections=tuple(Correction(**item) for item in audit_raw.get("corrections", ())),
            disagreement_ratio=float(audit_raw.get("disagreement_ratio", 0.0)),
            missing=bool(audit_raw.get("missing", audit_raw.get("missing_in_verifier", False))),
            conflict_candidate=bool(audit_raw.get("conflict_candidate", audit_raw.get("conflict", False))),
        )
        segments.append(
            ReconciledSegment(
                start_ms=int(raw.get("start_ms", round(float(raw.get("start", 0.0)) * 1000))),
                end_ms=int(raw.get("end_ms", round(float(raw.get("end", 0.0)) * 1000))),
                primary_text=str(raw.get("primary_text", "")),
                verifier_text=str(raw.get("verifier_text", "")),
                text=str(raw.get("text", raw.get("chosen_text", ""))),
                confidence=float(raw["confidence"]) if raw.get("confidence") is not None else None,
                audit=audit,
                whisper_text=str(raw.get("whisper_text", "")),
                ensemble_audit=dict(raw.get("ensemble_audit", {})),
                speaker_index=(int(raw["speaker_index"]) if raw.get("speaker_index") is not None else None),
                speaker_id=str(raw["speaker_id"]) if raw.get("speaker_id") is not None else None,
                speaker_label=str(raw["speaker_label"]) if raw.get("speaker_label") is not None else None,
                speaker_labels=tuple(str(item) for item in raw.get("speaker_labels", ()) if item),
                speaker_overlap=bool(raw.get("speaker_overlap", False)),
            )
        )
    subtitle_segments: list[TimedSubtitleSegment] = []
    for index, raw in enumerate(value.get("subtitle_segments", ())):
        if not isinstance(raw, dict):
            raise PipelineError(f"subtitle segment {index} 無效")
        subtitle_segments.append(
            TimedSubtitleSegment(
                id=str(raw.get("id") or f"cue-{index + 1:06d}"),
                start_ms=int(raw.get("start_ms", round(float(raw.get("start", 0.0)) * 1000))),
                end_ms=int(raw.get("end_ms", round(float(raw.get("end", 0.0)) * 1000))),
                text=str(raw.get("text", "")),
                source_start=int(raw.get("source_start", 0)),
                source_end=int(raw.get("source_end", 0)),
                source_segment_index=(
                    int(raw["source_segment_index"])
                    if raw.get("source_segment_index") is not None
                    else None
                ),
                source_segment_indices=tuple(
                    int(item) for item in raw.get("source_segment_indices", ())
                ),
                confidence=(
                    float(raw["confidence"])
                    if raw.get("confidence") is not None
                    else None
                ),
                low_confidence=bool(raw.get("low_confidence", False)),
                timing_review_required=raw.get("timing_review_required"),
                method=str(raw.get("method", "qwen3_forced_aligner")),
                speaker_index=(
                    int(raw["speaker_index"])
                    if raw.get("speaker_index") is not None
                    else None
                ),
                speaker_id=str(raw["speaker_id"]) if raw.get("speaker_id") is not None else None,
                speaker_label=(
                    str(raw["speaker_label"])
                    if raw.get("speaker_label") is not None
                    else None
                ),
                speaker_labels=tuple(str(item) for item in raw.get("speaker_labels", ()) if item),
                speaker_overlap=bool(raw.get("speaker_overlap", False)),
            )
        )
    return TranscriptDocument(
        media_path=str(value.get("source_path", value.get("media_path", ""))),
        text=str(value.get("final_transcript", value.get("text", ""))),
        segments=tuple(segments),
        language=str(value.get("language", "Cantonese")),
        model_primary=value.get("model_primary"),
        model_verifier=value.get("model_verifier"),
        model_whisper=value.get("model_whisper", value.get("whisper_model")),
        vocabulary=tuple(value.get("vocabulary", ())),
        metadata=dict(value.get("metadata", {})),
        subtitle_segments=tuple(subtitle_segments),
        word_timestamps=tuple(
            dict(item) for item in value.get("word_timestamps", ()) if isinstance(item, dict)
        ),
        character_timestamps=tuple(
            dict(item)
            for item in value.get("character_timestamps", ())
            if isinstance(item, dict)
        ),
        duration=float(value["duration"]) if value.get("duration") is not None else None,
        processing_started_at=value.get("processing_started_at"),
        processing_completed_at=value.get("processing_completed_at"),
        version=int(value.get("version", 1)),
    )


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class TranscriptionPipeline:
    """Coordinates real adapters while keeping other backend layers injectable.

    Integration contract (duck typed):
    - aligner.reconcile(primary=list[dict], verifier=list[dict], vocabulary=list[str]) -> JSON value
    - normalizer.normalize(alignment JSON value) -> JSON value
    - exporter.export_all(final JSON value, output_dir=Path) -> JSON value
    - job_store.update(job_id, **fields) is optional
    """

    def __init__(
        self,
        *,
        model_manager: ModelManager,
        settings: Settings,
        aligner: Any | None = None,
        normalizer: Any | None = None,
        exporter: Any | None = None,
        job_store: Any | None = None,
        qwen_factory: Callable[..., Any] = QwenASR,
        sherpa_factory: Callable[..., Any] = SherpaYueVerifier,
        whisper_factory: Callable[..., Any] = WhisperCPPASR,
        arbiter_factory: Callable[..., Any] = LocalCandidateArbiter,
        arbiter_lifecycle_factory: Callable[..., Any] = LMStudioLifecycle,
        resource_guard_factory: Callable[..., Any] = MacASRResourceGuard,
        qwen_supervisor_factory: Callable[..., Any] = QwenProcessSupervisor,
        forced_aligner_factory: Callable[..., Any] = QwenForcedTimestampAligner,
        forced_supervisor_factory: Callable[..., Any] = ForcedProcessSupervisor,
        sortformer_diarizer_factory: Callable[..., Any] | None = None,
        legacy_diarizer_factory: Callable[..., Any] | None = None,
        sortformer_helper_path: Path | None = None,
    ) -> None:
        self.models = model_manager
        self.settings = settings
        self.aligner = aligner
        self.normalizer = normalizer
        self.exporter = exporter
        self.job_store = job_store
        self.qwen_factory = qwen_factory
        self.sherpa_factory = sherpa_factory
        self.whisper_factory = whisper_factory
        self.arbiter_factory = arbiter_factory
        self.arbiter_lifecycle_factory = arbiter_lifecycle_factory
        self.resource_guard_factory = resource_guard_factory
        self.qwen_supervisor_factory = qwen_supervisor_factory
        self.forced_aligner_factory = forced_aligner_factory
        self.forced_supervisor_factory = forced_supervisor_factory
        # ``None`` deliberately resolves the module global at call time so
        # tests can inject/monkeypatch without production code searching PATH.
        self.sortformer_diarizer_factory = sortformer_diarizer_factory
        self.legacy_diarizer_factory = legacy_diarizer_factory
        self.sortformer_helper_path = (
            Path(sortformer_helper_path) if sortformer_helper_path is not None else None
        )
        self._use_qwen_supervisor = qwen_factory is QwenASR
        self._use_forced_supervisor = forced_aligner_factory is QwenForcedTimestampAligner
        self._require_dedicated_alignment_windows = (
            self._use_forced_supervisor
            and forced_supervisor_factory is ForcedProcessSupervisor
        )
        self._accuracy_mode = settings.accuracy_mode
        self._whisper_model = settings.whisper_model
        self._local_arbiter_enabled = settings.local_arbiter_enabled
        self._local_arbiter_requested = settings.local_arbiter_enabled
        self._local_arbiter_model = settings.local_arbiter_model
        self._local_arbiter_endpoint = settings.local_arbiter_endpoint
        self._arbiter_lifecycle = None
        self._arbiter_lifecycle_audit: list[dict[str, object]] = []
        self._arbiter_lifecycle_released = False
        self._primary_resource_report: dict[str, Any] = {}
        self._primary_runtime: dict[str, Any] | None = None
        # Wenet anchor retiming may change the editable timing clock.  It is
        # deliberately *not* a persisted user/app setting while its external
        # timing gate remains incomplete: ordinary worker jobs therefore keep
        # this false, while an isolated candidate harness must opt in on each
        # call to ``run``.
        self._wenet_timing_retime_enabled = False
        # Direct stage-level tests and recovery tooling may call ``_final``
        # without first entering ``run``; the default snapshot is empty.
        self._correction_memory_entries: tuple[CorrectionEntry, ...] = ()

    def _update_job(self, job_id: str, **fields: Any) -> None:
        if self.job_store is None:
            return
        update = getattr(self.job_store, "update", None) or getattr(self.job_store, "update_job", None)
        if callable(update):
            update(job_id, **fields)

    def _checkpoint_job(
        self,
        name: str,
        artifact: Path | Sequence[Path],
        *,
        data: Mapping[str, Any] | None = None,
        refresh: bool = False,
    ) -> None:
        if self.job_store is None:
            return
        checkpoint = getattr(self.job_store, "checkpoint", None)
        if callable(checkpoint):
            get = getattr(self.job_store, "get", None)
            artifacts = [artifact] if isinstance(artifact, Path) else list(artifact)
            resolved = tuple(str(Path(item).expanduser().resolve()) for item in artifacts)
            if callable(get):
                existing = get(self._job_id).checkpoints.get(name)
                existing_user_data = dict(existing.data) if existing is not None else {}
                existing_user_data.pop("checkpoint_integrity_version", None)
                existing_user_data.pop("checkpoint_artifact_manifest", None)
                if (
                    not refresh
                    and existing is not None
                    and existing.is_valid()
                    and tuple(existing.artifacts) == resolved
                    and existing_user_data == dict(data or {})
                ):
                    return
            checkpoint(self._job_id, name, artifacts=artifacts, data=dict(data or {}))

    def _begin_job_stage(self, stage: str, *, resumed: bool = False) -> None:
        if self.job_store is None:
            return
        transition = getattr(self.job_store, "transition", None)
        get = getattr(self.job_store, "get", None)
        if not callable(transition) or not callable(get):
            return
        from .jobs import JobState

        target = JobState(JOB_STAGE_STATES[stage])
        record = get(self._job_id)
        if record.state == JobState.COMPLETED:
            return
        target_index = JOB_STATE_ORDER.index(target.value)
        if record.state == JobState.QUEUED and record.resume_from is not None:
            resume_index = JOB_STATE_ORDER.index(record.resume_from.value)
            if target_index < resume_index:
                if resumed:
                    return
                transition(
                    self._job_id,
                    target,
                    resume_checkpoint_invalidated=True,
                )
                return
        elif record.state.value in JOB_STATE_ORDER:
            current_index = JOB_STATE_ORDER.index(record.state.value)
            if target_index < current_index:
                return
        if record.state != target:
            transition(self._job_id, target)

    def _finish_job_state(self, state: str, error: str | None = None) -> None:
        if self.job_store is None:
            return
        transition = getattr(self.job_store, "transition", None)
        get = getattr(self.job_store, "get", None)
        if not callable(transition) or not callable(get):
            return
        from .jobs import JobState

        target = JobState(state)
        record = get(self._job_id)
        if record.state == target:
            return
        error_value = {"code": "pipeline_failed", "message": error} if error else None
        transition(self._job_id, target, error=error_value)

    @staticmethod
    def _check_cancel(cancelled: Cancelled | None) -> None:
        if cancelled and cancelled():
            raise PipelineCancelled("已取消工作；完成 checkpoints 已保留")

    def _stage_progress(self, stage: str, event: dict[str, Any], callback: Progress | None) -> None:
        if callback is None:
            return
        ranges = ACCURACY_STAGE_PROGRESS if getattr(self, "_accuracy_mode", False) else STAGE_PROGRESS
        start, end = ranges[stage]
        local = event.get("progress")
        overall = start if local is None else start + (end - start) * max(0.0, min(1.0, float(local)))
        callback({**event, "stage": stage, "overall_progress": overall})

    def _retry(self, stage: str, operation: Callable[[], Any], *, cancelled: Cancelled | None) -> Any:
        attempts = self.settings.max_retries + 1
        for attempt in range(1, attempts + 1):
            self._check_cancel(cancelled)
            try:
                return operation()
            except (PipelineCancelled, ASRCancelled):
                raise
            except Exception:
                if attempt >= attempts:
                    raise
                time.sleep(min(0.25 * attempt, 1.0))
        raise AssertionError(f"unreachable retry state: {stage}")

    def _processing_start(self) -> str:
        if self.job_store is not None:
            get = getattr(self.job_store, "get", None)
            if callable(get):
                record = get(self._job_id)
                checkpoint_times = [
                    checkpoint.completed_at
                    for checkpoint in getattr(record, "checkpoints", {}).values()
                    if getattr(checkpoint, "completed_at", None)
                ]
                if checkpoint_times:
                    return min(checkpoint_times)
                if getattr(record, "updated_at", None):
                    return str(record.updated_at)
        return _utc_now()

    def _enrich_document(self, value: dict[str, Any]) -> dict[str, Any]:
        enriched = dict(value)
        text = str(enriched.get("final_transcript", enriched.get("text", "")))
        enriched.update(
            {
                "source_filename": Path(self._media_path).name,
                "source_path": self._media_path,
                "media_path": self._media_path,
                "duration": self._duration,
                "language": "Cantonese",
                "primary_model": self._primary_model,
                "verifier_model": self._verifier_model,
                "model_primary": self._primary_model,
                "model_verifier": self._verifier_model,
                "processing_started_at": enriched.get("processing_started_at")
                or self._processing_started_at,
                # Timestamp completion only after the optional forced-alignment
                # stage.  Stamping here used to under-report every job that
                # still had to generate word/character/cue timings.
                "processing_completed_at": enriched.get("processing_completed_at"),
                "final_transcript": text,
                "text": text,
                "vocabulary": list(self._vocabulary),
            }
        )
        fallback_audit = getattr(self, "_primary_model_fallback", None)
        if isinstance(fallback_audit, dict):
            enriched["requested_primary_model"] = self._requested_primary_model
            enriched["primary_model_auto_fallback"] = True
            enriched["primary_model_fallback"] = dict(fallback_audit)
        if getattr(self, "_accuracy_mode", False):
            enriched.update(
                {
                    "whisper_model": self._whisper_model,
                    "model_whisper": self._whisper_model,
                    "accuracy_mode": True,
                }
            )
        runtime = getattr(self, "_primary_runtime", None)
        if isinstance(runtime, dict):
            enriched["primary_runtime"] = dict(runtime)
        return enriched

    def _guard_primary_model_load(self, workspace: Path) -> str:
        """Select a safe installed Qwen model immediately before a real load."""

        resource_guard_path = workspace / "resource-guard.json"
        try:
            resource_guard = self.resource_guard_factory()
            resource_report = resource_guard.prepare(primary_model=self._primary_model)
        except ResourceGuardError as exc:
            self._primary_resource_report = dict(exc.report)
            _atomic_json(
                resource_guard_path,
                {
                    "schema": 1,
                    "complete": False,
                    "value": exc.report,
                    "error": str(exc),
                },
            )
            raise PipelineError(str(exc)) from exc
        self._primary_resource_report = dict(resource_report)
        _atomic_json(
            resource_guard_path,
            {"schema": 1, "complete": True, "value": resource_report},
        )
        return self._primary_model

    def _prepare_primary_runtime(
        self,
        *,
        key: str,
        source_model_path: Path,
        workspace: Path,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> Path:
        """Use a decoder-Q8 derivative for 1.7B on low-memory Apple Silicon.

        The ASR identity remains Qwen3-ASR-1.7B.  Only its local numerical
        representation changes; the audio encoder stays FP16 and the source
        checkpoint remains untouched.  There is deliberately no silent 0.6B
        fallback when preparation fails.
        """

        low_memory = bool(self._primary_resource_report.get("low_memory_device", False))
        if key != QWEN_PRIMARY_ID or not low_memory or not self._use_qwen_supervisor:
            self._primary_runtime = {
                "model": key,
                "quantized": False,
                "precision": "float16",
                "path": str(source_model_path),
            }
            return source_model_path

        candidate = runtime_output_path(source_model_path, bits=8)
        verified = verify_quantized_runtime(
            candidate,
            verify_hashes=True,
            expected_bits=8,
            expected_group_size=64,
            expected_mode="affine",
            expected_scope="text_decoder_only",
        )
        reusable = bool(
            verified.valid
            and isinstance(verified.manifest, dict)
            and _runtime_source_matches_verified_model(
                verified.manifest, source_model_path
            )
        )

        def conversion_progress(event: dict[str, Any]) -> None:
            self._stage_progress(
                "primary",
                {
                    "phase": "primary_runtime_optimizing",
                    # Keep overall progress monotonic: model optimization is a
                    # one-time preflight, before audio inference begins.
                    "progress": 0.0,
                    "runtime_progress": event.get("progress"),
                },
                progress,
            )

        try:
            result = (
                None
                if reusable
                else convert_qwen_runtime(
                    source_model_path,
                    bits=8,
                    group_size=64,
                    progress=conversion_progress,
                    cancelled=cancelled,
                )
            )
        except QwenRuntimeConversionCancelled as exc:
            raise PipelineCancelled(str(exc)) from exc
        except QwenRuntimeConversionError as exc:
            raise PipelineError(
                "未能準備 Qwen3-ASR 1.7B 低記憶體 runtime；"
                "原始模型已保留，亦冇轉用 0.6B。"
            ) from exc
        except (OSError, ValueError, ImportError, RuntimeError, MemoryError) as exc:
            raise PipelineError(
                "未能準備 Qwen3-ASR 1.7B 低記憶體 runtime；"
                "請驗證主模型或稍後再試。原始模型已保留，亦冇轉用 0.6B。"
            ) from exc

        runtime_path = candidate if result is None else result.output_dir
        manifest = verified.manifest if result is None else result.manifest
        quantization = (
            dict(manifest.get("quantization", {}))
            if isinstance(manifest, Mapping)
            else {}
        )
        self._primary_runtime = {
            "model": QWEN_PRIMARY_ID,
            "quantized": True,
            "precision": f"int{int(quantization['bits'])}",
            "bits": int(quantization["bits"]),
            "group_size": int(quantization["group_size"]),
            "mode": str(quantization["mode"]),
            "scope": str(quantization.get("scope", "text_decoder_only")),
            "audio_encoder_precision": "float16",
            "path": str(runtime_path),
            "reused": result is None or bool(result.reused),
        }
        guard_path = workspace / "resource-guard.json"
        try:
            guard_value = json.loads(guard_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            guard_value = {"schema": 1, "complete": True, "value": {}}
        raw_report = guard_value.get("value")
        report = dict(raw_report) if isinstance(raw_report, Mapping) else {}
        report["primary_runtime"] = dict(self._primary_runtime)
        guard_value["value"] = report
        _atomic_json(guard_path, guard_value)
        return runtime_path

    def run(
        self,
        *,
        job_id: str,
        workspace: Path,
        chunks: Iterable[AudioChunk | dict[str, Any] | Any],
        media_path: str | Path | None = None,
        vocabulary: Iterable[str] = (),
        correction_memory_entries: object = (),
        correction_memory_schema: int | None = None,
        primary_model: str | None = None,
        verifier_model: str | None = None,
        accuracy_mode: bool | None = None,
        whisper_model: str | None = None,
        local_arbiter_enabled: bool | None = None,
        local_arbiter_model: str | None = None,
        local_arbiter_endpoint: str | None = None,
        diarization_audio_path: str | Path | None = None,
        speaker_diarization_enabled: bool | None = None,
        speaker_num_speakers: int | None = None,
        forced_alignment_enabled: bool | None = None,
        wenet_timing_retime_enabled: bool = False,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
        interrupted: Cancelled | None = None,
    ) -> dict[str, Any]:
        workspace = Path(workspace)
        workspace.mkdir(parents=True, exist_ok=True)
        chunk_list = [AudioChunk.coerce(item) for item in chunks]
        if not chunk_list:
            raise PipelineError("工作無 audio chunks")
        self._vocabulary = tuple(
            dict.fromkeys(term.strip() for term in vocabulary if isinstance(term, str) and term.strip())
        )
        try:
            self._correction_memory_entries = correction_entries_from_snapshot(
                correction_memory_entries,
                schema=correction_memory_schema,
            )
        except CorrectionMemoryError as exc:
            raise PipelineError(str(exc)) from exc
        self._primary_model = primary_model or (
            QWEN_FALLBACK_ID if self.settings.use_fallback else QWEN_PRIMARY_ID
        )
        if self._primary_model not in {QWEN_PRIMARY_ID, QWEN_FALLBACK_ID}:
            raise PipelineError(f"primary model 唔支援：{self._primary_model}")
        self._requested_primary_model = self._primary_model
        self._primary_model_fallback: dict[str, Any] | None = None
        self._primary_resource_report = {}
        self._primary_runtime = None
        self._verifier_model = verifier_model or SHERPA_MODEL_NAME
        if self._verifier_model != SHERPA_MODEL_NAME:
            raise PipelineError(f"verifier model 必須係 {SHERPA_MODEL_NAME}")
        self._accuracy_mode = self.settings.accuracy_mode if accuracy_mode is None else accuracy_mode
        if not isinstance(self._accuracy_mode, bool):
            raise PipelineError("accuracy_mode 必須係布林值")
        self._whisper_model = whisper_model or self.settings.whisper_model
        if self._whisper_model not in WHISPER_MODEL_IDS:
            raise PipelineError("Whisper model 必須係 Large v3 或 Large v2")
        self._local_arbiter_enabled = (
            self.settings.local_arbiter_enabled
            if local_arbiter_enabled is None
            else local_arbiter_enabled
        )
        if not isinstance(self._local_arbiter_enabled, bool):
            raise PipelineError("local_arbiter_enabled 必須係布林值")
        self._local_arbiter_requested = self._local_arbiter_enabled
        self._local_arbiter_model = local_arbiter_model or self.settings.local_arbiter_model
        self._local_arbiter_endpoint = (
            local_arbiter_endpoint or self.settings.local_arbiter_endpoint
        )
        self._speaker_diarization_enabled = (
            self.settings.speaker_diarization_enabled
            if speaker_diarization_enabled is None
            else speaker_diarization_enabled
        )
        if not isinstance(self._speaker_diarization_enabled, bool):
            raise PipelineError("speaker_diarization_enabled 必須係布林值")
        self._forced_alignment_enabled = (
            self.settings.forced_alignment_enabled
            if forced_alignment_enabled is None
            else forced_alignment_enabled
        )
        if not isinstance(self._forced_alignment_enabled, bool):
            raise PipelineError("forced_alignment_enabled 必須係布林值")
        if not isinstance(wenet_timing_retime_enabled, bool):
            raise PipelineError("wenet_timing_retime_enabled 必須係布林值")
        # This is intentionally call-scoped rather than drawn from Settings or
        # worker RPC metadata.  A normal CTS job cannot silently become a
        # timing-retime experiment merely because a verifier checkpoint exists.
        self._wenet_timing_retime_enabled = wenet_timing_retime_enabled
        self._speaker_num_speakers = speaker_num_speakers
        if self._speaker_num_speakers is not None and (
            isinstance(self._speaker_num_speakers, bool)
            or self._speaker_num_speakers < 1
            or self._speaker_num_speakers > 20
        ):
            raise PipelineError("speaker_num_speakers 必須係 1 至 20 或留空自動辨認")
        self._arbiter_lifecycle = None
        self._arbiter_lifecycle_audit: list[dict[str, object]] = []
        self._arbiter_lifecycle_released = False
        self._job_id = job_id
        self._update_job(job_id, status="running", progress=0.0)
        self._media_path = str(Path(media_path) if media_path else chunk_list[0].path)
        self._duration = round(max(item.transcript_end for item in chunk_list), 3)
        self._diarization_audio_path = (
            str(Path(diarization_audio_path).expanduser().resolve())
            if diarization_audio_path
            else None
        )
        self._processing_started_at = self._processing_start()
        try:
            if self._accuracy_mode and self._local_arbiter_enabled:
                self._arbiter_lifecycle = self.arbiter_lifecycle_factory(
                    self._local_arbiter_model
                )
                configure_endpoint = getattr(
                    self._arbiter_lifecycle, "configure_endpoint", None
                )
                if callable(configure_endpoint):
                    configure_endpoint(self._local_arbiter_endpoint)
                lifecycle_event = self._arbiter_lifecycle.prepare_asr()
                self._arbiter_lifecycle_audit.append(dict(lifecycle_event))
                lifecycle_status = lifecycle_event.get("status")
                if lifecycle_status == "cli_missing":
                    # Gemma is an optional bounded-choice arbiter.  If LM
                    # Studio CLI binary is absent, keep the three independent
                    # ASR transcripts and use deterministic reconciliation.
                    # Memory-conflict/unload failures remain fail-closed below.
                    self._arbiter_lifecycle_audit.append(
                        {
                            "status": "disabled_for_job",
                            "reason": "cli_missing",
                            "model": self._local_arbiter_model,
                        }
                    )
                    self._local_arbiter_enabled = False
                    self._arbiter_lifecycle = None
                elif lifecycle_status not in {
                    "already_unloaded",
                    "unloaded_for_asr",
                }:
                    raise PipelineError(
                        "未能確認本機 LLM 已釋放；已停止，避免同 Qwen 同時佔用 RAM"
                    )
            primary = self._primary(
                workspace, chunk_list, progress=progress, cancelled=cancelled
            )
            # QwenASR releases Session/MLX in its finally block before the
            # Whisper process starts. Accuracy Mode intentionally runs the two
            # user-visible ASR hypotheses in this order: Qwen → Whisper.
            whisper = (
                self._whisper(
                    workspace, chunk_list, progress=progress, cancelled=cancelled
                )
                if self._accuracy_mode
                else None
            )
            # whisper.cpp exits before the CPU-only Cantonese verifier loads.
            verifier = self._verifier(
                workspace,
                chunk_list,
                primary=primary,
                progress=progress,
                cancelled=cancelled,
            )
            alignment = self._alignment(
                workspace,
                primary,
                verifier,
                whisper=whisper,
                progress=progress,
                cancelled=cancelled,
            )
            alignment = self._diarization(
                workspace,
                alignment,
                progress=progress,
                cancelled=cancelled,
            )
            final = self._final(
                workspace, alignment, progress=progress, cancelled=cancelled
            )
            final = self._timestamps(
                workspace,
                chunk_list,
                final,
                progress=progress,
                cancelled=cancelled,
            )
            exports = self._exports(
                workspace, final, progress=progress, cancelled=cancelled
            )
            result = {
                "job_id": job_id,
                "workspace": str(workspace),
                "primary": str(workspace / "primary.json"),
                "verifier": str(workspace / "verifier.json"),
                "alignment": str(workspace / "alignment.json"),
                "final": str(workspace / "final.json"),
                "timestamps": str(workspace / "timestamps.json"),
                "exports": exports,
            }
            if self._accuracy_mode:
                result["whisper"] = str(workspace / "whisper.json")
            self._finish_job_state("completed")
            self._update_job(job_id, status="completed", progress=1.0, result=result)
            return result
        except (PipelineCancelled, ASRCancelled) as exc:
            if interrupted is not None and interrupted():
                # Worker shutdown uses the same low-level cancellation token to
                # stop model subprocesses promptly, but it is not a user's
                # durable Cancel command.  Keep the active state/checkpoints so
                # JobStore.recover_interrupted() can requeue this attempt on
                # the next launch.
                raise PipelineInterrupted(
                    "App 已停止；工作會喺下次啟動由 checkpoint 繼續"
                ) from exc
            self._finish_job_state("canceled")
            self._update_job(job_id, status="cancelled", error=str(exc))
            raise PipelineCancelled(str(exc)) from exc
        except Exception as exc:
            self._finish_job_state("failed", str(exc))
            self._update_job(job_id, status="failed", error=str(exc))
            raise
        finally:
            if (
                self._arbiter_lifecycle is not None
                and not self._arbiter_lifecycle_released
            ):
                try:
                    event = dict(self._arbiter_lifecycle.release())
                except Exception:
                    event = {
                        "status": "release_failed",
                        "model": self._local_arbiter_model,
                    }
                self._arbiter_lifecycle_audit.append(event)
                self._arbiter_lifecycle_released = event.get("status") in {
                    "unloaded",
                    "already_unloaded",
                }

    def _primary(
        self, workspace: Path, chunks: list[AudioChunk], *, progress: Progress | None, cancelled: Cancelled | None
    ) -> list[TranscriptSegment]:
        key = self._primary_model
        primary_path = workspace / "primary.json"
        total_duration = sum(chunk.duration for chunk in chunks)
        context = self.settings.context.strip()
        if self._vocabulary:
            # mlx-qwen3-asr documents a simple space-separated context list.
            vocabulary_context = " ".join(self._vocabulary)
            context = "\n".join(item for item in (context, vocabulary_context) if item)
        input_fingerprint = _primary_input_fingerprint(
            model=key,
            context=context,
            vocabulary=self._vocabulary,
            chunks=chunks,
        )
        path_for = getattr(self.models, "path_for", None)

        def load_completed_from_installed_variants(
            model_key: str, fingerprint: str
        ) -> list[TranscriptSegment] | None:
            if not callable(path_for):
                return _load_completed_primary_checkpoint(
                    primary_path,
                    model=model_key,
                    input_fingerprint=fingerprint,
                    chunks=chunks,
                    model_path_for=None,
                )
            source_path = Path(path_for(model_key))
            candidates = [source_path]
            if model_key == QWEN_PRIMARY_ID:
                q8_path = runtime_output_path(source_path, bits=8)
                if q8_path.is_dir() and (q8_path / "manifest.json").is_file():
                    candidates.append(q8_path)
            for candidate_path in candidates:
                resumed_value = _load_completed_primary_checkpoint(
                    primary_path,
                    model=model_key,
                    input_fingerprint=fingerprint,
                    chunks=chunks,
                    model_path_for=lambda _key, path=candidate_path: path,
                )
                if resumed_value is not None:
                    return resumed_value
            return None

        resumed = load_completed_from_installed_variants(key, input_fingerprint)
        if resumed is not None:
            self._begin_job_stage("primary", resumed=True)
            self._primary_runtime = _primary_runtime_from_segments(
                resumed, model=key
            )
            self._checkpoint_job("primary_asr", primary_path)
            self._stage_progress("primary", {"progress": 1.0, "resumed": True}, progress)
            return resumed

        self._begin_job_stage("primary")
        self._stage_progress("primary", {"progress": 0.0}, progress)
        selected_key = self._guard_primary_model_load(workspace)
        if selected_key != key:
            key = selected_key
            input_fingerprint = _primary_input_fingerprint(
                model=key,
                context=context,
                vocabulary=self._vocabulary,
                chunks=chunks,
            )
            resumed = load_completed_from_installed_variants(key, input_fingerprint)
            if resumed is not None:
                self._primary_runtime = _primary_runtime_from_segments(
                    resumed, model=key
                )
                self._checkpoint_job("primary_asr", primary_path)
                self._stage_progress(
                    "primary",
                    {
                        "phase": "primary_model_fallback",
                        "progress": 1.0,
                        "resumed": True,
                    },
                    progress,
                )
                return resumed
            self._stage_progress(
                "primary",
                {
                    "phase": "primary_model_fallback",
                    "progress": 0.0,
                    "requested_model": self._requested_primary_model,
                    "selected_model": key,
                },
                progress,
            )
        source_model_path = self.models.require_local(key)
        model_path = self._prepare_primary_runtime(
            key=key,
            source_model_path=source_model_path,
            workspace=workspace,
            progress=progress,
            cancelled=cancelled,
        )
        model_manifest_sha256 = _model_manifest_sha256(model_path)
        run_fingerprint = _primary_run_fingerprint(
            model=key,
            model_path=model_path,
            context=context,
            vocabulary=self._vocabulary,
            chunks=chunks,
        )

        def operation() -> list[TranscriptSegment]:
            resumed = _load_primary_partial(
                primary_path,
                model=key,
                chunks=chunks,
                run_fingerprint=run_fingerprint,
            )
            remaining = chunks[len(resumed):]
            completed = list(resumed)
            processed_duration = sum(chunk.duration for chunk in chunks[: len(resumed)])

            # A crash can happen after the last per-chunk journal write but
            # before the final checkpoint is marked complete.  In that case all
            # inference work is already durable, so do not reload the 1.7B model.
            if not remaining:
                return resumed

            def persist_segment(segment: TranscriptSegment) -> None:
                completed.append(segment)
                sealed = {
                    "model": key,
                    "run_fingerprint": run_fingerprint,
                    "segments": segments_to_dict(completed),
                }
                _atomic_json(
                    primary_path,
                    {
                        "schema": 1,
                        "complete": False,
                        **sealed,
                        "payload_sha256": _json_fingerprint(sealed),
                    },
                )

            initial_previous_text = "".join(item.text for item in resumed)[-512:]
            if self._use_qwen_supervisor:
                watchdog_path = workspace / "qwen-watchdog.jsonl"
                prefix_by_chunk: dict[str, tuple[float, float]] = {}
                cursor = processed_duration
                for item in remaining:
                    prefix_by_chunk[item.id] = (cursor, item.duration)
                    cursor += item.duration
                last_logged_at = 0.0
                last_logged_progress: dict[str, float] = {}

                def on_watchdog_event(event: dict[str, Any]) -> None:
                    nonlocal last_logged_at
                    # Supervisor telemetry is allow-listed and contains no
                    # transcript.  A partial last JSONL record is diagnostic
                    # only and can never be mistaken for a checkpoint.
                    raw_progress = event.get("progress")
                    chunk_id = str(event.get("chunk_id") or "")
                    now = time.monotonic()
                    should_log = event.get("event") != "progress"
                    if (
                        not should_log
                        and isinstance(raw_progress, (int, float))
                        and not isinstance(raw_progress, bool)
                        and event.get("substantive") is not False
                    ):
                        fraction = max(0.0, min(1.0, float(raw_progress)))
                        previous = last_logged_progress.get(chunk_id, -1.0)
                        should_log = fraction >= previous + 0.05 or now - last_logged_at >= 5.0
                        if should_log:
                            last_logged_progress[chunk_id] = fraction
                    if should_log:
                        with watchdog_path.open("a", encoding="utf-8") as stream:
                            stream.write(
                                json.dumps(
                                    event,
                                    ensure_ascii=False,
                                    sort_keys=True,
                                    separators=(",", ":"),
                                    allow_nan=False,
                                )
                                + "\n"
                            )
                        last_logged_at = now
                    local_progress: float | None = None
                    if isinstance(raw_progress, (int, float)) and not isinstance(
                        raw_progress, bool
                    ):
                        if event.get("event") == "progress" and chunk_id in prefix_by_chunk:
                            prefix, duration = prefix_by_chunk[chunk_id]
                            local_progress = (
                                prefix + duration * max(0.0, min(1.0, float(raw_progress)))
                            ) / total_duration if total_duration else None
                        else:
                            local_progress = max(0.0, min(1.0, float(raw_progress)))
                    self._stage_progress(
                        "primary",
                        {
                            "phase": "primary_watchdog",
                            "chunk_id": chunk_id or None,
                            "progress": local_progress,
                            "watchdog": event,
                        },
                        progress,
                    )

                supervisor = self.qwen_supervisor_factory()
                supervised = supervisor.run_chunks_with_retries(
                    max_retries=self.settings.max_retries,
                    model_path=model_path,
                    chunks=remaining,
                    workspace=workspace / "qwen-supervisor",
                    context=context,
                    language="Cantonese",
                    initial_previous_text=initial_previous_text,
                    processed_duration=processed_duration,
                    total_duration=total_duration,
                    cancelled=cancelled,
                    telemetry=on_watchdog_event,
                    segment_completed=persist_segment,
                )
                generated = list(supervised.segments)
            else:
                adapter = self.qwen_factory(
                    model_path, context=context, language="Cantonese"
                )
                generated = adapter.transcribe_chunks(
                    remaining,
                    progress=lambda event: self._stage_progress("primary", event, progress),
                    cancelled=cancelled,
                    initial_previous_text=initial_previous_text,
                    processed_duration=processed_duration,
                    total_duration=total_duration,
                    segment_completed=persist_segment,
                )
            return resumed + generated

        # The process supervisor owns the full retry budget and resumes from its
        # last durable chunk.  Stacking the generic retry loop here could exceed
        # the product's maximum of two retries.
        segments = (
            operation()
            if self._use_qwen_supervisor
            else self._retry("primary", operation, cancelled=cancelled)
        )
        if (
            _checkpoint_segments_match_chunks(
                {"segments": segments_to_dict(segments)},
                chunks,
                source="primary",
            )
            is None
        ):
            raise PipelineError("Primary ASR 輸出同音訊 chunks 不一致；未寫入 checkpoint")
        sealed = {
            "model": key,
            "input_fingerprint": input_fingerprint,
            "model_manifest_sha256": model_manifest_sha256,
            "run_fingerprint": run_fingerprint,
            "prompt_policy_version": PRIMARY_PROMPT_POLICY_VERSION,
            "segments": segments_to_dict(segments),
        }
        _atomic_json(
            primary_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )
        self._checkpoint_job("primary_asr", primary_path, refresh=True)
        return segments

    def _verifier(
        self,
        workspace: Path,
        chunks: list[AudioChunk],
        *,
        primary: list[TranscriptSegment],
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> list[TranscriptSegment]:
        checkpoint_path = workspace / "verifier.json"
        primary_checkpoint = _load_checkpoint(workspace / "primary.json") or {}
        policy = _verifier_policy(self.sherpa_factory)
        input_fingerprint = _verifier_input_fingerprint(
            model=self._verifier_model,
            policy=policy,
            chunks=chunks,
            primary=primary,
            primary_checkpoint=primary_checkpoint,
        )
        path_for = getattr(self.models, "path_for", None)
        checkpoint = _load_checkpoint(checkpoint_path)
        if (
            checkpoint
            and checkpoint.get("model") == self._verifier_model
            and checkpoint.get("input_fingerprint") == input_fingerprint
            and checkpoint.get("policy") == policy
        ):
            model_path = (
                Path(path_for(self._verifier_model))
                if callable(path_for)
                else Path("/__cts_missing_verifier_model__")
            )
            stored_manifest = str(checkpoint.get("model_manifest_sha256", ""))
            sealed = {
                "model": checkpoint.get("model"),
                "input_fingerprint": checkpoint.get("input_fingerprint"),
                "model_manifest_sha256": stored_manifest,
                "policy": checkpoint.get("policy"),
                "segments": checkpoint.get("segments"),
            }
            seal = checkpoint.get("payload_sha256")
            try:
                resumed = _coerce_segments(checkpoint)
            except (KeyError, TypeError, ValueError):
                resumed = []
            semantic_match = len(resumed) == len(chunks) and all(
                segment.id == chunk.id
                and abs(segment.start - chunk.transcript_start) <= 0.001
                and abs(segment.end - chunk.transcript_end) <= 0.001
                and segment.source == "verifier"
                and not segment.truncated
                for segment, chunk in zip(resumed, chunks)
            )
            if (
                isinstance(seal, str)
                and hmac.compare_digest(seal, _json_fingerprint(sealed))
                and semantic_match
                and _installed_manifest_matches(
                    stored_sha256=stored_manifest,
                    model_path=model_path,
                    required_files=(
                        model_path / "model.int8.onnx",
                        model_path / "tokens.txt",
                    ),
                )
            ):
                self._begin_job_stage("verifier", resumed=True)
                verified_artifacts: Path | list[Path] = checkpoint_path
                if self._accuracy_mode:
                    verified_artifacts = [workspace / "whisper.json", checkpoint_path]
                self._checkpoint_job("verified", verified_artifacts)
                self._stage_progress(
                    "verifier", {"progress": 1.0, "resumed": True}, progress
                )
                return resumed
        self._begin_job_stage("verifier")
        self._stage_progress("verifier", {"progress": 0.0}, progress)
        model_path = self.models.require_local(self._verifier_model)
        model_manifest_sha256 = _model_manifest_sha256(model_path)

        def operation() -> list[TranscriptSegment]:
            adapter = self.sherpa_factory(model_path, num_threads=2)
            return adapter.verify_chunks(
                chunks,
                progress=lambda event: self._stage_progress("verifier", event, progress),
                cancelled=cancelled,
            )

        segments = self._retry("verifier", operation, cancelled=cancelled)
        sealed = {
            "model": self._verifier_model,
            "input_fingerprint": input_fingerprint,
            "model_manifest_sha256": model_manifest_sha256,
            "policy": policy,
            "segments": segments_to_dict(segments),
        }
        _atomic_json(
            checkpoint_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )
        verified_artifacts: Path | list[Path] = checkpoint_path
        if self._accuracy_mode:
            verified_artifacts = [workspace / "whisper.json", checkpoint_path]
        self._checkpoint_job("verified", verified_artifacts, refresh=True)
        return segments

    def _whisper(
        self,
        workspace: Path,
        chunks: list[AudioChunk],
        *,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> list[TranscriptSegment]:
        context = self.settings.context.strip()
        if self._vocabulary:
            context = "\n".join(
                item for item in (context, " ".join(self._vocabulary)) if item
            )
        policy = _whisper_policy(self.whisper_factory, model=self._whisper_model)
        fingerprint = _whisper_input_fingerprint(
            model=self._whisper_model,
            context=context,
            vocabulary=self._vocabulary,
            chunks=chunks,
            policy=policy,
        )
        checkpoint_path = workspace / "whisper.json"
        checkpoint = _load_checkpoint(checkpoint_path)
        if (
            checkpoint
            and checkpoint.get("model") == self._whisper_model
            and checkpoint.get("input_fingerprint") == fingerprint
            and checkpoint.get("policy") == policy
        ):
            stored_manifest = str(checkpoint.get("model_manifest_sha256", ""))
            sealed = {
                "model": checkpoint.get("model"),
                "input_fingerprint": checkpoint.get("input_fingerprint"),
                "model_manifest_sha256": stored_manifest,
                "policy": checkpoint.get("policy"),
                "segments": checkpoint.get("segments"),
            }
            seal = checkpoint.get("payload_sha256")
            resumed = _checkpoint_segments_match_chunks(
                checkpoint,
                chunks,
                source="whisper",
            )
            path_for = getattr(self.models, "path_for", None)
            manifests_match = True
            if callable(path_for):
                installed_model_path = Path(path_for(self._whisper_model))
                manifests_match = _installed_manifest_matches(
                    stored_sha256=stored_manifest,
                    model_path=installed_model_path,
                    required_files=(
                        installed_model_path / WHISPER_MODEL_FILENAMES[self._whisper_model],
                    ),
                )
            if (
                isinstance(seal, str)
                and hmac.compare_digest(seal, _json_fingerprint(sealed))
                and resumed is not None
                and manifests_match
            ):
                self._begin_job_stage("whisper", resumed=True)
                self._stage_progress(
                    "whisper", {"progress": 1.0, "resumed": True}, progress
                )
                return resumed

        self._begin_job_stage("whisper")
        self._stage_progress("whisper", {"progress": 0.0}, progress)
        model_path = self.models.require_local(self._whisper_model)
        model_manifest_sha256 = _model_manifest_sha256(model_path)
        output_dir = workspace / "whisper-cli" / fingerprint[:16]

        def operation() -> list[TranscriptSegment]:
            adapter = self.whisper_factory(
                model_path,
                context=context,
                output_dir=output_dir,
                language=policy["language"],
            )
            return adapter.transcribe_chunks(
                chunks,
                progress=lambda event: self._stage_progress("whisper", event, progress),
                cancelled=cancelled,
            )

        segments = self._retry("whisper", operation, cancelled=cancelled)
        if (
            _checkpoint_segments_match_chunks(
                {"segments": segments_to_dict(segments)},
                chunks,
                source="whisper",
            )
            is None
        ):
            raise PipelineError("Whisper 輸出同音訊 chunks 不一致；未寫入 checkpoint")
        sealed = {
            "model": self._whisper_model,
            "input_fingerprint": fingerprint,
            "model_manifest_sha256": model_manifest_sha256,
            "policy": policy,
            "segments": segments_to_dict(segments),
        }
        _atomic_json(
            checkpoint_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )
        return segments

    def _alignment(
        self,
        workspace: Path,
        primary: list[TranscriptSegment],
        verifier: list[TranscriptSegment],
        whisper: list[TranscriptSegment] | None = None,
        *,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> dict[str, Any]:
        # Check current evidence before reading a sealed alignment checkpoint.
        # run() always enters this stage before any downstream cache can return.
        primary_health = [
            primary_decode_health(segment.metadata, truncated=segment.truncated)
            for segment in primary
        ]
        failures = []
        for segment, health in zip(primary, primary_health):
            if health["failed"]:
                reasons = [
                    f"{item['source']}={item['value']}"
                    for item in health["finish_reasons"]
                    if item["value"] in ("repetition", "length")
                ] + [f"{source}=true" for source in health["truncation_sources"]]
                failures.append(
                    f"{segment.id} [{segment.start:.3f}, {segment.end:.3f}]s "
                    + ", ".join(reasons)
                )
        recovery_decisions = []
        if failures:
            details = "; ".join(failures[:4])
            if len(failures) > 4:
                details += f"; +{len(failures) - 4} segments"
            if self.aligner is not None:
                raise PipelineError(f"Primary decode 未完整；自訂 aligner 不支援安全 recovery：{details}")
            try:
                recovery_decisions = build_primary_recovery_decisions(
                    primary, verifier, verifier_model=self._verifier_model
                )
            except PrimaryRecoveryError as exc:
                raise PipelineError(f"Primary decode 未完整；停止對齊：{details}; {exc}") from exc
        primary_dict = segments_to_dict(primary)
        verifier_dict = segments_to_dict(verifier)
        fingerprint_value: dict[str, Any] = {
            "policy": _component_policy(self.aligner, RECONCILIATION_POLICY_VERSION),
            "primary": _segment_fingerprint_values(primary),
            "primary_decode_health_policy": PRIMARY_DECODE_HEALTH_POLICY,
            "primary_decode_health": primary_health,
            "primary_recovery_policy": PRIMARY_RECOVERY_POLICY,
            "primary_recovery_decisions": recovery_decisions,
            "verifier": _segment_fingerprint_values(verifier),
            "vocabulary": list(self._vocabulary),
            "primary_model": self._primary_model,
            "verifier_model": self._verifier_model,
        }
        if self._accuracy_mode:
            if whisper is None:
                raise PipelineError("高準確模式缺少 Whisper transcript")
            fingerprint_value.update(
                {
                    "accuracy_mode": True,
                    "ensemble_policy": ENSEMBLE_POLICY_VERSION,
                    "arbiter_policy": ARBITER_POLICY_VERSION,
                    "arbiter_enabled": self._local_arbiter_enabled,
                    "arbiter_model": self._local_arbiter_model,
                    "arbiter_endpoint": self._local_arbiter_endpoint,
                    "whisper_model": self._whisper_model,
                    "whisper": _segment_fingerprint_values(whisper),
                }
            )
        alignment_fingerprint = _json_fingerprint(fingerprint_value)
        checkpoint_path = workspace / "alignment.json"
        checkpoint = _load_checkpoint(checkpoint_path)
        if checkpoint and checkpoint.get("fingerprint") == alignment_fingerprint:
            checkpoint_value = checkpoint.get("value")
            sealed = {
                "fingerprint": checkpoint.get("fingerprint"),
                "value": checkpoint_value,
            }
            seal = checkpoint.get("payload_sha256")
            if (
                isinstance(checkpoint_value, dict)
                and isinstance(seal, str)
                and hmac.compare_digest(seal, _json_fingerprint(sealed))
            ):
                self._begin_job_stage("alignment", resumed=True)
                self._checkpoint_job("reconciled", checkpoint_path)
                self._stage_progress(
                    "alignment", {"progress": 1.0, "resumed": True}, progress
                )
                return checkpoint_value
        self._check_cancel(cancelled)
        self._begin_job_stage("alignment")
        self._stage_progress("alignment", {"progress": 0.0}, progress)
        if self.aligner is None:
            recovery_by_id = {d["parent_id"]: d for d in recovery_decisions}
            consensus_primary = [s for s in primary if s.id not in recovery_by_id]
            consensus_verifier, consensus_whisper = verifier, whisper
            if recovery_decisions and self._accuracy_mode:
                # Preserve the original assign_once ambiguity boundary. Removing
                # a failed parent must not make a previously crossing secondary
                # eligible for a neighboring healthy parent.
                # Textless failed decodes still own their original audio core.
                # _core_segments drops empty text and cannot define ownership.
                original_cores = [
                    (round(s.start * 1000), round(s.end * 1000)) for s in primary
                ]

                def unambiguous_secondaries(values: list[TranscriptSegment]) -> list[TranscriptSegment]:
                    return [s for s in values if sum(
                        end_ms > round(s.start * 1000) and start_ms < round(s.end * 1000)
                        for start_ms, end_ms in original_cores
                    ) == 1]

                consensus_verifier = unambiguous_secondaries(verifier)
                consensus_whisper = unambiguous_secondaries(whisper or [])
            if self._accuracy_mode:
                from .alignment import reconcile_three_segments

                assert whisper is not None
                # First settle deterministic consensus without waking the
                # 12B local arbiter.  This preserves the memory gate while
                # avoiding an unnecessary Gemma model load when two ASR
                # engines already agree on every selectable segment.
                reconciled = reconcile_three_segments(
                    _core_segments(consensus_primary),
                    _core_segments(consensus_verifier),
                    _core_segments(consensus_whisper or []),
                    vocabulary=self._vocabulary,
                    arbiter=None,
                )
                arbiter_needed = any(
                    bool(item.ensemble_audit.get("requires_local_arbiter", False))
                    for item in reconciled
                )
                arbiter = None
                if self._local_arbiter_enabled and arbiter_needed:
                    if self._arbiter_lifecycle is not None:
                        lifecycle_event = self._arbiter_lifecycle.prepare_arbiter()
                        self._arbiter_lifecycle_audit.append(dict(lifecycle_event))
                        if lifecycle_event.get("status") in {
                            "loaded",
                            "already_loaded",
                        } and isinstance(lifecycle_event.get("api_model"), str):
                            try:
                                arbiter = self.arbiter_factory(
                                    endpoint=self._local_arbiter_endpoint,
                                    model=str(lifecycle_event["api_model"]),
                                )
                            except Exception:
                                self._arbiter_lifecycle_audit.append(
                                    {
                                        "status": "arbiter_initialization_failed",
                                        "model": self._local_arbiter_model,
                                    }
                                )
                elif self._local_arbiter_enabled:
                    self._arbiter_lifecycle_audit.append(
                        {
                            "status": "not_needed",
                            "reason": "all_segments_deterministically_resolved",
                            "model": self._local_arbiter_model,
                        }
                    )
                try:
                    if arbiter is not None:
                        reconciled = reconcile_three_segments(
                            _core_segments(consensus_primary),
                            _core_segments(consensus_verifier),
                            _core_segments(consensus_whisper or []),
                            vocabulary=self._vocabulary,
                            arbiter=arbiter,
                        )
                finally:
                    if self._arbiter_lifecycle is not None:
                        try:
                            event = dict(self._arbiter_lifecycle.release())
                        except Exception:
                            event = {
                                "status": "release_failed",
                                "model": self._local_arbiter_model,
                            }
                        self._arbiter_lifecycle_audit.append(event)
                        self._arbiter_lifecycle_released = event.get("status") in {
                            "unloaded",
                            "already_unloaded",
                        }
            else:
                from .alignment import reconcile_segments

                reconciled = reconcile_segments(
                    _core_segments(consensus_primary),
                    _core_segments(verifier),
                    vocabulary=self._vocabulary,
                )
            if recovery_decisions:
                ordinary = iter(reconciled)
                reconciled = tuple(
                    recovery_segment(recovery_by_id[s.id]) if s.id in recovery_by_id else next(ordinary)
                    for s in primary if s.id in recovery_by_id or s.text.strip()
                )
            metadata: dict[str, Any] = {
                "primary": primary_dict,
                "verifier": verifier_dict,
            }
            if recovery_decisions:
                metadata["primary_recovery"] = {
                    "policy_version": PRIMARY_RECOVERY_POLICY, "decisions": recovery_decisions,
                    "original_primary_preserved": True, "consensus": False,
                    "review_required": True, "accuracy_verified": False,
                }
            if isinstance(getattr(self, "_primary_model_fallback", None), dict):
                metadata["primary_model_selection"] = dict(
                    self._primary_model_fallback
                )
            if self._accuracy_mode:
                metadata.update(
                    {
                        "whisper": segments_to_dict(whisper or []),
                        "ensemble": {
                            "policy_version": ENSEMBLE_POLICY_VERSION,
                            "kind": "heterogeneous_asr_late_fusion",
                            "not_neural_moe": True,
                            "not_cross_validation": True,
                            "local_arbiter_requested": self._local_arbiter_requested,
                            "local_arbiter_enabled": self._local_arbiter_enabled,
                            "local_arbiter_model": self._local_arbiter_model,
                            "lifecycle": list(self._arbiter_lifecycle_audit),
                            "free_text_generation_allowed": False,
                        },
                    }
                )
            value = {
                "media_path": self._media_path,
                "text": "".join(item.text for item in reconciled),
                "segments": [item.to_dict() for item in reconciled],
                "language": "Cantonese",
                "model_primary": self._primary_model,
                "model_verifier": self._verifier_model,
                "vocabulary": list(self._vocabulary),
                "metadata": metadata,
                "duration": self._duration,
                "processing_started_at": self._processing_started_at,
                "version": 1,
            }
            if self._accuracy_mode:
                value["model_whisper"] = self._whisper_model
                value["accuracy_mode"] = True
        else:
            if self._accuracy_mode:
                raise PipelineError("高準確模式唔支援自訂 aligner")
            value = self.aligner.reconcile(
                primary=primary_dict,
                verifier=verifier_dict,
                vocabulary=list(self._vocabulary),
            )
            value = dict(value)
            value["model_primary"] = self._primary_model
            value["model_verifier"] = self._verifier_model
            value["vocabulary"] = list(self._vocabulary)
        sealed = {"fingerprint": alignment_fingerprint, "value": value}
        _atomic_json(
            checkpoint_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )
        self._checkpoint_job("reconciled", checkpoint_path)
        self._stage_progress("alignment", {"progress": 1.0}, progress)
        return value

    def _diarization(
        self,
        workspace: Path,
        alignment: dict[str, Any],
        *,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> dict[str, Any]:
        """Attach anonymous speaker turns after ASR consensus, before HK conversion."""
        if not self._speaker_diarization_enabled:
            value = dict(alignment)
            metadata = dict(value.get("metadata", {}))
            metadata["diarization"] = {
                "enabled": False,
                "anonymous_labels": True,
                "reason": "disabled in settings",
            }
            value["metadata"] = metadata
            return value
        if not self._diarization_audio_path:
            # Injectable/unit-test pipelines do not always have the extracted WAV.
            value = dict(alignment)
            metadata = dict(value.get("metadata", {}))
            metadata["diarization"] = {
                "enabled": False,
                "anonymous_labels": True,
                "reason": "extracted audio path unavailable",
            }
            value["metadata"] = metadata
            return value
        self._check_cancel(cancelled)
        audio_path = Path(self._diarization_audio_path)
        if not audio_path.is_file():
            raise PipelineError(f"speaker diarization 音訊不存在：{audio_path}")

        # Sortformer is a fixed four-slot streaming model and is the measured
        # default for automatic / 1-4 speaker jobs.  The old clustering stack
        # remains available only when the user explicitly requests >4 people.
        use_sortformer = (
            self._speaker_num_speakers is None or self._speaker_num_speakers <= 4
        )
        helper_sha256: str | None = None
        diarizer: Any | None = None
        initialization_error: Exception | None = None
        required_model_files: dict[str, tuple[Path, tuple[Path, ...]]] = {}
        model_manifests: dict[str, str] = {}
        verify_model = getattr(self.models, "verify", None)

        def legacy_assets(*, required: bool) -> dict[str, Any] | None:
            segmentation_root = self.models.path_for(SPEAKER_SEGMENTATION_ID)
            embedding_root = self.models.path_for(SPEAKER_EMBEDDING_ID)
            model_segmentation = segmentation_root / "model.onnx"
            model_embedding = embedding_root / f"{SPEAKER_EMBEDDING_ID}.onnx"
            complete = (
                (segmentation_root / "manifest.json").is_file()
                and model_segmentation.is_file()
                and not model_segmentation.is_symlink()
                and (embedding_root / "manifest.json").is_file()
                and model_embedding.is_file()
                and not model_embedding.is_symlink()
            )
            if not complete:
                if required:
                    raise PipelineError(
                        "本機 speaker fallback models 未完整下載；"
                        "請到模型設定驗證或重新下載"
                    )
                return None
            if callable(verify_model):
                try:
                    verify_model(SPEAKER_SEGMENTATION_ID)
                    verify_model(SPEAKER_EMBEDDING_ID)
                except (ModelError, OSError, ValueError) as exc:
                    if required:
                        raise PipelineError(
                            f"本機 speaker fallback model 驗證失敗：{exc}"
                        ) from exc
                    logger.warning("Speaker CPU fallback model verification failed: %s", exc)
                    return None
            manifests = {
                "segmentation": _model_manifest_sha256(segmentation_root),
                "embedding": _model_manifest_sha256(embedding_root),
            }
            if not all(manifests.values()):
                if required:
                    raise PipelineError(
                        "本機 speaker fallback model manifest 缺失；請重新下載"
                    )
                return None
            return {
                "segmentation_root": segmentation_root,
                "embedding_root": embedding_root,
                "model_segmentation": model_segmentation,
                "model_embedding": model_embedding,
                "manifests": manifests,
            }

        legacy_fallback: dict[str, Any] | None = None

        if use_sortformer:
            engine = "fluid_audio_sortformer_coreml"
            model_root = self.models.path_for(SORTFORMER_COREML_ID)
            model_bundle = model_root / SORTFORMER_COREML_BUNDLE
            sortformer_files = tuple(
                model_root / relative for relative in SORTFORMER_COREML_FILES
            )
            if (
                not model_root.is_dir()
                or not (model_root / "manifest.json").is_file()
                or model_bundle.is_symlink()
                or not model_bundle.is_dir()
                or not all(path.is_file() and not path.is_symlink() for path in sortformer_files)
            ):
                raise PipelineError(
                    "Sortformer 講者模型未完整下載；請到模型設定驗證或重新下載"
                )
            if callable(verify_model):
                try:
                    verify_model(SORTFORMER_COREML_ID)
                except (ModelError, OSError, ValueError) as exc:
                    raise PipelineError(
                        f"Sortformer 講者模型驗證失敗：{exc}"
                    ) from exc
            sortformer_manifest = _model_manifest_sha256(model_root)
            if not sortformer_manifest:
                raise PipelineError("Sortformer 講者模型 manifest 缺失；請重新下載")
            required_model_files["sortformer"] = (model_root, sortformer_files)
            model_manifests["sortformer"] = sortformer_manifest
            legacy_fallback = legacy_assets(required=False)
            if legacy_fallback is not None:
                required_model_files.update(
                    {
                        "fallback_segmentation": (
                            legacy_fallback["segmentation_root"],
                            (legacy_fallback["model_segmentation"],),
                        ),
                        "fallback_embedding": (
                            legacy_fallback["embedding_root"],
                            (legacy_fallback["model_embedding"],),
                        ),
                    }
                )
                model_manifests.update(
                    {
                        "fallback_segmentation": legacy_fallback["manifests"]["segmentation"],
                        "fallback_embedding": legacy_fallback["manifests"]["embedding"],
                    }
                )
            factory = self.sortformer_diarizer_factory or SortformerCoreMLDiarizer
            kwargs: dict[str, Any] = {
                "run_directory": workspace / "sortformer-helper",
                "expected_speakers": self._speaker_num_speakers,
            }
            if self.sortformer_helper_path is not None:
                kwargs["helper_path"] = self.sortformer_helper_path
            try:
                diarizer = factory(model_bundle, **kwargs)
                helper_sha256 = str(getattr(diarizer, "helper_sha256", ""))
                if len(helper_sha256) != 64:
                    raise DiarizationError(
                        "Sortformer helper identity 無法驗證；請重新 build／安裝 App"
                    )
            except (DiarizationError, OSError, ValueError) as exc:
                # Runtime construction failure is recoverable when the local
                # sherpa CPU stack is present.  Record it below and start the
                # fallback from a fresh instance; never mix partial outputs.
                initialization_error = exc
                diarizer = None
                helper_sha256 = None
            policy = {
                **_callable_policy(factory, DIARIZATION_POLICY_VERSION),
                "engine": engine,
                "version": DIARIZATION_POLICY_VERSION,
                "model": SORTFORMER_COREML_ID,
                "variant": "highContextV2_1",
                "precision": "palettized",
                "compute_units": "cpuAndGPU",
                "fixed_speaker_slots": "4",
                "streaming_state": "continuous_across_disk_chunks",
                "short_input_policy": "bounded_trailing_silence_then_crop",
                "extra_expected_slot_policy": "omit_to_unknown_never_merge_guess",
                "assignment": "maximum_overlap_then_nearest_750ms",
                "runtime_fallback": {
                    "engine": "sherpa_onnx_legacy_clustering",
                    "provider": "cpu",
                    "available": legacy_fallback is not None,
                    "attempt_limit": 1,
                },
            }
            model_metadata = {
                "model": SORTFORMER_COREML_ID,
                "model_bundle": str(model_bundle),
                "helper_sha256": helper_sha256,
            }
            turns_model_name = (
                "FluidAudio Sortformer high-context v2.1 palettized Core ML"
            )
        else:
            engine = "sherpa_onnx_legacy_clustering"
            legacy_fallback = legacy_assets(required=True)
            assert legacy_fallback is not None
            segmentation_root = legacy_fallback["segmentation_root"]
            embedding_root = legacy_fallback["embedding_root"]
            model_segmentation = legacy_fallback["model_segmentation"]
            model_embedding = legacy_fallback["model_embedding"]
            required_model_files = {
                "segmentation": (segmentation_root, (model_segmentation,)),
                "embedding": (embedding_root, (model_embedding,)),
            }
            model_manifests = dict(legacy_fallback["manifests"])
            factory = self.legacy_diarizer_factory or SherpaOfflineDiarizer
            policy = {
                **_callable_policy(factory, DIARIZATION_POLICY_VERSION),
                "engine": engine,
                "version": DIARIZATION_POLICY_VERSION,
                "num_threads": "2",
                "threshold": "0.9",
                "routing": "explicit_requested_speaker_count_above_four_only",
                "automatic_consolidation": "complete_link_clear_elbow_with_overlap_guard",
                "automatic_consolidation_overlap_guard_ms": "100",
                "assignment": "maximum_overlap_then_nearest_750ms",
            }
            try:
                diarizer = factory(
                    model_segmentation,
                    model_embedding,
                    num_threads=2,
                    num_speakers=self._speaker_num_speakers,
                )
            except (DiarizationError, OSError, ValueError) as exc:
                initialization_error = exc
                diarizer = None
            model_metadata = {
                "model_segmentation": str(model_segmentation),
                "model_embedding": str(model_embedding),
            }
            turns_model_name = "sherpa-onnx legacy offline speaker diarization"

        fingerprint = _json_fingerprint(
            {
                "schema": 1,
                "audio": _file_fingerprint_value(audio_path),
                "alignment": alignment,
                "policy": policy,
                "engine": engine,
                "model_manifests": model_manifests,
                "helper_sha256": helper_sha256,
                "settings": {
                    "speaker_diarization_enabled": True,
                    "speaker_num_speakers": self._speaker_num_speakers,
                },
            }
        )
        checkpoint_path = workspace / "diarization.json"
        checkpoint = _load_checkpoint(checkpoint_path)
        if checkpoint and checkpoint.get("fingerprint") == fingerprint:
            stored_manifests = checkpoint.get("model_manifests")
            checkpoint_value = checkpoint.get("value")
            sealed = {
                "fingerprint": checkpoint.get("fingerprint"),
                "model_manifests": stored_manifests,
                "helper_sha256": checkpoint.get("helper_sha256"),
                "policy": checkpoint.get("policy"),
                "value": checkpoint_value,
            }
            seal = checkpoint.get("payload_sha256")
            semantic_match = False
            if isinstance(checkpoint_value, dict):
                saved_segments = checkpoint_value.get("segments")
                current_segments = alignment.get("segments", ())
                if (
                    isinstance(saved_segments, list)
                    and isinstance(current_segments, (list, tuple))
                    and len(saved_segments) == len(current_segments)
                ):
                    # Speaker fields may be added, but every fresh alignment
                    # field (especially timing/text/chosen_text) must survive
                    # byte-for-byte in the resumed value.
                    semantic_match = all(
                        isinstance(saved, dict)
                        and isinstance(current, dict)
                        and all(saved.get(key) == value for key, value in current.items())
                        for saved, current in zip(saved_segments, current_segments)
                    )
            manifests_match = isinstance(stored_manifests, dict) and all(
                _strict_installed_manifest_matches(
                    stored_sha256=str(stored_manifests.get(name, "")),
                    model_path=root,
                    required_files=files,
                )
                for name, (root, files) in required_model_files.items()
            )
            helper_match = (
                checkpoint.get("helper_sha256") == helper_sha256
                and (helper_sha256 is None or len(helper_sha256) == 64)
            )
            if (
                checkpoint.get("policy") == policy
                and isinstance(seal, str)
                and hmac.compare_digest(seal, _json_fingerprint(sealed))
                and semantic_match
                and manifests_match
                and helper_match
            ):
                value = dict(alignment)
                value["segments"] = checkpoint_value["segments"]
                metadata = dict(value.get("metadata", {}))
                saved_metadata = checkpoint_value.get("metadata", {})
                if isinstance(saved_metadata, dict) and isinstance(
                    saved_metadata.get("diarization"), dict
                ):
                    metadata["diarization"] = dict(saved_metadata["diarization"])
                    metadata["diarization_degraded"] = bool(
                        saved_metadata.get("diarization_degraded", False)
                    )
                value["metadata"] = metadata
                self._stage_progress(
                    "alignment",
                    {
                        "phase": "speaker_diarization",
                        "progress": 1.0,
                        "resumed": True,
                    },
                    progress,
                )
                return value
        self._begin_job_stage("alignment")
        self._stage_progress("alignment", {"phase": "speaker_diarization", "progress": 0.0}, progress)
        attempted_engines: list[str] = []
        failure_reasons: list[dict[str, str]] = []
        actual_engine: str | None = None
        actual_diarizer: Any | None = None
        actual_model_metadata: dict[str, Any] = {}
        actual_turns_model_name = "speaker diarization unavailable"
        turns: tuple[Any, ...] = ()

        def bounded_failure(exc: Exception) -> str:
            message = " ".join(str(exc).split())
            if not message:
                message = type(exc).__name__
            return message[-500:]

        def record_failure(candidate_engine: str, exc: Exception) -> None:
            failure_reasons.append(
                {
                    "engine": candidate_engine,
                    "error_type": type(exc).__name__,
                    "message": bounded_failure(exc),
                }
            )
            logger.exception(
                "Local speaker diarization candidate failed: %s",
                candidate_engine,
                exc_info=(type(exc), exc, exc.__traceback__),
            )

        def run_candidate(candidate_engine: str, candidate: Any) -> tuple[Any, ...] | None:
            attempted_engines.append(candidate_engine)
            try:
                result = candidate.diarize_wav(
                    audio_path,
                    progress=lambda event: self._stage_progress(
                        "alignment",
                        {
                            **dict(event),
                            "engine": candidate_engine,
                            "fallback": candidate_engine != engine,
                        },
                        progress,
                    ),
                    cancelled=cancelled,
                )
                return tuple(result)
            except DiarizationCancelled as exc:
                raise PipelineCancelled(str(exc)) from exc
            except PipelineCancelled:
                raise
            except Exception as exc:
                # Some native sherpa cancellation paths historically surfaced
                # as a generic runtime error.  Re-check the durable cancel
                # signal before considering any fallback.
                self._check_cancel(cancelled)
                record_failure(candidate_engine, exc)
                return None

        if initialization_error is not None:
            attempted_engines.append(engine)
            record_failure(engine, initialization_error)
        elif diarizer is not None:
            candidate_turns = run_candidate(engine, diarizer)
            if candidate_turns is not None:
                turns = candidate_turns
                actual_engine = engine
                actual_diarizer = diarizer
                actual_model_metadata = dict(model_metadata)
                actual_turns_model_name = turns_model_name

        # Sortformer is the precision-first path for <=4 speakers.  If its
        # fresh Core ML run fails, create a wholly separate sherpa CPU instance
        # and start again from the source WAV.  Each route is attempted once.
        if actual_engine is None and use_sortformer and legacy_fallback is not None:
            self._check_cancel(cancelled)
            fallback_engine = "sherpa_onnx_legacy_clustering"
            fallback_factory = self.legacy_diarizer_factory or SherpaOfflineDiarizer
            try:
                fallback_diarizer = fallback_factory(
                    legacy_fallback["model_segmentation"],
                    legacy_fallback["model_embedding"],
                    num_threads=2,
                    num_speakers=self._speaker_num_speakers,
                )
            except DiarizationCancelled as exc:
                raise PipelineCancelled(str(exc)) from exc
            except Exception as exc:
                self._check_cancel(cancelled)
                attempted_engines.append(fallback_engine)
                record_failure(fallback_engine, exc)
            else:
                fallback_turns = run_candidate(fallback_engine, fallback_diarizer)
                if fallback_turns is not None:
                    turns = fallback_turns
                    actual_engine = fallback_engine
                    actual_diarizer = fallback_diarizer
                    actual_model_metadata = {
                        "model_segmentation": str(
                            legacy_fallback["model_segmentation"]
                        ),
                        "model_embedding": str(legacy_fallback["model_embedding"]),
                    }
                    actual_turns_model_name = (
                        "sherpa-onnx legacy offline speaker diarization"
                    )

        raw_segments = list(alignment.get("segments", ()))
        speaker_values = assign_speakers(raw_segments, turns)
        segments = []
        for raw, speaker in zip(raw_segments, speaker_values):
            item = dict(raw)
            item.update(speaker)
            segments.append(item)
        metadata = dict(alignment.get("metadata", {}))
        fallback_used = actual_engine is not None and actual_engine != engine
        degraded = actual_engine is None
        if degraded:
            status = "degraded"
        elif fallback_used:
            status = "completed_with_fallback"
        else:
            status = "completed"
        diarization_metadata: dict[str, Any] = {
            "requested": True,
            "enabled": not degraded,
            "status": status,
            "degraded": degraded,
            "reason_code": "all_local_diarizers_failed" if degraded else None,
            "warning": (
                "字幕已完成，但今次未能產生可靠講者標籤；可保留字幕，之後重新轉錄或喺字幕編輯器手動覆核。"
                if degraded
                else (
                    "講者分析已自動使用本機 CPU 兼容模式完成。"
                    if fallback_used
                    else None
                )
            ),
            "anonymous_labels": True,
            "engine": actual_engine,
            "preferred_engine": engine,
            "attempted_engines": attempted_engines,
            "fallback_used": fallback_used,
            "failure_reasons": failure_reasons,
            **actual_model_metadata,
            "num_speakers": len({turn.speaker_index for turn in turns}),
            "turn_count": len(turns),
            "speaker_num_speakers_requested": self._speaker_num_speakers,
            "clustering_diagnostics": dict(
                getattr(actual_diarizer, "last_diagnostics", {})
            ),
        }
        metadata["diarization"] = diarization_metadata
        metadata["diarization_degraded"] = degraded
        value = dict(alignment)
        value["segments"] = segments
        value["metadata"] = metadata
        checkpoint_value = {"segments": segments, "metadata": metadata}
        sealed = {
            "fingerprint": fingerprint,
            "model_manifests": model_manifests,
            "helper_sha256": helper_sha256,
            "policy": policy,
            "value": checkpoint_value,
        }
        _atomic_json(
            checkpoint_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )
        write_turns(
            workspace / "diarization-turns.json",
            turns,
            model=actual_turns_model_name,
        )
        self._stage_progress("alignment", {"phase": "speaker_diarization", "progress": 1.0}, progress)
        return value

    def _final(
        self, workspace: Path, alignment: dict[str, Any], *, progress: Progress | None, cancelled: Cancelled | None
    ) -> dict[str, Any]:
        final_fingerprint = _json_fingerprint(
            {
                "policy": _component_policy(self.normalizer, HK_NORMALIZATION_POLICY_VERSION),
                "alignment": alignment,
                "vocabulary": list(self._vocabulary),
                "correction_memory_policy": CORRECTION_MEMORY_POLICY_VERSION,
                "correction_memory_entries": [
                    entry.to_json() for entry in self._correction_memory_entries
                ],
            }
        )
        checkpoint_path = workspace / "final.json"
        checkpoint = _load_checkpoint(checkpoint_path)
        if checkpoint and checkpoint.get("fingerprint") == final_fingerprint:
            checkpoint_value = checkpoint.get("value")
            sealed = {
                "fingerprint": checkpoint.get("fingerprint"),
                "value": checkpoint_value,
            }
            seal = checkpoint.get("payload_sha256")
            if (
                isinstance(checkpoint_value, dict)
                and isinstance(seal, str)
                and hmac.compare_digest(seal, _json_fingerprint(sealed))
            ):
                self._begin_job_stage("final", resumed=True)
                self._checkpoint_job("normalized", checkpoint_path)
                self._stage_progress(
                    "final", {"progress": 1.0, "resumed": True}, progress
                )
                value = self._enrich_document(checkpoint_value)
                if value != checkpoint_value:
                    rewritten = {"fingerprint": final_fingerprint, "value": value}
                    _atomic_json(
                        checkpoint_path,
                        {
                            "schema": 1,
                            "complete": True,
                            **rewritten,
                            "payload_sha256": _json_fingerprint(rewritten),
                        },
                    )
                return value
        self._check_cancel(cancelled)
        self._begin_job_stage("final")
        self._stage_progress("final", {"progress": 0.0}, progress)
        if self.normalizer is None:
            from .normalization import normalize_document

            value = normalize_document(_document_from_dict(alignment)).to_dict()
        else:
            value = self.normalizer.normalize(alignment)
        value = self._apply_correction_memory(value)
        value = self._enrich_document(value)
        sealed = {"fingerprint": final_fingerprint, "value": value}
        _atomic_json(
            checkpoint_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )
        self._checkpoint_job("normalized", checkpoint_path)
        self._stage_progress("final", {"progress": 1.0}, progress)
        return value

    def _apply_correction_memory(self, value: dict[str, Any]) -> dict[str, Any]:
        """Apply only approved exact aliases after HK normalization.

        Primary/verifier hypotheses remain untouched for audit.  The final text,
        chosen segment text and segment text change together so subtitle timing
        continues to refer to the exact transcript exported to the user.
        """

        output = dict(value)
        entries: tuple[CorrectionEntry, ...] = self._correction_memory_entries
        metadata = dict(output.get("metadata", {}))
        if not entries:
            metadata["correction_memory"] = {
                "policy_version": CORRECTION_MEMORY_POLICY_VERSION,
                "local_only": True,
                "entry_count": 0,
                "applied_count": 0,
                "changes": [],
            }
            output["metadata"] = metadata
            return output

        raw_segments = output.get("segments")
        segments: list[dict[str, Any]] = []
        changes: list[dict[str, object]] = []
        original_parts: list[str] = []
        corrected_parts: list[str] = []
        source_offset = 0
        output_offset = 0
        if isinstance(raw_segments, list):
            for index, raw in enumerate(raw_segments):
                if not isinstance(raw, Mapping):
                    raise PipelineError("normalized segment 無效")
                segment = dict(raw)
                original = str(segment.get("text", segment.get("chosen_text", "")))
                corrected, segment_audit = apply_approved_corrections(original, entries)
                original_parts.append(original)
                corrected_parts.append(corrected)
                segment["text"] = corrected
                if "chosen_text" in segment:
                    segment["chosen_text"] = corrected
                if segment_audit:
                    segment["correction_memory_audit"] = list(segment_audit)
                for item in segment_audit:
                    change = dict(item)
                    change.update(
                        {
                            "segment_index": index,
                            "source_start_global": source_offset + int(item["source_start"]),
                            "source_end_global": source_offset + int(item["source_end"]),
                            "output_start_global": output_offset + int(item["output_start"]),
                            "output_end_global": output_offset + int(item["output_end"]),
                        }
                    )
                    changes.append(change)
                source_offset += len(original)
                output_offset += len(corrected)
                segments.append(segment)

        source_text = str(output.get("final_transcript", output.get("text", "")))
        if segments and "".join(original_parts) != source_text:
            metadata["correction_memory"] = {
                "policy_version": CORRECTION_MEMORY_POLICY_VERSION,
                "local_only": True,
                "entry_count": len(entries),
                "applied_count": 0,
                "changes": [],
                "skipped_reason": "document_segment_text_mismatch",
            }
            output["metadata"] = metadata
            return output
        if segments:
            corrected_text = "".join(corrected_parts)
        else:
            corrected_text, whole_audit = apply_approved_corrections(source_text, entries)
            changes = [dict(item) for item in whole_audit]

        if segments:
            output["segments"] = segments
        output["final_transcript"] = corrected_text
        output["text"] = corrected_text
        metadata["correction_memory"] = {
            "policy_version": CORRECTION_MEMORY_POLICY_VERSION,
            "local_only": True,
            "entry_count": len(entries),
            "applied_count": len(changes),
            "changes": changes,
        }
        output["metadata"] = metadata
        return output

    @staticmethod
    def _timestamp_input(final: dict[str, Any]) -> dict[str, Any]:
        """Return only normalization-owned data for a stable timestamp hash."""

        value = {
            key: item
            for key, item in final.items()
            if key
            not in {
                "subtitle_segments",
                "word_timestamps",
                "character_timestamps",
                # This field is owned by the timestamp stage itself.  Excluding
                # it keeps the semantic fingerprint stable across restart.
                "processing_completed_at",
            }
        }
        metadata = dict(value.get("metadata", {}))
        metadata.pop("forced_timestamps", None)
        value["metadata"] = metadata
        return value

    @staticmethod
    def _fine_subtitle_segments(
        cues: Sequence[dict[str, Any]],
        raw_segments: Sequence[dict[str, Any]],
        *,
        method: str,
        speaker_turns: Sequence[Any] = (),
    ) -> list[dict[str, Any]]:
        ranges: list[tuple[int, int, int, dict[str, Any]]] = []
        cursor = 0
        for index, raw in enumerate(raw_segments):
            text = str(raw.get("text", raw.get("chosen_text", "")))
            end = cursor + len(text)
            ranges.append((cursor, end, index, raw))
            cursor = end

        precise_speakers = (
            assign_speakers(cues, speaker_turns) if speaker_turns else ()
        )
        output: list[dict[str, Any]] = []
        for cue_index, cue in enumerate(cues, start=1):
            source_start = int(cue["source_start"])
            source_end = int(cue["source_end"])
            overlaps: list[tuple[int, int, dict[str, Any]]] = []
            for range_start, range_end, segment_index, raw in ranges:
                overlap = max(0, min(source_end, range_end) - max(source_start, range_start))
                if overlap:
                    overlaps.append((overlap, segment_index, raw))
            overlaps.sort(key=lambda item: (-item[0], item[1]))
            source_indices = tuple(sorted(item[1] for item in overlaps))
            start_ms = int(cue["start_ms"])
            end_ms = max(start_ms + 1, int(cue["end_ms"]))
            temporal_overlaps: list[tuple[int, int, int, dict[str, Any]]] = []
            character_overlap_by_index = {item[1]: item[0] for item in overlaps}
            for segment_index, raw in enumerate(raw_segments):
                try:
                    segment_start = int(raw["start_ms"])
                    segment_end = int(raw["end_ms"])
                except (KeyError, TypeError, ValueError):
                    continue
                temporal = max(0, min(end_ms, segment_end) - max(start_ms, segment_start))
                if temporal:
                    temporal_overlaps.append(
                        (
                            temporal,
                            character_overlap_by_index.get(segment_index, 0),
                            segment_index,
                            raw,
                        )
                    )
            temporal_overlaps.sort(key=lambda item: (-item[0], -item[1], item[2]))
            dominant = (
                temporal_overlaps[0][3]
                if temporal_overlaps
                else overlaps[0][2]
                if overlaps
                else {}
            )
            confidences = [
                float(item[2]["confidence"])
                for item in overlaps
                if item[2].get("confidence") is not None
            ]
            speaker_sources = (
                [item[3] for item in temporal_overlaps]
                if temporal_overlaps
                else [item[2] for item in overlaps]
            )
            labels = tuple(
                dict.fromkeys(
                    str(item.get("speaker_label"))
                    for item in speaker_sources
                    if item.get("speaker_label") not in {None, "", "Unknown"}
                )
            )
            precise_speaker = (
                precise_speakers[cue_index - 1] if precise_speakers else None
            )
            if precise_speaker is not None:
                labels = tuple(
                    str(item)
                    for item in precise_speaker.get("speaker_labels", ())
                    if item
                )
            start_ms, end_ms = _adjust_wenet_display_cue(
                start_ms,
                end_ms,
                method=method,
            )
            low_confidence = any(
                bool(
                    (item[2].get("audit") or {}).get(
                        "low_confidence", item[2].get("low_confidence", False)
                    )
                )
                for item in overlaps
            )
            timed = TimedSubtitleSegment(
                id=f"cue-{cue_index:06d}",
                start_ms=start_ms,
                end_ms=end_ms,
                text=str(cue.get("text", "")),
                source_start=source_start,
                source_end=source_end,
                source_segment_index=(overlaps[0][1] if overlaps else None),
                source_segment_indices=source_indices,
                confidence=min(confidences) if confidences else None,
                low_confidence=low_confidence,
                method=method,
                speaker_index=(
                    int(precise_speaker["speaker_index"])
                    if precise_speaker is not None
                    and precise_speaker.get("speaker_index") is not None
                    else int(dominant["speaker_index"])
                    if dominant.get("speaker_index") is not None
                    else None
                ),
                speaker_id=(
                    str(precise_speaker["speaker_id"])
                    if precise_speaker is not None
                    and precise_speaker.get("speaker_id") is not None
                    else str(dominant["speaker_id"])
                    if dominant.get("speaker_id") is not None
                    else None
                ),
                speaker_label=(
                    str(precise_speaker["speaker_label"])
                    if precise_speaker is not None
                    and precise_speaker.get("speaker_label") is not None
                    else str(dominant["speaker_label"])
                    if dominant.get("speaker_label") is not None
                    else None
                ),
                speaker_labels=labels,
                speaker_overlap=(
                    bool(precise_speaker.get("speaker_overlap", False))
                    if precise_speaker is not None
                    else len(labels) > 1
                    or any(bool(item.get("speaker_overlap", False)) for item in speaker_sources)
                ),
            )
            output.append(timed.to_dict())
        return output

    @staticmethod
    def _write_timestamped_final(
        workspace: Path,
        final: dict[str, Any],
    ) -> None:
        final_path = workspace / "final.json"
        envelope = _load_checkpoint(final_path)
        if envelope is None:
            raise PipelineError("final.json checkpoint 唔完整，無法加入精細時間碼")
        sealed = {
            "fingerprint": envelope.get("fingerprint"),
            "value": final,
        }
        _atomic_json(
            final_path,
            {
                "schema": 1,
                "complete": True,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )

    @staticmethod
    def _validate_timestamp_payload(
        payload: dict[str, Any],
        *,
        final_text: str,
        duration_ms: int,
        chunk_ids: set[str],
        coarse_segment_count: int,
    ) -> None:
        if set(payload) != {
            "subtitle_segments",
            "word_timestamps",
            "character_timestamps",
            "audit",
        }:
            raise ValueError("timestamps checkpoint schema 無效")
        audit = payload.get("audit")
        expected_audit_fields = {
            "method",
            "model",
            "policy_version",
            "cue_policy",
            "fallback_reasons",
            "chunks",
            "cue_count",
            "word_count",
            "character_count",
            "timing_source_summary",
            "alignment_fallback_chunk_count",
            "adjustments",
            "fallback_semantics",
            "alignment_windows",
            "wenet_timing_backbone",
        }
        if not isinstance(audit, dict) or set(audit) != expected_audit_fields:
            raise ValueError("timestamps audit schema 無效")
        if (
            audit.get("model") != QWEN_ALIGNER_ID
            or audit.get("policy_version") != FORCED_TIMESTAMP_POLICY_VERSION
            or not isinstance(audit.get("method"), str)
            or not isinstance(audit.get("cue_policy"), str)
        ):
            raise ValueError("timestamps audit identity 無效")
        wenet_timing = audit.get("wenet_timing_backbone")
        required_wenet_fields = {
            "policy_version",
            "model",
            "applied",
            "transcript_text_changed",
            "timing_review_required",
            "display_cue_adjustment",
        }
        if (
            not isinstance(wenet_timing, dict)
            or not required_wenet_fields.issubset(wenet_timing)
            or wenet_timing.get("policy_version") != WENET_TIMING_POLICY_VERSION
            or wenet_timing.get("model") != WENET_TIMING_MODEL
            or not isinstance(wenet_timing.get("applied"), bool)
            or wenet_timing.get("transcript_text_changed") is not False
            or not isinstance(wenet_timing.get("timing_review_required"), bool)
        ):
            raise ValueError("Wenet timing audit 無效")
        display_cue_adjustment = wenet_timing.get("display_cue_adjustment")
        expected_display_cue_adjustment = _wenet_display_cue_adjustment(
            "+wenet_ctc_anchor_retime" if wenet_timing["applied"] else ""
        )
        if display_cue_adjustment != expected_display_cue_adjustment:
            raise ValueError("Wenet display cue adjustment audit 無效")
        if wenet_timing["applied"]:
            anchored_count = wenet_timing.get("anchored_character_count")
            if (
                isinstance(anchored_count, bool)
                or not isinstance(anchored_count, int)
                or anchored_count <= 0
            ):
                raise ValueError("Wenet timing anchor count 無效")

        cues = payload.get("subtitle_segments")
        if not isinstance(cues, list):
            raise ValueError("subtitle_segments 必須係 array")
        source_cursor = 0
        previous_end_ms = 0
        cue_text: list[str] = []
        for index, cue in enumerate(cues):
            if not isinstance(cue, dict):
                raise ValueError(f"subtitle cue {index} 無效")
            source_start = cue.get("source_start")
            source_end = cue.get("source_end")
            start_ms = cue.get("start_ms")
            end_ms = cue.get("end_ms")
            if any(
                isinstance(item, bool) or not isinstance(item, int)
                for item in (source_start, source_end, start_ms, end_ms)
            ):
                raise ValueError(f"subtitle cue {index} range 無效")
            assert isinstance(source_start, int)
            assert isinstance(source_end, int)
            assert isinstance(start_ms, int)
            assert isinstance(end_ms, int)
            if source_start != source_cursor or not source_start < source_end <= len(final_text):
                raise ValueError(f"subtitle cue {index} source range 唔連續")
            text = cue.get("text")
            if not isinstance(text, str) or text != final_text[source_start:source_end]:
                raise ValueError(f"subtitle cue {index} text 同 final transcript 唔一致")
            if start_ms < previous_end_ms or end_ms <= start_ms or end_ms > duration_ms:
                raise ValueError(f"subtitle cue {index} timestamp 唔單調")
            source_indices = cue.get("source_segment_indices", ())
            if not isinstance(source_indices, (list, tuple)) or any(
                isinstance(item, bool)
                or not isinstance(item, int)
                or not 0 <= item < coarse_segment_count
                for item in source_indices
            ):
                raise ValueError(f"subtitle cue {index} source segment refs 無效")
            confidence = cue.get("confidence")
            if confidence is not None and (
                isinstance(confidence, bool)
                or not isinstance(confidence, (int, float))
                or not math.isfinite(float(confidence))
                or not 0 <= float(confidence) <= 1
            ):
                raise ValueError(f"subtitle cue {index} confidence 無效")
            source_cursor = source_end
            previous_end_ms = end_ms
            cue_text.append(text)
        if source_cursor != len(final_text) or "".join(cue_text) != final_text:
            raise ValueError("subtitle cues 未完整覆蓋 final transcript")

        words = payload.get("word_timestamps")
        if not isinstance(words, list):
            raise ValueError("word_timestamps 必須係 array")
        _validate_word_source_coverage(words, final_text)
        previous_word_end = 0
        previous_source_end = 0
        for index, word in enumerate(words):
            if not isinstance(word, dict):
                raise ValueError(f"word timestamp {index} 無效")
            source_start = word.get("source_start")
            source_end = word.get("source_end")
            start_ms = word.get("start_ms")
            end_ms = word.get("end_ms")
            if any(
                isinstance(item, bool) or not isinstance(item, int)
                for item in (source_start, source_end, start_ms, end_ms)
            ):
                raise ValueError(f"word timestamp {index} range 無效")
            assert isinstance(source_start, int)
            assert isinstance(source_end, int)
            assert isinstance(start_ms, int)
            assert isinstance(end_ms, int)
            if not 0 <= source_start < source_end <= len(final_text):
                raise ValueError(f"word timestamp {index} source range 無效")
            if source_start < previous_source_end:
                raise ValueError(f"word timestamp {index} source range 無效")
            word_text = word.get("text")
            if not isinstance(word_text, str) or word_text != final_text[source_start:source_end]:
                raise ValueError(f"word timestamp {index} text 無效")
            if start_ms < previous_word_end or end_ms <= start_ms or end_ms > duration_ms:
                raise ValueError(f"word timestamp {index} 唔單調")
            if word.get("chunk_id") not in chunk_ids:
                raise ValueError(f"word timestamp {index} chunk id 無效")
            previous_source_end = source_end
            previous_word_end = end_ms

        characters = payload.get("character_timestamps")
        if not isinstance(characters, list) or len(characters) != len(final_text):
            raise ValueError("character_timestamps 未完整覆蓋 transcript")
        previous_character_end = 0
        for index, character in enumerate(characters):
            if not isinstance(character, dict) or character.get("source_index") != index:
                raise ValueError(f"character timestamp {index} source index 無效")
            if character.get("text") != final_text[index : index + 1]:
                raise ValueError(f"character timestamp {index} text 無效")
            start_ms = character.get("start_ms")
            end_ms = character.get("end_ms")
            if (
                isinstance(start_ms, bool)
                or not isinstance(start_ms, int)
                or isinstance(end_ms, bool)
                or not isinstance(end_ms, int)
                or start_ms < previous_character_end
                or end_ms < start_ms
                or end_ms > duration_ms
                or character.get("chunk_id") not in chunk_ids
            ):
                raise ValueError(f"character timestamp {index} range 無效")
            previous_character_end = end_ms

        def audit_int(value: Any, *, label: str) -> int:
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{label} 無效")
            return value

        raw_chunks = audit["chunks"]
        if not isinstance(raw_chunks, (list, tuple)) or len(raw_chunks) != len(
            chunk_ids
        ):
            raise ValueError("timestamps audit chunks 數量無效")
        chunk_fields = {
            "chunk_id",
            "method",
            "core_start_ms",
            "core_end_ms",
            "word_count",
            "character_count",
            "clipped_word_count",
            "window_clamped_word_count",
            "intra_block_monotonic_adjusted_word_count",
            "seam_adjusted_word_count",
            "max_window_clamp_ms",
            "max_intra_block_shift_ms",
            "max_seam_shift_ms",
            "raw_zero_duration_word_count",
            "quantization_repaired_word_count",
            "max_quantization_repair_ms",
            "zero_duration_word_count",
            "fallback_reason",
        }
        seen_chunk_ids: set[str] = set()
        fallback_reasons: list[str] = []
        fallback_count = 0
        adjustment_totals = {
            "unique_adjusted_word_count": 0,
            "window_clamped_word_count": 0,
            "intra_block_monotonic_adjusted_word_count": 0,
            "seam_adjusted_word_count": 0,
            "raw_zero_duration_word_count": 0,
            "quantization_repaired_word_count": 0,
            "max_window_clamp_ms": 0,
            "max_intra_block_shift_ms": 0,
            "max_seam_shift_ms": 0,
            "max_quantization_repair_ms": 0,
            "zero_duration_word_count": 0,
        }
        word_counts_by_chunk = {
            chunk_id: sum(word.get("chunk_id") == chunk_id for word in words)
            for chunk_id in chunk_ids
        }
        character_counts_by_chunk = {
            chunk_id: sum(
                character.get("chunk_id") == chunk_id for character in characters
            )
            for chunk_id in chunk_ids
        }
        for index, raw_chunk in enumerate(raw_chunks):
            if not isinstance(raw_chunk, dict) or set(raw_chunk) != chunk_fields:
                raise ValueError(f"timestamps audit chunk {index} schema 無效")
            chunk_id = raw_chunk["chunk_id"]
            if (
                not isinstance(chunk_id, str)
                or chunk_id not in chunk_ids
                or chunk_id in seen_chunk_ids
            ):
                raise ValueError(f"timestamps audit chunk {index} identity 無效")
            seen_chunk_ids.add(chunk_id)
            core_start = audit_int(
                raw_chunk["core_start_ms"], label=f"audit chunk {index} core_start"
            )
            core_end = audit_int(
                raw_chunk["core_end_ms"], label=f"audit chunk {index} core_end"
            )
            if core_end < core_start or core_end > duration_ms:
                raise ValueError(f"timestamps audit chunk {index} core range 無效")
            word_count = audit_int(
                raw_chunk["word_count"], label=f"audit chunk {index} word_count"
            )
            character_count = audit_int(
                raw_chunk["character_count"],
                label=f"audit chunk {index} character_count",
            )
            if (
                word_count != word_counts_by_chunk[chunk_id]
                or character_count != character_counts_by_chunk[chunk_id]
            ):
                raise ValueError(f"timestamps audit chunk {index} item counts 無效")
            category_counts = {
                name: audit_int(
                    raw_chunk[name], label=f"audit chunk {index} {name}"
                )
                for name in (
                    "window_clamped_word_count",
                    "intra_block_monotonic_adjusted_word_count",
                    "seam_adjusted_word_count",
                    "quantization_repaired_word_count",
                )
            }
            raw_zero_duration = audit_int(
                raw_chunk["raw_zero_duration_word_count"],
                label=f"audit chunk {index} raw_zero_duration_word_count",
            )
            clipped = audit_int(
                raw_chunk["clipped_word_count"],
                label=f"audit chunk {index} clipped_word_count",
            )
            if (
                clipped > word_count
                or any(value > word_count for value in category_counts.values())
                or raw_zero_duration > word_count
                or clipped < max(category_counts.values(), default=0)
                or clipped > sum(category_counts.values())
            ):
                raise ValueError(f"timestamps audit chunk {index} adjustment counts 無效")
            maxima = {
                name: audit_int(raw_chunk[name], label=f"audit chunk {index} {name}")
                for name in (
                    "max_window_clamp_ms",
                    "max_intra_block_shift_ms",
                    "max_seam_shift_ms",
                    "max_quantization_repair_ms",
                )
            }
            if raw_zero_duration != category_counts[
                "quantization_repaired_word_count"
            ]:
                raise ValueError(
                    f"timestamps audit chunk {index} quantization repair counts 無效"
                )
            for count_name, maximum_name in (
                ("window_clamped_word_count", "max_window_clamp_ms"),
                (
                    "intra_block_monotonic_adjusted_word_count",
                    "max_intra_block_shift_ms",
                ),
                ("seam_adjusted_word_count", "max_seam_shift_ms"),
                (
                    "quantization_repaired_word_count",
                    "max_quantization_repair_ms",
                ),
            ):
                if (category_counts[count_name] == 0) != (
                    maxima[maximum_name] == 0
                ):
                    raise ValueError(
                        f"timestamps audit chunk {index} adjustment maximum 無效"
                    )
            zero_duration = audit_int(
                raw_chunk["zero_duration_word_count"],
                label=f"audit chunk {index} zero_duration_word_count",
            )
            if zero_duration != 0:
                raise ValueError(f"timestamps audit chunk {index} zero duration 無效")
            reason = raw_chunk["fallback_reason"]
            method = raw_chunk["method"]
            if (
                not isinstance(method, str)
                or not (reason is None or isinstance(reason, str))
                or not _is_safe_fallback_reason(reason)
                or (reason is None and method != FORCED_ALIGNER_METHOD)
                or (reason is not None and method != "deterministic_coarse_fallback")
            ):
                raise ValueError(f"timestamps audit chunk {index} fallback 無效")
            if reason is not None:
                fallback_count += 1
                if reason not in fallback_reasons:
                    fallback_reasons.append(reason)
            adjustment_totals["unique_adjusted_word_count"] += clipped
            for name, value in category_counts.items():
                adjustment_totals[name] += value
            adjustment_totals["raw_zero_duration_word_count"] += raw_zero_duration
            adjustment_totals["max_window_clamp_ms"] = max(
                adjustment_totals["max_window_clamp_ms"],
                maxima["max_window_clamp_ms"],
            )
            adjustment_totals["max_intra_block_shift_ms"] = max(
                adjustment_totals["max_intra_block_shift_ms"],
                maxima["max_intra_block_shift_ms"],
            )
            adjustment_totals["max_seam_shift_ms"] = max(
                adjustment_totals["max_seam_shift_ms"],
                maxima["max_seam_shift_ms"],
            )
            adjustment_totals["max_quantization_repair_ms"] = max(
                adjustment_totals["max_quantization_repair_ms"],
                maxima["max_quantization_repair_ms"],
            )
            adjustment_totals["zero_duration_word_count"] += zero_duration
        if seen_chunk_ids != chunk_ids:
            raise ValueError("timestamps audit chunk coverage 無效")

        expected_method = FORCED_ALIGNER_METHOD
        expected_timing_source = "forced_aligner"
        if fallback_count == len(raw_chunks) and raw_chunks:
            expected_method = "deterministic_coarse_fallback"
            expected_timing_source = "deterministic_coarse_fallback"
        elif fallback_count:
            expected_method = "qwen3_forced_aligner_with_fallback"
            expected_timing_source = "mixed_forced_aligner_and_coarse_fallback"
        if wenet_timing["applied"]:
            expected_method += "+wenet_ctc_anchor_retime"
            expected_timing_source = "wenet_ctc_anchors_with_qwen_forced_fallback"
        raw_fallback_reasons = audit["fallback_reasons"]
        if not isinstance(raw_fallback_reasons, (list, tuple)) or any(
            not isinstance(item, str) for item in raw_fallback_reasons
        ):
            raise ValueError("timestamps audit fallback reasons 無效")
        summary_fallback_count = audit_int(
            audit["alignment_fallback_chunk_count"],
            label="audit alignment_fallback_chunk_count",
        )
        summary_word_count = audit_int(
            audit["word_count"], label="audit word_count"
        )
        summary_character_count = audit_int(
            audit["character_count"], label="audit character_count"
        )
        summary_cue_count = audit_int(audit["cue_count"], label="audit cue_count")
        if (
            audit["method"] != expected_method
            or audit["timing_source_summary"] != expected_timing_source
            or summary_fallback_count != fallback_count
            or tuple(raw_fallback_reasons) != tuple(fallback_reasons)
            or summary_word_count != len(words)
            or summary_character_count != len(characters)
            or summary_cue_count != len(cues)
        ):
            raise ValueError("timestamps audit summary 無效")
        adjustments = audit["adjustments"]
        if not isinstance(adjustments, dict) or adjustments != adjustment_totals:
            raise ValueError("timestamps audit adjustments 無效")
        if audit["fallback_semantics"] != {
            "fallback_reasons_scope": "alignment_or_timing_source_only",
            "boundary_selection_is_timing_fallback": False,
            "boundary_sources": ["reconciled_segment_range"],
        }:
            raise ValueError("timestamps audit fallback semantics 無效")
        alignment_windows = audit["alignment_windows"]
        expected_window_fields = {
            "source",
            "policy_version",
            "count",
            "context_seconds",
            "max_segment_seconds",
            "boundary_strategy",
        }
        if (
            not isinstance(alignment_windows, dict)
            or set(alignment_windows) != expected_window_fields
            or alignment_windows["source"]
            not in {
                "recognition_chunks",
                "dedicated_reconciled_segment_windows",
            }
            or alignment_windows["policy_version"] != ALIGNMENT_WINDOW_POLICY_VERSION
            or audit_int(
                alignment_windows["count"], label="audit alignment window count"
            )
            != len(chunk_ids)
            or alignment_windows["context_seconds"]
            != ALIGNMENT_WINDOW_CONTEXT_SECONDS
            or alignment_windows["max_segment_seconds"]
            != ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS
            or alignment_windows["boundary_strategy"]
            != ALIGNMENT_WINDOW_STRATEGY
        ):
            raise ValueError("timestamps audit alignment windows 無效")

    @staticmethod
    def _load_timestamp_chunk_journal(
        path: Path,
        *,
        fingerprint: str,
    ) -> list[dict[str, Any]]:
        """Load a sealed durable prefix or quarantine it fail-closed.

        The adapter performs the semantic block/text/timing validation before
        it trusts these records.  This layer binds the journal to the exact
        normalized document, local model manifest and audio bytes.
        """

        if not path.is_file() or path.is_symlink():
            return []
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if (
                not isinstance(raw, dict)
                or raw.get("schema") != 1
                or raw.get("fingerprint") != fingerprint
                or raw.get("state") not in {"partial", "complete"}
                or not isinstance(raw.get("chunks"), list)
            ):
                raise ValueError("timestamp chunk journal schema 無效")
            chunks = [dict(item) for item in raw["chunks"] if isinstance(item, dict)]
            if len(chunks) != len(raw["chunks"]):
                raise ValueError("timestamp chunk journal record 無效")
            expected = raw.get("payload_sha256")
            sealed = {
                "fingerprint": fingerprint,
                "state": raw["state"],
                "chunks": chunks,
            }
            if (
                not isinstance(expected, str)
                or len(expected) != 64
                or not hmac.compare_digest(expected, _json_fingerprint(sealed))
            ):
                raise ValueError("timestamp chunk journal digest mismatch")
            return chunks
        except (OSError, UnicodeError, json.JSONDecodeError, TypeError, ValueError):
            invalid = path.with_name(f"{path.name}.invalid-{time.time_ns()}-{os.getpid()}")
            try:
                os.replace(path, invalid)
            except OSError:
                pass
            return []

    @staticmethod
    def _write_timestamp_chunk_journal(
        path: Path,
        *,
        fingerprint: str,
        chunks: Sequence[Mapping[str, Any]],
        complete: bool,
    ) -> None:
        values = [dict(item) for item in chunks]
        state = "complete" if complete else "partial"
        sealed = {"fingerprint": fingerprint, "state": state, "chunks": values}
        _atomic_json(
            path,
            {
                "schema": 1,
                **sealed,
                "payload_sha256": _json_fingerprint(sealed),
            },
        )

    def _timestamps(
        self,
        workspace: Path,
        chunks: list[AudioChunk],
        final: dict[str, Any],
        *,
        progress: Progress | None,
        cancelled: Cancelled | None,
    ) -> dict[str, Any]:
        """Attach fine, editable subtitle cues after HK normalization."""

        self._check_cancel(cancelled)
        self._begin_job_stage("timestamps")
        self._stage_progress(
            "timestamps", {"phase": "forced_alignment", "progress": 0.0}, progress
        )
        checkpoint_path = workspace / "timestamps.json"
        base = self._timestamp_input(final)
        if not self._forced_alignment_enabled:
            value = dict(base)
            processing_completed_at = _utc_now()
            value["processing_completed_at"] = processing_completed_at
            metadata = dict(value.get("metadata", {}))
            metadata["forced_timestamps"] = {
                "enabled": False,
                "policy_version": FORCED_TIMESTAMP_POLICY_VERSION,
                "reason": "disabled in settings",
            }
            value["metadata"] = metadata
            fingerprint = _json_fingerprint(
                {"enabled": False, "policy": FORCED_TIMESTAMP_POLICY_VERSION, "final": base}
            )
            _atomic_json(
                checkpoint_path,
                {
                    "schema": 1,
                    "complete": True,
                    "fingerprint": fingerprint,
                    "processing_completed_at": processing_completed_at,
                    "value": {"metadata": metadata["forced_timestamps"]},
                    "payload_sha256": _json_fingerprint(
                        {
                            "value": {"metadata": metadata["forced_timestamps"]},
                            "processing_completed_at": processing_completed_at,
                        }
                    ),
                },
            )
            self._write_timestamped_final(workspace, value)
            # ``final.json`` is the artifact sealed by the normalized
            # checkpoint.  Timestamp enrichment intentionally rewrites that
            # envelope, so refresh the checkpoint after the rewrite.  Without
            # this, every correctly completed job looks tampered with on the
            # next App launch and is queued for an unnecessary repair run.
            self._checkpoint_job("normalized", workspace / "final.json", refresh=True)
            self._checkpoint_job("timestamps", checkpoint_path)
            self._stage_progress(
                "timestamps",
                {"phase": "forced_alignment", "progress": 1.0, "skipped": True},
                progress,
            )
            return value

        model_path = self.models.require_local(QWEN_ALIGNER_ID)
        model_manifest_sha256 = _model_manifest_sha256(model_path)
        verifier_timing_checkpoint = _verified_verifier_timing_checkpoint(
            workspace / "verifier.json"
        )
        verifier_timing_fingerprint = (
            str(verifier_timing_checkpoint.get("payload_sha256"))
            if verifier_timing_checkpoint is not None
            else None
        )
        timestamp_chunks = chunks
        alignment_window_source = "recognition_chunks"
        if self._require_dedicated_alignment_windows and not self._diarization_audio_path:
            raise PipelineError("精細字幕缺少 canonical mono WAV；已停止以避免降級時間碼")
        if self._use_forced_supervisor and self._diarization_audio_path:
            audio_path = Path(self._diarization_audio_path)
            if audio_path.is_symlink() or not audio_path.is_file():
                if self._require_dedicated_alignment_windows:
                    raise PipelineError("精細字幕 canonical mono WAV 無效；已停止以避免降級時間碼")
            else:
                try:
                    timestamp_chunks = prepare_alignment_windows(
                        audio_path,
                        workspace / "alignment-chunks",
                        segment_ranges_ms=tuple(
                            (int(item["start_ms"]), int(item["end_ms"]))
                            for item in base.get("segments", ())
                            if isinstance(item, Mapping)
                            and isinstance(item.get("start_ms"), int)
                            and not isinstance(item.get("start_ms"), bool)
                            and isinstance(item.get("end_ms"), int)
                            and not isinstance(item.get("end_ms"), bool)
                            and str(item.get("chosen_text", item.get("text", "")))
                        ),
                        cancelled=cancelled,
                    )
                except ASRCancelled:
                    raise
                except Exception as exc:
                    raise PipelineError(
                        f"建立精細字幕音訊視窗失敗：{type(exc).__name__}"
                    ) from exc
                alignment_window_source = (
                    "dedicated_reconciled_segment_windows"
                )
        fingerprint = _json_fingerprint(
            {
                "enabled": True,
                "policy": FORCED_TIMESTAMP_POLICY_VERSION,
                "alignment_window_policy": ALIGNMENT_WINDOW_POLICY_VERSION,
                "model": QWEN_ALIGNER_ID,
                "model_manifest_sha256": model_manifest_sha256,
                "wenet_timing_policy": WENET_TIMING_POLICY_VERSION,
                "wenet_display_cue_shift_policy": WENET_DISPLAY_CUE_SHIFT_POLICY_VERSION,
                "wenet_verifier_payload_sha256": verifier_timing_fingerprint,
                "wenet_timing_retime_enabled": self._wenet_timing_retime_enabled,
                "final": base,
                "chunks": [
                    {
                        "id": item.id,
                        "path": str(item.path),
                        "size": item.path.stat().st_size,
                        "mtime_ns": item.path.stat().st_mtime_ns,
                        "sha256": _file_sha256(item.path),
                        "start": item.start,
                        "end": item.end,
                        "core_start": item.transcript_start,
                        "core_end": item.transcript_end,
                    }
                    for item in timestamp_chunks
                ],
            }
        )
        checkpoint = _load_checkpoint(checkpoint_path)
        if checkpoint and checkpoint.get("fingerprint") == fingerprint:
            try:
                payload = dict(checkpoint["value"])
                payload_sha256 = checkpoint.get("payload_sha256")
                processing_completed_at = checkpoint.get("processing_completed_at")
                if (
                    not isinstance(processing_completed_at, str)
                    or not processing_completed_at.endswith("Z")
                    or not isinstance(payload_sha256, str)
                    or len(payload_sha256) != 64
                    or not hmac.compare_digest(
                        payload_sha256,
                        _json_fingerprint(
                            {
                                "value": payload,
                                "processing_completed_at": processing_completed_at,
                            }
                        ),
                    )
                ):
                    raise ValueError("timestamps payload digest mismatch")
                self._validate_timestamp_payload(
                    payload,
                    final_text=str(base.get("final_transcript", base.get("text", ""))),
                    duration_ms=max(1, round(float(base.get("duration", self._duration)) * 1000)),
                    chunk_ids={item.id for item in timestamp_chunks},
                    coarse_segment_count=len(base.get("segments", ())),
                )
            except (KeyError, TypeError, ValueError):
                invalid = checkpoint_path.with_name(
                    f"{checkpoint_path.name}.invalid-{time.time_ns()}-{os.getpid()}"
                )
                try:
                    os.replace(checkpoint_path, invalid)
                except OSError:
                    pass
            else:
                value = dict(base)
                value["processing_completed_at"] = processing_completed_at
                value.update(
                    {
                        "subtitle_segments": list(payload["subtitle_segments"]),
                        "word_timestamps": list(payload["word_timestamps"]),
                        "character_timestamps": list(payload["character_timestamps"]),
                    }
                )
                metadata = dict(value.get("metadata", {}))
                metadata["forced_timestamps"] = dict(payload["audit"])
                metadata["forced_timestamps"]["enabled"] = True
                value["metadata"] = metadata
                self._write_timestamped_final(workspace, value)
                self._checkpoint_job("normalized", workspace / "final.json", refresh=True)
                self._checkpoint_job("timestamps", checkpoint_path)
                self._stage_progress(
                    "timestamps",
                    {"phase": "forced_alignment", "progress": 1.0, "resumed": True},
                    progress,
                )
                return value

        journal_path = workspace / "timestamp-chunks.json"
        resume_chunks = self._load_timestamp_chunk_journal(
            journal_path,
            fingerprint=fingerprint,
        )
        durable_chunks = list(resume_chunks)

        def chunk_completed(value: Any) -> None:
            self._check_cancel(cancelled)
            record = value.to_dict() if hasattr(value, "to_dict") else dict(value)
            durable_chunks.append(record)
            self._write_timestamp_chunk_journal(
                journal_path,
                fingerprint=fingerprint,
                chunks=durable_chunks,
                complete=False,
            )

        try:
            if self._use_forced_supervisor:
                supervisor = self.forced_supervisor_factory()
                result = supervisor.run(
                    model_path=model_path,
                    model_id=QWEN_ALIGNER_ID,
                    language="Cantonese",
                    chunks=timestamp_chunks,
                    chosen_segments=base.get("segments", ()),
                    workspace=workspace / "forced-process",
                    progress=lambda event: self._stage_progress(
                        "timestamps", event, progress
                    ),
                    cancelled=cancelled,
                    resume_chunks=resume_chunks,
                    chunk_completed=chunk_completed,
                )
            else:
                # Tests and explicit custom adapters retain the original
                # in-process duck-typed injection contract.
                adapter = self.forced_aligner_factory(model_path)
                result = adapter.align(
                    timestamp_chunks,
                    base.get("segments", ()),
                    progress=lambda event: self._stage_progress(
                        "timestamps", event, progress
                    ),
                    cancelled=cancelled,
                    resume_chunks=resume_chunks,
                    chunk_completed=chunk_completed,
                )
        except ASRCancelled:
            raise
        except Exception as exc:
            raise PipelineError(f"精細字幕時間碼失敗：{type(exc).__name__}") from exc
        payload = result.to_dict()
        expected_text = str(base.get("final_transcript", base.get("text", "")))
        if payload.get("text") != expected_text:
            raise PipelineError("Forced aligner 改變咗 final transcript；已停止以保護內容")
        wenet_timing_audit: dict[str, Any] = {
            "policy_version": WENET_TIMING_POLICY_VERSION,
            "model": WENET_TIMING_MODEL,
            "applied": False,
            "transcript_text_changed": False,
            "timing_review_required": True,
            "reason": (
                "candidate_experiment_not_enabled"
                if not self._wenet_timing_retime_enabled
                else "sealed_verifier_checkpoint_unavailable"
            ),
        }
        if self._wenet_timing_retime_enabled and verifier_timing_checkpoint is not None:
            try:
                wenet_result = retime_with_wenet_anchors(
                    text=expected_text,
                    final_segments=[
                        dict(item)
                        for item in base.get("segments", ())
                        if isinstance(item, Mapping)
                    ],
                    verifier_segments=[
                        dict(item)
                        for item in verifier_timing_checkpoint.get("segments", ())
                        if isinstance(item, Mapping)
                    ],
                    words=list(payload.get("words", ())),
                    characters=list(payload.get("characters", ())),
                    duration_ms=max(
                        1,
                        round(float(base.get("duration", self._duration)) * 1_000),
                    ),
                )
            except (KeyError, TypeError, ValueError):
                wenet_timing_audit["reason"] = "wenet_anchor_retime_rejected"
            else:
                wenet_timing_audit = dict(wenet_result.audit)
                if wenet_result.audit.get("applied") is True:
                    payload["words"] = list(wenet_result.words)
                    payload["characters"] = list(wenet_result.characters)
                    payload["cues"] = list(wenet_result.cues)
                    payload_audit = dict(payload.get("audit", {}))
                    payload_audit["method"] = (
                        f"{payload_audit.get('method', FORCED_ALIGNER_METHOD)}"
                        "+wenet_ctc_anchor_retime"
                    )
                    payload["audit"] = payload_audit
                else:
                    wenet_timing_audit.setdefault("reason", "no_trusted_wenet_anchors")
        speaker_turns = ()
        diarization_metadata = (base.get("metadata") or {}).get("diarization")
        if (
            isinstance(diarization_metadata, dict)
            and diarization_metadata.get("enabled") is True
        ):
            try:
                speaker_turns = read_turns(workspace / "diarization-turns.json")
            except DiarizationError as exc:
                raise PipelineError(f"精細字幕講者資料無效：{exc}") from exc
        fine_method = str(
            (payload.get("audit") or {}).get("method", "qwen3_forced_aligner")
        )
        wenet_timing_audit["display_cue_adjustment"] = (
            _wenet_display_cue_adjustment(fine_method)
        )
        fine_segments = self._fine_subtitle_segments(
            list(payload.get("cues", ())),
            list(base.get("segments", ())),
            method=fine_method,
            speaker_turns=speaker_turns,
        )
        timing_review_spans = wenet_timing_audit.get("review_spans", ())
        if isinstance(timing_review_spans, list):
            for cue in fine_segments:
                source_start = int(cue.get("source_start", 0))
                source_end = int(cue.get("source_end", 0))
                timing_review_required = any(
                    isinstance(span, Mapping)
                    and isinstance(span.get("source_start"), int)
                    and isinstance(span.get("source_end"), int)
                    and max(source_start, int(span["source_start"]))
                    < min(source_end, int(span["source_end"]))
                    for span in timing_review_spans
                )
                timing_review_required = timing_review_required or (
                    int(cue.get("end_ms", 0)) - int(cue.get("start_ms", 0)) < 300
                )
                cue["timing_review_required"] = timing_review_required
                if timing_review_required:
                    cue["low_confidence"] = True
        if "".join(item["text"] for item in fine_segments) != expected_text:
            raise PipelineError("精細字幕未能完整保留 final transcript")
        raw_chunk_audits = list((payload.get("audit") or {}).get("chunks", ()))
        alignment_fallback_chunks = sum(
            1
            for item in raw_chunk_audits
            if isinstance(item, Mapping)
            and (
                item.get("fallback_reason") is not None
                or item.get("method") == "deterministic_coarse_fallback"
            )
        )
        if wenet_timing_audit.get("applied") is True:
            timing_source_summary = "wenet_ctc_anchors_with_qwen_forced_fallback"
        elif alignment_fallback_chunks == 0:
            timing_source_summary = "forced_aligner"
        elif alignment_fallback_chunks == len(raw_chunk_audits):
            timing_source_summary = "deterministic_coarse_fallback"
        else:
            timing_source_summary = "mixed_forced_aligner_and_coarse_fallback"
        adjustment_summary = {
            "unique_adjusted_word_count": sum(
                int(item.get("clipped_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
            "window_clamped_word_count": sum(
                int(item.get("window_clamped_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
            "intra_block_monotonic_adjusted_word_count": sum(
                int(item.get("intra_block_monotonic_adjusted_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
            "seam_adjusted_word_count": sum(
                int(item.get("seam_adjusted_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
            "max_window_clamp_ms": max(
                (
                    int(item.get("max_window_clamp_ms", 0))
                    for item in raw_chunk_audits
                    if isinstance(item, Mapping)
                ),
                default=0,
            ),
            "max_intra_block_shift_ms": max(
                (
                    int(item.get("max_intra_block_shift_ms", 0))
                    for item in raw_chunk_audits
                    if isinstance(item, Mapping)
                ),
                default=0,
            ),
            "max_seam_shift_ms": max(
                (
                    int(item.get("max_seam_shift_ms", 0))
                    for item in raw_chunk_audits
                    if isinstance(item, Mapping)
                ),
                default=0,
            ),
            "raw_zero_duration_word_count": sum(
                int(item.get("raw_zero_duration_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
            "quantization_repaired_word_count": sum(
                int(item.get("quantization_repaired_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
            "max_quantization_repair_ms": max(
                (
                    int(item.get("max_quantization_repair_ms", 0))
                    for item in raw_chunk_audits
                    if isinstance(item, Mapping)
                ),
                default=0,
            ),
            "zero_duration_word_count": sum(
                int(item.get("zero_duration_word_count", 0))
                for item in raw_chunk_audits
                if isinstance(item, Mapping)
            ),
        }
        audit = {
            **dict(payload.get("audit", {})),
            "cue_count": len(fine_segments),
            "word_count": len(payload.get("words", ())),
            "character_count": len(payload.get("characters", ())),
            "timing_source_summary": timing_source_summary,
            "alignment_fallback_chunk_count": alignment_fallback_chunks,
            "adjustments": adjustment_summary,
            "fallback_semantics": {
                "fallback_reasons_scope": "alignment_or_timing_source_only",
                "boundary_selection_is_timing_fallback": False,
                "boundary_sources": ["reconciled_segment_range"],
            },
            "alignment_windows": {
                "source": alignment_window_source,
                "policy_version": ALIGNMENT_WINDOW_POLICY_VERSION,
                "count": len(timestamp_chunks),
                "context_seconds": ALIGNMENT_WINDOW_CONTEXT_SECONDS,
                "max_segment_seconds": ALIGNMENT_WINDOW_MAX_SEGMENT_SECONDS,
                "boundary_strategy": ALIGNMENT_WINDOW_STRATEGY,
            },
            "wenet_timing_backbone": wenet_timing_audit,
        }
        checkpoint_value = {
            "subtitle_segments": fine_segments,
            "word_timestamps": list(payload.get("words", ())),
            "character_timestamps": list(payload.get("characters", ())),
            "audit": audit,
        }
        self._validate_timestamp_payload(
            checkpoint_value,
            final_text=expected_text,
            duration_ms=max(1, round(float(base.get("duration", self._duration)) * 1000)),
            chunk_ids={item.id for item in timestamp_chunks},
            coarse_segment_count=len(base.get("segments", ())),
        )
        processing_completed_at = _utc_now()
        self._write_timestamp_chunk_journal(
            journal_path,
            fingerprint=fingerprint,
            chunks=durable_chunks,
            complete=True,
        )
        _atomic_json(
            checkpoint_path,
            {
                "schema": 1,
                "complete": True,
                "fingerprint": fingerprint,
                "model_manifest_sha256": model_manifest_sha256,
                "processing_completed_at": processing_completed_at,
                "payload_sha256": _json_fingerprint(
                    {
                        "value": checkpoint_value,
                        "processing_completed_at": processing_completed_at,
                    }
                ),
                "value": checkpoint_value,
            },
        )
        value = dict(base)
        value["processing_completed_at"] = processing_completed_at
        value.update(
            {
                "subtitle_segments": fine_segments,
                "word_timestamps": checkpoint_value["word_timestamps"],
                "character_timestamps": checkpoint_value["character_timestamps"],
            }
        )
        metadata = dict(value.get("metadata", {}))
        metadata["forced_timestamps"] = {
            **checkpoint_value["audit"],
            "enabled": True,
        }
        value["metadata"] = metadata
        self._write_timestamped_final(workspace, value)
        self._checkpoint_job("normalized", workspace / "final.json", refresh=True)
        self._checkpoint_job("timestamps", checkpoint_path)
        self._stage_progress(
            "timestamps", {"phase": "forced_alignment", "progress": 1.0}, progress
        )
        return value

    @staticmethod
    def _export_artifact_manifest(
        value: dict[str, Any], exports_dir: Path
    ) -> list[dict[str, Any]]:
        root = exports_dir.resolve(strict=True)
        records: list[dict[str, Any]] = []
        for key, raw_path in sorted(value.items()):
            if not isinstance(key, str) or not isinstance(raw_path, str):
                raise PipelineError("export result 必須係 path mapping")
            path = Path(raw_path)
            if path.is_symlink() or not path.is_file():
                raise PipelineError(f"export artifact 缺失：{key}")
            resolved = path.resolve(strict=True)
            try:
                relative = resolved.relative_to(root)
            except ValueError as exc:
                raise PipelineError(f"export artifact 超出 exports 目錄：{key}") from exc
            stat = resolved.stat()
            records.append(
                {
                    "key": key,
                    "relative_path": str(relative),
                    "size": stat.st_size,
                    "sha256": _file_sha256(resolved),
                }
            )
        if not records:
            raise PipelineError("export result 冇任何檔案")
        return records

    @classmethod
    def _export_artifacts_valid(
        cls,
        marker: dict[str, Any],
        exports_dir: Path,
    ) -> bool:
        value = marker.get("value")
        records = marker.get("artifacts")
        seal = marker.get("payload_sha256")
        sealed = {
            "fingerprint": marker.get("fingerprint"),
            "value": value,
            "artifacts": records,
        }
        if (
            not isinstance(value, dict)
            or not isinstance(records, list)
            or not isinstance(seal, str)
            or not hmac.compare_digest(seal, _json_fingerprint(sealed))
        ):
            return False
        try:
            actual = cls._export_artifact_manifest(value, exports_dir)
        except (OSError, PipelineError):
            return False
        return actual == records

    def _exports(
        self, workspace: Path, final: dict[str, Any], *, progress: Progress | None, cancelled: Cancelled | None
    ) -> dict[str, Any]:
        export_fingerprint = _json_fingerprint(
            {
                "policy": _component_policy(self.exporter, EXPORT_POLICY_VERSION),
                "final": final,
            }
        )
        marker = _load_checkpoint(workspace / "exports.json")
        exports_dir = workspace / "exports"
        if (
            marker
            and marker.get("fingerprint") == export_fingerprint
            and exports_dir.is_dir()
            and self._export_artifacts_valid(marker, exports_dir)
        ):
            self._begin_job_stage("exports", resumed=True)
            export_paths = [Path(path) for path in marker["value"].values()]
            self._checkpoint_job(
                "exported",
                [workspace / "exports.json", *export_paths],
                data={"artifact_manifest": marker["artifacts"]},
            )
            self._stage_progress("exports", {"progress": 1.0, "resumed": True}, progress)
            return marker["value"]
        self._check_cancel(cancelled)
        self._begin_job_stage("exports")
        self._stage_progress("exports", {"progress": 0.0}, progress)
        temp_dir = Path(tempfile.mkdtemp(prefix=".exports-", dir=workspace))
        try:
            if self.exporter is None:
                from .exports import export_all

                document = _document_from_dict(final)
                value = export_all(
                    document,
                    temp_dir,
                    stem=Path(document.media_path).stem or self._job_id,
                )
            else:
                value = self.exporter.export_all(final, output_dir=temp_dir)
            if exports_dir.exists():
                move_to_trash(exports_dir)
            os.replace(temp_dir, exports_dir)
            if isinstance(value, dict):
                for key, path_value in tuple(value.items()):
                    if isinstance(path_value, str) and path_value.startswith(str(temp_dir)):
                        value[key] = str(exports_dir / Path(path_value).relative_to(temp_dir))
            if not isinstance(value, dict):
                raise PipelineError("exporter 必須回傳 path mapping")
            artifact_manifest = self._export_artifact_manifest(value, exports_dir)
            sealed = {
                "fingerprint": export_fingerprint,
                "value": value,
                "artifacts": artifact_manifest,
            }
            _atomic_json(
                workspace / "exports.json",
                {
                    "schema": 1,
                    "complete": True,
                    **sealed,
                    "payload_sha256": _json_fingerprint(sealed),
                },
            )
            export_paths = [Path(path) for path in value.values()]
            self._checkpoint_job(
                "exported",
                [workspace / "exports.json", *export_paths],
                data={"artifact_manifest": artifact_manifest},
            )
        except BaseException:
            move_to_trash(temp_dir)
            raise
        self._stage_progress("exports", {"progress": 1.0}, progress)
        return value


__all__ = [
    "PipelineCancelled",
    "PipelineError",
    "PipelineInterrupted",
    "TranscriptionPipeline",
]
