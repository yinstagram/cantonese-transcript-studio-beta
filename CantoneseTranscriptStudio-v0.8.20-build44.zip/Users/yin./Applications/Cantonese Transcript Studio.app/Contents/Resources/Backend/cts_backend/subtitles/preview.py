"""AVPlayer-compatible local preview proxy generation."""

from __future__ import annotations

import json
import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

from ..audio.media import (
    OwnedProcessCancelled,
    OwnedProcessDeadlineExceeded,
    OwnedProcessOutputLimitExceeded,
)
from ..models import move_to_trash
from .project import _atomic_json
from .render import (
    SubtitleRenderer,
    _run_subtitle_process,
    probe_media,
    validate_source_fingerprint,
)
from .schemas import SubtitleProject


PREVIEW_SCHEMA = 1
PREVIEW_MANIFEST = "preview.json"
MAX_PREVIEW_MANIFEST_BYTES = 1024 * 1024

ProgressCallback = Callable[[float, Mapping[str, str]], None]


class PreviewCancelled(RuntimeError):
    pass


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_preview_command(
    *,
    ffmpeg_path: str,
    source_path: str,
    partial_filename: str,
) -> list[str]:
    if Path(partial_filename).name != partial_filename or partial_filename in {".", ".."}:
        raise ValueError("preview partial output 必須使用 workspace 相對檔名")
    if not partial_filename.endswith(".mp4"):
        raise ValueError("preview partial output 必須係 MP4")
    return [
        ffmpeg_path,
        "-hide_banner",
        "-y",
        "-i",
        source_path,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-sn",
        "-dn",
        "-map_metadata",
        "-1",
        "-vf",
        (
            "scale=w='min(1280,iw)':h='min(720,ih)':"
            "force_original_aspect_ratio=decrease:force_divisible_by=2"
        ),
        "-c:v",
        "h264_videotoolbox",
        "-b:v",
        "4M",
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "96k",
        "-movflags",
        "+faststart",
        "-progress",
        "pipe:1",
        "-nostats",
        partial_filename,
    ]


def _idle_preview(job_id: str) -> dict[str, Any]:
    return {
        "schema": PREVIEW_SCHEMA,
        "job_id": job_id,
        "state": "idle",
        "progress": 0.0,
        "token": None,
        "source_fingerprint": None,
        "duration_ms": None,
        "source_width": None,
        "source_height": None,
        "source_rotation": 0,
        "output_path": None,
        "output_width": None,
        "output_height": None,
        "queued_at": None,
        "started_at": None,
        "completed_at": None,
        "error": None,
        "cancel_requested": False,
    }


def _safe_manifest(path: Path, job_id: str) -> dict[str, Any] | None:
    if not path.exists():
        return None
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_PREVIEW_MANIFEST_BYTES:
        raise ValueError("preview.json 無效")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("preview.json 已損壞") from exc
    if not isinstance(value, Mapping) or value.get("schema") != PREVIEW_SCHEMA:
        raise ValueError("preview.json schema 無效")
    if value.get("job_id") != job_id:
        raise ValueError("preview.json job id 無效")
    if value.get("state") not in {
        "idle",
        "queued",
        "rendering",
        "completed",
        "failed",
        "cancelled",
    }:
        raise ValueError("preview state 無效")
    progress = value.get("progress")
    if (
        isinstance(progress, bool)
        or not isinstance(progress, (int, float))
        or not 0 <= float(progress) <= 1
    ):
        raise ValueError("preview progress 無效")
    for key in ("partial_filename", "output_filename"):
        raw_name = value.get(key)
        if raw_name is not None and (
            not isinstance(raw_name, str)
            or Path(raw_name).name != raw_name
            or raw_name in {".", ".."}
        ):
            raise ValueError(f"preview {key} 無效")
    return dict(value)


class PreviewProxy:
    def __init__(self) -> None:
        self._manifest_lock = threading.RLock()

    @staticmethod
    def directory(workspace: Path) -> Path:
        return SubtitleRenderer.directory(workspace)

    def status(self, workspace: Path, job_id: str) -> dict[str, Any]:
        directory = self.directory(workspace)
        with self._manifest_lock:
            return _safe_manifest(directory / PREVIEW_MANIFEST, job_id) or _idle_preview(job_id)

    def save_status(self, workspace: Path, value: Mapping[str, Any]) -> dict[str, Any]:
        job_id = value.get("job_id")
        if not isinstance(job_id, str) or not job_id:
            raise ValueError("preview job_id 無效")
        payload = dict(value)
        # Validate through the same reader contract before publishing.
        state = payload.get("state")
        if state not in {"idle", "queued", "rendering", "completed", "failed", "cancelled"}:
            raise ValueError("preview state 無效")
        progress = payload.get("progress")
        if (
            isinstance(progress, bool)
            or not isinstance(progress, (int, float))
            or not 0 <= float(progress) <= 1
        ):
            raise ValueError("preview progress 無效")
        for key in ("partial_filename", "output_filename"):
            raw_name = payload.get(key)
            if raw_name is not None and (
                not isinstance(raw_name, str)
                or Path(raw_name).name != raw_name
                or raw_name in {".", ".."}
            ):
                raise ValueError(f"preview {key} 無效")
        directory = self.directory(workspace)
        with self._manifest_lock:
            _atomic_json(directory / PREVIEW_MANIFEST, payload)
        return payload

    def prepare(
        self,
        *,
        workspace: Path,
        project: SubtitleProject,
        ffmpeg_path: str,
        ffprobe_path: str,
    ) -> dict[str, Any]:
        current = self.status(workspace, project.job_id)
        if current.get("state") in {"queued", "rendering"}:
            raise ValueError("呢個工作已有 preview 處理中")
        media = probe_media(project.source_path, ffprobe_path=ffprobe_path)
        if not media["has_video"]:
            raise ValueError("原檔冇影片軌；純音訊唔需要建立影片 preview")
        token = uuid.uuid4().hex
        stem = f"preview-r{project.revision}-{token[:10]}"
        value = {
            "schema": PREVIEW_SCHEMA,
            "job_id": project.job_id,
            "state": "queued",
            "progress": 0.0,
            "token": token,
            "source_path": project.source_path,
            "source_fingerprint": project.source_fingerprint,
            "source_final_sha256": project.source_final_sha256,
            "duration_ms": max(project.duration_ms, int(media.get("duration_ms") or 0)),
            # probe_media reports display-oriented dimensions after applying rotation.
            "source_width": int(media["width"]),
            "source_height": int(media["height"]),
            "source_rotation": int(media.get("rotation") or 0),
            "output_path": None,
            "output_width": None,
            "output_height": None,
            "queued_at": _utc_now(),
            "started_at": None,
            "completed_at": None,
            "error": None,
            "cancel_requested": False,
            "ffmpeg_path": ffmpeg_path,
            "ffprobe_path": ffprobe_path,
            "partial_filename": f".{stem}.partial.mp4",
            "output_filename": f"{stem}.mp4",
        }
        return self.save_status(workspace, value)

    def execute(
        self,
        *,
        workspace: Path,
        manifest: Mapping[str, Any],
        cancel_event: threading.Event,
        progress_callback: ProgressCallback,
    ) -> dict[str, Any]:
        directory = self.directory(workspace)
        source = Path(str(manifest["source_path"])).expanduser()
        if source.is_symlink() or not source.is_file():
            raise FileNotFoundError(f"搵唔到原始影片：{source}")
        partial_name = str(manifest["partial_filename"])
        output_name = str(manifest["output_filename"])
        for name in (partial_name, output_name):
            if Path(name).name != name or name in {".", ".."}:
                raise ValueError("preview artifact 路徑無效")
        partial = directory / partial_name
        output = directory / output_name
        if (
            partial.exists()
            or partial.is_symlink()
            or output.exists()
            or output.is_symlink()
        ):
            raise ValueError("preview output 已存在；為免覆蓋檔案，請重新建立")
        if source.resolve() in {partial.resolve(strict=False), output.resolve(strict=False)}:
            raise ValueError("原始影片同 preview 路徑唔可以相同")
        validate_source_fingerprint(source, str(manifest.get("source_fingerprint") or ""))
        if cancel_event.is_set():
            raise PreviewCancelled("Preview 建立已取消")
        command = build_preview_command(
            ffmpeg_path=str(manifest["ffmpeg_path"]),
            source_path=str(source),
            partial_filename=partial_name,
        )
        log_path = directory / "preview.log"
        try:
            return_code, _ = _run_subtitle_process(
                command,
                directory=directory,
                cancel_event=cancel_event,
                progress_callback=progress_callback,
                duration_ms=int(manifest["duration_ms"]),
                log_path=log_path,
            )
        except OwnedProcessCancelled as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise PreviewCancelled("Preview 建立已取消") from exc
        except OwnedProcessDeadlineExceeded as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("Preview 建立逾時；請重試") from exc
        except OwnedProcessOutputLimitExceeded as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("Preview renderer 回傳過多資料，已安全停止") from exc
        except OSError as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("無法啟動 Preview renderer") from exc
        except BaseException:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise
        if cancel_event.is_set():
            if partial.exists():
                move_to_trash(partial)
            raise PreviewCancelled("Preview 建立已取消")
        if return_code != 0:
            if partial.exists():
                move_to_trash(partial)
            raise RuntimeError(
                f"Preview 建立失敗（code {return_code}）；技術詳情已寫入 preview.log"
            )
        if not partial.is_file() or partial.stat().st_size <= 0:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("FFmpeg 冇產生完整 preview")
        try:
            verified = probe_media(partial, ffprobe_path=str(manifest["ffprobe_path"]))
        except BaseException:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise
        if (
            not verified["has_video"]
            or verified.get("video_codec") != "h264"
            or verified.get("pixel_format") != "yuv420p"
            or (verified["has_audio"] and "aac" not in verified.get("audio_codecs", ()))
            or int(verified.get("duration_ms") or 0) <= 0
        ):
            move_to_trash(partial)
            raise RuntimeError("Preview 格式或完整性驗證失敗")
        expected_duration = int(manifest.get("duration_ms") or 0)
        actual_duration = int(verified["duration_ms"])
        if expected_duration > 2000 and actual_duration + 1000 < expected_duration * 0.9:
            move_to_trash(partial)
            raise RuntimeError("Preview 長度明顯短過原片")
        try:
            os.replace(partial, output)
        except BaseException:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise
        value = dict(manifest)
        value.update(
            {
                "state": "completed",
                "progress": 1.0,
                "output_path": str(output.resolve()),
                "completed_at": _utc_now(),
                "error": None,
                "cancel_requested": False,
                "output_width": verified.get("width"),
                "output_height": verified.get("height"),
            }
        )
        try:
            return self.save_status(workspace, value)
        except BaseException:
            if output.exists() or output.is_symlink():
                move_to_trash(output)
            raise

    def recover(self, jobs_root: Path) -> tuple[list[tuple[str, str]], list[str]]:
        queued: list[tuple[str, str]] = []
        interrupted: list[str] = []
        for path in sorted(jobs_root.glob(f"*/subtitle/{PREVIEW_MANIFEST}")):
            job_id = path.parents[1].name
            try:
                value = _safe_manifest(path, job_id)
                if value is None:
                    continue
                if value.get("state") == "queued":
                    token = value.get("token")
                    if isinstance(token, str) and token:
                        queued.append((job_id, token))
                elif value.get("state") == "rendering":
                    partial_name = value.get("partial_filename")
                    if isinstance(partial_name, str):
                        partial = path.parent / partial_name
                        if partial.exists():
                            move_to_trash(partial)
                    value.update(
                        {
                            "state": "failed",
                            "error": "App 上次關閉時中斷咗 preview 建立，請重試",
                            "completed_at": _utc_now(),
                            "cancel_requested": False,
                        }
                    )
                    self.save_status(path.parents[1], value)
                    interrupted.append(job_id)
            except Exception:
                continue
        return queued, interrupted


__all__ = [
    "PREVIEW_MANIFEST",
    "PreviewCancelled",
    "PreviewProxy",
    "build_preview_command",
]
