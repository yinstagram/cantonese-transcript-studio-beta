"""Offline Qwen3 ForcedAligner adapter for fine subtitle timestamps.

This module deliberately accepts a *verified local directory* instead of a
Hugging Face repository identifier.  The caller remains responsible for model
management and checkpoint persistence; this adapter only performs one bounded
alignment pass and returns transcript-bearing data in its result object.

Progress events and audit records contain counts and policy identifiers only.
They never contain transcript text.
"""

from __future__ import annotations

import gc
import json
import math
import unicodedata
import wave
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping, Sequence

from ..asr.types import ASRCancelled, AudioChunk


FORCED_TIMESTAMP_POLICY_VERSION = "qwen3-forced-timestamps-v10"
FORCED_ALIGNER_MODEL_ID = "Qwen/Qwen3-ForcedAligner-0.6B"
FORCED_ALIGNER_METHOD = "qwen3_forced_aligner"
TARGET_SAMPLE_RATE = 16_000
MAX_FORCED_ALIGNMENT_INPUT_MS = 300_000
MIN_CUE_MS = 2_000
MAX_CUE_MS = 7_000
TARGET_CUE_MS = 4_000
MAX_NON_ACOUSTIC_EDGE_EXTENSION_MS = 320

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]
AlignerFactory = Callable[[str], Any]
AudioLoader = Callable[[str | Path, int], Any]
Cleanup = Callable[[Any | None], None]
ChunkCompleted = Callable[["ForcedTimestampChunkResult"], None]


@dataclass(frozen=True)
class WordTimestamp:
    """An exact source-text span with an absolute timestamp range."""

    text: str
    start_ms: int
    end_ms: int
    source_start: int
    source_end: int
    chunk_id: str


@dataclass(frozen=True)
class CharacterTimestamp:
    """One unmodified Unicode code point from the final transcript."""

    text: str
    start_ms: int
    end_ms: int
    source_index: int
    chunk_id: str


@dataclass(frozen=True)
class SubtitleCue:
    """A deterministic, contiguous slice of the final transcript."""

    index: int
    start_ms: int
    end_ms: int
    text: str
    source_start: int
    source_end: int


@dataclass(frozen=True)
class ChunkTimestampAudit:
    """Non-transcript audit data for one disk-backed audio chunk."""

    chunk_id: str
    method: str
    core_start_ms: int
    core_end_ms: int
    word_count: int
    character_count: int
    # v3 only counts a real audio-window clamp or a monotonic seam repair.
    # It no longer means that a valid boundary was clipped to an ASR core.
    clipped_word_count: int = 0
    window_clamped_word_count: int = 0
    intra_block_monotonic_adjusted_word_count: int = 0
    seam_adjusted_word_count: int = 0
    max_window_clamp_ms: int = 0
    max_intra_block_shift_ms: int = 0
    max_seam_shift_ms: int = 0
    raw_zero_duration_word_count: int = 0
    quantization_repaired_word_count: int = 0
    max_quantization_repair_ms: int = 0
    zero_duration_word_count: int = 0
    fallback_reason: str | None = None


@dataclass(frozen=True)
class ForcedTimestampAudit:
    """Alignment provenance.  No field may contain transcript content."""

    method: str
    model: str
    policy_version: str
    cue_policy: str
    fallback_reasons: tuple[str, ...]
    chunks: tuple[ChunkTimestampAudit, ...]


@dataclass(frozen=True)
class ForcedTimestampResult:
    """Fine timestamps plus the exact, unmodified transcript body."""

    text: str
    words: tuple[WordTimestamp, ...]
    characters: tuple[CharacterTimestamp, ...]
    cues: tuple[SubtitleCue, ...]
    audit: ForcedTimestampAudit

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ForcedTimestampChunkResult:
    """One durable contiguous block for crash-safe stage resume."""

    chunk_id: str
    text: str
    source_start: int
    source_end: int
    words: tuple[WordTimestamp, ...]
    characters: tuple[CharacterTimestamp, ...]
    audit: ChunkTimestampAudit

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class _ChosenSegment:
    start_ms: int
    end_ms: int
    text: str


@dataclass(frozen=True)
class _SourceWord:
    text: str
    start: int
    end: int


@dataclass(frozen=True)
class _TextBlock:
    chunk: AudioChunk
    text: str
    source_start: int
    source_end: int
    coarse_start_ms: int
    coarse_end_ms: int
    fallback_reason: str | None = None


class _AlignmentRejected(ValueError):
    """Internal signal for deterministic coarse-timestamp fallback."""


@dataclass(frozen=True)
class _AdjustmentStats:
    window_clamped_word_indices: frozenset[int] = frozenset()
    intra_block_monotonic_adjusted_word_indices: frozenset[int] = frozenset()
    seam_adjusted_word_indices: frozenset[int] = frozenset()
    quantization_repaired_word_indices: frozenset[int] = frozenset()
    raw_zero_duration_word_indices: frozenset[int] = frozenset()
    max_window_clamp_ms: int = 0
    max_intra_block_shift_ms: int = 0
    max_seam_shift_ms: int = 0
    max_quantization_repair_ms: int = 0

    @property
    def window_clamped_word_count(self) -> int:
        return len(self.window_clamped_word_indices)

    @property
    def intra_block_monotonic_adjusted_word_count(self) -> int:
        return len(self.intra_block_monotonic_adjusted_word_indices)

    @property
    def seam_adjusted_word_count(self) -> int:
        return len(self.seam_adjusted_word_indices)

    @property
    def quantization_repaired_word_count(self) -> int:
        return len(self.quantization_repaired_word_indices)

    @property
    def raw_zero_duration_word_count(self) -> int:
        return len(self.raw_zero_duration_word_indices)

    @property
    def adjusted_word_indices(self) -> frozenset[int]:
        return frozenset(
            self.window_clamped_word_indices
            | self.intra_block_monotonic_adjusted_word_indices
            | self.seam_adjusted_word_indices
            | self.quantization_repaired_word_indices
        )


def _strict_mapping(value: Any, *, fields: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"resume {label} 必須係 object")
    if set(value) != fields:
        raise ValueError(f"resume {label} schema 無效")
    return value


def _strict_int(value: Any, *, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"resume {label} 必須係 integer")
    return value


def _is_safe_fallback_reason(value: str | None) -> bool:
    if value is None:
        return True
    known = {
        "malformed_timestamp_item",
        "invalid_timestamp_range",
        "aligned_token_projection_mismatch",
        "aligner_returned_no_words",
        "collapsed_timestamp_range",
        "seam_repair_exceeds_audio_window",
        "word_source_spans_not_monotonic",
        "transcript_has_no_alignable_tokens",
        "coarse_segment_exceeds_audio_window",
        "coarse_segment_exceeds_forced_aligner_limit",
    }
    if value in known:
        return True
    prefix = "alignment_runtime_error:"
    return value.startswith(prefix) and value.removeprefix(prefix).isidentifier()


def _coerce_resumed_word(value: Any) -> WordTimestamp:
    if isinstance(value, WordTimestamp):
        return value
    item = _strict_mapping(
        value,
        fields={
            "text",
            "start_ms",
            "end_ms",
            "source_start",
            "source_end",
            "chunk_id",
        },
        label="word",
    )
    if not isinstance(item["text"], str) or not isinstance(item["chunk_id"], str):
        raise ValueError("resume word text/chunk_id 無效")
    return WordTimestamp(
        text=item["text"],
        start_ms=_strict_int(item["start_ms"], label="word.start_ms"),
        end_ms=_strict_int(item["end_ms"], label="word.end_ms"),
        source_start=_strict_int(item["source_start"], label="word.source_start"),
        source_end=_strict_int(item["source_end"], label="word.source_end"),
        chunk_id=item["chunk_id"],
    )


def _coerce_resumed_character(value: Any) -> CharacterTimestamp:
    if isinstance(value, CharacterTimestamp):
        return value
    item = _strict_mapping(
        value,
        fields={"text", "start_ms", "end_ms", "source_index", "chunk_id"},
        label="character",
    )
    if not isinstance(item["text"], str) or not isinstance(item["chunk_id"], str):
        raise ValueError("resume character text/chunk_id 無效")
    return CharacterTimestamp(
        text=item["text"],
        start_ms=_strict_int(item["start_ms"], label="character.start_ms"),
        end_ms=_strict_int(item["end_ms"], label="character.end_ms"),
        source_index=_strict_int(item["source_index"], label="character.source_index"),
        chunk_id=item["chunk_id"],
    )


def _coerce_resumed_audit(value: Any) -> ChunkTimestampAudit:
    if isinstance(value, ChunkTimestampAudit):
        return value
    item = _strict_mapping(
        value,
        fields={
            "chunk_id",
            "method",
            "core_start_ms",
            "core_end_ms",
            "word_count",
            "character_count",
            "clipped_word_count",
            "window_clamped_word_count",
            "intra_block_monotonic_adjusted_word_count",
            "seam_adjusted_word_count",
            "max_window_clamp_ms",
            "max_intra_block_shift_ms",
            "max_seam_shift_ms",
            "raw_zero_duration_word_count",
            "quantization_repaired_word_count",
            "max_quantization_repair_ms",
            "zero_duration_word_count",
            "fallback_reason",
        },
        label="audit",
    )
    if not isinstance(item["chunk_id"], str) or not isinstance(item["method"], str):
        raise ValueError("resume audit identity 無效")
    fallback_reason = item["fallback_reason"]
    if fallback_reason is not None and not isinstance(fallback_reason, str):
        raise ValueError("resume audit fallback_reason 無效")
    if not _is_safe_fallback_reason(fallback_reason):
        raise ValueError("resume audit fallback_reason 無效")
    return ChunkTimestampAudit(
        chunk_id=item["chunk_id"],
        method=item["method"],
        core_start_ms=_strict_int(item["core_start_ms"], label="audit.core_start_ms"),
        core_end_ms=_strict_int(item["core_end_ms"], label="audit.core_end_ms"),
        word_count=_strict_int(item["word_count"], label="audit.word_count"),
        character_count=_strict_int(
            item["character_count"], label="audit.character_count"
        ),
        clipped_word_count=_strict_int(
            item["clipped_word_count"], label="audit.clipped_word_count"
        ),
        window_clamped_word_count=_strict_int(
            item["window_clamped_word_count"],
            label="audit.window_clamped_word_count",
        ),
        intra_block_monotonic_adjusted_word_count=_strict_int(
            item["intra_block_monotonic_adjusted_word_count"],
            label="audit.intra_block_monotonic_adjusted_word_count",
        ),
        seam_adjusted_word_count=_strict_int(
            item["seam_adjusted_word_count"],
            label="audit.seam_adjusted_word_count",
        ),
        max_window_clamp_ms=_strict_int(
            item["max_window_clamp_ms"], label="audit.max_window_clamp_ms"
        ),
        max_intra_block_shift_ms=_strict_int(
            item["max_intra_block_shift_ms"],
            label="audit.max_intra_block_shift_ms",
        ),
        max_seam_shift_ms=_strict_int(
            item["max_seam_shift_ms"], label="audit.max_seam_shift_ms"
        ),
        raw_zero_duration_word_count=_strict_int(
            item["raw_zero_duration_word_count"],
            label="audit.raw_zero_duration_word_count",
        ),
        quantization_repaired_word_count=_strict_int(
            item["quantization_repaired_word_count"],
            label="audit.quantization_repaired_word_count",
        ),
        max_quantization_repair_ms=_strict_int(
            item["max_quantization_repair_ms"],
            label="audit.max_quantization_repair_ms",
        ),
        zero_duration_word_count=_strict_int(
            item["zero_duration_word_count"],
            label="audit.zero_duration_word_count",
        ),
        fallback_reason=fallback_reason,
    )


def _coerce_resumed_chunk(value: Any) -> ForcedTimestampChunkResult:
    if isinstance(value, ForcedTimestampChunkResult):
        return value
    item = _strict_mapping(
        value,
        fields={
            "chunk_id",
            "text",
            "source_start",
            "source_end",
            "words",
            "characters",
            "audit",
        },
        label="chunk",
    )
    if not isinstance(item["chunk_id"], str) or not isinstance(item["text"], str):
        raise ValueError("resume chunk identity/text 無效")
    if not isinstance(item["words"], (list, tuple)) or not isinstance(
        item["characters"], (list, tuple)
    ):
        raise ValueError("resume chunk timestamp arrays 無效")
    return ForcedTimestampChunkResult(
        chunk_id=item["chunk_id"],
        text=item["text"],
        source_start=_strict_int(item["source_start"], label="chunk.source_start"),
        source_end=_strict_int(item["source_end"], label="chunk.source_end"),
        words=tuple(_coerce_resumed_word(word) for word in item["words"]),
        characters=tuple(
            _coerce_resumed_character(character) for character in item["characters"]
        ),
        audit=_coerce_resumed_audit(item["audit"]),
    )


def _validate_resumed_chunk(
    value: ForcedTimestampChunkResult,
    block: _TextBlock,
) -> None:
    """Reject stale, skipped or internally inconsistent durable chunk data."""

    expected_core_start = round(block.chunk.transcript_start * 1000)
    expected_core_end = round(block.chunk.transcript_end * 1000)
    if (
        value.chunk_id != block.chunk.id
        or value.text != block.text
        or value.source_start != block.source_start
        or value.source_end != block.source_end
        or value.source_end - value.source_start != len(value.text)
    ):
        raise ValueError("resume chunks 唔係 expected text blocks 嘅連續 prefix")

    expected_window_start = round(block.chunk.start * 1000)
    expected_window_end = round(block.chunk.end * 1000)
    previous_word_end = expected_window_start
    previous_source_end = block.source_start
    for word in value.words:
        if (
            word.chunk_id != block.chunk.id
            or word.source_start < previous_source_end
            or word.source_end <= word.source_start
            or word.source_end > block.source_end
            or word.text
            != block.text[
                word.source_start - block.source_start : word.source_end - block.source_start
            ]
            or word.start_ms < previous_word_end
            or word.end_ms <= word.start_ms
            or word.start_ms < expected_window_start
            or word.end_ms > expected_window_end
        ):
            raise ValueError("resume chunk word timestamps 無效")
        previous_source_end = word.source_end
        previous_word_end = word.end_ms

    if len(value.characters) != len(block.text):
        raise ValueError("resume chunk character timestamps 數量無效")
    previous_character_end = expected_window_start
    for offset, character in enumerate(value.characters):
        if (
            character.chunk_id != block.chunk.id
            or character.text != block.text[offset]
            or character.source_index != block.source_start + offset
            or character.start_ms < previous_character_end
            or character.end_ms < character.start_ms
            or character.start_ms < expected_window_start
            or character.end_ms > expected_window_end
        ):
            raise ValueError("resume chunk character timestamps 無效")
        previous_character_end = character.end_ms

    audit = value.audit
    if (
        audit.chunk_id != block.chunk.id
        or audit.core_start_ms != expected_core_start
        or audit.core_end_ms != expected_core_end
        or audit.word_count != len(value.words)
        or audit.character_count != len(value.characters)
        or audit.clipped_word_count < 0
        or audit.clipped_word_count > len(value.words)
        or audit.window_clamped_word_count < 0
        or audit.window_clamped_word_count > len(value.words)
        or audit.intra_block_monotonic_adjusted_word_count < 0
        or audit.intra_block_monotonic_adjusted_word_count > len(value.words)
        or audit.seam_adjusted_word_count < 0
        or audit.seam_adjusted_word_count > len(value.words)
        or audit.max_window_clamp_ms < 0
        or audit.max_intra_block_shift_ms < 0
        or audit.max_seam_shift_ms < 0
        or audit.raw_zero_duration_word_count < 0
        or audit.raw_zero_duration_word_count > len(value.words)
        or audit.quantization_repaired_word_count < 0
        or audit.quantization_repaired_word_count > len(value.words)
        or audit.max_quantization_repair_ms < 0
        or (
            audit.quantization_repaired_word_count == 0
            and audit.max_quantization_repair_ms != 0
        )
        or (
            audit.quantization_repaired_word_count > 0
            and audit.max_quantization_repair_ms == 0
        )
        or audit.zero_duration_word_count != 0
        or not _is_safe_fallback_reason(audit.fallback_reason)
        or audit.method
        not in {FORCED_ALIGNER_METHOD, "deterministic_coarse_fallback"}
        or (audit.fallback_reason is None) != (audit.method == FORCED_ALIGNER_METHOD)
    ):
        raise ValueError("resume chunk audit 無效")


def validate_local_forced_aligner_model(model_path: str | Path) -> Path:
    """Return a canonical local model path or fail before runtime import.

    A repository ID such as ``Qwen/...`` cannot pass this check, which prevents
    the runtime from silently reaching the network.  Full manifest hashing is
    intentionally owned by ``ModelManager.require_local``; the adapter repeats
    the critical local-path and model-file checks at its trust boundary.
    """

    raw = Path(model_path).expanduser()
    if raw.is_symlink():
        raise FileNotFoundError(f"Forced aligner model path 唔可以係 symlink：{raw}")
    try:
        resolved = raw.resolve(strict=True)
    except OSError as exc:
        raise FileNotFoundError(f"Forced aligner local model 唔存在：{raw}") from exc
    if not resolved.is_dir():
        raise FileNotFoundError(f"Forced aligner local model 唔係目錄：{resolved}")

    config = resolved / "config.json"
    if config.is_symlink() or not config.is_file():
        raise FileNotFoundError(f"Forced aligner model 缺少 config.json：{resolved}")
    try:
        value = json.loads(config.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Forced aligner config.json 無效：{resolved}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"Forced aligner config.json 必須係 JSON object：{resolved}")

    weights = sorted(resolved.glob("*.safetensors"))
    if not weights or any(path.is_symlink() or not path.is_file() for path in weights):
        raise FileNotFoundError(f"Forced aligner model 缺少本機 safetensors：{resolved}")
    return resolved


def _default_aligner_factory(model_path: str) -> Any:
    try:
        from mlx_qwen3_asr import ForcedAligner
    except ImportError as exc:  # pragma: no cover - runtime installation fault
        raise RuntimeError("runtime 未安裝 mlx-qwen3-asr==0.3.5") from exc
    # A canonical local path is the only value supplied here.  No Hub ID.
    return ForcedAligner(model_path=model_path, backend="mlx")


def _default_audio_loader(source: str | Path, sample_rate: int) -> Any:
    try:
        from mlx_qwen3_asr.audio import load_audio_np
    except ImportError as exc:  # pragma: no cover - runtime installation fault
        raise RuntimeError("runtime 未安裝 mlx-qwen3-asr==0.3.5") from exc
    return load_audio_np(source, sr=sample_rate)


def release_forced_aligner_memory(aligner: Any | None) -> None:
    """Release model references, package holders, Python GC and MLX cache."""

    if aligner is not None:
        backend = getattr(aligner, "_backend", None)
        if backend is not None:
            for attribute in ("model", "tokenizer", "config"):
                try:
                    delattr(backend, attribute)
                except (AttributeError, TypeError):
                    pass
        try:
            aligner._backend = None
        except (AttributeError, TypeError):
            pass
    try:
        from mlx_qwen3_asr.load_models import _ModelHolder

        _ModelHolder.clear()
    except (ImportError, AttributeError):
        pass
    try:
        from mlx_qwen3_asr.tokenizer import _TokenizerHolder

        _TokenizerHolder.clear()
    except (ImportError, AttributeError):
        pass
    gc.collect()
    try:
        import mlx.core as mx

        mx.clear_cache()
    except (ImportError, AttributeError, RuntimeError):
        pass


def _coerce_segment(value: Any) -> _ChosenSegment:
    if isinstance(value, Mapping):
        getter = value.get
    else:
        getter = lambda key, default=None: getattr(value, key, default)

    raw_start = getter("start_ms", None)
    raw_end = getter("end_ms", None)
    if raw_start is None:
        raw_start = round(float(getter("start", 0.0)) * 1000)
    if raw_end is None:
        raw_end = round(float(getter("end", 0.0)) * 1000)
    start_ms = int(raw_start)
    end_ms = int(raw_end)
    if start_ms < 0 or end_ms < start_ms:
        raise ValueError("chosen transcript timestamps 無效")

    chosen = getter("chosen_text", None)
    text = getter("text", "") if chosen is None else chosen
    if not isinstance(text, str):
        raise TypeError("chosen transcript text 必須係文字")
    return _ChosenSegment(start_ms=start_ms, end_ms=end_ms, text=text)


def _validate_chunk_audio(chunk: AudioChunk) -> None:
    if not chunk.path.is_file():
        raise FileNotFoundError(f"forced alignment chunk 唔存在：{chunk.path}")
    try:
        with wave.open(str(chunk.path), "rb") as reader:
            actual = (
                reader.getnchannels(),
                reader.getframerate(),
                reader.getsampwidth(),
                reader.getcomptype(),
            )
    except (OSError, EOFError, wave.Error) as exc:
        raise ValueError(f"forced alignment chunk 唔係有效 PCM WAV：{chunk.path}") from exc
    expected = (1, TARGET_SAMPLE_RATE, 2, "NONE")
    if actual != expected:
        raise ValueError(
            "forced alignment chunk 必須係 mono 16 kHz PCM16 WAV；"
            f"收到 channels={actual[0]} rate={actual[1]} width={actual[2]} type={actual[3]}"
        )


def _coerce_chunks(values: Iterable[Any]) -> list[AudioChunk]:
    chunks = [AudioChunk.coerce(value) for value in values]
    chunks.sort(key=lambda item: (item.transcript_start, item.transcript_end, item.index, item.id))
    previous_core_end = -math.inf
    for chunk in chunks:
        if not (
            0 <= chunk.start <= chunk.transcript_start <= chunk.transcript_end <= chunk.end
        ):
            raise ValueError(f"chunk core bounds 無效：{chunk.id}")
        if chunk.transcript_start < previous_core_end:
            raise ValueError("chunk core bounds 必須單調而且唔可以重疊")
        _validate_chunk_audio(chunk)
        previous_core_end = chunk.transcript_end
    return chunks


def _distance_to_core(midpoint_ms: float, chunk: AudioChunk) -> float:
    start = chunk.transcript_start * 1000
    end = chunk.transcript_end * 1000
    if start <= midpoint_ms <= end:
        return 0.0
    return min(abs(midpoint_ms - start), abs(midpoint_ms - end))


def _build_blocks(chunks: Sequence[AudioChunk], segments: Sequence[_ChosenSegment]) -> list[_TextBlock]:
    if segments and not chunks:
        raise ValueError("有 transcript 但冇 audio chunks")
    groups: list[list[tuple[int, _ChosenSegment]]] = [[] for _ in chunks]
    source_offset = 0
    previous_index = 0
    for segment in segments:
        midpoint = (segment.start_ms + segment.end_ms) / 2
        covering = [
            index
            for index, chunk in enumerate(chunks)
            if round(chunk.start * 1000) <= segment.start_ms
            and segment.end_ms <= round(chunk.end * 1000)
        ]
        ideal = min(
            covering or range(len(chunks)),
            key=lambda index: (_distance_to_core(midpoint, chunks[index]), index),
        )
        # Keep exact input text order even if a coarse ASR timestamp regresses.
        selected = max(previous_index, ideal)
        selected = min(selected, len(chunks) - 1)
        groups[selected].append((source_offset, segment))
        previous_index = selected
        source_offset += len(segment.text)

    blocks: list[_TextBlock] = []
    for chunk, items in zip(chunks, groups):
        if not items:
            continue
        text = "".join(item.text for _, item in items)
        first_offset = items[0][0]
        last_offset, last_segment = items[-1]
        source_end = last_offset + len(last_segment.text)
        window_start_ms = round(chunk.start * 1000)
        window_end_ms = round(chunk.end * 1000)
        coarse_start = max(window_start_ms, min(item.start_ms for _, item in items))
        coarse_end = min(window_end_ms, max(item.end_ms for _, item in items))
        if coarse_end <= coarse_start:
            coarse_start, coarse_end = window_start_ms, window_end_ms
        fallback_reason = (
            "coarse_segment_exceeds_audio_window"
            if any(
                item.start_ms < window_start_ms or item.end_ms > window_end_ms
                for _, item in items
            )
            else None
        )
        if coarse_end - coarse_start > MAX_FORCED_ALIGNMENT_INPUT_MS:
            fallback_reason = "coarse_segment_exceeds_forced_aligner_limit"
        blocks.append(
            _TextBlock(
                chunk=chunk,
                text=text,
                source_start=first_offset,
                source_end=source_end,
                coarse_start_ms=coarse_start,
                coarse_end_ms=coarse_end,
                fallback_reason=fallback_reason,
            )
        )
    return blocks


def _is_kept(character: str) -> bool:
    return character == "'" or unicodedata.category(character).startswith(("L", "N"))


def _is_cjk(character: str) -> bool:
    code = ord(character)
    return (
        0x4E00 <= code <= 0x9FFF
        or 0x3400 <= code <= 0x4DBF
        or 0x20000 <= code <= 0x2A6DF
        or 0x2A700 <= code <= 0x2B73F
        or 0x2B740 <= code <= 0x2B81F
        or 0x2B820 <= code <= 0x2CEAF
        or 0xF900 <= code <= 0xFAFF
    )


def _projection(text: str) -> tuple[str, list[int]]:
    projected: list[str] = []
    raw_indices: list[int] = []
    for index, character in enumerate(text):
        if not _is_kept(character):
            continue
        for folded in character.casefold():
            projected.append(folded)
            raw_indices.append(index)
    return "".join(projected), raw_indices


def _source_word_spans(text: str) -> list[_SourceWord]:
    """Mirror mlx-qwen3-asr's Cantonese/space-language token boundaries."""

    output: list[_SourceWord] = []
    index = 0
    while index < len(text):
        while index < len(text) and text[index].isspace():
            index += 1
        segment_start = index
        while index < len(text) and not text[index].isspace():
            index += 1
        segment_end = index
        kept = [i for i in range(segment_start, segment_end) if _is_kept(text[i])]
        buffer: list[int] = []

        def flush() -> None:
            if not buffer:
                return
            start, end = buffer[0], buffer[-1] + 1
            output.append(_SourceWord(text=text[start:end], start=start, end=end))
            buffer.clear()

        for raw_index in kept:
            if _is_cjk(text[raw_index]):
                flush()
                output.append(
                    _SourceWord(
                        text=text[raw_index : raw_index + 1],
                        start=raw_index,
                        end=raw_index + 1,
                    )
                )
            else:
                buffer.append(raw_index)
        flush()
    return output


def _aligned_value(item: Any, key: str) -> Any:
    if isinstance(item, Mapping):
        return item[key]
    return getattr(item, key)


def _forced_words(
    block: _TextBlock,
    aligned: Sequence[Any],
) -> tuple[list[WordTimestamp], _AdjustmentStats]:
    source_key, raw_indices = _projection(block.text)
    aligned_keys: list[str] = []
    raw_times: list[tuple[float, float]] = []
    for item in aligned:
        key, _ = _projection(str(_aligned_value(item, "text")))
        if not key:
            continue
        try:
            start = float(_aligned_value(item, "start_time"))
            end = float(_aligned_value(item, "end_time"))
        except (KeyError, AttributeError, TypeError, ValueError) as exc:
            raise _AlignmentRejected("malformed_timestamp_item") from exc
        # The official parser is quantized to 80 ms and can legitimately emit
        # equal start/end bins for short Cantonese characters.  A reversed
        # range is still invalid; equal bins are repaired below by the minimum
        # deterministic positive-duration projection and fully audited.
        if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end < start:
            raise _AlignmentRejected("invalid_timestamp_range")
        aligned_keys.append(key)
        raw_times.append((start, end))

    if "".join(aligned_keys) != source_key:
        raise _AlignmentRejected("aligned_token_projection_mismatch")
    if source_key and not aligned_keys:
        raise _AlignmentRejected("aligner_returned_no_words")
    if not source_key:
        return [], _AdjustmentStats()

    chunk_start = round(block.chunk.start * 1000)
    chunk_end = round(block.chunk.end * 1000)
    window_clamped: set[int] = set()
    max_window_clamp_ms = 0
    raw_zero_duration = {
        index
        for index, (relative_start, relative_end) in enumerate(raw_times)
        if round(relative_start * 1000) == round(relative_end * 1000)
    }
    raw_boundaries: list[int] = []
    clamped_boundaries: list[int] = []
    for word_index, (relative_start, relative_end) in enumerate(raw_times):
        untrimmed_start = chunk_start + round(relative_start * 1000)
        untrimmed_end = chunk_start + round(relative_end * 1000)
        raw_boundaries.extend((untrimmed_start, untrimmed_end))
        # Keep the aligner's acoustic estimate throughout the overlap context.
        # Clamping to the ownership core was the old source of seam drift.
        start_ms = max(chunk_start, min(chunk_end, untrimmed_start))
        end_ms = max(chunk_start, min(chunk_end, untrimmed_end))
        clamped_boundaries.extend((start_ms, end_ms))
        if start_ms != untrimmed_start or end_ms != untrimmed_end:
            window_clamped.add(word_index)
            max_window_clamp_ms = max(
                max_window_clamp_ms,
                abs(start_ms - untrimmed_start),
                abs(end_ms - untrimmed_end),
            )

    if raw_boundaries and (
        all(value <= chunk_start for value in raw_boundaries)
        or all(value >= chunk_end for value in raw_boundaries)
    ):
        raise _AlignmentRejected("collapsed_timestamp_range")

    # Project all boundaries together.  Odd boundaries are word ends and need
    # one millisecond after their starts; the boundary between adjacent words
    # may be equal.  If the forward pass reaches beyond the sealed WAV, a
    # backward pass packs the plateau against the right edge without overlap.
    projected: list[int] = []
    for boundary_index, value in enumerate(clamped_boundaries):
        minimum_gap = 1 if boundary_index % 2 else 0
        projected.append(
            max(
                value,
                projected[-1] + minimum_gap if projected else chunk_start,
            )
        )
    if projected and projected[-1] > chunk_end:
        projected[-1] = chunk_end
        for boundary_index in range(len(projected) - 2, -1, -1):
            next_gap = 1 if (boundary_index + 1) % 2 else 0
            projected[boundary_index] = min(
                projected[boundary_index],
                projected[boundary_index + 1] - next_gap,
            )
    if not projected or projected[0] < chunk_start:
        raise _AlignmentRejected("collapsed_timestamp_range")

    intra_block_adjusted: set[int] = set()
    quantization_repaired: set[int] = set()
    max_intra_block_shift_ms = 0
    max_quantization_repair_ms = 0
    for word_index in range(len(raw_times)):
        raw_pair = clamped_boundaries[word_index * 2 : word_index * 2 + 2]
        fixed_pair = projected[word_index * 2 : word_index * 2 + 2]
        shift = max(abs(left - right) for left, right in zip(raw_pair, fixed_pair))
        if shift:
            intra_block_adjusted.add(word_index)
            max_intra_block_shift_ms = max(max_intra_block_shift_ms, shift)
        if word_index in raw_zero_duration:
            quantization_repaired.add(word_index)
            max_quantization_repair_ms = max(max_quantization_repair_ms, shift)
        if fixed_pair[1] <= fixed_pair[0]:
            raise _AlignmentRejected("collapsed_timestamp_range")

    cursor = 0
    words: list[WordTimestamp] = []
    for word_index, key in enumerate(aligned_keys):
        source_start = raw_indices[cursor]
        cursor += len(key)
        source_end = raw_indices[cursor - 1] + 1
        start_ms, end_ms = projected[word_index * 2 : word_index * 2 + 2]
        words.append(
            WordTimestamp(
                text=block.text[source_start:source_end],
                start_ms=start_ms,
                end_ms=end_ms,
                source_start=block.source_start + source_start,
                source_end=block.source_start + source_end,
                chunk_id=block.chunk.id,
            )
        )
    return words, _AdjustmentStats(
        window_clamped_word_indices=frozenset(window_clamped),
        intra_block_monotonic_adjusted_word_indices=frozenset(
            intra_block_adjusted
        ),
        quantization_repaired_word_indices=frozenset(quantization_repaired),
        raw_zero_duration_word_indices=frozenset(raw_zero_duration),
        max_window_clamp_ms=max_window_clamp_ms,
        max_intra_block_shift_ms=max_intra_block_shift_ms,
        max_quantization_repair_ms=max_quantization_repair_ms,
    )


def _repair_block_seam(
    words: Sequence[WordTimestamp],
    *,
    previous_end_ms: int | None,
    window_end_ms: int,
) -> tuple[list[WordTimestamp], _AdjustmentStats]:
    """Make adjacent contextual windows monotonic without retiming interiors.

    A low-energy ownership boundary normally leaves adjacent words disjoint.
    If two contextual estimates overlap, only the leading edge of the new
    block is trimmed.  Later interior timings remain the aligner's values.
    """

    if previous_end_ms is None or not words:
        return list(words), _AdjustmentStats()
    repaired: list[WordTimestamp] = []
    cursor = previous_end_ms
    adjusted: set[int] = set()
    max_shift_ms = 0
    for word_index, word in enumerate(words):
        start_ms = word.start_ms
        end_ms = word.end_ms
        if start_ms < cursor:
            original_start_ms = start_ms
            start_ms = cursor
            end_ms = max(start_ms, end_ms)
            adjusted.add(word_index)
            max_shift_ms = max(max_shift_ms, start_ms - original_start_ms)
        if end_ms <= start_ms:
            if start_ms >= window_end_ms:
                raise _AlignmentRejected("collapsed_timestamp_range")
            end_ms = start_ms + 1
            adjusted.add(word_index)
        if start_ms > window_end_ms or end_ms > window_end_ms:
            raise _AlignmentRejected("seam_repair_exceeds_audio_window")
        repaired.append(replace(word, start_ms=start_ms, end_ms=end_ms))
        cursor = end_ms
    return repaired, _AdjustmentStats(
        seam_adjusted_word_indices=frozenset(adjusted),
        max_seam_shift_ms=max_shift_ms,
    )


def _fallback_words(block: _TextBlock) -> list[WordTimestamp]:
    spans = _source_word_spans(block.text)
    if not spans:
        return []
    window_start_ms = round(block.chunk.start * 1000)
    window_end_ms = round(block.chunk.end * 1000)
    start_ms = max(window_start_ms, min(window_end_ms, block.coarse_start_ms))
    # A deterministic fallback must still produce editable, positive-duration
    # word ranges. Expand a collapsed coarse span inside the sealed audio
    # window instead of persisting zero-length words.
    end_ms = min(window_end_ms, max(start_ms + len(spans), block.coarse_end_ms))
    if end_ms - start_ms < len(spans):
        start_ms = max(window_start_ms, end_ms - len(spans))
    if end_ms - start_ms < len(spans):
        raise _AlignmentRejected("collapsed_timestamp_range")
    duration_ms = end_ms - start_ms
    if duration_ms < len(spans):
        raise _AlignmentRejected("collapsed_timestamp_range")
    weights = [max(1, len(_projection(item.text)[0])) for item in spans]
    total_weight = sum(weights)
    distributable_ms = duration_ms - len(spans)
    cumulative_weight = 0
    boundary_ms = start_ms
    output: list[WordTimestamp] = []
    for index, (item, weight) in enumerate(zip(spans, weights), start=1):
        word_start = boundary_ms
        cumulative_weight += weight
        # Every word receives one guaranteed millisecond.  Only the remaining
        # duration is distributed by token weight, so integer rounding cannot
        # create overlap, zero duration, or a boundary beyond the sealed WAV.
        word_end = (
            start_ms
            + index
            + (distributable_ms * cumulative_weight) // total_weight
        )
        boundary_ms = word_end
        output.append(
            WordTimestamp(
                text=item.text,
                start_ms=word_start,
                end_ms=word_end,
                source_start=block.source_start + item.start,
                source_end=block.source_start + item.end,
                chunk_id=block.chunk.id,
            )
        )
    if not output or output[-1].end_ms != end_ms:
        raise _AlignmentRejected("collapsed_timestamp_range")
    return output


def _partition(start_ms: int, end_ms: int, count: int) -> list[tuple[int, int]]:
    if count <= 0:
        return []
    end_ms = max(start_ms, end_ms)
    return [
        (
            start_ms + round((end_ms - start_ms) * index / count),
            start_ms + round((end_ms - start_ms) * (index + 1) / count),
        )
        for index in range(count)
    ]


def _characters_for_block(
    block: _TextBlock,
    words: Sequence[WordTimestamp],
    *,
    minimum_start_ms: int | None = None,
) -> list[CharacterTimestamp]:
    output: list[CharacterTimestamp] = []
    cursor = 0
    time_cursor = max(
        block.coarse_start_ms,
        minimum_start_ms if minimum_start_ms is not None else block.coarse_start_ms,
    )

    def append_span(raw_start: int, raw_end: int, start_ms: int, end_ms: int) -> None:
        for raw_index, timing in zip(
            range(raw_start, raw_end),
            _partition(start_ms, end_ms, raw_end - raw_start),
        ):
            output.append(
                CharacterTimestamp(
                    text=block.text[raw_index],
                    start_ms=timing[0],
                    end_ms=timing[1],
                    source_index=block.source_start + raw_index,
                    chunk_id=block.chunk.id,
                )
            )

    for word in words:
        local_start = word.source_start - block.source_start
        local_end = word.source_end - block.source_start
        if local_start < cursor or local_end < local_start or local_end > len(block.text):
            raise _AlignmentRejected("word_source_spans_not_monotonic")
        gap_end_time = max(time_cursor, word.start_ms)
        append_span(cursor, local_start, time_cursor, gap_end_time)
        word_start_time = max(gap_end_time, word.start_ms)
        word_end_time = max(word_start_time, word.end_ms)
        append_span(local_start, local_end, word_start_time, word_end_time)
        cursor = local_end
        time_cursor = word_end_time

    trailing_end = max(time_cursor, block.coarse_end_ms)
    append_span(cursor, len(block.text), time_cursor, trailing_end)
    return output


_STRONG_BREAKS = frozenset("。！？!?；;\n")
_SOFT_BREAKS = frozenset("，,、：:")


def _is_non_acoustic_boundary_character(value: str) -> bool:
    """Return whether a transcript character has no independent speech edge.

    Forced alignment still keeps punctuation/whitespace in the immutable
    character clock so source offsets remain exact.  Subtitle display edges,
    however, must not inherit a multi-second interpolation interval merely
    because an unspoken punctuation mark sits before the next utterance.
    Symbols are deliberately retained: a currency sign or emoji may be spoken.
    """

    return bool(value) and all(
        character.isspace() or unicodedata.category(character).startswith("P")
        for character in value
    )


def _display_end_ms(
    characters: Sequence[CharacterTimestamp], start: int, boundary: int
) -> int:
    """Trim only implausibly long punctuation-owned display tails."""

    owned = characters[start:boundary]
    for character in reversed(owned):
        if not _is_non_acoustic_boundary_character(character.text):
            raw_end_ms = owned[-1].end_ms
            if raw_end_ms - character.end_ms > MAX_NON_ACOUSTIC_EDGE_EXTENSION_MS:
                return character.end_ms
            return raw_end_ms
    return owned[-1].end_ms


def _break_rank(text: str, boundary: int, word_boundaries: set[int]) -> int:
    index = boundary - 1
    while index >= 0 and text[index].isspace() and text[index] != "\n":
        index -= 1
    if index >= 0 and text[index] in _STRONG_BREAKS:
        return 3
    if index >= 0 and text[index] in _SOFT_BREAKS:
        return 2
    if boundary in word_boundaries:
        return 1
    return 0


def _coalesce_non_acoustic_only_cues(
    cues: Sequence[SubtitleCue],
    *,
    characters: Sequence[CharacterTimestamp],
    source_offset: int,
    starting_index: int,
    max_cue_ms: int,
) -> tuple[SubtitleCue, ...]:
    """Attach leading punctuation/space display slices to adjacent speech.

    Their source characters and immutable character clock remain untouched.
    Only the display grouping changes, and an attached trailing mark never
    extends the preceding acoustic cue into the interpolated silent gap.
    """

    output: list[SubtitleCue] = []
    leading: list[SubtitleCue] = []
    for cue_index, cue in enumerate(cues):
        prefix_width = 0
        for character in cue.text:
            if not _is_non_acoustic_boundary_character(character):
                break
            prefix_width += 1
        if output and prefix_width:
            previous = output[-1]
            entirely_non_acoustic = prefix_width == len(cue.text)
            preserve_final_acoustic_overflow = False
            if entirely_non_acoustic and cue_index == len(cues) - 1:
                previous_start = previous.source_start - source_offset
                previous_end = previous.source_end - source_offset
                acoustic_end_ms = max(
                    previous.start_ms + 1,
                    _display_end_ms(characters, previous_start, previous_end),
                )
                preserve_final_acoustic_overflow = acoustic_end_ms > previous.end_ms
            if preserve_final_acoustic_overflow:
                # The previous spoken character, rather than this mark,
                # exceeded the display ceiling. Leave the mark separate so
                # the Wenet media-end guard can retain a verified final
                # acoustic edge without generalising that exception.
                output.append(cue)
                continue
            prefix = cue.text[:prefix_width]
            new_source_start = cue.source_start + prefix_width
            output[-1] = replace(
                previous,
                text=previous.text + prefix,
                source_end=new_source_start,
            )
            if entirely_non_acoustic:
                continue
            local_start = new_source_start - source_offset
            acoustic_start_ms = characters[local_start].start_ms
            cue = replace(
                cue,
                start_ms=max(cue.start_ms, acoustic_start_ms),
                end_ms=max(max(cue.start_ms, acoustic_start_ms) + 1, cue.end_ms),
                text=cue.text[prefix_width:],
                source_start=new_source_start,
            )
        if _is_non_acoustic_boundary_character(cue.text):
            leading.append(cue)
            continue
        if leading:
            cue = replace(
                cue,
                text="".join(item.text for item in leading) + cue.text,
                source_start=leading[0].source_start,
            )
            leading.clear()
        output.append(cue)

    if leading:
        # A transcript containing only non-acoustic symbols has no speech edge
        # to inherit. Preserve it as one explicitly bounded display cue.
        first = leading[0]
        last = leading[-1]
        output.append(
            SubtitleCue(
                index=first.index,
                start_ms=first.start_ms,
                end_ms=min(
                    first.start_ms + max_cue_ms,
                    max(first.start_ms + 1, last.end_ms),
                ),
                text="".join(item.text for item in leading),
                source_start=first.source_start,
                source_end=last.source_end,
            )
        )

    return tuple(
        replace(cue, index=starting_index + index)
        for index, cue in enumerate(output)
    )


def regroup_word_timestamps(
    text: str,
    words: Sequence[WordTimestamp],
    characters: Sequence[CharacterTimestamp],
    *,
    min_cue_ms: int = MIN_CUE_MS,
    max_cue_ms: int = MAX_CUE_MS,
    target_cue_ms: int = TARGET_CUE_MS,
    starting_index: int = 1,
    source_offset: int = 0,
) -> tuple[SubtitleCue, ...]:
    """Regroup aligned words into deterministic 2--7 second subtitle cues.

    Word and punctuation boundaries are preferred.  Character boundaries are
    a deterministic last resort, so even an unusually long English word cannot
    cause transcript text to be dropped or rewritten.
    """

    if min_cue_ms <= 0 or max_cue_ms < min_cue_ms:
        raise ValueError("subtitle cue duration policy 無效")
    if not min_cue_ms <= target_cue_ms <= max_cue_ms:
        raise ValueError("target_cue_ms 必須喺 min/max 之間")
    if len(characters) != len(text):
        raise ValueError("character timestamps 數量同 transcript 唔一致")
    if "".join(item.text for item in characters) != text:
        raise ValueError("character timestamps 改變咗 transcript content")
    for index, character in enumerate(characters):
        if character.source_index != source_offset + index:
            raise ValueError("character source offsets 唔連續")

    if not text:
        return ()
    word_boundaries = {
        word.source_end - source_offset
        for word in words
        if source_offset < word.source_end <= source_offset + len(text)
    }
    cues: list[SubtitleCue] = []
    start = 0
    previous_end_ms = characters[0].start_ms
    while start < len(text):
        start_ms = max(previous_end_ms, characters[start].start_ms)
        allowed: list[int] = []
        for boundary in range(start + 1, len(text) + 1):
            end_ms = max(start_ms + 1, _display_end_ms(characters, start, boundary))
            if end_ms - start_ms <= max_cue_ms:
                allowed.append(boundary)
            elif allowed:
                break
        if not allowed:
            # One character carries a coarse interval longer than the ceiling.
            # Keep the character intact and cap only the display cue range.
            allowed = [start + 1]
        minimum = [
            boundary
            for boundary in allowed
            if max(start_ms + 1, _display_end_ms(characters, start, boundary))
            - start_ms
            >= min_cue_ms
        ]
        candidates = minimum or allowed
        boundary = max(
            candidates,
            key=lambda item: (
                _break_rank(text, item, word_boundaries),
                -abs(
                    max(start_ms + 1, _display_end_ms(characters, start, item))
                    - start_ms
                    - target_cue_ms
                ),
                item,
            ),
        )
        end_ms = max(start_ms + 1, _display_end_ms(characters, start, boundary))
        end_ms = min(start_ms + max_cue_ms, end_ms)
        cues.append(
            SubtitleCue(
                index=starting_index + len(cues),
                start_ms=start_ms,
                end_ms=end_ms,
                text=text[start:boundary],
                source_start=source_offset + start,
                source_end=source_offset + boundary,
            )
        )
        previous_end_ms = end_ms
        start = boundary
    grouped = _coalesce_non_acoustic_only_cues(
        cues,
        characters=characters,
        source_offset=source_offset,
        starting_index=starting_index,
        max_cue_ms=max_cue_ms,
    )
    if "".join(item.text for item in grouped) != text:
        raise AssertionError("cue regrouping must preserve transcript content")
    return grouped


def _fallback_code(exc: BaseException) -> str:
    if isinstance(exc, _AlignmentRejected):
        return str(exc)
    # Never copy an exception message: third-party failures can echo the input
    # transcript.  The class name is sufficient for technical diagnosis.
    return f"alignment_runtime_error:{type(exc).__name__}"


class QwenForcedTimestampAligner:
    """Align chosen transcript text against mono 16 kHz disk chunks."""

    def __init__(
        self,
        model_path: str | Path,
        *,
        model_id: str = FORCED_ALIGNER_MODEL_ID,
        language: str = "Cantonese",
        aligner_factory: AlignerFactory | None = None,
        audio_loader: AudioLoader | None = None,
        cleanup: Cleanup | None = None,
    ) -> None:
        self.model_path = Path(model_path)
        self.model_id = model_id
        self.language = language
        self._aligner_factory = aligner_factory or _default_aligner_factory
        self._audio_loader = audio_loader or _default_audio_loader
        self._cleanup = cleanup or release_forced_aligner_memory

    def align(
        self,
        chunks: Iterable[Any],
        chosen_segments: Iterable[Any],
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
        resume_chunks: Iterable[Any] = (),
        chunk_completed: ChunkCompleted | None = None,
    ) -> ForcedTimestampResult:
        model_path = validate_local_forced_aligner_model(self.model_path)
        items = _coerce_chunks(chunks)
        segments = [_coerce_segment(value) for value in chosen_segments]
        final_text = "".join(item.text for item in segments)
        blocks = _build_blocks(items, segments)
        nonempty_blocks = [block for block in blocks if block.text]
        resumed = [_coerce_resumed_chunk(value) for value in resume_chunks]
        if len(resumed) > len(nonempty_blocks):
            raise ValueError("resume chunks 唔係 expected text blocks 嘅連續 prefix")
        for saved, expected in zip(resumed, nonempty_blocks):
            _validate_resumed_chunk(saved, expected)

        aligner: Any | None = None
        all_words = [word for item in resumed for word in item.words]
        all_characters = [character for item in resumed for character in item.characters]
        chunk_audits = [item.audit for item in resumed]
        fallback_reasons: list[str] = []
        for item in resumed:
            reason = item.audit.fallback_reason
            if reason is not None and reason not in fallback_reasons:
                fallback_reasons.append(reason)
        try:
            if cancelled and cancelled():
                raise ASRCancelled("已取消 forced timestamp alignment")
            remaining_blocks = nonempty_blocks[len(resumed) :]
            for index, block in enumerate(
                remaining_blocks, start=len(resumed) + 1
            ):
                if cancelled and cancelled():
                    raise ASRCancelled("已取消 forced timestamp alignment")
                if progress is not None:
                    progress(
                        {
                            "phase": "forced_alignment",
                            "chunk_id": block.chunk.id,
                            "chunk_index": index,
                            "chunk_total": len(nonempty_blocks),
                            "progress": (index - 1) / len(nonempty_blocks),
                        }
                    )

                fallback_reason = block.fallback_reason
                intrinsic_adjustments = _AdjustmentStats()
                if fallback_reason is not None:
                    words = _fallback_words(block)
                else:
                    try:
                        if aligner is None:
                            aligner = self._aligner_factory(str(model_path))
                        audio = self._audio_loader(block.chunk.path, TARGET_SAMPLE_RATE)
                        aligned = aligner.align(audio, block.text, self.language)
                        words, intrinsic_adjustments = _forced_words(
                            block, list(aligned or ())
                        )
                        if not words and block.text:
                            fallback_reason = "transcript_has_no_alignable_tokens"
                    except ASRCancelled:
                        raise
                    except Exception as exc:
                        fallback_reason = _fallback_code(exc)
                        words = _fallback_words(block)

                if fallback_reason is not None:
                    if fallback_reason not in fallback_reasons:
                        fallback_reasons.append(fallback_reason)
                    if not words:
                        words = _fallback_words(block)
                previous_output_end_ms = max(
                    all_words[-1].end_ms if all_words else 0,
                    all_characters[-1].end_ms if all_characters else 0,
                )
                try:
                    words, seam_adjustments = _repair_block_seam(
                        words,
                        previous_end_ms=(
                            previous_output_end_ms
                            if all_words or all_characters
                            else None
                        ),
                        window_end_ms=round(block.chunk.end * 1000),
                    )
                    characters = _characters_for_block(
                        block,
                        words,
                        minimum_start_ms=(
                            previous_output_end_ms
                            if all_words or all_characters
                            else None
                        ),
                    )
                except _AlignmentRejected as exc:
                    fallback_reason = _fallback_code(exc)
                    if fallback_reason not in fallback_reasons:
                        fallback_reasons.append(fallback_reason)
                    words = _fallback_words(block)
                    intrinsic_adjustments = _AdjustmentStats()
                    words, seam_adjustments = _repair_block_seam(
                        words,
                        previous_end_ms=(
                            previous_output_end_ms
                            if all_words or all_characters
                            else None
                        ),
                        window_end_ms=round(block.chunk.end * 1000),
                    )
                    characters = _characters_for_block(
                        block,
                        words,
                        minimum_start_ms=(
                            previous_output_end_ms
                            if all_words or all_characters
                            else None
                        ),
                    )

                all_words.extend(words)
                all_characters.extend(characters)
                zero_duration_word_count = sum(
                    item.end_ms <= item.start_ms for item in words
                )
                if zero_duration_word_count:
                    raise _AlignmentRejected("collapsed_timestamp_range")
                clipped = len(
                    intrinsic_adjustments.adjusted_word_indices
                    | seam_adjustments.adjusted_word_indices
                )
                audit = ChunkTimestampAudit(
                    chunk_id=block.chunk.id,
                    method=(
                        "deterministic_coarse_fallback"
                        if fallback_reason is not None
                        else FORCED_ALIGNER_METHOD
                    ),
                    core_start_ms=round(block.chunk.transcript_start * 1000),
                    core_end_ms=round(block.chunk.transcript_end * 1000),
                    word_count=len(words),
                    character_count=len(characters),
                    clipped_word_count=clipped,
                    window_clamped_word_count=(
                        intrinsic_adjustments.window_clamped_word_count
                    ),
                    intra_block_monotonic_adjusted_word_count=(
                        intrinsic_adjustments.intra_block_monotonic_adjusted_word_count
                    ),
                    seam_adjusted_word_count=seam_adjustments.seam_adjusted_word_count,
                    max_window_clamp_ms=intrinsic_adjustments.max_window_clamp_ms,
                    max_intra_block_shift_ms=(
                        intrinsic_adjustments.max_intra_block_shift_ms
                    ),
                    max_seam_shift_ms=seam_adjustments.max_seam_shift_ms,
                    raw_zero_duration_word_count=(
                        intrinsic_adjustments.raw_zero_duration_word_count
                    ),
                    quantization_repaired_word_count=(
                        intrinsic_adjustments.quantization_repaired_word_count
                    ),
                    max_quantization_repair_ms=(
                        intrinsic_adjustments.max_quantization_repair_ms
                    ),
                    zero_duration_word_count=zero_duration_word_count,
                    fallback_reason=fallback_reason,
                )
                chunk_audits.append(audit)
                completed = ForcedTimestampChunkResult(
                    chunk_id=block.chunk.id,
                    text=block.text,
                    source_start=block.source_start,
                    source_end=block.source_end,
                    words=tuple(words),
                    characters=tuple(characters),
                    audit=audit,
                )
                if chunk_completed is not None:
                    chunk_completed(completed)
                if cancelled and cancelled():
                    raise ASRCancelled("已取消 forced timestamp alignment")
                if progress is not None:
                    progress(
                        {
                            "phase": "forced_alignment",
                            "chunk_id": block.chunk.id,
                            "chunk_index": index,
                            "chunk_total": len(nonempty_blocks),
                            "progress": index / len(nonempty_blocks),
                            "word_count": len(words),
                            "character_count": len(characters),
                            "fallback": fallback_reason is not None,
                        }
                    )
        finally:
            self._cleanup(aligner)

        if "".join(item.text for item in all_characters) != final_text:
            raise AssertionError("forced timestamps must preserve the chosen transcript")
        all_cues = regroup_word_timestamps(final_text, all_words, all_characters)
        if "".join(item.text for item in all_cues) != final_text:
            raise AssertionError("subtitle cues must preserve the chosen transcript")
        method = FORCED_ALIGNER_METHOD
        if fallback_reasons:
            method = (
                "deterministic_coarse_fallback"
                if all(item.fallback_reason for item in chunk_audits)
                else "qwen3_forced_aligner_with_fallback"
            )
        return ForcedTimestampResult(
            text=final_text,
            words=tuple(all_words),
            characters=tuple(all_characters),
            cues=tuple(all_cues),
            audit=ForcedTimestampAudit(
                method=method,
                model=self.model_id,
                policy_version=FORCED_TIMESTAMP_POLICY_VERSION,
                cue_policy=(
                    "word/punctuation boundaries preferred; "
                    f"target={TARGET_CUE_MS}ms min={MIN_CUE_MS}ms max={MAX_CUE_MS}ms; "
                    "character-boundary fallback"
                ),
                fallback_reasons=tuple(fallback_reasons),
                chunks=tuple(chunk_audits),
            ),
        )


__all__ = [
    "CharacterTimestamp",
    "ChunkTimestampAudit",
    "FORCED_ALIGNER_METHOD",
    "FORCED_ALIGNER_MODEL_ID",
    "FORCED_TIMESTAMP_POLICY_VERSION",
    "ForcedTimestampAudit",
    "ForcedTimestampChunkResult",
    "ForcedTimestampResult",
    "MAX_CUE_MS",
    "MIN_CUE_MS",
    "QwenForcedTimestampAligner",
    "SubtitleCue",
    "TARGET_CUE_MS",
    "WordTimestamp",
    "regroup_word_timestamps",
    "release_forced_aligner_memory",
    "validate_local_forced_aligner_model",
]
