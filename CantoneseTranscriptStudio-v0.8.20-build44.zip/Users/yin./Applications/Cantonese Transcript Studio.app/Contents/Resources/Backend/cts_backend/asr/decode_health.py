"""Deterministic decode termination evidence, independent of transcript text."""

from __future__ import annotations

from typing import Any, Mapping


PRIMARY_DECODE_HEALTH_POLICY = "primary-decode-health-v1"


def primary_decode_health(
    metadata: Mapping[str, Any], *, truncated: bool = False
) -> dict[str, Any]:
    """Inspect current top-level and model-chunk termination evidence only.

    Missing or unfamiliar reasons remain unknown; legacy ASR metadata is not
    declared healthy. Diagnostic timing, memory, and transcript text have no
    effect. This reports a failed decode, not transcript correctness or recovery.
    """
    finish_reasons: list[dict[str, str]] = []
    truncation_sources = ["segment.truncated"] if truncated is True else []
    unknown_sources: list[str] = []

    def inspect(node: Mapping[str, Any], path: str) -> None:
        reason = node.get("finish_reason")
        reason_path = f"{path}.finish_reason"
        if isinstance(reason, str) and reason:
            finish_reasons.append({"source": reason_path, "value": reason})
        if reason not in ("eos", "repetition", "length"):
            unknown_sources.append(reason_path)
        if node.get("truncated") is True:
            truncation_sources.append(f"{path}.truncated")
        chunks = node.get("model_chunks")
        if isinstance(chunks, (list, tuple)):
            for index, chunk in enumerate(chunks):
                chunk_path = f"{path}.model_chunks[{index}]"
                if isinstance(chunk, Mapping):
                    inspect(chunk, chunk_path)
                else:
                    unknown_sources.append(chunk_path)
        elif chunks is not None:
            unknown_sources.append(f"{path}.model_chunks")

    inspect(metadata, "metadata")
    failed = bool(truncation_sources) or any(
        item["value"] in ("repetition", "length") for item in finish_reasons
    )
    return {
        "policy": PRIMARY_DECODE_HEALTH_POLICY,
        "version": 1,
        "status": "failed" if failed else "unknown" if unknown_sources else "healthy",
        "failed": failed,
        "finish_reasons": finish_reasons,
        "truncation_sources": truncation_sources,
        "unknown_sources": unknown_sources,
    }
