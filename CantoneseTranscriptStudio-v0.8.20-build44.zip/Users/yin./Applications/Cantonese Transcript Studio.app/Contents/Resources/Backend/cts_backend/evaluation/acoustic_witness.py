"""Exact, abstaining dual-acoustic token witness calibration helpers.

This module never rewrites transcript text and never generates production
timestamps.  It maps literal token strings from two independent local models
back to immutable source spans only when a contiguous run is unique inside its
reconciled segment.  Any ambiguity, tokenisation mismatch, or timing
disagreement causes abstention.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence


DUAL_WITNESS_POLICY_VERSION = "dual-acoustic-token-witness-v1-calibration"


@dataclass(frozen=True)
class WitnessSegment:
    index: int
    source_start: int
    source_end: int
    start_ms: int
    end_ms: int


@dataclass(frozen=True)
class WitnessToken:
    text: str
    start_ms: int


@dataclass(frozen=True)
class ExactTokenAnchor:
    segment_index: int
    source_start: int
    source_end: int
    text: str
    start_ms: int
    qualifying_run_tokens: int


@dataclass(frozen=True)
class DualTokenAnchor:
    segment_index: int
    source_start: int
    source_end: int
    text: str
    first_start_ms: int
    second_start_ms: int

    @property
    def disagreement_ms(self) -> int:
        return abs(self.first_start_ms - self.second_start_ms)


def _occurrences(haystack: str, needle: str) -> tuple[int, ...]:
    if not needle:
        return ()
    output: list[int] = []
    offset = 0
    while True:
        found = haystack.find(needle, offset)
        if found < 0:
            return tuple(output)
        output.append(found)
        offset = found + 1


def _validate_inputs(
    source_text: str,
    segments: Sequence[WitnessSegment],
    tokens: Sequence[WitnessToken],
) -> None:
    if not source_text:
        raise ValueError("source_text must not be empty")
    previous_source_end = 0
    previous_segment_start = -1
    for position, segment in enumerate(segments):
        if segment.index < 0:
            raise ValueError("segment index must be non-negative")
        if segment.source_start != previous_source_end:
            raise ValueError("segment source ranges must be contiguous")
        if not segment.source_start < segment.source_end <= len(source_text):
            raise ValueError("segment source range is invalid")
        if not 0 <= segment.start_ms < segment.end_ms:
            raise ValueError("segment time range is invalid")
        if position and segment.start_ms < previous_segment_start:
            raise ValueError("segment times must be monotonic")
        previous_source_end = segment.source_end
        previous_segment_start = segment.start_ms
    if previous_source_end != len(source_text):
        raise ValueError("segments must cover the complete source text")
    previous_token_start = -1
    for token in tokens:
        if not token.text:
            raise ValueError("witness token must not be empty")
        if token.start_ms < previous_token_start:
            raise ValueError("witness token timestamps must be monotonic")
        previous_token_start = token.start_ms


def exact_unique_run_anchors(
    source_text: str,
    segments: Sequence[WitnessSegment],
    tokens: Sequence[WitnessToken],
    *,
    minimum_run_tokens: int = 3,
) -> tuple[ExactTokenAnchor, ...]:
    """Map literal witness tokens to source spans with strict abstention.

    Tokens are not case-folded, converted between writing systems, stripped,
    or fuzzily compared.  Whitespace-only tokens delimit runs and are never
    anchors.  A token is returned only when every qualifying unique run that
    contains it assigns the same exact source span.
    """

    if minimum_run_tokens < 2:
        raise ValueError("minimum_run_tokens must be at least two")
    _validate_inputs(source_text, segments, tokens)
    output: list[ExactTokenAnchor] = []

    for segment_position, segment in enumerate(segments):
        segment_text = source_text[segment.source_start : segment.source_end]
        is_last = segment_position == len(segments) - 1
        selected = [
            (token_index, token)
            for token_index, token in enumerate(tokens)
            if segment.start_ms <= token.start_ms
            and (token.start_ms <= segment.end_ms if is_last else token.start_ms < segment.end_ms)
        ]
        candidates: dict[int, list[tuple[int, int, int]]] = {}
        block: list[tuple[int, WitnessToken]] = []

        def consume_block() -> None:
            if len(block) < minimum_run_tokens:
                return
            for run_start in range(len(block)):
                combined = ""
                for run_end in range(run_start, len(block)):
                    combined += block[run_end][1].text
                    run_count = run_end - run_start + 1
                    if run_count < minimum_run_tokens:
                        continue
                    positions = _occurrences(segment_text, combined)
                    if len(positions) != 1:
                        continue
                    cursor = segment.source_start + positions[0]
                    for token_index, token in block[run_start : run_end + 1]:
                        span = (cursor, cursor + len(token.text), run_count)
                        candidates.setdefault(token_index, []).append(span)
                        cursor += len(token.text)

        for item in selected:
            if item[1].text.isspace():
                consume_block()
                block = []
            else:
                block.append(item)
        consume_block()

        for token_index, spans in candidates.items():
            unique_spans = {(start, end) for start, end, _ in spans}
            if len(unique_spans) != 1:
                continue
            source_start, source_end = next(iter(unique_spans))
            token = tokens[token_index]
            if source_text[source_start:source_end] != token.text:
                raise AssertionError("exact token mapping changed source text")
            output.append(
                ExactTokenAnchor(
                    segment_index=segment.index,
                    source_start=source_start,
                    source_end=source_end,
                    text=token.text,
                    start_ms=token.start_ms,
                    qualifying_run_tokens=max(run_count for _, _, run_count in spans),
                )
            )

    return tuple(
        sorted(
            output,
            key=lambda item: (
                item.segment_index,
                item.source_start,
                item.source_end,
                item.start_ms,
            ),
        )
    )


def dual_acoustic_token_anchors(
    source_text: str,
    segments: Sequence[WitnessSegment],
    first_tokens: Sequence[WitnessToken],
    second_tokens: Sequence[WitnessToken],
    *,
    minimum_run_tokens: int = 3,
    maximum_disagreement_ms: int = 250,
) -> tuple[DualTokenAnchor, ...]:
    """Return exact same-span anchors where two acoustic witnesses agree."""

    if maximum_disagreement_ms < 0:
        raise ValueError("maximum_disagreement_ms must be non-negative")
    first = exact_unique_run_anchors(
        source_text, segments, first_tokens, minimum_run_tokens=minimum_run_tokens
    )
    second = exact_unique_run_anchors(
        source_text, segments, second_tokens, minimum_run_tokens=minimum_run_tokens
    )
    first_by_span = {
        (item.segment_index, item.source_start, item.source_end, item.text): item
        for item in first
    }
    second_by_span = {
        (item.segment_index, item.source_start, item.source_end, item.text): item
        for item in second
    }
    output: list[DualTokenAnchor] = []
    for key in sorted(first_by_span.keys() & second_by_span.keys()):
        first_item = first_by_span[key]
        second_item = second_by_span[key]
        if abs(first_item.start_ms - second_item.start_ms) > maximum_disagreement_ms:
            continue
        output.append(
            DualTokenAnchor(
                segment_index=first_item.segment_index,
                source_start=first_item.source_start,
                source_end=first_item.source_end,
                text=first_item.text,
                first_start_ms=first_item.start_ms,
                second_start_ms=second_item.start_ms,
            )
        )
    return tuple(output)


def coerce_segments(values: Sequence[Mapping[str, object]]) -> tuple[WitnessSegment, ...]:
    return tuple(
        WitnessSegment(
            index=int(value["index"]),
            source_start=int(value["source_start"]),
            source_end=int(value["source_end"]),
            start_ms=int(value["start_ms"]),
            end_ms=int(value["end_ms"]),
        )
        for value in values
    )


def coerce_tokens(values: Sequence[Mapping[str, object]]) -> tuple[WitnessToken, ...]:
    return tuple(
        WitnessToken(text=str(value["token"]), start_ms=int(value["timestamp_ms"]))
        for value in values
    )


__all__ = [
    "DUAL_WITNESS_POLICY_VERSION",
    "DualTokenAnchor",
    "ExactTokenAnchor",
    "WitnessSegment",
    "WitnessToken",
    "coerce_segments",
    "coerce_tokens",
    "dual_acoustic_token_anchors",
    "exact_unique_run_anchors",
]
