"""Safe, app-owned local runtime lease for Live AI Cue.

The live-caption path has a stricter memory budget than offline Accuracy Mode:
Whisper Small and Large v3 must remain responsive while a cue is being
generated.  This module owns only CTS's dedicated small Gemma identifier.  It
never downloads a model, never probes a non-loopback endpoint, and never
stops the process-global LM Studio server.

Failure is deliberately fail-open for captions: callers receive a compact,
text-free unavailable status and continue normal live ASR without a cue.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Protocol, Sequence

from ..alignment import LMStudioLifecycle
from ..resource_guard import parse_memory_pressure
from .assistant import (
    DEFAULT_LIVE_ASSISTANT_MODEL,
    LIVE_ASSISTANT_API_MODEL,
    LIVE_ASSISTANT_POLICY_VERSION,
    LiveAssistantConfig,
)


# This is intentionally separate from the 12B post-ASR arbiter.  E2B is the
# only model CTS will ever auto-load for an optional, low-latency live cue.
LIVE_ASSISTANT_MANAGED_MODEL = DEFAULT_LIVE_ASSISTANT_MODEL
LIVE_ASSISTANT_MANAGED_IDENTIFIER = LIVE_ASSISTANT_API_MODEL
LIVE_ASSISTANT_RUNTIME_POLICY_VERSION = "2026-08-25.1"

_LOW_MEMORY_DEVICE_BYTES = 20 * 1024**3
_VERY_LOW_MEMORY_DEVICE_BYTES = 12 * 1024**3
_LIVE_CONTEXT_LENGTH = 2_048
_LIVE_MODEL_TTL_SECONDS = 300
_THROTTLED_PAGES = re.compile(r"Pages throttled:\s*([0-9,]+)\.?", re.IGNORECASE)


Runner = Callable[..., subprocess.CompletedProcess[str]]


def read_total_memory_bytes(*, runner: Runner = subprocess.run) -> int | None:
    """Read the hardware memory size without any other telemetry."""

    try:
        result = runner(
            ["/usr/sbin/sysctl", "-n", "hw.memsize"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=10.0,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    raw = result.stdout.strip() if result.returncode == 0 else ""
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def should_use_lightweight_live_asr(
    assistant_runtime_requested: bool,
    total_memory_bytes: int | None,
) -> bool:
    """Choose single-Small live ASR when the optional answer lease is on.

    On a low-memory machine, Small + Large v3 resident Whisper servers leave
    the assistant pre-load gate below its required free percentage, so the
    cue can never start.  Keeping only Small resident (the validated 16 GB
    configuration) trades final-caption fidelity for a working answer card.
    Unknown machine size keeps the historical dual-engine behaviour; the
    assistant memory gate still protects the machine either way.
    """

    return (
        assistant_runtime_requested
        and total_memory_bytes is not None
        and total_memory_bytes <= _LOW_MEMORY_DEVICE_BYTES
    )


class _Lifecycle(Protocol):
    def prepare_arbiter(self) -> Mapping[str, object]: ...

    def release(self) -> Mapping[str, object]: ...


@dataclass(frozen=True)
class LiveAssistantMemoryReport:
    """Transcript-free memory decision consumed by the native status UI."""

    phase: str
    total_memory_bytes: int | None
    free_percentage: int | None
    throttled_pages: int | None
    required_free_percentage: int
    allowed: bool
    reasons: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "phase": self.phase,
            "total_memory_bytes": self.total_memory_bytes,
            "free_percentage": self.free_percentage,
            "throttled_pages": self.throttled_pages,
            "required_free_percentage": self.required_free_percentage,
            "allowed": self.allowed,
            "reasons": list(self.reasons),
        }


class LiveAssistantMemoryGate:
    """Read-only pre/post-load memory guard for concurrent live ASR + cue.

    Production creates Whisper Small/Large v3 (and Lazy Camman's speaker
    engine) before calling this gate, so the pre-load reading already includes
    the live-ASR working set.  On a 16 GB Apple-Silicon machine we then require
    at least 35% free before touching Gemma and at least 18% after it is
    resident, with no throttled VM pages.  The post-load gate catches runtime
    overhead that the model-file size alone cannot predict. Unknown telemetry
    fails closed for the optional cue only.
    """

    policy_version = LIVE_ASSISTANT_RUNTIME_POLICY_VERSION

    def __init__(self, *, runner: Runner = subprocess.run) -> None:
        self._runner = runner

    def _run(self, arguments: Sequence[str], *, timeout: float = 10.0) -> str:
        try:
            result = self._runner(
                list(arguments),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return ""
        return result.stdout.strip() if result.returncode == 0 else ""

    def _memory_bytes(self) -> int | None:
        return read_total_memory_bytes(runner=self._runner)

    def _free_percentage(self) -> int | None:
        return parse_memory_pressure(self._run(["/usr/bin/memory_pressure", "-Q"]))

    def _throttled_pages(self) -> int | None:
        raw = self._run(["/usr/bin/vm_stat"])
        match = _THROTTLED_PAGES.search(raw)
        if match is None:
            return None
        try:
            return int(match.group(1).replace(",", ""))
        except ValueError:
            return None

    @staticmethod
    def _required_percentage(total_memory_bytes: int | None, phase: str) -> int:
        if total_memory_bytes is not None and total_memory_bytes <= _VERY_LOW_MEMORY_DEVICE_BYTES:
            return 55 if phase == "before_load" else 30
        if total_memory_bytes is not None and total_memory_bytes <= _LOW_MEMORY_DEVICE_BYTES:
            return 35 if phase == "before_load" else 18
        return 25 if phase == "before_load" else 15

    def inspect(self, *, phase: str) -> LiveAssistantMemoryReport:
        if phase not in {"before_load", "after_load"}:
            raise ValueError("live assistant memory phase 無效")
        total_memory_bytes = self._memory_bytes()
        free_percentage = self._free_percentage()
        throttled_pages = self._throttled_pages()
        required = self._required_percentage(total_memory_bytes, phase)
        reasons: list[str] = []
        if total_memory_bytes is None:
            reasons.append("memory_size_unknown")
        if free_percentage is None:
            reasons.append("memory_pressure_unknown")
        elif free_percentage < required:
            reasons.append("insufficient_free_memory")
        if throttled_pages is None:
            reasons.append("memory_throttle_unknown")
        elif throttled_pages > 0:
            reasons.append("memory_pages_throttled")
        return LiveAssistantMemoryReport(
            phase=phase,
            total_memory_bytes=total_memory_bytes,
            free_percentage=free_percentage,
            throttled_pages=throttled_pages,
            required_free_percentage=required,
            allowed=not reasons,
            reasons=tuple(reasons),
        )


class LiveAssistantRuntimeManager:
    """Own the one small local Gemma lease used by an opted-in live session."""

    def __init__(
        self,
        config: LiveAssistantConfig,
        *,
        lifecycle_factory: Callable[..., _Lifecycle] = LMStudioLifecycle,
        memory_gate: LiveAssistantMemoryGate | None = None,
    ) -> None:
        self.config = config
        self._lifecycle_factory = lifecycle_factory
        self._memory_gate = memory_gate or LiveAssistantMemoryGate()
        self._lifecycle: _Lifecycle | None = None
        self._prepared = False
        self._runtime_state = "disabled" if not config.runtime_enabled else "not_prepared"
        self._unavailable_reason: str | None = None
        self._memory_report: LiveAssistantMemoryReport | None = None
        self._release_status: str | None = None

    @property
    def prepared(self) -> bool:
        return self._prepared

    @staticmethod
    def _compact_lifecycle_status(value: Mapping[str, object]) -> str:
        status = value.get("status")
        return str(status) if isinstance(status, str) and status else "status_unknown"

    def _set_unavailable(
        self,
        *,
        state: str,
        reason: str,
        report: LiveAssistantMemoryReport | None = None,
    ) -> dict[str, object]:
        self._prepared = False
        self._runtime_state = state
        self._unavailable_reason = reason
        if report is not None:
            self._memory_report = report
        return self.status()

    def prepare(self) -> dict[str, object]:
        """Load E2B only after the live-ASR memory gate has passed.

        It intentionally returns status instead of raising for expected local
        runtime issues.  That lets ``live.start`` continue to the caption
        engines without a cue when LM Studio is absent, busy, or unsafe.
        """

        if not self.config.runtime_enabled:
            self._runtime_state = "disabled"
            return self.status()
        if self._prepared:
            return self.status()
        if self.config.model != LIVE_ASSISTANT_MANAGED_MODEL:
            return self._set_unavailable(
                state="unsupported_model",
                reason="managed_model_required",
            )

        before = self._memory_gate.inspect(phase="before_load")
        self._memory_report = before
        if not before.allowed:
            return self._set_unavailable(
                state="memory_preflight_failed",
                reason="memory_preflight_failed",
                report=before,
            )

        try:
            lifecycle = self._lifecycle_factory(
                LIVE_ASSISTANT_MANAGED_MODEL,
                endpoint=self.config.endpoint,
                api_identifier=LIVE_ASSISTANT_MANAGED_IDENTIFIER,
                context_length=_LIVE_CONTEXT_LENGTH,
                parallel=1,
                ttl_seconds=_LIVE_MODEL_TTL_SECONDS,
            )
            lifecycle_event = lifecycle.prepare_arbiter()
        except Exception:
            # Do not expose command errors because development backends may
            # echo request text.  Captions still start normally.
            return self._set_unavailable(
                state="runtime_unavailable",
                reason="runtime_prepare_failed",
            )

        lifecycle_status = self._compact_lifecycle_status(lifecycle_event)
        if lifecycle_status not in {"loaded", "already_loaded"}:
            # A failed load may have left a partial CTS-owned identifier.  A
            # best-effort release touches only that identifier, never another
            # model or the process-global server.
            try:
                lifecycle.release()
            except Exception:
                pass
            return self._set_unavailable(
                state="runtime_unavailable",
                reason=lifecycle_status,
            )

        after = self._memory_gate.inspect(phase="after_load")
        self._memory_report = after
        if not after.allowed:
            try:
                lifecycle.release()
            except Exception:
                pass
            return self._set_unavailable(
                state="memory_postload_failed",
                reason="memory_postload_failed",
                report=after,
            )

        self._lifecycle = lifecycle
        self._prepared = True
        self._runtime_state = "prepared"
        self._unavailable_reason = None
        return self.status()

    def release(self) -> dict[str, object]:
        """Release only CTS's dedicated E2B model, preserving LM Studio."""

        lifecycle = self._lifecycle
        self._lifecycle = None
        self._prepared = False
        if lifecycle is None:
            if self._runtime_state == "prepared":
                self._runtime_state = "released"
            return self.status()
        try:
            result = lifecycle.release()
            self._release_status = self._compact_lifecycle_status(result)
            self._runtime_state = "released"
            self._unavailable_reason = None
        except Exception:
            self._release_status = "release_failed"
            self._runtime_state = "release_failed"
            self._unavailable_reason = "release_failed"
        return self.status()

    def status(self) -> dict[str, object]:
        memory = self._memory_report.to_dict() if self._memory_report is not None else None
        return {
            "enabled": self.config.runtime_enabled,
            "offline": True,
            "model": self.config.model if self.config.runtime_enabled else None,
            "policy_version": LIVE_ASSISTANT_POLICY_VERSION,
            "pending": False,
            "circuit_open": False,
            "circuit_retry_after_seconds": 0.0,
            "captions_in_memory": 0,
            "runtime_management": "app_managed",
            "prepared": self._prepared,
            "runtime_state": self._runtime_state,
            "unavailable_reason": self._unavailable_reason,
            "memory_gate": memory,
            "release_status": self._release_status,
            "asr_priority": True,
        }


__all__ = [
    "LIVE_ASSISTANT_MANAGED_IDENTIFIER",
    "LIVE_ASSISTANT_MANAGED_MODEL",
    "LIVE_ASSISTANT_RUNTIME_POLICY_VERSION",
    "LiveAssistantMemoryGate",
    "LiveAssistantMemoryReport",
    "LiveAssistantRuntimeManager",
    "read_total_memory_bytes",
    "should_use_lightweight_live_asr",
]
