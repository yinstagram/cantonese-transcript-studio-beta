"""A/B timing measurement for hash-bound semantic text spans.

The semantic choice is made elsewhere without timestamps.  This module takes
only already-eligible rows, projects their immutable base cue IDs to exact
transcript source ranges, and compares the same text edges in two sealed CTS
final envelopes.  It never changes either envelope.
"""

from __future__ import annotations

from collections import Counter
import hashlib
import math
from typing import Any, Mapping, Sequence

from .semantic_pairing import canonical_sha256


class SemanticTimingABError(ValueError):
    """The semantic timing A/B evidence is incomplete or inconsistent."""


def _mapping(value: object, label: str) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        raise SemanticTimingABError(f"{label} must be an object")
    return value


def _array(value: object, label: str) -> list[object]:
    if not isinstance(value, list):
        raise SemanticTimingABError(f"{label} must be an array")
    return value


def _text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise SemanticTimingABError(f"{label} must be non-empty text")
    return value


def _integer(value: object, label: str, *, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise SemanticTimingABError(f"{label} must be an integer")
    if minimum is not None and value < minimum:
        raise SemanticTimingABError(f"{label} is below its minimum")
    return value


def _validate_report(report: Mapping[str, object]) -> None:
    if report.get("schema") != "cts.o8-scoped-ai-semantic-timing-report/v1":
        raise SemanticTimingABError("semantic report schema mismatch")
    claimed = report.get("report_canonical_sha256")
    unsigned = dict(report)
    unsigned.pop("report_canonical_sha256", None)
    if not isinstance(claimed, str) or canonical_sha256(unsigned) != claimed:
        raise SemanticTimingABError("semantic report canonical hash mismatch")
    scope = _mapping(report.get("scope"), "semantic report scope")
    if (
        scope.get("video_id") != "O8IB7nao2K4"
        or scope.get("youtube_url") != "https://www.youtube.com/watch?v=O8IB7nao2K4"
        or scope.get("ai_semantic_validation") is not True
        or scope.get("human_confirmation") is not False
        or scope.get("production_wide_human_gold_claim") is not False
        or scope.get("broader_human_gold_gate_overwritten") is not False
        or scope.get("automatic_timing_mutation") is not False
        or scope.get("production_release_verdict") is not False
    ):
        raise SemanticTimingABError("semantic report scope is unsafe")


def _validate_final(final: Mapping[str, object], label: str) -> dict[str, object]:
    if final.get("complete") is not True:
        raise SemanticTimingABError(f"{label} final envelope is incomplete")
    value = _mapping(final.get("value"), f"{label} final value")
    sealed = {"fingerprint": final.get("fingerprint"), "value": value}
    if final.get("payload_sha256") != canonical_sha256(sealed):
        raise SemanticTimingABError(f"{label} final payload seal mismatch")
    transcript = _text(value.get("final_transcript"), f"{label} transcript")
    characters_raw = _array(value.get("character_timestamps"), f"{label} characters")
    if len(characters_raw) != len(transcript):
        raise SemanticTimingABError(f"{label} character count does not match transcript")
    characters: list[dict[str, object]] = []
    previous_start = -1
    for expected_index, raw in enumerate(characters_raw):
        row = dict(_mapping(raw, f"{label} character"))
        source_index = _integer(row.get("source_index"), f"{label} source index", minimum=0)
        start = _integer(row.get("start_ms"), f"{label} character start", minimum=0)
        end = _integer(row.get("end_ms"), f"{label} character end", minimum=start)
        if (
            source_index != expected_index
            or row.get("text") != transcript[expected_index]
            or start < previous_start
        ):
            raise SemanticTimingABError(f"{label} character projection is invalid")
        previous_start = start
        characters.append(row)
    segments_raw = _array(value.get("subtitle_segments"), f"{label} subtitle segments")
    segments: list[dict[str, object]] = []
    segment_ids: set[str] = set()
    previous_source_end = 0
    for raw in segments_raw:
        row = dict(_mapping(raw, f"{label} subtitle segment"))
        cue_id = _text(row.get("id"), f"{label} cue ID")
        source_start = _integer(row.get("source_start"), f"{label} cue source start", minimum=0)
        source_end = _integer(
            row.get("source_end"), f"{label} cue source end", minimum=source_start + 1
        )
        if (
            cue_id in segment_ids
            or source_start != previous_source_end
            or source_end > len(transcript)
            or row.get("text") != transcript[source_start:source_end]
        ):
            raise SemanticTimingABError(f"{label} subtitle source ownership is invalid")
        segment_ids.add(cue_id)
        previous_source_end = source_end
        segments.append(row)
    if previous_source_end != len(transcript):
        raise SemanticTimingABError(f"{label} subtitle projection does not cover transcript")
    return {
        "transcript": transcript,
        "characters": characters,
        "segments": segments,
        "value": value,
    }


def _percentile(values: Sequence[int], percentile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return float(ordered[0])
    rank = (len(ordered) - 1) * percentile
    lower = math.floor(rank)
    upper = math.ceil(rank)
    if lower == upper:
        return float(ordered[lower])
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (rank - lower)


def _stats(values: Sequence[int]) -> dict[str, float | int | None]:
    if not values:
        return {"count": 0, "median": None, "p90": None, "p95": None, "max": None}
    return {
        "count": len(values),
        "median": _percentile(values, 0.5),
        "p90": _percentile(values, 0.9),
        "p95": _percentile(values, 0.95),
        "max": max(values),
    }


def _grade(start_abs: int, end_abs: int) -> str:
    if start_abs <= 500 and end_abs <= 500:
        return "ON_TIME"
    if start_abs <= 2000 and end_abs <= 2000:
        return "SLIGHT_OFFSET"
    return "OFF_TIME"


def _variant_metrics(rows: Sequence[Mapping[str, object]], prefix: str) -> dict[str, object]:
    starts = [int(row[f"{prefix}_start_absolute_error_ms"]) for row in rows]
    ends = [int(row[f"{prefix}_end_absolute_error_ms"]) for row in rows]
    maximums = [int(row[f"{prefix}_max_edge_absolute_error_ms"]) for row in rows]
    counts = Counter(str(row[f"{prefix}_timing_grade"]) for row in rows)
    return {
        "timing_rows": len(rows),
        "grade_counts": {
            grade: counts.get(grade, 0) for grade in ("ON_TIME", "SLIGHT_OFFSET", "OFF_TIME")
        },
        "start_absolute_error_ms": _stats(starts),
        "end_absolute_error_ms": _stats(ends),
        "max_edge_absolute_error_ms": _stats(maximums),
    }


def evaluate_semantic_timing_ab(
    *,
    semantic_report: Mapping[str, object],
    baseline_final: Mapping[str, object],
    candidate_final: Mapping[str, object],
) -> dict[str, object]:
    """Compare identical semantic text boundaries before and after retiming."""

    _validate_report(semantic_report)
    baseline = _validate_final(baseline_final, "baseline")
    candidate = _validate_final(candidate_final, "candidate")
    transcript = str(baseline["transcript"])
    if candidate["transcript"] != transcript:
        raise SemanticTimingABError("baseline and candidate transcripts differ")
    base_segments = baseline["segments"]
    base_characters = baseline["characters"]
    candidate_characters = candidate["characters"]
    candidate_segments = candidate["segments"]
    assert all(isinstance(value, list) for value in (
        base_segments,
        base_characters,
        candidate_characters,
        candidate_segments,
    ))
    by_id = {str(row["id"]): row for row in base_segments}
    eligible_source_rows = [
        _mapping(row, "semantic row")
        for row in _array(semantic_report.get("rows"), "semantic rows")
        if isinstance(row, Mapping)
        and row.get("semantic_timing_status") == "ELIGIBLE_AI_SCOPED_REFERENCE_ONLY"
    ]
    if not eligible_source_rows:
        raise SemanticTimingABError("semantic report has no eligible source rows")
    output_rows: list[dict[str, object]] = []
    previous_source_end = 0
    for semantic in eligible_source_rows:
        atom_ids = _array(semantic.get("candidate_atom_ids"), "semantic candidate atoms")
        if not atom_ids or any(not isinstance(cue_id, str) or cue_id not in by_id for cue_id in atom_ids):
            raise SemanticTimingABError("semantic row references unknown baseline cue IDs")
        selected = [by_id[str(cue_id)] for cue_id in atom_ids]
        source_start = int(selected[0]["source_start"])
        source_end = int(selected[-1]["source_end"])
        expected_cursor = source_start
        for segment in selected:
            if int(segment["source_start"]) != expected_cursor:
                raise SemanticTimingABError("semantic row baseline cues are not contiguous")
            expected_cursor = int(segment["source_end"])
        if expected_cursor != source_end or source_start < previous_source_end:
            raise SemanticTimingABError("semantic source path is not unique and monotonic")
        selected_text = transcript[source_start:source_end]
        if " ".join(str(segment["text"]) for segment in selected) != semantic.get("candidate_text"):
            raise SemanticTimingABError("semantic candidate text differs from baseline source range")
        reference_start = _integer(
            semantic.get("reference_start_ms"), "semantic reference start", minimum=0
        )
        reference_end = _integer(
            semantic.get("reference_end_ms"),
            "semantic reference end",
            minimum=reference_start + 1,
        )
        base_first = base_characters[source_start]
        base_last = base_characters[source_end - 1]
        after_first = candidate_characters[source_start]
        after_last = candidate_characters[source_end - 1]
        assert all(isinstance(value, Mapping) for value in (
            base_first,
            base_last,
            after_first,
            after_last,
        ))
        before_start = int(base_first["start_ms"])
        before_end = int(base_last["end_ms"])
        after_start = int(after_first["start_ms"])
        after_end = int(after_last["end_ms"])
        before_start_error = before_start - reference_start
        before_end_error = before_end - reference_end
        after_start_error = after_start - reference_start
        after_end_error = after_end - reference_end
        before_start_abs = abs(before_start_error)
        before_end_abs = abs(before_end_error)
        after_start_abs = abs(after_start_error)
        after_end_abs = abs(after_end_error)
        before_max = max(before_start_abs, before_end_abs)
        after_max = max(after_start_abs, after_end_abs)
        overlapping_after_cues = [
            row
            for row in candidate_segments
            if int(row["source_start"]) < source_end and int(row["source_end"]) > source_start
        ]
        output_rows.append(
            {
                "reference_unit_id": semantic["reference_unit_id"],
                "reference_ordinal": semantic["reference_ordinal"],
                "reference_text": semantic["reference_text"],
                "candidate_span_id": semantic["candidate_span_id"],
                "candidate_atom_ids": list(atom_ids),
                "candidate_text": semantic["candidate_text"],
                "source_start": source_start,
                "source_end": source_end,
                "source_text_sha256": hashlib.sha256(selected_text.encode("utf-8")).hexdigest(),
                "reference_start_ms": reference_start,
                "reference_end_ms": reference_end,
                "before_start_ms": before_start,
                "before_end_ms": before_end,
                "before_start_error_ms": before_start_error,
                "before_end_error_ms": before_end_error,
                "before_start_absolute_error_ms": before_start_abs,
                "before_end_absolute_error_ms": before_end_abs,
                "before_max_edge_absolute_error_ms": before_max,
                "before_timing_grade": _grade(before_start_abs, before_end_abs),
                "after_start_ms": after_start,
                "after_end_ms": after_end,
                "after_start_error_ms": after_start_error,
                "after_end_error_ms": after_end_error,
                "after_start_absolute_error_ms": after_start_abs,
                "after_end_absolute_error_ms": after_end_abs,
                "after_max_edge_absolute_error_ms": after_max,
                "after_timing_grade": _grade(after_start_abs, after_end_abs),
                "max_edge_delta_ms": after_max - before_max,
                "outcome": "IMPROVED" if after_max < before_max else (
                    "WORSENED" if after_max > before_max else "UNCHANGED"
                ),
                "after_start_timing_source": after_first.get("timing_source", "UNKNOWN"),
                "after_end_timing_source": after_last.get("timing_source", "UNKNOWN"),
                "after_overlapping_cue_ids": [str(row["id"]) for row in overlapping_after_cues],
                "after_timing_review_required": any(
                    row.get("timing_review_required") is True for row in overlapping_after_cues
                ),
            }
        )
        previous_source_end = source_end
    outcomes = Counter(str(row["outcome"]) for row in output_rows)
    source_counts = Counter(
        str(row[field])
        for row in output_rows
        for field in ("after_start_timing_source", "after_end_timing_source")
    )
    result: dict[str, object] = {
        "schema": "cts.o8-scoped-ai-semantic-timing-ab/v1",
        "policy_version": "o8-scoped-ai-semantic-character-edge-ab-m0-2026-09-08",
        "scope": {
            "video_id": "O8IB7nao2K4",
            "youtube_url": "https://www.youtube.com/watch?v=O8IB7nao2K4",
            "semantic_authority": "local AI same_meaning proposals on a unique monotonic path",
            "reference_role": "user-authorized gold for this O8 comparison only",
            "measurement_unit": "same CTS transcript source-character span before and after Wenet v4 retiming",
            "human_confirmation": False,
            "production_wide_human_gold_claim": False,
            "broader_human_gold_gate_overwritten": False,
            "automatic_timing_mutation": False,
            "production_release_verdict": False,
        },
        "semantic_report_canonical_sha256": semantic_report["report_canonical_sha256"],
        "transcript": {
            "characters": len(transcript),
            "identity_preserved": True,
        },
        "rows": output_rows,
        "before": _variant_metrics(output_rows, "before"),
        "after": _variant_metrics(output_rows, "after"),
        "delta": {
            "outcome_counts": {
                outcome: outcomes.get(outcome, 0)
                for outcome in ("IMPROVED", "UNCHANGED", "WORSENED")
            },
            "after_boundary_timing_source_counts": dict(sorted(source_counts.items())),
            "after_timing_review_required_rows": sum(
                row["after_timing_review_required"] is True for row in output_rows
            ),
        },
        "failure_samples": sorted(
            output_rows,
            key=lambda row: int(row["after_max_edge_absolute_error_ms"]),
            reverse=True,
        )[:10],
        "claims": [
            {
                "label": "FACT",
                "confidence": 100,
                "claim": "Before and after use the same sealed transcript source ranges selected without timing access.",
            },
            {
                "label": "FACT",
                "confidence": 100,
                "claim": "The A/B measures source-character span edges, not whole display-cue boxes, so segmentation changes cannot manufacture an improvement.",
            },
            {
                "label": "INFERENCE",
                "confidence": 75,
                "claim": "This scoped sample estimates whether Wenet v4 moves semantically matched text closer to the O8 reference clock.",
            },
            {
                "label": "UNKNOWN",
                "confidence": 100,
                "claim": "The sample does not establish acoustic onset/offset truth, production-wide accuracy, or release readiness.",
            },
        ],
    }
    result["result_canonical_sha256"] = canonical_sha256(result)
    return result


__all__ = ["SemanticTimingABError", "evaluate_semantic_timing_ab"]
