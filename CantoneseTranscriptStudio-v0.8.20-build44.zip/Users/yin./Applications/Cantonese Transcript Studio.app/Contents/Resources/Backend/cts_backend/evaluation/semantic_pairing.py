"""Fail-closed text-only semantic-pairing preparation for caption timing QA.

This module deliberately separates an approximate-meaning review task from
acoustic timing.  It reads only immutable text identifiers and text strings
when it creates candidate spans or retrieval suggestions.  Numeric timestamps
from a CTS final output are never available to the selection functions.

The deterministic lexical suggestions are *not* semantic decisions.  They
exist solely to make a later blind reviewer or bounded local judge's search
space manageable.  Nothing in this module may mutate a caption timestamp or
make a release claim.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Iterable, Mapping, Sequence
import unicodedata

from .metrics import comparison_text
from ..normalization import HongKongNormalizer
from ..youtube.captions import CaptionParseError, parse_vtt


SEMANTIC_PAIRING_POLICY_VERSION = "semantic-monotonic-pairing-m0-2026-09-03"
SEMANTIC_PAIRING_BUNDLE_SCHEMA = "cts.youtube-semantic-timing-review-bundle/v1"
PAIRING_PROPOSALS_SCHEMA = "cts.semantic-pairing-proposals/v1"
BLIND_REVIEW_PACKET_SCHEMA = "cts.semantic-pairing-blind-review-packet/v1"

_TIMESTAMP_KEY_PATTERN = re.compile(
    r"(?:timestamp|timecode|offset|(?:^|_)(?:start|end|duration|seconds|milliseconds|ms)(?:_|$))",
    re.IGNORECASE,
)
_RELATIONS = frozenset({"same_meaning", "partial", "different", "uncertain"})
_TERMINAL_REFERENCE_TEXT = re.compile(r"[。！？?!…][」』\"']?$")
_SHA256_HEX = re.compile(r"^[0-9a-f]{64}$")


class SemanticPairingError(ValueError):
    """The evidence cannot safely be prepared for semantic review."""


@dataclass(frozen=True)
class ReferenceUnit:
    """An immutable formal-caption review unit with no timing fields."""

    unit_id: str
    ordinal: int
    text: str
    text_sha256: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class CandidateAtom:
    """An immutable CTS text atom with no timing fields."""

    atom_id: str
    ordinal: int
    text: str
    text_sha256: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class CandidateSpan:
    """A deterministic contiguous sequence of candidate text atoms."""

    span_id: str
    first_ordinal: int
    last_ordinal: int
    atom_ids: tuple[str, ...]
    text: str
    text_sha256: str

    def to_dict(self) -> dict[str, object]:
        value = asdict(self)
        value["atom_ids"] = list(self.atom_ids)
        return value


def canonical_sha256(value: object) -> str:
    return hashlib.sha256(
        json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
    ).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _text_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _clean_text(value: object, *, field: str) -> str:
    if not isinstance(value, str):
        raise SemanticPairingError(f"{field} 必須係文字")
    cleaned = " ".join(value.split())
    if not cleaned:
        raise SemanticPairingError(f"{field} 唔可以空白")
    return cleaned


def _identifier(value: object, *, field: str) -> str:
    if not isinstance(value, (str, int)) or isinstance(value, bool):
        raise SemanticPairingError(f"{field} 必須係穩定 ID")
    identifier = str(value).strip()
    if not identifier or len(identifier) > 160:
        raise SemanticPairingError(f"{field} 無效")
    return identifier


def validate_bundle(bundle: Mapping[str, object]) -> None:
    """Validate the existing hash-bound bundle before using its text projection."""

    if not isinstance(bundle, Mapping):
        raise SemanticPairingError("semantic bundle 必須係 object")
    if bundle.get("schema") != SEMANTIC_PAIRING_BUNDLE_SCHEMA:
        raise SemanticPairingError("semantic bundle schema 唔支援")
    claimed = bundle.get("bundle_canonical_sha256")
    if not isinstance(claimed, str):
        raise SemanticPairingError("semantic bundle 冇 canonical hash")
    body = dict(bundle)
    body.pop("bundle_canonical_sha256", None)
    if canonical_sha256(body) != claimed:
        raise SemanticPairingError("semantic bundle canonical hash mismatch")
    units = bundle.get("units")
    candidates = bundle.get("candidate_cues")
    if not isinstance(units, list) or not units:
        raise SemanticPairingError("semantic bundle 冇 review units")
    if not isinstance(candidates, list) or not candidates:
        raise SemanticPairingError("semantic bundle 冇 candidate cues")


def build_reference_units(bundle: Mapping[str, object]) -> tuple[ReferenceUnit, ...]:
    """Project reference text only; do not read its display timestamps."""

    validate_bundle(bundle)
    raw_units = bundle["units"]
    assert isinstance(raw_units, list)
    result: list[ReferenceUnit] = []
    seen: set[str] = set()
    for ordinal, raw in enumerate(raw_units, start=1):
        if not isinstance(raw, Mapping):
            raise SemanticPairingError(f"reference unit {ordinal} 無效")
        unit_id = _identifier(raw.get("unit_id"), field=f"reference unit {ordinal} ID")
        if unit_id in seen:
            raise SemanticPairingError(f"duplicate reference unit ID: {unit_id}")
        seen.add(unit_id)
        text = _clean_text(raw.get("reference_text"), field=f"reference unit {unit_id} text")
        result.append(ReferenceUnit(unit_id, ordinal, text, _text_sha256(text)))
    return tuple(result)


def reconstruct_reference_review_units_from_vtt(path: Path) -> list[dict[str, object]]:
    """Rebuild the bundle's deterministic review groups from raw VTT evidence.

    This source-binding check uses reference-display timing only to reproduce
    the pre-existing reference grouping.  It is never passed to candidate
    retrieval or a semantic judge, and it never reads CTS candidate timing.
    """

    try:
        cues = parse_vtt(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeDecodeError, CaptionParseError) as exc:
        raise SemanticPairingError(f"cannot parse reference VTT: {path}") from exc
    if not cues:
        raise SemanticPairingError("reference VTT has no cues")
    units: list[dict[str, object]] = []
    current: list[tuple[str, object]] = []

    def joined_text() -> str:
        return " ".join(
            _clean_text(getattr(cue, "text"), field="reference VTT cue")
            for _cue_id, cue in current
        )

    def flush(reason: str) -> None:
        if not current:
            return
        first_id, first = current[0]
        _ = first_id
        _last_id, last = current[-1]
        units.append(
            {
                "unit_id": f"U{len(units) + 1:04d}",
                "reference_cue_ids": [cue_id for cue_id, _cue in current],
                "reference_start_ms": getattr(first, "start_ms"),
                "reference_end_ms": getattr(last, "end_ms"),
                "reference_text": joined_text(),
                "group_end_reason": reason,
            }
        )
        current.clear()

    for index, cue in enumerate(cues):
        if current:
            previous = current[-1][1]
            if getattr(cue, "start_ms") - getattr(previous, "end_ms") >= 650:
                flush("gap_at_least_650ms")
        current.append((str(index + 1), cue))
        first = current[0][1]
        duration = getattr(cue, "end_ms") - getattr(first, "start_ms")
        text = joined_text()
        text_length = len(text.replace(" ", ""))
        if _TERMINAL_REFERENCE_TEXT.search(_clean_text(getattr(cue, "text"), field="reference VTT cue")):
            flush("terminal_punctuation")
        elif duration >= 6_000:
            flush("duration_at_least_6000ms")
        elif text_length >= 42:
            flush("text_at_least_42_characters")
        elif index == len(cues) - 1:
            flush("end_of_file")
    return units


def validate_reference_bundle_against_vtt(bundle: Mapping[str, object], path: Path) -> int:
    """Ensure bundle text/grouping is an exact reconstruction of its VTT source."""

    validate_bundle(bundle)
    expected = reconstruct_reference_review_units_from_vtt(path)
    actual = bundle.get("units")
    if not isinstance(actual, list) or len(actual) != len(expected):
        raise SemanticPairingError("reference VTT grouping count does not match bundle")
    fields = (
        "unit_id",
        "reference_cue_ids",
        "reference_start_ms",
        "reference_end_ms",
        "reference_text",
        "group_end_reason",
    )
    for index, (source, received) in enumerate(zip(expected, actual), start=1):
        if not isinstance(received, Mapping):
            raise SemanticPairingError(f"bundle reference unit {index} is invalid")
        for field in fields:
            if received.get(field) != source[field]:
                raise SemanticPairingError(
                    f"reference VTT grouping mismatch at unit {index}: {field}"
                )
    return len(expected)


def build_candidate_atoms(bundle: Mapping[str, object]) -> tuple[CandidateAtom, ...]:
    """Project candidate IDs/text only; do not read candidate timing values."""

    validate_bundle(bundle)
    raw_candidates = bundle["candidate_cues"]
    assert isinstance(raw_candidates, list)
    result: list[CandidateAtom] = []
    seen: set[str] = set()
    for ordinal, raw in enumerate(raw_candidates, start=1):
        if not isinstance(raw, Mapping):
            raise SemanticPairingError(f"candidate cue {ordinal} 無效")
        atom_id = _identifier(raw.get("cue_id"), field=f"candidate cue {ordinal} ID")
        if atom_id in seen:
            raise SemanticPairingError(f"duplicate candidate cue ID: {atom_id}")
        seen.add(atom_id)
        text = _clean_text(raw.get("text"), field=f"candidate cue {atom_id} text")
        result.append(CandidateAtom(atom_id, ordinal, text, _text_sha256(text)))
    return tuple(result)


def project_candidate_atoms_from_final(path: Path) -> tuple[CandidateAtom, ...]:
    """Verify a final-envelope seal, then project only subtitle IDs and text.

    The integrity seal covers the complete final artifact.  Its verification is
    an evidence check; the returned projection intentionally omits every timing
    field so semantic selection cannot consume it.
    """

    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise SemanticPairingError(f"cannot read CTS final.json: {path}") from exc
    if not isinstance(envelope, dict) or envelope.get("complete") is not True:
        raise SemanticPairingError("CTS final.json is not a complete envelope")
    value = envelope.get("value")
    if not isinstance(value, dict):
        raise SemanticPairingError("CTS final.json value is invalid")
    sealed = {"fingerprint": envelope.get("fingerprint"), "value": value}
    if envelope.get("payload_sha256") != canonical_sha256(sealed):
        raise SemanticPairingError("CTS final.json integrity seal does not match")
    rows = value.get("subtitle_segments")
    if not isinstance(rows, list) or not rows:
        raise SemanticPairingError("CTS final.json 冇 subtitle segments")
    projection: dict[str, object] = {"schema": SEMANTIC_PAIRING_BUNDLE_SCHEMA, "units": [{"unit_id": "synthetic", "reference_text": "synthetic"}], "candidate_cues": []}
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, Mapping):
            raise SemanticPairingError(f"CTS subtitle segment {index} 無效")
        projection["candidate_cues"].append(  # type: ignore[index]
            {"cue_id": row.get("id") or index, "text": row.get("text")}
        )
    body = dict(projection)
    body["bundle_canonical_sha256"] = canonical_sha256(body)
    return build_candidate_atoms(body)


def candidate_text_projection_sha256(atoms: Sequence[CandidateAtom]) -> str:
    return canonical_sha256([atom.to_dict() for atom in atoms])


def assert_same_candidate_projection(
    bundle_atoms: Sequence[CandidateAtom], final_atoms: Sequence[CandidateAtom]
) -> None:
    left = [(atom.atom_id, atom.text_sha256) for atom in bundle_atoms]
    right = [(atom.atom_id, atom.text_sha256) for atom in final_atoms]
    if left != right:
        raise SemanticPairingError(
            "bundle candidate text projection does not match sealed CTS final.json"
        )


def enumerate_contiguous_candidate_spans(
    atoms: Sequence[CandidateAtom], *, max_atoms_per_span: int = 3
) -> tuple[CandidateSpan, ...]:
    if not atoms:
        raise SemanticPairingError("candidate atoms 唔可以空白")
    if (
        isinstance(max_atoms_per_span, bool)
        or not isinstance(max_atoms_per_span, int)
        or not 1 <= max_atoms_per_span <= 8
    ):
        raise SemanticPairingError("max_atoms_per_span 必須係 1 至 8")
    result: list[CandidateSpan] = []
    for start in range(len(atoms)):
        for width in range(1, min(max_atoms_per_span, len(atoms) - start) + 1):
            selected = atoms[start : start + width]
            if any(
                right.ordinal != left.ordinal + 1
                for left, right in zip(selected, selected[1:])
            ):
                raise SemanticPairingError("candidate atoms 必須順序連續")
            text = " ".join(atom.text for atom in selected)
            result.append(
                CandidateSpan(
                    span_id=f"S{len(result) + 1:06d}",
                    first_ordinal=selected[0].ordinal,
                    last_ordinal=selected[-1].ordinal,
                    atom_ids=tuple(atom.atom_id for atom in selected),
                    text=text,
                    text_sha256=_text_sha256(text),
                )
            )
    return tuple(result)


def _normalized_text(text: str, normalizer: HongKongNormalizer) -> str:
    return comparison_text(normalizer.normalize(unicodedata.normalize("NFKC", text)))


def _counter_score(left: Counter[str], right: Counter[str]) -> float:
    left_length = sum(left.values())
    right_length = sum(right.values())
    if not left_length or not right_length:
        return 0.0
    overlap = sum((left & right).values())
    return round(2.0 * overlap / (left_length + right_length), 6)


def lexical_retrieval_score(
    reference_text: str, candidate_text: str, *, normalizer: HongKongNormalizer | None = None
) -> float:
    """Return a deterministic character-overlap retrieval score, not meaning."""

    active_normalizer = normalizer or HongKongNormalizer()
    return _counter_score(
        Counter(_normalized_text(reference_text, active_normalizer)),
        Counter(_normalized_text(candidate_text, active_normalizer)),
    )


def build_text_only_review_queue(
    references: Sequence[ReferenceUnit],
    spans: Sequence[CandidateSpan],
    *,
    top_candidates: int = 4,
    ordinal_progress_radius: int | None = 24,
    normalizer: HongKongNormalizer | None = None,
) -> list[dict[str, object]]:
    """Build only a blind-review queue; no row receives a semantic verdict."""

    if not references or not spans:
        raise SemanticPairingError("reference units and candidate spans are required")
    if (
        isinstance(top_candidates, bool)
        or not isinstance(top_candidates, int)
        or not 1 <= top_candidates <= 8
    ):
        raise SemanticPairingError("top_candidates 必須係 1 至 8")
    if ordinal_progress_radius is not None and (
        isinstance(ordinal_progress_radius, bool)
        or not isinstance(ordinal_progress_radius, int)
        or not 1 <= ordinal_progress_radius <= 256
    ):
        raise SemanticPairingError("ordinal_progress_radius 必須係 1 至 256 或 null")
    active_normalizer = normalizer or HongKongNormalizer()
    # Normalization is text-only but can still be expensive (notably OpenCC).
    # Cache it once per immutable span/reference rather than re-normalizing a
    # candidate for every reference unit.  This preserves the exact score.
    normalized_spans = [
        (Counter(_normalized_text(span.text, active_normalizer)), span)
        for span in spans
    ]
    candidate_atom_count = max(span.last_ordinal for span in spans)
    queue: list[dict[str, object]] = []
    for reference in references:
        normalized_reference = Counter(_normalized_text(reference.text, active_normalizer))
        progress_center = round(reference.ordinal * candidate_atom_count / len(references))
        eligible_spans = normalized_spans
        if ordinal_progress_radius is not None:
            lower = max(1, progress_center - ordinal_progress_radius)
            upper = min(candidate_atom_count, progress_center + ordinal_progress_radius)
            eligible_spans = [
                (normalized_span, span)
                for normalized_span, span in normalized_spans
                if span.first_ordinal <= upper and span.last_ordinal >= lower
            ]
            if not eligible_spans:
                raise SemanticPairingError(
                    f"no ordinal-progress candidate spans for {reference.unit_id}"
                )
        scored = [
            (_counter_score(normalized_reference, normalized_span), span)
            for normalized_span, span in eligible_spans
        ]
        scored.sort(
            key=lambda item: (
                -item[0],
                item[1].first_ordinal,
                len(item[1].atom_ids),
                item[1].span_id,
            )
        )
        suggestions = [
            {
                "candidate_span_id": span.span_id,
                "candidate_atom_ids": list(span.atom_ids),
                "candidate_text": span.text,
                "candidate_text_sha256": span.text_sha256,
                "lexical_retrieval_score": score,
            }
            for score, span in scored[:top_candidates]
        ]
        queue.append(
            {
                "reference_unit_id": reference.unit_id,
                "reference_ordinal": reference.ordinal,
                "reference_text": reference.text,
                "reference_text_sha256": reference.text_sha256,
                "status": "REVIEW_REQUIRED",
                "decision": "UNASSESSABLE_NO_HUMAN_SEMANTIC_CONFIRMATION",
                "proposer": "text_only_lexical_retrieval_not_semantic_judge",
                "ordinal_progress_prior": {
                    "used": ordinal_progress_radius is not None,
                    "reference_ordinal": reference.ordinal,
                    "candidate_ordinal_center": progress_center,
                    "candidate_ordinal_radius": ordinal_progress_radius,
                },
                "suggested_candidates": suggestions,
            }
        )
    return queue


def build_blind_review_packet(queue: Sequence[Mapping[str, object]]) -> dict[str, object]:
    """Remove heuristic scores and timestamp fields before semantic review."""

    units: list[dict[str, object]] = []
    for raw in queue:
        suggestions = raw.get("suggested_candidates")
        if not isinstance(suggestions, list) or any(not isinstance(item, Mapping) for item in suggestions):
            raise SemanticPairingError("review queue has invalid suggestions")
        units.append(
            {
                "reference_unit_id": raw.get("reference_unit_id"),
                "reference_text": raw.get("reference_text"),
                "reference_text_sha256": raw.get("reference_text_sha256"),
                "candidate_options": [
                    {
                        "candidate_span_id": item.get("candidate_span_id"),
                        "candidate_atom_ids": item.get("candidate_atom_ids"),
                        "candidate_text": item.get("candidate_text"),
                        "candidate_text_sha256": item.get("candidate_text_sha256"),
                    }
                    for item in suggestions
                ],
            }
        )
    packet: dict[str, object] = {
        "schema": BLIND_REVIEW_PACKET_SCHEMA,
        "policy_version": SEMANTIC_PAIRING_POLICY_VERSION,
        "semantic_selection_used_candidate_timing": False,
        "blind_packet_contains_numeric_timing_values": False,
        "review_question": (
            "每個 candidate option 係咪同 reference unit 大概同一個意思？"
            "可答 same_meaning、partial、different 或 uncertain；唔肯定要 uncertain。"
        ),
        "allowed_relations": sorted(_RELATIONS),
        "required_response_fields": [
            "reference_unit_id",
            "candidate_span_id",
            "relation",
            "evidence_atom_ids",
        ],
        "units": units,
    }
    assert_no_timestamp_fields(packet)
    packet["packet_canonical_sha256"] = canonical_sha256(packet)
    validate_blind_review_packet_shape(packet)
    return packet


def validate_blind_review_packet_shape(packet: Mapping[str, object]) -> None:
    """Apply an allowlist schema to every field exposed to a semantic judge.

    The generic timestamp-name guard is intentionally only a backstop.  This
    structural allowlist is the primary leakage control: fields such as `pts`,
    frame counts, clock ticks, or future numeric timing aliases cannot enter a
    blind packet because they are not part of the schema at all.
    """

    base_root = {
        "schema",
        "policy_version",
        "semantic_selection_used_candidate_timing",
        "blind_packet_contains_numeric_timing_values",
        "review_question",
        "allowed_relations",
        "required_response_fields",
        "units",
        "packet_canonical_sha256",
    }
    optional_root = {
        "scope",
        "authority",
        "reference_unit_count",
        "candidate_atom_count",
        "reference_unit_segmentation_derived_from_reference_timing",
    }
    if set(packet).difference(base_root | optional_root) or not base_root.issubset(packet):
        raise SemanticPairingError("blind review packet root schema is invalid")
    if packet.get("schema") != BLIND_REVIEW_PACKET_SCHEMA:
        raise SemanticPairingError("blind review packet schema is invalid")
    if packet.get("policy_version") != SEMANTIC_PAIRING_POLICY_VERSION:
        raise SemanticPairingError("blind review packet policy is invalid")
    if packet.get("semantic_selection_used_candidate_timing") is not False:
        raise SemanticPairingError("blind review packet timing selection flag is unsafe")
    if packet.get("blind_packet_contains_numeric_timing_values") is not False:
        raise SemanticPairingError("blind review packet timing-value flag is unsafe")
    if packet.get("allowed_relations") != sorted(_RELATIONS):
        raise SemanticPairingError("blind review packet relation schema is invalid")
    if packet.get("required_response_fields") != [
        "reference_unit_id",
        "candidate_span_id",
        "relation",
        "evidence_atom_ids",
    ]:
        raise SemanticPairingError("blind review packet response schema is invalid")
    for count_field in ("reference_unit_count", "candidate_atom_count"):
        if count_field in packet and (
            isinstance(packet[count_field], bool)
            or not isinstance(packet[count_field], int)
            or int(packet[count_field]) < 1
        ):
            raise SemanticPairingError("blind review packet count is invalid")
    if (
        "reference_unit_segmentation_derived_from_reference_timing" in packet
        and packet["reference_unit_segmentation_derived_from_reference_timing"] is not True
    ):
        raise SemanticPairingError("blind review packet reference grouping provenance is invalid")
    scope = packet.get("scope")
    if scope is not None:
        if not isinstance(scope, Mapping) or set(scope) != {
            "video_id",
            "youtube_url",
            "gold_authority",
            "production_wide_human_gold_claim",
        }:
            raise SemanticPairingError("blind review packet scope schema is invalid")
    authority = packet.get("authority")
    if authority is not None:
        if not isinstance(authority, Mapping) or set(authority) != {
            "bundle_file_sha256",
            "bundle_canonical_sha256",
            "candidate_text_projection_sha256",
        }:
            raise SemanticPairingError("blind review packet authority schema is invalid")
    units = packet.get("units")
    if not isinstance(units, list) or not units:
        raise SemanticPairingError("blind review packet units are invalid")
    seen_units: set[str] = set()
    for unit in units:
        if not isinstance(unit, Mapping) or set(unit) != {
            "reference_unit_id",
            "reference_text",
            "reference_text_sha256",
            "candidate_options",
        }:
            raise SemanticPairingError("blind review packet unit schema is invalid")
        unit_id = _identifier(unit.get("reference_unit_id"), field="blind review unit ID")
        if unit_id in seen_units:
            raise SemanticPairingError("blind review packet duplicate unit ID")
        seen_units.add(unit_id)
        _clean_text(unit.get("reference_text"), field="blind review reference text")
        text_hash = unit.get("reference_text_sha256")
        options = unit.get("candidate_options")
        if (
            not isinstance(text_hash, str)
            or not _SHA256_HEX.fullmatch(text_hash)
            or not isinstance(options, list)
            or not 0 <= len(options) <= 4
        ):
            raise SemanticPairingError("blind review packet unit contents are invalid")
        seen_options: set[str] = set()
        for option in options:
            if not isinstance(option, Mapping) or set(option) != {
                "candidate_span_id",
                "candidate_atom_ids",
                "candidate_text",
                "candidate_text_sha256",
            }:
                raise SemanticPairingError("blind review packet option schema is invalid")
            span_id = _identifier(option.get("candidate_span_id"), field="blind candidate span ID")
            atom_ids = option.get("candidate_atom_ids")
            if (
                span_id in seen_options
                or not isinstance(atom_ids, list)
                or not atom_ids
                or any(not isinstance(atom_id, str) or not atom_id for atom_id in atom_ids)
                or len(atom_ids) != len(set(atom_ids))
            ):
                raise SemanticPairingError("blind review packet candidate ownership is invalid")
            seen_options.add(span_id)
            text = _clean_text(option.get("candidate_text"), field="blind candidate text")
            if option.get("candidate_text_sha256") != _text_sha256(text):
                raise SemanticPairingError("blind review packet candidate text hash is invalid")


def assert_no_timestamp_fields(value: object) -> None:
    """Reject common timing-field variants in a blind semantic packet."""

    if isinstance(value, Mapping):
        for key, child in value.items():
            if not isinstance(key, str):
                raise SemanticPairingError("blind review packet key must be text")
            if _TIMESTAMP_KEY_PATTERN.search(key):
                raise SemanticPairingError(f"blind review packet leaked timestamp field: {key}")
            assert_no_timestamp_fields(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            assert_no_timestamp_fields(child)


def validate_model_or_human_response(
    response: Mapping[str, object],
    *,
    reference_unit_id: str,
    allowed_spans: Mapping[str, CandidateSpan],
) -> tuple[bool, str]:
    """Validate an immutable-ID review response; it never grants timing access."""

    if set(response) != {
        "reference_unit_id",
        "candidate_span_id",
        "relation",
        "evidence_atom_ids",
    }:
        return False, "invalid_schema"
    if response.get("reference_unit_id") != reference_unit_id:
        return False, "wrong_reference_unit"
    span_id = response.get("candidate_span_id")
    relation = response.get("relation")
    evidence = response.get("evidence_atom_ids")
    if not isinstance(span_id, str) or span_id not in allowed_spans:
        return False, "unknown_candidate_span"
    if relation not in _RELATIONS:
        return False, "invalid_relation"
    if not isinstance(evidence, list) or not evidence:
        return False, "invalid_evidence_atoms"
    if any(isinstance(item, bool) or not isinstance(item, str) for item in evidence):
        return False, "invalid_evidence_atoms"
    if len(evidence) != len(set(evidence)):
        return False, "duplicate_evidence_atoms"
    allowed_atoms = set(allowed_spans[span_id].atom_ids)
    if not set(evidence).issubset(allowed_atoms):
        return False, "unknown_evidence_atom"
    return True, "model_or_human_proposal_requires_confirmation"


def timing_eligibility(
    *,
    reference_unit_id: str,
    candidate_span_id: str,
    relation: str | None,
    blind_review_packet: Mapping[str, object] | None,
    human_confirmation_receipt: Mapping[str, object] | None,
    monotonic_path_receipt: Mapping[str, object] | None,
    acoustic_witness: Mapping[str, object] | None,
    direct_posterior_context: Mapping[str, object] | None = None,
) -> tuple[bool, str]:
    """Require actual, hash-bound artifacts before a scoped timing diagnostic.

    This function intentionally accepts artifacts, not merely SHA-shaped text.
    It validates their canonical identities, then re-reads the hash-locked
    direct-posterior evidence before it can return eligible.  The result
    remains a scoped cue-edge diagnostic, never a production or acoustic-onset
    release verdict.
    """

    if not isinstance(reference_unit_id, str) or not reference_unit_id:
        return False, "UNASSESSABLE_UNKNOWN_REFERENCE_UNIT"
    if not isinstance(candidate_span_id, str) or not candidate_span_id:
        return False, "UNASSESSABLE_UNKNOWN_CANDIDATE_SPAN"
    if relation != "same_meaning":
        return False, "UNASSESSABLE_NON_EQUIVALENT_SEMANTIC_RELATION"
    if not isinstance(blind_review_packet, Mapping):
        return False, "UNASSESSABLE_NO_BLIND_REVIEW_PACKET_BINDING"
    try:
        assert_no_timestamp_fields(blind_review_packet)
        validate_blind_review_packet_shape(blind_review_packet)
        _validate_canonical_artifact(
            blind_review_packet, "packet_canonical_sha256", BLIND_REVIEW_PACKET_SCHEMA
        )
    except SemanticPairingError:
        return False, "UNASSESSABLE_INVALID_BLIND_REVIEW_PACKET"
    packet_hash = blind_review_packet.get("packet_canonical_sha256")
    packet_units = blind_review_packet.get("units")
    if not isinstance(packet_hash, str) or not isinstance(packet_units, list):
        return False, "UNASSESSABLE_INVALID_BLIND_REVIEW_PACKET"
    packet_option: Mapping[str, object] | None = None
    for unit in packet_units:
        if (
            not isinstance(unit, Mapping)
            or unit.get("reference_unit_id") != reference_unit_id
            or not isinstance(unit.get("candidate_options"), list)
        ):
            continue
        packet_option = next(
            (
                option
                for option in unit["candidate_options"]
                if isinstance(option, Mapping)
                and option.get("candidate_span_id") == candidate_span_id
            ),
            None,
        )
        if packet_option is not None:
            break
    if packet_option is None:
        return False, "UNASSESSABLE_PAIR_NOT_BOUND_TO_BLIND_PACKET"
    if not isinstance(human_confirmation_receipt, Mapping):
        return False, "UNASSESSABLE_NO_HUMAN_SEMANTIC_CONFIRMATION"
    try:
        _validate_canonical_artifact(
            human_confirmation_receipt,
            "receipt_canonical_sha256",
            "cts.semantic-pairing-human-confirmation-receipt/v1",
        )
    except SemanticPairingError:
        return False, "UNASSESSABLE_NO_HUMAN_CONFIRMATION_RECEIPT"
    if (
        human_confirmation_receipt.get("human_confirmed") is not True
        or human_confirmation_receipt.get("reference_unit_id") != reference_unit_id
        or human_confirmation_receipt.get("candidate_span_id") != candidate_span_id
        or human_confirmation_receipt.get("relation") != "same_meaning"
        or human_confirmation_receipt.get("blind_review_packet_canonical_sha256") != packet_hash
    ):
        return False, "UNASSESSABLE_NO_HUMAN_CONFIRMATION_RECEIPT"
    human_receipt_hash = human_confirmation_receipt.get("receipt_canonical_sha256")
    if not isinstance(monotonic_path_receipt, Mapping):
        return False, "UNASSESSABLE_AMBIGUOUS_MONOTONIC_PATH"
    try:
        _validate_canonical_artifact(
            monotonic_path_receipt,
            "path_canonical_sha256",
            "cts.semantic-monotonic-path-receipt/v1",
        )
    except SemanticPairingError:
        return False, "UNASSESSABLE_AMBIGUOUS_MONOTONIC_PATH"
    if (
        monotonic_path_receipt.get("path_valid") is not True
        or monotonic_path_receipt.get("reference_unit_id") != reference_unit_id
        or monotonic_path_receipt.get("candidate_span_id") != candidate_span_id
        or monotonic_path_receipt.get("human_confirmation_receipt_canonical_sha256")
        != human_receipt_hash
    ):
        return False, "UNASSESSABLE_AMBIGUOUS_MONOTONIC_PATH"
    if not isinstance(acoustic_witness, Mapping):
        return False, "UNASSESSABLE_NO_ACOUSTIC_WITNESS"
    try:
        _validate_canonical_artifact(
            acoustic_witness,
            "witness_canonical_sha256",
            "cts.acoustic-witness/v1",
        )
    except SemanticPairingError:
        return False, "UNASSESSABLE_NO_ACOUSTIC_WITNESS_BINDING"
    source_hash = acoustic_witness.get("acoustic_source_sha256")
    if (
        acoustic_witness.get("reference_unit_id") != reference_unit_id
        or acoustic_witness.get("candidate_span_id") != candidate_span_id
        or not isinstance(acoustic_witness.get("witness_id"), str)
        or not str(acoustic_witness["witness_id"]).strip()
        or not isinstance(source_hash, str)
        or not _SHA256_HEX.fullmatch(source_hash)
    ):
        return False, "UNASSESSABLE_NO_ACOUSTIC_WITNESS_BINDING"
    if acoustic_witness.get("vad_compatible") is not True:
        return False, "UNASSESSABLE_VAD_INCOMPATIBLE"
    candidate_text = packet_option.get("candidate_text")
    if not isinstance(candidate_text, str) or not candidate_text:
        return False, "UNASSESSABLE_PAIR_NOT_BOUND_TO_BLIND_PACKET"
    try:
        # Import locally: direct_posterior_witness imports this function for
        # its pre-witness semantic gate, while the completed-witness path must
        # validate the full direct receipt binding rather than a generic
        # self-sealed witness shell.
        from .direct_posterior_witness import validate_direct_posterior_acoustic_witness

        validate_direct_posterior_acoustic_witness(
            acoustic_witness,
            reference_unit_id=reference_unit_id,
            candidate_span_id=candidate_span_id,
            candidate_span_text=candidate_text,
            blind_review_packet_canonical_sha256=packet_hash,
            human_confirmation_receipt_canonical_sha256=str(human_receipt_hash),
            monotonic_path_receipt_canonical_sha256=str(
                monotonic_path_receipt.get("path_canonical_sha256")
            ),
            direct_posterior_context=direct_posterior_context,
        )
    except (ImportError, ValueError):
        return False, "UNASSESSABLE_NO_ACOUSTIC_WITNESS_BINDING"
    return True, "ELIGIBLE_SCOPED_CUE_EDGE_DIAGNOSTIC"


def _validate_canonical_artifact(
    value: Mapping[str, object], hash_field: str, schema: str
) -> None:
    if value.get("schema") != schema:
        raise SemanticPairingError("artifact schema mismatch")
    claimed = value.get(hash_field)
    if not isinstance(claimed, str) or not _SHA256_HEX.fullmatch(claimed):
        raise SemanticPairingError("artifact canonical hash invalid")
    body = dict(value)
    body.pop(hash_field, None)
    if canonical_sha256(body) != claimed:
        raise SemanticPairingError("artifact canonical hash mismatch")


def validate_monotonic_pair_path(
    pairs: Iterable[Mapping[str, object]],
    *,
    references: Sequence[ReferenceUnit],
    spans: Sequence[CandidateSpan],
) -> tuple[bool, str]:
    """Validate unique forward-only candidate ownership for confirmed pairs."""

    reference_order = {row.unit_id: row.ordinal for row in references}
    span_by_id = {row.span_id: row for row in spans}
    seen_references: set[str] = set()
    owned_atoms: set[str] = set()
    previous_reference = 0
    previous_last_atom = 0
    for pair in pairs:
        reference_id = pair.get("reference_unit_id")
        span_id = pair.get("candidate_span_id")
        if not isinstance(reference_id, str) or reference_id not in reference_order:
            return False, "UNASSESSABLE_UNKNOWN_REFERENCE_UNIT"
        if not isinstance(span_id, str) or span_id not in span_by_id:
            return False, "UNASSESSABLE_UNKNOWN_CANDIDATE_SPAN"
        if reference_id in seen_references:
            return False, "UNASSESSABLE_DUPLICATE_REFERENCE_UNIT"
        if pair.get("relation") != "same_meaning":
            return False, "UNASSESSABLE_NO_HUMAN_SEMANTIC_CONFIRMATION"
        span = span_by_id[span_id]
        if reference_order[reference_id] <= previous_reference:
            return False, "UNASSESSABLE_NON_MONOTONIC_REFERENCE_PATH"
        if span.first_ordinal <= previous_last_atom:
            return False, "UNASSESSABLE_AMBIGUOUS_MONOTONIC_PATH"
        if owned_atoms.intersection(span.atom_ids):
            return False, "UNASSESSABLE_CANDIDATE_REUSE"
        seen_references.add(reference_id)
        owned_atoms.update(span.atom_ids)
        previous_reference = reference_order[reference_id]
        previous_last_atom = span.last_ordinal
    if not seen_references:
        return False, "UNASSESSABLE_NO_CONFIRMED_PAIRS"
    return True, "STRUCTURALLY_UNIQUE_MONOTONIC_PATH"


__all__ = [
    "BLIND_REVIEW_PACKET_SCHEMA",
    "PAIRING_PROPOSALS_SCHEMA",
    "SEMANTIC_PAIRING_BUNDLE_SCHEMA",
    "SEMANTIC_PAIRING_POLICY_VERSION",
    "CandidateAtom",
    "CandidateSpan",
    "ReferenceUnit",
    "SemanticPairingError",
    "assert_no_timestamp_fields",
    "assert_same_candidate_projection",
    "build_blind_review_packet",
    "build_candidate_atoms",
    "build_reference_units",
    "build_text_only_review_queue",
    "candidate_text_projection_sha256",
    "canonical_sha256",
    "enumerate_contiguous_candidate_spans",
    "file_sha256",
    "lexical_retrieval_score",
    "project_candidate_atoms_from_final",
    "timing_eligibility",
    "validate_bundle",
    "validate_blind_review_packet_shape",
    "validate_model_or_human_response",
    "validate_monotonic_pair_path",
    "validate_reference_bundle_against_vtt",
]
