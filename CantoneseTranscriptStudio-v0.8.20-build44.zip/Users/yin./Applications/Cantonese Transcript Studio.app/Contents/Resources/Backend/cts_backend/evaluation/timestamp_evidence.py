"""Trustless joins for production timestamp evaluation evidence.

Candidate output is deliberately limited to observations.  Human reference
boundaries, word roles, baseline errors, pipeline audit decisions, and blinded
review judgements are joined from separately bound evidence inside the gate.
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping, Sequence


TIMESTAMP_EVALUATION_RESULT_SCHEMA = "cts.timestamp-candidate-observations/v2"
TIMESTAMP_PIPELINE_AUDIT_SCHEMA = "cts.timestamp-pipeline-audit/v2"
BLINDED_REVIEW_PLAN_SCHEMA = "cts.blinded-cue-review-plan/v1"
BLINDED_REVIEW_PACKET_SCHEMA = "cts.blinded-cue-review-packet/v2"
BLINDED_REVIEW_TRANSACTION_SCHEMA = "cts.blinded-cue-review-transaction/v1"
BLINDED_REVIEW_RESPONSE_SCHEMA = "cts.blinded-cue-review-response/v2"
BLINDED_REVIEW_RECEIPT_SCHEMA = "cts.blinded-cue-review-receipt/v2"

RESULT_KEYS = {
    "schema",
    "execution_id",
    "candidate_identity_sha256",
    "gold_test_seal_sha256",
    "words",
    "cues",
}
WORD_OBSERVATION_KEYS = {
    "id",
    "text",
    "matched",
    "hypothesis_start_ms",
    "hypothesis_end_ms",
}
CUE_OBSERVATION_KEYS = {
    "id",
    "matched",
    "hypothesis_start_ms",
    "hypothesis_end_ms",
}
PIPELINE_AUDIT_KEYS = {
    "schema",
    "execution_id",
    "candidate_identity_sha256",
    "result_sha256",
    "candidate_input_sha256",
    "model_manifest_sha256",
    "policy_version",
    "blocks",
    "words",
}
PIPELINE_WORD_AUDIT_KEYS = {
    "id",
    "block_id",
}
PIPELINE_BLOCK_AUDIT_KEYS = {
    "id",
    "clip_id",
    "chunk_id",
    "audio_sha256",
    "source_start_ms",
    "source_end_ms",
    "method",
    "fallback_reason",
    "owned_word_ids",
    "llm_timing_used",
}
BLINDED_PLAN_KEYS = {
    "schema",
    "review_id",
    "evaluation_execution_id",
    "candidate_identity_sha256",
    "baseline_identity_sha256",
    "gold_test_seal_sha256",
    "created_at",
    "randomization_commitment",
    "packet_sha256",
    "presentations",
    "sha256",
}
BLINDED_PLAN_PRESENTATION_KEYS = {
    "presentation_id",
    "cue_id",
    "candidate_side",
    "candidate_observation_sha256",
    "baseline_observation_sha256",
}
BLINDED_PACKET_KEYS = {
    "schema",
    "review_id",
    "evaluation_execution_id",
    "gold_test_seal_sha256",
    "created_at",
    "presentations",
    "sha256",
}
BLINDED_PACKET_PRESENTATION_KEYS = {
    "presentation_id",
    "cue_id",
    "clip_id",
    "audio_path",
    "audio_sha256",
    "cue_text",
    "cue_text_sha256",
    "option_a_observation_sha256",
    "option_b_observation_sha256",
    "option_a_start_ms",
    "option_a_end_ms",
    "option_b_start_ms",
    "option_b_end_ms",
}
BLINDED_TRANSACTION_KEYS = {
    "schema",
    "review_id",
    "evaluation_execution_id",
    "created_at",
    "candidate_identity_sha256",
    "baseline_identity_sha256",
    "gold_test_seal_sha256",
    "plan_sha256",
    "packet_sha256",
    "candidate_result_sha256",
    "baseline_result_sha256",
    "candidate_input_sha256",
    "model_manifest_sha256",
    "renderer_path",
    "renderer_sha256",
    "review_html_sha256",
    "ui_contract_sha256",
    "audio_set_sha256",
    "prepared_inventory_sha256",
    "response_absent_at_preseal",
    "receipt_absent_at_preseal",
    "sha256",
}
BLINDED_RESPONSE_KEYS = {
    "schema",
    "review_id",
    "packet_sha256",
    "transaction_sha256",
    "ui_contract_sha256",
    "audio_set_sha256",
    "reviewer_pseudonym",
    "blindness_declaration",
    "started_at",
    "completed_at",
    "responses",
    "sha256",
}
BLINDED_RESPONSE_ROW_KEYS = {
    "presentation_id",
    "selected",
    "audio_sha256_verified",
    "cue_text_sha256_verified",
    "played_a",
    "played_b",
    "candidate_side_concealed",
}
BLINDED_RECEIPT_KEYS = {
    "schema",
    "evaluation_execution_id",
    "review_id",
    "plan_sha256",
    "packet_sha256",
    "response_sha256",
    "transaction_sha256",
    "ui_contract_sha256",
    "audio_set_sha256",
    "randomization_seed_reveal",
    "reviewer_pseudonym",
    "blindness_declaration",
    "candidate_acceptable_ids",
    "candidate_unacceptable_ids",
    "status",
    "sha256",
}


def canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def canonical_sha256(value: object) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def _exact(value: object, keys: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != keys:
        raise ValueError(f"{label} schema is invalid")
    return value


def _self_hashed(
    value: Mapping[str, Any], keys: set[str], schema: str, label: str
) -> Mapping[str, Any]:
    row = _exact(value, keys, label)
    if row.get("schema") != schema:
        raise ValueError(f"{label} schema version is invalid")
    payload = dict(row)
    claimed = payload.pop("sha256")
    if not isinstance(claimed, str) or claimed != canonical_sha256(payload):
        raise ValueError(f"{label} self hash is invalid")
    return row


def _valid_boundary(start: object, end: object) -> bool:
    return (
        not isinstance(start, bool)
        and not isinstance(end, bool)
        and isinstance(start, int)
        and isinstance(end, int)
        and 0 <= start < end
    )


def _observation_map(
    result: Mapping[str, Any],
    *,
    execution_id: str,
    identity_sha256: str,
    test_seal_sha256: str,
    expected_word_ids: set[str],
    expected_cue_ids: set[str],
    label: str,
) -> tuple[dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    result = _exact(result, RESULT_KEYS, label)
    if (
        result.get("schema") != TIMESTAMP_EVALUATION_RESULT_SCHEMA
        or result.get("execution_id") != execution_id
        or result.get("candidate_identity_sha256") != identity_sha256
        or result.get("gold_test_seal_sha256") != test_seal_sha256
    ):
        raise ValueError(f"{label} identity is invalid")
    raw_words = result.get("words")
    raw_cues = result.get("cues")
    if not isinstance(raw_words, list) or not isinstance(raw_cues, list):
        raise ValueError(f"{label} arrays are invalid")

    words: dict[str, Mapping[str, Any]] = {}
    for index, raw in enumerate(raw_words):
        row = _exact(raw, WORD_OBSERVATION_KEYS, f"{label} word {index}")
        identity = row.get("id")
        matched = row.get("matched")
        text = row.get("text")
        start = row.get("hypothesis_start_ms")
        end = row.get("hypothesis_end_ms")
        if (
            not isinstance(identity, str)
            or identity in words
            or not isinstance(text, str)
            or not isinstance(matched, bool)
        ):
            raise ValueError(f"{label} word observation is invalid")
        if matched:
            if not _valid_boundary(start, end):
                raise ValueError(f"{label} matched word boundary is invalid")
        elif start is not None or end is not None:
            raise ValueError(f"{label} unmatched word has a boundary")
        words[identity] = row
    if set(words) != expected_word_ids:
        raise ValueError(f"{label} word set does not match locked test gold")

    cues: dict[str, Mapping[str, Any]] = {}
    for index, raw in enumerate(raw_cues):
        row = _exact(raw, CUE_OBSERVATION_KEYS, f"{label} cue {index}")
        identity = row.get("id")
        matched = row.get("matched")
        start = row.get("hypothesis_start_ms")
        end = row.get("hypothesis_end_ms")
        if (
            not isinstance(identity, str)
            or identity in cues
            or not isinstance(matched, bool)
        ):
            raise ValueError(f"{label} cue observation is invalid")
        if matched:
            if not _valid_boundary(start, end):
                raise ValueError(f"{label} matched cue boundary is invalid")
        elif start is not None or end is not None:
            raise ValueError(f"{label} unmatched cue has a boundary")
        cues[identity] = row
    if set(cues) != expected_cue_ids:
        raise ValueError(f"{label} cue set does not match locked test gold")
    return words, cues


def _audit_map(
    audit: Mapping[str, Any],
    *,
    execution_id: str,
    candidate_identity_sha256: str,
    result_sha256: str,
    candidate_input_sha256: str,
    model_manifest_sha256: str,
    expected_word_ids: set[str],
) -> tuple[dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    audit = _exact(audit, PIPELINE_AUDIT_KEYS, "timestamp pipeline audit")
    if (
        audit.get("schema") != TIMESTAMP_PIPELINE_AUDIT_SCHEMA
        or audit.get("execution_id") != execution_id
        or audit.get("candidate_identity_sha256") != candidate_identity_sha256
        or audit.get("result_sha256") != result_sha256
        or audit.get("candidate_input_sha256") != candidate_input_sha256
        or audit.get("model_manifest_sha256") != model_manifest_sha256
        or not isinstance(audit.get("policy_version"), str)
        or not audit.get("policy_version")
        or not isinstance(audit.get("blocks"), list)
        or not isinstance(audit.get("words"), list)
    ):
        raise ValueError("timestamp pipeline audit identity is invalid")
    rows: dict[str, Mapping[str, Any]] = {}
    for index, raw in enumerate(audit["words"]):
        row = _exact(raw, PIPELINE_WORD_AUDIT_KEYS, f"pipeline audit word {index}")
        identity = row.get("id")
        block_id = row.get("block_id")
        if (
            not isinstance(identity, str)
            or identity in rows
            or (block_id is not None and not isinstance(block_id, str))
        ):
            raise ValueError("timestamp pipeline audit word is invalid")
        rows[identity] = row
    if set(rows) != expected_word_ids:
        raise ValueError("timestamp pipeline audit word set is incomplete")
    blocks: dict[str, Mapping[str, Any]] = {}
    claimed_words: set[str] = set()
    for index, raw in enumerate(audit["blocks"]):
        block = _exact(
            raw, PIPELINE_BLOCK_AUDIT_KEYS, f"pipeline audit block {index}"
        )
        identity = block.get("id")
        owned = block.get("owned_word_ids")
        start = block.get("source_start_ms")
        end = block.get("source_end_ms")
        fallback = block.get("fallback_reason")
        if (
            not isinstance(identity, str)
            or not identity
            or identity in blocks
            or not isinstance(block.get("clip_id"), str)
            or not block.get("clip_id")
            or not isinstance(block.get("chunk_id"), str)
            or not block.get("chunk_id")
            or not isinstance(block.get("audio_sha256"), str)
            or len(block["audio_sha256"]) != 64
            or not _valid_boundary(start, end)
            or not isinstance(block.get("method"), str)
            or not block.get("method")
            or (fallback is not None and (not isinstance(fallback, str) or not fallback))
            or not isinstance(owned, list)
            or len(set(owned)) != len(owned)
            or any(not isinstance(word_id, str) or word_id not in expected_word_ids for word_id in owned)
            or not isinstance(block.get("llm_timing_used"), bool)
        ):
            raise ValueError("timestamp pipeline audit block is invalid")
        if claimed_words.intersection(owned):
            raise ValueError("timestamp pipeline audit word is owned by multiple blocks")
        claimed_words.update(owned)
        blocks[identity] = block
    if not blocks:
        raise ValueError("timestamp pipeline audit contains no evaluated blocks")
    for word_id, row in rows.items():
        block_id = row.get("block_id")
        if block_id is None:
            if word_id in claimed_words:
                raise ValueError("unmatched audit word is claimed by a block")
        elif block_id not in blocks or word_id not in blocks[block_id]["owned_word_ids"]:
            raise ValueError("timestamp pipeline audit word-to-block mapping is invalid")
    return rows, blocks


def _cue_observation_sha256(row: Mapping[str, Any]) -> str:
    return canonical_sha256({key: row[key] for key in sorted(CUE_OBSERVATION_KEYS)})


def _validate_blinded_review(
    evidence: Mapping[str, Mapping[str, Any]],
    *,
    evaluation_execution_id: str,
    candidate_identity_sha256: str,
    baseline_identity_sha256: str,
    candidate_result_sha256: str,
    baseline_result_sha256: str,
    candidate_input_sha256: str,
    model_manifest_sha256: str,
    test_seal_sha256: str,
    candidate_cues: Mapping[str, Mapping[str, Any]],
    baseline_cues: Mapping[str, Mapping[str, Any]],
    cue_review_context: Mapping[str, Mapping[str, str]],
    expected_cue_ids: set[str],
    forbidden_reviewer_pseudonyms: set[str],
    minimum_unique_cues: int,
) -> tuple[int, int]:
    if set(evidence) != {"transaction", "plan", "packet", "response", "receipt"}:
        raise ValueError("blinded cue review evidence is incomplete")
    plan = _self_hashed(
        evidence["plan"], BLINDED_PLAN_KEYS, BLINDED_REVIEW_PLAN_SCHEMA, "review plan"
    )
    packet = _self_hashed(
        evidence["packet"],
        BLINDED_PACKET_KEYS,
        BLINDED_REVIEW_PACKET_SCHEMA,
        "review packet",
    )
    transaction = _self_hashed(
        evidence["transaction"],
        BLINDED_TRANSACTION_KEYS,
        BLINDED_REVIEW_TRANSACTION_SCHEMA,
        "review transaction",
    )
    response = _self_hashed(
        evidence["response"],
        BLINDED_RESPONSE_KEYS,
        BLINDED_REVIEW_RESPONSE_SCHEMA,
        "review response",
    )
    receipt = _self_hashed(
        evidence["receipt"],
        BLINDED_RECEIPT_KEYS,
        BLINDED_REVIEW_RECEIPT_SCHEMA,
        "review receipt",
    )

    review_id = plan.get("review_id")
    if (
        not isinstance(review_id, str)
        or not review_id
        or plan.get("evaluation_execution_id") != evaluation_execution_id
        or plan.get("candidate_identity_sha256") != candidate_identity_sha256
        or plan.get("baseline_identity_sha256") != baseline_identity_sha256
        or plan.get("gold_test_seal_sha256") != test_seal_sha256
        or not isinstance(plan.get("created_at"), str)
        or not plan.get("created_at")
        or not isinstance(plan.get("randomization_commitment"), str)
        or len(plan["randomization_commitment"]) != 64
    ):
        raise ValueError("blinded review plan identity is invalid")
    if (
        packet.get("review_id") != review_id
        or packet.get("evaluation_execution_id") != evaluation_execution_id
        or packet.get("gold_test_seal_sha256") != test_seal_sha256
        or packet.get("created_at") != plan.get("created_at")
        or plan.get("packet_sha256") != packet.get("sha256")
    ):
        raise ValueError("blinded review packet identity is invalid")
    if (
        transaction.get("review_id") != review_id
        or transaction.get("evaluation_execution_id") != evaluation_execution_id
        or transaction.get("candidate_identity_sha256") != candidate_identity_sha256
        or transaction.get("baseline_identity_sha256") != baseline_identity_sha256
        or transaction.get("gold_test_seal_sha256") != test_seal_sha256
        or transaction.get("plan_sha256") != plan.get("sha256")
        or transaction.get("packet_sha256") != packet.get("sha256")
        or transaction.get("candidate_result_sha256") != candidate_result_sha256
        or transaction.get("baseline_result_sha256") != baseline_result_sha256
        or transaction.get("candidate_input_sha256") != candidate_input_sha256
        or transaction.get("model_manifest_sha256") != model_manifest_sha256
        or transaction.get("created_at") != plan.get("created_at")
        or transaction.get("response_absent_at_preseal") is not True
        or transaction.get("receipt_absent_at_preseal") is not True
        or any(
            not isinstance(transaction.get(key), str) or not transaction.get(key)
            for key in (
                "renderer_path",
                "renderer_sha256",
                "review_html_sha256",
                "ui_contract_sha256",
                "audio_set_sha256",
                "prepared_inventory_sha256",
            )
        )
    ):
        raise ValueError("blinded review transaction identity is invalid")

    raw_plan_rows = plan.get("presentations")
    raw_packet_rows = packet.get("presentations")
    if not isinstance(raw_plan_rows, list) or not isinstance(raw_packet_rows, list):
        raise ValueError("blinded review presentations are invalid")
    if len(raw_plan_rows) < minimum_unique_cues or len(raw_plan_rows) != len(raw_packet_rows):
        raise ValueError("blinded review does not cover enough unique test cues")
    plan_rows: dict[str, Mapping[str, Any]] = {}
    cue_ids: set[str] = set()
    for index, raw in enumerate(raw_plan_rows):
        row = _exact(raw, BLINDED_PLAN_PRESENTATION_KEYS, f"review plan row {index}")
        presentation_id = row.get("presentation_id")
        cue_id = row.get("cue_id")
        side = row.get("candidate_side")
        if (
            not isinstance(presentation_id, str)
            or not presentation_id
            or presentation_id in plan_rows
            or not isinstance(cue_id, str)
            or cue_id in cue_ids
            or cue_id not in expected_cue_ids
            or side not in {"A", "B"}
            or row.get("candidate_observation_sha256")
            != _cue_observation_sha256(candidate_cues[cue_id])
            or row.get("baseline_observation_sha256")
            != _cue_observation_sha256(baseline_cues[cue_id])
        ):
            raise ValueError("blinded review plan row is invalid")
        plan_rows[presentation_id] = row
        cue_ids.add(cue_id)

    packet_rows: dict[str, Mapping[str, Any]] = {}
    for index, raw in enumerate(raw_packet_rows):
        row = _exact(
            raw, BLINDED_PACKET_PRESENTATION_KEYS, f"review packet row {index}"
        )
        presentation_id = row.get("presentation_id")
        cue_id = row.get("cue_id")
        if (
            not isinstance(presentation_id, str)
            or presentation_id in packet_rows
            or presentation_id not in plan_rows
            or cue_id != plan_rows[presentation_id]["cue_id"]
        ):
            raise ValueError("blinded review packet row is invalid")
        source = plan_rows[presentation_id]
        expected_a = (
            source["candidate_observation_sha256"]
            if source["candidate_side"] == "A"
            else source["baseline_observation_sha256"]
        )
        expected_b = (
            source["candidate_observation_sha256"]
            if source["candidate_side"] == "B"
            else source["baseline_observation_sha256"]
        )
        candidate = candidate_cues[str(cue_id)]
        baseline = baseline_cues[str(cue_id)]
        option_a = candidate if source["candidate_side"] == "A" else baseline
        option_b = candidate if source["candidate_side"] == "B" else baseline
        context = cue_review_context.get(str(cue_id))
        if (
            row.get("option_a_observation_sha256") != expected_a
            or row.get("option_b_observation_sha256") != expected_b
            or not isinstance(context, Mapping)
            or row.get("clip_id") != context.get("clip_id")
            or row.get("audio_path") != context.get("audio_path")
            or row.get("audio_sha256") != context.get("audio_sha256")
            or row.get("cue_text") != context.get("cue_text")
            or row.get("cue_text_sha256") != context.get("cue_text_sha256")
            or row.get("option_a_start_ms") != option_a.get("hypothesis_start_ms")
            or row.get("option_a_end_ms") != option_a.get("hypothesis_end_ms")
            or row.get("option_b_start_ms") != option_b.get("hypothesis_start_ms")
            or row.get("option_b_end_ms") != option_b.get("hypothesis_end_ms")
        ):
            raise ValueError("blinded review packet reveals or swaps an option")
        packet_rows[presentation_id] = row
    if set(packet_rows) != set(plan_rows):
        raise ValueError("blinded review packet coverage is incomplete")
    audio_inventory = sorted(
        {
            (str(row["audio_path"]), str(row["audio_sha256"]))
            for row in packet_rows.values()
        }
    )
    expected_audio_set_sha256 = canonical_sha256(
        [
            {"audio_path": path, "audio_sha256": digest}
            for path, digest in audio_inventory
        ]
    )
    expected_ui_contract_sha256 = canonical_sha256(
        {
            "schema": BLINDED_REVIEW_TRANSACTION_SCHEMA,
            "renderer_sha256": transaction["renderer_sha256"],
            "packet_sha256": packet["sha256"],
            "review_html_sha256": transaction["review_html_sha256"],
        }
    )
    if (
        transaction.get("audio_set_sha256") != expected_audio_set_sha256
        or transaction.get("ui_contract_sha256") != expected_ui_contract_sha256
    ):
        raise ValueError("blinded review verified-audio UI contract is invalid")

    reviewer = response.get("reviewer_pseudonym")
    if (
        response.get("review_id") != review_id
        or response.get("packet_sha256") != packet.get("sha256")
        or response.get("transaction_sha256") != transaction.get("sha256")
        or response.get("ui_contract_sha256") != transaction.get("ui_contract_sha256")
        or response.get("audio_set_sha256") != transaction.get("audio_set_sha256")
        or not isinstance(reviewer, str)
        or not reviewer
        or reviewer in forbidden_reviewer_pseudonyms
        or response.get("blindness_declaration") is not True
        or not isinstance(response.get("started_at"), str)
        or not isinstance(response.get("completed_at"), str)
        or not plan["created_at"] <= response["started_at"] <= response["completed_at"]
        or not isinstance(response.get("responses"), list)
    ):
        raise ValueError("blinded review response identity is invalid")
    responses: dict[str, str] = {}
    for index, raw in enumerate(response["responses"]):
        row = _exact(raw, BLINDED_RESPONSE_ROW_KEYS, f"review response row {index}")
        identity = row.get("presentation_id")
        selected = row.get("selected")
        packet_row = packet_rows.get(str(identity))
        if (
            not isinstance(identity, str)
            or identity in responses
            or identity not in plan_rows
            or selected not in {"A", "B", "BOTH", "NEITHER"}
            or not isinstance(packet_row, Mapping)
            or row.get("audio_sha256_verified") != packet_row.get("audio_sha256")
            or row.get("cue_text_sha256_verified") != packet_row.get("cue_text_sha256")
            or row.get("played_a") is not True
            or row.get("played_b") is not True
            or row.get("candidate_side_concealed") is not True
        ):
            raise ValueError("blinded review response row is invalid")
        responses[identity] = str(selected)
    if set(responses) != set(plan_rows):
        raise ValueError("blinded review response coverage is incomplete")

    acceptable: list[str] = []
    unacceptable: list[str] = []
    for presentation_id in sorted(plan_rows):
        row = plan_rows[presentation_id]
        selected = responses[presentation_id]
        chosen = selected == row["candidate_side"] or selected == "BOTH"
        (acceptable if chosen else unacceptable).append(str(row["cue_id"]))

    seed_reveal = receipt.get("randomization_seed_reveal")
    if not isinstance(seed_reveal, str):
        raise ValueError("blinded review randomization seed reveal is missing")
    try:
        seed = bytes.fromhex(seed_reveal)
    except ValueError as exc:
        raise ValueError("blinded review randomization seed reveal is invalid") from exc
    if len(seed) != 32 or hashlib.sha256(seed).hexdigest() != plan["randomization_commitment"]:
        raise ValueError("blinded review randomization commitment did not open")
    for row in plan_rows.values():
        expected_side = (
            "A"
            if hashlib.sha256(seed + str(row["cue_id"]).encode("utf-8")).digest()[0] % 2 == 0
            else "B"
        )
        if row["candidate_side"] != expected_side:
            raise ValueError("blinded review option mapping differs from committed seed")

    receipt_payload = {
        "schema": BLINDED_REVIEW_RECEIPT_SCHEMA,
        "evaluation_execution_id": evaluation_execution_id,
        "review_id": review_id,
        "plan_sha256": plan["sha256"],
        "packet_sha256": packet["sha256"],
        "response_sha256": response["sha256"],
        "transaction_sha256": transaction["sha256"],
        "ui_contract_sha256": transaction["ui_contract_sha256"],
        "audio_set_sha256": transaction["audio_set_sha256"],
        "randomization_seed_reveal": seed_reveal,
        "reviewer_pseudonym": reviewer,
        "blindness_declaration": True,
        "candidate_acceptable_ids": acceptable,
        "candidate_unacceptable_ids": unacceptable,
        "status": "COMPLETE_BLINDED_HUMAN_REVIEW",
    }
    for key, expected in receipt_payload.items():
        if receipt.get(key) != expected:
            raise ValueError("blinded review receipt is not a deterministic projection")
    return len(acceptable), len(unacceptable)


def _nearest_rank_p95(values: Sequence[int]) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("timestamp metric group must not be empty")
    return float(ordered[max(0, math.ceil(0.95 * len(ordered)) - 1)])


def timestamp_metrics_from_evidence(
    *,
    manifest: Mapping[str, Any],
    candidate_result: Mapping[str, Any],
    candidate_result_sha256: str,
    baseline_result: Mapping[str, Any],
    baseline_result_sha256: str,
    pipeline_audit: Mapping[str, Any],
    candidate_input_sha256: str,
    model_manifest_sha256: str,
    blinded_review: Mapping[str, Mapping[str, Any]],
    execution_id: str,
    candidate_identity_sha256: str,
    baseline_execution_id: str,
    baseline_identity_sha256: str,
    test_seal_sha256: str,
    minimum_blinded_review_cues: int = 100,
) -> dict[str, Any]:
    """Join candidate observations against authoritative, separately bound truth."""

    clips = manifest.get("clips")
    annotations = manifest.get("annotations")
    if not isinstance(clips, list) or not isinstance(annotations, Mapping):
        raise ValueError("authoritative timestamp manifest is invalid")
    split_by_clip = {
        str(row.get("id")): str(row.get("split"))
        for row in clips
        if isinstance(row, Mapping)
    }
    reference_words = {
        str(row.get("id")): row
        for row in annotations.get("words", [])
        if isinstance(row, Mapping)
        and split_by_clip.get(str(row.get("clip_id"))) == "test"
    }
    reference_cues = {
        str(row.get("id")): row
        for row in annotations.get("cues", [])
        if isinstance(row, Mapping)
        and split_by_clip.get(str(row.get("clip_id"))) == "test"
    }
    clip_audio_sha256 = {
        str(row.get("id")): str(row.get("audio_sha256"))
        for row in clips
        if isinstance(row, Mapping)
    }
    cue_review_context = {
        identity: {
            "clip_id": str(row.get("clip_id")),
            "audio_path": f"review-audio/{row.get('clip_id')}.wav",
            "audio_sha256": clip_audio_sha256[str(row.get("clip_id"))],
            "cue_text": str(row.get("text")),
            "cue_text_sha256": hashlib.sha256(
                str(row.get("text")).encode("utf-8")
            ).hexdigest(),
        }
        for identity, row in reference_cues.items()
    }
    if not reference_words or not reference_cues:
        raise ValueError("locked test reference metric groups must not be empty")
    expected_word_ids = set(reference_words)
    expected_cue_ids = set(reference_cues)
    candidate_words, candidate_cues = _observation_map(
        candidate_result,
        execution_id=execution_id,
        identity_sha256=candidate_identity_sha256,
        test_seal_sha256=test_seal_sha256,
        expected_word_ids=expected_word_ids,
        expected_cue_ids=expected_cue_ids,
        label="candidate timestamp observations",
    )
    baseline_words, baseline_cues = _observation_map(
        baseline_result,
        execution_id=baseline_execution_id,
        identity_sha256=baseline_identity_sha256,
        test_seal_sha256=test_seal_sha256,
        expected_word_ids=expected_word_ids,
        expected_cue_ids=expected_cue_ids,
        label="baseline timestamp observations",
    )
    _, audit_blocks = _audit_map(
        pipeline_audit,
        execution_id=execution_id,
        candidate_identity_sha256=candidate_identity_sha256,
        result_sha256=candidate_result_sha256,
        candidate_input_sha256=candidate_input_sha256,
        model_manifest_sha256=model_manifest_sha256,
        expected_word_ids=expected_word_ids,
    )
    forbidden_reviewers = {
        str(value)
        for value in manifest.get("role_identities", {}).values()
        if isinstance(value, str) and value
    }
    for key in ("annotator_pseudonyms", "adjudicator_pseudonyms"):
        values = annotations.get(key, [])
        if isinstance(values, list):
            forbidden_reviewers.update(
                str(value) for value in values if isinstance(value, str) and value
            )
    blind_correct, blind_incorrect = _validate_blinded_review(
        blinded_review,
        evaluation_execution_id=execution_id,
        candidate_identity_sha256=candidate_identity_sha256,
        baseline_identity_sha256=baseline_identity_sha256,
        candidate_result_sha256=candidate_result_sha256,
        baseline_result_sha256=baseline_result_sha256,
        candidate_input_sha256=candidate_input_sha256,
        model_manifest_sha256=model_manifest_sha256,
        test_seal_sha256=test_seal_sha256,
        candidate_cues=candidate_cues,
        baseline_cues=baseline_cues,
        cue_review_context=cue_review_context,
        expected_cue_ids=expected_cue_ids,
        forbidden_reviewer_pseudonyms=forbidden_reviewers,
        minimum_unique_cues=minimum_blinded_review_cues,
    )

    roles = {"leading": [], "trailing": [], "interior": []}
    matched_words: list[str] = []
    exact_text = True
    start_errors: list[int] = []
    end_errors: list[int] = []
    leading_start_errors: list[int] = []
    interior_candidate: list[int] = []
    interior_baseline: list[int] = []
    over_1000 = 0
    for identity, reference in reference_words.items():
        role = reference.get("role")
        if role not in roles:
            raise ValueError("authoritative word role is invalid")
        roles[str(role)].append(identity)
        candidate = candidate_words[identity]
        baseline = baseline_words[identity]
        exact_text = exact_text and candidate["text"] == reference.get("text")
        if baseline["text"] != reference.get("text") or baseline["matched"] is not True:
            raise ValueError("bound baseline is not a complete same-text projection")
        if candidate["matched"] is not True:
            continue
        matched_words.append(identity)
        start_error = abs(
            int(candidate["hypothesis_start_ms"]) - int(reference["start_ms"])
        )
        end_error = abs(
            int(candidate["hypothesis_end_ms"]) - int(reference["end_ms"])
        )
        start_errors.append(start_error)
        end_errors.append(end_error)
        if role == "leading":
            leading_start_errors.append(start_error)
        if role == "interior":
            interior_candidate.append(start_error)
            interior_baseline.append(
                abs(
                    int(baseline["hypothesis_start_ms"])
                    - int(reference["start_ms"])
                )
            )
        if max(start_error, end_error) > 1000:
            over_1000 += 1

    if any(not rows for rows in roles.values()):
        raise ValueError("authoritative word role metric group must not be empty")
    matched_cues = [
        identity for identity, row in candidate_cues.items() if row["matched"] is True
    ]
    cue_start_errors = [
        abs(
            int(candidate_cues[identity]["hypothesis_start_ms"])
            - int(reference_cues[identity]["appearance_ms"])
        )
        for identity in matched_cues
    ]
    cue_end_errors = [
        abs(
            int(candidate_cues[identity]["hypothesis_end_ms"])
            - int(reference_cues[identity]["disappearance_ms"])
        )
        for identity in matched_cues
    ]

    return {
        "exact_text_unchanged": exact_text,
        "word_count": len(reference_words),
        "matched_word_count": len(matched_words),
        "leading_word_count": len(roles["leading"]),
        "matched_leading_word_count": sum(
            identity in matched_words for identity in roles["leading"]
        ),
        "interior_word_count": len(roles["interior"]),
        "matched_interior_word_count": sum(
            identity in matched_words for identity in roles["interior"]
        ),
        "cue_count": len(reference_cues),
        "matched_cue_count": len(matched_cues),
        "coverage_ratio": len(matched_words) / len(reference_words),
        "leading_coverage_ratio": sum(
            identity in matched_words for identity in roles["leading"]
        )
        / len(roles["leading"]),
        "interior_coverage_ratio": sum(
            identity in matched_words for identity in roles["interior"]
        )
        / len(roles["interior"]),
        "cue_coverage_ratio": len(matched_cues) / len(reference_cues),
        "overall_start_p95_ms": _nearest_rank_p95(start_errors),
        "leading_start_p95_ms": _nearest_rank_p95(leading_start_errors),
        "end_p95_ms": _nearest_rank_p95(end_errors),
        "cue_start_p95_ms": _nearest_rank_p95(cue_start_errors),
        "cue_end_p95_ms": _nearest_rank_p95(cue_end_errors),
        "over_1000ms_count": over_1000,
        "interior_p95_regression_ms": max(
            0.0,
            _nearest_rank_p95(interior_candidate)
            - _nearest_rank_p95(interior_baseline),
        ),
        "silent_fallback_count": sum(
            row["fallback_reason"] is not None for row in audit_blocks.values()
        ),
        "llm_timing_count": sum(
            row["llm_timing_used"] is True for row in audit_blocks.values()
        ),
        "blinded_heldout_cues_correct": blind_correct,
        "blinded_heldout_cues_incorrect": blind_incorrect,
    }


__all__ = [
    "BLINDED_REVIEW_PACKET_SCHEMA",
    "BLINDED_REVIEW_PLAN_SCHEMA",
    "BLINDED_REVIEW_RECEIPT_SCHEMA",
    "BLINDED_REVIEW_RESPONSE_SCHEMA",
    "BLINDED_REVIEW_TRANSACTION_SCHEMA",
    "TIMESTAMP_EVALUATION_RESULT_SCHEMA",
    "TIMESTAMP_PIPELINE_AUDIT_SCHEMA",
    "canonical_sha256",
    "timestamp_metrics_from_evidence",
]
