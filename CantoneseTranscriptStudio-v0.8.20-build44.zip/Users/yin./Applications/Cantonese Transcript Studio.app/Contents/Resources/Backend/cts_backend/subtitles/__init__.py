"""Editable subtitle projects and local burn-in rendering."""

from .ass import generate_ass
from .preview import PreviewProxy
from .project import SubtitleProjectStore
from .render import SubtitleRenderer
from .segmentation import (
    DEFAULT_MAX_CHARACTERS,
    MAX_MAX_CHARACTERS,
    MIN_MAX_CHARACTERS,
    SEGMENTATION_POLICY_VERSION,
    OverLimitCueAudit,
    SegmentedSubtitleCue,
    SubtitleSegmentationAudit,
    SubtitleSegmentationPolicy,
    SubtitleSegmentationResult,
    segment_subtitles,
)
from .schemas import (
    SubtitleCue,
    SubtitleProject,
    SubtitleSpeakerProfile,
    SubtitleSpeakerStyle,
    SubtitleStyle,
)

__all__ = [
    "DEFAULT_MAX_CHARACTERS",
    "MAX_MAX_CHARACTERS",
    "MIN_MAX_CHARACTERS",
    "OverLimitCueAudit",
    "SEGMENTATION_POLICY_VERSION",
    "SegmentedSubtitleCue",
    "SubtitleCue",
    "PreviewProxy",
    "SubtitleProject",
    "SubtitleProjectStore",
    "SubtitleSpeakerProfile",
    "SubtitleSpeakerStyle",
    "SubtitleRenderer",
    "SubtitleSegmentationAudit",
    "SubtitleSegmentationPolicy",
    "SubtitleSegmentationResult",
    "SubtitleStyle",
    "generate_ass",
    "segment_subtitles",
]
