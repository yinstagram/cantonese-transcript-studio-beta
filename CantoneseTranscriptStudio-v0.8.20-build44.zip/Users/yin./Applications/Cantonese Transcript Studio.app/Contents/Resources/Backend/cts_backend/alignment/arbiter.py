"""Fail-closed local candidate selector for bounded ASR reconciliation.

The arbiter never returns transcript text.  It may only return the identifier
of one immutable ASR-grounded candidate, or ``abstain``.  The caller performs
the identifier lookup after strict validation.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence


ARBITER_POLICY_VERSION = "2026-08-24.1"
_CANDIDATE_ID = re.compile(r"c[0-9]{1,2}")
_IDENTIFIER_SAFE = re.compile(r"[^A-Za-z0-9_.-]+")
_LOOPBACK_HOSTS = {"127.0.0.1", "::1"}


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Never let a loopback arbiter redirect transcript-bearing requests."""

    def redirect_request(self, *_: object, **__: object) -> None:
        return None


@dataclass(frozen=True)
class Candidate:
    identifier: str
    text: str
    supported_by: tuple[str, ...] = ()
    # Each candidate is built by deterministic code before Gemma sees it.  The
    # evidence is explanatory only: Gemma never receives an editable output
    # field and cannot introduce words that are absent from a candidate.
    evidence: tuple[Mapping[str, object], ...] = ()


@dataclass(frozen=True)
class ArbitrationResult:
    choice: str
    status: str
    model: str
    policy_version: str = ARBITER_POLICY_VERSION

    @property
    def selected(self) -> bool:
        return self.choice != "abstain"

    def to_dict(self) -> dict[str, object]:
        return {
            "choice": self.choice,
            "status": self.status,
            "model": self.model,
            "policy_version": self.policy_version,
        }


def _validated_endpoint(endpoint: str) -> str:
    parsed = urllib.parse.urlparse(endpoint)
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError("arbiter endpoint port 無效") from exc
    if (
        parsed.scheme != "http"
        or parsed.hostname not in _LOOPBACK_HOSTS
        or port is None
        or not 1024 <= port <= 65_535
        or parsed.path.rstrip("/") != "/v1/chat/completions"
        or parsed.username is not None
        or parsed.password is not None
        or parsed.params
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("arbiter endpoint 必須係本機 loopback chat completions")
    return endpoint


def _strict_candidate_choice(
    content: str, valid_ids: Iterable[str]
) -> tuple[bool, str]:
    """Return schema validity separately from a legitimate abstention."""
    allowed = set(valid_ids)
    try:
        value = json.loads(content)
    except (TypeError, json.JSONDecodeError):
        return False, "abstain"
    if not isinstance(value, dict) or set(value) != {"choice"}:
        return False, "abstain"
    choice = value.get("choice")
    if choice == "abstain":
        return True, "abstain"
    if isinstance(choice, str) and choice in allowed:
        return True, choice
    return False, "abstain"


def parse_candidate_choice(content: str, valid_ids: Iterable[str]) -> str:
    """Accept one exact JSON object and fail closed on every other response."""
    return _strict_candidate_choice(content, valid_ids)[1]


class LocalCandidateArbiter:
    """Use an OpenAI-compatible loopback endpoint as an optional text judge.

    Network proxies are explicitly disabled.  Unavailable endpoints, invalid
    schemas, timeouts and model errors all become ``abstain`` and never fail a
    transcription job.
    """

    policy_version = ARBITER_POLICY_VERSION

    def __init__(
        self,
        *,
        endpoint: str,
        model: str,
        timeout_seconds: float = 45.0,
        max_response_bytes: int = 16_384,
    ) -> None:
        self.endpoint = _validated_endpoint(endpoint)
        self.model = model.strip()
        if not self.model:
            raise ValueError("arbiter model 唔可以空白")
        if not 1.0 <= float(timeout_seconds) <= 120.0:
            raise ValueError("arbiter timeout 必須係 1 至 120 秒")
        self.timeout_seconds = float(timeout_seconds)
        if (
            isinstance(max_response_bytes, bool)
            or not isinstance(max_response_bytes, int)
            or not 256 <= max_response_bytes <= 65_536
        ):
            raise ValueError("arbiter response cap 必須係 256 至 65536 bytes")
        self.max_response_bytes = max_response_bytes
        self._opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), _NoRedirectHandler()
        )
        self._disabled_status: str | None = None

    def choose(
        self,
        candidates: Sequence[Candidate],
        *,
        vocabulary: Sequence[str] = (),
    ) -> ArbitrationResult:
        if self._disabled_status is not None:
            return ArbitrationResult("abstain", "circuit_open", self.model)
        valid_ids = tuple(candidate.identifier for candidate in candidates)
        if (
            len(candidates) < 2
            or len(candidates) > 4
            or len(set(valid_ids)) != len(valid_ids)
            or any(not _CANDIDATE_ID.fullmatch(identifier) for identifier in valid_ids)
            or any(not candidate.text.strip() or len(candidate.text) > 5_000 for candidate in candidates)
        ):
            return ArbitrationResult("abstain", "invalid_candidates", self.model)

        allowed_choices = [*valid_ids, "abstain"]
        user_payload = {
            "task": (
                "Choose the most likely Cantonese transcript candidate. Every candidate is "
                "already an evidence-bounded rewrite prepared from ASR output. Never write text."
            ),
            "vocabulary": list(vocabulary),
            "candidates": [
                {
                    "id": candidate.identifier,
                    "text": candidate.text,
                    "supported_by": list(candidate.supported_by),
                    "evidence": [dict(item) for item in candidate.evidence],
                }
                for candidate in candidates
            ],
            "allowed_choices": allowed_choices,
        }
        request_payload = {
            "model": self.model,
            "temperature": 0,
            "max_tokens": 32,
            "reasoning_effort": "none",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你係香港廣東話逐字稿候選判斷器。你聽唔到音訊，所以只可以根據"
                        "已列出嘅 ASR evidence、多模型支持、用戶提供嘅專有名詞同口語一致性，"
                        "喺現有 candidate ID之中揀一個；冇可靠證據就 abstain。候選本身已由"
                        "程式限制為可追查嘅修訂；你禁止新增、刪除、改寫或翻譯任何文字。"
                        "只輸出一個 JSON object，例如 {\"choice\":\"c0\"}。"
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(user_payload, ensure_ascii=False, separators=(",", ":")),
                },
            ],
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "candidate_choice",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {"choice": {"type": "string", "enum": allowed_choices}},
                        "required": ["choice"],
                        "additionalProperties": False,
                    },
                },
            },
        }
        request = urllib.request.Request(
            self.endpoint,
            data=json.dumps(request_payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                if getattr(response, "status", response.getcode()) != 200:
                    self._disabled_status = "endpoint_error"
                    return ArbitrationResult("abstain", "endpoint_error", self.model)
                raw = response.read(self.max_response_bytes + 1)
                if len(raw) > self.max_response_bytes:
                    self._disabled_status = "response_too_large"
                    return ArbitrationResult(
                        "abstain", "response_too_large", self.model
                    )
                payload = json.loads(raw.decode("utf-8"))
            content = payload["choices"][0]["message"]["content"]
            if not isinstance(content, str):
                self._disabled_status = "invalid_response"
                return ArbitrationResult("abstain", "invalid_response", self.model)
            valid, choice = _strict_candidate_choice(content, valid_ids)
            if not valid:
                self._disabled_status = "invalid_response"
                return ArbitrationResult("abstain", "invalid_response", self.model)
            status = "selected" if choice != "abstain" else "abstained"
            return ArbitrationResult(choice, status, self.model)
        except (
            OSError,
            KeyError,
            IndexError,
            TypeError,
            ValueError,
            json.JSONDecodeError,
            urllib.error.URLError,
        ):
            self._disabled_status = "unavailable"
            return ArbitrationResult("abstain", "unavailable", self.model)


class LMStudioLifecycle:
    """Bounded memory management for the one model selected by Accuracy Mode."""

    def __init__(
        self,
        model: str,
        cli_path: str | None = None,
        *,
        endpoint: str = "http://127.0.0.1:1234/v1/chat/completions",
        api_identifier: str | None = None,
        context_length: int = 4096,
        parallel: int = 1,
        ttl_seconds: int = 300,
    ) -> None:
        self.model = model.strip()
        if not self.model:
            raise ValueError("LM Studio model 唔可以空白")
        safe_model = _IDENTIFIER_SAFE.sub("-", self.model).strip("-.")
        if api_identifier is None:
            self.api_identifier = f"cts-{safe_model or 'local-arbiter'}"
        else:
            candidate = api_identifier.strip() if isinstance(api_identifier, str) else ""
            if (
                not candidate
                or len(candidate) > 200
                or _IDENTIFIER_SAFE.sub("-", candidate) != candidate
            ):
                raise ValueError("LM Studio API identifier 無效")
            self.api_identifier = candidate
        if (
            isinstance(context_length, bool)
            or not isinstance(context_length, int)
            or not 512 <= context_length <= 16_384
        ):
            raise ValueError("LM Studio context length 必須係 512 至 16384")
        if isinstance(parallel, bool) or not isinstance(parallel, int) or not 1 <= parallel <= 4:
            raise ValueError("LM Studio parallel 必須係 1 至 4")
        if (
            isinstance(ttl_seconds, bool)
            or not isinstance(ttl_seconds, int)
            or not 30 <= ttl_seconds <= 3_600
        ):
            raise ValueError("LM Studio TTL 必須係 30 至 3600 秒")
        self.context_length = context_length
        self.parallel = parallel
        self.ttl_seconds = ttl_seconds
        self.endpoint = _validated_endpoint(endpoint)
        parsed_endpoint = urllib.parse.urlparse(self.endpoint)
        self.server_host = str(parsed_endpoint.hostname)
        assert parsed_endpoint.port is not None
        self.server_port = parsed_endpoint.port
        self._server_started_by_us = False
        discovered = cli_path or shutil.which("lms")
        fallback = Path.home() / ".lmstudio" / "bin" / "lms"
        self.cli_path = Path(discovered).expanduser() if discovered else fallback

    def configure_endpoint(self, endpoint: str) -> None:
        """Bind lifecycle server management to the validated arbiter endpoint."""

        if self._server_started_by_us:
            raise RuntimeError("LM Studio server 已由目前 lifecycle 啟動")
        self.endpoint = _validated_endpoint(endpoint)
        parsed_endpoint = urllib.parse.urlparse(self.endpoint)
        self.server_host = str(parsed_endpoint.hostname)
        assert parsed_endpoint.port is not None
        self.server_port = parsed_endpoint.port

    @property
    def available(self) -> bool:
        return self.cli_path.is_file() and os.access(self.cli_path, os.X_OK)

    def _run(self, arguments: Sequence[str], timeout: float) -> subprocess.CompletedProcess[str] | None:
        if not self.available:
            return None
        try:
            return subprocess.run(
                [str(self.cli_path), *arguments],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return None

    def _loaded_values(self) -> list[dict[str, object]] | None:
        status = self._run(["ps", "--json"], timeout=15)
        if status is None or status.returncode != 0:
            return None
        try:
            values = json.loads(status.stdout)
        except json.JSONDecodeError:
            return None
        if not isinstance(values, list):
            return None
        return [value for value in values if isinstance(value, dict)]

    def _dedicated_entries(
        self, values: Sequence[Mapping[str, object]]
    ) -> list[Mapping[str, object]]:
        return [
            value
            for value in values
            if value.get("identifier") == self.api_identifier
        ]

    def _model_keys(self, value: Mapping[str, object]) -> tuple[str, ...]:
        return tuple(
            str(candidate).strip()
            for candidate in (
                value.get("modelKey"),
                value.get("path"),
                value.get("model"),
                value.get("loadedModelKey"),
            )
            if isinstance(candidate, str) and candidate.strip()
        )

    def _matches_expected_model(self, value: Mapping[str, object]) -> bool:
        expected = self.model.casefold()
        return value.get("type") == "llm" and any(
            candidate.casefold() == expected for candidate in self._model_keys(value)
        )

    def _identifier_conflict(
        self, values: Sequence[Mapping[str, object]]
    ) -> bool:
        return any(
            not self._matches_expected_model(value)
            for value in self._dedicated_entries(values)
        )

    def _identifier_conflict_event(
        self, values: Sequence[Mapping[str, object]]
    ) -> dict[str, object]:
        loaded_model_keys = sorted(
            {
                key
                for value in self._dedicated_entries(values)
                for key in self._model_keys(value)
            }
        )
        return {
            "status": "identifier_conflict",
            "model": self.model,
            "api_model": self.api_identifier,
            "loaded_model_keys": loaded_model_keys or ["unknown"],
        }

    def _dedicated_loaded(self, values: Sequence[Mapping[str, object]]) -> bool:
        return any(
            self._matches_expected_model(value)
            for value in self._dedicated_entries(values)
        )

    def _dedicated_identifier_present(
        self, values: Sequence[Mapping[str, object]]
    ) -> bool:
        return bool(self._dedicated_entries(values))

    def _other_llm_identifiers(
        self, values: Sequence[Mapping[str, object]]
    ) -> list[str]:
        return sorted(
            str(value.get("identifier") or value.get("modelKey") or "unknown")
            for value in values
            if value.get("type") == "llm"
            and value.get("identifier") != self.api_identifier
        )

    def _wait_until_unloaded(self, timeout: float = 30.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            values = self._loaded_values()
            if values is not None and not self._dedicated_identifier_present(values):
                return True
            if values is None:
                return False
            time.sleep(0.25)
        return False

    def _wait_until_ready(self, timeout: float = 180.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            values = self._loaded_values()
            if values is None:
                return False
            for value in values:
                if value.get("identifier") != self.api_identifier:
                    continue
                if not self._matches_expected_model(value):
                    return False
                if value.get("status") in {"idle", "loaded", "ready"}:
                    return True
            time.sleep(0.25)
        return False

    def _server_state(self) -> dict[str, object] | None:
        status = self._run(["server", "status", "--json"], timeout=15)
        if status is None or status.returncode != 0:
            return None
        try:
            value = json.loads(status.stdout)
        except json.JSONDecodeError:
            return None
        if not isinstance(value, dict) or not isinstance(value.get("running"), bool):
            return None
        port = value.get("port")
        if port is not None and (
            isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65_535
        ):
            return None
        return value

    def _wait_until_server_running(self, timeout: float = 30.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            state = self._server_state()
            if (
                state is not None
                and state.get("running") is True
                and state.get("port") == self.server_port
            ):
                return True
            time.sleep(0.25)
        return False

    def _ensure_server(self) -> str:
        state = self._server_state()
        if state is None:
            return "server_status_unknown"
        if state.get("running") is True:
            if state.get("port") != self.server_port:
                return "server_port_conflict"
            return "server_already_running"
        started = self._run(
            [
                "server",
                "start",
                "--port",
                str(self.server_port),
                "--bind",
                self.server_host,
            ],
            timeout=30,
        )
        if started is None or started.returncode != 0:
            return "server_start_failed"
        # Audit-only provenance.  `lms server` is process-global and exposes
        # no instance token, so release deliberately never issues `server
        # stop`: doing so could race with and stop another local process's
        # replacement server.  The dedicated Gemma model is still unloaded.
        self._server_started_by_us = True
        if not self._wait_until_server_running():
            return "server_start_timeout"
        return "server_started"

    def _ready_event(self, status: str) -> dict[str, object]:
        server_status = self._ensure_server()
        if server_status not in {"server_started", "server_already_running"}:
            return {
                "status": server_status,
                "model": self.model,
                "reason": server_status,
            }
        return {
            "status": status,
            "model": self.model,
            "api_model": self.api_identifier,
            "reason": server_status,
        }

    def prepare_asr(self) -> dict[str, object]:
        if not self.available:
            return {"status": "cli_missing", "model": self.model}
        values = self._loaded_values()
        if values is None:
            return {"status": "status_unknown", "model": self.model}
        if self._identifier_conflict(values):
            return self._identifier_conflict_event(values)
        others = self._other_llm_identifiers(values)
        if others:
            return {
                "status": "other_models_loaded",
                "model": self.model,
                "loaded_identifiers": others,
            }
        if not self._dedicated_loaded(values):
            return {"status": "already_unloaded", "model": self.model}
        unloaded = self._run(["unload", self.api_identifier], timeout=30)
        if unloaded is None or unloaded.returncode != 0:
            return {"status": "unload_failed", "model": self.model}
        if not self._wait_until_unloaded():
            return {"status": "unload_timeout", "model": self.model}
        return {"status": "unloaded_for_asr", "model": self.model}

    def prepare_arbiter(self) -> dict[str, object]:
        if not self.available:
            return {"status": "cli_missing", "model": self.model}
        values = self._loaded_values()
        if values is None:
            return {"status": "status_unknown", "model": self.model}
        if self._identifier_conflict(values):
            return self._identifier_conflict_event(values)
        others = self._other_llm_identifiers(values)
        if others:
            return {
                "status": "other_models_loaded",
                "model": self.model,
                "loaded_identifiers": others,
            }
        if self._dedicated_loaded(values):
            return self._ready_event("already_loaded")
        loaded = self._run(
            [
                "load",
                self.model,
                "--identifier",
                self.api_identifier,
                "--gpu",
                "max",
                "--context-length",
                str(self.context_length),
                "--parallel",
                str(self.parallel),
                "--ttl",
                str(self.ttl_seconds),
                "--yes",
            ],
            timeout=180,
        )
        if loaded is None:
            return {"status": "status_unknown", "model": self.model}
        if loaded.returncode != 0:
            return {"status": "load_failed", "model": self.model}
        if not self._wait_until_ready():
            current = self._loaded_values()
            if current is not None and self._identifier_conflict(current):
                return self._identifier_conflict_event(current)
            return {"status": "load_timeout", "model": self.model}
        return self._ready_event("loaded")

    def release(self) -> dict[str, object]:
        if not self.available:
            return {"status": "cli_missing", "model": self.model}
        values = self._loaded_values()
        if values is None:
            return {"status": "status_unknown", "model": self.model}
        if self._identifier_conflict(values):
            return self._identifier_conflict_event(values)
        status = "already_unloaded"
        if self._dedicated_loaded(values):
            unloaded = self._run(["unload", self.api_identifier], timeout=30)
            if unloaded is None:
                return {"status": "status_unknown", "model": self.model}
            if unloaded.returncode != 0:
                return {"status": "unload_failed", "model": self.model}
            if not self._wait_until_unloaded():
                return {"status": "unload_timeout", "model": self.model}
            status = "unloaded"
        return {
            "status": status,
            "model": self.model,
            "reason": "model_unloaded_server_preserved",
        }


__all__ = [
    "ARBITER_POLICY_VERSION",
    "ArbitrationResult",
    "Candidate",
    "LocalCandidateArbiter",
    "LMStudioLifecycle",
    "parse_candidate_choice",
]
