"""Strict, fail-closed local judge for same-meaning *and same-extent* spans."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Mapping, Sequence

from .semantic_pair_judge import (
    LocalSemanticPairJudge,
    SemanticPairJudgeAudit,
    SemanticPairJudgment,
    _hard_request_deadline,
    _parse_response,
)
from .semantic_pairing import (
    CandidateSpan,
    ReferenceUnit,
    assert_no_timestamp_fields,
)


SEMANTIC_EXTENT_JUDGE_POLICY_VERSION = (
    "local-semantic-same-extent-judge-m2-sparse-options-2026-09-14"
)
_RELATIONS = ("different", "partial", "same_meaning", "uncertain")


class LocalSemanticExtentJudge(LocalSemanticPairJudge):
    """Require equivalent proposition coverage before returning same_meaning."""

    policy_version = SEMANTIC_EXTENT_JUDGE_POLICY_VERSION

    def judge(
        self,
        reference: ReferenceUnit,
        candidates: Sequence[CandidateSpan],
    ) -> SemanticPairJudgment:
        candidate_count = len(candidates) if isinstance(candidates, Sequence) else 0
        # Full-context retrieval may find nothing or one real candidate. Do
        # not fabricate distractors to satisfy a multiple-choice minimum.
        if (isinstance(reference, ReferenceUnit)
                and isinstance(candidates, Sequence)
                and not isinstance(candidates, (str, bytes, bytearray))
                and candidate_count == 0):
            return self._abstain(reference.unit_id, candidate_count=0,
                                 reason="no_candidate_proposed")
        if self._disabled_reason is not None:
            return self._abstain(
                reference.unit_id,
                candidate_count=candidate_count,
                reason="circuit_open",
            )
        if (
            not isinstance(reference, ReferenceUnit)
            or not isinstance(candidates, Sequence)
            or isinstance(candidates, (str, bytes, bytearray))
            or not 1 <= candidate_count <= 4
            or len(reference.text) > 2_000
        ):
            return self._abstain(
                reference.unit_id if isinstance(reference, ReferenceUnit) else "",
                candidate_count=candidate_count,
                reason="invalid_request",
            )
        spans = {candidate.span_id: candidate for candidate in candidates}
        if (
            len(spans) != candidate_count
            or any(
                not candidate.text.strip()
                or len(candidate.text) > 4_000
                or not candidate.atom_ids
                or len(set(candidate.atom_ids)) != len(candidate.atom_ids)
                for candidate in candidates
            )
        ):
            return self._abstain(
                reference.unit_id,
                candidate_count=candidate_count,
                reason="invalid_candidates",
            )

        allowed_span_ids = [*spans, "abstain"]
        allowed_atom_ids = [atom for span in candidates for atom in span.atom_ids]
        user_payload = {
            "task": (
                "Choose a candidate only when it covers approximately the same meaning AND "
                "the same semantic extent as the formal reference. No timing inference."
            ),
            "reference": {"id": reference.unit_id, "text": reference.text},
            "candidate_options": [
                {
                    "id": candidate.span_id,
                    "text": candidate.text,
                    "evidence_atom_ids": list(candidate.atom_ids),
                }
                for candidate in candidates
            ],
            "allowed_candidate_span_ids": allowed_span_ids,
            "allowed_relations": list(_RELATIONS),
        }
        assert_no_timestamp_fields(user_payload)
        request_payload = {
            "model": self.model,
            "temperature": 0,
            "max_tokens": 160,
            "reasoning_effort": "none",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "你係香港廣東話字幕嘅嚴格語意範圍配對器。reference 可能係正式書面中文，"
                        "candidate 係口語 ASR；口語助詞、同義詞、詞序同正式／口語差異可以接受，"
                        "毋須逐字相同。但 relation='same_meaning' 只可以喺兩邊講緊同一批獨立命題、"
                        "事件同答案範圍時使用：candidate 不可額外包含 reference 以外嘅下一句、"
                        "另一個事件、問題或答案，亦不可漏咗 reference 嘅獨立核心內容。"
                        "只要 candidate 過闊、過窄、由半句開始／完結、混入相鄰內容，必須用 partial；"
                        "數字、否定、人物、專名或核心事件衝突就用 different 或 uncertain。"
                        "如冇同時符合大概意思及相同範圍嘅候選，必須 abstain，relation 只可係"
                        "uncertain 或 different，evidence_atom_ids=[]。你唔可以新增、刪除、改寫、"
                        "翻譯或重排字幕，亦唔可以推斷時間。只輸出一個 JSON object，所有 ID 必須"
                        "係題目提供嘅 immutable IDs。"
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        user_payload,
                        ensure_ascii=False,
                        separators=(",", ":"),
                    ),
                },
            ],
            "response_format": {
                "type": "json_schema",
                "json_schema": {
                    "name": "strict_semantic_extent_proposal",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {
                            "reference_unit_id": {
                                "type": "string",
                                "const": reference.unit_id,
                            },
                            "candidate_span_id": {
                                "type": "string",
                                "enum": allowed_span_ids,
                            },
                            "relation": {"type": "string", "enum": list(_RELATIONS)},
                            "evidence_atom_ids": {
                                "type": "array",
                                "items": {
                                    "type": "string",
                                    "enum": allowed_atom_ids,
                                },
                                "uniqueItems": True,
                                "maxItems": max(len(allowed_atom_ids), 1),
                            },
                        },
                        "required": [
                            "reference_unit_id",
                            "candidate_span_id",
                            "relation",
                            "evidence_atom_ids",
                        ],
                        "additionalProperties": False,
                    },
                },
            },
        }
        request = urllib.request.Request(
            self.endpoint,
            data=json.dumps(request_payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            method="POST",
        )
        try:
            with _hard_request_deadline(self.hard_deadline_seconds):
                with self._opener.open(request, timeout=self.timeout_seconds) as response:
                    status = getattr(response, "status", None)
                    if status is None:
                        status = response.getcode()
                    if status != 200:
                        self._disabled_reason = "http_error"
                        return self._abstain(
                            reference.unit_id,
                            candidate_count=candidate_count,
                            reason="http_error",
                        )
                    raw = response.read(self.max_response_bytes + 1)
            if len(raw) > self.max_response_bytes:
                self._disabled_reason = "response_too_large"
                return self._abstain(
                    reference.unit_id,
                    candidate_count=candidate_count,
                    reason="response_too_large",
                )
            payload = json.loads(raw.decode("utf-8"))
            content = payload["choices"][0]["message"]["content"]
            if not isinstance(content, str):
                return self._abstain(
                    reference.unit_id,
                    candidate_count=candidate_count,
                    reason="invalid_response",
                )
            valid, span_id, relation, evidence, reason = _parse_response(
                content,
                reference_unit_id=reference.unit_id,
                spans=spans,
            )
            if not valid:
                return self._abstain(
                    reference.unit_id,
                    candidate_count=candidate_count,
                    reason=reason,
                )
            return SemanticPairJudgment(
                reference_unit_id=reference.unit_id,
                candidate_span_id=span_id,
                relation=relation,
                evidence_atom_ids=evidence,
                audit=SemanticPairJudgeAudit(
                    status="model_proposed" if span_id is not None else "abstained",
                    model=self.model,
                    candidate_count=candidate_count,
                    reason=reason,
                ),
            )
        except (TimeoutError, urllib.error.URLError) as exc:
            reason = (
                "timeout"
                if isinstance(exc, TimeoutError)
                or (
                    isinstance(exc, urllib.error.URLError)
                    and isinstance(exc.reason, TimeoutError)
                )
                else "unavailable"
            )
            self._disabled_reason = reason
            return self._abstain(
                reference.unit_id,
                candidate_count=candidate_count,
                reason=reason,
            )
        except (
            OSError,
            KeyError,
            IndexError,
            TypeError,
            ValueError,
            json.JSONDecodeError,
        ):
            return self._abstain(
                reference.unit_id,
                candidate_count=candidate_count,
                reason="invalid_response",
            )


__all__ = [
    "LocalSemanticExtentJudge",
    "SEMANTIC_EXTENT_JUDGE_POLICY_VERSION",
]
