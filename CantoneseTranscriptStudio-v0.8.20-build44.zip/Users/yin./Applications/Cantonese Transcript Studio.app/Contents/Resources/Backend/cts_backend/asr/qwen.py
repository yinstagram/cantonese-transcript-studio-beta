"""MLX Qwen3-ASR 0.3.5 adapter using explicit local-path Sessions."""

from __future__ import annotations

import gc
import json
import logging
import math
import time
from pathlib import Path
from typing import Any, Callable, Iterable

from ..audio.chunking import remove_text_overlap
from .qwen_quantized import CONVERTER_SCHEMA, DEFAULT_MODE, DEFAULT_SCOPE
from .types import ASRCancelled, AudioChunk, TranscriptSegment

logger = logging.getLogger(__name__)
Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]
SegmentCompleted = Callable[[TranscriptSegment], None]

QWEN_MIN_NEW_TOKENS = 96
QWEN_MAX_NEW_TOKENS = 256
QWEN_RETRY_MAX_NEW_TOKENS = 384
QWEN_TOKENS_PER_AUDIO_SECOND = 8.0
QWEN_TOKEN_MARGIN = 24


def qwen_runtime_metadata(model_path: str | Path) -> dict[str, Any]:
    """Describe the local numerical runtime without changing model identity.

    Quantized checkpoints remain the same Qwen3-ASR model.  Keeping precision
    metadata separate prevents an MLX Q8 runtime from being mislabeled as a
    different ASR model (or, worse, as the 0.6B fallback).
    """

    config_path = Path(model_path) / "quantization_config.json"
    if not config_path.is_file():
        return {"quantized": False, "precision": "float16"}
    try:
        value = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {"quantized": False, "precision": "float16", "metadata_valid": False}
    if not isinstance(value, dict):
        return {"quantized": False, "precision": "float16", "metadata_valid": False}
    bits = value.get("bits")
    group_size = value.get("group_size")
    mode = value.get("mode")
    if (
        value.get("schema") != CONVERTER_SCHEMA
        or isinstance(bits, bool)
        or bits not in {4, 8}
        or isinstance(group_size, bool)
        or group_size not in {32, 64, 128}
        or mode != DEFAULT_MODE
        or value.get("scope") != DEFAULT_SCOPE
        or value.get("source_dtype") != "BF16"
        or value.get("non_quantized_float_dtype") != "float16"
    ):
        return {"quantized": False, "precision": "float16", "metadata_valid": False}
    return {
        "quantized": True,
        "precision": f"int{bits}",
        "bits": int(bits),
        "group_size": int(group_size),
        "mode": DEFAULT_MODE,
        "scope": DEFAULT_SCOPE,
        "metadata_valid": True,
    }


def qwen_token_budget(duration_seconds: float) -> int:
    """Bound a no-EOS decode while leaving headroom for dense Cantonese speech."""
    adaptive = math.ceil(max(0.0, float(duration_seconds)) * QWEN_TOKENS_PER_AUDIO_SECOND)
    return min(
        QWEN_MAX_NEW_TOKENS,
        max(QWEN_MIN_NEW_TOKENS, adaptive + QWEN_TOKEN_MARGIN),
    )


def mlx_memory_snapshot() -> dict[str, Any]:
    """Return non-sensitive MLX diagnostics without making MLX a test stub dependency."""
    try:
        import mlx.core as mx

        device = mx.device_info(mx.gpu)
        return {
            "device": str(mx.default_device()),
            "device_name": device.get("device_name"),
            "active_bytes": int(mx.get_active_memory()),
            "cache_bytes": int(mx.get_cache_memory()),
            "peak_bytes": int(mx.get_peak_memory()),
            "recommended_working_set_bytes": int(
                device.get("max_recommended_working_set_size", 0) or 0
            ),
        }
    except (ImportError, AttributeError, RuntimeError, TypeError, ValueError):
        return {}


def prepare_mlx_session(session: Any) -> dict[str, Any]:
    """Materialize native weights, then release loader/cast allocator buffers.

    The official Qwen checkpoints are BF16.  mlx-qwen3-asr's FP16 default first
    materializes another full copy and leaves it in the allocator cache until the
    first audio chunk finishes.  On a 16 GB M1 that creates a paging cliff before
    the first progress event.  Keep the package's established FP16 numerical path
    but clear that temporary copy before inference begins.
    """
    try:
        import mlx.core as mx

        model = getattr(session, "model", None)
        parameters = getattr(model, "parameters", None)
        if callable(parameters):
            mx.eval(parameters())
        gc.collect()
        mx.clear_cache()
    except (ImportError, AttributeError, RuntimeError, TypeError, ValueError) as exc:
        # This cleanup is the difference between normal Metal inference and a
        # multi-minute swap cliff on 16 GB Macs.  Never hide a future runtime
        # regression from the technical log.
        logger.warning("MLX session cache cleanup failed before inference: %s", exc)
    return mlx_memory_snapshot()


def release_mlx_memory(session: Any | None = None) -> None:
    """Release session references, package caches, Python GC and Metal cache."""
    if session is not None:
        try:
            del session.model
        except (AttributeError, TypeError):
            pass
        try:
            del session.tokenizer
        except (AttributeError, TypeError):
            pass
    try:
        from mlx_qwen3_asr.load_models import _ModelHolder

        _ModelHolder.clear()
    except (ImportError, AttributeError):
        pass
    try:
        from mlx_qwen3_asr.tokenizer import _TokenizerHolder

        _TokenizerHolder.clear()
    except (ImportError, AttributeError):
        pass
    gc.collect()
    try:
        import mlx.core as mx

        clear = getattr(mx, "clear_cache", None)
        if callable(clear):
            clear()
        else:
            metal = getattr(mx, "metal", None)
            metal_clear = getattr(metal, "clear_cache", None)
            if callable(metal_clear):
                metal_clear()
    except ImportError:
        pass


class QwenASR:
    def __init__(
        self,
        model_path: Path,
        *,
        context: str = "",
        language: str = "Cantonese",
        session_factory: Callable[..., Any] | None = None,
    ) -> None:
        self.model_path = Path(model_path)
        self.context = context
        self.language = language
        self._session_factory = session_factory

    def _validate_local(self) -> None:
        if not self.model_path.is_dir():
            raise FileNotFoundError(f"Qwen local model 唔存在：{self.model_path}")
        if not (self.model_path / "config.json").is_file():
            raise FileNotFoundError(f"Qwen local model 缺少 config.json：{self.model_path}")
        if not list(self.model_path.glob("*.safetensors")):
            raise FileNotFoundError(f"Qwen local model 缺少 safetensors：{self.model_path}")

    def transcribe_chunks(
        self,
        chunks: Iterable[AudioChunk | dict[str, Any] | Any],
        *,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
        initial_previous_text: str = "",
        processed_duration: float = 0.0,
        total_duration: float | None = None,
        segment_completed: SegmentCompleted | None = None,
    ) -> list[TranscriptSegment]:
        self._validate_local()
        items = [AudioChunk.coerce(item) for item in chunks]
        for chunk in items:
            if not chunk.path.is_file():
                raise FileNotFoundError(f"disk chunk 唔存在：{chunk.path}")
        if not items:
            return []
        if self._session_factory is None:
            try:
                from mlx_qwen3_asr import Session
            except ImportError as exc:
                raise RuntimeError("runtime 未安裝 mlx-qwen3-asr==0.3.5") from exc
            session_factory = Session
        else:
            session_factory = self._session_factory

        session = None
        output: list[TranscriptSegment] = []
        # Only a short tail is needed for deterministic overlap removal.  Keeping
        # the complete transcript here made long jobs repeatedly rescan all text.
        previous_text = initial_previous_text[-512:]
        remaining_duration = sum(chunk.duration for chunk in items)
        effective_total_duration = float(total_duration or (processed_duration + remaining_duration))
        processed = float(processed_duration)
        runtime_metadata = qwen_runtime_metadata(self.model_path)
        try:
            # Passing a verified local directory prevents implicit Hub access.
            try:
                import mlx.core as mx
            except ImportError as exc:
                raise RuntimeError("runtime 未安裝 MLX") from exc
            if progress is not None:
                progress({"phase": "primary_model_loading"})
            # Keep the package's tested FP16 inference path.  prepare_mlx_session
            # immediately releases the BF16 -> FP16 conversion cache.
            session = session_factory(str(self.model_path), dtype=mx.float16)
            load_memory = prepare_mlx_session(session)
            if progress is not None:
                progress({"phase": "primary_model_ready"})
            logger.info(
                "Qwen session ready model=%s precision=%s memory=%s",
                self.model_path.name,
                runtime_metadata["precision"],
                load_memory,
            )
            for index, chunk in enumerate(items, start=1):
                if cancelled and cancelled():
                    raise ASRCancelled("已取消 primary transcription")

                def on_model_progress(event: dict[str, Any]) -> None:
                    if progress is None:
                        return
                    local_fraction = event.get("progress")
                    fraction = (
                        (processed + chunk.duration * float(local_fraction)) / effective_total_duration
                        if effective_total_duration and local_fraction is not None
                        else None
                    )
                    progress(
                        {
                            "phase": "primary",
                            "chunk_id": chunk.id,
                            "chunk_index": index,
                            "chunk_total": len(items),
                            "progress": fraction,
                            "model_event": dict(event),
                        }
                    )

                initial_token_budget = qwen_token_budget(chunk.duration)
                token_budget = initial_token_budget
                chunk_started_at = time.perf_counter()
                decode_attempts = 0
                while True:
                    decode_attempts += 1
                    if progress is not None:
                        progress(
                            {
                                "phase": "primary_decoding",
                                "chunk_id": chunk.id,
                                "chunk_index": index,
                                "chunk_total": len(items),
                            }
                        )
                    result = session.transcribe(
                        str(chunk.path),
                        context=self.context,
                        language=self.language,
                        return_timestamps=False,
                        return_chunks=True,
                        max_new_tokens=token_budget,
                        verbose=False,
                        on_progress=on_model_progress,
                    )
                    if not bool(getattr(result, "truncated", False)):
                        break
                    if token_budget >= QWEN_RETRY_MAX_NEW_TOKENS:
                        raise RuntimeError(f"Qwen generation truncated：{chunk.id}")
                    next_budget = min(QWEN_RETRY_MAX_NEW_TOKENS, token_budget + 128)
                    logger.warning(
                        "Qwen chunk hit token budget; retrying chunk=%s budget=%d->%d",
                        chunk.id,
                        token_budget,
                        next_budget,
                    )
                    token_budget = next_budget
                    gc.collect()
                    try:
                        mx.clear_cache()
                    except (AttributeError, RuntimeError):
                        logger.warning("MLX cache cleanup failed before bounded decode retry")
                elapsed = time.perf_counter() - chunk_started_at
                text = str(getattr(result, "text", ""))
                if previous_text and text:
                    text = remove_text_overlap(previous_text, text)
                language = str(getattr(result, "language", self.language) or self.language)
                truncated = bool(getattr(result, "truncated", False))
                if truncated:
                    raise RuntimeError(f"Qwen generation truncated：{chunk.id}")
                metadata = {
                    "finish_reason": getattr(result, "finish_reason", None),
                    "model_chunks": getattr(result, "chunks", None),
                    "model_path": str(self.model_path),
                    "elapsed_seconds": elapsed,
                    "initial_token_budget": initial_token_budget,
                    "token_budget": token_budget,
                    "decode_attempts": decode_attempts,
                    "mlx_memory": mlx_memory_snapshot(),
                    "runtime": dict(runtime_metadata),
                }
                segment = TranscriptSegment(
                    id=chunk.id,
                    start=chunk.transcript_start,
                    end=chunk.transcript_end,
                    text=text,
                    language=language,
                    source="primary",
                    truncated=truncated,
                    metadata=metadata,
                )
                output.append(segment)
                if segment_completed is not None:
                    segment_completed(segment)
                previous_text = (previous_text + text)[-512:]
                processed += chunk.duration
                generated_tokens = sum(
                    int(item.get("generated_tokens", 0) or 0)
                    for item in (getattr(result, "chunks", None) or [])
                    if isinstance(item, dict)
                )
                logger.info(
                    "Qwen chunk complete model=%s chunk=%s audio=%.3fs elapsed=%.3fs "
                    "tokens=%d finish=%s memory=%s",
                    self.model_path.name,
                    chunk.id,
                    chunk.duration,
                    elapsed,
                    generated_tokens,
                    getattr(result, "finish_reason", None),
                    metadata["mlx_memory"],
                )
                if progress is not None:
                    progress(
                        {
                            "phase": "primary",
                            "chunk_id": chunk.id,
                            "chunk_index": index,
                            "chunk_total": len(items),
                            "progress": processed / effective_total_duration
                            if effective_total_duration
                            else 1.0,
                        }
                    )
            return output
        finally:
            release_mlx_memory(session)
            session = None
