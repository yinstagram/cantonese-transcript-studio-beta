"""Fail-safe memory checks before loading the Qwen 1.7B Metal model.

The guard is deliberately read-only.  It never terminates applications or
unloads models: ownership-sensitive cleanup remains the responsibility of the
component that loaded a resource.  This module only prevents a known 16 GB
memory cliff and emits a small, transcript-free audit record.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


_FREE_PERCENT = re.compile(r"memory free percentage:\s*(\d+)%", re.IGNORECASE)
_SWAP_USED = re.compile(
    r"\bused\s*=\s*(\d+(?:\.\d+)?)\s*([KMGT])\b",
    re.IGNORECASE,
)
_LOW_MEMORY_LIMIT = 20 * 1024**3
_CRITICAL_FREE_PERCENT = 10
_MINIMUM_START_FREE_PERCENT = 20
_LIMITED_HEADROOM_FREE_PERCENT = 45
_HIGH_SWAP_USED_BYTES = 4 * 1024**3


class ResourceGuardError(RuntimeError):
    """Raised when starting the 1.7B model would predictably be unsafe."""

    def __init__(self, message: str, report: Mapping[str, Any]) -> None:
        super().__init__(message)
        self.report = dict(report)


@dataclass(frozen=True)
class LoadedLocalModel:
    identifier: str
    model_key: str
    status: str
    size_bytes: int | None


def parse_memory_pressure(value: str) -> int | None:
    """Return the free percentage reported by macOS ``memory_pressure -Q``."""

    match = _FREE_PERCENT.search(value or "")
    if not match:
        return None
    percentage = int(match.group(1))
    return percentage if 0 <= percentage <= 100 else None


def parse_swap_used_bytes(value: str) -> int | None:
    """Return the used swap reported by macOS ``sysctl vm.swapusage``."""

    match = _SWAP_USED.search(value or "")
    if not match:
        return None
    amount = float(match.group(1))
    multiplier = {
        "K": 1024,
        "M": 1024**2,
        "G": 1024**3,
        "T": 1024**4,
    }[match.group(2).upper()]
    return max(0, int(amount * multiplier))


def _safe_int(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    try:
        parsed = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    return parsed if parsed >= 0 else None


def sanitize_loaded_models(values: object) -> tuple[LoadedLocalModel, ...]:
    """Reduce LM Studio process data to the fields needed for memory safety."""

    if not isinstance(values, list):
        return ()
    output: list[LoadedLocalModel] = []
    for value in values:
        if not isinstance(value, Mapping) or value.get("type") != "llm":
            continue
        identifier = str(value.get("identifier") or "unknown").strip() or "unknown"
        model_key = str(
            value.get("modelKey") or value.get("loadedModelKey") or value.get("model") or "unknown"
        ).strip() or "unknown"
        output.append(
            LoadedLocalModel(
                identifier=identifier,
                model_key=model_key,
                status=str(value.get("status") or "unknown"),
                size_bytes=_safe_int(value.get("sizeBytes")),
            )
        )
    return tuple(output)


Runner = Callable[..., subprocess.CompletedProcess[str]]


class MacASRResourceGuard:
    """Inspect macOS memory and local LLM residency before Qwen inference."""

    policy_version = "2026-08-27.2"

    def __init__(
        self,
        *,
        runner: Runner = subprocess.run,
        lms_path: str | Path | None = None,
    ) -> None:
        self._runner = runner
        discovered = str(lms_path) if lms_path else shutil.which("lms")
        fallback = Path.home() / ".lmstudio" / "bin" / "lms"
        self._lms_path = Path(discovered).expanduser() if discovered else fallback

    def _run(self, arguments: Sequence[str], *, timeout: float = 15.0) -> str:
        try:
            result = self._runner(
                list(arguments),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return ""
        return result.stdout.strip() if result.returncode == 0 else ""

    def _memory_bytes(self) -> int | None:
        raw = self._run(["/usr/sbin/sysctl", "-n", "hw.memsize"])
        return _safe_int(raw)

    def _free_percentage(self) -> int | None:
        return parse_memory_pressure(self._run(["/usr/bin/memory_pressure", "-Q"]))

    def _swap_used_bytes(self) -> int | None:
        return parse_swap_used_bytes(
            self._run(["/usr/sbin/sysctl", "-n", "vm.swapusage"])
        )

    def _loaded_models(self) -> tuple[tuple[LoadedLocalModel, ...], str]:
        if not self._lms_path.is_file() or not os.access(self._lms_path, os.X_OK):
            return (), "cli_missing"
        try:
            result = self._runner(
                [str(self._lms_path), "ps", "--json"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=15.0,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return (), "query_failed"
        if result.returncode != 0:
            return (), "query_failed"
        try:
            decoded = json.loads(result.stdout)
        except json.JSONDecodeError:
            return (), "invalid_json"
        if not isinstance(decoded, list):
            return (), "invalid_json"
        return sanitize_loaded_models(decoded), "ok"

    def _lm_studio_process_present(self) -> bool:
        raw = self._run(["/bin/ps", "-axo", "command="])
        folded = raw.casefold()
        return any(
            marker in folded
            for marker in (
                "/lm studio.app/",
                "lm studio.app/contents/macos/lm studio",
                "lmstudio",
                "llmster",
            )
        )

    def inspect(self, *, primary_model: str) -> dict[str, Any]:
        memory_bytes = self._memory_bytes()
        free_percentage = self._free_percentage()
        swap_used_bytes = self._swap_used_bytes()
        lm_studio_process_present = self._lm_studio_process_present()
        if lm_studio_process_present:
            loaded_models, local_model_query_status = self._loaded_models()
        else:
            # `lms ps` can launch LM Studio/llmster on an otherwise idle Mac.
            # Do not let a read-only safety check create the memory pressure it
            # is meant to detect.
            loaded_models, local_model_query_status = (), "not_running"
        low_memory_device = memory_bytes is not None and memory_bytes <= _LOW_MEMORY_LIMIT
        is_qwen_1_7b = primary_model == "Qwen/Qwen3-ASR-1.7B"

        reasons: list[str] = []
        warnings: list[str] = []
        if is_qwen_1_7b and low_memory_device and loaded_models:
            reasons.append("other_local_llm_loaded")
        if (
            is_qwen_1_7b
            and low_memory_device
            and local_model_query_status
            in {"query_failed", "invalid_json", "cli_missing"}
            and lm_studio_process_present
        ):
            reasons.append("local_llm_status_unknown")
        if (
            is_qwen_1_7b
            and low_memory_device
            and not reasons
            and free_percentage is not None
            and free_percentage <= _CRITICAL_FREE_PERCENT
        ):
            reasons.append("critical_memory_pressure")
        elif (
            is_qwen_1_7b
            and low_memory_device
            and not reasons
            and (
                (
                    free_percentage is not None
                    and free_percentage <= _MINIMUM_START_FREE_PERCENT
                )
                or (
                    free_percentage is None
                    and
                    swap_used_bytes is not None
                    and swap_used_bytes >= _HIGH_SWAP_USED_BYTES
                )
            )
        ):
            # Current memory pressure is authoritative. A large swap footprint
            # can remain for hours after pressure has cleared, so use it only
            # when macOS cannot report the current free-memory percentage.
            reasons.append("sustained_memory_pressure")
        elif (
            is_qwen_1_7b
            and low_memory_device
            and not reasons
            and free_percentage is not None
            and free_percentage <= _LIMITED_HEADROOM_FREE_PERCENT
        ):
            # The optimized MLX loader has repeatedly completed real 1.7B jobs
            # on this 16 GB target with 23-41% free. Keep the reduced headroom
            # visible in the audit, but do not make an otherwise usable M4A
            # import fail before the model gets a chance to run.
            warnings.append("limited_memory_headroom")

        return {
            "schema": 1,
            "policy_version": self.policy_version,
            "primary_model": primary_model,
            "memory_bytes": memory_bytes,
            "free_percentage": free_percentage,
            "swap_used_bytes": swap_used_bytes,
            "low_memory_device": low_memory_device,
            "loaded_local_models": [asdict(item) for item in loaded_models],
            "local_model_query_status": local_model_query_status,
            "lm_studio_process_present": lm_studio_process_present,
            "allowed": not reasons,
            "reasons": reasons,
            "warnings": warnings,
            "automatic_app_termination": False,
        }

    def prepare(self, *, primary_model: str) -> dict[str, Any]:
        report = self.inspect(primary_model=primary_model)
        if report["allowed"]:
            return report
        identifiers = ", ".join(
            str(item["identifier"]) for item in report["loaded_local_models"]
        )
        detail = f"（{identifiers}）" if identifiers else ""
        raise ResourceGuardError(
            "1.7B 暫時未開始：記憶體壓力太高"
            f"{detail}。請先確保有足夠可用記憶體再重試，或者切換 0.6B；"
            "App 唔會自動關閉任何程式。",
            report,
        )


__all__ = [
    "LoadedLocalModel",
    "MacASRResourceGuard",
    "ResourceGuardError",
    "parse_memory_pressure",
    "parse_swap_used_bytes",
    "sanitize_loaded_models",
]
