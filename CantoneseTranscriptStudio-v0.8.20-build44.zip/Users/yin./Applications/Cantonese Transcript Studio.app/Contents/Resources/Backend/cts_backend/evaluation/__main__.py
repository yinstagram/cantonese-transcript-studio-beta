from __future__ import annotations

import argparse

from .benchmark import run_benchmark


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build a redacted, local ASR comparison report.",
    )
    parser.add_argument("manifest", help="Benchmark manifest JSON")
    parser.add_argument("--output", required=True, help="Destination metrics JSON")
    parser.add_argument("--markdown-output", help="Optional destination Markdown report")
    arguments = parser.parse_args()
    run_benchmark(arguments.manifest, arguments.output, arguments.markdown_output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
