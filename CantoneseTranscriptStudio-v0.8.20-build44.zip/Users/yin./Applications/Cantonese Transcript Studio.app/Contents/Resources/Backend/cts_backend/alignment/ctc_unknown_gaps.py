"""Opt-in, untrusted CTC diagnostics with acoustically scored unknown slots.

Unknown slots are scaffolding, NOT recognized words or accepted timestamps.
Even a finite, stable path does not establish that the requested words were said.
The caller owns source offsets; this module never edits text or application state.
"""

from __future__ import annotations

import math
from numbers import Integral
from typing import Sequence

import numpy as np


GAP_LOG_PENALTIES = (0.0, math.log(0.5), math.log(0.1))
MAX_UNKNOWN_PROPORTION = 0.10
MAX_UNKNOWN_DURATION_MS = 1000.0
MAX_KNOWN_EDGE_VARIATION_MS = 40.0


def diagnose_ctc_unknown_gaps(
    log_probabilities: np.ndarray,
    token_ids: Sequence[int | None],
    *,
    blank_id: int,
    special_ids: Sequence[int],
    frame_step_ms: float,
) -> dict:
    """Return three untrusted Viterbi diagnostics, without modifying any input.

    The matrix must already be log-normalized. ``-inf`` means zero probability.
    Unknown emission is max(original allowed nonblank/nonspecial log probability)
    plus the fixed per-frame sensitivity penalty; it is never a free wildcard.
    Unknown slots require a blank on BOTH sides, including window boundaries.
    Frames/end times are window-relative and exclusive, not speech boundaries.
    """
    matrix, targets, allowed, step = _validate(
        log_probabilities, token_ids, blank_id, special_ids, frame_step_ms
    )
    unknown_count = sum(value is None for value in targets)
    proportion = unknown_count / len(targets)
    gap_scores = (
        np.max(matrix[:, allowed], axis=1) if unknown_count else None
    )
    variants = [
        _align(matrix, targets, blank_id, gap_scores, penalty, step)
        for penalty in GAP_LOG_PENALTIES
    ]
    for variant in variants:
        reasons = []
        if proportion > MAX_UNKNOWN_PROPORTION:
            reasons.append("unknown_target_proportion_exceeds_10_percent")
        if not variant["finite_path"]:
            reasons.append("no_finite_path")
        if any(
            slot["scaffold_duration_ms"] > MAX_UNKNOWN_DURATION_MS
            for slot in variant["unknown_scaffolds"]
        ):
            reasons.append("unknown_scaffold_exceeds_1000_ms")
        variant["diagnostic_usable"] = not reasons
        variant["unusable_reasons"] = reasons

    stability = []
    all_finite = all(variant["finite_path"] for variant in variants)
    for target_index, token_id in enumerate(targets):
        if token_id is None:
            continue
        start_range = end_range = None
        if all_finite:
            rows = [
                next(row for row in variant["known_tokens"]
                     if row["target_index"] == target_index)
                for variant in variants
            ]
            starts = [row["start_frame"] for row in rows]
            ends = [row["end_frame"] for row in rows]
            start_range = (max(starts) - min(starts)) * step
            end_range = (max(ends) - min(ends)) * step
        stable = bool(
            all_finite
            and start_range <= MAX_KNOWN_EDGE_VARIATION_MS
            and end_range <= MAX_KNOWN_EDGE_VARIATION_MS
        )
        stability.append({
            "target_index": target_index,
            "token_id": token_id,
            "start_variation_ms": start_range,
            "end_variation_ms": end_range,
            "stable_under_gap_penalties": stable,
            "requires_review": True,
            "accuracy_status": "UNKNOWN",
        })
    return {
        "schema": "cts.ctc-unknown-gap-diagnostic/v1",
        "diagnostic_only": True,
        "requires_review": True,
        "accepted_for_app": False,
        "accuracy_status": "UNKNOWN",
        "target_count": len(targets),
        "unknown_target_count": unknown_count,
        "unknown_target_proportion": proportion,
        "frame_count": int(matrix.shape[0]),
        "frame_step_ms": step,
        "policy": {
            "unknown_score": "max_original_allowed_nonblank_nonspecial_log_probability",
            "gap_penalty_applied_per_frame": True,
            "blank_required_before_and_after_unknown": True,
            "max_unknown_target_proportion": MAX_UNKNOWN_PROPORTION,
            "max_unknown_scaffold_duration_ms": MAX_UNKNOWN_DURATION_MS,
            "max_known_edge_variation_ms": MAX_KNOWN_EDGE_VARIATION_MS,
            "source_offsets": "caller_owned",
        },
        "variants": variants,
        "known_edge_stability": stability,
        "diagnostic_usable": all(row["diagnostic_usable"] for row in variants),
        "all_known_edges_stable": bool(stability) and all_finite and all(
            row["stable_under_gap_penalties"] for row in stability
        ),
    }


def _validate(matrix, token_ids, blank_id, special_ids, frame_step_ms):
    matrix = np.asarray(matrix)
    if matrix.ndim != 2 or not matrix.shape[0] or not matrix.shape[1]:
        raise ValueError("log probabilities must be a non-empty frame×vocabulary matrix")
    if not np.issubdtype(matrix.dtype, np.number) or np.iscomplexobj(matrix):
        raise ValueError("log probabilities must be real numeric values")
    if np.isnan(matrix).any() or np.isposinf(matrix).any():
        raise ValueError("log probabilities must not contain NaN or positive infinity")
    if not np.allclose(np.exp(matrix).sum(axis=1), 1.0, rtol=1e-5, atol=1e-7):
        raise ValueError("log probabilities must already be normalized; no renormalization is performed")
    vocab_size = matrix.shape[1]

    def valid_id(value):
        return isinstance(value, Integral) and not isinstance(value, (bool, np.bool_)) and 0 <= value < vocab_size

    if not valid_id(blank_id):
        raise ValueError("blank_id must be an in-range integer")
    specials = tuple(special_ids)
    if any(not valid_id(value) for value in specials):
        raise ValueError("special_ids must contain in-range integers")
    targets = tuple(token_ids)
    if not targets:
        raise ValueError("target must contain at least one token")
    if any(value is not None and (
        not valid_id(value) or value == blank_id or value in specials
    ) for value in targets):
        raise ValueError("known target must be an in-range nonblank nonspecial integer")
    targets = tuple(None if value is None else int(value) for value in targets)
    allowed = [value for value in range(vocab_size) if value != blank_id and value not in specials]
    if None in targets and not allowed:
        raise ValueError("unknown slots require at least one allowed acoustic label")
    if isinstance(frame_step_ms, (bool, np.bool_)):
        raise ValueError("frame_step_ms must be finite and positive")
    try:
        step = float(frame_step_ms)
    except (TypeError, ValueError):
        raise ValueError("frame_step_ms must be finite and positive") from None
    if not math.isfinite(step) or step <= 0:
        raise ValueError("frame_step_ms must be finite and positive")
    return matrix, targets, allowed, step


def _align(matrix, targets, blank_id, gap_scores, penalty, step):
    frame_count = len(matrix)
    state_count = 2 * len(targets) + 1
    emissions = np.empty((frame_count, state_count), dtype=np.float64)
    emissions[:, 0::2] = matrix[:, blank_id, None]
    for index, token_id in enumerate(targets):
        emissions[:, 2 * index + 1] = (
            gap_scores + penalty if token_id is None else matrix[:, token_id]
        )
    scores = np.full(state_count, -np.inf)
    scores[0] = emissions[0, 0]
    if targets[0] is not None:
        scores[1] = emissions[0, 1]
    back = np.full((frame_count, state_count), -1, dtype=np.int8)
    for frame in range(1, frame_count):
        previous = scores
        scores = np.full(state_count, -np.inf)
        for state in range(state_count):
            best, transition = previous[state], 0
            if state and previous[state - 1] > best:
                best, transition = previous[state - 1], 1
            # No skip into OR out of unknown; adjacent actual labels may match.
            if state > 1 and state % 2:
                index = state // 2
                current, prior = targets[index], targets[index - 1]
                if current is not None and prior is not None and current != prior and previous[state - 2] > best:
                    best, transition = previous[state - 2], 2
            if np.isfinite(best):
                scores[state] = best + emissions[frame, state]
                back[frame, state] = transition
    terminals = (state_count - 1,) if targets[-1] is None else (state_count - 1, state_count - 2)
    terminal = max(terminals, key=lambda value: scores[value])
    path_score = float(scores[terminal])
    result = {
        "gap_log_penalty": penalty,
        "finite_path": math.isfinite(path_score),
        "path_log_probability": path_score if math.isfinite(path_score) else None,
        "path_log_probability_per_frame": path_score / frame_count if math.isfinite(path_score) else None,
        "known_tokens": [],
        "unknown_scaffolds": [],
        "requires_review": True,
        "accuracy_status": "UNKNOWN",
    }
    if not result["finite_path"]:
        return result
    states = np.empty(frame_count, dtype=np.int64)
    state = terminal
    for frame in range(frame_count - 1, -1, -1):
        states[frame] = state
        if frame:
            transition = int(back[frame, state])
            if transition < 0:
                raise RuntimeError("finite path has invalid backtrace")
            state -= transition
    for index, token_id in enumerate(targets):
        frames = np.flatnonzero(states == 2 * index + 1)
        if not len(frames):
            raise RuntimeError("finite path omitted a target slot")
        start, end = int(frames[0]), int(frames[-1]) + 1
        if token_id is None:
            result["unknown_scaffolds"].append({
                "target_index": index,
                "token_id": None,
                "lexical_identity": "UNKNOWN",
                "timing_status": "UNKNOWN",
                "scaffold_start_frame": start,
                "scaffold_end_frame": end,
                "scaffold_duration_ms": (end - start) * step,
                "mean_unpenalized_max_log_probability": float(np.mean(gap_scores[frames])),
                "requires_review": True,
                "trusted": False,
            })
        else:
            values = matrix[frames, token_id]
            peak_index = int(np.argmax(values))
            result["known_tokens"].append({
                "target_index": index,
                "token_id": token_id,
                "start_frame": start,
                "end_frame": end,
                "start_ms": start * step,
                "end_ms": end * step,
                "peak_frame": int(frames[peak_index]),
                "mean_log_probability": float(np.mean(values)),
                "peak_probability": float(np.exp(values[peak_index])),
                "requires_review": True,
                "timing_status": "UNKNOWN",
            })
    return result
