"""Private parent-death wrapper for one whisper.cpp batch.

The worker cannot rely on ``Process.terminate()`` reaching grandchildren.  This
small wrapper owns a new process group, starts whisper-cli inside that group,
and kills the group if the backend worker disappears unexpectedly.
"""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import threading
import time


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    return parser


def _group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _terminate_group(process_group_id: int, *, grace_seconds: float = 0.5) -> None:
    try:
        os.killpg(process_group_id, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return
    deadline = time.monotonic() + max(0.0, grace_seconds)
    while time.monotonic() < deadline and _group_exists(process_group_id):
        time.sleep(0.01)
    if _group_exists(process_group_id):
        try:
            os.killpg(process_group_id, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass


def _watch_parent(
    expected_parent_pid: int,
    child_group_id: int,
    stop: threading.Event,
) -> None:
    while not stop.wait(0.25):
        if os.getppid() != expected_parent_pid:
            _terminate_group(child_group_id, grace_seconds=0.1)
            os._exit(73)


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    command = list(arguments.command)
    if command and command[0] == "--":
        command.pop(0)
    if (
        arguments.parent_pid <= 1
        or not command
        or any(not isinstance(item, str) or not item or "\x00" in item for item in command)
    ):
        return 64
    if os.getsid(0) != os.getpid() or os.getpgrp() != os.getpid():
        # The adapter promises start_new_session=True.  Refuse to run when a
        # group signal could target an unrelated process.
        return 64
    if os.getppid() != arguments.parent_pid:
        return 73

    child: subprocess.Popen[bytes] | None = None
    stop = threading.Event()
    watcher: threading.Thread | None = None
    try:
        child = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            close_fds=True,
            start_new_session=True,
            shell=False,
        )
        child_group_id = child.pid

        def terminate_on_signal(signum: int, _frame: object) -> None:
            _terminate_group(child_group_id)
            raise SystemExit(128 + signum)

        signal.signal(signal.SIGTERM, terminate_on_signal)
        signal.signal(signal.SIGINT, terminate_on_signal)
        watcher = threading.Thread(
            target=_watch_parent,
            args=(arguments.parent_pid, child_group_id, stop),
            name="whisper-parent-watch",
            daemon=True,
        )
        watcher.start()
        return child.wait()
    except OSError:
        return 69
    finally:
        stop.set()
        if child is not None:
            _terminate_group(child.pid)
            try:
                child.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                _terminate_group(child.pid, grace_seconds=0.0)
        if watcher is not None:
            watcher.join(timeout=0.5)


if __name__ == "__main__":
    raise SystemExit(main())
