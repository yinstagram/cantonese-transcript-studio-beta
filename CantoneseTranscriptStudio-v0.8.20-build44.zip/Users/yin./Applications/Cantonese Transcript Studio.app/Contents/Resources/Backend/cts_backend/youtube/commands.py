"""Build inert, shell-free argv for the project-pinned yt-dlp runtime."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from .schemas import ArtifactKind, SubtitleSource, SubtitleTrack
from .urls import (
    SocialURL,
    YouTubeResourceKind,
    YouTubeURL,
    validate_remote_url,
)


PROGRESS_PREFIX = "CTS_YTDLP_PROGRESS"
PROGRESS_TEMPLATE = (
    "download:CTS_YTDLP_PROGRESS\t%(progress.status)s\t"
    "%(progress.downloaded_bytes)s\t"
    "%(progress.total_bytes,progress.total_bytes_estimate)s\t"
    "%(progress.fragment_index)s\t%(progress.fragment_count)s"
)
ARTIFACT_PREFIX = "CTS_YTDLP_ARTIFACT"
ARTIFACT_TEMPLATE = "after_move:CTS_YTDLP_ARTIFACT\t%(id)s\t%(filepath)j"

# Anonymous YouTube downloads should not fetch the normal watch webpage first.
# Repeated watch-page requests are much more likely to trigger HTTP 429 / bot
# challenges, while the embedded player client still exposes public formats and
# captions without touching browser cookies.  This client became a supported
# fallback in yt-dlp 2026.08.19, which is pinned by this project.
YOUTUBE_ANONYMOUS_EXTRACTOR_ARGS = (
    "youtube:player_client=web_embedded;player_skip=webpage"
)

# Keep retries finite so cancel remains responsive, but make long downloads
# resilient to brief Wi-Fi changes and CDN fragment failures.  A single
# fragment is downloaded at a time to avoid making YouTube rate limiting worse.
BASE_RELIABILITY_ARGS = (
    "--retries",
    "20",
    "--extractor-retries",
    "5",
    "--file-access-retries",
    "5",
    "--retry-sleep",
    "http:exp=1:20",
    "--retry-sleep",
    "extractor:exp=1:10",
    "--socket-timeout",
    "60",
)
FRAGMENT_RELIABILITY_ARGS = (
    "--fragment-retries",
    "20",
    "--retry-sleep",
    "fragment:exp=1:20",
    "--concurrent-fragments",
    "1",
    "--abort-on-unavailable-fragments",
)


def _absolute_path(
    value: str | Path,
    name: str,
    *,
    preserve_final_symlink: bool = False,
) -> str:
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ValueError(f"{name} 必須係 absolute path")
    if path.name.startswith("-") or any(ord(char) < 32 for char in str(path)):
        raise ValueError(f"{name} 無效")
    if preserve_final_symlink:
        # A venv's ``bin/python`` is intentionally a symlink to the base
        # interpreter.  Executing the lexical venv path is what activates its
        # pyvenv.cfg and site-packages; resolving it first silently drops the
        # pinned yt-dlp installation, especially with Python ``-I``.
        return os.path.normpath(str(path))
    return str(path.resolve(strict=False))


@dataclass(frozen=True)
class YtDlpRuntimePaths:
    python_executable: str
    deno_executable: str
    ffmpeg_executable: str

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "python_executable",
            _absolute_path(
                self.python_executable,
                "python executable",
                preserve_final_symlink=True,
            ),
        )
        object.__setattr__(
            self,
            "deno_executable",
            _absolute_path(self.deno_executable, "Deno executable"),
        )
        object.__setattr__(
            self,
            "ffmpeg_executable",
            _absolute_path(self.ffmpeg_executable, "FFmpeg executable"),
        )


def _common_argv(runtime: YtDlpRuntimePaths, *, youtube_only: bool = True) -> list[str]:
    # -I prevents user-site Python packages and environment injection.  The
    # explicit negative options remain valuable even if a future yt-dlp default
    # changes; --ignore-config prevents credentials/proxies/exec from config.
    argv = [
        runtime.python_executable,
        "-I",
        "-m",
        "yt_dlp",
        "--ignore-config",
        "--no-config-locations",
        "--no-plugin-dirs",
        "--no-js-runtimes",
        "--js-runtimes",
        f"deno:{runtime.deno_executable}",
        "--no-remote-components",
        "--no-update",
        "--no-exec",
        "--no-cookies",
        "--no-cookies-from-browser",
        "--no-cache-dir",
        "--no-write-comments",
        "--no-write-info-json",
        "--no-write-playlist-metafiles",
        "--no-write-thumbnail",
        "--no-mark-watched",
        "--no-wait-for-video",
        "--no-live-from-start",
        "--no-colors",
        *BASE_RELIABILITY_ARGS,
    ]
    if youtube_only:
        argv.extend(
            [
                "--use-extractors",
                "youtube.*",
                "--extractor-args",
                YOUTUBE_ANONYMOUS_EXTRACTOR_ARGS,
            ]
        )
    return argv


def _target(value: str | YouTubeURL | SocialURL) -> YouTubeURL | SocialURL:
    if isinstance(value, (YouTubeURL, SocialURL)):
        # Re-validate even typed input so callers cannot hand-construct a target
        # with a different canonical hostname or option-like value.
        return validate_remote_url(value.canonical_url)
    return validate_remote_url(value)


def build_metadata_argv(
    runtime: YtDlpRuntimePaths,
    target: str | YouTubeURL | SocialURL,
    *,
    flat_playlist: bool | None = None,
) -> tuple[str, ...]:
    parsed = _target(target)
    should_flatten = isinstance(parsed, YouTubeURL) and parsed.kind is YouTubeResourceKind.PLAYLIST
    if flat_playlist is not None and flat_playlist != should_flatten:
        raise ValueError("flat_playlist 必須同 URL 類型一致")
    argv = _common_argv(runtime, youtube_only=isinstance(parsed, YouTubeURL))
    argv.extend(
        [
            "--dump-single-json",
            "--skip-download",
            "--flat-playlist" if should_flatten else "--no-playlist",
            "--",
            parsed.canonical_url,
        ]
    )
    return tuple(argv)


def _safe_workspace(value: str | Path) -> Path:
    raw = Path(value).expanduser()
    if not raw.is_absolute():
        raise ValueError("YouTube workspace 必須係 absolute path")
    if raw.is_symlink():
        raise ValueError("YouTube workspace 唔可以係 symlink")
    if any(ord(char) < 32 for char in str(raw)):
        raise ValueError("YouTube workspace 含有非法字元")
    workspace = raw.resolve(strict=False)
    if workspace.name in {"", ".", ".."}:
        raise ValueError("YouTube workspace 無效")
    return workspace


def _inside(workspace: Path, *parts: str) -> Path:
    candidate = workspace.joinpath(*parts).resolve(strict=False)
    try:
        candidate.relative_to(workspace)
    except ValueError as exc:
        raise ValueError("YouTube artifact path 超出 workspace") from exc
    return candidate


def build_artifact_argv(
    runtime: YtDlpRuntimePaths,
    target: str | YouTubeURL | SocialURL,
    *,
    kind: ArtifactKind,
    workspace: str | Path,
    video_id: str,
    subtitle_track: SubtitleTrack | None = None,
    output_prefix: str = "youtube",
) -> tuple[str, ...]:
    parsed = _target(target)
    if isinstance(parsed, YouTubeURL):
        if parsed.kind is not YouTubeResourceKind.VIDEO or parsed.video_id != video_id:
            raise ValueError("artifact target 同 video_id 唔一致")
    elif parsed.resource_id != video_id:
        raise ValueError("artifact target 同 resource id 唔一致")
    if not output_prefix or not output_prefix.isascii() or not output_prefix.replace("-", "").isalnum():
        raise ValueError("output prefix 無效")
    if not isinstance(kind, ArtifactKind):
        kind = ArtifactKind(str(kind))
    if kind is ArtifactKind.SUBTITLE_NORMALIZED:
        raise ValueError("normalized subtitle 由本機 parser 產生，唔可以下載")
    if kind is ArtifactKind.SUBTITLE_RAW and subtitle_track is None:
        raise ValueError("subtitle artifact 必須指定 track")
    if kind is not ArtifactKind.SUBTITLE_RAW and subtitle_track is not None:
        raise ValueError("只有 subtitle artifact 可以指定 track")

    root = _safe_workspace(workspace)
    output_directory = _inside(root, "raw", kind.value)
    partial_directory = _inside(root, "partial", kind.value)
    output_template = f"{output_prefix}-{video_id}.%(ext)s"

    argv = _common_argv(runtime, youtube_only=isinstance(parsed, YouTubeURL))
    argv.extend(
        [
            "--no-playlist",
            "--continue",
            "--part",
            *FRAGMENT_RELIABILITY_ARGS,
            "--no-overwrites",
            "--ffmpeg-location",
            runtime.ffmpeg_executable,
            "--paths",
            f"home:{output_directory}",
            "--paths",
            f"temp:{partial_directory}",
            "--output",
            output_template,
        ]
    )

    if kind in {ArtifactKind.VIDEO, ArtifactKind.AUDIO}:
        argv.extend(
            [
                "--newline",
                "--progress",
                "--progress-delta",
                "0.5",
                "--progress-template",
                PROGRESS_TEMPLATE,
                "--print",
                ARTIFACT_TEMPLATE
                if isinstance(parsed, YouTubeURL)
                else f"{ARTIFACT_PREFIX}\t{video_id}\t%(filepath)j",
            ]
        )
    if kind is ArtifactKind.VIDEO:
        argv.extend(["--format", "bv*+ba/b"])
    elif kind is ArtifactKind.AUDIO:
        argv.extend(
            [
                "--format",
                "ba/b",
                "--extract-audio",
                "--audio-format",
                "m4a",
                "--audio-quality",
                "0",
            ]
        )
    elif kind is ArtifactKind.SUBTITLE_RAW:
        assert subtitle_track is not None
        if subtitle_track.source is SubtitleSource.LOCAL_ASR:
            raise ValueError("local ASR subtitle 唔可以用 yt-dlp 下載")
        argv.extend(
            [
                "--skip-download",
                (
                    "--write-subs"
                    if subtitle_track.source is SubtitleSource.MANUAL
                    else "--write-auto-subs"
                ),
                "--sub-langs",
                subtitle_track.language,
                "--sub-format",
                subtitle_track.extension,
            ]
        )
    argv.extend(["--", parsed.canonical_url])
    return tuple(argv)


def build_direct_artifact_argv(
    runtime: YtDlpRuntimePaths,
    direct_url: str,
    *,
    kind: ArtifactKind,
    workspace: str | Path,
    video_id: str,
    output_prefix: str = "threads",
) -> tuple[str, ...]:
    """Build a safe argv for a direct HTTPS media URL obtained from a public adapter."""

    if not isinstance(direct_url, str) or len(direct_url) > 16_384:
        raise ValueError("direct media URL 無效")
    from urllib.parse import urlsplit

    try:
        split = urlsplit(direct_url)
        port = split.port
    except ValueError as exc:
        raise ValueError("direct media URL 無效") from exc
    host = (split.hostname or "").lower()
    if (
        split.scheme != "https"
        or not host
        or split.username
        or split.password
        or port not in (None, 443)
        or not host.endswith((".fbcdn.net", ".cdninstagram.com"))
    ):
        raise ValueError("direct media URL 必須係 HTTPS")
    if not video_id or not video_id.isascii() or not video_id.replace("-", "").isalnum():
        raise ValueError("video_id 無效")
    if not output_prefix or not output_prefix.isascii() or not output_prefix.replace("-", "").isalnum():
        raise ValueError("output prefix 無效")
    if kind not in {ArtifactKind.VIDEO, ArtifactKind.AUDIO}:
        raise ValueError("direct URL 只支援影片／音訊")
    root = _safe_workspace(workspace)
    output_directory = _inside(root, "raw", kind.value)
    partial_directory = _inside(root, "partial", kind.value)
    argv = _common_argv(runtime, youtube_only=False)
    argv.extend(
        [
            "--no-playlist",
            "--referer",
            "https://www.threads.com/",
            "--continue",
            "--part",
            *FRAGMENT_RELIABILITY_ARGS,
            "--no-overwrites",
            "--ffmpeg-location",
            runtime.ffmpeg_executable,
            "--paths",
            f"home:{output_directory}",
            "--paths",
            f"temp:{partial_directory}",
            "--output",
            f"{output_prefix}-{video_id}.%(ext)s",
            "--newline",
            "--progress",
            "--progress-delta",
            "0.5",
            "--progress-template",
            PROGRESS_TEMPLATE,
            "--print",
            f"{ARTIFACT_PREFIX}\t{video_id}\t%(filepath)j",
        ]
    )
    if kind is ArtifactKind.VIDEO:
        argv.extend(["--format", "b/b"])
    else:
        argv.extend(
            [
                "--format",
                "b/b",
                "--extract-audio",
                "--audio-format",
                "m4a",
                "--audio-quality",
                "0",
            ]
        )
    argv.extend(["--", direct_url])
    return tuple(argv)
