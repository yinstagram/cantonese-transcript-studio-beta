"""Bounded subprocess supervisor for one Qwen audio chunk.

The in-process adapter in :mod:`cts_backend.asr.qwen` is intentionally kept
small and model focused.  This module owns the failure boundary around it:

* one process group per chunk;
* a dedicated, JSON-lines event file descriptor (model stdout is never
  telemetry);
* independent wall-clock and substantive-progress deadlines;
* atomic, resumable per-chunk result files; and
* bounded TERM -> KILL shutdown on cancellation or failure.

Retries are deliberately *not* implicit.  ``run_chunk`` performs one attempt;
``run_chunk_with_retries`` only retries when its caller explicitly supplies a
``max_retries`` value from zero through two.
"""

from __future__ import annotations

import errno
import hashlib
import hmac
import json
import math
import os
import selectors
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import asdict, dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Final

from .types import ASRCancelled, AudioChunk, TranscriptSegment, VerifierToken


PROTOCOL_VERSION: Final[int] = 1
MAX_CALLER_RETRIES: Final[int] = 2
MAX_EVENT_LINE_BYTES: Final[int] = 16 * 1024
MAX_SEGMENT_LINE_BYTES: Final[int] = 1024 * 1024
MAX_REQUEST_BYTES: Final[int] = 4 * 1024 * 1024
MAX_CHECKPOINT_BYTES: Final[int] = MAX_SEGMENT_LINE_BYTES + 64 * 1024
MAX_TRANSCRIPT_BYTES: Final[int] = 512 * 1024
MAX_METADATA_BYTES: Final[int] = 384 * 1024
MAX_TOKEN_COUNT: Final[int] = 32_768
MAX_EVENT_PIPE_BYTES: Final[int] = 64 * 1024 * 1024
MAX_SEGMENT_PIPE_BYTES: Final[int] = 128 * 1024 * 1024
SHA256_HEX_LENGTH: Final[int] = 64

Cancelled = Callable[[], bool]
Telemetry = Callable[[dict[str, Any]], None]
SegmentCompleted = Callable[[TranscriptSegment], None]


class QwenProcessError(RuntimeError):
    """Base class for classified supervisor failures."""

    category = "qwen_process_error"

    def __init__(self, message: str, *, attempt: int = 1) -> None:
        super().__init__(message)
        self.attempt = int(attempt)


class QwenProcessTimeout(QwenProcessError):
    """The child exceeded a wall or substantive-progress deadline."""

    category = "qwen_timeout"

    def __init__(self, message: str, *, timeout_kind: str, attempt: int = 1) -> None:
        super().__init__(message, attempt=attempt)
        self.timeout_kind = timeout_kind


class QwenChildCrashError(QwenProcessError):
    """The child exited unsuccessfully or was terminated externally."""

    category = "qwen_child_crash"

    def __init__(
        self,
        message: str,
        *,
        returncode: int | None,
        child_category: str = "child_crash",
        attempt: int = 1,
    ) -> None:
        super().__init__(message, attempt=attempt)
        self.returncode = returncode
        self.child_category = child_category


class QwenProtocolError(QwenChildCrashError):
    """The child/result did not satisfy the versioned JSON contract."""

    category = "qwen_protocol_error"

    def __init__(
        self,
        message: str,
        *,
        returncode: int | None = None,
        attempt: int = 1,
    ) -> None:
        super().__init__(
            message,
            returncode=returncode,
            child_category="protocol_error",
            attempt=attempt,
        )


class QwenProcessCancelled(ASRCancelled):
    """The caller cancelled a supervised Qwen chunk."""

    category = "qwen_cancelled"


@dataclass(frozen=True)
class QwenSupervisorConfig:
    """Deadlines and shutdown bounds for a single child attempt."""

    # The first Metal graph compilation on a 16 GB M1 has measured at 188s and
    # can cross five minutes under contention.  Keep that one cold-start window
    # bounded at ten minutes; later chunks retain the tighter 300s limit.
    model_load_timeout_seconds: float = 600.0
    soft_no_progress_seconds: float = 60.0
    hard_no_progress_seconds: float = 300.0
    hard_wall_seconds: float = 14_400.0
    per_chunk_wall_seconds: float = 300.0
    termination_grace_seconds: float = 2.5
    poll_seconds: float = 0.05
    child_heartbeat_seconds: float = 2.0
    pipe_drain_timeout_seconds: float = 2.0

    def __post_init__(self) -> None:
        numeric = {
            "model_load_timeout_seconds": self.model_load_timeout_seconds,
            "soft_no_progress_seconds": self.soft_no_progress_seconds,
            "hard_no_progress_seconds": self.hard_no_progress_seconds,
            "hard_wall_seconds": self.hard_wall_seconds,
            "per_chunk_wall_seconds": self.per_chunk_wall_seconds,
            "termination_grace_seconds": self.termination_grace_seconds,
            "poll_seconds": self.poll_seconds,
            "child_heartbeat_seconds": self.child_heartbeat_seconds,
            "pipe_drain_timeout_seconds": self.pipe_drain_timeout_seconds,
        }
        for name, value in numeric.items():
            if not math.isfinite(float(value)) or float(value) <= 0:
                raise ValueError(f"{name} must be a positive finite number")
        if self.soft_no_progress_seconds >= self.hard_no_progress_seconds:
            raise ValueError("soft no-progress deadline must precede hard deadline")
        if self.per_chunk_wall_seconds > self.hard_wall_seconds:
            raise ValueError("per-chunk wall deadline may not exceed stage wall deadline")
        if self.termination_grace_seconds > 3.0:
            raise ValueError("termination grace may not exceed three seconds")
        if self.poll_seconds > 0.1:
            raise ValueError("poll interval may not exceed 100 ms")
        if self.pipe_drain_timeout_seconds > 10.0:
            raise ValueError("pipe drain timeout may not exceed ten seconds")


@dataclass(frozen=True)
class SupervisedQwenChunk:
    """A completed segment plus its durable checkpoint identity."""

    segment: TranscriptSegment
    request_id: str
    checkpoint_path: Path
    resumed: bool
    attempt: int


@dataclass(frozen=True)
class SupervisedQwenBatch:
    """Ordered durable prefix produced by one or more stage attempts."""

    segments: tuple[TranscriptSegment, ...]
    checkpoint_paths: tuple[Path, ...]
    request_id: str | None
    resumed_count: int
    attempts: int


def _canonical_json(value: Mapping[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def _json_safe(value: Any) -> Any:
    """Convert known protocol values while rejecting opaque model objects."""
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("non-finite float is not JSON safe")
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    item_method = getattr(value, "item", None)
    if callable(item_method):
        scalar = item_method()
        if scalar is not value:
            return _json_safe(scalar)
    raise TypeError(f"unsupported JSON protocol value: {type(value).__name__}")


def _reject_json_constant(value: str) -> None:
    raise ValueError(f"non-finite JSON constant is not allowed: {value}")


def _stable_regular_file(
    path: Path,
    *,
    collect: bool = False,
    max_bytes: int | None = None,
    owner_only: bool = False,
) -> tuple[str, int, bytes | None, tuple[int, ...]]:
    """Hash one non-symlink regular file and reject an in-flight replacement.

    The descriptor is opened with ``O_NOFOLLOW`` where available, then both the
    open descriptor and pathname are compared before and after the read.  This
    does not pretend to sandbox a same-user attacker, but closes the accidental
    replacement/partial-download TOCTOU window relevant to resumable jobs.
    """

    candidate = Path(path).expanduser()
    try:
        pathname_before = os.stat(candidate, follow_symlinks=False)
    except OSError as exc:
        raise ValueError(f"Qwen input file is unavailable: {candidate}") from exc
    if stat.S_ISLNK(pathname_before.st_mode) or not stat.S_ISREG(pathname_before.st_mode):
        raise ValueError(f"Qwen input must be a non-symlink regular file: {candidate}")
    if owner_only and stat.S_IMODE(pathname_before.st_mode) & 0o077:
        raise ValueError("Qwen request file permissions must be owner-only")
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(candidate, flags)
    except OSError as exc:
        raise ValueError(f"Qwen input file could not be opened safely: {candidate}") from exc
    digest = hashlib.sha256()
    payload = bytearray() if collect else None
    observed = 0
    try:
        descriptor_before = os.fstat(descriptor)
        if not stat.S_ISREG(descriptor_before.st_mode):
            raise ValueError(f"Qwen input must be a regular file: {candidate}")
        if (
            descriptor_before.st_dev,
            descriptor_before.st_ino,
        ) != (pathname_before.st_dev, pathname_before.st_ino):
            raise ValueError(f"Qwen input changed before hashing: {candidate}")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            observed += len(block)
            if max_bytes is not None and observed > max_bytes:
                raise ValueError(f"Qwen input exceeds size limit: {candidate}")
            digest.update(block)
            if payload is not None:
                payload.extend(block)
        descriptor_after = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    try:
        pathname_after = os.stat(candidate, follow_symlinks=False)
    except OSError as exc:
        raise ValueError(f"Qwen input disappeared while hashing: {candidate}") from exc
    stable_fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    if any(
        getattr(descriptor_before, name) != getattr(descriptor_after, name)
        or getattr(descriptor_after, name) != getattr(pathname_after, name)
        for name in stable_fields
    ):
        raise ValueError(f"Qwen input changed while hashing: {candidate}")
    if observed != descriptor_after.st_size:
        raise ValueError(f"Qwen input size changed while hashing: {candidate}")
    snapshot = tuple(getattr(descriptor_after, name) for name in stable_fields)
    return (
        digest.hexdigest(),
        observed,
        bytes(payload) if payload is not None else None,
        snapshot,
    )


def _valid_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == SHA256_HEX_LENGTH
        and all(character in "0123456789abcdef" for character in value)
    )


def _audio_identity(path: Path) -> dict[str, Any]:
    digest, size, _payload, _snapshot = _stable_regular_file(path)
    return {"algorithm": "sha256", "sha256": digest, "size": size}


def _model_directory_identity(model_path: Path) -> dict[str, Any]:
    """Fully verify a model manifest/directory and return its content digest."""

    supplied = Path(model_path).expanduser()
    try:
        supplied_stat = os.stat(supplied, follow_symlinks=False)
    except OSError as exc:
        raise ValueError(f"Qwen model directory is unavailable: {supplied}") from exc
    if stat.S_ISLNK(supplied_stat.st_mode) or not stat.S_ISDIR(supplied_stat.st_mode):
        raise ValueError("Qwen model path must be a non-symlink directory")
    root = supplied.resolve(strict=True)
    root_before = os.stat(root, follow_symlinks=False)
    manifest_path = root / "manifest.json"
    records: list[dict[str, Any]] = []
    observations: list[tuple[Path, tuple[int, ...]]] = []
    manifest_sha256: str | None = None
    expected_paths: set[str] = set()

    if manifest_path.is_file():
        manifest_sha256, _size, manifest_bytes, manifest_snapshot = _stable_regular_file(
            manifest_path, collect=True, max_bytes=16 * 1024 * 1024
        )
        observations.append((manifest_path, manifest_snapshot))
        assert manifest_bytes is not None
        try:
            manifest = json.loads(
                manifest_bytes.decode("utf-8"), parse_constant=_reject_json_constant
            )
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
            raise ValueError("Qwen model manifest is invalid") from exc
        raw_files = manifest.get("files") if isinstance(manifest, Mapping) else None
        if not isinstance(raw_files, list) or not raw_files:
            raise ValueError("Qwen model manifest has no files")
        for entry in raw_files:
            if not isinstance(entry, Mapping):
                raise ValueError("Qwen model manifest file entry is invalid")
            relative = PurePosixPath(str(entry.get("path", "")))
            if relative.is_absolute() or not relative.parts or ".." in relative.parts:
                raise ValueError("Qwen model manifest path is invalid")
            relative_text = relative.as_posix()
            if relative_text in expected_paths:
                raise ValueError("Qwen model manifest paths must be unique")
            expected_paths.add(relative_text)
            expected_size = entry.get("size")
            expected_sha256 = entry.get("sha256")
            if (
                isinstance(expected_size, bool)
                or not isinstance(expected_size, int)
                or expected_size < 0
                or not _valid_sha256(expected_sha256)
            ):
                raise ValueError("Qwen model manifest identity is invalid")
            model_file = root.joinpath(*relative.parts)
            digest, size, _payload, snapshot = _stable_regular_file(model_file)
            observations.append((model_file, snapshot))
            if size != expected_size or not hmac.compare_digest(digest, expected_sha256):
                raise ValueError(f"Qwen model file failed manifest verification: {relative_text}")
            records.append({"path": relative_text, "size": size, "sha256": digest})

    # Include unmanifested regular files as well, while excluding the model
    # manager's verification cache and Hub cache.  Therefore adding, removing,
    # or replacing an inference-visible file also invalidates resume identity.
    for candidate in sorted(root.rglob("*")):
        relative = candidate.relative_to(root)
        relative_text = relative.as_posix()
        if relative.parts and relative.parts[0] == ".cache":
            continue
        candidate_stat = os.stat(candidate, follow_symlinks=False)
        if stat.S_ISLNK(candidate_stat.st_mode):
            raise ValueError(f"Qwen model directory contains a symlink: {relative_text}")
        if not stat.S_ISREG(candidate_stat.st_mode):
            continue
        if relative_text in {"manifest.json", ".verification.json"}:
            continue
        if relative_text in expected_paths:
            continue
        digest, size, _payload, snapshot = _stable_regular_file(candidate)
        observations.append((candidate, snapshot))
        records.append({"path": relative_text, "size": size, "sha256": digest})

    records.sort(key=lambda item: str(item["path"]))
    stable_fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
    for candidate, expected_snapshot in observations:
        try:
            current = os.stat(candidate, follow_symlinks=False)
        except OSError as exc:
            raise ValueError("Qwen model file disappeared while hashing") from exc
        actual_snapshot = tuple(getattr(current, name) for name in stable_fields)
        if actual_snapshot != expected_snapshot or not stat.S_ISREG(current.st_mode):
            raise ValueError("Qwen model file changed while hashing")
    root_after = os.stat(root, follow_symlinks=False)
    for name in ("st_dev", "st_ino", "st_mtime_ns", "st_ctime_ns"):
        if getattr(root_before, name) != getattr(root_after, name):
            raise ValueError("Qwen model directory changed while hashing")
    identity_payload = {
        "schema": 1,
        "manifest_sha256": manifest_sha256,
        "files": records,
    }
    digest = hashlib.sha256(_canonical_json(identity_payload)).hexdigest()
    return {
        "algorithm": "sha256",
        "digest": digest,
        "manifest_sha256": manifest_sha256,
        "file_count": len(records),
    }


def verify_request_inputs(request: Mapping[str, Any]) -> None:
    """Re-hash every bound input immediately before child inference."""

    expected_model = request.get("model_identity")
    actual_model = _model_directory_identity(Path(str(request.get("model_path", ""))))
    if not isinstance(expected_model, Mapping) or not hmac.compare_digest(
        _canonical_json(_json_safe(dict(expected_model))),
        _canonical_json(_json_safe(actual_model)),
    ):
        raise ValueError("Qwen model identity changed after request creation")
    raw_chunks = request.get("chunks")
    if not isinstance(raw_chunks, list):
        raw_chunks = [request.get("chunk")]
    for chunk in raw_chunks:
        if not isinstance(chunk, Mapping):
            raise ValueError("Qwen request chunk is invalid")
        expected_audio = chunk.get("audio_identity")
        actual_audio = _audio_identity(Path(str(chunk.get("path", ""))))
        if not isinstance(expected_audio, Mapping) or not hmac.compare_digest(
            _canonical_json(_json_safe(dict(expected_audio))),
            _canonical_json(_json_safe(actual_audio)),
        ):
            raise ValueError("Qwen audio identity changed after request creation")


def atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    """Durably replace ``path`` with one complete, mode-0600 JSON document."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    safe_payload = _json_safe(payload)
    encoded = _canonical_json(safe_payload)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.",
        suffix=".tmp",
        dir=destination.parent,
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "wb", closefd=True) as handle:
            handle.write(encoded)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
        try:
            directory_fd = os.open(destination.parent, os.O_RDONLY)
        except OSError:
            return
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        # Preserve an interrupted temporary file as forensic evidence.  A later
        # atomic replace cannot mistake it for a completed checkpoint.
        try:
            os.close(descriptor)
        except OSError:
            pass
        raise


def _request_payload(
    *,
    model_path: Path,
    chunk: AudioChunk,
    context: str,
    language: str,
    initial_previous_text: str,
    processed_duration: float,
    total_duration: float | None,
    model_identity: Mapping[str, Any],
    audio_identity: Mapping[str, Any],
) -> dict[str, Any]:
    base: dict[str, Any] = {
        "protocol_version": PROTOCOL_VERSION,
        "model_path": str(Path(model_path).expanduser().resolve()),
        "model_identity": dict(model_identity),
        "chunk": {
            "id": chunk.id,
            "path": str(chunk.path.expanduser().resolve()),
            "audio_identity": dict(audio_identity),
            "start": chunk.start,
            "end": chunk.end,
            "index": chunk.index,
            "core_start": chunk.core_start,
            "core_end": chunk.core_end,
        },
        "context": str(context),
        "language": str(language),
        "initial_previous_text": str(initial_previous_text)[-512:],
        "processed_duration": float(processed_duration),
        "total_duration": float(total_duration) if total_duration is not None else None,
    }
    request_id = hashlib.sha256(_canonical_json(_json_safe(base))).hexdigest()
    return {**base, "request_id": request_id}


def _batch_request_payload(
    *,
    model_path: Path,
    chunks: Sequence[AudioChunk],
    context: str,
    language: str,
    initial_previous_text: str,
    processed_duration: float,
    total_duration: float | None,
    model_identity: Mapping[str, Any],
    audio_identities: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    base: dict[str, Any] = {
        "protocol_version": PROTOCOL_VERSION,
        "mode": "batch",
        "model_path": str(Path(model_path).expanduser().resolve()),
        "model_identity": dict(model_identity),
        "chunks": [
            {
                "id": chunk.id,
                "path": str(chunk.path.expanduser().resolve()),
                "audio_identity": dict(audio_identities[chunk.id]),
                "start": chunk.start,
                "end": chunk.end,
                "index": chunk.index,
                "core_start": chunk.core_start,
                "core_end": chunk.core_end,
            }
            for chunk in chunks
        ],
        "context": str(context),
        "language": str(language),
        "initial_previous_text": str(initial_previous_text)[-512:],
        "processed_duration": float(processed_duration),
        "total_duration": float(total_duration) if total_duration is not None else None,
    }
    request_id = hashlib.sha256(_canonical_json(_json_safe(base))).hexdigest()
    return {**base, "request_id": request_id}


def validate_request_payload(value: Any) -> dict[str, Any]:
    """Validate the complete child request and its content-derived identity."""
    if not isinstance(value, Mapping):
        raise ValueError("Qwen request must be a JSON object")
    payload = dict(value)
    if payload.get("protocol_version") != PROTOCOL_VERSION:
        raise ValueError("unsupported Qwen child protocol version")
    request_id = payload.pop("request_id", None)
    if not isinstance(request_id, str) or len(request_id) != 64:
        raise ValueError("Qwen request_id is invalid")
    expected = hashlib.sha256(_canonical_json(_json_safe(payload))).hexdigest()
    if not hmac.compare_digest(request_id, expected):
        raise ValueError("Qwen request_id does not match request content")
    model_identity = payload.get("model_identity")
    if (
        not isinstance(model_identity, Mapping)
        or model_identity.get("algorithm") != "sha256"
        or not _valid_sha256(model_identity.get("digest"))
        or (
            model_identity.get("manifest_sha256") is not None
            and not _valid_sha256(model_identity.get("manifest_sha256"))
        )
        or isinstance(model_identity.get("file_count"), bool)
        or not isinstance(model_identity.get("file_count"), int)
        or int(model_identity.get("file_count", -1)) < 0
    ):
        raise ValueError("Qwen model identity is invalid")
    raw_chunks: Any
    if payload.get("mode") == "batch":
        raw_chunks = payload.get("chunks")
        if not isinstance(raw_chunks, list) or not raw_chunks:
            raise ValueError("Qwen batch request chunks are invalid")
    else:
        raw_chunks = [payload.get("chunk")]
    identifiers: set[str] = set()
    for chunk in raw_chunks:
        if not isinstance(chunk, Mapping) or not str(chunk.get("id", "")):
            raise ValueError("Qwen request chunk is invalid")
        identifier = str(chunk["id"])
        if identifier in identifiers:
            raise ValueError("Qwen request chunk ids must be unique")
        identifiers.add(identifier)
        audio_identity = chunk.get("audio_identity")
        if (
            not isinstance(audio_identity, Mapping)
            or audio_identity.get("algorithm") != "sha256"
            or not _valid_sha256(audio_identity.get("sha256"))
            or isinstance(audio_identity.get("size"), bool)
            or not isinstance(audio_identity.get("size"), int)
            or int(audio_identity.get("size", -1)) < 0
        ):
            raise ValueError("Qwen audio identity is invalid")
        for key in ("start", "end"):
            if key not in chunk or isinstance(chunk[key], bool):
                raise ValueError(f"Qwen chunk {key} is invalid")
            number = float(chunk[key])
            if not math.isfinite(number):
                raise ValueError(f"Qwen chunk {key} must be finite")
        if float(chunk["end"]) < float(chunk["start"]):
            raise ValueError("Qwen chunk end precedes start")
    payload["request_id"] = request_id
    return payload


def load_request(path: Path) -> dict[str, Any]:
    _digest, _size, payload, _snapshot = _stable_regular_file(
        path, collect=True, max_bytes=MAX_REQUEST_BYTES, owner_only=True
    )
    assert payload is not None
    try:
        decoded = json.loads(
            payload.decode("utf-8"), parse_constant=_reject_json_constant
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError("Qwen request is not valid JSON") from exc
    return validate_request_payload(decoded)


def completed_checkpoint(
    request: Mapping[str, Any], segment: TranscriptSegment, *, attempt: int
) -> dict[str, Any]:
    """Build the only payload which is accepted as a resumable checkpoint."""
    payload = {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": str(request["request_id"]),
        "chunk_id": str(request["chunk"]["id"]),
        "input_identity": {
            "audio_sha256": str(request["chunk"]["audio_identity"]["sha256"]),
            "model_digest": str(request["model_identity"]["digest"]),
        },
        "status": "completed",
        "attempt": int(attempt),
        "segment": _json_safe(asdict(segment)),
    }
    # This is an integrity seal for accidental/manual corruption, not an
    # authentication boundary against a malicious process running as the same
    # macOS user.  Crucially, the seal is checked before transcript data can be
    # returned or forwarded to the primary journal callback.
    payload["payload_sha256"] = hashlib.sha256(_canonical_json(payload)).hexdigest()
    return payload


def segment_protocol_payload(segment: TranscriptSegment) -> dict[str, Any]:
    """Serialize a transcript segment for the private result channel."""
    return dict(_json_safe(asdict(segment)))


def failed_checkpoint(
    request: Mapping[str, Any] | None,
    *,
    attempt: int,
    category: str,
    error_type: str,
) -> dict[str, Any]:
    """Build a non-resumable failure record without error text/transcript."""
    chunk = request.get("chunk", {}) if isinstance(request, Mapping) else {}
    return {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": str(request.get("request_id", "unknown"))
        if isinstance(request, Mapping)
        else "unknown",
        "chunk_id": str(chunk.get("id", "unknown")) if isinstance(chunk, Mapping) else "unknown",
        "status": "failed",
        "attempt": int(attempt),
        "error": {"category": str(category), "type": str(error_type)},
    }


def completed_batch_manifest(
    request: Mapping[str, Any], *, attempt: int, completed_chunk_ids: Sequence[str]
) -> dict[str, Any]:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": str(request["request_id"]),
        "status": "completed",
        "attempt": int(attempt),
        "completed_chunk_ids": [str(item) for item in completed_chunk_ids],
    }


def failed_batch_manifest(
    request: Mapping[str, Any] | None,
    *,
    attempt: int,
    category: str,
    error_type: str,
) -> dict[str, Any]:
    return {
        "protocol_version": PROTOCOL_VERSION,
        "request_id": str(request.get("request_id", "unknown"))
        if isinstance(request, Mapping)
        else "unknown",
        "status": "failed",
        "attempt": int(attempt),
        "error": {"category": str(category), "type": str(error_type)},
    }


def _segment_from_payload(value: Any, *, expected_chunk: AudioChunk) -> TranscriptSegment:
    if not isinstance(value, Mapping):
        raise ValueError("completed checkpoint segment must be an object")
    expected_keys = {
        "id",
        "start",
        "end",
        "text",
        "language",
        "source",
        "tokens",
        "truncated",
        "metadata",
    }
    if set(value) != expected_keys:
        raise ValueError("checkpoint segment schema is invalid")
    identifier = str(value.get("id", ""))
    if identifier != expected_chunk.id:
        raise ValueError("checkpoint segment does not match requested chunk")
    text = value.get("text")
    language = value.get("language")
    source = value.get("source")
    truncated = value.get("truncated")
    if not isinstance(text, str) or len(text.encode("utf-8")) > MAX_TRANSCRIPT_BYTES:
        raise ValueError("checkpoint transcript text is invalid")
    if "\x00" in text:
        raise ValueError("checkpoint transcript contains a NUL byte")
    if (
        not isinstance(language, str)
        or not language
        or len(language.encode("utf-8")) > 64
    ):
        raise ValueError("checkpoint language is invalid")
    if source != "primary":
        raise ValueError("checkpoint source must be primary")
    if not isinstance(truncated, bool) or truncated:
        raise ValueError("truncated Qwen segments are not resumable")
    tokens_value = value.get("tokens", [])
    if not isinstance(tokens_value, list) or len(tokens_value) > MAX_TOKEN_COUNT:
        raise ValueError("checkpoint tokens must be a list")
    try:
        start = float(value["start"])
        end = float(value["end"])
    except (TypeError, ValueError) as exc:
        raise ValueError("checkpoint timestamps are invalid") from exc
    if (
        isinstance(value["start"], bool)
        or isinstance(value["end"], bool)
        or not math.isfinite(start)
        or not math.isfinite(end)
        or end < start
        or not math.isclose(start, expected_chunk.transcript_start, abs_tol=1e-6)
        or not math.isclose(end, expected_chunk.transcript_end, abs_tol=1e-6)
    ):
        raise ValueError("checkpoint timestamps do not match requested chunk")
    tokens: list[VerifierToken] = []
    for token in tokens_value:
        if not isinstance(token, Mapping) or set(token) != {
            "token",
            "timestamp",
            "log_probability",
        }:
            raise ValueError("checkpoint token must be an object")
        token_text = token.get("token")
        if (
            not isinstance(token_text, str)
            or len(token_text.encode("utf-8")) > 4096
            or "\x00" in token_text
        ):
            raise ValueError("checkpoint token text is invalid")
        if isinstance(token.get("timestamp"), bool):
            raise ValueError("checkpoint token timestamp is invalid")
        timestamp = float(token["timestamp"])
        if (
            not math.isfinite(timestamp)
            or timestamp < start - 1e-6
            or timestamp > end + 1e-6
        ):
            raise ValueError("checkpoint token timestamp is out of range")
        raw_probability = token.get("log_probability")
        if isinstance(raw_probability, bool):
            raise ValueError("checkpoint token probability is invalid")
        probability = float(raw_probability) if raw_probability is not None else None
        if probability is not None and not math.isfinite(probability):
            raise ValueError("checkpoint token probability is invalid")
        tokens.append(
            VerifierToken(
                token=token_text,
                timestamp=timestamp,
                log_probability=probability,
            )
        )
    metadata = value.get("metadata", {})
    if not isinstance(metadata, Mapping):
        raise ValueError("checkpoint metadata must be an object")
    try:
        safe_metadata = _json_safe(metadata)
        if len(_canonical_json(safe_metadata)) > MAX_METADATA_BYTES:
            raise ValueError("checkpoint metadata exceeds size limit")
    except (TypeError, ValueError) as exc:
        raise ValueError("checkpoint metadata is invalid") from exc
    return TranscriptSegment(
        id=identifier,
        start=start,
        end=end,
        text=text,
        language=language,
        source="primary",
        tokens=tokens,
        truncated=False,
        metadata=dict(safe_metadata),
    )


def _quarantine_invalid_checkpoint(path: Path) -> Path | None:
    checkpoint = Path(path)
    if not checkpoint.exists() and not checkpoint.is_symlink():
        return None
    destination = checkpoint.with_name(
        f"{checkpoint.name}.invalid-{time.time_ns()}-{uuid.uuid4().hex[:8]}"
    )
    try:
        os.replace(checkpoint, destination)
    except OSError:
        return None
    return destination


def load_completed_checkpoint(
    path: Path,
    *,
    expected_request_id: str,
    expected_chunk: AudioChunk,
    expected_audio_sha256: str,
    expected_model_digest: str,
) -> TranscriptSegment | None:
    """Return a verified completed segment; failures are never resumable."""
    checkpoint = Path(path)
    if not checkpoint.is_file():
        return None
    try:
        _digest, _size, raw, _snapshot = _stable_regular_file(
            checkpoint, collect=True, max_bytes=MAX_CHECKPOINT_BYTES, owner_only=True
        )
        assert raw is not None
        value = json.loads(
            raw.decode("utf-8"), parse_constant=_reject_json_constant
        )
        if not isinstance(value, Mapping):
            raise ValueError("Qwen checkpoint must be an object")
        if value.get("status") != "completed":
            return None
        if set(value) != {
            "protocol_version",
            "request_id",
            "chunk_id",
            "input_identity",
            "status",
            "attempt",
            "segment",
            "payload_sha256",
        }:
            raise ValueError("Qwen checkpoint schema is invalid")
        payload_sha256 = value.get("payload_sha256")
        if not _valid_sha256(payload_sha256):
            raise ValueError("Qwen checkpoint payload digest is invalid")
        unsigned = dict(value)
        unsigned.pop("payload_sha256", None)
        actual_payload_sha256 = hashlib.sha256(_canonical_json(_json_safe(unsigned))).hexdigest()
        if not hmac.compare_digest(str(payload_sha256), actual_payload_sha256):
            raise ValueError("Qwen checkpoint payload digest mismatch")
        if value.get("protocol_version") != PROTOCOL_VERSION:
            raise ValueError("Qwen checkpoint protocol version mismatch")
        if value.get("request_id") != expected_request_id:
            raise ValueError("Qwen checkpoint request_id mismatch")
        if value.get("chunk_id") != expected_chunk.id:
            raise ValueError("Qwen checkpoint chunk_id mismatch")
        attempt = value.get("attempt")
        if isinstance(attempt, bool) or not isinstance(attempt, int) or attempt < 1:
            raise ValueError("Qwen checkpoint attempt is invalid")
        input_identity = value.get("input_identity")
        if not isinstance(input_identity, Mapping) or set(input_identity) != {
            "audio_sha256",
            "model_digest",
        }:
            raise ValueError("Qwen checkpoint input identity is invalid")
        if not hmac.compare_digest(
            str(input_identity.get("audio_sha256", "")), expected_audio_sha256
        ) or not hmac.compare_digest(
            str(input_identity.get("model_digest", "")), expected_model_digest
        ):
            raise ValueError("Qwen checkpoint input identity mismatch")
        return _segment_from_payload(value.get("segment"), expected_chunk=expected_chunk)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError) as exc:
        _quarantine_invalid_checkpoint(checkpoint)
        raise ValueError("Qwen checkpoint failed semantic validation") from exc


def _read_failure_category(path: Path, request_id: str) -> str:
    try:
        with Path(path).open("r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return "child_crash"
    if not isinstance(value, Mapping) or value.get("request_id") != request_id:
        return "child_crash"
    error = value.get("error", {})
    if isinstance(error, Mapping):
        return str(error.get("category", "child_crash"))
    return "child_crash"


def _group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _signal_group(process_group_id: int, signum: int) -> bool:
    try:
        os.killpg(process_group_id, signum)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # A diagnostic sandbox can deny signalling the process group even
        # though the direct child is owned by this worker.  The caller falls
        # back to Popen.terminate()/kill() and must preserve the original
        # timeout classification instead of masking it with EPERM.
        return False


def terminate_process_group(
    process: subprocess.Popen[bytes], *, grace_seconds: float
) -> None:
    """Terminate and reap the owned process group within a three-second grace."""
    process_group_id = process.pid
    shutdown_started = time.monotonic()
    shutdown_deadline = shutdown_started + 2.85
    if not _signal_group(process_group_id, signal.SIGTERM):
        try:
            process.terminate()
        except (ProcessLookupError, PermissionError):
            pass
    term_deadline = shutdown_started + min(2.4, max(0.0, float(grace_seconds)))
    while time.monotonic() < term_deadline:
        if process.poll() is not None and not _group_exists(process_group_id):
            break
        time.sleep(0.01)
    if _group_exists(process_group_id):
        if not _signal_group(process_group_id, signal.SIGKILL):
            try:
                process.kill()
            except (ProcessLookupError, PermissionError):
                pass
    remaining = max(0.01, shutdown_deadline - time.monotonic())
    try:
        process.wait(timeout=remaining)
    except subprocess.TimeoutExpired:
        if not _signal_group(process_group_id, signal.SIGKILL):
            try:
                process.kill()
            except (ProcessLookupError, PermissionError):
                pass
        # SIGKILL has already been sent to the complete owned group.  Do not
        # turn cancellation into an unbounded wait on a kernel I/O state.


class QwenProcessSupervisor:
    """Run one Qwen stage in an owned, time-bounded subprocess group."""

    def __init__(
        self,
        *,
        config: QwenSupervisorConfig | None = None,
        child_command: Sequence[str] | None = None,
    ) -> None:
        self.config = config or QwenSupervisorConfig()
        self.child_command = tuple(
            child_command
            or (sys.executable, "-m", "cts_backend.asr.qwen_child")
        )
        if not self.child_command or any(not isinstance(item, str) or not item for item in self.child_command):
            raise ValueError("child command must contain non-empty string arguments")

    @staticmethod
    def _emit(callback: Telemetry | None, event: Mapping[str, Any]) -> None:
        if callback is not None:
            # Every call site constructs an allow-listed event.  Round-tripping
            # here is a final guard against opaque or non-finite telemetry.
            callback(dict(_json_safe(event)))

    @staticmethod
    def _decode_line(line: bytes, *, attempt: int, channel: str) -> Mapping[str, Any]:
        try:
            raw = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise QwenProtocolError(
                f"Qwen child emitted invalid {channel} JSON", attempt=attempt
            ) from exc
        if not isinstance(raw, Mapping) or raw.get("protocol_version") != PROTOCOL_VERSION:
            raise QwenProtocolError("Qwen child event protocol mismatch", attempt=attempt)
        return raw

    @staticmethod
    def _batch_manifest_category(path: Path, request_id: str) -> str:
        return _read_failure_category(path, request_id)

    def run_chunks(
        self,
        *,
        model_path: Path,
        chunks: Sequence[AudioChunk | Mapping[str, Any] | Any],
        workspace: Path,
        context: str = "",
        language: str = "Cantonese",
        initial_previous_text: str = "",
        processed_duration: float = 0.0,
        total_duration: float | None = None,
        cancelled: Cancelled | None = None,
        telemetry: Telemetry | None = None,
        segment_completed: SegmentCompleted | None = None,
        resume: bool = True,
        attempt: int = 1,
    ) -> SupervisedQwenBatch:
        """Run all remaining chunks in one model-loading child process.

        Each segment crosses a transcript-bearing pipe which is never forwarded
        to telemetry.  The parent verifies and atomically checkpoints it before
        invoking ``segment_completed``.  Therefore a killed/retried child starts
        strictly after the last durable prefix.
        """
        if isinstance(attempt, bool) or not isinstance(attempt, int) or attempt < 1:
            raise ValueError("attempt must be a positive integer")
        items = [AudioChunk.coerce(item) for item in chunks]
        if len({item.id for item in items}) != len(items):
            raise ValueError("Qwen chunk ids must be unique within a stage")
        if not items:
            return SupervisedQwenBatch(
                segments=(),
                checkpoint_paths=(),
                request_id=None,
                resumed_count=0,
                attempts=attempt,
            )

        root = Path(workspace)
        root.mkdir(parents=True, exist_ok=True)
        model = Path(model_path)
        model_identity = _model_directory_identity(model)
        audio_identities = {item.id: _audio_identity(item.path) for item in items}
        previous_text = str(initial_previous_text)[-512:]
        current_processed = float(processed_duration)
        durable: list[TranscriptSegment] = []
        durable_paths: list[Path] = []
        resumed_count = 0

        # Resume only a contiguous, verified prefix.  Never skip a missing chunk
        # and consume a later checkpoint whose overlap context would differ.
        if resume:
            for item in items:
                item_request = _request_payload(
                    model_path=model,
                    chunk=item,
                    context=context,
                    language=language,
                    initial_previous_text=previous_text,
                    processed_duration=current_processed,
                    total_duration=total_duration,
                    model_identity=model_identity,
                    audio_identity=audio_identities[item.id],
                )
                item_path = root / f"qwen-{item_request['request_id']}.result.json"
                try:
                    segment = load_completed_checkpoint(
                        item_path,
                        expected_request_id=str(item_request["request_id"]),
                        expected_chunk=item,
                        expected_audio_sha256=str(
                            audio_identities[item.id]["sha256"]
                        ),
                        expected_model_digest=str(model_identity["digest"]),
                    )
                except ValueError as exc:
                    raise QwenProtocolError(
                        "Existing Qwen chunk checkpoint is invalid", attempt=attempt
                    ) from exc
                if segment is None:
                    break
                if cancelled is not None and cancelled():
                    raise QwenProcessCancelled("已取消 Qwen primary transcription")
                if segment_completed is not None:
                    segment_completed(segment)
                durable.append(segment)
                durable_paths.append(item_path)
                resumed_count += 1
                previous_text = (previous_text + segment.text)[-512:]
                current_processed += item.duration
                self._emit(
                    telemetry,
                    {
                        "event": "checkpoint_resumed",
                        "chunk_id": item.id,
                        "attempt": attempt,
                        "progress": current_processed / float(total_duration)
                        if total_duration
                        else len(durable) / len(items),
                    },
                )

        remaining = items[len(durable) :]
        if not remaining:
            return SupervisedQwenBatch(
                segments=tuple(durable),
                checkpoint_paths=tuple(durable_paths),
                request_id=None,
                resumed_count=resumed_count,
                attempts=attempt,
            )

        batch_request = _batch_request_payload(
            model_path=model,
            chunks=remaining,
            context=context,
            language=language,
            initial_previous_text=previous_text,
            processed_duration=current_processed,
            total_duration=total_duration,
            model_identity=model_identity,
            audio_identities=audio_identities,
        )
        batch_request_id = str(batch_request["request_id"])
        batch_stem = f"qwen-stage-{batch_request_id}"
        request_path = root / f"{batch_stem}.request.json"
        manifest_path = root / f"{batch_stem}.result.json"
        atomic_write_json(request_path, batch_request)

        event_read_fd, event_write_fd = os.pipe()
        segment_read_fd, segment_write_fd = os.pipe()
        os.set_inheritable(event_write_fd, True)
        os.set_inheritable(segment_write_fd, True)
        command = [
            *self.child_command,
            "--request",
            str(request_path),
            "--result",
            str(manifest_path),
            "--event-fd",
            str(event_write_fd),
            "--segment-fd",
            str(segment_write_fd),
            "--parent-pid",
            str(os.getpid()),
            "--attempt",
            str(attempt),
            "--heartbeat-seconds",
            str(self.config.child_heartbeat_seconds),
        ]

        process: subprocess.Popen[bytes] | None = None
        selector = selectors.DefaultSelector()
        buffers = {event_read_fd: bytearray(), segment_read_fd: bytearray()}
        channels = {event_read_fd: "event", segment_read_fd: "segment"}
        pipe_open = {event_read_fd: True, segment_read_fd: True}
        pipe_bytes = {event_read_fd: 0, segment_read_fd: 0}
        pipe_byte_limits = {
            event_read_fd: MAX_EVENT_PIPE_BYTES,
            segment_read_fd: MAX_SEGMENT_PIPE_BYTES,
        }
        started = time.monotonic()
        last_substantive = started
        last_fraction = -1.0
        model_loaded = False
        soft_warned = False
        drain_deadline: float | None = None
        chunk_started = started
        next_remaining_index = 0
        recent_completed_id: str | None = None
        completed_this_attempt: set[str] = set()
        remaining_ids = {item.id for item in remaining}

        def expected_chunk() -> AudioChunk | None:
            if next_remaining_index >= len(remaining):
                return None
            return remaining[next_remaining_index]

        def accept_segment(line: bytes) -> None:
            nonlocal previous_text, current_processed, next_remaining_index
            nonlocal recent_completed_id, last_substantive, last_fraction
            nonlocal model_loaded, soft_warned
            nonlocal chunk_started
            raw = self._decode_line(line, attempt=attempt, channel="segment")
            if raw.get("event") != "segment" or raw.get("request_id") != batch_request_id:
                raise QwenProtocolError("Qwen segment envelope is invalid", attempt=attempt)
            expected = expected_chunk()
            if expected is None:
                raise QwenProtocolError("Qwen child emitted an extra segment", attempt=attempt)
            try:
                ordinal = int(raw["ordinal"])
            except (KeyError, TypeError, ValueError) as exc:
                raise QwenProtocolError("Qwen segment ordinal is invalid", attempt=attempt) from exc
            if ordinal != next_remaining_index or raw.get("chunk_id") != expected.id:
                raise QwenProtocolError("Qwen child segment order mismatch", attempt=attempt)
            try:
                segment = _segment_from_payload(
                    raw.get("segment"), expected_chunk=expected
                )
            except (KeyError, TypeError, ValueError) as exc:
                raise QwenProtocolError("Qwen child segment payload is invalid", attempt=attempt) from exc

            item_request = _request_payload(
                model_path=model,
                chunk=expected,
                context=context,
                language=language,
                initial_previous_text=previous_text,
                processed_duration=current_processed,
                total_duration=total_duration,
                model_identity=model_identity,
                audio_identity=audio_identities[expected.id],
            )
            item_path = root / f"qwen-{item_request['request_id']}.result.json"
            atomic_write_json(
                item_path,
                completed_checkpoint(item_request, segment, attempt=attempt),
            )
            # The callback normally atomically appends the project's primary
            # journal.  Do not acknowledge durability until it returns.
            if segment_completed is not None:
                segment_completed(segment)
            durable.append(segment)
            durable_paths.append(item_path)
            previous_text = (previous_text + segment.text)[-512:]
            current_processed += expected.duration
            recent_completed_id = expected.id
            completed_this_attempt.add(expected.id)
            next_remaining_index += 1
            now = time.monotonic()
            chunk_started = now
            last_substantive = now
            last_fraction = -1.0
            model_loaded = True
            soft_warned = False
            self._emit(
                telemetry,
                {
                    "event": "segment_checkpointed",
                    "chunk_id": expected.id,
                    "attempt": attempt,
                    "elapsed_seconds": now - started,
                    "progress": current_processed / float(total_duration)
                    if total_duration
                    else len(durable) / len(items),
                },
            )

        def accept_event(line: bytes) -> None:
            nonlocal last_substantive, last_fraction, model_loaded, soft_warned
            raw = self._decode_line(line, attempt=attempt, channel="event")
            event_type = str(raw.get("event", ""))
            elapsed = max(0.0, time.monotonic() - started)
            expected = expected_chunk()
            expected_id = expected.id if expected is not None else recent_completed_id
            if event_type == "heartbeat":
                self._emit(
                    telemetry,
                    {
                        "event": "heartbeat",
                        "chunk_id": expected_id,
                        "attempt": attempt,
                        "elapsed_seconds": elapsed,
                    },
                )
                return
            if event_type == "ready":
                self._emit(
                    telemetry,
                    {
                        "event": "child_ready",
                        "chunk_id": expected_id,
                        "attempt": attempt,
                        "elapsed_seconds": elapsed,
                    },
                )
                return
            if event_type == "phase":
                phase = str(raw.get("phase", ""))
                raw_chunk_id = str(raw.get("chunk_id", ""))
                if phase not in {
                    "primary_model_loading",
                    "primary_model_ready",
                    "primary_decoding",
                }:
                    raise QwenProtocolError("Qwen child phase is invalid", attempt=attempt)
                if expected is None or raw_chunk_id != expected.id:
                    if raw_chunk_id not in completed_this_attempt and raw_chunk_id not in remaining_ids:
                        raise QwenProtocolError("Qwen child phase chunk mismatch", attempt=attempt)
                    # Segment and control pipes are ordered independently.  A
                    # phase for the just-finished or next chunk may arrive
                    # before its segment envelope; preserve it as telemetry
                    # without changing watchdog progress state.
                self._emit(
                    telemetry,
                    {
                        "event": "phase",
                        "phase": phase,
                        "chunk_id": raw_chunk_id,
                        "attempt": attempt,
                        "elapsed_seconds": elapsed,
                    },
                )
                return
            if event_type == "progress":
                raw_chunk_id = str(raw.get("chunk_id", ""))
                try:
                    fraction = float(raw["fraction"])
                except (KeyError, TypeError, ValueError) as exc:
                    raise QwenProtocolError("Qwen child progress is invalid", attempt=attempt) from exc
                if not math.isfinite(fraction) or not 0.0 <= fraction <= 1.0:
                    raise QwenProtocolError("Qwen child progress is out of range", attempt=attempt)
                if raw_chunk_id in completed_this_attempt and (
                    expected is None or raw_chunk_id != expected.id
                ):
                    # QwenASR emits one final progress record immediately after
                    # segment_completed; across two pipes it may arrive later.
                    self._emit(
                        telemetry,
                        {
                            "event": "progress",
                            "chunk_id": raw_chunk_id,
                            "attempt": attempt,
                            "elapsed_seconds": elapsed,
                            "progress": fraction,
                            "substantive": False,
                        },
                    )
                    return
                if raw_chunk_id in remaining_ids and (
                    expected is None or raw_chunk_id != expected.id
                ):
                    # Result/control pipes preserve order individually, not
                    # relative to each other.  A future chunk's control record
                    # may be readable before its earlier segment envelope.
                    self._emit(
                        telemetry,
                        {
                            "event": "progress",
                            "chunk_id": raw_chunk_id,
                            "attempt": attempt,
                            "elapsed_seconds": elapsed,
                            "progress": fraction,
                            "substantive": False,
                        },
                    )
                    return
                if expected is None or raw_chunk_id != expected.id:
                    raise QwenProtocolError("Qwen child progress chunk mismatch", attempt=attempt)
                substantive = fraction > last_fraction + 1e-9
                if substantive:
                    last_fraction = fraction
                    last_substantive = time.monotonic()
                    model_loaded = True
                    soft_warned = False
                self._emit(
                    telemetry,
                    {
                        "event": "progress",
                        "chunk_id": raw_chunk_id,
                        "attempt": attempt,
                        "elapsed_seconds": elapsed,
                        "progress": fraction,
                        "substantive": substantive,
                    },
                )
                return
            if event_type == "stage_complete":
                self._emit(
                    telemetry,
                    {
                        "event": "stage_complete",
                        "chunk_id": recent_completed_id,
                        "attempt": attempt,
                        "elapsed_seconds": elapsed,
                    },
                )
                return
            if event_type == "error":
                self._emit(
                    telemetry,
                    {
                        "event": "child_error",
                        "chunk_id": expected_id,
                        "attempt": attempt,
                        "elapsed_seconds": elapsed,
                        "category": str(raw.get("category", "child_crash")),
                    },
                )
                return
            raise QwenProtocolError("Qwen child emitted an unknown event", attempt=attempt)

        try:
            try:
                process = subprocess.Popen(
                    command,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                    pass_fds=(event_write_fd, segment_write_fd),
                    start_new_session=True,
                    shell=False,
                )
            except OSError as exc:
                raise QwenChildCrashError(
                    "Qwen child could not be launched",
                    returncode=None,
                    child_category="launch_error",
                    attempt=attempt,
                ) from exc
            os.close(event_write_fd)
            event_write_fd = -1
            os.close(segment_write_fd)
            segment_write_fd = -1
            for descriptor in (event_read_fd, segment_read_fd):
                os.set_blocking(descriptor, False)
                selector.register(descriptor, selectors.EVENT_READ, channels[descriptor])
            self._emit(
                telemetry,
                {
                    "event": "child_started",
                    "chunk_id": remaining[0].id,
                    "attempt": attempt,
                    "pid": process.pid,
                    "chunk_count": len(remaining),
                },
            )

            while True:
                now = time.monotonic()
                if cancelled is not None and cancelled():
                    terminate_process_group(
                        process, grace_seconds=self.config.termination_grace_seconds
                    )
                    self._emit(
                        telemetry,
                        {
                            "event": "cancelled",
                            "chunk_id": expected_chunk().id if expected_chunk() else recent_completed_id,
                            "attempt": attempt,
                            "elapsed_seconds": time.monotonic() - started,
                        },
                    )
                    raise QwenProcessCancelled("已取消 Qwen primary transcription")
                if now - started >= self.config.hard_wall_seconds:
                    terminate_process_group(
                        process, grace_seconds=self.config.termination_grace_seconds
                    )
                    raise QwenProcessTimeout(
                        "Qwen child exceeded hard wall deadline",
                        timeout_kind="wall",
                        attempt=attempt,
                    )
                if (
                    expected_chunk() is not None
                    and now - chunk_started
                    >= (
                        max(
                            self.config.per_chunk_wall_seconds,
                            self.config.model_load_timeout_seconds,
                        )
                        if next_remaining_index == 0 and not model_loaded
                        else self.config.per_chunk_wall_seconds
                    )
                ):
                    terminate_process_group(
                        process, grace_seconds=self.config.termination_grace_seconds
                    )
                    raise QwenProcessTimeout(
                        "Qwen child exceeded per-chunk wall deadline",
                        timeout_kind="chunk_wall",
                        attempt=attempt,
                    )
                inactive = now - (started if not model_loaded else last_substantive)
                if not model_loaded and inactive >= self.config.model_load_timeout_seconds:
                    terminate_process_group(
                        process, grace_seconds=self.config.termination_grace_seconds
                    )
                    raise QwenProcessTimeout(
                        "Qwen child did not load the model before deadline",
                        timeout_kind="model_load",
                        attempt=attempt,
                    )
                if model_loaded and inactive >= self.config.hard_no_progress_seconds:
                    terminate_process_group(
                        process, grace_seconds=self.config.termination_grace_seconds
                    )
                    raise QwenProcessTimeout(
                        "Qwen child made no substantive progress before deadline",
                        timeout_kind="no_substantive_progress",
                        attempt=attempt,
                    )
                if inactive >= self.config.soft_no_progress_seconds and not soft_warned:
                    soft_warned = True
                    self._emit(
                        telemetry,
                        {
                            "event": "soft_timeout_warning",
                            "chunk_id": expected_chunk().id if expected_chunk() else recent_completed_id,
                            "attempt": attempt,
                            "inactive_seconds": inactive,
                            "phase": "model_load" if not model_loaded else "chunk",
                        },
                    )

                ready_descriptors = selector.select(timeout=self.config.poll_seconds)
                ready_descriptors.sort(key=lambda item: 0 if item[0].data == "segment" else 1)
                for key, _mask in ready_descriptors:
                    descriptor = int(key.fd)
                    try:
                        block = os.read(descriptor, 65_536)
                    except BlockingIOError:
                        continue
                    if not block:
                        selector.unregister(descriptor)
                        pipe_open[descriptor] = False
                        continue
                    pipe_bytes[descriptor] += len(block)
                    if pipe_bytes[descriptor] > pipe_byte_limits[descriptor]:
                        raise QwenProtocolError(
                            f"Qwen child {channels[descriptor]} pipe exceeded byte cap",
                            attempt=attempt,
                        )
                    buffer = buffers[descriptor]
                    buffer.extend(block)
                    limit = (
                        MAX_EVENT_LINE_BYTES
                        if channels[descriptor] == "event"
                        else MAX_SEGMENT_LINE_BYTES
                    )
                    if len(buffer) > limit and b"\n" not in buffer:
                        raise QwenProtocolError(
                            f"Qwen child {channels[descriptor]} exceeded size limit",
                            attempt=attempt,
                        )
                    while b"\n" in buffer:
                        line, _, remainder = buffer.partition(b"\n")
                        buffer[:] = remainder
                        if not line:
                            continue
                        if len(line) > limit:
                            raise QwenProtocolError(
                                f"Qwen child {channels[descriptor]} exceeded size limit",
                                attempt=attempt,
                            )
                        if channels[descriptor] == "event":
                            accept_event(bytes(line))
                        else:
                            accept_segment(bytes(line))

                returncode = process.poll()
                if returncode is not None:
                    if drain_deadline is None:
                        drain_deadline = (
                            time.monotonic() + self.config.pipe_drain_timeout_seconds
                        )
                    if not any(pipe_open.values()):
                        break
                    if time.monotonic() >= drain_deadline:
                        raise QwenProtocolError(
                            "Qwen child pipes did not reach EOF before drain deadline",
                            returncode=returncode,
                            attempt=attempt,
                        )

            for descriptor, buffer in buffers.items():
                if not buffer.strip():
                    continue
                if channels[descriptor] == "event":
                    accept_event(bytes(buffer))
                else:
                    accept_segment(bytes(buffer))
            returncode = process.wait()
            if returncode != 0:
                raise QwenChildCrashError(
                    "Qwen child exited unsuccessfully",
                    returncode=returncode,
                    child_category=self._batch_manifest_category(
                        manifest_path, batch_request_id
                    ),
                    attempt=attempt,
                )
            if next_remaining_index != len(remaining):
                raise QwenProtocolError(
                    "Qwen child exited before all segment checkpoints arrived",
                    returncode=returncode,
                    attempt=attempt,
                )
            try:
                with manifest_path.open("r", encoding="utf-8") as handle:
                    manifest = json.load(handle)
            except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise QwenProtocolError(
                    "Qwen child did not write a valid stage manifest",
                    returncode=returncode,
                    attempt=attempt,
                ) from exc
            expected_ids = [item.id for item in remaining]
            if (
                not isinstance(manifest, Mapping)
                or manifest.get("protocol_version") != PROTOCOL_VERSION
                or manifest.get("request_id") != batch_request_id
                or manifest.get("status") != "completed"
                or manifest.get("completed_chunk_ids") != expected_ids
            ):
                raise QwenProtocolError(
                    "Qwen child stage manifest does not match the request",
                    returncode=returncode,
                    attempt=attempt,
                )
            return SupervisedQwenBatch(
                segments=tuple(durable),
                checkpoint_paths=tuple(durable_paths),
                request_id=batch_request_id,
                resumed_count=resumed_count,
                attempts=attempt,
            )
        finally:
            selector.close()
            for descriptor in (event_write_fd, segment_write_fd, event_read_fd, segment_read_fd):
                if descriptor < 0:
                    continue
                try:
                    os.close(descriptor)
                except OSError:
                    pass
            if process is not None:
                terminate_process_group(
                    process, grace_seconds=self.config.termination_grace_seconds
                )

    def run_chunk(
        self,
        *,
        model_path: Path,
        chunk: AudioChunk | Mapping[str, Any] | Any,
        workspace: Path,
        context: str = "",
        language: str = "Cantonese",
        initial_previous_text: str = "",
        processed_duration: float = 0.0,
        total_duration: float | None = None,
        cancelled: Cancelled | None = None,
        telemetry: Telemetry | None = None,
        resume: bool = True,
        attempt: int = 1,
    ) -> SupervisedQwenChunk:
        """Single-chunk canary wrapper; production should call ``run_chunks``."""
        item = AudioChunk.coerce(chunk)
        batch = self.run_chunks(
            model_path=model_path,
            chunks=[item],
            workspace=workspace,
            context=context,
            language=language,
            initial_previous_text=initial_previous_text,
            processed_duration=processed_duration,
            total_duration=total_duration,
            cancelled=cancelled,
            telemetry=telemetry,
            resume=resume,
            attempt=attempt,
        )
        checkpoint_path = batch.checkpoint_paths[0]
        request_id = checkpoint_path.name.removeprefix("qwen-").removesuffix(
            ".result.json"
        )
        return SupervisedQwenChunk(
            segment=batch.segments[0],
            request_id=request_id,
            checkpoint_path=checkpoint_path,
            resumed=batch.resumed_count == 1,
            attempt=attempt,
        )

    def run_chunks_with_retries(
        self,
        *,
        max_retries: int,
        telemetry: Telemetry | None = None,
        segment_completed: SegmentCompleted | None = None,
        **kwargs: Any,
    ) -> SupervisedQwenBatch:
        """Retry a stage from its last durable chunk, never reloading per chunk."""
        if isinstance(max_retries, bool) or not isinstance(max_retries, int):
            raise ValueError("max_retries must be an integer from zero through two")
        if not 0 <= max_retries <= MAX_CALLER_RETRIES:
            raise ValueError("max_retries must be from zero through two")
        if "attempt" in kwargs:
            raise TypeError("attempt is owned by run_chunks_with_retries")
        if "resume" in kwargs:
            if kwargs.pop("resume") is not True:
                raise ValueError("retries require durable-prefix resume")
        notified: set[str] = set()

        def notify_once(segment: TranscriptSegment) -> None:
            if segment.id in notified:
                return
            if segment_completed is not None:
                segment_completed(segment)
            notified.add(segment.id)

        last_error: QwenProcessError | None = None
        for attempt in range(1, max_retries + 2):
            try:
                result = self.run_chunks(
                    telemetry=telemetry,
                    segment_completed=notify_once,
                    attempt=attempt,
                    resume=True,
                    **kwargs,
                )
                return SupervisedQwenBatch(
                    segments=result.segments,
                    checkpoint_paths=result.checkpoint_paths,
                    request_id=result.request_id,
                    resumed_count=result.resumed_count,
                    attempts=attempt,
                )
            except QwenProcessCancelled:
                raise
            except (QwenProcessTimeout, QwenChildCrashError) as exc:
                last_error = exc
                if attempt > max_retries:
                    raise
                self._emit(
                    telemetry,
                    {
                        "event": "retry_scheduled",
                        "attempt": attempt,
                        "next_attempt": attempt + 1,
                        "category": exc.category,
                    },
                )
        assert last_error is not None
        raise last_error

    def run_chunk_with_retries(
        self,
        *,
        max_retries: int,
        telemetry: Telemetry | None = None,
        **kwargs: Any,
    ) -> SupervisedQwenChunk:
        """Single-chunk retry wrapper retained for diagnostics/canaries."""
        if "chunk" not in kwargs:
            raise TypeError("run_chunk_with_retries requires chunk")
        item = AudioChunk.coerce(kwargs.pop("chunk"))
        result = self.run_chunks_with_retries(
            max_retries=max_retries,
            chunks=[item],
            telemetry=telemetry,
            **kwargs,
        )
        checkpoint_path = result.checkpoint_paths[0]
        request_id = checkpoint_path.name.removeprefix("qwen-").removesuffix(
            ".result.json"
        )
        return SupervisedQwenChunk(
            segment=result.segments[0],
            request_id=request_id,
            checkpoint_path=checkpoint_path,
            resumed=result.resumed_count == 1,
            attempt=result.attempts,
        )


__all__ = [
    "MAX_CALLER_RETRIES",
    "PROTOCOL_VERSION",
    "QwenChildCrashError",
    "QwenProcessCancelled",
    "QwenProcessError",
    "QwenProcessSupervisor",
    "QwenProcessTimeout",
    "QwenProtocolError",
    "QwenSupervisorConfig",
    "SupervisedQwenBatch",
    "SupervisedQwenChunk",
    "atomic_write_json",
    "completed_batch_manifest",
    "completed_checkpoint",
    "failed_batch_manifest",
    "failed_checkpoint",
    "load_completed_checkpoint",
    "load_request",
    "segment_protocol_payload",
    "terminate_process_group",
    "validate_request_payload",
    "verify_request_inputs",
]
