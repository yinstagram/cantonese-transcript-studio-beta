"""Default-off whole-display experiment; coarse VAD is not acoustic gold."""

from collections.abc import Mapping, Sequence
from copy import deepcopy
import math
from typing import Any
import unicodedata


_DELIMITERS = frozenset("，,。！？!?；;：:\n\r")


def _spoken(char: str) -> bool:
    return not (char.isspace() or unicodedata.category(char).startswith("P"))


def _units(text: str) -> list[tuple[int, int]]:
    """Keep delimiter runs and following whitespace with the preceding unit.

    Leading non-spoken characters belong to the first unit. A period alone is
    not a delimiter. This ownership convention never deletes source characters.
    """
    result = []
    start = index = 0
    has_spoken = False
    while index < len(text):
        has_spoken = has_spoken or _spoken(text[index])
        if text[index] in _DELIMITERS and has_spoken:
            end = index + 1
            while end < len(text) and not _spoken(text[end]):
                end += 1
            result.append((start, end))
            start = index = end
            has_spoken = False
        else:
            index += 1
    if start < len(text):
        result.append((start, len(text)))
    return result


def bound_experimental_utterance_islands(
    *,
    fine_cues: Sequence[Mapping[str, Any]],
    character_timestamps: Sequence[Mapping[str, Any]],
    text: str,
    speech_islands: Sequence[Mapping[str, Any]],
    duration_ms: int,
    enabled: bool = False,
    external_raw_token_witness: Mapping[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Apply only the frozen punctuation-unit candidate, never word clocks.

    Caller owns exact PCM/VAD/envelope lineage verification. All decisions use
    original source and display geometry. Fixed proposals are applied in safe
    batches to a fixed point; only overlap safety sees previously applied output.
    No model inference or reference input exists.
    """
    output = deepcopy(list(fine_cues))
    audit: dict[str, Any] = {
        "policy": "experimental-punctuation-unit-isolated-island-v1",
        "enabled": enabled, "applied": False, "changed_cue_count": 0,
        "reference_timing_used": False, "acoustic_gold_claimed": False,
        "accepted_posterior_context_claimed": False, "release_verdict": None,
        "input_lineage": "caller_must_verify_pcm_vad_envelope_and_code_hashes",
        "input_display_trim": "already_applied_no_additional_trim",
        "unknown_character_clocks_assigned": False,
        "partition_ownership": "trailing_punctuation_and_whitespace_belong_to_previous_unit",
        "limits": {"target_spoken_min": 1, "target_spoken_max": 12,
                   "neighbor_min_native_anchors": 3, "neighbor_min_native_coverage": 0.75,
                   "maximum_native_displacement_ms": 300, "island_anchor_tolerance_ms": 150,
                   "minimum_strictly_inside_neighbor_anchors": 2,
                   "minimum_silence_ms": 250, "minimum_display_duration_ms": 200,
                   "maximum_edge_movement_ms": 1000},
        "cues": [], "units": [], "application_batches": [],
    }

    def invalid(reason: str):
        audit["abstention_reason"] = reason
        return output, audit

    def number(value: Any) -> bool:
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)

    def integer(value: Any) -> bool:
        return isinstance(value, int) and not isinstance(value, bool)

    if enabled is not True:
        return invalid("disabled" if enabled is False else "invalid_enabled_flag")
    if not isinstance(text, str) or not text or not integer(duration_ms) or duration_ms <= 0:
        return invalid("invalid_transcript_or_duration")
    if not speech_islands:
        return invalid("no_speech_islands")
    previous_end = 0
    for island in speech_islands:
        if (not isinstance(island, Mapping)
                or any(not integer(island.get(k)) for k in ("start_ms", "end_ms"))
                or not previous_end <= island["start_ms"] < island["end_ms"] <= duration_ms):
            return invalid("invalid_or_overlapping_speech_islands")
        previous_end = island["end_ms"]

    characters: dict[int, Mapping[str, Any]] = {}
    native: dict[int, float] = {}
    for row in character_timestamps:
        if not isinstance(row, Mapping) or not integer(row.get("source_index")):
            return invalid("invalid_character_source")
        source = row["source_index"]
        if (source in characters or not 0 <= source < len(text) or row.get("text") != text[source]
                or not number(row.get("start_ms")) or not number(row.get("end_ms"))
                or not 0 <= row["start_ms"] < row["end_ms"] <= duration_ms):
            return invalid("invalid_or_ambiguous_character_coverage")
        characters[source] = row
        if external_raw_token_witness is not None:
            # Legacy clock metadata is not native evidence in external mode.
            # The immutable character array is still source/range validated.
            continue
        clock = row.get("native_token_start_ms")
        displacement = row.get("moved_from_native_token_start_ms")
        # Missing evidence is unknown, but contradictory/nonsensical evidence
        # cannot be silently converted into an unknown to help eligibility.
        if clock is not None and (not number(clock) or not 0 <= clock < duration_ms):
            return invalid("invalid_native_clock")
        if displacement is not None and not number(displacement):
            return invalid("invalid_native_displacement")
        if clock is not None and displacement is not None:
            actual = row["start_ms"] - clock
            if abs(actual - displacement) > 1e-6:
                return invalid("inconsistent_native_displacement")
            if (row.get("timing_source") == "wenet_ctc_anchor"
                    and row.get("start_clock_evidence") == "direct_native_token_timestamp"
                    and abs(actual) <= 300):
                native[source] = clock
    if len(characters) != len(text):
        return invalid("incomplete_character_coverage")

    if external_raw_token_witness is not None:
        from .external_raw_wenet_witness import validated_external_raw_starts

        try:
            raw_starts = validated_external_raw_starts(external_raw_token_witness,
                text=text, character_timestamps=character_timestamps, duration_ms=duration_ms)
        except (ValueError, TypeError, KeyError, OverflowError) as error:
            audit["external_witness_error"] = str(error)
            return invalid("invalid_external_raw_token_witness")
        audit["anchor_evidence_source"] = "external_raw_wenet_only"
        audit["external_witness_report_sha256"] = external_raw_token_witness["report_sha256"]
        audit["external_anchor_evidence"] = []
        for source, clock in raw_starts.items():
            disagreement = characters[source]["start_ms"] - clock
            accepted = abs(disagreement) <= 300
            audit["external_anchor_evidence"].append({"source_index": source,
                "raw_token_start_ms": clock,
                "baseline_to_raw_start_disagreement_ms": disagreement,
                "accepted_for_display_anchor": accepted})
            if accepted:
                native[source] = clock

    expected = 0
    previous_start = -1
    for cue in output:
        if (not isinstance(cue, dict)
                or any(not integer(cue.get(k)) for k in ("source_start", "source_end", "start_ms", "end_ms"))
                or cue["source_start"] != expected
                or not expected < cue["source_end"] <= len(text)
                or cue.get("text") != text[expected:cue["source_end"]]
                or not 0 <= cue["start_ms"] < cue["end_ms"] <= duration_ms
                or cue["start_ms"] < previous_start):
            return invalid("invalid_or_incomplete_display_coverage")
        for sec, ms in (("start", "start_ms"), ("end", "end_ms")):
            if sec in cue and (not number(cue[sec]) or abs(cue[sec] * 1000 - cue[ms]) > 1e-6):
                return invalid("inconsistent_display_seconds_alias")
        expected, previous_start = cue["source_end"], cue["start_ms"]
    if expected != len(text):
        return invalid("invalid_or_incomplete_display_coverage")

    units = _units(text)
    unit_lookup = {span: i for i, span in enumerate(units)}
    for start, end in units:
        spoken = [i for i in range(start, end) if _spoken(text[i])]
        anchored = [i for i in spoken if i in native]
        clocks = [native[i] for i in anchored]
        matches = [i for i, island in enumerate(speech_islands)
                   if sum(island["start_ms"] < t < island["end_ms"] for t in clocks) >= 2
                   and all(island["start_ms"] - 150 <= t <= island["end_ms"] + 150 for t in clocks)]
        audit["units"].append({"source_start": start, "source_end": end,
            "text": text[start:end], "spoken_source_indices": spoken,
            "native_source_indices": anchored, "native_start_ms": clocks,
            "native_coverage": len(anchored) / len(spoken) if spoken else 0,
            "increasing_native_clocks": all(a < b for a, b in zip(clocks, clocks[1:])),
            "candidate_speech_islands": matches})

    def neighbor_reason(unit: Mapping[str, Any]) -> str | None:
        if len(unit["native_source_indices"]) < 3:
            return "neighbor_fewer_than_three_native_anchors"
        if unit["native_coverage"] < 0.75:
            return "neighbor_native_coverage_below_75_percent"
        if not unit["increasing_native_clocks"]:
            return "neighbor_non_increasing_native_clocks"
        if len(unit["candidate_speech_islands"]) != 1:
            return "neighbor_island_assignment_missing_or_ambiguous"
        return None

    proposals: dict[int, tuple[int, int]] = {}
    for index, cue in enumerate(output):
        row: dict[str, Any] = {"cue_position": index, "text": cue["text"],
            "source_start": cue["source_start"], "source_end": cue["source_end"],
            "original_display_start_ms": cue["start_ms"], "original_display_end_ms": cue["end_ms"],
            "after_display_start_ms": cue["start_ms"], "after_display_end_ms": cue["end_ms"],
            "changed": False}
        audit["cues"].append(row)
        unit_index = unit_lookup.get((cue["source_start"], cue["source_end"]))
        if unit_index is None:
            row["abstention_reason"] = "cue_not_exactly_one_complete_punctuation_unit"
            continue
        row["unit_index"] = unit_index
        unit = audit["units"][unit_index]
        if not 1 <= len(unit["spoken_source_indices"]) <= 12:
            row["abstention_reason"] = "target_spoken_count_outside_1_to_12"
            continue
        if cue.get("speaker_overlap") or cue.get("overlap") or cue.get("overlap_speaker"):
            row["abstention_reason"] = "target_speaker_overlap"
            continue
        if unit_index == 0 or unit_index + 1 == len(units):
            row["abstention_reason"] = "missing_immediate_neighbor_unit"
            continue
        left, right = audit["units"][unit_index - 1], audit["units"][unit_index + 1]
        reason = neighbor_reason(left) or neighbor_reason(right)
        if reason:
            row["abstention_reason"] = reason
            continue
        left_index, right_index = left["candidate_speech_islands"][0], right["candidate_speech_islands"][0]
        row.update(left_speech_island_index=left_index, right_speech_island_index=right_index)
        if right_index != left_index + 2:
            row["abstention_reason"] = "not_exactly_one_intermediate_island"
            continue
        target_index = left_index + 1
        target = speech_islands[target_index]
        start, end = target["start_ms"], target["end_ms"]
        row.update(target_speech_island_index=target_index, proposed_display_start_ms=start,
                   proposed_display_end_ms=end,
                   unknown_spoken_source_indices=[i for i in unit["spoken_source_indices"] if i not in native])
        if (start - speech_islands[left_index]["end_ms"] < 250
                or speech_islands[right_index]["start_ms"] - end < 250):
            reason = "silence_below_250ms"
        elif not unit["native_start_ms"]:
            reason = "target_has_no_valid_native_anchor"
        elif not all(start < t < end for t in unit["native_start_ms"]):
            reason = "target_native_anchor_outside_intermediate_island"
        elif not unit["increasing_native_clocks"]:
            reason = "target_non_increasing_native_clocks"
        elif end - start < 200:
            reason = "display_duration_below_200ms"
        elif max(abs(start - cue["start_ms"]), abs(end - cue["end_ms"])) > 1000:
            reason = "edge_movement_over_1000ms"
        elif (start, end) == (cue["start_ms"], cue["end_ms"]):
            reason = "already_at_island_edges"
        else:
            reason = None
        if reason:
            row["abstention_reason"] = reason
        else:
            proposals[index] = (start, end)

    # Geometry, original movement limits, and source evidence never change in
    # this bounded loop. A shrinking neighbor may free an originally blocked
    # fixed proposal. Simultaneous batch selection avoids source-order effects.
    pending = dict(proposals)
    for _ in range(len(proposals)):
        safe = {index: edges for index, edges in pending.items()
                if not ((index > 0 and output[index - 1]["end_ms"] > edges[0])
                        or (index + 1 < len(output) and edges[1] > output[index + 1]["start_ms"]))}
        conflicted = set()
        for index, (start, end) in safe.items():
            if index + 1 in safe and end > safe[index + 1][0]:
                conflicted.update((index, index + 1))
        for index in conflicted:
            audit["cues"][index]["abstention_reason"] = "simultaneous_candidate_overlap"
        safe = {index: edges for index, edges in safe.items() if index not in conflicted}
        if not safe:
            break
        batch = sorted(safe)
        audit["application_batches"].append(batch)
        for index in batch:
            start, end = pending.pop(index)
            cue = output[index]
            cue.update(start_ms=start, end_ms=end, low_confidence=True, timing_review_required=True)
            if "start" in cue:
                cue["start"] = start / 1000
            if "end" in cue:
                cue["end"] = end / 1000
            audit["cues"][index].update(changed=True, after_display_start_ms=start,
                after_display_end_ms=end, application_batch=len(audit["application_batches"]) - 1)
            audit["changed_cue_count"] += 1
    for index in pending:
        audit["cues"][index].setdefault("abstention_reason", "proposed_display_overlaps_immediate_neighbor")
    audit["final_display_overlap_count"] = sum(left["end_ms"] > right["start_ms"]
                                              for left, right in zip(output, output[1:]))
    audit["applied"] = audit["changed_cue_count"] > 0
    return output, audit
