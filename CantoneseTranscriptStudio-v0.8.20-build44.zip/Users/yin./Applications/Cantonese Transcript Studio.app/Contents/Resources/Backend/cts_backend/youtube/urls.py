"""Strict URL parsing for user-initiated media downloads.

The original YouTube contract remains intact.  Public social URLs use a
separate explicit allow-list and receive a stable internal id derived from
their canonical URL; extractor ids are never trusted as filesystem names.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from enum import Enum
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


ALLOWED_YOUTUBE_HOSTS = frozenset(
    {
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "music.youtube.com",
        "youtu.be",
    }
)
ALLOWED_SOCIAL_HOSTS = frozenset(
    {
        "instagram.com",
        "www.instagram.com",
        "m.instagram.com",
        "threads.net",
        "www.threads.net",
        "threads.com",
        "www.threads.com",
        "x.com",
        "www.x.com",
        "mobile.x.com",
        "twitter.com",
        "www.twitter.com",
        "mobile.twitter.com",
        "tiktok.com",
        "www.tiktok.com",
        "vm.tiktok.com",
        "facebook.com",
        "www.facebook.com",
        "fb.watch",
        "reddit.com",
        "www.reddit.com",
        "v.redd.it",
        "bilibili.com",
        "www.bilibili.com",
        "m.bilibili.com",
        "b23.tv",
    }
)
VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
PLAYLIST_ID_RE = re.compile(r"^[A-Za-z0-9_-]{10,128}$")
_CONTROL_OR_SPACE_RE = re.compile(r"[\x00-\x20\x7f]")
_CHANNEL_PREFIXES = ("/channel/", "/c/", "/user/", "/@", "/feed/")


class YouTubeURLValidationError(ValueError):
    """Raised when input is not one exact, public HTTPS YouTube target."""


class SocialURLValidationError(ValueError):
    """Raised when input is not a public URL on an explicitly supported site."""


class SocialPlatform(str, Enum):
    INSTAGRAM = "instagram"
    THREADS = "threads"
    X = "x"
    TIKTOK = "tiktok"
    FACEBOOK = "facebook"
    REDDIT = "reddit"
    BILIBILI = "bilibili"


@dataclass(frozen=True)
class SocialURL:
    canonical_url: str
    platform: SocialPlatform
    resource_id: str

    @property
    def kind(self) -> str:
        return "video"

    def __str__(self) -> str:
        return self.canonical_url


class YouTubeResourceKind(str, Enum):
    VIDEO = "video"
    PLAYLIST = "playlist"


@dataclass(frozen=True)
class YouTubeURL:
    canonical_url: str
    kind: YouTubeResourceKind
    video_id: str | None = None
    playlist_id: str | None = None

    def __str__(self) -> str:
        return self.canonical_url


def _query_values(query: str) -> dict[str, list[str]]:
    try:
        pairs = parse_qsl(
            query,
            keep_blank_values=True,
            strict_parsing=False,
            max_num_fields=50,
        )
    except ValueError as exc:
        raise YouTubeURLValidationError("YouTube URL query 無效") from exc
    values: dict[str, list[str]] = {}
    for key, value in pairs:
        values.setdefault(key, []).append(value)
    return values


def _one_query_value(values: dict[str, list[str]], name: str) -> str | None:
    matches = values.get(name, [])
    if not matches:
        return None
    if len(matches) != 1 or not matches[0]:
        raise YouTubeURLValidationError(f"YouTube URL 嘅 {name} 參數無效")
    return matches[0]


def _video(value: str | None) -> str:
    if value is None or VIDEO_ID_RE.fullmatch(value) is None:
        raise YouTubeURLValidationError("YouTube video ID 無效")
    return value


def _playlist(value: str | None) -> str:
    if value is None or PLAYLIST_ID_RE.fullmatch(value) is None:
        raise YouTubeURLValidationError("YouTube playlist ID 無效")
    return value


def validate_youtube_url(value: str) -> YouTubeURL:
    """Validate and reduce a YouTube URL to a tracking-free canonical target.

    URL-like search strings, credentials, non-HTTPS schemes, channel-wide
    pages, look-alike hostnames, fragments, and all unrelated query fields are
    rejected or stripped before an argv is ever built.
    """

    if not isinstance(value, str):
        raise YouTubeURLValidationError("YouTube URL 必須係文字")
    if not value or len(value) > 2_048:
        raise YouTubeURLValidationError("YouTube URL 長度無效")
    if value.startswith("-") or _CONTROL_OR_SPACE_RE.search(value):
        raise YouTubeURLValidationError("YouTube URL 含有非法字元")

    try:
        split = urlsplit(value)
        port = split.port
    except ValueError as exc:
        raise YouTubeURLValidationError("YouTube URL 無效") from exc

    if split.scheme != "https":
        raise YouTubeURLValidationError("只接受 HTTPS YouTube URL")
    if split.username is not None or split.password is not None:
        raise YouTubeURLValidationError("YouTube URL 唔可以包含 credentials")
    host = (split.hostname or "").lower()
    if host not in ALLOWED_YOUTUBE_HOSTS:
        raise YouTubeURLValidationError("只接受 exact YouTube hostname")
    if port not in (None, 443):
        raise YouTubeURLValidationError("YouTube URL port 無效")

    path = split.path.rstrip("/") or "/"
    lower_path = path.lower()
    if lower_path.startswith(_CHANNEL_PREFIXES):
        raise YouTubeURLValidationError("唔支援 channel-wide 下載")
    values = _query_values(split.query)

    if host == "youtu.be":
        parts = [part for part in path.split("/") if part]
        if len(parts) != 1:
            raise YouTubeURLValidationError("youtu.be URL 無效")
        video_id = _video(parts[0])
        canonical = urlunsplit(
            ("https", "www.youtube.com", "/watch", urlencode({"v": video_id}), "")
        )
        return YouTubeURL(canonical, YouTubeResourceKind.VIDEO, video_id=video_id)

    if path == "/watch":
        video_id = _video(_one_query_value(values, "v"))
        playlist_id = _one_query_value(values, "list")
        if playlist_id is not None:
            playlist_id = _playlist(playlist_id)
        query: list[tuple[str, str]] = [("v", video_id)]
        if playlist_id is not None:
            query.append(("list", playlist_id))
        canonical = urlunsplit(("https", "www.youtube.com", "/watch", urlencode(query), ""))
        return YouTubeURL(
            canonical,
            YouTubeResourceKind.VIDEO,
            video_id=video_id,
            playlist_id=playlist_id,
        )

    if path == "/playlist":
        playlist_id = _playlist(_one_query_value(values, "list"))
        canonical = urlunsplit(
            ("https", "www.youtube.com", "/playlist", urlencode({"list": playlist_id}), "")
        )
        return YouTubeURL(
            canonical,
            YouTubeResourceKind.PLAYLIST,
            playlist_id=playlist_id,
        )

    for prefix in ("/shorts/", "/live/", "/embed/"):
        if path.startswith(prefix):
            suffix = path.removeprefix(prefix)
            if "/" in suffix:
                raise YouTubeURLValidationError("YouTube video URL path 無效")
            video_id = _video(suffix)
            canonical = urlunsplit(
                ("https", "www.youtube.com", "/watch", urlencode({"v": video_id}), "")
            )
            return YouTubeURL(canonical, YouTubeResourceKind.VIDEO, video_id=video_id)

    raise YouTubeURLValidationError("唔支援呢類 YouTube URL")


def _social_platform(host: str) -> SocialPlatform:
    if "instagram" in host:
        return SocialPlatform.INSTAGRAM
    if "threads" in host:
        return SocialPlatform.THREADS
    if host in {"x.com", "www.x.com", "mobile.x.com", "twitter.com", "www.twitter.com", "mobile.twitter.com"}:
        return SocialPlatform.X
    if "tiktok" in host:
        return SocialPlatform.TIKTOK
    if host in {"fb.watch", "facebook.com", "www.facebook.com"}:
        return SocialPlatform.FACEBOOK
    if host in {"b23.tv", "bilibili.com", "www.bilibili.com", "m.bilibili.com"}:
        return SocialPlatform.BILIBILI
    return SocialPlatform.REDDIT


def validate_social_url(value: str) -> SocialURL:
    """Validate one public social post URL without accepting credentials.

    Query strings and fragments are removed from the canonical form.  This
    prevents tracking and signed parameters from being persisted in job data;
    the platform extractor receives the clean public URL only.
    """

    if not isinstance(value, str):
        raise SocialURLValidationError("社交平台 URL 必須係文字")
    if not value or len(value) > 2_048:
        raise SocialURLValidationError("社交平台 URL 長度無效")
    if value.startswith("-") or _CONTROL_OR_SPACE_RE.search(value):
        raise SocialURLValidationError("社交平台 URL 含有非法字元")
    try:
        split = urlsplit(value)
        port = split.port
    except ValueError as exc:
        raise SocialURLValidationError("社交平台 URL 無效") from exc
    if split.scheme != "https":
        raise SocialURLValidationError("只接受 HTTPS 社交平台 URL")
    if split.username is not None or split.password is not None:
        raise SocialURLValidationError("URL 唔可以包含 credentials")
    host = (split.hostname or "").lower()
    if host not in ALLOWED_SOCIAL_HOSTS:
        raise SocialURLValidationError("唔支援呢個社交平台 hostname")
    if port not in (None, 443):
        raise SocialURLValidationError("URL port 無效")
    path = split.path.rstrip("/")
    if not path or path == "/":
        raise SocialURLValidationError("請貼上單一公開貼文或影片連結")
    lowered = path.lower()
    if any(token in lowered for token in ("/login", "/accounts/login", "/signup", "/settings")):
        raise SocialURLValidationError("唔接受登入、設定或帳戶頁面")
    # Facebook's public watch/video pages carry the actual media id in `v`;
    # retain only that content-bearing parameter and discard tracking fields.
    canonical_query = ""
    platform = _social_platform(host)
    if platform is SocialPlatform.FACEBOOK and path.lower() in {"/watch", "/video.php"}:
        values = _query_values(split.query)
        video_value = values.get("v", [])
        if len(video_value) == 1 and video_value[0] and re.fullmatch(r"[A-Za-z0-9_-]{1,128}", video_value[0]):
            canonical_query = urlencode({"v": video_value[0]})
    elif platform is SocialPlatform.BILIBILI:
        values = _query_values(split.query)
        if path.lower().startswith("/festival/"):
            bvid = values.get("bvid", [])
            if len(bvid) == 1 and re.fullmatch(r"[AaBb][Vv][A-Za-z0-9_-]+", bvid[0] or ""):
                canonical_query = urlencode({"bvid": bvid[0]})
        else:
            part = values.get("p", [])
            if len(part) == 1 and re.fullmatch(r"[1-9][0-9]{0,5}", part[0] or ""):
                canonical_query = urlencode({"p": part[0]})
    canonical = urlunsplit(("https", host, path, canonical_query, ""))
    resource_id = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:11]
    return SocialURL(canonical, _social_platform(host), resource_id)


def validate_remote_url(value: str) -> YouTubeURL | SocialURL:
    """Validate a supported remote media URL and preserve platform identity."""
    # Keep YouTube's specific diagnostics (for example channel-wide URLs)
    # instead of hiding them behind the generic social-host error.
    try:
        host = (urlsplit(value).hostname or "").lower() if isinstance(value, str) else ""
    except ValueError:
        host = ""
    if host in ALLOWED_YOUTUBE_HOSTS:
        return validate_youtube_url(value)
    return validate_social_url(value)
