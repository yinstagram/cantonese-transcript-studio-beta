"""Fail-closed, read-only sidecar for post-session interview timing review.

This module deliberately does *not* run an aligner, touch a subtitle project,
or store microphone audio.  It only serializes immutable live-session evidence
into a strict review manifest.  Any missing link between the captured audio,
caption spans and capture chunks is represented as ``unassessable`` instead of
being guessed as an edit timestamp.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .assistant import FinalizedCaption
from .interview import OperationalInterviewMarker


POST_SESSION_INTERVIEW_TIMING_SCHEMA = "cts.post_session_interview_timing/v1"
CLOCK_RELATION = "exact_only_when_dropped_samples==0"
_MANIFEST_KEYS = frozenset(
    {
        "schema",
        "session_id",
        "automatic_timestamp_mutation",
        "marker_clock",
        "caption_clock",
        "clock_relation",
        "source_audio",
        "capture_chunk_map",
        "raw_markers",
        "raw_spans",
        "candidates",
    }
)
_MARKER_CLOCK_KEYS = frozenset(
    {"domain", "sample_rate_hz", "dropped_samples", "dropped_sample_mapping"}
)
_CAPTION_CLOCK_KEYS = frozenset({"domain", "origin", "unit"})
_MARKER_KEYS = frozenset(
    {
        "marker_id",
        "kind",
        "subject_number",
        "question_id",
        "visit_id",
        "revision",
        "captured_audio_clock",
        "captured_audio_sample_index",
        "captured_audio_sample_rate_hz",
        "captured_audio_seconds",
        "source",
        "precision",
    }
)
_SPAN_KEYS = frozenset({"source_span_id", "sequence", "start", "end", "text", "text_sha256"})
_CANDIDATE_KEYS = frozenset(
    {
        "candidate_id",
        "status",
        "review_status",
        "source_span_ids",
        "source_text_sha256",
        "verifier_span_ids",
        "verifier_text_sha256",
        "source_chunk_ids",
        "source_audio_sha256",
        "aligner_provenance",
        "candidate_start",
        "candidate_end",
        "candidate_start_sample_index",
        "candidate_end_sample_index",
        "reason_codes",
    }
)
# This module is deliberately a source-only handoff.  It does not possess
# immutable audio bytes or an aligner output which it can re-hash.  A later,
# separate runtime may define a verified-candidate schema, but this generic
# sidecar must never treat self-reported metadata as that proof.
_CANDIDATE_STATUSES = frozenset({"unassessable"})
_REVIEW_STATUSES = frozenset({"not_reviewed"})
_DROPPED_MAPPING_KEYS = frozenset({"start_sample_index", "end_sample_index"})


def _unknown_fields(value: Mapping[str, Any], allowed: frozenset[str], *, field: str) -> None:
    unknown = set(value) - allowed
    if unknown:
        raise ValueError(f"{field} 有未知欄位：{', '.join(sorted(unknown))}")


def _nonempty_string(value: object, *, field: str, maximum: int = 256) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError(f"{field} 無效")
    return value


def _nonnegative_int(value: object, *, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field} 無效")
    return value


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _strict_dict(value: object, *, field: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{field} 必須係 object")
    return value


def _validated_dropped_mapping(value: object, *, dropped_samples: int) -> list[dict[str, int]] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError("dropped_sample_mapping 必須係 list 或 null")
    entries: list[dict[str, int]] = []
    prior_end = 0
    total = 0
    for raw in value:
        item = _strict_dict(raw, field="dropped sample mapping")
        _unknown_fields(item, _DROPPED_MAPPING_KEYS, field="dropped sample mapping")
        if set(item) != _DROPPED_MAPPING_KEYS:
            raise ValueError("dropped sample mapping 缺少欄位")
        start = _nonnegative_int(item["start_sample_index"], field="dropped sample start")
        end = _nonnegative_int(item["end_sample_index"], field="dropped sample end")
        if end <= start or (entries and start < prior_end):
            raise ValueError("dropped sample mapping 無效")
        entries.append({"start_sample_index": start, "end_sample_index": end})
        prior_end = end
        total += end - start
    if total != dropped_samples:
        raise ValueError("dropped sample mapping count 不一致")
    return entries


def _validated_marker(value: object) -> dict[str, Any]:
    item = _strict_dict(value, field="raw marker")
    _unknown_fields(item, _MARKER_KEYS, field="raw marker")
    if set(item) != _MARKER_KEYS:
        raise ValueError("raw marker 缺少欄位")
    marker = OperationalInterviewMarker(
        marker_id=item["marker_id"],
        kind=item["kind"],
        subject_number=item["subject_number"],
        question_id=item["question_id"],
        visit_id=item["visit_id"],
        revision=item["revision"],
        captured_audio_sample_index=item["captured_audio_sample_index"],
        captured_audio_sample_rate_hz=item["captured_audio_sample_rate_hz"],
        captured_audio_seconds=item["captured_audio_seconds"],
        source=item["source"],
        precision=item["precision"],
    )
    if item["captured_audio_clock"] != "accepted_pcm_sample_index":
        raise ValueError("raw marker clock domain 無效")
    return marker.to_dict()


def _caption_from_value(value: object) -> FinalizedCaption:
    if isinstance(value, FinalizedCaption):
        return value
    item = _strict_dict(value, field="raw caption")
    allowed = frozenset({"sequence", "start", "end", "text"})
    _unknown_fields(item, allowed, field="raw caption")
    if set(item) != allowed:
        raise ValueError("raw caption 缺少欄位")
    return FinalizedCaption(
        sequence=item["sequence"], start=item["start"], end=item["end"], text=item["text"]
    )


def _validated_span(value: object) -> dict[str, Any]:
    item = _strict_dict(value, field="raw span")
    _unknown_fields(item, _SPAN_KEYS, field="raw span")
    if set(item) != _SPAN_KEYS:
        raise ValueError("raw span 缺少欄位")
    caption = FinalizedCaption(
        sequence=item["sequence"], start=item["start"], end=item["end"], text=item["text"]
    )
    expected_id = caption.evidence_id
    if item["source_span_id"] != expected_id:
        raise ValueError("raw span id 同 caption sequence 不一致")
    if item["text_sha256"] != _sha256_text(caption.text):
        raise ValueError("raw span text hash 不一致")
    return {
        "source_span_id": expected_id,
        "sequence": caption.sequence,
        "start": caption.start,
        "end": caption.end,
        "text": caption.text,
        "text_sha256": item["text_sha256"],
    }


def _validated_candidate(
    value: object,
    *,
    spans: Mapping[str, dict[str, Any]],
) -> dict[str, Any]:
    item = _strict_dict(value, field="candidate")
    _unknown_fields(item, _CANDIDATE_KEYS, field="candidate")
    if set(item) != _CANDIDATE_KEYS:
        raise ValueError("candidate 缺少欄位")
    candidate_id = _nonempty_string(item["candidate_id"], field="candidate id")
    status = item["status"]
    review_status = item["review_status"]
    if status not in _CANDIDATE_STATUSES:
        raise ValueError("current source-only timing sidecar 只接受 unassessable candidate")
    if review_status not in _REVIEW_STATUSES:
        raise ValueError("unassessable candidate review_status 必須係 not_reviewed")
    source_span_ids = item["source_span_ids"]
    source_text_sha256 = item["source_text_sha256"]
    if not isinstance(source_span_ids, list) or not isinstance(source_text_sha256, list):
        raise ValueError("candidate source spans 必須係 list")
    if not source_span_ids or len(source_span_ids) != len(source_text_sha256):
        raise ValueError("candidate source spans 無效")
    if len(set(source_span_ids)) != len(source_span_ids):
        raise ValueError("candidate source span 重複")
    for span_id, text_hash in zip(source_span_ids, source_text_sha256, strict=True):
        if span_id not in spans or spans[span_id]["text_sha256"] != text_hash:
            raise ValueError("candidate source span 或 text hash 不一致")
    source_span_sequences = [spans[span_id]["sequence"] for span_id in source_span_ids]
    if source_span_sequences != sorted(source_span_sequences) or len(set(source_span_sequences)) != len(source_span_sequences):
        raise ValueError("candidate source span 次序無效")

    verifier_span_ids = item["verifier_span_ids"]
    verifier_text_sha256 = item["verifier_text_sha256"]
    source_chunk_ids = item["source_chunk_ids"]
    source_audio_sha256 = item["source_audio_sha256"]
    aligner_provenance = item["aligner_provenance"]
    start_sample_index = item["candidate_start_sample_index"]
    end_sample_index = item["candidate_end_sample_index"]
    start, end = item["candidate_start"], item["candidate_end"]
    if (
        start is not None
        or end is not None
        or start_sample_index is not None
        or end_sample_index is not None
        or verifier_span_ids != []
        or verifier_text_sha256 != []
        or source_chunk_ids != []
        or source_audio_sha256 is not None
        or aligner_provenance is not None
    ):
        raise ValueError("unassessable candidate 唔可以帶 candidate、method 或 provenance")
    reason_codes = item["reason_codes"]
    if not isinstance(reason_codes, list) or not reason_codes:
        raise ValueError("candidate reason_codes 無效")
    normalized_reasons = [_nonempty_string(code, field="candidate reason") for code in reason_codes]
    return {
        "candidate_id": candidate_id,
        "status": status,
        "review_status": review_status,
        "source_span_ids": list(source_span_ids),
        "source_text_sha256": list(source_text_sha256),
        "verifier_span_ids": list(verifier_span_ids),
        "verifier_text_sha256": list(verifier_text_sha256),
        "source_chunk_ids": list(source_chunk_ids),
        "source_audio_sha256": source_audio_sha256,
        "aligner_provenance": aligner_provenance,
        "candidate_start": start,
        "candidate_end": end,
        "candidate_start_sample_index": start_sample_index,
        "candidate_end_sample_index": end_sample_index,
        "reason_codes": normalized_reasons,
    }


@dataclass(frozen=True)
class PostSessionInterviewTimingV1:
    """Validated read-only handoff for a later timing-review tool."""

    value: dict[str, Any]

    def __post_init__(self) -> None:
        validated = self.validate(self.value)
        object.__setattr__(self, "value", validated)

    @classmethod
    def from_dict(cls, value: object) -> "PostSessionInterviewTimingV1":
        return cls(dict(_strict_dict(value, field="post-session timing manifest")))

    @classmethod
    def validate(cls, value: object) -> dict[str, Any]:
        item = _strict_dict(value, field="post-session timing manifest")
        _unknown_fields(item, _MANIFEST_KEYS, field="post-session timing manifest")
        if set(item) != _MANIFEST_KEYS:
            raise ValueError("post-session timing manifest 缺少欄位")
        if item["schema"] != POST_SESSION_INTERVIEW_TIMING_SCHEMA:
            raise ValueError("post-session timing schema 無效")
        session_id = _nonempty_string(item["session_id"], field="session id")
        if item["automatic_timestamp_mutation"] is not False:
            raise ValueError("automatic_timestamp_mutation 必須係 false")
        marker_clock = _strict_dict(item["marker_clock"], field="marker_clock")
        _unknown_fields(marker_clock, _MARKER_CLOCK_KEYS, field="marker_clock")
        if set(marker_clock) != _MARKER_CLOCK_KEYS:
            raise ValueError("marker_clock 缺少欄位")
        if marker_clock["domain"] != "accepted_pcm_sample_index":
            raise ValueError("marker_clock domain 無效")
        sample_rate_hz = _nonnegative_int(marker_clock["sample_rate_hz"], field="marker_clock sample rate")
        dropped_samples = _nonnegative_int(marker_clock["dropped_samples"], field="marker_clock dropped samples")
        dropped_mapping = _validated_dropped_mapping(
            marker_clock["dropped_sample_mapping"], dropped_samples=dropped_samples
        )
        caption_clock = _strict_dict(item["caption_clock"], field="caption_clock")
        _unknown_fields(caption_clock, _CAPTION_CLOCK_KEYS, field="caption_clock")
        if caption_clock != {
            "domain": "live_caption_timeline_seconds",
            "origin": "capture_start",
            "unit": "seconds",
        }:
            raise ValueError("caption_clock metadata 無效")
        if item["clock_relation"] != CLOCK_RELATION:
            raise ValueError("clock_relation 無效")
        # A sha256 written into a sidecar is not verification: this runtime
        # has no retained bytes to hash.  Keep this source-only schema unable
        # to represent an apparently-supported candidate at all.
        if item["source_audio"] is not None or item["capture_chunk_map"] is not None:
            raise ValueError(
                "current source-only timing sidecar 唔接受未可重算嘅 audio 或 capture mapping"
            )
        source_audio = None
        raw_markers = [_validated_marker(marker) for marker in item["raw_markers"]] if isinstance(item["raw_markers"], list) else None
        if raw_markers is None:
            raise ValueError("raw_markers 必須係 list")
        if any(marker["captured_audio_sample_rate_hz"] != sample_rate_hz for marker in raw_markers):
            raise ValueError("raw marker sample rate 同 marker clock 不一致")
        raw_spans = [_validated_span(span) for span in item["raw_spans"]] if isinstance(item["raw_spans"], list) else None
        if raw_spans is None:
            raise ValueError("raw_spans 必須係 list")
        spans = {span["source_span_id"]: span for span in raw_spans}
        if len(spans) != len(raw_spans):
            raise ValueError("raw span id 重複")
        chunks = None
        if not isinstance(item["candidates"], list):
            raise ValueError("candidates 必須係 list")
        candidates = [
            _validated_candidate(
                candidate,
                spans=spans,
            )
            for candidate in item["candidates"]
        ]
        if len({candidate["candidate_id"] for candidate in candidates}) != len(candidates):
            raise ValueError("candidate id 重複")

        return {
            "schema": POST_SESSION_INTERVIEW_TIMING_SCHEMA,
            "session_id": session_id,
            "automatic_timestamp_mutation": False,
            "marker_clock": {
                "domain": "accepted_pcm_sample_index",
                "sample_rate_hz": sample_rate_hz,
                "dropped_samples": dropped_samples,
                "dropped_sample_mapping": dropped_mapping,
            },
            "caption_clock": dict(caption_clock),
            "clock_relation": CLOCK_RELATION,
            "source_audio": source_audio,
            "capture_chunk_map": chunks,
            "raw_markers": raw_markers,
            "raw_spans": raw_spans,
            "candidates": candidates,
        }

    def to_dict(self) -> dict[str, Any]:
        """Return a fresh deep JSON-safe copy, never a mutable internal alias."""

        return self.validate(self.value)


def build_unassessable_post_session_timing(
    *,
    session_id: str,
    raw_markers: Iterable[OperationalInterviewMarker | Mapping[str, Any]],
    finalized_captions: Iterable[FinalizedCaption | Mapping[str, Any]],
    sample_rate_hz: int,
    dropped_samples: int,
    dropped_sample_mapping: list[Mapping[str, Any]] | None = None,
) -> PostSessionInterviewTimingV1:
    """Make an explicitly-unassessable, non-mutating review sidecar.

    The current live session does not persist source audio or chunk-to-audio
    mapping.  This builder is intentionally only for that honest handoff: it
    keeps raw markers/captions byte-for-byte as supplied and creates no timing
    candidate which could be silently applied.
    """

    markers = [
        item.to_dict() if isinstance(item, OperationalInterviewMarker) else dict(item)
        for item in raw_markers
    ]
    captions = [_caption_from_value(item) for item in finalized_captions]
    spans = [
        {
            "source_span_id": caption.evidence_id,
            "sequence": caption.sequence,
            "start": caption.start,
            "end": caption.end,
            "text": caption.text,
            "text_sha256": _sha256_text(caption.text),
        }
        for caption in captions
    ]
    reason_codes: list[str] = []
    reason_codes.extend(["source_audio_not_retained", "aligner_output_not_verified"])
    if not spans:
        reason_codes.append("transcript_spans_missing")
    if dropped_samples > 0 and not dropped_sample_mapping:
        reason_codes.append("dropped_samples_mapping_missing")
    candidates = [
        {
            "candidate_id": f"candidate-{span['source_span_id']}",
            "status": "unassessable",
            "review_status": "not_reviewed",
            "source_span_ids": [span["source_span_id"]],
            "source_text_sha256": [span["text_sha256"]],
            "verifier_span_ids": [],
            "verifier_text_sha256": [],
            "source_chunk_ids": [],
            "source_audio_sha256": None,
            "aligner_provenance": None,
            "candidate_start": None,
            "candidate_end": None,
            "candidate_start_sample_index": None,
            "candidate_end_sample_index": None,
            "reason_codes": list(reason_codes),
        }
        for span in spans
    ]
    return PostSessionInterviewTimingV1.from_dict(
        {
            "schema": POST_SESSION_INTERVIEW_TIMING_SCHEMA,
            "session_id": session_id,
            "automatic_timestamp_mutation": False,
            "marker_clock": {
                "domain": "accepted_pcm_sample_index",
                "sample_rate_hz": sample_rate_hz,
                "dropped_samples": dropped_samples,
                "dropped_sample_mapping": (
                    None if dropped_sample_mapping is None else [dict(item) for item in dropped_sample_mapping]
                ),
            },
            "caption_clock": {
                "domain": "live_caption_timeline_seconds",
                "origin": "capture_start",
                "unit": "seconds",
            },
            "clock_relation": CLOCK_RELATION,
            "source_audio": None,
            "capture_chunk_map": None,
            "raw_markers": markers,
            "raw_spans": spans,
            "candidates": candidates,
        }
    )


__all__ = [
    "CLOCK_RELATION",
    "POST_SESSION_INTERVIEW_TIMING_SCHEMA",
    "PostSessionInterviewTimingV1",
    "build_unassessable_post_session_timing",
]
