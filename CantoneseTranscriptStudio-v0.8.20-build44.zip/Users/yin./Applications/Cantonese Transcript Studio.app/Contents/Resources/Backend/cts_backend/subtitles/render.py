"""Local libass burn-in renderer with real FFmpeg progress and cancellation."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import shutil
import subprocess
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping

from ..audio.media import (
    OwnedProcessCancelled,
    OwnedProcessDeadlineExceeded,
    OwnedProcessOutputLimitExceeded,
    run_owned_process,
    terminate_owned_process_group,
)
from ..jobs.state import fingerprint_file
from ..models import move_to_trash
from .ass import generate_ass
from .project import _atomic_json
from .schemas import SHA256_PATTERN, SubtitleProject


RENDER_SCHEMA = 1
RENDER_DIRECTORY = "subtitle"
RENDER_MANIFEST = "render.json"
MAX_RENDER_MANIFEST_BYTES = 1024 * 1024
DEFAULT_FFMPEG_FULL = Path("/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg")
DEFAULT_FFPROBE_FULL = Path("/opt/homebrew/opt/ffmpeg-full/bin/ffprobe")
DEFAULT_FFPROBE = Path("/opt/homebrew/bin/ffprobe")
SUBTITLE_PROCESS_TIMEOUT_SECONDS = 6 * 60 * 60.0
SUBTITLE_TERMINATION_GRACE_SECONDS = 2.0
MAX_SUBTITLE_PROGRESS_BYTES = 8 * 1024 * 1024
MAX_SUBTITLE_PROGRESS_LINE_BYTES = 1024 * 1024

ProgressCallback = Callable[[float, Mapping[str, str]], None]


class RenderCancelled(RuntimeError):
    pass


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _sha256_bytes(payload: bytes) -> str:
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return f"sha256:{digest.hexdigest()}"


def _executable(path: Path) -> bool:
    return path.is_file() and not path.is_symlink() and os.access(path, os.X_OK)


def terminate_owned_process(process: subprocess.Popen[str], *, timeout: float = 3.0) -> None:
    """Boundedly terminate an isolated owned encoder process group."""
    terminate_owned_process_group(process, grace_seconds=timeout)


def _run_subtitle_process(
    command: list[str],
    *,
    directory: Path,
    cancel_event: threading.Event,
    progress_callback: ProgressCallback,
    duration_ms: int,
    log_path: Path,
) -> tuple[int, str]:
    """Run FFmpeg with live progress and a parent-death-safe process group."""

    pending_stdout = bytearray()
    progress_event: dict[str, str] = {}

    def accept_stdout(data: bytes) -> None:
        pending_stdout.extend(data)
        if (
            len(pending_stdout) > MAX_SUBTITLE_PROGRESS_LINE_BYTES
            and b"\n" not in pending_stdout
        ):
            raise OwnedProcessOutputLimitExceeded
        while True:
            newline = pending_stdout.find(b"\n")
            if newline < 0:
                return
            raw_line = bytes(pending_stdout[:newline])
            del pending_stdout[: newline + 1]
            line = raw_line.rstrip(b"\r").decode("utf-8", errors="replace").strip()
            if not line or "=" not in line:
                continue
            key, value = line.split("=", 1)
            progress_event[key] = value
            if key == "progress":
                fraction = parse_progress_fraction(progress_event, duration_ms)
                if fraction is not None:
                    progress_callback(fraction, dict(progress_event))
                progress_event.clear()

    if log_path.is_symlink():
        raise ValueError("字幕 renderer log 路徑唔可以係 symlink")
    with log_path.open("ab") as log:
        return_code, _, stderr_tail = run_owned_process(
            command,
            timeout_seconds=SUBTITLE_PROCESS_TIMEOUT_SECONDS,
            termination_grace_seconds=SUBTITLE_TERMINATION_GRACE_SECONDS,
            cancel_requested=cancel_event.is_set,
            stdout_consumer=accept_stdout,
            stderr_consumer=log.write,
            stdout_limit_bytes=MAX_SUBTITLE_PROGRESS_BYTES,
            working_directory=directory,
        )
        log.flush()
        os.fsync(log.fileno())
    if pending_stdout:
        accept_stdout(b"\n")
    return return_code, stderr_tail.decode("utf-8", errors="replace")


def _has_ass_filter(output: str) -> bool:
    for line in output.splitlines():
        fields = line.split()
        if len(fields) >= 2 and fields[1] == "ass":
            return True
    return False


def resolve_subtitle_ffmpeg() -> str:
    configured = os.environ.get("CTS_SUBTITLE_FFMPEG")
    candidates = [Path(configured).expanduser()] if configured else [DEFAULT_FFMPEG_FULL]
    path = next((candidate.resolve() for candidate in candidates if _executable(candidate)), None)
    if path is None:
        raise RuntimeError(
            "搵唔到支援字幕嘅 ffmpeg-full；請先完成字幕 renderer 安裝"
        )
    try:
        return_code, stdout, stderr = run_owned_process(
            [str(path), "-hide_banner", "-filters"],
            timeout_seconds=15,
            termination_grace_seconds=SUBTITLE_TERMINATION_GRACE_SECONDS,
        )
    except (
        OSError,
        ValueError,
        OwnedProcessDeadlineExceeded,
        OwnedProcessOutputLimitExceeded,
    ) as exc:
        raise RuntimeError(f"無法驗證字幕 renderer：{exc}") from exc
    output = (stdout + stderr).decode("utf-8", errors="replace")
    if return_code != 0 or not _has_ass_filter(output):
        raise RuntimeError("目前 FFmpeg 冇 ass/libass filter，唔可以燒入字幕")
    return str(path)


def resolve_subtitle_ffprobe(ffmpeg_path: str) -> str:
    configured = os.environ.get("CTS_SUBTITLE_FFPROBE")
    candidates = []
    if configured:
        candidates.append(Path(configured).expanduser())
    candidates.extend([Path(ffmpeg_path).with_name("ffprobe"), DEFAULT_FFPROBE_FULL, DEFAULT_FFPROBE])
    for candidate in candidates:
        if _executable(candidate):
            return str(candidate.resolve())
    discovered = shutil.which("ffprobe")
    if discovered and _executable(Path(discovered)):
        return str(Path(discovered).resolve())
    raise RuntimeError("搵唔到 ffprobe，無法驗證影片輸出")


def probe_media(path: str | Path, *, ffprobe_path: str) -> dict[str, Any]:
    source = Path(path).expanduser()
    if source.is_symlink() or not source.is_file():
        raise FileNotFoundError(f"搵唔到原始媒體：{source}")
    command = [
        ffprobe_path,
        "-v",
        "error",
        "-show_entries",
        (
            "stream=codec_type,codec_name,width,height,pix_fmt:"
            "stream_tags=rotate:stream_side_data=rotation:format=duration"
        ),
        "-of",
        "json",
        str(source),
    ]
    try:
        return_code, stdout, _ = run_owned_process(
            command,
            timeout_seconds=30,
            termination_grace_seconds=SUBTITLE_TERMINATION_GRACE_SECONDS,
        )
    except OwnedProcessDeadlineExceeded as exc:
        raise ValueError("讀取原始媒體逾時") from exc
    except (OSError, ValueError, OwnedProcessOutputLimitExceeded) as exc:
        raise ValueError("無法啟動媒體完整性驗證") from exc
    if return_code != 0:
        raise ValueError("無法讀取原始媒體；檔案可能損壞或格式不支援")
    try:
        payload = json.loads(stdout.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("ffprobe 回傳無效資料") from exc
    streams = payload.get("streams") if isinstance(payload, Mapping) else None
    if not isinstance(streams, list):
        streams = []
    video = next(
        (
            item
            for item in streams
            if isinstance(item, Mapping)
            and item.get("codec_type") == "video"
            and isinstance(item.get("width"), int)
            and isinstance(item.get("height"), int)
        ),
        None,
    )
    duration = 0.0
    raw_format = payload.get("format") if isinstance(payload, Mapping) else None
    if isinstance(raw_format, Mapping):
        try:
            duration = max(0.0, float(raw_format.get("duration", 0)))
        except (TypeError, ValueError):
            duration = 0.0
    rotation = 0
    if video is not None:
        tags = video.get("tags")
        raw_rotation = tags.get("rotate") if isinstance(tags, Mapping) else None
        side_data = video.get("side_data_list")
        if isinstance(side_data, list):
            for item in side_data:
                if isinstance(item, Mapping) and item.get("rotation") is not None:
                    raw_rotation = item.get("rotation")
                    break
        try:
            rotation = int(float(raw_rotation or 0)) % 360
        except (TypeError, ValueError):
            rotation = 0
    width = int(video["width"]) if video is not None else None
    height = int(video["height"]) if video is not None else None
    if width is not None and height is not None and rotation in {90, 270}:
        width, height = height, width
    return {
        "has_video": video is not None,
        "has_audio": any(
            isinstance(item, Mapping) and item.get("codec_type") == "audio" for item in streams
        ),
        "width": width,
        "height": height,
        "rotation": rotation,
        "video_codec": str(video.get("codec_name")) if video is not None else None,
        "pixel_format": str(video.get("pix_fmt")) if video is not None else None,
        "audio_codecs": tuple(
            str(item.get("codec_name"))
            for item in streams
            if isinstance(item, Mapping)
            and item.get("codec_type") == "audio"
            and item.get("codec_name")
        ),
        "duration_ms": round(duration * 1000),
    }


def validate_source_fingerprint(path: str | Path, expected: str) -> str:
    """Fail closed when the imported source no longer matches its job fingerprint."""
    source = Path(path).expanduser()
    if source.is_symlink() or not source.is_file():
        raise FileNotFoundError(f"搞唔到原始媒體：{source}")
    if not isinstance(expected, str) or not SHA256_PATTERN.fullmatch(expected):
        raise ValueError("工作缺少有效原始媒體指紋；請重新匯入檔案")
    try:
        actual = fingerprint_file(source)
    except (OSError, RuntimeError) as exc:
        raise ValueError(f"無法驗證原始媒體指紋：{exc}") from exc
    if actual != expected:
        raise ValueError("原始媒體已經更改；為免字幕燒入錯片，請重新匯入檔案")
    return actual


def parse_progress_fraction(event: Mapping[str, str], duration_ms: int) -> float | None:
    if event.get("progress") == "end":
        return 1.0
    if duration_ms <= 0:
        return None
    for key in ("out_time_us", "out_time_ms"):
        raw = event.get(key)
        if raw is None:
            continue
        try:
            return max(0.0, min(0.999, int(raw) / (duration_ms * 1000)))
        except ValueError:
            continue
    return None


def _video_bitrate(width: int, height: int) -> str:
    pixels = width * height
    if pixels <= 1280 * 720:
        return "5M"
    if pixels <= 1920 * 1080:
        return "10M"
    return "20M"


def build_render_command(
    *,
    ffmpeg_path: str,
    source_path: str,
    ass_filename: str,
    partial_filename: str,
    width: int,
    height: int,
) -> list[str]:
    if Path(ass_filename).name != ass_filename or Path(partial_filename).name != partial_filename:
        raise ValueError("render artifact 必須使用 workspace 相對檔名")
    if not partial_filename.endswith(".mp4"):
        raise ValueError("render partial output 必須係 MP4")
    return [
        ffmpeg_path,
        "-hide_banner",
        "-y",
        "-i",
        source_path,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-vf",
        f"ass={ass_filename}",
        "-c:v",
        "h264_videotoolbox",
        "-b:v",
        _video_bitrate(width, height),
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        "96k",
        "-movflags",
        "+faststart",
        "-progress",
        "pipe:1",
        "-nostats",
        partial_filename,
    ]


def _safe_manifest(path: Path, job_id: str) -> dict[str, Any] | None:
    if not path.exists():
        return None
    if path.is_symlink() or not path.is_file() or path.stat().st_size > MAX_RENDER_MANIFEST_BYTES:
        raise ValueError("render.json 無效")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("render.json 已損壞") from exc
    if (
        not isinstance(value, Mapping)
        or value.get("schema") != RENDER_SCHEMA
        or value.get("job_id") != job_id
    ):
        raise ValueError("render.json job id 無效")
    if value.get("state") not in {
        "idle",
        "queued",
        "rendering",
        "completed",
        "failed",
        "cancelled",
    }:
        raise ValueError("render state 無效")
    progress = value.get("progress")
    if (
        isinstance(progress, bool)
        or not isinstance(progress, (int, float))
        or not 0 <= float(progress) <= 1
    ):
        raise ValueError("render progress 無效")
    for key in ("ass_filename", "partial_filename", "output_filename"):
        raw_name = value.get(key)
        if raw_name is not None and (
            not isinstance(raw_name, str)
            or Path(raw_name).name != raw_name
            or raw_name in {".", ".."}
        ):
            raise ValueError(f"render {key} 無效")
    render_content = value.get("render_content", "source")
    if render_content not in {"source", "bilingual", "translated"}:
        raise ValueError("render content identity 無效")
    ass_sha256 = value.get("ass_sha256")
    if ass_sha256 is not None and (
        not isinstance(ass_sha256, str) or SHA256_PATTERN.fullmatch(ass_sha256) is None
    ):
        raise ValueError("render ASS identity 無效")
    return dict(value)


def _idle_render(job_id: str) -> dict[str, Any]:
    return {
        "schema": RENDER_SCHEMA,
        "job_id": job_id,
        "state": "idle",
        "progress": 0.0,
        "profile": "h264_mp4",
        "output_path": None,
        "started_at": None,
        "completed_at": None,
        "error": None,
        "project_revision": None,
        "source_final_sha256": None,
        "render_content": "source",
        "target_language": None,
        "translation_layout": None,
        "translation_artifact_sha256": None,
        "translation_result_sha256": None,
        "ass_sha256": None,
        "cancel_requested": False,
    }


class SubtitleRenderer:
    def __init__(self) -> None:
        self._manifest_lock = threading.RLock()

    @staticmethod
    def directory(workspace: Path) -> Path:
        root = workspace.resolve(strict=True)
        directory = root / RENDER_DIRECTORY
        if directory.is_symlink():
            raise ValueError("subtitle render directory 唔可以係 symlink")
        directory.mkdir(parents=True, exist_ok=True)
        resolved = directory.resolve(strict=True)
        resolved.relative_to(root)
        return resolved

    def status(self, workspace: Path, job_id: str) -> dict[str, Any]:
        directory = self.directory(workspace)
        with self._manifest_lock:
            return _safe_manifest(directory / RENDER_MANIFEST, job_id) or _idle_render(job_id)

    def save_status(self, workspace: Path, value: Mapping[str, Any]) -> dict[str, Any]:
        job_id = value.get("job_id")
        if not isinstance(job_id, str) or not job_id:
            raise ValueError("render job_id 無效")
        state = value.get("state")
        if state not in {"idle", "queued", "rendering", "completed", "failed", "cancelled"}:
            raise ValueError("render state 無效")
        progress = value.get("progress")
        if isinstance(progress, bool) or not isinstance(progress, (int, float)) or not 0 <= progress <= 1:
            raise ValueError("render progress 無效")
        payload = dict(value)
        directory = self.directory(workspace)
        with self._manifest_lock:
            _atomic_json(directory / RENDER_MANIFEST, payload)
        return payload

    def prepare(
        self,
        *,
        workspace: Path,
        project: SubtitleProject,
        ffmpeg_path: str,
        ffprobe_path: str,
        render_content: str = "source",
        target_language: str | None = None,
        translation_layout: str | None = None,
        translation_artifact_sha256: str | None = None,
        translation_result_sha256: str | None = None,
    ) -> dict[str, Any]:
        current = self.status(workspace, project.job_id)
        if current.get("state") in {"queued", "rendering"}:
            raise ValueError("呢個工作已有字幕影片處理中")
        media = probe_media(project.source_path, ffprobe_path=ffprobe_path)
        if not media["has_video"]:
            raise ValueError("原檔冇影片軌；純音訊唔可以燒入字幕")
        width = int(media["width"])
        height = int(media["height"])
        if render_content not in {"source", "bilingual", "translated"}:
            raise ValueError("字幕影片內容類型無效")
        if render_content == "source":
            if any(
                value is not None
                for value in (
                    target_language,
                    translation_layout,
                    translation_artifact_sha256,
                    translation_result_sha256,
                )
            ):
                raise ValueError("原文字幕輸出唔接受翻譯 identity")
        elif (
            translation_layout != render_content
            or not isinstance(target_language, str)
            or not target_language
            or not isinstance(translation_artifact_sha256, str)
            or not isinstance(translation_result_sha256, str)
            or SHA256_PATTERN.fullmatch(translation_result_sha256) is None
        ):
            raise ValueError("雙語字幕輸出缺少完整 translation identity")
        token = uuid.uuid4().hex[:10]
        stem = f"burned-{render_content}-subtitles-r{project.revision}-{token}"
        directory = self.directory(workspace)
        ass_name = f"captions-r{project.revision}-{token}.ass"
        partial_name = f".{stem}.partial.mp4"
        output_name = f"{stem}.mp4"
        ass_path = directory / ass_name
        ass_text = generate_ass(project, width=width, height=height)
        ass_payload = ass_text.encode("utf-8")
        ass_sha256 = _sha256_bytes(ass_payload)
        descriptor = os.open(ass_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(ass_payload)
            handle.flush()
            os.fsync(handle.fileno())
        now = _utc_now()
        manifest = {
            "schema": RENDER_SCHEMA,
            "job_id": project.job_id,
            "state": "queued",
            "progress": 0.0,
            "profile": "h264_mp4",
            "output_path": None,
            "started_at": None,
            "completed_at": None,
            "error": None,
            "project_revision": project.revision,
            "source_fingerprint": project.source_fingerprint,
            "source_final_sha256": project.source_final_sha256,
            "render_content": render_content,
            "target_language": target_language,
            "translation_layout": translation_layout,
            "translation_artifact_sha256": translation_artifact_sha256,
            "translation_result_sha256": translation_result_sha256,
            "ass_sha256": ass_sha256,
            "cancel_requested": False,
            "queued_at": now,
            "source_path": project.source_path,
            "ffmpeg_path": ffmpeg_path,
            "ffprobe_path": ffprobe_path,
            "ass_filename": ass_name,
            "partial_filename": partial_name,
            "output_filename": output_name,
            "width": width,
            "height": height,
            "duration_ms": max(project.duration_ms, int(media.get("duration_ms") or 0)),
        }
        return self.save_status(workspace, manifest)

    def execute(
        self,
        *,
        workspace: Path,
        manifest: Mapping[str, Any],
        cancel_event: threading.Event,
        progress_callback: ProgressCallback,
    ) -> dict[str, Any]:
        directory = self.directory(workspace)
        source = Path(str(manifest["source_path"])).expanduser()
        if source.is_symlink() or not source.is_file():
            raise FileNotFoundError(f"搵唔到原始影片：{source}")
        partial_name = str(manifest["partial_filename"])
        output_name = str(manifest["output_filename"])
        ass_name = str(manifest["ass_filename"])
        for name in (ass_name, partial_name, output_name):
            if Path(name).name != name or name in {".", ".."}:
                raise ValueError("render artifact 路徑無效")
        ass_path = directory / ass_name
        if ass_path.is_symlink() or not ass_path.is_file():
            raise FileNotFoundError("搵唔到安全 ASS 字幕檔")
        expected_ass_sha256 = manifest.get("ass_sha256")
        if manifest.get("schema") == RENDER_SCHEMA:
            if (
                not isinstance(expected_ass_sha256, str)
                or SHA256_PATTERN.fullmatch(expected_ass_sha256) is None
            ):
                raise ValueError("字幕影片缺少有效 ASS identity；請重新開始輸出")
            actual_ass_sha256 = _sha256_file(ass_path)
            if not hmac.compare_digest(expected_ass_sha256, actual_ass_sha256):
                raise ValueError("ASS 字幕檔 integrity 驗證失敗；請重新開始輸出")
        partial = directory / partial_name
        output = directory / output_name
        if (
            partial.exists()
            or partial.is_symlink()
            or output.exists()
            or output.is_symlink()
        ):
            raise ValueError("render output 已存在；為免覆蓋檔案，請重新開始輸出")
        if source.resolve() in {partial.resolve(strict=False), output.resolve(strict=False)}:
            raise ValueError("原始影片同輸出路徑唔可以相同")
        validate_source_fingerprint(source, str(manifest.get("source_fingerprint") or ""))
        if cancel_event.is_set():
            raise RenderCancelled("字幕影片輸出已取消")
        command = build_render_command(
            ffmpeg_path=str(manifest["ffmpeg_path"]),
            source_path=str(source),
            ass_filename=ass_name,
            partial_filename=partial_name,
            width=int(manifest["width"]),
            height=int(manifest["height"]),
        )
        log_path = directory / "render.log"
        try:
            return_code, _ = _run_subtitle_process(
                command,
                directory=directory,
                cancel_event=cancel_event,
                progress_callback=progress_callback,
                duration_ms=int(manifest["duration_ms"]),
                log_path=log_path,
            )
        except OwnedProcessCancelled as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RenderCancelled("字幕影片輸出已取消") from exc
        except OwnedProcessDeadlineExceeded as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("字幕影片輸出逾時；請重試") from exc
        except OwnedProcessOutputLimitExceeded as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("字幕 renderer 回傳過多資料，已安全停止") from exc
        except OSError as exc:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("無法啟動字幕 renderer") from exc
        except BaseException:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise
        if cancel_event.is_set():
            if partial.exists():
                move_to_trash(partial)
            raise RenderCancelled("字幕影片輸出已取消")
        if return_code != 0:
            if partial.exists():
                move_to_trash(partial)
            raise RuntimeError(
                f"字幕影片輸出失敗（code {return_code}）；技術詳情已寫入 render.log"
            )
        if not partial.is_file() or partial.stat().st_size <= 0:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise RuntimeError("FFmpeg 冇產生完整影片")
        try:
            verified = probe_media(partial, ffprobe_path=str(manifest["ffprobe_path"]))
        except BaseException:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise
        if not verified["has_video"] or int(verified.get("duration_ms") or 0) <= 0:
            move_to_trash(partial)
            raise RuntimeError("輸出影片完整性驗證失敗")
        expected_duration = int(manifest.get("duration_ms") or 0)
        actual_duration = int(verified["duration_ms"])
        if expected_duration > 2000 and actual_duration + 1000 < expected_duration * 0.9:
            move_to_trash(partial)
            raise RuntimeError("輸出影片長度明顯短過原片")
        try:
            os.replace(partial, output)
        except BaseException:
            if partial.exists() or partial.is_symlink():
                move_to_trash(partial)
            raise
        result = dict(manifest)
        result.update(
            {
                "state": "completed",
                "progress": 1.0,
                "output_path": str(output.resolve()),
                "completed_at": _utc_now(),
                "error": None,
                "cancel_requested": False,
            }
        )
        try:
            return self.save_status(workspace, result)
        except BaseException:
            if output.exists() or output.is_symlink():
                move_to_trash(output)
            raise

    def recover(self, jobs_root: Path) -> tuple[list[str], list[str]]:
        """Requeue never-started renders and mark interrupted encodes failed."""
        queued: list[str] = []
        interrupted: list[str] = []
        for path in sorted(jobs_root.glob(f"*/{RENDER_DIRECTORY}/{RENDER_MANIFEST}")):
            job_id = path.parents[1].name
            try:
                value = _safe_manifest(path, job_id)
                if value is None:
                    continue
                if value.get("state") == "queued":
                    queued.append(job_id)
                elif value.get("state") == "rendering":
                    partial_name = value.get("partial_filename")
                    if isinstance(partial_name, str):
                        partial = path.parent / partial_name
                        if partial.exists() or partial.is_symlink():
                            move_to_trash(partial)
                    value.update(
                        {
                            "state": "failed",
                            "error": "App 上次關閉時中斷咗字幕影片輸出，請重試",
                            "completed_at": _utc_now(),
                            "cancel_requested": False,
                        }
                    )
                    self.save_status(path.parents[1], value)
                    interrupted.append(job_id)
            except Exception:
                continue
        return queued, interrupted


__all__ = [
    "RenderCancelled",
    "SubtitleRenderer",
    "build_render_command",
    "parse_progress_fraction",
    "probe_media",
    "resolve_subtitle_ffmpeg",
    "resolve_subtitle_ffprobe",
    "terminate_owned_process",
    "validate_source_fingerprint",
]
