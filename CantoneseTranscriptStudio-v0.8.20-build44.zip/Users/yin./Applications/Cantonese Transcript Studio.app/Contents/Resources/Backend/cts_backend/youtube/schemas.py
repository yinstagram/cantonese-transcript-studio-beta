"""Strict, serializable contracts for YouTube import planning and artifacts."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import PurePosixPath
from typing import Any, Mapping, Sequence


SCHEMA_VERSION = 1
MAX_REQUEST_URLS = 200
_SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$")
_VIDEO_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
_SHA256_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_LANGUAGE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")


class ArtifactKind(str, Enum):
    VIDEO = "video"
    AUDIO = "audio"
    SUBTITLE_RAW = "subtitle_raw"
    SUBTITLE_NORMALIZED = "subtitle_normalized"


class ArtifactState(str, Enum):
    PLANNED = "planned"
    DOWNLOADING = "downloading"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class SubtitleSource(str, Enum):
    MANUAL = "manual"
    AUTOMATIC = "automatic"
    LOCAL_ASR = "local_asr"


@dataclass(frozen=True)
class SubtitleTrack:
    language: str
    source: SubtitleSource
    extension: str

    def __post_init__(self) -> None:
        language = self.language.strip()
        extension = self.extension.lower().lstrip(".")
        if _LANGUAGE_RE.fullmatch(language) is None:
            raise ValueError("subtitle language 無效")
        if extension not in {"vtt", "srt"}:
            raise ValueError("只支援 VTT／SRT subtitle track")
        object.__setattr__(self, "language", language)
        object.__setattr__(self, "extension", extension)
        if not isinstance(self.source, SubtitleSource):
            object.__setattr__(self, "source", SubtitleSource(str(self.source)))

    def to_dict(self) -> dict[str, str]:
        return {
            "language": self.language,
            "source": self.source.value,
            "extension": self.extension,
        }


@dataclass(frozen=True)
class YouTubeImportRequest:
    urls: tuple[str, ...]
    rights_confirmed: bool
    download_video: bool = True
    download_audio: bool = False
    download_subtitles: bool = True
    allow_playlists: bool = True

    def __post_init__(self) -> None:
        from .urls import YouTubeResourceKind, validate_remote_url

        if isinstance(self.urls, (str, bytes)):
            raise ValueError("YouTube urls 必須係 sequence")
        for name in (
            "rights_confirmed",
            "download_video",
            "download_audio",
            "download_subtitles",
            "allow_playlists",
        ):
            if not isinstance(getattr(self, name), bool):
                raise ValueError(f"{name} 必須係 boolean")
        if not self.rights_confirmed:
            raise ValueError("必須確認有權下載內容")
        if not self.urls or len(self.urls) > MAX_REQUEST_URLS:
            raise ValueError("YouTube URL 數量無效")
        if not (self.download_video or self.download_audio or self.download_subtitles):
            raise ValueError("至少要選擇一種下載 artifact")
        canonical: list[str] = []
        seen: set[str] = set()
        for raw in self.urls:
            parsed = validate_remote_url(raw)
            if isinstance(parsed, str):
                raise ValueError("remote URL 無效")
            if getattr(parsed, "kind", None) is YouTubeResourceKind.PLAYLIST and not self.allow_playlists:
                raise ValueError("今次 request 唔允許 playlist")
            if parsed.canonical_url not in seen:
                seen.add(parsed.canonical_url)
                canonical.append(parsed.canonical_url)
        object.__setattr__(self, "urls", tuple(canonical))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "YouTubeImportRequest":
        raw_urls = value.get("urls")
        if not isinstance(raw_urls, Sequence) or isinstance(raw_urls, (str, bytes)):
            raise ValueError("urls 必須係 list")
        return cls(
            urls=tuple(str(item) for item in raw_urls),
            rights_confirmed=value.get("rights_confirmed") is True,
            download_video=value.get("download_video", True) is True,
            download_audio=value.get("download_audio", False) is True,
            download_subtitles=value.get("download_subtitles", True) is True,
            allow_playlists=value.get("allow_playlists", True) is True,
        )


def _safe_relative_path(value: str | None) -> str | None:
    if value is None:
        return None
    path = PurePosixPath(value)
    if not value or path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError("artifact relative_path 無效")
    return path.as_posix()


@dataclass(frozen=True)
class ArtifactManifest:
    artifact_id: str
    video_id: str
    kind: ArtifactKind
    state: ArtifactState
    created_at: str
    updated_at: str
    relative_path: str | None = None
    size_bytes: int | None = None
    sha256: str | None = None
    subtitle_language: str | None = None
    subtitle_source: SubtitleSource | None = None
    raw_artifact_id: str | None = None
    error_code: str | None = None
    revision: int = 0
    version: int = SCHEMA_VERSION

    def __post_init__(self) -> None:
        if _SAFE_ID_RE.fullmatch(self.artifact_id) is None:
            raise ValueError("artifact_id 無效")
        if _VIDEO_ID_RE.fullmatch(self.video_id) is None:
            raise ValueError("video_id 無效")
        if not isinstance(self.kind, ArtifactKind):
            object.__setattr__(self, "kind", ArtifactKind(str(self.kind)))
        if not isinstance(self.state, ArtifactState):
            object.__setattr__(self, "state", ArtifactState(str(self.state)))
        if self.subtitle_source is not None and not isinstance(self.subtitle_source, SubtitleSource):
            object.__setattr__(self, "subtitle_source", SubtitleSource(str(self.subtitle_source)))
        object.__setattr__(self, "relative_path", _safe_relative_path(self.relative_path))
        if self.size_bytes is not None and self.size_bytes < 0:
            raise ValueError("artifact size_bytes 無效")
        if self.sha256 is not None and _SHA256_RE.fullmatch(self.sha256) is None:
            raise ValueError("artifact sha256 無效")
        if self.raw_artifact_id is not None and _SAFE_ID_RE.fullmatch(self.raw_artifact_id) is None:
            raise ValueError("raw_artifact_id 無效")
        if self.error_code is not None and _SAFE_ID_RE.fullmatch(self.error_code) is None:
            raise ValueError("error_code 無效")
        if self.revision < 0:
            raise ValueError("artifact revision 無效")
        if self.state is ArtifactState.COMPLETED:
            if self.relative_path is None or self.size_bytes is None or self.sha256 is None:
                raise ValueError("completed artifact 必須有 path、size 同 hash")
        subtitle_kinds = {ArtifactKind.SUBTITLE_RAW, ArtifactKind.SUBTITLE_NORMALIZED}
        if self.kind in subtitle_kinds:
            if not self.subtitle_language or self.subtitle_source is None:
                raise ValueError("subtitle artifact 必須有 language 同 source")
        elif any(
            value is not None
            for value in (self.subtitle_language, self.subtitle_source, self.raw_artifact_id)
        ):
            raise ValueError("media artifact 唔可以帶 subtitle fields")
        if self.kind is ArtifactKind.SUBTITLE_RAW and self.raw_artifact_id is not None:
            raise ValueError("raw subtitle 唔可以引用另一個 raw artifact")
        if (
            self.kind is ArtifactKind.SUBTITLE_NORMALIZED
            and self.subtitle_source is not SubtitleSource.LOCAL_ASR
            and self.raw_artifact_id is None
        ):
            raise ValueError("normalized downloaded subtitle 必須引用 raw artifact")

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["kind"] = self.kind.value
        value["state"] = self.state.value
        value["subtitle_source"] = (
            self.subtitle_source.value if self.subtitle_source is not None else None
        )
        return value

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ArtifactManifest":
        return cls(
            artifact_id=str(value["artifact_id"]),
            video_id=str(value["video_id"]),
            kind=ArtifactKind(str(value["kind"])),
            state=ArtifactState(str(value["state"])),
            created_at=str(value["created_at"]),
            updated_at=str(value["updated_at"]),
            relative_path=(str(value["relative_path"]) if value.get("relative_path") else None),
            size_bytes=(int(value["size_bytes"]) if value.get("size_bytes") is not None else None),
            sha256=(str(value["sha256"]) if value.get("sha256") else None),
            subtitle_language=(
                str(value["subtitle_language"]) if value.get("subtitle_language") else None
            ),
            subtitle_source=(
                SubtitleSource(str(value["subtitle_source"]))
                if value.get("subtitle_source")
                else None
            ),
            raw_artifact_id=(str(value["raw_artifact_id"]) if value.get("raw_artifact_id") else None),
            error_code=(str(value["error_code"]) if value.get("error_code") else None),
            revision=int(value.get("revision", 0)),
            version=int(value.get("version", SCHEMA_VERSION)),
        )


@dataclass(frozen=True)
class PlaylistEntryPlan:
    position: int
    total: int
    video_id: str
    canonical_url: str
    display_title: str | None = None


@dataclass(frozen=True)
class PlaylistEntryFailure:
    position: int
    reason: str


@dataclass(frozen=True)
class PlaylistPlan:
    playlist_id: str
    entries: tuple[PlaylistEntryPlan, ...]
    failures: tuple[PlaylistEntryFailure, ...]
    source_count: int
