"""Atomic, fixed-schema persistence for one manifest per downloaded artifact."""

from __future__ import annotations

import json
import hashlib
import os
import re
import tempfile
import threading
from dataclasses import replace
from pathlib import Path
from typing import Any, Mapping

from .schemas import ArtifactManifest, ArtifactState


MAX_MANIFEST_BYTES = 1024 * 1024
_SAFE_ARTIFACT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,95}$")
_ALLOWED_TRANSITIONS = {
    ArtifactState.PLANNED: frozenset(
        {ArtifactState.DOWNLOADING, ArtifactState.FAILED, ArtifactState.CANCELED}
    ),
    ArtifactState.DOWNLOADING: frozenset(
        {ArtifactState.COMPLETED, ArtifactState.FAILED, ArtifactState.CANCELED}
    ),
    ArtifactState.FAILED: frozenset({ArtifactState.DOWNLOADING, ArtifactState.CANCELED}),
    ArtifactState.CANCELED: frozenset({ArtifactState.DOWNLOADING}),
    ArtifactState.COMPLETED: frozenset(),
}


class ManifestError(RuntimeError):
    pass


def _atomic_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    except BaseException:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
        raise


class ArtifactManifestStore:
    """Store manifests without remote URLs, cookies, titles, or raw responses."""

    def __init__(self, workspace: str | Path) -> None:
        root = Path(workspace).expanduser()
        if not root.is_absolute():
            raise ValueError("manifest workspace 必須係 absolute path")
        if root.is_symlink():
            raise ValueError("manifest workspace 唔可以係 symlink")
        self.workspace = root.resolve(strict=False)
        self.root = self.workspace / "artifact-manifests"
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def _path(self, artifact_id: str) -> Path:
        # ArtifactManifest applies the exact identifier contract.  Constructing
        # an inert planned record is safer than duplicating a looser path test.
        if _SAFE_ARTIFACT_ID_RE.fullmatch(artifact_id) is None:
            raise ValueError("artifact_id 無效")
        path = self.root / f"{artifact_id}.json"
        if path.parent != self.root:
            raise ValueError("artifact manifest path 無效")
        return path

    def _validate_artifact_path(self, manifest: ArtifactManifest) -> None:
        if manifest.relative_path is None:
            return
        unresolved = self.workspace / manifest.relative_path
        cursor = self.workspace
        for part in Path(manifest.relative_path).parts:
            cursor /= part
            if cursor.is_symlink():
                raise ManifestError("artifact path 包含不安全 symlink")
        candidate = unresolved.resolve(strict=False)
        try:
            candidate.relative_to(self.workspace)
        except ValueError as exc:
            raise ManifestError("artifact path 超出 workspace") from exc

    def save(
        self,
        manifest: ArtifactManifest,
        *,
        expected_revision: int | None = None,
    ) -> ArtifactManifest:
        self._validate_artifact_path(manifest)
        with self._lock:
            path = self._path(manifest.artifact_id)
            if path.exists():
                current = self._read(path)
                if expected_revision is not None and current.revision != expected_revision:
                    raise ManifestError("artifact manifest revision conflict")
                if manifest.revision <= current.revision:
                    raise ManifestError("artifact manifest revision 必須遞增")
            elif expected_revision is not None:
                raise ManifestError("artifact manifest 唔存在")
            _atomic_json(path, manifest.to_dict())
            return manifest

    def create(self, manifest: ArtifactManifest) -> ArtifactManifest:
        with self._lock:
            path = self._path(manifest.artifact_id)
            if path.exists():
                raise ManifestError("artifact manifest 已存在")
            if manifest.revision != 0:
                raise ManifestError("新 artifact manifest revision 必須係 0")
            self._validate_artifact_path(manifest)
            _atomic_json(path, manifest.to_dict())
            return manifest

    def _read(self, path: Path) -> ArtifactManifest:
        if path.is_symlink() or not path.is_file():
            raise ManifestError("artifact manifest 唔存在或者唔安全")
        if path.stat().st_size > MAX_MANIFEST_BYTES:
            raise ManifestError("artifact manifest 超出大小限制")
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(raw, Mapping):
                raise TypeError("root is not an object")
            manifest = ArtifactManifest.from_dict(raw)
            self._validate_artifact_path(manifest)
            return manifest
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise ManifestError("artifact manifest 已損壞") from exc

    def get(self, artifact_id: str) -> ArtifactManifest:
        with self._lock:
            return self._read(self._path(artifact_id))

    def list(self) -> tuple[ArtifactManifest, ...]:
        with self._lock:
            manifests = [self._read(path) for path in self.root.glob("*.json")]
        return tuple(sorted(manifests, key=lambda item: (item.created_at, item.artifact_id)))

    def verify_completed(self, artifact_id: str) -> Path:
        """Verify a completed artifact before it is published or reused."""

        manifest = self.get(artifact_id)
        if manifest.state is not ArtifactState.COMPLETED or manifest.relative_path is None:
            raise ManifestError("artifact 尚未完成")
        self._validate_artifact_path(manifest)
        path = (self.workspace / manifest.relative_path).resolve(strict=False)
        if path.is_symlink() or not path.is_file():
            raise ManifestError("completed artifact 唔存在或者唔安全")
        stat = path.stat()
        if stat.st_size != manifest.size_bytes:
            raise ManifestError("completed artifact size 唔一致")
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            while block := handle.read(1024 * 1024):
                digest.update(block)
        if f"sha256:{digest.hexdigest()}" != manifest.sha256:
            raise ManifestError("completed artifact hash 唔一致")
        return path

    def transition(
        self,
        artifact_id: str,
        state: ArtifactState,
        *,
        updated_at: str,
        relative_path: str | None = None,
        size_bytes: int | None = None,
        sha256: str | None = None,
        error_code: str | None = None,
    ) -> ArtifactManifest:
        if not isinstance(state, ArtifactState):
            state = ArtifactState(str(state))
        with self._lock:
            current = self._read(self._path(artifact_id))
            if state not in _ALLOWED_TRANSITIONS[current.state]:
                raise ManifestError(f"非法 artifact state transition：{current.state.value} → {state.value}")
            updated = replace(
                current,
                state=state,
                updated_at=updated_at,
                relative_path=relative_path,
                size_bytes=size_bytes,
                sha256=sha256,
                error_code=error_code,
                revision=current.revision + 1,
            )
            self._validate_artifact_path(updated)
            _atomic_json(self._path(artifact_id), updated.to_dict())
            return updated
