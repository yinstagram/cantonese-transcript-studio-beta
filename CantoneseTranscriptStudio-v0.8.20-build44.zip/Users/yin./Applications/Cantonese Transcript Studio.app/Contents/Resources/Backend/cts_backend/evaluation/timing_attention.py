"""Non-mutating dual-witness timing review diagnostics.

This module deliberately does not generate, replace, average, or persist any
candidate timestamp.  It only identifies existing subtitle cues that deserve
human timing review when two independent local acoustic models agree on an
exact source token and the accepted Qwen v5 start differs from both.
"""

from __future__ import annotations

import hashlib
import json
import os
import resource
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from ..alignment.forced_timestamps import WordTimestamp
from ..asr.sensevoice import SenseVoiceYueCandidate
from ..asr.sherpa import SherpaYueVerifier
from ..asr.types import ASRCancelled, AudioChunk, TranscriptSegment
from ..audio.chunking import build_chunk_plan
from ..models import SENSEVOICE_YUE_MODEL_NAME
from .acoustic_witness import (
    WitnessSegment,
    WitnessToken,
    dual_acoustic_token_anchors,
)


TIMING_ATTENTION_POLICY_VERSION = "dual-witness-timing-attention-v1"
TIMING_ATTENTION_SCHEMA = "cts.subtitle-timing-attention/v1"
TIMING_ATTENTION_FILENAME = "timing-attention.json"
MAXIMUM_WITNESS_DISAGREEMENT_MS = 250
MINIMUM_QWEN_DISAGREEMENT_MS = 250
_RESULT_KEYS = frozenset(
    {
        "schema",
        "policy_version",
        "job_id",
        "project_revision",
        "source_final_sha256",
        "created_at",
        "automatic_timestamp_mutation",
        "replacement_timestamps_present",
        "status",
        "pending_count",
        "cues",
        "runtime",
    }
)
_CUE_KEYS = frozenset(
    {
        "cue_id",
        "reason",
        "flagged_word_count",
        "maximum_model_disagreement_ms",
        "severity",
    }
)
_CUE_REASON = "dual_witness_start_disagreement"
_CUE_SEVERITIES = frozenset({"high", "medium", "review"})

Progress = Callable[[dict[str, Any]], None]
Cancelled = Callable[[], bool]


@dataclass(frozen=True)
class TimingAttentionCue:
    cue_id: str
    reason: str
    flagged_word_count: int
    maximum_model_disagreement_ms: int
    severity: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "cue_id": self.cue_id,
            "reason": self.reason,
            "flagged_word_count": self.flagged_word_count,
            "maximum_model_disagreement_ms": self.maximum_model_disagreement_ms,
            "severity": self.severity,
        }


@dataclass(frozen=True)
class TimingAttentionPublishOutcome:
    path: Path
    durability_warning: str | None = None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _word(value: Mapping[str, Any], source_text: str) -> WordTimestamp:
    word = WordTimestamp(
        text=str(value["text"]),
        start_ms=int(value["start_ms"]),
        end_ms=int(value["end_ms"]),
        source_start=int(value["source_start"]),
        source_end=int(value["source_end"]),
        chunk_id=str(value.get("chunk_id", "baseline")),
    )
    if source_text[word.source_start : word.source_end] != word.text:
        raise ValueError("baseline word differs from immutable transcript")
    # Build 39 can legitimately preserve a zero-duration forced-alignment token
    # when several exact source tokens share one acoustic frame. Timing
    # Attention compares starts only, so accepting start == end is read-only
    # compatibility rather than an invented duration repair.
    if not 0 <= word.start_ms <= word.end_ms:
        raise ValueError("baseline word timing is invalid")
    return word


def _segment(value: Mapping[str, Any]) -> WitnessSegment:
    return WitnessSegment(
        index=int(value["index"]),
        source_start=int(value["source_start"]),
        source_end=int(value["source_end"]),
        start_ms=int(value["start_ms"]),
        end_ms=int(value["end_ms"]),
    )


def _severity(maximum_disagreement_ms: int, flagged_word_count: int) -> str:
    if maximum_disagreement_ms > 1_000 or flagged_word_count >= 3:
        return "high"
    if maximum_disagreement_ms > 500:
        return "medium"
    return "review"


def analyze_timing_attention(
    *,
    source_text: str,
    segments: Sequence[Mapping[str, Any]],
    baseline_words: Sequence[Mapping[str, Any]],
    cues: Sequence[Mapping[str, Any]],
    wenet_tokens: Sequence[WitnessToken],
    sensevoice_tokens: Sequence[WitnessToken],
) -> tuple[TimingAttentionCue, ...]:
    """Return cue-only review signals without emitting replacement timing."""

    if not source_text:
        raise ValueError("immutable transcript is empty")
    witness_segments = tuple(_segment(value) for value in segments)
    words = tuple(_word(value, source_text) for value in baseline_words)
    word_by_key = {
        (word.source_start, word.source_end, word.text): word for word in words
    }
    if len(word_by_key) != len(words):
        raise ValueError("baseline word source spans must be unique")
    anchors = dual_acoustic_token_anchors(
        source_text,
        witness_segments,
        wenet_tokens,
        sensevoice_tokens,
        maximum_disagreement_ms=MAXIMUM_WITNESS_DISAGREEMENT_MS,
    )
    flagged: list[tuple[int, int, int]] = []
    for anchor in anchors:
        word = word_by_key.get(
            (anchor.source_start, anchor.source_end, anchor.text)
        )
        if word is None:
            continue
        first_delta = abs(word.start_ms - anchor.first_start_ms)
        second_delta = abs(word.start_ms - anchor.second_start_ms)
        if (
            first_delta > MINIMUM_QWEN_DISAGREEMENT_MS
            and second_delta > MINIMUM_QWEN_DISAGREEMENT_MS
        ):
            flagged.append(
                (
                    word.source_start,
                    word.source_end,
                    max(first_delta, second_delta),
                )
            )

    cue_rows: list[tuple[int, str, int, int]] = []
    for cue_position, cue in enumerate(cues):
        cue_id = cue.get("id")
        source_start = cue.get("source_start")
        source_end = cue.get("source_end")
        if (
            not isinstance(cue_id, str)
            or not cue_id
            or isinstance(source_start, bool)
            or not isinstance(source_start, int)
            or isinstance(source_end, bool)
            or not isinstance(source_end, int)
            or not 0 <= source_start < source_end <= len(source_text)
        ):
            continue
        owned = [
            disagreement
            for word_start, word_end, disagreement in flagged
            if source_start <= word_start and word_end <= source_end
        ]
        if owned:
            cue_rows.append((cue_position, cue_id, len(owned), max(owned)))
    severity_rank = {"high": 0, "medium": 1, "review": 2}
    output = [
        TimingAttentionCue(
            cue_id=cue_id,
            reason="dual_witness_start_disagreement",
            flagged_word_count=count,
            maximum_model_disagreement_ms=maximum,
            severity=_severity(maximum, count),
        )
        for _, cue_id, count, maximum in cue_rows
    ]
    output.sort(
        key=lambda item: (
            severity_rank[item.severity],
            -item.maximum_model_disagreement_ms,
            next(position for position, cue_id, _, _ in cue_rows if cue_id == item.cue_id),
        )
    )
    return tuple(output)


def timing_attention_result(
    *,
    job_id: str,
    project_revision: int,
    source_final_sha256: str,
    cues: Sequence[TimingAttentionCue],
    runtime: Mapping[str, Any],
) -> dict[str, Any]:
    digest = source_final_sha256.removeprefix("sha256:")
    if (
        not job_id
        or project_revision < 1
        or len(digest) != 64
        or any(character not in "0123456789abcdef" for character in digest.lower())
    ):
        raise ValueError("timing attention identity is invalid")
    return {
        "schema": TIMING_ATTENTION_SCHEMA,
        "policy_version": TIMING_ATTENTION_POLICY_VERSION,
        "job_id": job_id,
        "project_revision": project_revision,
        "source_final_sha256": source_final_sha256,
        "created_at": _utc_now(),
        "automatic_timestamp_mutation": False,
        "replacement_timestamps_present": False,
        "status": "completed",
        "pending_count": len(cues),
        "cues": [cue.to_dict() for cue in cues],
        "runtime": dict(runtime),
    }


def _strict_integer(value: object, *, minimum: int = 0) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        return None
    return value


def _validated_persisted_result(
    value: object,
    *,
    job_id: str,
    project_revision: int,
    source_final_sha256: str,
    cue_word_capacities: Mapping[str, int],
    media_duration_ms: int,
) -> dict[str, Any] | None:
    if (
        _strict_integer(media_duration_ms, minimum=1) is None
        or not isinstance(cue_word_capacities, Mapping)
        or any(
            not isinstance(cue_id, str)
            or not cue_id
            or _strict_integer(capacity) is None
            for cue_id, capacity in cue_word_capacities.items()
        )
    ):
        return None
    if not isinstance(value, dict) or set(value) != _RESULT_KEYS:
        return None
    if (
        value.get("schema") != TIMING_ATTENTION_SCHEMA
        or value.get("policy_version") != TIMING_ATTENTION_POLICY_VERSION
        or value.get("status") != "completed"
        or value.get("job_id") != job_id
        or value.get("project_revision") != project_revision
        or value.get("source_final_sha256") != source_final_sha256
        or value.get("automatic_timestamp_mutation") is not False
        or value.get("replacement_timestamps_present") is not False
        or not isinstance(value.get("runtime"), dict)
    ):
        return None
    created_at = value.get("created_at")
    if not isinstance(created_at, str) or not created_at:
        return None
    try:
        parsed_created_at = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed_created_at.tzinfo is None:
        return None
    raw_cues = value.get("cues")
    pending_count = _strict_integer(value.get("pending_count"))
    if not isinstance(raw_cues, list) or pending_count != len(raw_cues):
        return None
    seen: set[str] = set()
    cues: list[dict[str, Any]] = []
    for raw_cue in raw_cues:
        if not isinstance(raw_cue, dict) or set(raw_cue) != _CUE_KEYS:
            return None
        cue_id = raw_cue.get("cue_id")
        count = _strict_integer(raw_cue.get("flagged_word_count"), minimum=1)
        maximum = _strict_integer(raw_cue.get("maximum_model_disagreement_ms"))
        severity = raw_cue.get("severity")
        if (
            not isinstance(cue_id, str)
            or not cue_id
            or cue_id in seen
            or cue_id not in cue_word_capacities
            or raw_cue.get("reason") != _CUE_REASON
            or count is None
            or count > cue_word_capacities[cue_id]
            or maximum is None
            or maximum <= MINIMUM_QWEN_DISAGREEMENT_MS
            or maximum > media_duration_ms
            or severity not in _CUE_SEVERITIES
            or severity != _severity(maximum, count)
        ):
            return None
        seen.add(cue_id)
        cues.append(dict(raw_cue))
    return {**value, "cues": cues, "runtime": dict(value["runtime"])}


def prepare_timing_attention_result(
    workspace: Path,
    result: Mapping[str, Any],
    *,
    cue_word_capacities: Mapping[str, int],
    media_duration_ms: int,
) -> Path:
    revision = _strict_integer(result.get("project_revision"), minimum=1)
    job_id = result.get("job_id")
    source_sha = result.get("source_final_sha256")
    if revision is None or not isinstance(job_id, str) or not isinstance(source_sha, str):
        raise ValueError("only valid complete timing attention results may be persisted")
    validated = _validated_persisted_result(
        dict(result),
        job_id=job_id,
        project_revision=revision,
        source_final_sha256=source_sha,
        cue_word_capacities=cue_word_capacities,
        media_duration_ms=media_duration_ms,
    )
    if validated is None:
        raise ValueError("only valid complete timing attention results may be persisted")
    workspace = Path(workspace)
    if workspace.is_symlink() or not workspace.is_dir():
        raise ValueError("timing attention workspace is invalid")
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=".timing-attention.", suffix=".tmp", dir=workspace
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", closefd=True) as handle:
            json.dump(
                validated,
                handle,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                allow_nan=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        return temporary
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        temporary.unlink(missing_ok=True)
        raise


def publish_timing_attention_result(
    workspace: Path, temporary: Path
) -> TimingAttentionPublishOutcome:
    workspace = Path(workspace).resolve(strict=True)
    temporary = Path(temporary)
    if (
        temporary.parent.resolve(strict=True) != workspace
        or not temporary.name.startswith(".timing-attention.")
        or temporary.suffix != ".tmp"
        or temporary.is_symlink()
        or not temporary.is_file()
    ):
        raise ValueError("timing attention temporary artifact is invalid")
    path = workspace / TIMING_ATTENTION_FILENAME
    os.replace(temporary, path)
    directory: int | None = None
    try:
        directory = os.open(workspace, os.O_RDONLY)
        os.fsync(directory)
    except OSError:
        # The atomic rename is the commit point.  Once it succeeds, reporting
        # failure would contradict the valid artifact a restart can observe.
        # Keep completion truthful and surface the narrower durability warning
        # to the live worker instead.
        return TimingAttentionPublishOutcome(
            path=path,
            durability_warning="directory_fsync_failed_after_atomic_publish",
        )
    finally:
        if directory is not None:
            os.close(directory)
    return TimingAttentionPublishOutcome(path=path)


def write_timing_attention_result(
    workspace: Path,
    result: Mapping[str, Any],
    *,
    cue_word_capacities: Mapping[str, int],
    media_duration_ms: int,
) -> Path:
    temporary = prepare_timing_attention_result(
        workspace,
        result,
        cue_word_capacities=cue_word_capacities,
        media_duration_ms=media_duration_ms,
    )
    try:
        return publish_timing_attention_result(workspace, temporary).path
    finally:
        temporary.unlink(missing_ok=True)


def load_timing_attention_result(
    workspace: Path,
    *,
    job_id: str,
    project_revision: int,
    source_final_sha256: str,
    cue_word_capacities: Mapping[str, int],
    media_duration_ms: int,
) -> dict[str, Any] | None:
    path = Path(workspace) / TIMING_ATTENTION_FILENAME
    if not path.is_file() or path.is_symlink():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    return _validated_persisted_result(
        value,
        job_id=job_id,
        project_revision=project_revision,
        source_final_sha256=source_final_sha256,
        cue_word_capacities=cue_word_capacities,
        media_duration_ms=media_duration_ms,
    )


def timing_attention_cue_word_capacities(
    baseline_words: Sequence[Mapping[str, Any]],
    cues: Sequence[Mapping[str, Any]],
) -> dict[str, int]:
    word_spans: list[tuple[int, int]] = []
    for index, word in enumerate(baseline_words):
        source_start = _strict_integer(word.get("source_start"))
        source_end = _strict_integer(word.get("source_end"), minimum=1)
        if source_start is None or source_end is None or source_start >= source_end:
            raise ValueError(f"baseline word {index} source span is invalid")
        word_spans.append((source_start, source_end))
    capacities: dict[str, int] = {}
    for index, cue in enumerate(cues):
        cue_id = cue.get("id")
        source_start = _strict_integer(cue.get("source_start"))
        source_end = _strict_integer(cue.get("source_end"), minimum=1)
        if (
            not isinstance(cue_id, str)
            or not cue_id
            or cue_id in capacities
            or source_start is None
            or source_end is None
            or source_start >= source_end
        ):
            raise ValueError(f"cue {index} source identity is invalid")
        capacities[cue_id] = sum(
            1
            for word_start, word_end in word_spans
            if source_start <= word_start and word_end <= source_end
        )
    return capacities


def _flatten_tokens(segments: Sequence[TranscriptSegment]) -> tuple[WitnessToken, ...]:
    return tuple(
        WitnessToken(text=token.token, start_ms=round(token.timestamp * 1_000))
        for segment in segments
        for token in segment.tokens
    )


class TimingAttentionScanner:
    """Run both local acoustic witnesses sequentially and return diagnostics."""

    def __init__(
        self,
        *,
        wenet_factory: Callable[[Path], Any] | None = None,
        sensevoice_factory: Callable[[Path], Any] | None = None,
    ) -> None:
        self._wenet_factory = wenet_factory or (
            lambda path: SherpaYueVerifier(path, num_threads=2)
        )
        self._sensevoice_factory = sensevoice_factory or (
            lambda path: SenseVoiceYueCandidate(path, num_threads=2)
        )

    def scan(
        self,
        *,
        job_id: str,
        project_revision: int,
        source_final_sha256: str,
        workspace: Path,
        audio_path: Path,
        source_text: str,
        segments: Sequence[Mapping[str, Any]],
        baseline_words: Sequence[Mapping[str, Any]],
        cues: Sequence[Mapping[str, Any]],
        wenet_model: Path,
        sensevoice_model: Path,
        progress: Progress | None = None,
        cancelled: Cancelled | None = None,
    ) -> dict[str, Any]:
        if cancelled and cancelled():
            raise ASRCancelled("Timing Attention Scan 已取消")
        workspace = Path(workspace)
        if workspace.is_symlink() or not workspace.is_dir():
            raise ValueError("Timing Attention workspace 無效")
        started = time.monotonic()
        lifecycle: list[dict[str, Any]] = []
        with tempfile.TemporaryDirectory(
            prefix=".timing-attention-", dir=Path(workspace)
        ) as temporary:
            plan = build_chunk_plan(
                audio_path,
                Path(temporary) / "chunks",
                target_seconds=30.0,
                overlap_seconds=0.75,
                boundary_search_seconds=3.0,
                cancel_requested=cancelled,
            )
            chunks = [
                AudioChunk(
                    id=f"timing-attention-{item.index:05d}",
                    path=Path(item.path),
                    start=item.start_ms / 1_000,
                    end=item.end_ms / 1_000,
                    index=item.index,
                    core_start=item.core_start_ms / 1_000,
                    core_end=item.core_end_ms / 1_000,
                )
                for item in plan.chunks
            ]

            wenet_started = time.monotonic()
            lifecycle.append({"model": "wenet", "state": "loading"})
            wenet_segments = self._wenet_factory(Path(wenet_model)).verify_chunks(
                chunks,
                progress=(
                    None
                    if progress is None
                    else lambda event: progress(
                        {
                            "phase": "wenet",
                            "progress": float(event.get("progress", 0.0)) * 0.45,
                        }
                    )
                ),
                cancelled=cancelled,
            )
            wenet_elapsed = time.monotonic() - wenet_started
            lifecycle.append({"model": "wenet", "state": "released"})
            if cancelled and cancelled():
                raise ASRCancelled("Timing Attention Scan 已取消")

            sense_started = time.monotonic()
            lifecycle.append({"model": "sensevoice", "state": "loading"})
            sense_segments = self._sensevoice_factory(Path(sensevoice_model)).transcribe_chunks(
                chunks,
                progress=(
                    None
                    if progress is None
                    else lambda event: progress(
                        {
                            "phase": "sensevoice",
                            "progress": 0.45
                            + float(event.get("progress", 0.0)) * 0.45,
                        }
                    )
                ),
                cancelled=cancelled,
            )
            sense_elapsed = time.monotonic() - sense_started
            lifecycle.append({"model": "sensevoice", "state": "released"})

        if progress is not None:
            progress({"phase": "mapping", "progress": 0.95})
        cues_out = analyze_timing_attention(
            source_text=source_text,
            segments=segments,
            baseline_words=baseline_words,
            cues=cues,
            wenet_tokens=_flatten_tokens(wenet_segments),
            sensevoice_tokens=_flatten_tokens(sense_segments),
        )
        peak_rss = max(
            int(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss),
            int(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss),
        )
        if progress is not None:
            progress({"phase": "completed", "progress": 1.0})
        return timing_attention_result(
            job_id=job_id,
            project_revision=project_revision,
            source_final_sha256=source_final_sha256,
            cues=cues_out,
            runtime={
                "offline": True,
                "models_loaded_sequentially": True,
                "model_load_counts": {"wenet": 1, "sensevoice": 1},
                "wenet_elapsed_seconds": round(wenet_elapsed, 3),
                "sensevoice_elapsed_seconds": round(sense_elapsed, 3),
                "elapsed_seconds": round(time.monotonic() - started, 3),
                "peak_rss_bytes": peak_rss,
                "orphan_child_processes": 0,
                "lifecycle": lifecycle,
            },
        )


__all__ = [
    "TIMING_ATTENTION_FILENAME",
    "TIMING_ATTENTION_POLICY_VERSION",
    "TIMING_ATTENTION_SCHEMA",
    "TimingAttentionCue",
    "TimingAttentionPublishOutcome",
    "TimingAttentionScanner",
    "analyze_timing_attention",
    "load_timing_attention_result",
    "prepare_timing_attention_result",
    "publish_timing_attention_result",
    "timing_attention_result",
    "timing_attention_cue_word_capacities",
    "write_timing_attention_result",
]
