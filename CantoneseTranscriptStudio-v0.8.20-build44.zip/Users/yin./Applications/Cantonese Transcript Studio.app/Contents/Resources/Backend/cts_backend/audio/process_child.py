"""Private parent-death wrapper for local media subprocesses.

The backend supervisor starts this module in a fresh session.  FFmpeg or
ffprobe then joins the wrapper's process group, allowing one bounded group
signal to reach the entire native subprocess tree.  If the backend disappears
without running its cleanup path, the watcher kills that isolated group.
"""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    return parser


def _watch_parent(expected_parent_pid: int, stop: threading.Event) -> None:
    while not stop.wait(0.10):
        if os.getppid() != expected_parent_pid:
            os.killpg(os.getpgrp(), signal.SIGKILL)
            os._exit(73)


def _group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _cleanup_group_after_owner_exit(
    *, process_group_id: int, owner_fd: int, grace_seconds: float
) -> int:
    """Independent guardian used to close the leader-exit/parent-death race."""

    if (
        process_group_id <= 1
        or process_group_id in {os.getpid(), os.getpgrp()}
        or owner_fd < 3
    ):
        return 64
    try:
        while os.read(owner_fd, 1):
            pass
    except OSError:
        pass
    finally:
        try:
            os.close(owner_fd)
        except OSError:
            pass
    # Give the live backend supervisor one poll interval to observe that the
    # leader exited while the group is still occupied.  It can then return a
    # truthful non-zero status; this independent guardian remains the fallback
    # when that backend died too.
    handoff_deadline = time.monotonic() + 1.25
    while time.monotonic() < handoff_deadline:
        if not _group_exists(process_group_id):
            return 0
        time.sleep(0.05)
    try:
        os.killpg(process_group_id, signal.SIGTERM)
    except (ProcessLookupError, PermissionError):
        return 0
    deadline = time.monotonic() + min(2.0, max(0.05, grace_seconds))
    while time.monotonic() < deadline:
        if not _group_exists(process_group_id):
            return 0
        time.sleep(0.02)
    try:
        os.killpg(process_group_id, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass
    return 0


def _start_group_guardian(process_group_id: int) -> int:
    owner_read, owner_write = os.pipe()
    try:
        subprocess.Popen(
            [
                sys.executable,
                str(Path(__file__)),
                "--watch-process-group",
                str(process_group_id),
                "--owner-fd",
                str(owner_read),
                "--grace-seconds",
                "0.5",
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            pass_fds=(owner_read,),
            start_new_session=True,
            shell=False,
        )
    except BaseException:
        os.close(owner_read)
        os.close(owner_write)
        raise
    os.close(owner_read)
    # Intentionally keep this descriptor open.  The independent guardian gets
    # EOF only after this wrapper exits, including SIGKILL and interpreter
    # crashes, and can then clean the exact old process group.
    return owner_write


def main(argv: list[str] | None = None) -> int:
    raw_arguments = list(sys.argv[1:] if argv is None else argv)
    if raw_arguments and raw_arguments[0] == "--watch-process-group":
        guardian = argparse.ArgumentParser(add_help=False)
        guardian.add_argument("--watch-process-group", type=int, required=True)
        guardian.add_argument("--owner-fd", type=int, required=True)
        guardian.add_argument("--grace-seconds", type=float, default=0.5)
        parsed = guardian.parse_args(raw_arguments)
        return _cleanup_group_after_owner_exit(
            process_group_id=parsed.watch_process_group,
            owner_fd=parsed.owner_fd,
            grace_seconds=parsed.grace_seconds,
        )
    arguments = _parser().parse_args(raw_arguments)
    command = list(arguments.command)
    if command and command[0] == "--":
        command.pop(0)
    if (
        arguments.parent_pid <= 1
        or not command
        or any(not isinstance(item, str) or not item or "\x00" in item for item in command)
    ):
        return 64
    if os.getsid(0) != os.getpid() or os.getpgrp() != os.getpid():
        # The media supervisor promises start_new_session=True.  Refuse to run
        # if a group signal could target an unrelated process.
        return 64
    if os.getppid() != arguments.parent_pid:
        return 73

    try:
        _owner_write_fd = _start_group_guardian(os.getpgrp())
    except OSError:
        return 69

    stop = threading.Event()
    watcher = threading.Thread(
        target=_watch_parent,
        args=(arguments.parent_pid, stop),
        name="media-parent-watch",
        daemon=True,
    )
    watcher.start()
    try:
        child = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            close_fds=True,
            start_new_session=False,
            shell=False,
        )
        return child.wait()
    except OSError:
        return 69
    finally:
        stop.set()
        watcher.join(timeout=0.5)


if __name__ == "__main__":
    raise SystemExit(main())
