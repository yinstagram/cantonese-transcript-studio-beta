# Cantonese Transcript Studio

一個俾 Apple Silicon Mac 用嘅本地廣東話影片／音訊轉錄 App。用戶喺 Finder 開啟 App、加入一個或多個檔案，再按一次「開始處理」，程式會依次完成：

1. FFmpeg 抽取及統一音訊；
2. Qwen3-ASR 主要轉錄；
3. WenetSpeech-Yue 獨立覆核；
4. deterministic 對齊及保守修正；
5. 可選本機 speaker diarization：自動／最多 4 人用 Core ML Sortformer，多於 4 人先用 legacy sherpa 分群；結果只係匿名 `Speaker 1`、`Speaker 2`，唔會猜真實姓名；
6. OpenCC `s2hk` 香港繁體轉換；
7. Qwen3 ForcedAligner 將已選定文字對齊到音軌，產生可恢復時間碼；
8. 產生六種輸出：普通 TXT、timestamp TXT、SRT、VTT、JSON、CSV。

設定頁另有 opt-in「模型共識會」高準確模式：Qwen → Whisper Large v3（廣東話 `yue`）→ WenetSpeech-Yue。Qwen保留主模型文字及時間骨架；Whisper同Wenet喺同一個局部位置獨立支持相同補字／修正時，程式會將所有互不衝突嘅共識修訂融合入Qwen骨架，而唔係三揀一。單一secondary model獨有內容只會留喺audit，未有calibrated word-level acoustic evidence前唔會自動補入；兩個secondary同意刪字亦唔會自動刪除語氣詞、粗口或口頭禪。Gemma只可以喺程式預先建立嘅不可變、ASR證據限定candidate ID中揀選，冇權自由改寫或補寫逐字稿。研究、Do's／Don'ts、真錄音 A/B 同限制見 [高準確模式研究](docs/accuracy-mode-research.md)。

本機咪高峰即時字幕用 macOS `AVAudioEngine` 收音，再交俾兩個只綁定 `127.0.0.1` 嘅 `whisper.cpp` server：**Whisper Small（`zh`）只出 provisional partial；Whisper Large-v3（`yue`）先出 final 香港繁體字幕**。普通「即時字幕」固定係純字幕模式，唔會載入 CAM++、分析講者、標示 Speaker 或發出轉人提示。**Lazy Camman** 保持為獨立側欄功能：建立 2–15 人 project 後，App 會逐位要求約 10 秒有效說話、顯示註冊質素；每位完成後返回 project 畫面，只有使用者撳「註冊下一位講者」先開始下一位，未全部註冊就不能開始。Project session 只會比較已註冊嘅本機 CAM++ 聲紋，唔會臨場自創另一個 Speaker；兩個相容 sliding windows 先確認 A→B，畫面以新講者顏色 pulse 兩下並提供 VoiceOver／可選聲音提示。低信心、名單外、太短或含重疊風險嘅聲音會保持 Unknown。Profile 由 Swift 用 Keychain + AES-GCM 加密保存；Python worker 無權讀 Keychain，原始註冊音訊、live PCM 同逐字稿唔會寫入 project store，只有加密聲音特徵會保留。

### Explicit speaker enrollment（最新）

真模型驗收用兩把真人聲、註冊段同測試段 byte-disjoint，順序 `A,A,B,B,A`：三組 protocol 全部 5/5、每組正確 2 次轉人、0 誤報、0 個有效 turn 變 Unknown；production Worker 同時真跑 Whisper Large-v3 + CAM++，逐位註冊、A→B→A、clean stop、加密 snapshot restart、cancel 同私隱清理全部通過。證據：`dist/evidence/lazy-camman-real-human-acceptance-0.8.3-20260826.json`、`dist/evidence/live-project-real-smoke-source-0.8.3-20260826.json`。呢個係可重現嘅本機 real-audio acceptance；實際房間咪高峰、WhatsApp speaker playback、相似聲線同多人同時講嘢仍要做人手 field check，亦唔應稱為真人身份認證。

> 本機檔案轉錄、整理、編輯同 burn-in 唔會上載原檔或逐字稿，亦冇 analytics／telemetry。只係用戶主動下載模型，或主動提供公開影片 URL 匯入時，先會連線到對應上游服務。

> **網站分發狀態：目前只係 Yin 呢部 Mac 嘅本機 build，唔可以將現有 `.app`／ZIP 原封不動放上網站俾朋友下載。** Docker 亦唔係普通朋友版嘅解法；下一個 distribution 目標係 Aiko-like self-contained native `.app`／DMG。完整原因見 [Aiko／Docker 研究](docs/aiko-native-distribution-research.md) 同 [release gate](docs/distribution.md)。

## 目前狀態

**FACT（100%）**：截至 2026-08-29，已安裝本機版係 `0.8.12 (36)`；candidate同installed嘅105-file canonical inventory SHA-256一致（`2712db20bada8575fc8c6ec5cfc14014dfa7e49557eb2012bce9c8d3a4b50dae`），strict ad-hoc signature通過。Backend regression係 `938 passed`、1個 environment-gated skip、0 failed；Swift Testing係 `165/165 passed`。Installed bundle真實完成Qwen3-ASR 1.7B → Whisper Large-v3 → WenetSpeech-Yue → bounded Gemma 4 12B arbiter → OpenCC → ForcedAligner →六種exports，並重開worker讀回同一completed job；15/15媒體格式抽音、YouTube人工zh-HK字幕六種export、本機雙語翻譯及兩款burn-in亦已通過。Build36修正咗完成job因timestamp checkpoint未重新seal而每次啟動被誤排入queue嘅P0；第二次restart response入面target仍completed，獨立before／after metadata SHA-256一致。完整證據索引見`dist/adversarial-audit/adversarial-audit-build36-final.json`。

**BOUNDARY（100%）**：Installed Build36核心local-beta flow已通過：native file picker一次multi-select 4檔、只啟動一次Start，第2檔故意失敗後第3／4檔仍按FIFO完成，每個有效job有六種verified exports；Yin亦確認普通匯入／處理順暢及本地summary有用。Current-build右鍵移除／Clear All、現場咪高峰／WhatsApp playback、human-gold ASR、兩小時真模型wall-clock、36GB+ routing同網站分發仍係獨立gate；公開分發維持 **HOLD**。Build37 source加入逐片語evidence fusion，未安裝／未真模型驗收前唔會冒充Build36 installed evidence。

**FACT（100%）**：截至 2026-08-27，已安裝本機版係 `0.8.9 (32)`。Build32 candidate regression 為 backend `903 passed`、1 個 environment-gated skip、0 failed；Swift `154 passed`、0 failed。已安裝 App 真實完成 M4A + MP4 兩檔 FIFO batch：Qwen3-ASR 1.7B Q8／MLX GPU、Whisper Large-v3、WenetSpeech-Yue、OpenCC `s2hk`、ForcedAligner 同六種輸出全部完成，兩個來源檔保持不變。Build32 亦真實完成 77/77 段本機翻譯、local insights、公開 YouTube 字幕六種輸出及 M4A 下載、兩款 burn-in、5:48 雙人錄音 Sortformer 分段，以及受控真音訊嘅即時字幕／Lazy Camman。呢啲證據唔會冒充 fresh Finder 實體拖放、現場咪高峰、36GB+ 27B 或 clean-Mac 公開發行驗收。

**FACT（100%）**：2026-08-26 新增嘅 P0 本機 AI 整理同雙語字幕已用一個已完成真 job（`t1.mp4`、148.116 秒）跑通：Gemma 4 12B 產生有證據 segment ID 嘅 Summary、Points、Actions、Chapters 同 Concepts，再產生 31 段 cue-aligned 英文翻譯，並輸出雙語 SRT／VTT／ASS 及譯文 timestamp TXT；重開 worker 後兩份 derived state 仍然可回復，`final.json` 沒有被改寫。同日在這部 16 GiB Mac 實測 `Qwen3.8-27B-Q2_K.gguf`（11,839,440,480 bytes）：Metal 在三種 offload／context 設定下都於第一個真 request OOM，所以它不會取代現時可完成工作嘅 Gemma 12B；完整比較見 [Qwen3.8-27B 16GB 實測決策](docs/research/qwen38-27b-16gb-benchmark-20260826.md)。普通即時字幕係純字幕模式，獨立 Lazy Camman 支援 2–15 人逐位聲紋註冊、每位完成後手動確認下一位、closed-roster matching 同 pre-ASR switch cue。

**HISTORICAL**：截至 2026-08-09，`0.8.1 (11)` 係早期 Lazy Camman V2 beta build。Build32 已喺同一部 Mac／同一 Keychain generation 安裝並保留 84 Jobs、15 Models、3 speaker profiles 同3個公開影片 imports；呢個只證明同機 update preservation，唔證明跨機／網站版 migration。早前十分鐘 ASR／Aiko比較仍然冇人工 gold transcript，所以唔宣稱 WER／CER winner；Qwen 仍係保守、deterministic transcript backbone。網站公開版同 model／runtime license chain review維持 **HOLD**。1.7B loader performance cliff嘅歷史真實證據見 [performance doctor](docs/performance-doctor-2026-08-05.md)。

| 驗證項目 | 狀態 | 證據 |
|---|---:|---|
| Build36 final automated regression | 通過 | Backend `938 passed, 1 skipped, 0 failed`；Swift Testing `165/165 passed`。Evidence：`dist/adversarial-audit/tests/backend-build36-after-recovery-fix.xml`、`dist/adversarial-audit/tests/swift-build36/`。 |
| Build36 installed pipeline／recovery | 真模型通過 | 12秒真錄音完成Qwen 1.7B、Whisper Large-v3、Wenet、Gemma bounded selection、OpenCC、ForcedAligner及六種exports；第二次worker restart 0 startup events、job仍completed、metadata hash不變。Evidence：`dist/adversarial-audit/tests/installed-build36-real-accuracy-gemma-recovery-smoke.json`、`dist/adversarial-audit/tests/build36-recovery-idempotent-response.jsonl`。 |
| Build36 formats／YouTube／burn-in | 通過／固定fixtures | 15/15格式抽音為16kHz mono；公開YouTube人工zh-HK字幕完成raw／normalized VTT及六種exports；本機Gemma翻譯後雙語／純譯文burn-in同speaker-specific style已抽frame視覺核對。Evidence：`dist/adversarial-audit/tests/installed-build36-media-formats/report.json`、`dist/adversarial-audit/tests/installed-build36-youtube-smoke.json`、`dist/adversarial-audit/tests/installed-build36-real-video-bilingual-burn-smoke.json`。 |
| Build32 automated regression | 通過 | Backend 903 passed + 1 gated skip、0 failed；Swift 154 passed、0 failed。Evidence：`dist/evidence/backend-full-build32-candidate-20260827.xml`、`dist/evidence/swift-testing-run-20260827T100848Z-97695.log`。 |
| Build32 installed batch／格式 | 通過 | File picker 真實加入 M4A + MP4，最大 concurrency 1、FIFO，兩項 completed、六種 exports manifest 全通過；另有15種格式 production probe／extraction 15/15。Evidence：`dist/evidence/installed-ui-batch-build32-20260827.json`、`dist/evidence/media-format-smoke-build32-installed/report.json`。15種格式矩陣唔等於15次完整 ASR。 |
| Build32 translation／insights／burn-in | 真模型通過 | Gemma 4 12B 將真 job 77/77 cues 完成、0 failed；四種雙語輸出、local insights、雙語及純翻譯 burn-in全部通過，`final.json`同來源影片不變。Evidence：`dist/evidence/installed-translation-build32-20260827.json`、`dist/evidence/installed-local-insights-build32-20260827.json`、`dist/evidence/bilingual-burn-build32-installed-20260827.json`。 |
| Build32講者／Live／AI Cue | 通過／bounded | 真5:48雙人電話錄音：Sortformer Core ML 2 speakers／111 turns／3.178秒；受控真廣東話由Large-v3成功輸出final，Small已設定為provisional model，fresh partial emission仍待實體咪高峰驗收；Lazy Camman A→B→A、0 false switch；AI Cue真載入本機Gemma後卸載。未冒充現場咪高峰／WhatsApp field benchmark。 |
| Build32公開影片匯入 | 通過／固定公開 fixtures | IG、Threads、X、Bilibili public metadata/resolver 4/4；YouTube manual zh-HK字幕六種輸出同約25MB M4A真下載完成，無cookies／credentials。Evidence：`dist/evidence/social-metadata-build32-installed-20260827.json`、`dist/evidence/youtube-installed-smoke-build32-report-20260827.json`。 |
| Build32 queue管理 | 通過／右鍵仍要真人點一次 | Shift實機多選3檔、Delete確認後queue=0；「清除全部」實機清走2檔，原檔SHA-256不變。Computer Use未能令SwiftUI Table右鍵menu出現在可讀畫面；右鍵入口本身仍留喺UI code及154個Swift regression內，final field gate要真人點一次。 |
| P0 final automated regression | 通過 | Backend 801 passed、1 real-model-gated skip、0 failed；Swift 128 passed、0 failed。Evidence：`dist/evidence/backend-p0-final-20260826-junit.xml`、`dist/evidence/swift-p0-final-20260826.log`。 |
| P0 本機 AI 整理／雙語字幕 | 真模型通過 | Gemma 4 12B 在 148.116 秒真實 completed job 用 108.145 秒完成 insights、5-cue 真翻譯同專名 probe；真 worker 另完成 31 cues、4 種檔案及 restart read-back。Reports：`dist/evidence/gemma12b-p0-derived-real-smoke-20260826.json` 及 `dist/evidence/p0-derived-worker-real-acceptance-20260826.md`。 |
| Qwen3.8-27B Q2_K／16GB | 拒絕取代 Gemma | Exact 11,839,440,480-byte GGUF 用 llama.cpp 0.3.0 build 10621；full GPU 4K、40-layer 2K 及 auto-fit 4K 都在真 request 出現 Metal `kIOGPUCommandBufferCallbackErrorOutOfMemory`，0 generated tokens。 |
| Current ordinary live captions | 通過／真模型 | `0.8.9 (32)` installed backend 用真廣東話跑 Whisper Large-v3 final；active status 固定 `captions_only`，唔載入講者模型、唔產生 speaker event。UI 只見字幕同可選 AI 提示；Evidence：`dist/evidence/installed-live-captions-only-0.8.9-build32-20260827.json`。 |
| Current Lazy Camman automated regression | 通過 | Build32 backend `903 passed, 1 real-model-gated skipped, 0 failed`；Swift Testing `154 passed, 0 failed`。包括 captions-only 隔離、2–15 人 project、完整 roster、Speaker 15 最後一位註冊、固定顏色／圖示，以及儲存後必須手動撳下一位。Evidence：`dist/evidence/backend-full-build32-candidate-20260827.xml`、`dist/evidence/swift-testing-run-20260827T100848Z-97695.log`。 |
| Current Lazy Camman installed-bundle backend | 通過／受控真音訊；現場仍待真人 | `0.8.9 (32)` installed-bundle backend smoke真跑Whisper Large-v3 + CAM++ exact A→B→A、2次正確轉人、0誤報；另一enrolled short-B smoke只出1次A→B。Evidence：`dist/evidence/installed-lazy-camman-real-e2e-0.8.9-build32-20260827.json`、`dist/evidence/installed-live-speaker-short-candidate-0.8.9-build32-20260827.json`。呢啲唔係SwiftUI／實體咪高峰播放；房間咪高峰、WhatsApp playback、相似聲線同重疊講話仍要真人驗收。 |
| Current Lazy Camman real-human／production Worker | 通過／bounded | 三組 real-human disjoint enrol/eval 均為 `A,A,B,B,A` 5/5、2 true switches、0 false switches；production Worker 真跑兩位順序註冊、Whisper Large-v3 final、CAM++ A→B→A、restart／cancel／privacy cleanup。唔等於實際房間／重疊說話 population benchmark。 |
| Historical Wenet physical-mic end-to-end | 通過／有限 device-flow | 切換到 Whisper pair **之前**，實際咪高峰顯示 final 字幕；named Project 建立、normal stop、App restart、第二次 start 已通過。當時 `0.8.1` 同一 build Keychain／restart／rebuild-protection 驗收見 `dist/evidence/lazy-camman-v2-keynamespace-acceptance-0.8.1.md`。呢個唔係新 Whisper Small／Large-v3 path 的 device-flow acceptance；真實兩人 speaker-switch field evidence 亦尚未完成。 |
| Human-labelled file speaker benchmark | 通過／單一 fixture | 28.647188秒、2位人手標註講者：Sortformer high-context Core ML DER `0.094200`／JER `0.108580`，舊 sherpa known-2 baseline DER `0.320650`／JER `0.590947`；warm helper 1.121秒。只證明同一英語 fixture改善，唔冒充廣東話通用準確度。Report：`dist/evidence/sortformer-coreml-real-smoke-20260807.json` |
| Historical 0.7.0 supplied-audio speaker control | historical，不等於 current mic acceptance | 3.072秒真廣東話：24/24 frames、0 dropped，final `兩隻小企鵝都有嘢食`，final inference 117.338ms；A→B→A control 116/116 frames、0 dropped，A2 返回 Speaker 1（similarity 0.910327）。呢個係 production worker continuity control，唔係多人 DER。Report：`dist/evidence/live-caption-speaker-real-smoke-20260807.md` |
| Historical Wenet Lazy Camman V2 project continuity | 通過／bounded | 切換前真本機 Wenet + 3D-Speaker：named project start → clean stop profile snapshot → restart with snapshot → cancel；3.072 秒 sample、1.4 秒、offline、無 audio／transcript／embedding 寫入。同一 installed build 的 UI Project restart 與 ad-hoc rebuild protection 另有 read-back。Whisper pair 需另跑同一 smoke；A→B 實地 false-switch／missed-switch benchmark 亦尚未完成，唔冒充 identity accuracy。Reports：`dist/evidence/live-project-real-smoke-installed-0.8.1-keynamespace.json`、`dist/evidence/lazy-camman-v2-keynamespace-acceptance-0.8.1.md` |
| Speaker editor／樣式／burn-in | 通過 | 可重新命名、顯示／隱藏名、逐 cue 改派、每位講者文字色／斜體／背景；preview、ASS actor/style、時間碼 TXT／SRT／VTT／JSON／CSV 同 burn-in 都保存 assignment audit。Renderer視覺基線：`/Users/yin./Claude/scratch/cts-subtitle-final-20260806/run-20260806T052822Z-59511/acceptance-report.json` |
| 本機個人修正記憶 | 通過 | 可手動加入 alias、匯入／匯出、逐項刪除、確認後清空、關閉自動學習。成功儲存字幕修改後先學短詞；推斷修正要2次確認先可自動套用，唔會自由重寫。Real RPC evidence：`dist/evidence/correction-memory-real-smoke-20260807.md` |
| Accuracy v4 真完整 pipeline | 通過／真模型短 sample | 3.072秒真廣東話 WAV 已跑 Qwen 1.7B → Whisper Large v3（`yue`）→ WenetSpeech-Yue → deterministic consensus → Sortformer → OpenCC → ForcedAligner → 6 exports。Qwen + Wenet 一致，Gemma按新 deferred policy 正確略過；獨立真 Gemma 12B strict-candidate smoke另行通過。呢個唔係WER／CER winner。 |
| 真 10 分鐘 ASR 比較 | 通過／無 gold | Qwen 529.68 秒、Wenet 28.559、Whisper Large v3 204.54、SenseVoice 19.918、legacy Large v2 161.06。決定保留 Qwen primary、v3 challenger、Wenet verifier；v2只留 legacy。Report：`/Users/yin./Claude/scratch/cts-accuracy-benchmark-20260806/consensus-v3.md` |
| Aiko export comparison | presence signal only | 同一 no-gold redacted report：Aiko Large v2 observed Cantonese forms 97／specified terms 4；Whisper v3 251／7；Qwen 387／6。呢啲係出現次數，唔係 recall、WER 或準確度排名。Report：`/Users/yin./Claude/scratch/cts-accuracy-benchmark-20260806/benchmark-with-aiko.redacted.md` |
| 真 Gemma 自然斷句 | 通過 | Installed App policy v3：revision 9→10、38.875秒、43 cues、最大17 visible characters、最短320ms、under 200ms係0、under 500ms係3、readability merges 4、remaining short 3；3 calls／33個selector IDs、exact text preserved、lexical phrase present且`split=false`。Lifecycle係`server_already_running + loaded → model_unloaded_server_preserved`；後驗server仍喺port 1234運行、loaded model count 0。Report：`/Users/yin./Claude/scratch/cts-accuracy-benchmark-20260806/installed-v0.6.0-semantic-subtitle-smoke.json` |
| Segmentation policy v3 regression | Installed通過 | `timestamp-semantic-dp-v3`將semantic IDs當soft hints，以500ms readability scoring抑制flash，再只喺唔改字、唔超字數上限時安全合併；semantic hint撞正句號或speech pause時會保留較強boundary，lexical-glue gate亦繼續防止已知短語被假pause拆開。Focused semantic／project suite 67 passed。Read-only replay確認3條under-500ms cues全部係完整標點短句；完整超短句可保留。呢啲唔代表一般中文斷詞完美 |
| LM Studio server lifecycle | Installed通過 | Gemma需要loopback server而未運行時，App可自動啟動；release只unload專用Gemma model，**永不執行process-global server stop**。今次真機沿用已運行server，完成load／unload後server保留而loaded model count係0 |
| Export／資源保護修正 | 通過 | CSV formula cells同 SRT／VTT 偽時間軸行會作 format-specific neutralization，JSON／原文字不改；LM Studio query失敗但冇相關 process時不再誤擋1.7B，有 process而狀態不明仍 fail closed |
| Historical 0.7.0 installed App integrity | historical／只限本機 | `0.7.0 (9)`、arm64、macOS 14+；App 同 bundled Sortformer helper會做本機 ad-hoc signing／strict read-back。Signature仍然冇 Team ID，唔等於網站分發簽署 |
| 2 小時 bounded-memory 架構 endurance | 通過 | 7,200 秒、230,400,044-byte PCM16 WAV 建立 300 個 disk chunks；core 連續、原檔 stat 不變；呢個唔等於 2 小時真模型 wall-clock benchmark |
| YouTube 單 URL 真實匯入 | 通過／全矩陣未 live | 82.121 秒獲授權 Creative Commons fixture；mutagen-free `yt-dlp` core + EJS + Deno runtime 喺 16.168 秒完成 video／audio／zh-Hant 自動字幕、raw + normalized caption、6 exports、hash manifests、restart read-back 同 privacy scan；current targeted suite另有 `60 passed`。Playlist、multi-URL batch、人工字幕、無字幕 fallback同 network cancel／resume只完成 deterministic tests，未稱為全 live驗收 |
| 公開分發 audit | HOLD | 2026-08-29對installed `0.8.12 (36)`重跑`--portable-only`：12 PASS／4 FAIL／0 WARN，`RESULT: NOT DISTRIBUTABLE`。Failures係development bundle ID、冇embedded Python、冇bundled FFmpeg／ffprobe、backend仍有external runtime paths。Evidence：`dist/adversarial-audit/tests/installed-build36-portable-audit.log`。 |

## 系統要求

- Apple Silicon Mac（arm64）
- macOS 14 或以上；現有本機 runtime 只喺呢部 Apple Silicon Mac（macOS 26.5.2）完整驗證，對外最低版本仍要等 portable runtime 重建及 clean-Mac smoke先可承諾
- 建議 16GB unified memory
- 現時預設 1.7B + verifier + ForcedAligner + Sortformer + speaker embedding 嘅本機目錄合共約 6.36 GiB；高準確模式加 Whisper 後約 9.24 GiB；再預留原始媒體、disk chunks、preview 同 burn-in 空間
- 首次 bootstrap／model download 需要網絡；之後正常轉錄可離線

呢個 local build 用 SwiftUI + Python 3.12，依賴 Homebrew FFmpeg做音訊準備，同獨立嘅 `ffmpeg-full`／libass做本機字幕 burn-in。bootstrap會一次過安裝及驗證兩者；使用 App 時唔需要開 Terminal，Terminal只用於首次安裝、重建或診斷。

以上只描述現有本機開發環境，**唔係對外發布嘅最低版本承諾**。公開版要先將所有 native runtime 重建／bundle，逐個核對 Mach-O deployment target，再喺乾淨 Apple Silicon Mac 實測；今版 App 同 Sortformer helper嘅 minimum deployment target都係 macOS 14。

## 安裝

喺 project root 執行一次：

```zsh
scripts/bootstrap.sh
```

bootstrap 會建立兩個隔離環境：repo 內 `.venv` 用於開發／測試；實際 App worker 用：

```text
~/Library/Application Support/Cantonese Transcript Studio/Runtime/.venv/
```

預設會下載／驗證目前揀選嘅 primary 同 verifier、跑測試、安裝再開啟 App。只想重建程式而唔下載模型，可用 `scripts/bootstrap.sh --skip-models`；只想避免自動開 App，可另加 `--no-open`。

完成 build 後，App 預設安裝到：

```text
~/Applications/Cantonese Transcript Studio.app
```

如模型稍後先下載，可用 App 首次設定畫面確認下載；亦可執行：

```zsh
scripts/download_models.sh
```

## 日常使用

1. 喺 Finder 開啟 `~/Applications/Cantonese Transcript Studio.app`。
2. 拖放檔案，或者按「選擇檔案」；可一次加入多個檔案。Build32 已真實驗證 file picker；Finder → App 實體拖放今輪自動化未能作實，驗收前要真人再拖一次。
3. 如有需要，展開「人名與專有詞」輸入人名、品牌、地名或英文術語。
4. 按一次「開始轉錄」。M1／16GB 預設會逐個 job 處理，兩個模型亦唔會同時常駐。
5. 喺「逐字稿」搜尋、複製、查看時間段／低信心提示，或者展開進階比對。
6. 按普通 TXT、時間碼 TXT、SRT、VTT、JSON 或 CSV，揀一個位置儲存副本。

### 本機 AI 整理、雙語字幕同快速覆核

1. 完成轉錄後，「逐字稿」會顯示本機 AI 整理卡，可分別揀 Summary、Point form 或行動清單；AI 提示只解釋逐字稿真正提及嘅概念，每項保留 evidence segment IDs。
2. 「編輯字幕」→「翻譯」可揀英文、日文、韓文、法文、德文或西班牙文，以雙語或只顯示譯文 preview，再輸出 timestamp TXT、SRT、VTT 或 ASS。原文一有修改，舊譯文會標示過期而不會被靜默重用。
3. 「樣式」可將字體、顏色、shadow、斜體、背景色塊同字幕位置儲存成 Brand Kit，再套用、改名或刪除自建 preset；內置 preset 不可改寫。
4. Preview 可開 9:16、1:1 或 16:9 social safe-zone guide；guide 只係畫面參考，不會燒入影片。「只看低信心」會帶用戶逐段上一條／下一條覆核，並保留完成進度。

上述所有 AI 請求只允許 literal `127.0.0.1`／`::1`，不跟 redirect，亦沒有 cloud fallback。Insights 同 translation 係可重新產生嘅 derived artifacts，不會覆蓋 ASR `final.json`。16GB Mac 一次只會載入一個 heavy model；轉錄期間不會同時駐留 Gemma。

「設定」入面可以開關「自動標示邊個講嘢」，亦可揀自動或預期講者數。自動／1–4人會先用 FluidAudio high-context Sortformer Core ML CPU+GPU；如本次runtime失敗，App由頭改用本機sherpa CPU。明確多於4人直接用legacy sherpa PyAnnote + CAM++。兩個engine都失敗時字幕仍會完成，但不會作假speaker ID，結果頁會顯示橙色提示。Speaker label會出現喺 segment list、時間碼TXT、SRT、VTT、CSV同JSON；原始turns同engine decision會保留audit。

重要錄音可先到「設定」開啟「模型共識會」。三個ASR順序完成後，程式先將Whisper／Wenet共同支持嘅局部補字或修正融合到Qwen時間骨架；單一模型raw transcript唔會成段覆蓋final。只喺另有三模型專名anchor等immutable evidence candidate而仍要判斷時，App先管理指定 `google/gemma-4-12b-qat` 嘅載入／釋放；答案不合schema、timeout或證據不足時一律保留Qwen骨架並標示低信心。已知有其他 local LLM載入時會喺 Qwen前 fail closed；`lms`查詢失敗／輸出不明只會喺同時偵測到 LM Studio process時阻擋，冇相關 process就唔再誤報記憶體風險。呢個功能借鏡多模型 council，但技術上係 ASR system combination，唔係真正 neural MoE 或 cross-validation。

### 公開影片／音訊／字幕匯入

1. 去「影片下載」貼上單條或多條公開 URL；支援 YouTube、Instagram、Threads、X/Twitter、Bilibili、TikTok、Facebook、Reddit（平台 extractor 容許時）。
2. 揀影片、音訊、字幕或全部；playlist 可展開成每條獨立、可重試嘅 persisted item。
3. 揀人工／自動字幕優先次序；冇適合字幕時，可選擇下載音訊後自動轉入本機 ASR queue。
4. 確認內容係自己擁有、已獲授權或法律容許下載，再按一次「開始匯入」。

公開影片匯入係明確嘅用戶主動連線功能；會向對應平台／CDN 傳送一般下載 request 所需嘅 URL、IP 同 metadata。完成後嘅字幕 normalization、ASR、編輯同 export 仍然喺本機處理。功能唔支援 browser cookies、登入、DRM、私人影片或繞過平台限制；公開可觀看亦唔代表有下載權。Threads 目前由 App 辨認 URL，並以 public-only adapter 嘗試；Bilibili 會優先抓公開 spoken subtitles，`danmaku` 唔會當成字幕；如果平台未提供 media／字幕，會顯示清楚錯誤而唔會使用登入資料。技術邊界見 [YouTube／社交平台匯入決策](docs/youtube-import-research.md)。

### Local API／Apple Shortcuts

設定頁可以 opt-in 開啟只限 `127.0.0.1` 嘅 Local API；App 開住先會監聽，並以每部機獨立 token 保護。API 可由 Apple Shortcuts 自動 create job、poll 完成狀態，再取得 timestamp TXT。完整 endpoint、Shortcut setup 同安全限制見 [docs/local-api.md](docs/local-api.md)。

### 咪高峰即時字幕

1. 去側欄「即時字幕」，按「開始收音」；首次使用按 macOS 提示允許咪高峰。
2. 普通「即時字幕」只會轉錄咪高峰內容；唔會分析邊個講緊嘢、顯示 Speaker、儲存聲紋或發出轉人提示。
3. 如拍攝時需要已註冊講者同轉人提示，改去獨立「Lazy Camman」建立或重開 project。
4. 按「停止」會完成手上嗰句；「取消」會結束session。只有正常停止嘅 named project 會更新加密聲紋資料；Confirmed字幕可一次過複製。

即時字幕固定使用兩個本機 `whisper.cpp` server，唔需要網絡：Whisper Small 用 `zh` 只產生較快嘅 provisional partial；Whisper Large-v3 用 `yue` 產生最終 final，所以唔會將 Small 常見嘅廣東話字形替代當成最終來源。兩個 model 各自喺 session 內長駐、保持 Metal enabled；每個 request 只送到隨機 path 保護嘅 `127.0.0.1` endpoint，短 PCM WAV 用後即刪。WenetSpeech-Yue 只係檔案 pipeline verifier，唔係 live ASR。普通即時字幕完全跳過 CAM++ speaker engine；只有用戶喺 Lazy Camman 明確揀一個完整註冊 project，backend 先會載入講者 model。

### 個人詞庫／修正記憶

「設定」→「個人詞庫」可以加入正確寫法同容易聽錯嘅alias，例如`Antigravity`／`Entigravity`、`IG Reels`／`IG VIOS`，亦可匯入、匯出、逐項刪除或確認後清空。畫面會清楚顯示「自動學習字幕修正」開關：開啟時，只有成功儲存嘅短詞修改先會成為本機證據；關閉後字幕照常保存但唔學習。手動／匯入alias可直接成為bounded replacement，字幕推斷alias要接受兩次先可自動套用；數字／日期／價錢、自由改寫同單一含糊中文字唔會變成全域替換。

### 編輯、預覽及燒入字幕

1. 完成轉錄後，去「逐字稿」按「編輯字幕」。
2. 拖動播放滑桿或底部字幕 timeline；playhead 到達某段時會自動選中，按右邊任何一段亦會精確 seek。
3. 改該段文字、開始／結束時間；App會做overlap保護及revision-safe autosave，重新開App仍會讀返修改。
4. 右邊「講者」可改匿名講者名、決定字幕要唔要顯示名、將單一cue改派另一位講者，並為每位講者設定文字色、斜體同背景色塊。
5. 需要重新整理長句時，設定每段6–60字（預設18），再揀「精準時間」或「自然斷句」；系統會保護專名、英文詞、URL同數字，重排前先要求確認。
6. 右邊切到「樣式」，選3款preset，或自訂字體、大小、文字色、斜體、shadow、背景色塊及底部距離；左邊會即時預覽。講者樣式會疊加喺project style之上。
7. 可將常用樣式儲存為 Brand Kit，開啟 social safe-zone guide，並用低信心 previous／next 只覆核有風險嘅 cue。
8. 「翻譯」可產生雙語／純譯文 preview 同字幕檔；「輸出影片」產生H.264/AAC MP4，進度來自真實encoder，可取消，成功後可直接播放或在Finder顯示。字幕再有修改時，舊影片會標示為舊版本，唔會假裝已包含新內容。

MP4、MOV、M4V 會優先由 AVPlayer 直接播放。MKV、WebM、AVI 等 macOS 不能直播嘅格式，App 會自動在 job workspace 建立本機 H.264/AAC preview proxy，顯示真實進度及取消；原片不會被改動。純音訊可在黑色 canvas 編輯 timing，但不會假裝有影片軌可燒入。

最近用過嘅專有名詞只會存喺本機 `UserDefaults`。佢哋會傳入 Qwen context，亦會喺 OpenCC 階段受保護，但唔代表模型一定會採用。

## 支援格式

| 類型 | 副檔名 |
|---|---|
| 影片 | MP4、MOV、MKV、M4V、AVI、WebM |
| 音訊 | WAV、MP3、M4A、AAC、FLAC、AIFF／AIF、OGG、Opus |

副檔名檢查不分大小寫；實際內容仍會經 ffprobe 驗證。無音軌影片、損壞檔案或格式內容不符會顯示可理解錯誤。原檔只讀，內部音訊會另存為 mono、16kHz、PCM16 WAV。

## 本機資料位置

```text
~/Library/Application Support/Cantonese Transcript Studio/
├── Models/                 # 模型及下載暫存
├── Jobs/<job-id>/          # 每個 job 嘅中間結果及 exports
├── YouTube Imports/<id>/    # 每個 YouTube import、raw／normalized artifacts 及 manifests
├── Logs/worker.log         # 技術 log
├── Runtime/.venv/          # 固定 Python 3.12 runtime
├── Runtime/youtube/deno    # 本機 YouTube JavaScript runtime copy
├── correction-memory.json   # owner-only個人詞庫／修正證據
└── settings.json           # model／worker 設定
```

每個 job workspace 會按進度保存 `job.json`、音訊、disk chunks、`primary.json`、`verifier.json`、`alignment.json`、`diarization.json`、`diarization-turns.json`、`final.json`、`timestamp-chunks.json`、`timestamps.json`、`exports.json` 同 `exports/`；高準確模式另有 `whisper.json` 同逐批 raw whisper.cpp JSON。AI 整理另存 `derived/insights.json`，每種譯文另存 `derived/translation-<language>.json`；雙語及純譯文輸出放喺 `subtitle/translation-exports/`。ForcedAligner同diarization checkpoint會綁定model／helper identity、音訊fingerprint同chosen transcript；無效或被改過嘅checkpoint唔會被靜默信任。開啟字幕editor後會另存`subtitle-project.json`，包括speaker profiles／assignment／style、Brand Kit reference、safe-zone preference 同低信心 review state；`subtitle/`內放preview/render manifest、ASS、logs同版本化MP4。`final.json`永遠唔會因手動改字幕、AI 整理或翻譯而被覆寫。App crash或重新開啟後，worker會根據有效checkpoint排隊續跑；已完成階段唔需要無條件重做。

加入大型媒體時，App 先用檔案大小加開頭／結尾各 4 MiB 建立 bounded quick fingerprint，所以 UI 唔使同步讀完整條片；duration 亦由 AVFoundation 非同步載入。Background runner 正式處理前會計完整 SHA-256、再次核對檔案未變，再 seal 做 canonical content fingerprint；同一內容未清除前唔會重複處理。Batch 入面一個重複或損壞項目只會顯示該項錯誤，其餘檔案照樣加入 queue。清除完成記錄或刪除模型時，App 會移到 macOS Trash，唔會直接永久刪除。

## 模型

| 用途 | 預設／選項 | 約佔空間 |
|---|---|---:|
| Primary | `Qwen/Qwen3-ASR-1.7B`（預設） | 4,703,121,032 bytes（4.380 GiB） |
| 16GB Primary runtime | 同一 `Qwen/Qwen3-ASR-1.7B`；decoder-only MLX Q8、audio encoder FP16 | 2,467,917,821 bytes（2.298 GiB；首次使用由原模型本機產生） |
| Primary fallback | `Qwen/Qwen3-ASR-0.6B` | 1,880,625,121 bytes（1.751 GiB） |
| Verifier | `sherpa-onnx-wenetspeech-yue-u2pp-conformer-ctc-zh-en-cantonese-int8-2025-09-10` | 140,729,992 bytes extracted（tokens、README、test WAVs 等） |
| Timestamp aligner（預設開啟） | `Qwen/Qwen3-ForcedAligner-0.6B` | 1,840,015,971 bytes（1.714 GiB） |
| 即時 provisional | `whisper.cpp/small`／`ggml-small.bin`（multilingual Whisper Small；`zh`；**唔係「v3 small」**） | 487,601,967 bytes（0.454 GiB） |
| 即時 final／Accuracy Mode 第三模型 | `whisper.cpp/large-v3`／`ggml-large-v3.bin`（whisper.cpp maintainer-hosted OpenAI Large v3 GGML conversion；live 用 `yue`） | 3,095,033,483 bytes（2.882 GiB；weight file） |
| P0 本機 AI 整理／翻譯 | `google/gemma-4-12b-qat` 本機 Q4_0 GGUF（optional LM Studio runtime） | 6,975,879,008-byte file（6.497 GiB） |
| 實驗性，不啟用 | `bartowski/Qwen3.8-27B-GGUF` `Q2_K` | 11,839,440,480 bytes（11.026 GiB）；16 GiB 真 request Metal OOM，不取代 Gemma |
| File speaker預設（自動／1–4人） | `FluidInference/diar-streaming-sortformer-coreml`／`SortformerNvidiaHigh_v2.1.mlmodelc`（CPU+GPU） | 103,798,404 bytes（含manifest／verification） |
| Speaker embedding（file diarization；Lazy Camman） | `3dspeaker_speech_campplus_sv_zh-cn_16k-common` | 28,282,142 bytes（ONNX 28,281,138 bytes） |
| File speaker CPU fallback／明確多於4人 | `sherpa-onnx-pyannote-segmentation-3-0` | 7,535,791 bytes |

上表 bytes 係呢部 Mac 直接加總每個完整 model directory，包括 manifest／verification stamp；上游網絡下載量可略低，會因 archive／revision 而異。預設 1.7B file pipeline 連 Sortformer、segmentation 同 CAM++ embedding 係 6,823,483,332 bytes（約 6.355 GiB）；Accuracy 再加 Whisper v3 係 9,918,517,637 bytes（約 9.237 GiB）。即時字幕另需要 Small + Large-v3 兩個 model（合計 3,582,635,450 bytes／3.336 GiB）；模型唔會放入 git 或 `.app`。設定頁可以查看、驗證、重新下載或移到 Trash。完整 provenance、pin 同尚未完成嘅公開分發 license-chain review 見 [docs/model-licenses.md](docs/model-licenses.md)。

## 開發、測試及重建

```zsh
# 同步 pinned Python dependencies
/opt/homebrew/bin/uv sync --frozen --all-groups --python /opt/homebrew/opt/python@3.12/bin/python3.12

# Python tests；real-model tests 另按 marker 執行
.venv/bin/python -m pytest backend/tests

# Swift tests
swift test \
  --package-path app \
  --disable-keychain \
  --disable-netrc \
  --disable-xctest \
  --enable-swift-testing \
  -Xswiftc -F \
  -Xswiftc /Library/Developer/CommandLineTools/Library/Developer/Frameworks

# 呢部只裝 Command Line Tools 的 Mac 會編譯／連結 Swift Testing target，
# 但唔會真正啟動 runner；另外跑真實 Store source 的本機 verifier：
scripts/verify_live_speaker_project_store.sh

# 先只 build／sign 到 dist，唔會停止或更換已安裝 App
CTS_BUILD_ONLY=1 CTS_PRESERVE_LOCAL_KEYCHAIN_GENERATION=1 scripts/build_app.sh

# 驗證候選後，先安裝到 ~/Applications（會只重開 CTS 本身）
CTS_PRESERVE_LOCAL_KEYCHAIN_GENERATION=1 scripts/build_app.sh

# 安裝後 health／signature smoke
scripts/test_installation.sh

# GPU、Metal、swap、model integrity；可另加最多 30 秒 WAV 做真 1.7B benchmark
scripts/doctor.sh
scripts/doctor.sh --benchmark-audio /path/to/short.wav --model 1.7B
```

依賴由 `uv.lock` 同 `requirements.lock` pin 住；App 正常啟動唔會重新安裝 packages。

### ASR 公平比較

將 Qwen、Aiko／Whisper、SenseVoice 等 timestamp transcript 寫入 manifest，然後執行：

```zsh
PYTHONPATH=backend .venv/bin/python -m cts_backend.evaluation \
  /private/path/benchmark-manifest.json \
  --output /private/path/benchmark-report.json
```

Report 會分開 raw／香港繁體 metrics、CER、專有名詞、`系／係`、edit operations、segment disagreement 同 RTF；冇 human gold 時只會報 agreement，唔會宣稱邊個較準。輸出唔包含逐字稿、音訊或來源路徑。Manifest schema 見 [docs/asr-comparison.md](docs/asr-comparison.md)。

## 網站／朋友下載

**可以做，但現有 build 未過分發 gate。** 正常網站版需要 self-contained arm64 runtime、經 license 審核嘅 FFmpeg／subtitle renderer、穩定 bundle identifier、Developer ID Application signature、Hardened Runtime、Apple notarization／stapling，同保留 quarantine 嘅乾淨 Mac smoke test。Apple Developer Program 目前列明年費係 USD 99 或當地貨幣；未有 Yin 明確批准付費及建立身份前，project 唔會代為 enrollment、簽署或發布。

Docker Desktop 喺 Mac 係 Linux VM，普通 container 無法沿用目前 MLX／Metal primary ASR，亦會要求朋友額外安裝 Docker 同分配記憶體，所以唔會用作 consumer download。Aiko 參考結果同下一階段次序見 [docs/aiko-native-distribution-research.md](docs/aiko-native-distribution-research.md)：先由 Yin 試用現有本機 Final Beta，之後先做 embedded runtime、clean-Mac smoke、Developer ID notarized DMG。

只讀審核現有 App：

```zsh
scripts/audit_distribution.sh \
  "$HOME/Applications/Cantonese Transcript Studio.app"
```

審核會逐項檢查 bundle 內 Python/helper、FFmpeg/ffprobe、arm64、deployment targets、dylib/rpath、bundle metadata、Developer ID、Hardened Runtime、timestamp、notarization ticket 同 Gatekeeper。任何一項欠缺都會清楚 `FAIL`、exit nonzero；佢唔會修改 App、quarantine 或系統安全設定。

`scripts/package_release.sh` 只係 production packaging scaffold：輸入 App 必須已經完整 self-contained、Developer ID signed、notarized、stapled 並通過上述審核；另外要有本機 Keychain identity 同 `notarytool` profile，否則會拒絕建立 DMG。詳細步驟見 [release checklist](docs/release-checklist.md)。

Models唔會塞入DMG。朋友首次啟動要明確確認下載。以2026-08-09本機完整目錄計：預設1.7B + verifier + ForcedAligner + Sortformer + embedding約6.358 GiB；用0.6B primary約3.730 GiB；1.7B Accuracy Mode再加Whisper Large-v3約9.241 GiB；即時字幕另要求 Whisper Small + Large-v3 約3.336 GiB。現時仍依賴本機 Homebrew `whisper-server`，所以未達 portable consumer build。呢啲係安裝後本機logical bytes，唔係下一個upstream revision嘅下載承諾；公開下載頁要以final pinned artifacts重新量度。模型下載之外，本機檔案轉錄、咪高峰字幕、個人詞庫、字幕preview／burn-in同exports都必須保持本機處理；公開平台URL匯入例外地需要用戶主動連線。

本機開發如用 Homebrew `ffmpeg-full`／libass 做字幕 burn-in，只屬開發 runtime；公開版唔會直接複製呢部 Mac 嘅 GPL-enabled Homebrew binary。正式 bundle 要用可重現、逐項審核 license／dylib 嘅 renderer build，並附 source、configure line、notices 同所需 source offer。

## 已知限制

- 呢個係本機 ad-hoc signed build，未有 self-contained runtime、Developer ID notarization 或 clean-quarantine Mac驗證；唔適合直接 upload 或分發俾其他 Mac。
- App 目前 unsandboxed，並以 ad-hoc signature 加 `--options runtime`／audio-input entitlement 建置；呢個 Hardened Runtime flag **唔等於** Developer ID signing、notarization 或公開發布資格。佢仍要依賴本機 worker、FFmpeg、MLX 同用戶揀選嘅媒體，亦冇全域降低 Gatekeeper 安全設定。
- 預設已啟用 `Qwen/Qwen3-ForcedAligner-0.6B` 嘅 v3 時間碼對齊；獨立約60秒 timing windows 會用 coarse segment end／低能量邊界同 1.5 秒 overlap，唔再將結果硬裁到24秒 ASR core。Chosen transcript不變，character／word／cue timestamps同fallback reason會保留audit。Primary synthetic acoustic regression由v2 boundary median 66ms／P95 7,497ms改善至v3 34.5ms／1,815ms；另一批未參與調參、含重複廣東話語氣詞同 VOO／YouTube／Reels／Threads 嘅 held-out fixture，由v2 42ms／5,731ms改善至v3 28ms／411ms，coverage 100%，但最差 boundary 仍有2,723ms。兩批都唔係真人自然語音gold；快速對話、重疊講話、雜音或ASR文字本身錯誤時，精準剪接前仍然要試聽。
- 即時預覽用 SwiftUI/CoreText，燒入片用 libass；App 保存同一組 pixel-based style 同原片 raster reference，但唔宣稱兩個 renderer pixel-identical。字體 fallback、換行同 shadow blur 仍要以最終影片 frame 為準。
- Qwen 1.7B 喺呢部 M1 Pro 16GB 使用 Metal GPU：修正後同一段 33.10 秒真錄音 inference 19.231 秒、兩個 internal chunks 正常 EOS、文字 hash 不變；另一段 15 秒 doctor canary 總計 12.949 秒。開始前仍會警告高 swap，queue 固定單工作。
- 7,200 秒 sparse PCM16 架構 endurance 已驗證 300 個 disk chunks、連續 core ranges 同 bounded Python memory；呢個只證明長錄音分塊架構，亦冇實際跑完 2 小時嘅三 ASR／ForcedAligner wall-clock。
- File speaker diarization係聲音分群而非身份驗證；Sortformer固定最多4個slots，runtime失敗會轉本機sherpa CPU，明確多於4人亦直接用legacy engine。現有DER／JER只來自一個28.647秒、2人、英語human-labelled fixture；廣東話、重疊講話、嘈聲或實際人數錯誤仍要喺字幕editor覆核，並可重新命名／改派。
- 普通即時字幕完全停用 speaker tracking；只有用戶明確進入 Lazy Camman 並揀 named project，App 才會載入 CAM++，並以 Keychain + AES-GCM 在本機加密保留有限聲音特徵。短句會安全顯示「未確定講者」，佢唔係身份驗證；現有 A→B→A control／project smoke亦唔代表一般 DER 或真人辨認準確率。
- 即時 ASR 已由 Wenet 切換到 Whisper Small `zh` provisional + Large-v3 `yue` final；已有本機 loopback／server lifecycle tests，但舊 Wenet build 的 physical-mic evidence 唔可以移植成新 pair 的真機準確度或延遲承諾。新 pair 仍要完成 physical-mic smoke，同時唔代表真人 speaker-switch benchmark。
- 個人修正記憶只係deterministic短詞mapping：手動／匯入alias或重複接受嘅字幕修正先可套用。要完全停用學習可喺設定關閉；清空前如要保留，先匯出JSON備份。
- YouTube URL 匯入需要網絡，並受平台狀態、版權、region 同 extractor 變更影響；真實 smoke 通過不代表任何影片都可下載。

架構決定見 [docs/architecture.md](docs/architecture.md)，故障處理見 [docs/troubleshooting.md](docs/troubleshooting.md)。
