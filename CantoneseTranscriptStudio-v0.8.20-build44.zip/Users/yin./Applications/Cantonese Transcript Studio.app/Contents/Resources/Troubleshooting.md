# Troubleshooting

先記住兩個原則：唔好全域關閉Gatekeeper；唔好手動永久刪除`Models`或`Jobs`。Model／job清除會移到macOS Trash；個人詞庫「清除全部」係另一個有確認提示嘅動作，如要保留請先匯出JSON。

呢份指引對應 source／candidate／installed `0.8.12 (36)`、macOS 14+。Build36 regression係backend 938 passed + 1 environment-gated skip、Swift Testing 165/165 passed；installed真模型pipeline、15/15格式、YouTube字幕、雙語及speaker-style burn-in都已重跑。普通即時字幕固定係純字幕模式；Lazy Camman regression另行覆蓋2–15人project／最後一位註冊／手動下一位gate同受控真音訊A→B→A e2e。現場房間咪高峰仍係獨立人手gate。

## App 開唔到

### 由網站／朋友傳過嚟嘅 `.app` 開唔到

目前 project 只交付 Yin 呢部 Mac 嘅 local build；**唔好將現有 `.app`／ZIP 直接傳俾朋友**。現時 bundle 大小明顯小過完整 runtime／models，因為 Python、MLX／sherpa packages、FFmpeg、Deno 同模型仍然喺 bundle 外。就算朋友用 Finder 單次 override Gatekeeper，仍然會缺少必需組件。

先喺原 build Mac做 read-only audit：

```zsh
scripts/audit_distribution.sh \
  "$HOME/Applications/Cantonese Transcript Studio.app"
```

見到任何 `[FAIL]` 或 `RESULT: NOT DISTRIBUTABLE`就唔可以 upload。唔好用 `spctl --master-disable`、唔好移除 quarantine、唔好叫朋友執行來歷不明嘅 Terminal bypass。正式朋友版要依 [release checklist](release-checklist.md)完成 self-contained runtime、license、Developer ID、notarization同 clean quarantined Mac驗證。

`scripts/package_release.sh` 唔係繞過 signing嘅 shortcut。缺 `CTS_DEVELOPER_ID_APPLICATION`、`CTS_NOTARY_KEYCHAIN_PROFILE`，或者輸入 App未過 full audit時，佢會 fail-closed，唔產生貌似正式嘅 DMG。

### 顯示「本機處理器未安裝完成」

App bundle 同 Python runtime 分開。喺 project root 重新執行：

```zsh
scripts/bootstrap.sh
scripts/test_installation.sh
```

再用 Finder 開：

```text
~/Applications/Cantonese Transcript Studio.app
```

### macOS 阻止開啟

呢個 build 係本機 ad-hoc signed，未 notarize。先確認 App 係由同一個 project 喺呢部 Mac build；再於 Finder 對 App 按右鍵 →「開啟」。如仍失敗，重新跑 `scripts/build_app.sh` 同 `scripts/test_installation.sh`。

唔好使用 `spctl --master-disable`，亦唔好全域關閉 Gatekeeper。對外分發要另做 Developer ID signing + notarization。

Developer ID／notarization正常需要 Apple Developer Program membership；Apple目前列明 USD 99／年或當地貨幣。呢個係外部付費同身份決定，project script唔會自動 enrollment、保存 Apple Account password或將 private key寫入 repo。

## 首次畫面一直話模型未準備好

1. 去「設定」→「語音模型」。
2. 對畫面列為required嘅每個model按「檢查完整性」；預設自動／1–4人file speaker route包括primary、verifier、ForcedAligner、Sortformer Core ML、Pyannote segmentation同CAM++ embedding，後兩個係本機CPU fallback；明確>4人直接用segmentation + embedding。
3. 缺少或 checksum／manifest 不符就按「重新下載」。
4. 確認模型位置係：

```text
~/Library/Application Support/Cantonese Transcript Studio/Models/
```

呢部 Mac 實際 CAM++ speaker embedding 目錄係 28,282,142 bytes；預設 1.7B + verifier + ForcedAligner + Sortformer + CAM++ 組合係 6,815,947,541 bytes（約 6.348 GiB）。模型共識會另加 Whisper Large v3 後係 9,910,981,846 bytes（約 9.230 GiB）。Segmentation 目錄約 7.5 MB；現時所有開啟file diarization嘅安裝都需要，因為佢同CAM++組成Sortformer失敗時嘅CPU fallback。呢啲係 installed logical bytes，唔等於未來 revision 嘅 network transfer size。

下載需要網絡同足夠磁碟空間。下載中斷後再按下載：Qwen／Sortformer逐檔、sherpa archives同Whisper單檔都可resume，完成固定revision／size／hash檢查先原子寫入正式位置。Sortformer只接受pinned 10-file compiled bundle；完整驗證成功後有本機verification stamp，檔案一有變化就會要求重驗，唔會信任半下載model。

設定頁嘅 model location 今版係固定路徑；「喺 Finder 顯示」會打開實際 Models folder，唔會搬移大型檔案。

## 「搵唔到 FFmpeg／ffprobe」

重新執行：

```zsh
scripts/bootstrap.sh
```

bootstrap 會確認 `/opt/homebrew/bin/ffmpeg` 同 `ffprobe`。程式唔會將 Homebrew FFmpeg 複製入 app bundle。

如錯誤發生喺字幕 burn-in：本機開發 renderer可能係獨立 `ffmpeg-full`／libass，唔等同 extraction用嘅 FFmpeg。先睇技術 log入面嘅 capability probe；冇 `ass`／`subtitles` filter時應該顯示 renderer unavailable，唔應用無字幕影片冒充成功。公開版必須bundle經 license同dylib審核嘅 renderer，唔會要求朋友先裝Homebrew。

本機重建可重新執行 `scripts/bootstrap.sh --skip-models --no-open`；script會確保 `/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg` 同配套 `ffprobe`存在，並實際讀返 `ass` filter。唔需要、亦唔應該 `brew link ffmpeg-full` 覆蓋原本 extraction用嘅 FFmpeg。

## 加唔到檔案

支援：

- 影片：MP4、MOV、MKV、M4V、AVI、WebM
- 音訊：WAV、MP3、M4A、AAC、FLAC、AIFF／AIF、OGG、Opus

如果副檔名正確但仍失敗，ffprobe 可能判斷檔案損壞、內容格式不符或者影片冇音軌。原檔唔會被修改。

Build36已用installed production probe／extraction逐一驗證以上15種格式；Build32亦曾用file picker將真M4A + MP4加入同一batch並完成整條pipeline。呢啲唔等於Build36嘅Finder實體拖放已由本輪自動化作實：本輪Computer Use服務喺file picker／跨視窗drag時自行中斷，但App保持運行、queue仍為0。請真人先用「選擇檔案」加入一個M4A，再拖一個MP4及多選batch；如仍無反應，保留source filename同`Logs/worker.log`。

外置硬碟檔案要保持連接；如果重開 App 後 source path 不存在，接回原本 volume，再按「再試一次」。

## 同一檔案加唔到兩次／大型影片加入得慢

App 加入檔案時先讀開頭／結尾各 4 MiB 做 bounded quick fingerprint，duration 亦非同步載入；正式 background runner 開始前先做完整 SHA-256 seal。呢個設計避免大型影片喺 UI 同步掃完整檔案，同時確保處理前會偵測檔案變更及真內容重複。Batch 其中一項重複或損壞，只會提示該項錯誤，其餘項目照樣加入。

如果你真係要重新跑同一內容：先將需要保留嘅 exports 匯出到其他位置，再喺「歷史記錄」清除完成記錄；清除內容會移到 Trash。

## 即時字幕一直等咪高峰權限

1. 先回應macOS顯示嘅咪高峰權限視窗；呢個系統視窗必須由使用者親自撳「允許」。
2. 如App等超過45秒，會停止轉圈並顯示可理解提示；回應系統視窗後再按一次「開始收音」。
3. 去「系統設定」→「私隱與保安」→「咪高峰」，確認Cantonese Transcript Studio已開啟；改動後重新開App。
4. 本機重建後跑`scripts/test_installation.sh`；佢會同時核對`NSMicrophoneUsageDescription`、signature完整性同`com.apple.security.device.audio-input=true`，缺一不可。

唔好用`tccutil reset`、直接改TCC database或全域降低macOS安全設定去繞過授權。權限視窗有時會喺其他視窗後面；先用Mission Control確認，而唔係重複啟動多個App instance。

## Job 失敗、取消或 App 中途關閉

- 失敗：喺 queue／歷史記錄按「再試一次」。
- 取消：同樣可以 retry。FFmpeg／一般 ASR 喺安全 chunk 邊界停止；ForcedAligner 會終止專用 process group，限時 SIGTERM 後再 SIGKILL，唔會無限等 native call。
- App crash／重開：Build36 recovery contract只會將真正中斷、可安全續跑嘅job放回queue；已完成job以workspace artifacts為準，原source之後搬走亦唔會誤重跑。完成checkpoint損壞會轉為failed並要求使用者明確按retry，唔會自動執行。Build36已對真completed job連續重開兩次：第二次0 startup events、job metadata hash不變。
- 已有 `primary.json`、`verifier.json` 等完整 checkpoint 時，retry 唔應無條件重跑之前階段。Forced timestamps 另用 `timestamp-chunks.json` 恢復有效 contiguous prefix；`timestamps.json` 要通過 fingerprint、payload digest、完整 text coverage 同 timestamp bounds 先會重用。Exports 要逐檔對 size／SHA-256，冇完整 artifact manifest 就會重建。

如果 source file、checkpoint artifact 或 model 已被手動搬走，resume 會退回較早階段或者報錯；請接回原始媒體／重新下載模型後再試。

## 記憶體壓力／App 被系統終止

M1 16GB 建議：

1. 先執行 `scripts/doctor.sh`，確認 `Device(gpu, 0)`、Metal `OK`、model 已驗證；
2. Swap 超過 4GB 時，關閉其他高記憶體 App；
3. 保持一次只處理一個 job（預設就係 sequential queue）；
4. 重新開 App 再 retry，primary 同 forced timestamps 都會由各自最後一個有效 contiguous chunk journal 續跑；
5. 只係 doctor 真 benchmark 仍失敗或記憶體壓力持續，先暫時改用 `Qwen3-ASR 0.6B`。

```zsh
scripts/doctor.sh
scripts/doctor.sh --benchmark-audio /path/to/short-16khz-mono.wav --model 1.7B
```

Doctor benchmark 只接受最多 30 秒 WAV；佢會真正跑 local model，唔係假 progress。修正版會喺第一段 inference 前清 loader cast cache，Primary 完成後再清 MLX cache，之後先建立 CPU verifier；technical log 會保留每段 elapsed time、tokens、EOS 同 memory snapshot。

## 逐字稿有橙色／低信心段落

代表模型之間有未可靠解決嘅差異、similarity偏低，或者confidence不足。標準模式會比較primary／verifier；模型共識會亦會計Whisper、ensemble choice同safety-gate結果。高準確模式無安全候選時會保留Whisper Large v3，唔會由Gemma自由補寫。

展開「進階比對」可查看primary、verifier、Whisper audit、similarity、候選同reconciliation／safety-gate reason。Vocabulary只係correction evidence/context，唔保證正確，低信心內容仍要人手聽返。

## 講者分辨結果唔準／第一次好耐

- 自動或預期1–4人應顯示Sortformer Core ML engine；明確>4人先應走legacy sherpa。Engine、model／helper hash同raw turns會寫入`diarization.json`／`diarization-turns.json`。
- Sortformer現時固定用Core ML CPU+GPU，唔使用ANE。第一次喺新機仍可能因Core ML compile較慢；完成後有效checkpoint可resume。
- 如Sortformer runtime失敗，App會自動用sherpa CPU兼容模式並在結果頁顯示橙色提示；兩個engine都失敗亦會照出字幕，但講者顯示Unknown。呢個狀態唔代表ASR失敗，可稍後只Retry講者stage。
- 如果錄音其實得2人但結果太碎，可喺設定填預期2人再retry。額外Sortformer slot會省略成`Unknown`，系統唔會猜邊兩個cluster應該合併。
- 如果錄音多於4人，要明確填實際預期數先使用legacy engine。Sortformer本身固定4個slots，唔可以靠threshold扮支援更多人。
- 完成後去字幕editor「講者」重新命名、逐cue改派、決定顯示名同樣式；呢啲只改revisioned subtitle project，唔會竄改raw diarization audit。

Current human-labelled benchmark只係28.647188秒、2人英語fixture：Sortformer DER 0.094200／JER 0.108580，舊sherpa known-2 baseline DER 0.320650／JER 0.590947。錄音重疊、背景聲、距離遠或廣東話場景仍可能有誤，唔好將呢組數字當真人身份準確率。詳見 [speaker diarization](speaker-diarization.md)。

## 即時字幕冇反應／冇講者名

1. 確認macOS 14+，到「系統設定」→「私隱與保安」→「咪高峰」允許Cantonese Transcript Studio；拒絕後要喺系統設定重新開，App唔會繞過權限。
2. 如果macOS權限視窗被另一個密碼／安全視窗遮住，先取消嗰個無關視窗再回應咪高峰權限。App最多等45秒，之後會清楚提示你回應權限視窗同再按「開始收音」，唔會無限轉圈。
3. 即時字幕需要 Whisper Small 同 Whisper Large-v3；到設定驗證兩個 model 同 whisper.cpp runtime。WenetSpeech-Yue 係檔案 verifier，唔係 live ASR。
4. Generic「即時字幕」唔會分析講者，所以冇 Speaker 名同轉人提示係正常；如果需要呢兩樣功能，要去獨立「Lazy Camman」頁建立 project。Lazy Camman 另需要 CAM++ speaker embedding，缺少時會拒絕 project start，唔會靜默退化成亂猜。
5. Lazy Camman 太短句子顯示「未確定講者」係安全行為；只有用戶明確註冊嘅 project profiles 會由 Swift 加密保存。
6. 見到overrun／drop提示，先停止其他轉錄或render，再重新開始。Swift transport最多8個in-flight audio push，backend亦係bounded queue；佢會明確drop同提示，唔會假裝已聽到所有聲音。
7. 停止中等太耐可再按取消；backend容許由stopping升級cancel，只有session真正terminal先釋放heavy-work lock。仍失敗就完整退出再開App，保留`Logs/worker.log`。

Current production Worker smoke用兩把真人廣東話、分離註冊／測試音訊，依次完成Speaker 1、Speaker 2註冊，再以真Whisper Large-v3 + CAM++跑`A,A,B,B,A`，exact A→B→A、0 false switch、snapshot restart／cancel／cleanup全部通過。呢啲證明本機受控Worker／model path，唔證明實體咪高峰、SwiftUI畫面提示、WhatsApp playback或現場準確率。

## 拍攝 project 開唔返／想改講者名稱或顏色

1. 去獨立側欄「Lazy Camman」，揀返 project；第一次建立先填 2–15 位講者、名稱同顏色。
2. 新 project 會由 Speaker 1 開始逐位註冊；每位要約 10 秒有效說話，質素不足會顯示原因並要求重試。完成全部 speaker 後先可以開始。要更新個別 profile 可按該位「重新註冊」。
3. 如畫面話 project 暫時未能讀取，可能係 Mac Keychain key 已不存在、blob 被破壞，或者 speaker model identity 不相容。App 唔會偷偷清空；用 recovery entry 刪除損壞 project，再建立新 project／重新登錄。
4. 刪除 project 前會再確認；刪嘅只係嗰一個加密 project，唔會刪原始錄音、字幕、Jobs 或其他 project。Keychain key 消失後舊 blob 無法復原，呢個係安全設計。

呢個功能係「同一個 project 的聲音分組延續」，唔係保證識別真人。相近聲線、嘈音、離咪或重疊時，系統應該顯示未確定／少提示，而唔應該強塞 A／B。

## 個人詞庫冇學到／想停用或清空

- 設定頁「自動學習字幕修正」有獨立開關。關閉後字幕仍正常儲存，但成功save唔會再加入學習證據；已存在嘅手動／匯入alias仍可按bounded policy套用。
- 只有成功儲存嘅短、單一replacement會考慮學習；大段改寫、插入／刪除、數字／日期／價錢、隱藏Unicode controls同含糊單一中文字會拒絕。
- 由字幕edit推斷嘅alias第一次只留作review／prompt vocabulary，要接受同一mapping兩次先可自動套用。手動加入或匯入alias係明確指令，可即時成為exact-span candidate。
- 詞庫路徑係`~/Library/Application Support/Cantonese Transcript Studio/correction-memory.json`，權限應係`0600`。可以匯出JSON備份、transactional匯入、逐項刪除，或者按「清除全部詞語」再確認；clear-all唔會刪字幕、Jobs或原始錄音。
- Correction memory只改final／chosen copy並寫audit，`primary.json`、`verifier.json`、`whisper.json`同raw live ASR保持原樣。見到錯誤自動替換時，先關閉學習並移除該alias，而唔好手動改raw checkpoint。

## 模型共識會／Gemma 候選覆核

- 三個語音模型一定係逐個執行，唔會同時常駐；整體時間會比標準模式長。
- Gemma只可以喺Qwen／Whisper或deterministic對齊產生嘅immutable candidate ID中選擇或abstain，唔會自己補寫逐字稿；完整raw Wenet文字只供audit，固定不可選。所有段落已由兩個ASR一致解決時會見到`not_needed`，代表12B刻意冇載入，唔係失敗。
- 已知有其他local LLM載入時，16GB 1.7B job會喺Qwen前停止。`lms` query失敗、invalid JSON或CLI missing只會喺同時偵測到LM Studio process時視為狀態不明而阻擋；冇相關process就允許繼續，避免「LM Studio其實冇開」仍false-block。`load_failed`／`load_timeout`亦會寫入lifecycle audit。
- 如已向loopback Gemma endpoint發出request，其後先遇timeout、無效schema或不合資格candidate ID，安全閘會fail closed並保留Whisper Large v3。
- RAM safety guard 係另一條獨立保護：如其他本機 LLM 仲佔用記憶體或指定 Gemma 未能確認釋放，pipeline 會喺 Qwen 前停止，唔會假裝只係 Gemma 被略過。
- `whisper.json`、`alignment.json` 同每段 `ensemble_audit` 會保存實際候選、支持來源、choice 同 reason；冇人工 gold transcript 時，模型一致只代表 agreement，唔等於已證明正確。
- App 只會 load／unload設定中指定嘅 Gemma model，唔會關閉 WhatsApp、Surfshark 或其他應用程式。

如Gemma一直係`disabled_for_job`／`load_failed`／`load_timeout`，先確認`lms` CLI、指定model同LM Studio local server `127.0.0.1:1234`已準備好，再喺設定關閉／重開「Gemma候選覆核」。如果同時見到LM Studio process但CLI查詢／RAM狀態不明，先完整退出或修復LM Studio；如果根本冇相關process，新版resource guard應該容許1.7B繼續，仍然被擋就連同resource report報bug。唔好將endpoint改成LAN、cloud或公開IP；backend會拒絕非loopback位址。

新版lifecycle會喺需要Gemma而loopback server未運行時自動啟動server；工作完結只會unload專用Gemma model，**永不執行process-global server stop**，無論server原本存在或由今次工作啟動都會保留。如果見到`server_status_unknown`、`server_port_conflict`、`server_start_timeout`、`unload_failed`或`unload_timeout`，保留lifecycle audit同worker log。Current installed smoke已真實驗證沿用既有server、model load→unload；最後server仍喺port 1234運行，loaded model count 0。

## 字幕時間唔夠貼字

預設已啟用 `Qwen/Qwen3-ForcedAligner-0.6B` 嘅 v5 時間碼。v5 會由完整 mono WAV 按每個 reconciled segment 建立獨立 alignment window，左右各保留 250 ms acoustic context，唔再硬裁到 ASR chunk core；單一 segment 超過官方 5 分鐘上限會清楚標記 deterministic coarse fallback。完成後，job workspace 應有：

```text
timestamp-chunks.json
timestamps.json
alignment-chunks/alignment-window-manifest.json
final.json
exports/transcript-with-timestamps.txt
exports/subtitles.srt
exports/subtitles.vtt
```

`timestamps.json` 嘅 `metadata.forced_timestamps` 會記錄 method、fallback、cue／word／character counts 同 audit。Chosen transcript 必須原字不變；aligner 如果回傳不同文字，job 會停止來保護內容。

如果顯示「精細字幕時間碼失敗」：

1. 去「設定」對 ForcedAligner 按「檢查完整性」；
2. 確認磁碟仍有空間，原始音訊同 `chunks/` 冇被搬走；
3. 按「再試一次」；有效 `timestamp-chunks.json` 會續跑，唔會無條件從第一塊開始；
4. 查 `Logs/worker.log` 分辨 `forced_timeout`、`forced_child_crash`、`forced_protocol_error` 或 model-integrity error。

Forced aligner 可以改善 cue／word／character 時間，但唔係人工校對。v5 audit 入面舊名 `clipped_word_count` 只代表有 timing 調整嘅 distinct words，已經唔再代表 ASR core clipping；window clamp、block shift、seam shift 同 quantization repair 另有獨立 count／maximum。快速語音、重疊講話、嘈聲或 ASR 文字本身錯誤時，精準剪接前仍然要喺 editor 試聽。字幕用戶手動改過文字／時間後，最終以 `subtitle-project.json` 嘅 revision 為準。

如要集中覆核最可疑嘅 cue，可喺字幕 editor 執行「時間碼覆核」。第一次使用前到「設定」下載並檢查 optional `SenseVoice Yue 時間碼覆核`；WenetSpeech-Yue 亦必須已驗證。完成後橙色隊列只係雙模型一致指出「值得試聽」，唔會自動改時間。按上一段／下一段會由既有 cue 前1秒播放；聽清楚後先按「設開頭為播放位置」。編輯字幕、重排或 project revision 改變會令舊結果失效並要求重新掃描。

字幕編輯器可將每段上限設為6–60個visible characters（預設18），再揀「精準時間」或「自然斷句」。精準模式只依timestamps、停頓、標點同受保護詞語；自然斷句會暫時載入設定中嘅本機Gemma，Gemma只可揀合法boundary ID，唔可改寫文字，失敗就完整退回精準模式。Policy `timestamp-semantic-dp-v3`將semantic IDs當soft hints，再以500ms readability scoring同safe flash merge避免一閃而過；任何merge都必須連續、不改字同不超字數上限。完整而有標點嘅200–499ms短句可以保留，唔會為湊時長硬合併。Lexical-glue gate仍保護「之後」等curated短語；佢唔係一般中文斷詞器，其他陌生詞仍要預覽。重排現有字幕前App會要求確認；手動cue唔會靜靜被覆蓋。Installed policy-v3 true smoke由rev9→10，用3 calls／33 selector IDs喺38.875秒產生43 cues、max17、min320ms、under200=0、under500=3、readability merges 4、remaining short 3、exact text preserved、lexical phrase `split=false`；read-only replay確認3條短cue全部係完整標點短句。最後專用model已unload，server保留喺port 1234而loaded model count係0。如果完成後`lms ps --json`仍見到`cts-*` model，保留semantic report同worker log再報bug。

如果見到「超過上限」橙色提示，先睇該段係咪一個不可安全拆開嘅 URL、email、英文詞、數字或 vocabulary phrase。系統寧願保留一個有 audit嘅超限 token，都唔會將 `清華大學`、`IG Reels` 或 URL從中間切斷。

## 香港繁體字形有問題

文字處理順序係 reconciliation → OpenCC `s2hk`；中間嘅 speaker diarization 只加匿名時間標籤，唔改 transcript wording。之後 ForcedAligner 只對齊已選定文字，最後先 export。專有名詞 vocabulary 會喺 OpenCC 階段受 placeholder 保護；OpenCC 唔會將廣東話翻譯成普通話。

如見到可重現錯字，保留以下資料再報告：source filename、job ID、`alignment.json`、`final.json` 同相關時間段。唔需要分享原始錄音，除非你自己選擇。

## 匯出按鈕灰咗／儲存失敗

六個格式要完成`exports` checkpoint後先啟用：TXT、時間碼TXT、SRT、VTT、JSON、CSV。先確認job顯示「已完成」。

如 save panel 目標已經有同名檔，App 會先將舊目標移到 Trash再複製新檔；冇權限或磁碟已滿時，揀另一個可寫位置。

CSV開啟時見到文字前多一個apostrophe，通常係安全neutralization：任何trim-leading後以`= + - @`開頭嘅string cell都會阻止spreadsheet當公式執行。SRT／VTT cue內如果原文一行貌似`00:00:00,000 --> ...`時間軸header，亦會加安全前綴，避免破壞字幕結構。JSON同原始逐字稿仍保留exact text；唔好手動批量刪除呢啲format-specific保護再轉發不可信檔案。

Job 自動產生嘅原始 exports 位於：

```text
~/Library/Application Support/Cantonese Transcript Studio/Jobs/<job-id>/exports/
```

## 公開影片匯入失敗／無字幕

先跑：

```zsh
scripts/test_installation.sh
```

Health 要顯示影片下載 runtime ready；實際路徑係 Application Support runtime 嘅 Python，同 `Runtime/youtube/deno`，唔讀用戶 PATH 來猜一個 Deno。2026-08-06 嘅 lock 直接 pin `yt-dlp==2026.7.4` + `yt-dlp-ejs==0.8.0`，已移除 `[default]` extra 帶入嘅 `mutagen`，並已用 82.121 秒獲授權 fixture 真實重跑 video／audio／caption／6 exports 回歸，16.168 秒完成。如果重建 lock，要再檢查 project venv 同 Application Support runtime 都冇 `mutagen`，並重跑真實 import regression。

常見原因：

- 冇勾選內容權利確認：App 會拒絕開始；公開可看唔代表有下載權。
- URL 唔係 exact HTTPS 公開平台 host，或包含 credentials／localhost／`file:`：會喺 preflight 拒絕。
- Threads 顯示 `threads_extractor_unavailable`：Meta public endpoint 未提供可下載 media，或者平台已變更；App 唔會改用 cookies／第三方下載網站，請改用原片檔案匯入。
- Bilibili 字幕顯示 `bilibili_subtitle_login_required`：平台要求登入先可以讀字幕；App 唔會使用登入資料，請開啟本機 ASR fallback 或匯入原片。
- 選擇「只要人工字幕」，但影片只得自動字幕：改為人工優先後自動，或啟用 ASR fallback。
- 下載影片／音訊失敗：可能係平台 extractor、region、network、影片已刪除或 DRM；App 唔支援 cookies、登入、私人影片或繞過限制。
- Playlist 部分失敗：每條係獨立 persisted item，已成功 artifact 唔應因另一條失敗而重做；只對 failed item 按 retry。

完成後嘅匯入記錄喺：

```text
~/Library/Application Support/Cantonese Transcript Studio/YouTube Imports/<import-id>/
```

Raw caption 係 immutable evidence，normalized caption 同六種 exports 分開寫；唔應用 HK normalization 覆蓋 raw source。如果 cancel／crash 後懷疑有 orphan，先重開 App 讓 persisted state recovery 處理，再查 worker log；唔要手動清空整個 Application Support 目錄。

## 技術 log 同 health check

Log：

```text
~/Library/Application Support/Cantonese Transcript Studio/Logs/worker.log
```

安裝 health smoke：

```zsh
scripts/test_installation.sh
```

直接查看 worker health：

```zsh
PYTHONPATH=backend \
  "$HOME/Library/Application Support/Cantonese Transcript Studio/Runtime/.venv/bin/python" \
  -m cts_backend.worker --health-check
```

正常結果應包含 `"ok":true`、protocol version、Application Support paths、model readiness、YouTube runtime capability 同 `"normal_transcription_network":false`。呢個 network flag 指 local-file transcription path，唔係話主動 YouTube import 可以離線。

## Privacy 檢查

本機檔案轉錄同咪高峰即時字幕只用local input、local models、FFmpeg／MLX／Core ML／sherpa-onnx／whisper.cpp／OpenCC同本機IO。Optional Gemma只連同一部Mac嘅loopback LM Studio；音訊、逐字稿、session speaker prototypes同個人詞庫唔會傳出電腦。App冇cloud speech provider、analytics或telemetry。

有兩類明確 external-network operation：

1. model download，包括下載前查 remote metadata；本機 model status／verification 本身唔使網絡；
2. 用戶主動提供公開平台URL嘅metadata／media／caption import；呢條路徑會向平台／CDN傳送request所需URL、IP同一般metadata。

如你要完全air-gapped使用，先喺有網絡時完成所有已啟用模型下載及「檢查完整性」；自動／1–4人file route包括primary、verifier、ForcedAligner、Sortformer同embedding，模型共識會另加Whisper Large v3。Optional Gemma另由本機LM Studio管理。離線期間唔好使用公開平台匯入。Build32 installed batch已真跑Qwen 1.7B Q8 MLX GPU → Whisper Large-v3 → Wenet Yue → deterministic reconciliation → OpenCC →六種exports；Gemma只做有候選證據約束嘅post-ASR arbiter／insights／翻譯，完成後立即unload。日常App worker固定Hugging Face／Transformers offline mode，但model download同公開平台功能本身仍然要連線。
