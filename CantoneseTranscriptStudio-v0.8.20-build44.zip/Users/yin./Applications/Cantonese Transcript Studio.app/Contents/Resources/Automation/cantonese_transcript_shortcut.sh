#!/bin/zsh
# Apple Shortcuts helper: pass one local media path as the first argument.
# It prints the completed timestamped TXT to stdout.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  print -u2 -- "用法：cantonese_transcript_shortcut.sh /path/to/audio-or-video"
  exit 2
fi

SOURCE_PATH="${1:A}"
STATUS_FILE="$HOME/Library/Application Support/Cantonese Transcript Studio/local-api.json"
if [[ ! -f "$STATUS_FILE" ]]; then
  print -u2 -- "Local API 未啟用；請喺 App 設定開啟並重新開啟 App。"
  exit 1
fi

BASE_URL="$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["base_url"])' "$STATUS_FILE")"
TOKEN="$(/usr/bin/python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["token"] or "")' "$STATUS_FILE")"
if [[ -z "$TOKEN" || "$BASE_URL" == *"null"* ]]; then
  print -u2 -- "Local API 未運行；請確認 App 開住。"
  exit 1
fi

REQUEST="$(/usr/bin/python3 - "$SOURCE_PATH" <<'PY'
import json, sys
print(json.dumps({"source_path": sys.argv[1], "auto_start": True}, ensure_ascii=False))
PY
)"
RESPONSE="$(curl --silent --show-error --fail --max-time 30 \
  -H "Content-Type: application/json" -H "X-CTS-Token: $TOKEN" \
  -d "$REQUEST" "$BASE_URL/jobs")"
JOB_ID="$(/usr/bin/python3 -c 'import json,sys; print(json.load(sys.stdin)["job"]["id"])' <<< "$RESPONSE")"

for _ in {1..86400}; do
  JOB="$(curl --silent --show-error --fail --max-time 30 \
    -H "X-CTS-Token: $TOKEN" "$BASE_URL/jobs/$JOB_ID")"
  STATE="$(/usr/bin/python3 -c 'import json,sys; print(json.load(sys.stdin).get("status", ""))' <<< "$JOB")"
  case "$STATE" in
    completed)
      curl --silent --show-error --fail --max-time 30 \
        -H "X-CTS-Token: $TOKEN" "$BASE_URL/jobs/$JOB_ID/export/timestamp_txt"
      exit 0
      ;;
    failed|cancelled)
      /usr/bin/python3 -c 'import json,sys; j=json.load(sys.stdin); print(j.get("error_message") or "轉錄失敗", file=sys.stderr)' <<< "$JOB"
      exit 1
      ;;
  esac
  sleep 2
done

print -u2 -- "等候轉錄超時；工作仍然保留喺 App。"
exit 1
