# Model and runtime licenses

核對日期：2026-08-30；對應本機 CTS beta source。呢份文件記錄model provenance、直接runtime licenses同URL HTTP驗證；唔係法律意見。公開網站分發仍然係 **HOLD**，尤其Sortformer converted／upstream license chain、Wenet verifier weights caveat、外部 `whisper-server` runtime 同最終 Whisper artifact redistribution flow未完成release review；以下資料唔代表已完成redistribution或notarization審核。

## 最重要嘅 provenance 分界

**FACT（100%）**：`Qwen/Qwen3-ASR-*` weights 由 Qwen 官方 Hugging Face organization 發布；`mlx-qwen3-asr` 係 moona3k 維護嘅第三方 Apple MLX port。兩者都標示 Apache-2.0，但唔可以將第三方 port 稱為 Qwen 官方 MLX implementation。

**FACT（100%）**：`Qwen/Qwen3-ForcedAligner-0.6B` 由同一 Qwen 官方 organization 發布，model metadata 標示 Apache-2.0；今次安裝固定到 revision `c7cbfc2048c462b0d63a45797104fc9db3ad62b7`。Hugging Face model repository 內冇獨立 LICENSE file，所以 App 嘅 release notices 仍要另行保留 Qwen3-ASR upstream Apache-2.0 text 同 model-card provenance，唔可以只靠 metadata label。

**FACT（99%）**：WenetSpeech-Yue verifier asset 由 sherpa-onnx official model release 提供，來源對應 ASLP-lab `WSYue-ASR` U2++ Conformer。Release archive 本身只得簡短 README，冇獨立 LICENSE file；因此本 App 同時列明 sherpa-onnx runtime、WSYue-ASR model card 同 WenetSpeech-Yue dataset provenance，唔用 archive 缺少嘅文件填空。

**FACT（99%）**：可選 Timing Attention 使用 sherpa-onnx official release `sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09` 做第二個只讀 acoustic witness；archive 165,783,878 bytes、固定 SHA-256 `7305f7905bfcf77fa0b39388a313f3da35c68d971661a65475b56fb2162c8e63`，2026-08-30 exact URL 回應 200。佢唔會自動改字幕，只會同 Wenet 一致時標示需要人手試聽嘅 cue。Exact archive 同樣冇 standalone LICENSE file，故 weight redistribution 仍沿用下方 caveat，網站／DMG唔直接包 weights。

**FACT（100%）**：Accuracy Mode使用嘅`ggml-large-v3.bin`係whisper.cpp maintainer-hosted conversion of OpenAI Whisper Large v3；唔應稱為OpenAI官方GGML檔。OpenAI Whisper code／weights同whisper.cpp code均為MIT。舊`large-v2` weight只保留作向後兼容同historical no-gold A/B evidence，唔再係預設。

**FACT（100%）**：目前 live caption source 使用兩個 whisper.cpp conversion：標準 multilingual `ggml-small.bin`（Whisper Small，`zh`）只產生 provisional partial；`ggml-large-v3.bin`（Whisper Large-v3，`yue`）才產生 final。Small **唔係「Whisper V3 Small」**；OpenAI 的 v3 designation 係 Large checkpoint。兩個 model 由本機 `whisper-server` 1.9.1 子程序持有，僅綁 `127.0.0.1`、保持 GPU policy enabled。呢個係 local runtime design；舊 Wenet live evidence 屬 historical，不代表新 pair 已完成 physical-mic benchmark。

**FACT（100%）**：模型共識會同 P0 text insights／translation 現時指定本機 `google/gemma-4-12b-qat`（Gemma 4 12B QAT，Q4_0；exact GGUF 6,975,879,008 bytes，LM Studio record 7,151,067,268 bytes）做optional local model；Google Gemma 4 model card列Apache-2.0。2026-08-26 已用真 completed job 完成 Summary／Points／Actions／Concepts、cue translation 同專名 probe；LM Studio Desktop本身係proprietary App Terms，唔會由本project bundle、轉售或重分發，朋友必須自行安裝及接受條款。

**FACT（100%）**：實驗性 `Qwen/Qwen3.8-27B` 官方 card標示Apache-2.0、約28B parameters；本機測試用 `bartowski/Qwen3.8-27B-GGUF` `Q2_K` conversion，exact file 11,839,440,480 bytes、SHA-256 `028a1d47b9c822ca76d1e9295d0078d21351a8816ec5612cb4860d7c1ef429d9`。它不屬 App required models、亦不會由 App分發；這部16 GiB Mac三個 llama.cpp配置都在真 inference Metal OOM，所以只保留為實驗 artifact，不會取代 Gemma 12B。

**FACT（100%）**：file diarization自動／1–4人使用 FluidAudio 0.15.5 載入 pinned high-context Sortformer Core ML；明確多於4人才使用 legacy PyAnnote + 3D-Speaker。呢度有三個要分開嘅 license layers：FluidAudio SDK 係 Apache-2.0、FluidInference converted repository metadata 係 CC BY 4.0、NVIDIA upstream model metadata 係 NVIDIA Open Model License。列齊三者唔等於法律審核完成，所以 public release 維持 HOLD。`0.8.3` Lazy Camman 使用 sherpa-onnx release 嘅 CAM++ 中文 16k speaker embedding；project profile 係運行時加密資料，唔係可重分發 weights，亦唔係生物認證。

## Models

| App 用途 | 精確名稱 | License／provenance | 本機約佔空間 | 核實 |
|---|---|---|---:|---:|
| Primary default | `Qwen/Qwen3-ASR-1.7B` | Apache-2.0；Qwen 官方 model repository；revision `7278e1e70fe206f11671096ffdd38061171dd6e5` | 4,703,121,032 bytes | FACT 100% |
| 16GB Primary derived runtime | 同一 `Qwen/Qwen3-ASR-1.7B`；decoder-only MLX Q8、audio tower FP16 | 由上列已 pin Apache-2.0 checkpoint 喺用戶本機轉換；唔係另一個模型、唔會包入 git／App下載 | 2,467,917,821 bytes | FACT 100% |
| Primary fallback | `Qwen/Qwen3-ASR-0.6B` | Apache-2.0；Qwen 官方 model repository；revision `5eb144179a02acc5e5ba31e748d22b0cf3e303b0` | 1,880,625,121 bytes | FACT 100% |
| Verifier | `sherpa-onnx-wenetspeech-yue-u2pp-conformer-ctc-zh-en-cantonese-int8-2025-09-10` | Upstream WSYue-ASR card：Apache-2.0；sherpa release archive | 117,203,117-byte archive；本機 extracted 140,729,992 bytes | FACT 99% |
| Optional timestamp witness | `sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09` | sherpa official release；upstream WSYue-ASR card：Apache-2.0；archive冇獨立LICENSE | 165,783,878-byte archive；本機完整目錄 243,963,487 bytes | FACT 99% |
| Timestamp aligner | `Qwen/Qwen3-ForcedAligner-0.6B` | Apache-2.0 metadata；Qwen 官方 model repository；revision `c7cbfc2048c462b0d63a45797104fc9db3ad62b7` | 1,840,015,971 bytes | FACT 100% |
| Live provisional ASR | `whisper.cpp/small`／`ggml-small.bin` | OpenAI Whisper Small：MIT；whisper.cpp maintainer-hosted GGML conversion | weight 487,601,967 bytes | FACT 100% |
| Live final ASR／Accuracy third ASR | `whisper.cpp/large-v3`／`ggml-large-v3.bin` | OpenAI Whisper Large v3：MIT；whisper.cpp maintainer-hosted GGML conversion | weight 3,095,033,483 bytes；2026-08-09 完整本機目錄 3,095,034,307 bytes | FACT 100% |
| Optional text arbiter／P0 insights／translation | `google/gemma-4-12b-qat`；本機 LM Studio Q4_0 GGUF | Apache-2.0；用戶自行經 LM Studio管理，唔由 App分發 | exact GGUF 6,975,879,008 bytes；LM Studio record 7,151,067,268 bytes | FACT 100% |
| Experimental text model（disabled） | `Qwen/Qwen3.8-27B` → `bartowski/Qwen3.8-27B-GGUF:Q2_K` | Official base + community GGUF card均標示Apache-2.0；用戶直接下載，只作本機probe | 11,839,440,480 bytes | FACT 100%；16GiB真 request OOM |
| Speaker diarization default（自動／最多4人） | `FluidInference/diar-streaming-sortformer-coreml`；`SortformerNvidiaHigh_v2.1.mlmodelc` | Converted card metadata：CC BY 4.0；NVIDIA upstream metadata：NVIDIA Open Model License；revision `ae9a27ab45dc0aa3abede7d2d6bad2b7a69aa6d1` | pinned 10 files，103,793,339 bytes | FACT 100% artifacts；license chain release review未完成 |
| Legacy speaker segmentation（明確多於4人） | `sherpa-onnx-pyannote-segmentation-3-0` | sherpa-onnx release asset；PyAnnote segmentation ONNX，Apache-2.0 runtime boundary | 6,958,444-byte archive；完整本機目錄 7,535,791 bytes | FACT 100% |
| Speaker embedding（file diarization；Lazy Camman） | `3dspeaker_speech_campplus_sv_zh-cn_16k-common` | sherpa-onnx release asset；3D-Speaker CAM++ voice embedding ONNX，Apache-2.0 runtime boundary | upstream ONNX 28,281,138 bytes；完整本機目錄 28,282,142 bytes；SHA-256 `f682b514c05d947ee3fa91cd6ec6c5c7543479a128373fa29b1faedccd21fd11` | FACT 100% |

**FACT（100%）**：「完整本機目錄」係2026-08-06至09以regular-file logical bytes直接加總，包括`manifest.json`、verification stamp同archive解壓後必需檔案。Sortformer完整目錄103,798,404 bytes，其中pinned model bundle本身103,793,339 bytes。呢啲唔係網絡transfer size，亦唔係對未來upstream revision嘅尺寸承諾。

Verifier archive 固定 SHA-256：

```text
8636295785a43538a1b4620f167bcb89c10ce5ebdcee61c72a388738b783f992
```

SenseVoice Yue witness archive 固定 SHA-256：

```text
7305f7905bfcf77fa0b39388a313f3da35c68d971661a65475b56fb2162c8e63
```

Whisper Large v3 GGML 固定 SHA-256：

```text
64d182b440b98d5203c4f9bd541544d84c605196c4f7b845dfa11fb23594d1e2
```

Whisper Small GGML 固定 SHA-256：

```text
1be3a9b2063867b937e64e2ec7483364a79917e157fa98c5d94b5c1fffea987b
```

**FACT（100%）**：本機 archive hash 同 code registry 固定值一致。Qwen downloader 會固定 Hugging Face revision，並為實際下載檔建立本機逐檔 SHA-256 manifest。

Models 只會下載到：

```text
~/Library/Application Support/Cantonese Transcript Studio/Models/
```

大型 weights 唔會 commit 入 git，亦唔包入 `.app`。

### 公開版首次下載分界

| Model 組合 | 2026-08-26 本機完整目錄 | 首次網絡下載 | 分發策略 |
|---|---:|---:|---|
| 預設auto／1–4人：1.7B + verifier + ForcedAligner + Sortformer + CAM++ | 6,815,947,541 bytes（約6.348 GiB） | 最終公開build要按pinned artifacts重新量度 | 用戶確認後由upstream下載；weights唔包入DMG |
| 輕量auto／1–4人：0.6B + verifier + ForcedAligner + Sortformer + CAM++ | 3,993,451,630 bytes（約3.719 GiB） | 同上 | 輕量primary；其餘enabled models仍dynamic required |
| 即時字幕：Whisper Small + Whisper Large v3 | 3,582,635,450 bytes（3.336 GiB；兩個 pinned weight files） | 同上 | 兩個模型都係 live required；現時另需要本機 `whisper-server`，唔包入App／DMG |
| 高準確：預設auto組合 + Whisper Large v3 | 9,910,981,846 bytes（約9.230 GiB） | 同上 | Large v3 亦係Accuracy Mode required；唔包入App／DMG |
| 全部兩個Qwen primary選項 + 上述auto models | 11,791,606,967 bytes（約10.982 GiB） | 同上 | optional；唔係首次啟動硬性要求 |
| Legacy明確>4人：1.7B + verifier + ForcedAligner + PyAnnote + CAM++ | 6,719,684,928 bytes（約6.258 GiB） | 同上 | 只有用戶明確要求>4 speakers先需要segmentation asset |

Gemma／LM Studio唔計入App required-model download：佢係optional external local runtime。已知有其他local LLM載入時，16GB 1.7B job會安全停止；`lms` query失敗、invalid JSON或CLI missing只會喺同時偵測到LM Studio process時視為狀態不明而阻擋，冇相關process就允許繼續，避免false block。Gemma loopback server未運行時，App可經本機`lms` CLI自動start；由於server command係process-global而冇instance token，release只unload專用Gemma，**全repo永不發出global server stop**。Automated tests同installed smoke均已驗證start／load／unload／server-preserved路徑；指定model load或unload失敗會另記lifecycle error。

**FACT（100%）**：model weights唔bundle可以減少網站artifact size，但唔代表可以省略provenance／license。下載頁同App仍要列exact model名稱、來源、約需空間及首次下載需要網絡；本機檔案轉錄、咪高峰live caption、個人詞庫、字幕project、preview同burn-in唔會上載。live caption 只會把 bounded PCM WAV 送到同一部 Mac 的 `127.0.0.1` whisper-server，唔會連 cloud ASR。公開平台URL匯入係另一個明確、用戶主動嘅network boundary，唔可包喺「正常轉錄完全離線」嘅無條件句子內。

## 直接 runtime dependencies

| Component | Pinned version | License | 角色／備註 | 核實 |
|---|---:|---|---|---:|
| `mlx-qwen3-asr` | 0.3.5 | Apache-2.0 | 第三方 MLX Qwen ASR port | FACT 100% |
| `mlx` / `mlx-metal` | 0.32.0 | MIT | Apple MLX runtime；wheel 亦包含其第三方 notice | FACT 100% |
| FluidAudio | 0.15.5（SwiftPM exact pin） | Apache-2.0 | Core ML Sortformer streaming runtime；helper只開本機 pinned `.mlmodelc` | FACT 100% |
| `sherpa-onnx` / `-core` / `-bin` | 1.13.4 | Apache-2.0 | Offline CPU verifier、legacy file diarization、3D-Speaker live session tracking + matching native runtime | FACT 100% |
| `opencc-py` | 1.4.1 | Apache-2.0 | Maintained pure-Python OpenCC API | FACT 100% |
| `opencc-data` | 1.4.1 | Apache-2.0 | `s2hk` conversion data | FACT 100% |
| `RapidFuzz` | 3.14.5 | MIT | Similarity／Levenshtein | FACT 100% |
| `huggingface-hub` | 1.26.0 | Apache-2.0 | 首次 Qwen model download；唔參與正常 inference | FACT 100% |
| `numpy` | 2.5.1 | BSD-3-Clause 為主，附 bundled component notices | sherpa audio samples | FACT 100% |
| `yt-dlp` | 2026.7.4 | Unlicense | 用戶主動 YouTube、Instagram、X/Twitter、Bilibili、TikTok、Facebook、Reddit metadata／media／subtitle 下載；直接 pin core wheel，唔用 `[default]` extra | FACT 100% |
| `yt-dlp-ejs` | 0.8.0 | `Unlicense AND MIT AND ISC` | yt-dlp 官方 EJS challenge scripts package | FACT 100% |
| Deno | 2.7.7（arm64 macOS） | MIT | YouTube JavaScript runtime；本機 bootstrap 複製到 `Runtime/youtube/deno` 並用 absolute path | FACT 100% |
| ONNX Runtime dylib | 1.27.0 | MIT，並有 upstream `ThirdPartyNotices.txt` | 實際喺 `sherpa_onnx/lib/` 內由 sherpa wheel 帶入 | FACT 100% |
| Python | 3.12.13 | PSF License | Application Support runtime | FACT 100% |
| `whisper.cpp` CLI + `whisper-server` | 1.9.1（本機 Homebrew） | MIT | CLI 用於Accuracy Mode；server 用於本機 Small `zh` provisional + Large-v3 `yue` final live ASR。現時 runtime 仍係 external Homebrew binary，未 bundle／未可重分發 | FACT 100% |
| Gemma 4 12B QAT | 本機 Q4_0 GGUF | Apache-2.0 | Optional candidate-ID-only／abstain主席，以及post-ASR insights／translation；唔接收音訊 | FACT 100% |
| `llama.cpp` | 0.3.0 build 10621（本機 Homebrew） | MIT | 只用於Qwen3.8-27B Q2_K 16GiB feasibility probe；唔由App啟動或bundle | FACT 100% |
| `lms` CLI | 本機安裝 | MIT | 只管理指定 Gemma model load／unload | FACT 100% |
| LM Studio Desktop | 用戶本機安裝 | Proprietary App Terms | Optional localhost server；禁止由本 project重分發 | FACT 100% |

完整 pinned package inventory 喺 `uv.lock` 同 `requirements.lock`；安裝後 wheel 自帶嘅 license／notice 應保留喺 `Runtime/.venv/.../*.dist-info/licenses/`。**FACT（100%）**：2026-08-06 今次 lock 已由 `yt-dlp[default]` 改為直接 pin `yt-dlp` core + `yt-dlp-ejs`；project venv 同 Application Support runtime 都冇 `mutagen`、`requests` 或 `websockets` package。移除後已用 82.121 秒獲授權 fixture 真實跑過 video／audio／zh-Hant caption／6 exports／manifest／restart 回歸，耗時 16.168 秒；將來每次重新 lock／bundle 後仍要再跑，唔可以只因 package 消失就推斷功能無回歸。

**INFERENCE（98%）**：移除 GPL-2.0-or-later `mutagen` 減少一個明確嘅公開分發 license blocker，但唔會自動令整個 App 「可分發」。FFmpeg build、ONNX Runtime notices、Deno nested signing、其他 Python transitive packages、Wenet verifier weights caveat、Whisper conversion／external server bundle flow 同 Apple notarization 仍然要獨立過 gate。開發用 pytest packages 亦由 lock file pin 住，但唔屬 model license。

### 公開平台網絡／內容權利邊界

**FACT（100%）**：`yt-dlp`、`yt-dlp-ejs` 同 Deno 嘅 software licenses 只規管佢哋嘅 code，唔會授權下載第三方影片或字幕。App 會要求用戶確認只處理自己擁有、已獲授權或法律容許嘅內容；呢個工程措施唔係法律判斷，亦唔保證某條公開 URL 可以合法下載。

**FACT（100%）**：公開平台 import 係用戶主動嘅連線功能，會向 YouTube、Instagram、Threads、X/Twitter、TikTok、Facebook 或 Reddit／CDN 送出一般 request 所需嘅 URL、IP 同 metadata。本機檔案 ASR、reconciliation、OpenCC、subtitle editing、burn-in 同 exports 仍然係 local path。Privacy 說明必須分開呢兩個邊界，並另列模型下載亦需要網絡。Threads adapter 只嘗試 public page，唔使用 browser cookies 或第三方下載服務。

## FFmpeg

**FACT（100%）**：App 用 `/opt/homebrew/bin/ffmpeg` 同 `ffprobe`，冇複製入 `.app`。目前呢部 Mac 嘅 FFmpeg 8.1.1 build flags 包括 `--enable-gpl --enable-version3`，`ffmpeg -L` 自述為 GPL version 3 or later。FFmpeg 實際 license 會因 build configuration 改變，所以文件記錄「本機 binary」而唔將所有 FFmpeg build 一概標成 GPLv3。

### Subtitle renderer／公開重分發

**FACT（100%）**：本機字幕 burn-in開發如另用 Homebrew `ffmpeg-full`／libass，嗰個 binary同佢嘅 Homebrew Cellar dylibs只係 local runtime；唔會直接 copy入朋友／公開 build。FFmpeg官方列明：default主要係 LGPL 2.1+，一旦加入 `--enable-gpl` component，成個 binary嘅適用條款會轉為 GPL；實際義務一定要按 final build configuration判斷。

**INFERENCE（98%）**：正式 release應由固定 FFmpeg source revision建立最少功能 renderer，保存 source tarball/hash、完整 configure line、patch、linked dependency inventory、license texts同適用source offer。libass、font stack、codec/encoder每次改版都要再審；「免費俾朋友」唔會免除 redistribution obligation。

**UNKNOWN**：最終 subtitle renderer係採用完整 LGPL route，抑或以 GPL-compliant方式分發，要等 reproducible public binary完成後，以 `ffmpeg -buildconf`、`ffmpeg -L`、`otool -L`同所有 dependency license做最終判斷。未完成前 `scripts/audit_distribution.sh`應因 bundled tools缺失而 fail。

## App source

App 自己嘅 source 使用 repo root `LICENSE` 所列 MIT License。SwiftUI／AppKit 係 macOS system frameworks，唔由呢個 repo 重分發。

## 已驗證 primary sources

以下每條 URL 都以 `curl -sIL` 檢查；只保留 final HTTP 200 嘅來源。HTTP status 係可達性證據，license 判斷另以 upstream metadata／LICENSE 同本機 installed license 交叉核對。

| Source | 用途 | HTTP |
|---|---|---:|
| [Qwen3-ASR 1.7B model card](https://huggingface.co/Qwen/Qwen3-ASR-1.7B) | 官方 model、license metadata、files | 200 |
| [Qwen3-ASR 1.7B API metadata](https://huggingface.co/api/models/Qwen/Qwen3-ASR-1.7B) | `license: apache-2.0`、revision | 200 |
| [Qwen3-ASR 1.7B pinned commit](https://huggingface.co/Qwen/Qwen3-ASR-1.7B/commit/7278e1e70fe206f11671096ffdd38061171dd6e5) | Exact immutable source snapshot | 200 |
| [Qwen3-ASR 0.6B model card](https://huggingface.co/Qwen/Qwen3-ASR-0.6B) | 官方 fallback model | 200 |
| [Qwen3-ASR 0.6B API metadata](https://huggingface.co/api/models/Qwen/Qwen3-ASR-0.6B) | `license: apache-2.0`、revision | 200 |
| [Qwen3-ASR 0.6B pinned commit](https://huggingface.co/Qwen/Qwen3-ASR-0.6B/commit/5eb144179a02acc5e5ba31e748d22b0cf3e303b0) | Exact immutable source snapshot | 200 |
| [Qwen3 ForcedAligner API metadata](https://huggingface.co/api/models/Qwen/Qwen3-ForcedAligner-0.6B) | Exact aligner model、`license: apache-2.0`、revision | 200 |
| [Qwen3 ForcedAligner pinned commit](https://huggingface.co/Qwen/Qwen3-ForcedAligner-0.6B/commit/c7cbfc2048c462b0d63a45797104fc9db3ad62b7) | Exact immutable source snapshot | 200 |
| [Qwen3-ASR upstream LICENSE](https://raw.githubusercontent.com/QwenLM/Qwen3-ASR/main/LICENSE) | Qwen upstream Apache-2.0 text | 200 |
| [mlx-qwen3-asr repository](https://github.com/moona3k/mlx-qwen3-asr) | 第三方 port provenance | 200 |
| [mlx-qwen3-asr LICENSE](https://raw.githubusercontent.com/moona3k/mlx-qwen3-asr/main/LICENSE) | Apache-2.0 text | 200 |
| [Apple MLX repository](https://github.com/ml-explore/mlx) | Runtime provenance | 200 |
| [Apple MLX LICENSE](https://raw.githubusercontent.com/ml-explore/mlx/main/LICENSE) | MIT text | 200 |
| [sherpa-onnx repository](https://github.com/k2-fsa/sherpa-onnx) | Runtime provenance | 200 |
| [FluidAudio repository](https://github.com/FluidInference/FluidAudio) | Core ML Sortformer runtime provenance | 200 |
| [FluidAudio Apache-2.0 LICENSE](https://github.com/FluidInference/FluidAudio/blob/main/LICENSE) | Exact Swift runtime license | 200 |
| [FluidAudio Sortformer guide](https://github.com/FluidInference/FluidAudio/blob/main/Documentation/Diarization/Sortformer.md) | High-context streaming／four-slot behavior | 200 |
| [Converted Sortformer Core ML model](https://huggingface.co/FluidInference/diar-streaming-sortformer-coreml) | Exact converted artifact repository／CC BY 4.0 metadata | 200 |
| [NVIDIA Sortformer v2.1 upstream](https://huggingface.co/nvidia/diar_streaming_sortformer_4spk-v2.1) | Upstream model provenance／NVIDIA Open Model License metadata | 200 |
| [NVIDIA Open Model License](https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-open-model-license/) | Upstream model license text | 200 |
| [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) | Converted repository metadata license text | 200 |
| [sherpa offline speaker diarization docs](https://k2-fsa.github.io/sherpa/onnx/speaker-diarization/index.html) | PyAnnote segmentation + 3D-Speaker embedding + clustering architecture | 200 |
| [Speaker segmentation release](https://github.com/k2-fsa/sherpa-onnx/releases/download/speaker-segmentation-models/sherpa-onnx-pyannote-segmentation-3-0.tar.bz2) | Exact PyAnnote model archive | 200 |
| [3D-Speaker CAM++ embedding release](https://github.com/k2-fsa/sherpa-onnx/releases/download/speaker-recongition-models/3dspeaker_speech_campplus_sv_zh-cn_16k-common.onnx) | Exact embedding model | 200 |
| [sherpa-onnx LICENSE](https://raw.githubusercontent.com/k2-fsa/sherpa-onnx/master/LICENSE) | Apache-2.0 text | 200 |
| [sherpa Wenet CTC model page](https://k2-fsa.github.io/sherpa/onnx/pretrained_models/offline-ctc/wenet/index.html) | Exact verifier filename／usage | 200 |
| [Exact verifier archive](https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-wenetspeech-yue-u2pp-conformer-ctc-zh-en-cantonese-int8-2025-09-10.tar.bz2) | Release asset | 200 |
| [sherpa SenseVoice model page](https://k2-fsa.github.io/sherpa/onnx/sense-voice/pretrained.html) | SenseVoice runtime／model family provenance | 200 |
| [Exact SenseVoice Yue archive](https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-sense-voice-zh-en-ja-ko-yue-int8-2025-09-09.tar.bz2) | Optional Timing Attention witness asset | 200 |
| [WSYue-ASR model card](https://huggingface.co/ASLP-lab/WSYue-ASR) | Upstream model provenance | 200 |
| [WSYue-ASR API metadata](https://huggingface.co/api/models/ASLP-lab/WSYue-ASR) | `license: apache-2.0` | 200 |
| [WenetSpeech-Yue official repository](https://github.com/ASLP-lab/WenetSpeech-Yue) | Dataset provenance | 200 |
| [WenetSpeech-Yue repository LICENSE](https://raw.githubusercontent.com/ASLP-lab/WenetSpeech-Yue/main/LICENSE) | Processing code／repository Apache-2.0 text | 200 |
| [WenetSpeech-Yue dataset card](https://huggingface.co/datasets/ASLP-lab/WenetSpeech-Yue) | Dataset `CC-BY-NC-4.0` metadata | 200 |
| [CC BY-NC 4.0 legal code](https://creativecommons.org/licenses/by-nc/4.0/legalcode.en) | Dataset license terms | 200 |
| [OpenAI Whisper README](https://github.com/openai/whisper/blob/main/README.md) | Code/model-weight provenance | 200 |
| [OpenAI Whisper Large v3 release](https://github.com/openai/whisper/discussions/1762) | Cantonese language token、training同version provenance | 200 |
| [OpenAI Whisper LICENSE](https://raw.githubusercontent.com/openai/whisper/main/LICENSE) | MIT text | 200 |
| [whisper.cpp converted models](https://huggingface.co/ggerganov/whisper.cpp) | Large v3 GGML artifact、size同conversion provenance | 200 |
| [Whisper Small GGML artifact](https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin) | Exact live provisional artifact | 200 |
| [Whisper Large-v3 GGML artifact](https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3.bin) | Exact live final／Accuracy artifact | 200 |
| [whisper.cpp model repository](https://huggingface.co/ggerganov/whisper.cpp) | GGML conversion provenance／exact file | 200 |
| [whisper.cpp LICENSE](https://raw.githubusercontent.com/ggml-org/whisper.cpp/master/LICENSE) | MIT text | 200 |
| [whisper.cpp v1.9.1 server source](https://raw.githubusercontent.com/ggml-org/whisper.cpp/v1.9.1/examples/server/server.cpp) | `--host`、`--request-path`、`/health`、multipart inference interface provenance | 200 |
| [Google Gemma 4 model card](https://ai.google.dev/gemma/docs/core/model_card_4) | 12B model／Apache-2.0 | 200 |
| [Google Gemma 4 Apache license](https://ai.google.dev/gemma/apache_2) | Official Gemma 4 license boundary | 200 |
| [LM Studio Community Gemma 4 12B QAT GGUF](https://huggingface.co/lmstudio-community/gemma-4-12B-it-QAT-GGUF) | Exact本機12B quantization provenance | 200 |
| [Qwen3.8-27B official model card](https://huggingface.co/Qwen/Qwen3.8-27B) | Official parameter count／Apache-2.0 metadata | 200 |
| [Bartowski Qwen3.8-27B GGUF](https://huggingface.co/bartowski/Qwen3.8-27B-GGUF/blob/main/README.md) | Q2_K conversion、quant size／quality table | 200 |
| [MLX Community Qwen3.8-27B 4-bit files](https://huggingface.co/mlx-community/Qwen3.8-27B-4bit/tree/main) | 4-bit shard inventory／actual repository size | 200 |
| [llama.cpp LICENSE](https://github.com/ggml-org/llama.cpp/blob/master/LICENSE) | MIT license for probe runtime | 200 |
| [LM Studio App Terms](https://lmstudio.ai/app-terms) | Desktop redistribution restriction | 200 |
| [LM Studio CLI](https://lmstudio.ai/docs/cli) | Public CLI integration | 200 |
| [LM Studio OpenAI-compatible API](https://lmstudio.ai/docs/developer/openai-compat) | Localhost endpoint integration | 200 |
| [`lms` LICENSE](https://raw.githubusercontent.com/lmstudio-ai/lms/main/LICENSE) | MIT text | 200 |
| [OpenCC repository](https://github.com/BYVoid/OpenCC) | Conversion engine／data provenance | 200 |
| [OpenCC LICENSE](https://raw.githubusercontent.com/BYVoid/OpenCC/master/LICENSE) | Apache-2.0 text | 200 |
| [opencc-py 1.4.1 on PyPI](https://pypi.org/project/opencc-py/1.4.1/) | Exact Python distribution metadata | 200 |
| [RapidFuzz repository](https://github.com/rapidfuzz/RapidFuzz) | Library provenance | 200 |
| [RapidFuzz LICENSE](https://raw.githubusercontent.com/rapidfuzz/RapidFuzz/main/LICENSE) | MIT text | 200 |
| [yt-dlp 2026.7.4 PyPI metadata](https://pypi.org/pypi/yt-dlp/2026.7.4/json) | Exact wheel metadata、version、Unlicense expression | 200 |
| [yt-dlp 2026.07.04 LICENSE](https://raw.githubusercontent.com/yt-dlp/yt-dlp/2026.07.04/LICENSE) | Tagged Unlicense text | 200 |
| [yt-dlp-ejs 0.8.0 PyPI metadata](https://pypi.org/pypi/yt-dlp-ejs/0.8.0/json) | Exact EJS package metadata、license expression | 200 |
| [Deno v2.7.7 release](https://github.com/denoland/deno/releases/tag/v2.7.7) | Exact runtime release provenance | 200 |
| [Deno v2.7.7 LICENSE](https://raw.githubusercontent.com/denoland/deno/v2.7.7/LICENSE.md) | MIT text | 200 |
| [ONNX Runtime v1.27.0 LICENSE](https://raw.githubusercontent.com/microsoft/onnxruntime/v1.27.0/LICENSE) | Embedded dylib MIT text | 200 |
| [ONNX Runtime v1.27.0 third-party notices](https://raw.githubusercontent.com/microsoft/onnxruntime/v1.27.0/ThirdPartyNotices.txt) | Bundled component notices | 200 |
| [YouTube Terms](https://www.youtube.com/static?template=terms) | Media service／user-rights boundary | 200 |
| [FFmpeg legal](https://ffmpeg.org/legal.html) | Build-dependent licensing explanation | 200 |
| [FFmpeg license](https://ffmpeg.org/doxygen/trunk/md_LICENSE.html) | GPL components對整個 build嘅影響 | 200 |
| [Python license](https://docs.python.org/3/license.html) | PSF license | 200 |
| [Apple SwiftUI documentation](https://developer.apple.com/documentation/swiftui) | System framework provenance | 200 |

## 尚未能由 upstream archive 單獨證明嘅項目

**UNKNOWN（archive-level）**：exact sherpa verifier 同 SenseVoice Yue `.tar.bz2` 內冇獨立 LICENSE，故無法單靠 archive 內容證明 license。呢份文件分開記錄 WSYue-ASR model card／sherpa runtime嘅 Apache-2.0、WenetSpeech-Yue dataset嘅 CC BY-NC 4.0，同 archives 缺少獨立 LICENSE嘅 provenance caveat；如將來對外分發 weights，應先再做一次法律／redistribution review。

補充：WenetSpeech-Yue **dataset** card係 CC BY-NC 4.0，而 repository processing code同 WSYue-ASR model card先係 Apache-2.0。官方文件冇明確解答 CC BY-NC training data對 downstream weights／INT8 conversion商業重分發嘅最終影響；因此本 App維持 direct-upstream-download，唔由網站、DMG或 git重分發 verifier weights，直至取得 ASLP／k2-fsa明確澄清。

**UNKNOWN（release-chain）**：Sortformer converted repository標示CC BY 4.0，而佢指向嘅NVIDIA upstream model標示NVIDIA Open Model License；FluidAudio runtime本身先係Apache-2.0。現有本機build只由用戶下載pinned compiled weights到Application Support，唔將weights放入git／App／DMG。公開下載頁、attribution、acceptable-use／redistribution義務同是否可由App代為下載，仍要以三層actual license text同final distribution flow做一次專門review；未完成前唔可以因SDK係Apache-2.0就稱整條chain已清。
